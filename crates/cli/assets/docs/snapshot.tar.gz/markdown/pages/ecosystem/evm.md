<a id="_top"></a>

# EVM & Solidity

Source: <https://docs.groundhog.dev/ecosystem/evm/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Groundhog concepts for Solidity and EVM developers.

This guide is for developers who know Solidity and the EVM. It uses familiar EVM concepts to compare Groundhog’s storage and execution rules.

For the foundational concepts (delta operations, commutativity, storage types), see [For Blockchain Developers](../start/for-blockchain-developers.md). This page builds on that with concrete patterns and a worked example.

<a id="the-contract-lifecycle"></a>

## The Contract Lifecycle

If you’ve deployed and called contracts on Ethereum, the Groundhog lifecycle will feel familiar. The mechanics differ, but the shape is the same: write a contract, compile it, deploy it, call functions on it.

<a id="writing"></a>

### Writing

Groundhog contracts are written in Rust and compiled to RV32 artifacts by default, not EVM bytecode. RV32 is Groundhog’s 32-bit RISC-V contract target. The SDK provides optional convenience macros, but you can also work directly with raw syscalls. A minimal contract looks like this:

```rust
use sdk::*;
use sdk::storage::NNInt;

#[contract_exception]
pub enum Error {
    NotAuthorized = 1,
}

#[derive(Debug)]
#[sdk::storage]
pub struct MyContract {
    value: NNInt,
}

#[contract(throws = Error)]
impl MyContract {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.try_get().none_if_missing().unwrap_or(0)
    }
}
```

Where Solidity uses `constructor()`, Groundhog contracts commonly expose an ordinary `initialize` method. Deployment does not call it automatically or enforce that it runs once, so the contract must guard one-time initialization when that matters. Where Solidity uses `uint256` state variables, Groundhog uses typed storage fields (`Balance`, `NNInt`, `Map<K, V>`, `Bytestring`). The type you choose determines how concurrent writes merge. This is the core difference: storage types enforce parallelism rules, not the developer.

<a id="compiling"></a>

### Compiling

Solidity compiles to EVM bytecode. Groundhog contracts compile to RV32, a 32-bit RISC-V target, by default:

```bash
groundhog build
```

The output is a `.rv32a` artifact plus [contract spec](../reference/contract-spec.md) sidecars, analogous to Solidity’s bytecode + ABI.

<a id="deploying"></a>

### Deploying

On Ethereum, you send a transaction containing bytecode, the EVM executes the constructor, and you get an address back. On Groundhog, deployment submits the contract artifact and creates a contract instance with a nonce:

1. **Include the RV32 artifact** in the deploy transaction.
2. **Create a contract instance** with a nonce. The nonce, combined with the deployer’s address and the contract hash, deterministically produces the contract address.

This is closer to Ethereum’s `CREATE2` than `CREATE`. The address is predictable before deployment.

The same contract artifact can be instantiated multiple times at different addresses. Initialization is a separate contract call unless an application-specific deployer combines deployment and initialization in one parent invocation.

<a id="calling"></a>

### Calling

On Ethereum, you send a transaction specifying a contract address, a function selector (4-byte hash), and ABI-encoded arguments. On Groundhog, a transaction specifies a contract address, an entrypoint ID (8-byte identifier), and CXS-encoded arguments.

The SDK generates entrypoint IDs from method names and the `#[contract]` macro handles encoding. From a developer’s perspective, calling a contract looks like this:

```rust
let client = MyContractClient::new(&contract_addr);
client.increment(42);
let value = client.get();
```

The generated client handles serialization. You don’t construct raw calldata.

<a id="reading-state"></a>

### Reading State

On Ethereum, you call `view` functions or read storage slots directly via `eth_getStorageAt`. On Groundhog, typed reads normally use `&self` methods through `groundhog_view`. The gateway also exposes `groundhog_getStorageAt` for low-level reads of a specific 32-byte contract-data key.

Transactions in a block share a starting snapshot. Ordinary storage reads can reflect earlier writes within the same transaction, but not writes from concurrent transactions. `RetrocausalQueue` has separate rules for observing concurrent inserts.

<a id="mental-model-shifts"></a>

## Mental Model Shifts

| Solidity / EVM                                 | Groundhog                                                                 | Why                                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `balance = newValue`                           | `balance.increase(amount)` or `decrease(amount)`                          | Deltas merge in parallel. Different absolute writes conflict.                              |
| `mapping(address => uint256)`                  | `Map<ContractAddress, Balance>`                                           | Same concept. The value type enforces non-negativity and enables parallel execution.       |
| Gas per operation                              | Gas exists for metering but costs zero. HOG deposit for storage capacity. | Gas limits bound computation, but no tokens are burned.                                    |
| Sequential execution                           | Parallel by default                                                       | Transactions execute concurrently against the same block snapshot.                         |
| `require(condition, "message")`                | `ensure(condition, Error::Variant)`                                       | Typed errors instead of string messages.                                                   |
| `revert()` / `require()`                       | `throw(error)`                                                            | Aborts the transaction. Cannot be caught within the same contract.                         |
| Solidity + EVM bytecode                        | Rust + RV32 artifact                                                      | Different VM and artifact format. Attached Groundhog contract blobs are capped at 256 KiB. |
| `constructor()`                                | Ordinary initialization method                                            | Deployment does not invoke it automatically; guard one-time initialization in storage.     |
| `msg.sender`                                   | `get_caller()`                                                            | Same concept.                                                                              |
| `view` / `pure`                                | `&self` / no self                                                         | Read-only methods don’t produce state changes.                                             |
| `public` / `external` / `internal` / `private` | `pub` / not pub                                                           | Rust visibility. Public methods become contract entrypoints.                               |
| OpenZeppelin inheritance                       | Trait implementations                                                     | Rust uses traits and composition, not inheritance.                                         |

<a id="execution-differences"></a>

## Execution Differences

The runtime and storage model change how these patterns are implemented.

<a id="reentrancy"></a>

### Reentrancy

See [Solidity’s contract-call semantics](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls) for the EVM side of this comparison.

On the EVM, calling an external contract hands over execution control. That contract can call back into yours before your state updates are complete. Entire categories of exploits (DAO hack, read-only reentrancy) exist because of this.

Groundhog bans reentrancy at the runtime level. A contract cannot be called while it is already on the call stack. The runtime enforces this: if contract A calls contract B, and B tries to call back into A, the call fails. This is not a convention or a guard you add. It is a protocol-level guarantee.

Within a transaction, reads can observe earlier writes and successful child calls. Snapshot isolation separates concurrent transactions; the explicit runtime check prevents reentrancy.

You do not need a `nonReentrant` guard for contract calls. Application logic and error handling still depend on call order.

<a id="ordering-and-mev"></a>

### Ordering and MEV

On Ethereum, pending transactions are visible in the mempool. Searchers can insert transactions before yours (front-running), after yours (back-running), or around yours (sandwich attacks). This is because transaction order within a block affects outcomes.

On Groundhog, commutative operations produce the same merged result regardless of execution order. Two compatible credits to the same account therefore produce the same final balance whichever executes first. Operations that conflict do not both land: one is excluded and returned to the mempool. The proposer still controls transaction selection and which contender wins a conflict, so Groundhog does not make a blanket claim that every application is MEV-free.

<a id="gas-limits-and-gas-price-estimation"></a>

### Gas Limits and Gas Price Estimation

EVM developers spend significant effort estimating gas, setting gas limits, and handling out-of-gas reverts. Groundhog has gas limits for metering (bounding computation, preventing infinite loops), but gas costs zero tokens. You hold HOG tokens for capacity (compute throughput and storage). There is no gas price to estimate. Exceeding the declared gas limit still faults the transaction, and the declared limit determines its scheduling cost.

<a id="nonce-management"></a>

### Nonce Management

Every Ethereum transaction requires a sequential nonce per account. Sending transactions in parallel requires careful nonce tracking, and a stuck transaction blocks all subsequent ones. Groundhog has no sequential nonces. Replay protection uses a `Uniquifier` (a per-address value made of a block expiry height and an arbitrary nonce); it just has to be unique, not monotonic, so transactions from the same address can execute concurrently and out of order.

<a id="integer-overflowunderflow"></a>

### Integer Overflow/Underflow

Solidity 0.8+ added checked arithmetic by default, but earlier versions required SafeMath. Groundhog’s `Balance` type enforces non-negativity at the storage layer. Checked `increase` and `decrease` abort automatically if the result would overflow or underflow. You don’t write separate arithmetic checks because the type handles them.

<a id="the-approve-race-condition"></a>

### The `approve()` Race Condition

The ERC-20 `approve(spender, amount)` function sets an absolute allowance. If you approve 100, then want to change it to 50, the spender can front-run your second `approve` and spend the original 100 before the new value takes effect.

Groundhog’s ERC-20 pattern uses `adjust_allowance(spender, diff)` instead. You send a delta (+50 or -50), not an absolute value. Concurrent allowance adjustments merge correctly because addition commutes.

<a id="pattern-adaptations"></a>

## Pattern Adaptations

<a id="balance-transfer"></a>

### Balance Transfer

**Solidity:**

```solidity
mapping(address => uint256) private balances;

function transfer(address to, uint256 amount) external {
    require(balances[msg.sender] >= amount, "Insufficient balance");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

**What changes:** No explicit balance check. `decrease` loads the sender and aborts during contract execution if its snapshot balance is insufficient. `lazy_increase` skips the receiver load and defers its bound check until delta reservation. Both operations produce mergeable deltas. Two transfers from the same account in the same block execute against the snapshot and produce deltas. If the account has enough balance for both, both succeed. If not, one is excluded.

<a id="access-control"></a>

### Access Control

**Solidity:**

```solidity
address public owner;

modifier onlyOwner() {
    require(msg.sender == owner, "Not owner");
    _;
}

function mint(address to, uint256 amount) external onlyOwner {
    balances[to] += amount;
    totalSupply += amount;
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    contract_owner: Value<ContractAddress>,
    // ...
}

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    ensure(get_caller() == self.contract_owner.get(), Error::NotOwner);
    self.total_supply.increase(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

**What changes:** No modifier system. Rust doesn’t have decorators. Use `ensure(condition, error)` at the top of the method. The pattern is the same (check authorization, then act), just expressed differently. For contracts with multiple roles, store a `Map<ContractAddress, Value<Role>>` and check against it.

<a id="constructor-and-initialization"></a>

### Constructor and Initialization

**Solidity:**

```solidity
contract Token {
    address public owner;
    uint256 public totalSupply;

    constructor(uint256 initialSupply) {
        owner = msg.sender;
        totalSupply = initialSupply;
        balances[msg.sender] = initialSupply;
    }
}
```

**Groundhog:**

```rust
use sdk::*;
use sdk::storage::{Balance, Map, Value};
use groundhog_erc20_if::{Amount, MintEvent, log_mint_event};

#[contract_exception]
pub enum Error {
    AlreadyInitialized = 1,
}

#[sdk::storage]
pub struct Token {
    contract_owner: Value<ContractAddress>,
    total_supply: Balance,
    balances: Map<ContractAddress, Balance>,
}

#[contract(throws = Error, emits(MintEvent))]
impl Token {
    pub fn initialize(&mut self, initial_supply: Amount) {
        ensure(
            self.contract_owner.try_get().none_if_missing().is_none(),
            Error::AlreadyInitialized,
        );
        let caller = get_caller();
        self.contract_owner.set_exclusive(&caller);
        self.total_supply.increase(initial_supply);
        self.balances.at_mut(&caller).lazy_increase(initial_supply);
        log_mint_event(&caller, initial_supply);
    }
}
```

The `groundhog_erc20_if` dependency provides the amount type and mint event helpers. See [Build a Token](../tutorials/build-a-token.md) for dependency setup and a complete token contract.

**What changes:** Groundhog has no special constructor syntax. Call `initialize` after deployment, or have an application-specific deployer invoke it in the same parent transaction. The runtime does not provide once-only constructor semantics. This example uses the owner field as its initialization marker. The exclusive write prevents concurrent initializations from both landing, even for the same caller. State initialization uses the same storage operations as everything else.

<a id="events"></a>

### Events

**Solidity:**

```solidity
event Transfer(address indexed from, address indexed to, uint256 value);

function transfer(address to, uint256 amount) external {
    // ... transfer logic ...
    emit Transfer(msg.sender, to, amount);
}
```

**Groundhog:**

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    // ... transfer logic ...
    log_transfer_event(&caller, receiver, amount);
}
```

**What changes:** Fields marked `#[topic]` become topics on typed events. Interface 0.1.41 uses `TransferEvent` and `AllowanceChangeEvent`, whose `.log()` methods encode the event. Allowance changes carry signed deltas, not absolute approvals. Filtering happens through the indexer/RPC. See [Add Events](../tutorials/add-events-to-a-contract.md) and [Contract Spec](../reference/contract-spec.md#events).

<a id="erc-20-side-by-side"></a>

## ERC-20 Side-by-Side

Here’s how the core of an ERC-20 token compares. This isn’t the full implementation (see [Build a Token](../tutorials/build-a-token.md) for that), but it shows the key design differences.

**Solidity (OpenZeppelin-style):**

```solidity
contract ERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;

    function transfer(address to, uint256 amount) public returns (bool) {
        require(_balances[msg.sender] >= amount, "Insufficient");
        _balances[msg.sender] -= amount;
        _balances[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) public returns (bool) {
        _allowances[msg.sender][spender] = amount;  // absolute write
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public returns (bool) {
        require(_allowances[from][msg.sender] >= amount, "Allowance exceeded");
        require(_balances[from] >= amount, "Insufficient");
        _allowances[from][msg.sender] -= amount;
        _balances[from] -= amount;
        _balances[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct TokenContract {
    contract_owner: Value<ContractAddress>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Balance>>,
    total_supply: Balance,
}

#[contract(version = "0.1.5")]
impl ERC20 for TokenContract {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let owner = get_caller();
        self.balances.at_mut(&owner).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
        log_transfer_event(&owner, receiver, amount);
    }

    fn adjust_allowance(&mut self, spender: &ContractAddress, diff: Difference) {
        let owner = get_caller();
        let mut allowances = self.allowances.at_mut(&owner);
        let mut allowance = allowances.at_mut(spender);
        if diff >= 0 {
            allowance.increase(diff as u128);
        } else {
            allowance.decrease(diff.unsigned_abs());
        }
        log_approval_event(&owner, spender, diff);
    }

    fn transfer_from(&mut self, owner: &ContractAddress, receiver: &ContractAddress, amount: Amount) {
        let spender = get_caller();
        self.allowances.at_mut(owner).at_mut(&spender).decrease(amount);
        self.balances.at_mut(owner).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
        log_transfer_event(owner, receiver, amount);
    }
}
```

**Key differences:**

- **No explicit balance checks.** `Balance::decrease` aborts if the result would be negative. The check is built into the type.
- **`adjust_allowance` instead of `approve`.** Deltas instead of absolute writes. Compatible relative adjustments merge. The application must choose this API explicitly.
- **No success boolean.** These ERC-20 methods return unit on success and abort on failure, instead of returning `bool`. Other Groundhog methods can return typed values.
- **No `require` guards.** `Balance` enforces non-negativity. You only need `ensure()` for business logic checks (authorization, etc.), not arithmetic safety.
- **Parallel execution.** Two transfers debiting the same account both run against the snapshot. If the account has enough balance for both, both succeed and their deltas merge. If not, one is excluded and returned to the mempool.

For the full implementation with initialization, minting, burning, and tests, see [Build a Token](../tutorials/build-a-token.md).

<a id="what-doesnt-exist"></a>

## What Doesn’t Exist

These EVM features have no Groundhog equivalent. Set your expectations:

| EVM Feature                        | Status on Groundhog                            | Alternative                                                                                |
| ---------------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `msg.value` (send ETH with call)   | Does not exist                                 | Transfer tokens explicitly via a token contract                                            |
| `delegatecall` / proxy patterns    | Does not exist                                 | Contracts are immutable. Deploy new versions at new addresses.                             |
| `selfdestruct`                     | Does not exist                                 | Contracts are permanent                                                                    |
| `receive()` / `fallback()`         | Does not exist                                 | All methods must be explicitly defined                                                     |
| `block.timestamp` / `block.number` | `get_block_timepoint()` / `get_block_height()` | The timepoint is coarse consensus time chosen by the proposer, not a per-transaction clock |
| `gasleft()`                        | `stats::gas_remaining()`                       | Available for execution control, but gas costs zero tokens                                 |
| Contract inheritance               | Does not exist                                 | Use Rust traits and composition                                                            |
| 24KB EVM runtime-code limit        | Different limit                                | Attached Groundhog contract blobs are capped at 256 KiB                                    |
| Storage slot packing               | Does not exist                                 | Each storage field is independent                                                          |

<a id="next-steps"></a>

## Next Steps

- [Contract quickstart](../get-started/contract.md) for a first deployment, and [Project structure](../contracts/project-structure.md) for the generated files
- [Build a Counter](../tutorials/build-a-counter.md) for a step-by-step first contract
- [Build a Token](../tutorials/build-a-token.md) for the full ERC-20 implementation
- [Merged Deltas](../programming-model/execution.md#merged-deltas) for the contract-level merge model
- [Storage Types](../reference/storage-types.md) for the full `Balance`, `NNInt`, `Map`, and `Bytestring` API
