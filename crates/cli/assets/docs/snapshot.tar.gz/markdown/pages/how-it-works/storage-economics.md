<a id="_top"></a>

# Compute, Capacity & Storage

Source: <https://docs.groundhog.dev/how-it-works/storage-economics/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

How HOG provides scheduling capacity and refundable storage deposits, while gas meters execution without a token fee.

Groundhog’s economic model is capital-based, not usage-based. You hold HOG tokens to get capacity. You don’t pay per operation.

HOG has two jobs: providing scheduling capacity and backing stored data.

<a id="the-two-jobs-of-hog"></a>

## The Two Jobs of HOG

Every HOG token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Free HOGs determine how many transactions you can push through the network. Locked HOGs hold your data on-chain. The tradeoff is direct: every HOG you lock for storage is one less HOG contributing to your throughput share.

<a id="execution-free-throughput-allocated"></a>

## Execution: Free, Throughput-Allocated

Running contract code has no token fee. It still uses finite execution and scheduling capacity.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

There is no unused-gas token refund. Metering does not debit or refund the sender’s HOG balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.

<a id="balance-proportional-scheduling"></a>

### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to free HOG balances over time. If account A holds 1,000 free HOGs and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s free HOGs sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, the transaction’s declared gas limit moves that much HOG capacity from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose HOGs have waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

HOGs cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

HOG transferred between accounts enters the recipient’s scheduling queue as newly received capacity. It does not carry the sender’s accumulated scheduling age.

<a id="storage-refundable-deposits"></a>

## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks HOG according to the [storage type](../programming-model/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees HOG for other storage or scheduling capacity.

<a id="cost-accounting"></a>

### Cost Accounting

Every contract has a HOG balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts HOG from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked HOG to the contract’s free balance.

If an address does not have enough free HOG to cover a storage change, reservation can fail for insufficient funds. The transaction is excluded from that proposal and returned to the mempool. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Transaction Lifecycle](transaction-lifecycle.md#outcomes-to-distinguish).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.

<a id="configured-costs"></a>

### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.

<a id="sponsoring-users"></a>

### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.

<a id="the-native-token"></a>

## The Native Token

A sufficient first HOG credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](../typescript/accounts.md#request-devnet-funds).

HOG is implemented by a native precompiled token contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting.

<a id="toll-free-calls"></a>

## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.

<a id="related-documentation"></a>

## Related Documentation

- [Contract Execution](../programming-model/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](execution-model.md): How compatible state changes are admitted
- [System Overview](architecture.md): The component map
- [Storage Types Reference](../reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](../get-started/contract.md): Deploy your first contract
