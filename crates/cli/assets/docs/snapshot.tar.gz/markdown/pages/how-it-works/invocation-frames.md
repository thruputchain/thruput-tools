<a id="_top"></a>

# Invocation Frames

Source: <https://thruput.network/docs/how-it-works/invocation-frames/>

Documentation source: `245ae77a61dbf80ce178bf622622c0e73f1230a6`. Hosted docs may be newer than this snapshot.

How contract calls track state, return results, and merge or discard child effects.

An invocation frame is the execution context for one contract call. A transaction begins with a root frame. A [cross-contract call](../contracts/cross-contract-calls.md) creates a child frame and returns control to its parent when it finishes.

The same model applies to RV32 contracts and native system contracts.

<a id="frame-structure"></a>

## Frame Structure

| Part          | Contents                                                                          |
| ------------- | --------------------------------------------------------------------------------- |
| Call context  | Contract address, entrypoint, calldata, invocation flags, and gas budget          |
| State changes | Storage operations and deployments made by this frame and its successful children |
| Events        | Events emitted by this frame and its successful children                          |
| Child result  | Status and return bytes from the most recent child call                           |
| Resource use  | Gas consumed by this frame and its children                                       |

A transaction’s root invocation has no child-call flags. A child’s gas budget is capped by its parent’s remaining budget. See [Invocation configuration](../contracts/cross-contract-calls.md) for SDK controls.

<a id="call-stack"></a>

## Call Stack

```text
Root: wallet.execute
  Child: counter.increment
    Nested child: another contract method
```

Each child has its own execution context. Its ordinary reads use the block snapshot plus visible changes from the current transaction. A child call is part of that transaction, not a separate transaction or a separate block.

<a id="frame-lifecycle"></a>

## Frame Lifecycle

<a id="1-creation"></a>

### 1. Creation

The runtime creates a frame with the call context and an empty record of local changes and events.

<a id="2-execution"></a>

### 2. Execution

Contract code uses [syscalls](../reference/syscalls.md) to read state, record changes, emit events, and call other contracts. Child calls can create further frames.

<a id="3-completion"></a>

### 3. Completion

| Result           | Return bytes                                  | Contract effects                      |
| ---------------- | --------------------------------------------- | ------------------------------------- |
| **Return** (`0`) | Returned to the caller                        | Preserved for merging into the parent |
| **Fault** (`1`)  | Empty                                         | Discarded                             |
| **Abort** (`2`)  | Returned to the caller, usually as error data | Discarded                             |

A fault can result from an invalid instruction, invalid memory access, or exhausted gas. An abort is an explicit revert. SDK-generated wrappers use the Return syscall with its revert flag to produce a return or abort. Gas consumed before either failure remains consumed; it is computation metering, not a token fee.

<a id="4-merge-into-parent-or-finalize-for-root"></a>

### 4. Merge into Parent (or Finalize for Root)

On a successful child return, its storage changes, deployments, and events become part of the parent frame. They have not committed to the ledger yet. On a child abort or fault, those effects are discarded.

In either case, the parent receives the child’s status and return buffer and accounts for its gas use. A recoverable SDK call lets the parent inspect the failure. A throwing call propagates an unhandled failure. See [Cross-Contract Calls](../contracts/cross-contract-calls.md#error-handling).

When the root returns successfully, the transaction’s changes must still pass reservation against the proposed block. A committed root abort or fault records the failure while discarding contract effects; protocol bookkeeping such as replay protection remains. See [Transaction Lifecycle](transaction-lifecycle.md#root-frame-completion).

<a id="5-pop-and-return"></a>

### 5. Pop and Return

The runtime discards the completed frame’s guest memory, registers, and stack. Control returns to the parent, or execution ends for the root. Only state written through the storage APIs can persist beyond execution.

<a id="example-nested-contract-calls"></a>

## Example: Nested Contract Calls

Suppose contract A calls B, C, and D using recoverable calls:

| Step                         | Outcome                                          | Changes retained by A |
| ---------------------------- | ------------------------------------------------ | --------------------- |
| A writes `AAA`               | A continues                                      | `AAA`                 |
| B writes `BBB` and returns   | Child effects merge                              | `AAA`, `BBB`          |
| C writes `CCC` and aborts    | Child effects are discarded; A handles the error | `AAA`, `BBB`          |
| D writes `DDD` and faults    | Child effects are discarded; A handles the fault | `AAA`, `BBB`          |
| A writes `FINAL` and returns | Root changes enter reservation                   | `AAA`, `BBB`, `FINAL` |

If the transaction is admitted and committed, the ledger contains `AAA`, `BBB`, and `FINAL`. C’s and D’s writes never commit. If A instead propagates either child failure, A’s contract effects are discarded too.

<a id="related-documentation"></a>

## Related Documentation

- [Cross-Contract Calls](../contracts/cross-contract-calls.md): SDK call and error-handling patterns
- [Authorization](authorization.md#passing-auth-tokens): Auth-token ownership across frames
- [Transaction Lifecycle](transaction-lifecycle.md): Reservation and final outcomes
- [Contract artifacts and addresses](contracts.md): Code and deployment identities
