<a id="_top"></a>

# Explorer

Source: <https://thruput.network/docs/tools/block-explorer/>

Documentation source: `fd91c2019cd8f984aeda15c0303042679e1c8825`. Hosted docs may be newer than this snapshot.

Use the Futurenet explorer to look up transactions, inspect receipts and events, and check address activity.

Use the [Futurenet explorer](https://explorer.thruput.network/) to look up transactions, inspect receipts and events, and check address balances and recent activity. Sign in if prompted.

<a id="look-up-a-transaction-or-address"></a>

## Look Up a Transaction or Address

1. Open the [Futurenet explorer](https://explorer.thruput.network/).
2. Paste the transaction hash or address into the search field.
3. Select **Search**.

The home page also lists recent native-token transfers. Select a transaction to inspect it, or follow an address link to view that address.

<a id="transactions"></a>

### Transactions

The transaction page shows:

- Transaction status and, once committed, block height and execution result.
- Receipt events, including decoded token transfers, mints, and burns where supported.
- Raw receipt data for debugging.

Events without a supported decoder appear as raw topics and data.

<a id="addresses-and-tokens"></a>

### Addresses and Tokens

The address page shows the native-token balance. For non-token addresses, it also shows recent transactions and sent or received native-token transfers. Recognized token contracts show token metadata and token transfer history. Other contracts can show their emitted events.

Address transaction history combines transactions whose root invocation targets the address with native-token transfer activity. It does not cover every nested invocation or every token transfer involving the address.

<a id="share-a-result"></a>

### Share a Result

Copy the page URL to share a transaction or address:

```text
https://explorer.thruput.network/tx/<transaction-hash>
https://explorer.thruput.network/address/<address>
```

<a id="inspect-state-without-an-explorer"></a>

## Inspect State Without an Explorer

Use the CLI for terminal workflows, local nodes, or when the explorer is unavailable:

```bash
thruput balance <wallet-or-address> --profile futurenet
thruput tx show <transaction-hash> --profile futurenet
thruput view <contract-or-alias> <method> --profile futurenet
thruput storage <contract-or-alias> 0x<32-byte-key> --profile futurenet
```

These commands use Futurenet. For a local node, use `--profile local` instead. The hosted explorer does not show your local node’s transactions.

Use the [JSON-RPC API](../reference/json-rpc-api.md) directly for receipts, status, address-rooted history, and event pagination.

<a id="if-a-result-is-missing"></a>

## If a result is missing

Check the full hash or address and the network that produced it. Indexer-backed history can lag, so use `thruput tx show` for the original transaction before submitting another one. A pending or missing result does not prove failure.
