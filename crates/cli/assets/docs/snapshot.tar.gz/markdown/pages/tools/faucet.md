<a id="_top"></a>

# Faucet

Source: <https://thruput.network/docs/tools/faucet/>

Documentation source: `245ae77a61dbf80ce178bf622622c0e73f1230a6`. Hosted docs may be newer than this snapshot.

Request native test tokens for a Futurenet wallet and check the funding result.

Use the [hosted faucet](https://thruput-faucet.up.railway.app) to fund a Futurenet wallet or contract address with native test tokens. These tokens have no monetary value.

<a id="request-funds-in-the-browser"></a>

## Request funds in the browser

1. Copy your public address from the [Wallet Extension](wallet-extension.md) or your [CLI wallet](../cli/wallets.md#create-a-key-and-wallet).
2. Open the [faucet](https://thruput-faucet.up.railway.app).
3. Paste your wallet address into **Wallet address**.
4. Click **Request airdrop**. The faucet sets the amount.
5. Wait for the **Sent … native tokens** notice, then check the receiving wallet’s balance. The notice also shows a shortened transaction hash.

If the page cannot connect, it shows **Faucet unavailable** and disables the request. Click **Retry** to connect again.

The faucet needs only a public address. Amounts, cooldowns, and quotas depend on the deployment; follow the values and errors shown by the service.

<a id="cli"></a>

## CLI

With a Futurenet wallet already configured:

```bash
thruput airdrop --profile futurenet
thruput balance --profile futurenet
```

The faucet selects the amount, so omit `--amount` for remote requests. For initial key and wallet setup, follow the [CLI quickstart](../get-started/cli.md).

The CLI retains a nonce for a pending remote airdrop. If the outcome is unclear, rerun the same command to resume that request. A timeout does not prove that funding failed.

<a id="typescript"></a>

## TypeScript

Use the client or wallet’s `requestAirdrop` action. [Script accounts](../typescript/accounts.md) covers funding and retaining a request nonce for recovery. The client must use a cluster with airdrop support.

For Localnet, use your local node’s airdrop through the [CLI](../cli/local-node.md) or SDK rather than the hosted Futurenet faucet.

<a id="if-funding-does-not-appear"></a>

## If funding does not appear

- Check that the recipient address and wallet network match the request.
- Follow the displayed cooldown before requesting again.
- If you have a transaction hash, inspect it in the [Explorer](block-explorer.md). A committed transaction must also have a successful execution result.
- If the browser lost its connection, check the balance before starting a new request.
