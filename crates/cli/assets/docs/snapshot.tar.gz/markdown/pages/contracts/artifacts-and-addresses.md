<a id="_top"></a>

# Contract artifacts and addresses

Source: <https://www.thruput.network/docs/contracts/artifacts-and-addresses/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.

An artifact is compiled contract code. Its code hash identifies that code; a deployment address identifies one instance with its own storage. The same artifact can be deployed at multiple addresses.

This page explains those identities and the rules of deployment. For deployment commands, see [Deploy and call](../cli/deploy-and-call.md).

User contracts compile to RV32, Project Thruput’s 32-bit RISC-V contract target. Native system contracts serve separate purposes, described below.

<a id="contract-types"></a>

## Contract Types

<a id="rv32-contracts"></a>

### RV32 Contracts

`thruput build` compiles the contract’s RV32 entrypoint wrapper for `riscv32im-unknown-none-elf`, lowers that ELF into a deployable `.rv32a` artifact, and finalizes its contract-spec sidecars.

For a crate named `counter`, the default build writes:

```txt
target/thruput/counter.rv32a
target/thruput/counter.rv32.json
target/thruput/counter.spec.xdr
target/thruput/counter.spec.json
```

The `.rv32a` file is the executable contract artifact. `thruput deploy` wraps those bytes in the protocol’s `Contract::kRv32` variant before signing and submitting the deploy transaction.

Deployment must satisfy the network’s limits on attached contract size, RV32 code, guest memory, and new contracts per transaction. Client and gateway submission limits also apply. Use the selected network’s configuration rather than assuming a fixed maximum.

<a id="entrypoints"></a>

#### Entrypoints

Every callable method is identified by an 8-byte `ContractEntrypointID`. The SDK’s `#[contract]` macro emits one dispatch record per method into the `thruput_rv32_entrypoints` link section.

When hogd invokes an RV32 contract, it enters the guest at `_start` with the method ID in registers. The RV32 runtime dispatches by scanning that section, then calls the generated wrapper for the matching method. That wrapper decodes calldata, calls the Rust method, and returns through the Return syscall.

Entrypoint IDs can be arbitrary 8-byte values at the protocol layer. The SDK derives them as the first 8 bytes of `SHA256("<interface>::<major>::<method>")`. See [SDK Macros](reference/sdk-macros.md) and the [contract spec reference](../reference/contract-spec.md) for the developer-facing shape.

<a id="artifact-shape"></a>

#### Artifact Shape

Most developers should let the [Thruput CLI](../cli/build-and-test.md) produce RV32 artifacts. Under the hood, the RV32 lowerer:

- Parses the `riscv32im-unknown-none-elf` contract binary.
- Validates the layout expected by the Project Thruput RV32 runtime.
- Packs code, initial memory, metadata, and section digests into the `.rv32a` artifact.
- Self-verifies the artifact before writing it.

The node executes the lowered artifact through the RV32 runtime. Contract state does not live in guest memory. Durable state must be written through Project Thruput storage APIs.

<a id="artifact-format-and-compatibility"></a>

#### Artifact Format and Compatibility

CLI 0.48.0 builds RV32 format v7. The artifact header declares the syscall API version from the guest ELF. Gas metering uses the chain’s schedule.

To admit a v7 artifact, the chain must accept format 7. The artifact’s syscall API major version must match the runtime, and the minor version must fall within the chain’s configured range. Check the artifact format range in [`getChainConfig`](../reference/json-rpc-api.md#getchainconfig). Futurenet platform 0.1.38 accepts formats 5 through 7. Rebuild with the current CLI and SDK when you want to use the new syscalls.

<a id="native-precompiled-contracts"></a>

### Native Precompiled Contracts

Native precompiled contracts are implemented directly inside the Project Thruput runtime. They are used for trusted system behavior, such as the native token contract, and can have permissions that user-deployed guest contracts do not have.

Users cannot deploy native contracts. Network configuration assigns system contract addresses; implementations are identified by values from `HogexecPrecompiledNativeContracts`.

<a id="contract-deployment"></a>

## Contract Deployment

Contracts are deployed by the DeployContract [system call](reference/syscalls.md). In normal CLI usage, `thruput deploy` calls `deploy` on the signing account. For a pubkey account, that call runs the native DefaultWallet, which calls DeployContract with the artifact hash and deployment nonce.

<a id="contract-identification"></a>

### Contract Identification

Contracts are identified by the SHA256 hash of the XDR-encoded `Contract` union. For an RV32 artifact, the deploy hash is:

```txt
SHA256(XDR(Contract::kRv32 {
    rv32_contract: ContractBlob {
        data: <.rv32a artifact bytes>
    }
}))
```

This is not just the SHA256 hash of the raw `.rv32a` bytes. The XDR wrapper and `kRv32` type tag are part of the hash preimage.

<a id="deploycontract-syscall"></a>

### DeployContract Syscall

To deploy a contract, the caller invokes DeployContract with two arguments:

- `nonce`: a 32-byte value chosen by the caller
- `contract_hash`: the SHA256 hash identifying the contract artifact to deploy

The system then:

1. Verifies that the contract identified by `contract_hash` is available for deployment.
2. Computes the deployment address: `ContractAddress = SHA256(XDR(ContractDeploymentHashPreimage))`.
3. Writes the contract’s `DeployedContractHash` to the computed address’s `Metadata` key.
4. Stores the contract code separately in the deduplicated contract code store.

<a id="deterministic-address-derivation"></a>

### Deterministic Address Derivation

The address to which a contract is deployed is computed from the deployer address, nonce, and contract hash. Anyone can predict the address before deployment.

A single contract artifact can be deployed at many addresses. Each deployment has separate metadata and separate storage.

In Rust SDK 0.64.0, a factory can use a typed `CodeHash<C>` and a `DeployNonce`. `CodeHash::deploy` returns an [`Address<C>`](cross-contract-calls.md#typed-addresses), which keeps the expected client interface with the new address.

<a id="deployment-preimage"></a>

### Deployment Preimage

```rust
pub struct ContractDeploymentHashPreimage {
    /// Address of the contract performing the deployment.
    pub deployer_address: ContractAddress,

    /// Arbitrary 32-byte nonce chosen by the deployer.
    pub nonce: SHA256Hash,

    /// SHA256 hash of the contract artifact.
    pub contract_hash: SHA256Hash,
}
```

Under XDR encoding, this structure serializes as the concatenation of its fields:

```txt
XDR(ContractDeploymentHashPreimage) = deployer_address || nonce || contract_hash
```

<a id="example"></a>

### Example

A wallet contract at address `0x1234...` deploys `counter.rv32a`:

```txt
deployer_address = 0x1234...
nonce            = 0x5678...
contract_hash    = SHA256(XDR(Contract::kRv32 {
                       rv32_contract: ContractBlob { data: bytes(counter.rv32a) }
                   }))
                 = 0xabcd...

ContractAddress  = SHA256(0x1234... || 0x5678... || 0xabcd...)
                 = 0x9999...
```

The deployed counter contract’s address is now `0x9999...`.

This scheme is analogous to Ethereum’s `CREATE2` opcode because the address can be calculated before deployment.

<a id="deployment-eligibility"></a>

## Deployment Eligibility

To be deployed via DeployContract, a contract identified by `contract_hash` must be available in the context of the current transaction.

A contract is available if either of the following holds:

- The contract code already exists in the on-chain contract code store.
- The contract is included in the `contracts_to_deploy` field of the current transaction.

```rust
pub struct Transaction {
    pub invocation: Invocation,
    pub uniquifier: Uniquifier,

    /// New contract code to make available for deployment.
    pub contracts_to_deploy: VecM<Contract>,

    /// Authorization claim specifying required signatures.
    pub auth_claim: AuthClaim,
}
```

`contracts_to_deploy` makes contract code available, but it does not deploy the code to an address by itself. Deployment to a specific address happens when a contract invokes DeployContract.

Example flow:

1. The transaction includes `contracts_to_deploy: [Contract::kRv32 { rv32_contract: ContractBlob { data: <artifact bytes> } }]`.
2. The contract code becomes available under its `contract_hash`.
3. During execution, a contract calls `DeployContract(nonce, contract_hash)`.
4. The system computes the deployed address and writes its metadata.

<a id="address-metadata"></a>

## Address Metadata

When a contract is deployed, the system writes its `DeployedContractHash` to the storage key `(contract_address, StorageKeyType::Metadata)`.

```rust
pub struct DeployedContractHash {
    /// SHA256 hash of the contract code.
    pub hash: SHA256Hash,

    /// Size of the contract in bytes.
    pub contract_size: u32,

    /// Type of contract: kNative, kMockTest, or kRv32.
    pub contract_type: ContractType,
}
```

This metadata allows the executor and off-chain tools to:

- Verify what code is running at an address.
- Determine the contract type without loading bytecode.
- Calculate storage costs from the contract size.

The metadata is set during deployment and persists for the lifetime of the contract address.

<a id="deployment-concurrency"></a>

## Deployment Concurrency

Multiple transactions may deploy the same contract to the same address in the same block. Project Thruput does not consider concurrent deployments of the same contract to the same address to be in conflict. Collision resistance of SHA256 implies that different contracts cannot be deployed to the same address.

If a contract requires one-time initialization, implement that guard in contract storage.

<a id="redeployment-and-immutability"></a>

## Redeployment and Immutability

Once a contract is deployed to an address, that address’s `DeployedContractHash` cannot be changed. Deployed contracts are immutable.

<a id="related-documentation"></a>

## Related Documentation

- [Thruput CLI](../cli.md): RV32 builds, local nodes, deployment, and codegen
- [Invocation Frames](invocation-frames.md): execution context and call stack management
- [Syscalls](reference/syscalls.md): system calls available to contracts
- [SDK Macros](reference/sdk-macros.md): SDK entrypoint IDs and generated clients
- [Contract Spec](../reference/contract-spec.md): generated method, type, event, and error metadata
- [System Overview](../architecture/system-overview.md): the component map
