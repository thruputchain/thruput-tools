<a id="_top"></a>

# Project structure

Source: <https://thruput.network/docs/contracts/project-structure/>

Documentation source: `3cc5d07f366f6182e06af875daffd57a90a66e06`. Hosted docs may be newer than this snapshot.

Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.

`thruput new` creates a minimal Cargo contract project by default. Use `thruput new my-counter --template counter` for the counter layout below, including its example methods and tests. Keep the generated dependency versions, compiler settings, and CLI configuration together.

<a id="generated-files"></a>

## Generated files

```text
my-counter/
  Cargo.toml              # Package, SDK dependencies, and build features
  AGENTS.md               # Instructions for coding agents
  build.rs                # Integration-test setup
  thruput.toml          # Project profiles and contract aliases
  rust-toolchain.toml     # Selected compiler and targets
  .cargo/
    config.toml           # Registry and Cargo configuration
    contract.toml         # Contract-build configuration
  src/
    lib.rs                # Library modules
    implementation.rs     # Contract logic, storage, errors, and events
    main.rs               # Contract entrypoint wrapper
  tests/
    test.rs               # Native logic tests
    test_rv32.rs          # Contract artifact tests
    integration.rs        # Tests against a running node
```

The `.gitignore` excludes build output and project-local runtime state.

<a id="build-artifacts"></a>

## Build artifacts

`thruput build` compiles the entrypoint for RV32, Project Thruput’s 32-bit RISC-V contract target. It lowers the compiler output into an artifact the node can execute.

For `my-counter`, the output under `target/thruput/` includes:

- `my_counter.rv32a`: deployable contract artifact.
- `my_counter.rv32.json`: lowering metadata.
- `my_counter.spec.xdr`: binary contract specification.
- `my_counter.spec.json`: readable contract specification.

The specification describes the contract interface and supports [TypeScript binding generation](../tools/typescript-bindings.md).

<a id="test-modes"></a>

## Test modes

- `cargo test` runs the native contract tests.
- `thruput test` runs the RV32 artifact tests.
- `thruput test --integration` manages a local node for the integration tests.

See [Testing](../programming-model/testing.md) for the execution modes, generated integration environment, and how to add assertions.

<a id="sdk-layers"></a>

## SDK layers

Generated projects start with the SDK’s contract and storage macros. Use typed storage handles for normal state access. Lower-level syscall wrappers are available when you need a custom abstraction.

These layers can be combined within a contract. Use [Storage Types](../programming-model/storage-types.md) to choose an API, [SDK Macros](../reference/sdk-macros.md) for macro reference, and [Rust API Docs](../tools/rust-api-docs.md) for exact signatures.
