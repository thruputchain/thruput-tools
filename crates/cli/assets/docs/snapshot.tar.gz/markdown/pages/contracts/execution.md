<a id="_top"></a>

# Contract Execution

Source: <https://www.thruput.network/docs/contracts/execution/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.

Your contract reads from a frozen snapshot and produces typed storage changes, called deltas. Ordinary storage reads do not see other transactions’ writes. The runtime checks whether each transaction’s deltas can coexist with the other changes landing in the block. Deltas that can coexist form the next committed state. Transactions with conflicting deltas are excluded from that proposal.

Read this page first, then [Storage Types](storage-types.md). It explains the behavior your contract relies on without requiring the engine’s lock and reservation implementation.

<a id="rules-that-cause-bugs"></a>

## Rules That Cause Bugs

- **Reads are not checked at commit.** A decision based on a value that another transaction can change in the same block can be stale. See [Snapshot Isolation](execution.md#snapshot-isolation).
- **Decreases must fit the base.** All decreases admitted to one `Balance` or `NNInt` in a block must fit within the base value. For `Balance` and ordinary `NNInt` updates, the base is the start-of-block snapshot; an explicit `NNInt::set_add` uses the base it sets. Same-block credits do not count. See [Merged Deltas](execution.md#merged-deltas) and [NNInt](nnint.md).
- **Exclusion applies to one proposal.** It does not consume the replay nonce or guarantee automatic requeue. A committed abort, revert, or out-of-gas fault consumes the nonce. See [Exclusion](execution.md#exclusion).
- **Absolute writes merge only when equal.** Two `Value`, `Bytestring`, or `NNInt::set` writes to one key land together only when they write the same value. See [Storage Types](storage-types.md#choosing-a-type).
- **Some operations allow one writer per block.** One transaction per block can consume from a queue, push or pop a `Vector`, or hold an exclusive write on a key. See [RCQ](storage-types.md#rcqt--retrocausalqueue) and [Exclusive Writes](storage-types.md#exclusive-writes).
- **The full gas limit is reserved.** Scheduling uses the declared limit, not the gas used. See [Gas](execution.md#gas).

<a id="snapshot-isolation"></a>

## Snapshot Isolation

All transactions in a block read the same committed state from the previous block. Ordinary storage reads do not see another transaction’s writes within the block. Reads include changes made within your transaction, including successful child calls. Other transactions cannot change the snapshot you read.

Reads are not validated when the transaction commits. Only writes can conflict. If two transactions each read `total_supply`, find room under a cap, and mint, both can land and exceed the cap. Enforce a rule that spans transactions with a write the runtime checks: a `Balance` or `NNInt` floor, a [`CapacityConstraint`](storage-types.md#capacityconstraint), or an [exclusive write](storage-types.md#exclusive-writes).

`RetrocausalQueue` has separate observation rules: a consumer can observe concurrent inserts in the same block. The proposer records these observations for validator replay.

<a id="merged-deltas"></a>

## Merged Deltas

A delta describes how one transaction changes a storage location. It is not necessarily an arithmetic difference. The storage type gives the delta its meaning and defines whether it can coexist with other changes to the same location.

For a `Balance`, the delta is an increase or decrease. When you write:

```rust
self.balance.lazy_increase(5);
```

This says “add 5 to the balance.” It does not say “set the balance to 105.”

Suppose two transactions read a balance of 100:

```text
Tx A: lazy_decrease(20)
Tx B: lazy_decrease(30)
Both land: 100 - 20 - 30 = 50
```

Both changes can land because addition gives the same result in either order and the combined debit fits within the balance. We say the operations **commute**, and the runtime can merge their deltas. If the transactions instead try to debit 80 and 30, the combined debit exceeds the snapshot balance, so whichever transaction reserves second is excluded.

Merge rules depend on the storage type:

- `Balance` merges increases and decreases. All decreases admitted in a block must fit within the snapshot value; credits from other transactions in the same block do not fund a decrease.
- `NNInt` exposes lower-level signed changes and explicit bases.
- Changes to different `Map` keys are independent.
- Two `Value` writes to the same key can coexist only when they store the same value.

In these docs, **compatible deltas** means the storage type allows both changes to land. See [`Balance`](storage-types.md#balance) for the ordinary balance API and [NNInt and concurrent updates](nnint.md) for the underlying `set_add` rules.

<a id="block-lifecycle"></a>

## Block Lifecycle

1. **Read and execute:** your contract reads the block snapshot plus its own changes and successful child calls. It records typed deltas.
2. **Reserve:** after the root call succeeds, the runtime checks whether the complete delta batch can coexist with the proposal’s other changes.
3. **Commit or exclude:** admissible transactions contribute to the finalized block. Conflicting transactions are excluded from that proposal.

Your contract does not control these phases. [Transaction Lifecycle](../architecture/transaction-lifecycle.md) covers submission through finalization; [Parallel Execution](../architecture/execution-model.md) explains the reservation machinery.

<a id="exclusion"></a>

## Exclusion

From your contract’s perspective, a conflicting attempt doesn’t land in that proposal. Your code runs, produces deltas, and the system determines whether that completed delta batch is compatible with the proposal’s other changes. Exclusion does not commit the transaction or consume its replay nonce. It does not establish whether the same transaction committed in another proposal. See [How Conflicts Are Resolved](../architecture/execution-model.md#how-conflicts-are-resolved) for the engine-level details.

The scheduler can requeue transactions when a nomination is rolled back or a different proposal commits. When its own proposal commits, it removes the attempted transactions, including excluded ones, and records retryable execution failures as `retry`. See [Exclusion, requeue, and resubmission](../architecture/transaction-lifecycle.md#exclusion-requeue-and-resubmission) for the full lifecycle.

A committed abort, revert, or out-of-gas fault discards the contract changes but records the replay nonce and RCQ observations. Once the receipt confirms that committed failure, fix the cause before signing a new transaction.

Clients keep the signed bytes, submitted hash, and original network, then observe the outcome. Receipt polling does not resubmit. When retrying is appropriate, reuse the same signed transaction while it remains valid. A timeout, expiration, or missing result does not prove that an earlier attempt never committed. See [Resubmission and replacement](../typescript/transaction-status.md#resubmission-and-replacement).

When a recent attempt hit a storage conflict, [`getTransactionStatus`](../reference/json-rpc-api.md#gettransactionstatus) can include `recentFailure` with `cause.kind` set to `dbConflict` and a `conflict` object naming the contract address, storage key, and conflict code. Use it to find hot keys. It is an advisory diagnostic, not permission to resubmit or sign a replacement.

To handle a conflict inside a child call, use [`with_commit_locking()`](cross-contract-calls.md#gas-limits). The child takes its commit locks before it returns, so a `try_` call sees the conflict as a failure.

<a id="gas"></a>

## Gas

Transactions and cross-contract calls specify a gas limit. Gas bounds computation, including work in child calls, but costs zero tokens.

For root transactions, the gas limit is the scheduling quantity. The scheduler accounts for the amount you declare whether execution uses all of it or only part of it. If execution exceeds the limit, the transaction faults. The fault is committed with its contract changes discarded.

Each chain caps the root gas limit at `max_tx_gas`. A transaction above the cap is rejected, not clamped. Wire `14.1.0` servers expose the cap as `stated.maxTxGas` in [`getChainConfig`](../reference/json-rpc-api.md#getchainconfig) and report the rejection as `gasLimitTooHigh`.

A child call without `with_gas_limit` can use all of the caller’s remaining gas. Unused child-call gas returns to the caller’s execution budget. That is not a token refund and does not change the root transaction’s scheduling amount.

```rust
let client = TokenClient::new(&token_address);
client.with_gas_limit(100_000).transfer(&to, amount);
```

Gas has no token fee, but lower gas limits use less scheduling capacity. Choose a limit that covers execution and design storage operations to avoid unnecessary conflicts.

Project Thruput needs no gas price estimation because the token price of gas is zero. Gas usage still matters when choosing an execution limit.

<a id="throughput"></a>

## Throughput

Your unlocked native-token balance provides scheduling capacity. A transaction’s gas limit must fit within the capacity the sending account’s tokens provide; the scheduler drops a transaction whose limit exceeds it. Compatible storage changes do not guarantee inclusion in the next block: admission, capacity, propagation, and expiry still matter. See [Balance-Proportional Scheduling](../architecture/storage-economics.md#balance-proportional-scheduling) for the allocation rules.

<a id="storage-costs"></a>

## Storage Costs

The address that owns stored data funds its deposit. The runtime accounts for storage changes; your contract does not calculate the deposit itself. Delete data you no longer need with `delete()` or `Map::delete_at` to release its deposit. See [Storage: Refundable Deposits](../architecture/storage-economics.md#storage-refundable-deposits) for funding and cost rules.

Next, [Storage Types](storage-types.md) turns this model into concrete API choices.
