<a id="_top"></a>

# Generate client bindings

Source: <https://www.thruput.network/docs/contracts/client-bindings/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Deliver a contract's typed interface to TypeScript application developers.

Client bindings let an application use your contract’s methods, types, errors, and events. Generate them from the contract spec produced by the same build you deploy:

```bash
thruput build --bindings ts
```

The spec describes the exported interface. Bindings turn that description into TypeScript code for application developers.

<a id="keep-the-interface-and-deployment-together"></a>

## Keep the interface and deployment together

- Regenerate bindings when methods, argument or return types, errors, or events change.
- Give application developers the bindings and the matching deployment address and network.
- Keep generated files separate from application code so regeneration does not overwrite manual changes.

See [Generate TypeScript bindings](../cli/codegen.md) for output paths and generation from an existing spec, and [Use contract bindings](../typescript/bindings.md) for consuming the generated interface in an application.
