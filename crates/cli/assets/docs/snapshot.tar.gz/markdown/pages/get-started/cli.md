<a id="_top"></a>

# CLI quickstart

Source: <https://docs.groundhog.dev/get-started/cli/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Create a Devnet wallet, request test HOG, and inspect your first transaction from the terminal.

Create a wallet on Devnet, fund it with test HOG, and inspect the funding transaction. You do not need a contract project or a local node.

**Before you start:** [install the latest CLI](../cli/install.md). Run these commands outside an existing Groundhog project so they use your global configuration.

<a id="1-set-up-the-cli"></a>

## 1. Set up the CLI

```bash
groundhog init
```

On a fresh installation, accept signing-key creation and decline starter-project creation. Setup creates the `default` key and the built-in network profiles.

<a id="2-create-a-wallet"></a>

## 2. Create a wallet

```bash
groundhog wallet create --profile devnet
```

Confirm the prompt. The CLI saves a wallet address for your selected key. Creating this wallet does not fund it or send a transaction.

```bash
groundhog wallet ls --profile devnet
```

You should see your wallet’s name and address. With a fresh setup, its name is `default`.

<a id="3-request-test-funds"></a>

## 3. Request test funds

```bash
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Confirm the airdrop and wait for its result. You should have a positive HOG balance. Save the transaction hash printed by the airdrop command.

Devnet HOG is for testing. The faucet selects the amount; you do not need an amount flag.

<a id="4-inspect-the-transaction"></a>

## 4. Inspect the transaction

Replace `TX_HASH` with the hash from the airdrop:

```bash
groundhog tx show TX_HASH --profile devnet
```

Check that the transaction committed successfully. You now have a funded wallet and have verified an onchain result.

<a id="next"></a>

## Next

[Deploy your first contract](contract.md) using this wallet.

If funding is pending, rerun the same airdrop command to resume the request. For network errors or faucet limits, see [Faucet](../tools/faucet.md).

<a id="use-a-coding-agent"></a>

## Use a coding agent

Copy this prompt into your agent:

```text
Help me complete the Groundhog CLI quickstart:
https://docs.groundhog.dev/get-started/cli/
Use the latest CLI and read groundhog skill show cli. Set up a Devnet
wallet without creating a contract project or running a local node.
Preserve any existing keys and configuration. Request test funds,
check the wallet balance, and inspect the airdrop transaction.
Report success only after checking the committed transaction result.
Ask me to supply any required registry access through my environment,
not in this conversation. Report a network failure rather than bypassing it.
```
