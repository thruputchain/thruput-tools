<a id="_top"></a>

# Contract quickstart

Source: <https://www.thruput.network/docs/get-started/contract/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Create, test, and deploy a Rust counter contract to Project Thruput Futurenet.

Deploy a counter to Futurenet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](cli.md) so you have the latest CLI and a funded Futurenet wallet.

<a id="1-create-a-contract"></a>

## 1. Create a contract

```bash
thruput new my-counter --template counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`. The counter uses [Balance](../contracts/storage-types.md#balance) for nonnegative counts.

<a id="2-build-and-test"></a>

## 2. Build and test

```bash
thruput build
thruput test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.

The generated project follows your global Futurenet selection. Check it with `thruput config get` before deploying.

<a id="3-deploy-to-futurenet"></a>

## 3. Deploy to Futurenet

```bash
thruput deploy --estimate
```

Read the reported minimum funding in whole native tokens. Add **10 native test tokens** as this walkthrough’s storage allowance, then replace `TOTAL_FUNDING` below with that decimal total. The allowance is an example budget, not an estimate of initializer writes or a universal requirement. These tokens have no monetary value. See [deployment estimates](../cli/deploy-and-call.md#estimate-deployment-funding) for the breakdown.

```bash
thruput deploy --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
```

Confirm the deployment. Funding, deployment, and initialization happen atomically. The CLI prints the contract address and saves the alias `my-counter` in the project’s Futurenet profile. The sender also needs its own storage and scheduling capacity.

<a id="4-change-the-counter"></a>

## 4. Change the counter

Increase the counter initialized during deployment:

```bash
thruput call my-counter increment 5
```

Confirm the call and wait for success. Do not initialize again: this example method adds the initial amount rather than enforcing one-time initialization.

<a id="5-read-the-result"></a>

## 5. Read the result

```bash
thruput view my-counter get
```

The result should be **15**. You have built, tested, deployed, and called a contract on Futurenet.

<a id="next"></a>

## Next

[Build a Counter](../tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](../contracts/project-structure.md).

<a id="use-a-coding-agent"></a>

## Use a coding agent

```text
Help me complete the Project Thruput contract quickstart:
https://www.thruput.network/docs/get-started/contract/
Use the latest CLI. Check CLI setup first: select Futurenet with
thruput config use futurenet if it is not already selected, and confirm
the wallet is funded. Scaffold my-counter with --template counter, then
install the thruput skill in that project and read thruput skill show
contracts. Preserve the generated dependency and compiler settings, then
build and test it.
Read the deployment estimate and add the documented storage allowance to its
minimum. Deploy with that explicit total and initialize atomically to 10,
increment by 5, and verify that the view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```
