<a id="_top"></a>

# Contract quickstart

Source: <https://docs.groundhog.dev/get-started/contract/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Create, test, and deploy a Rust counter contract to Groundhog Devnet.

Deploy a counter to Devnet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](cli.md) so you have the latest CLI and a funded Devnet wallet. Keep your [Cargo registry access](../cli/install.md#configure-cargo-access) available in this terminal.

<a id="1-create-a-contract"></a>

## 1. Create a contract

```bash
groundhog new my-counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`.

<a id="2-build-and-test"></a>

## 2. Build and test

```bash
groundhog build
groundhog test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.

<a id="3-deploy-to-devnet"></a>

## 3. Deploy to Devnet

```bash
groundhog deploy --profile devnet --fund 10
```

Confirm the deployment. The CLI prints the contract address and saves the alias `my-counter` in the project’s Devnet profile.

`--fund 10` transfers 10 test HOG to the contract for this example’s storage. It is a funding amount, not a fixed deployment fee.

<a id="4-change-the-counter"></a>

## 4. Change the counter

Initialize this new counter, then increase it:

```bash
groundhog call my-counter initialize 10 --profile devnet
groundhog call my-counter increment 5 --profile devnet
```

Confirm each call and wait for success. Run `initialize` only once for this walkthrough; this example method adds the initial amount rather than enforcing one-time initialization.

<a id="5-read-the-result"></a>

## 5. Read the result

```bash
groundhog view my-counter get --profile devnet
```

The result should be **15**. You have built, tested, deployed, and called a contract on Devnet.

<a id="next"></a>

## Next

[Build a Counter](../tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](../contracts/project-structure.md).

<a id="use-a-coding-agent"></a>

## Use a coding agent

```text
Help me complete the Groundhog contract quickstart:
https://docs.groundhog.dev/get-started/contract/
Use the latest CLI and read groundhog skill show contracts. Check CLI setup and
Devnet funding first. Scaffold my-counter, preserve its generated
dependency and compiler settings, then build and test it.
Deploy to Devnet with the documented contract funding, initialize
the new counter to 10, increment by 5, and verify that its view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```
