<a id="_top"></a>

# TypeScript quickstart

Source: <https://thruput.network/get-started/typescript/>

Documentation source: `c395bff83c52fc8618aa373273398cdd2c9d6535`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Connect to Devnet and read the native-token contract with a typed TypeScript client.

Read the native token’s total supply from Devnet with a typed contract call. This experimental token has no monetary value. This path needs Node.js and package access, but no CLI, signing key, or contract deployment.

<a id="1-create-a-project"></a>

## 1. Create a project

```bash
mkdir my-thruput-app
cd my-thruput-app
npm init -y
npm pkg set type=module
mkdir -p src
```

Configure [npm package access](../typescript/setup.md#give-npm-package-access) in this directory, then install the latest SDK and a TypeScript runner:

```bash
npm install @groundhogchain/client @groundhogchain/protocol
npm install --save-dev typescript tsx @types/node
```

<a id="2-read-a-contract"></a>

## 2. Read a contract

Create `src/index.ts`:

```ts
import { createGroundhogClient, devnet, formatUnits, getContract } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";

async function main() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
  const supply = await hog.totalSupply.view({ args: undefined });

  console.log("Native-token supply:", formatUnits(supply.value, 7));
  console.log("Read at block:", supply.height.toString());
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
```

`devnet()` selects the hosted network. The SDK includes the native-token contract’s standard binding, and `HOG_ADDRESS` is its protocol constant, so you do not need to generate a binding. `supply.value` is a typed integer; formatting it displays whole-token units rather than base units.

<a id="3-run-it"></a>

## 3. Run it

```bash
npx tsx src/index.ts
```

You should see **Native-token supply** and **Read at block**, each followed by a value. Run the command again to make another read. The values come from Devnet and can change; there is no fixed expected block number.

This is a read-only call. It does not request wallet permission or submit a transaction.

<a id="next"></a>

## Next

Use [Read contract data](../typescript/reads.md) for arguments, caller context, and cancellation, or [Connect a wallet](../tools/wallet-integration.md) to add signing and transaction submission.

<a id="use-a-coding-agent"></a>

## Use a coding agent

```text
Build the Stellar Thruput TypeScript quickstart:
https://thruput.network/docs/get-started/typescript/
Use the latest published SDK packages and the hosted Devnet.
Configure package access through my environment. Create the typed native-token
total-supply read shown in the guide and run it. Show the actual supply
and block height, or report the exact error if the request fails.
Do not install the Rust toolchain, deploy a contract, or create a wallet
for this read-only example. Keep the generated package lockfile.
```
