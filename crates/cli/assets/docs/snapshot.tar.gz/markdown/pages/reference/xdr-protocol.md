<a id="_top"></a>

# XDR Protocol

Source: <https://thruput.network/docs/reference/xdr-protocol/>

Documentation source: `53198a762a9adc3260457997acb6ad86b75d9932`. Hosted docs may be newer than this snapshot.

Encoding boundaries and source definitions for the Project Thruput protocol.

<a id="encodings"></a>

## Encodings

| Surface                                                                      | Encoding                                                                                    | Reference                                                                                 |
| ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `Transaction`, `SignedTransaction`, contract spec sidecars                   | Classic XDR                                                                                 | Protocol definitions below                                                                |
| Contract arguments, return values, exceptions, typed storage, event payloads | CXS, the compact encoding used by the SDK                                                   | [Contract Spec](contract-spec.md), [TypeScript Bindings](../tools/typescript-bindings.md) |
| Transaction signing preimage                                                 | CXS domain separator, raw network hash, then classic XDR transaction                        | [Authorization](../how-it-works/authorization.md)                                         |
| Public JSON-RPC requests and responses                                       | JSON, with base58 identifiers, `0x` hex byte fields, and decimal strings for large integers | [JSON-RPC API](json-rpc-api.md)                                                           |

The Rust traits retain the names `ReadXDR` and `WriteXDR` for both encodings. Use generated SDK clients and TypeScript bindings for contract payloads; a classic XDR encoder produces different bytes.

<a id="source-definitions"></a>

## Source Definitions

| Source baseline            | Value                  |
| -------------------------- | ---------------------- |
| Rust protocol package      | `thruput-xdr` `0.61.0` |
| Embedded protocol revision | `hogp/6705996afff00a0` |

| Definition                                                                                                                        | Types                                                                |
| --------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| [transaction.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/transaction.x)     | `Invocation`, `Transaction`, `SignedTransaction`, invocation outputs |
| [types.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/types.x)                 | Addresses, hashes, signatures, protocol scalar types                 |
| [storage_item.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/storage_item.x)   | Storage items and deltas                                             |
| [header.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/header.x)               | Proposal header                                                      |
| [consensus.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/consensus.x)         | Consensus values                                                     |
| [contract_spec.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/contract_spec.x) | Contract types, methods, events, and interface metadata              |
