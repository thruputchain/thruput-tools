<a id="_top"></a>

# Whitepapers

Source: <https://thruput.network/whitepapers/>

Documentation source: `fd91c2019cd8f984aeda15c0303042679e1c8825`. Hosted docs may be newer than this snapshot.

Read the whitepapers on Project Thruput’s system design and trust-minimized bridging between FBA blockchains.

Project Thruput / Research

## Whitepapers

The ideas behind Project Thruput, from the system design to research on connecting blockchains.

<a id="thruput"></a>

01 / System design

<a id="thruput-title"></a>

## Project Thruput

The main whitepaper introduces the case for abundant blockchain compute. It explores unordered transactions within blocks, concurrent updates to shared state, and the system architecture and capacity model behind Project Thruput.

Start here for the project’s motivation and design.

[Read PDF ](../assets/whitepapers/thruput.pdf)[Download PDF](../assets/whitepapers/thruput.pdf)

<a id="fba-bridging"></a>

02 / Consensus research

<a id="fba-bridging-title"></a>

## Trust-minimized bridging between FBA blockchains

This research paper explores how Federated Byzantine Agreement (FBA) can extend across blockchains. It presents a way for one chain to agree on another’s state, enabling asset transfers without giving an external third party custody of the escrowed assets.

For readers interested in consensus protocols, trust assumptions, and cross-chain interoperability.

[Read PDF ](../assets/whitepapers/fba-bridging.pdf)[Download PDF](../assets/whitepapers/fba-bridging.pdf)

[Understand Project Thruput](architecture.md)

[![Stellar](../assets/brand/stellar.svg) ![Stellar](../assets/brand/stellar-dark.svg) ](https://stellar.org)[Project Thruput](index.md)

A blockchain for abundant compute

Technology preview · alpha-pre.1
