<a id="_top"></a>

# Deploy and call

Source: <https://thruput.network/cli/deploy-and-call/>

Documentation source: `c395bff83c52fc8618aa373273398cdd2c9d6535`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Deploy an artifact, fund its storage, call methods, and read committed state.

Run these commands in a contract project with a built artifact. Deployment and calls need a funded account; estimating needs no signing key. Select the intended [profile](configuration.md) explicitly. The examples use Devnet and the scaffolded counter’s methods.

<a id="estimate-deployment-funding"></a>

## Estimate deployment funding

```bash
thruput build
thruput deploy --estimate --profile devnet
thruput deploy --estimate --profile devnet --json
```

The estimate reads the network’s authoritative execution rules and storage prices without signing or submitting. It checks the artifact, code, and memory limits and assumes a fresh, unfunded contract address. Unlike `--dry-run`, it does not prepare a signed transaction.

| Report field                             | Meaning                                                                                                                             |
| ---------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `balanceDepositRaw`, `deploymentCostRaw` | First balance-item deposit and code collateral, in native-token base units                                                          |
| `minimumFundingRaw`, `minimumFundingHog` | Their sum, as an integer base-unit string and a whole-token decimal string respectively; one native token has 10,000,000 base units |
| `initializerFundingRaw`                  | `null` when an initializer is requested, because its storage is not estimated; `"0"` when none is requested                         |
| `execution`                              | Observed committed tip, configuration hash, effective limits, and storage prices                                                    |

Missing authoritative rules or prices produce an error, not a zero-cost estimate. The reading applies at its reported configuration; prices can change before inclusion. Re-estimate after rebuilding or changing networks.

For deployment without initialization, the CLI can read and transfer the minimum directly:

```bash
thruput deploy --profile devnet --fund minimum
```

The minimum leaves **zero free contract balance** for further storage. It excludes initializer writes, later storage growth, the sender’s replay storage, and the sender’s scheduling capacity. `--fund minimum` cannot be combined with `--init`. Use an explicit total amount when initialization or later calls need storage, as in the [counter guide](../tutorials/build-a-counter.md#build-deploy-and-initialize).

<a id="deploy-an-artifact"></a>

## Deploy an artifact

```bash
thruput build
thruput deploy --profile devnet --fund 10
```

Confirm the deployment. The CLI waits for its result, prints the deployed address, and saves an alias using the package name. For a project named `my-counter`, later commands can use that alias instead of the address.

Numeric `--fund` transfers exactly that many native tokens from the sender to the new contract. Set it to the estimated minimum plus an allowance for contract storage. `10` above illustrates the syntax; choose your total from the current estimate rather than treating it as a fixed fee or minimum.

At a workspace root, use `-p PACKAGE`. Use `--artifact PATH` to select an artifact directly and `--alias NAME` when you want a specific alias.

<a id="include-initialization"></a>

## Include initialization

For a new deployment that initializes the counter in the same transaction, use this instead:

```bash
thruput deploy --profile devnet --fund 10 \
  --init initialize --init-arg 10
```

Repeat `--init-arg` for additional arguments. The initializer sees the deploying wallet as its caller. Funding, deployment, and initialization succeed together or roll back together.

Initialization is an ordinary contract method. The contract must enforce one-time initialization when its design requires it. The starter counter simply adds the supplied amount, so do not call it again after initializing this example.

<a id="submit-a-call"></a>

## Submit a call

For a counter that has been deployed and initialized:

```bash
thruput call my-counter increment 5 --profile devnet
```

This signs and submits a transaction. Method names and typed arguments use the contract spec. Without metadata, an explicit entrypoint and raw calldata are required; use generated metadata for normal development.

Use `--gas-limit` when the call needs a different execution budget. The sender must have the corresponding scheduling capacity; gas itself has no token fee.

<a id="read-without-submitting"></a>

## Read without submitting

```bash
thruput view my-counter get --profile devnet
```

`view` runs a sandboxed call against committed state. It does not submit a transaction. Use `--from ADDRESS` when a read needs a simulated caller; this does not prove control of that address.

`thruput storage CONTRACT KEY` reads a raw storage item. Prefer a view when you want the contract’s typed behavior.

<a id="prepare-without-broadcasting"></a>

## Prepare without broadcasting

```bash
thruput deploy --profile devnet --fund 10 --dry-run
thruput call my-counter increment 5 --profile devnet --dry-run
```

A dry run prepares and signs a transaction but does not submit it. It still needs the selected key and network access. It is not a simulation of the state change and does not prove that execution will succeed.

<a id="inspect-an-uncertain-result"></a>

## Inspect an uncertain result

Keep the transaction hash and original network if submission or receipt observation fails:

```bash
thruput tx show TX_HASH --profile devnet
```

A timeout or `unknown` status does not prove that the transaction failed. Repeating a deployment creates a new nonce and predicted address. Inspect the original transaction before deciding to submit a new operation. See [Inspect transactions and events](transactions.md).
