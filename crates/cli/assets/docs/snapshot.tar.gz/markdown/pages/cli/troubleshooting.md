<a id="_top"></a>

# Troubleshooting

Source: <https://thruput.network/cli/troubleshooting/>

Documentation source: `44bc1f66f613eb3dcda6693605fcd1b6d4a41d48`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Diagnose configuration, build, runtime, funding, and transaction-observation problems.

Start with the command’s error and the selected environment:

```bash
thruput --version
thruput status --profile futurenet
thruput config get futurenet --sources
```

For local work, use `--profile local`. `status` can exit nonzero when it finds warnings; inspect the findings rather than assuming the report itself failed.

<a id="cargo-cannot-access-packages"></a>

## Cargo cannot access packages

Complete [Cargo access setup](install.md#configure-cargo-access) in the terminal running the build. A registry token alone is not enough if Cargo has no credential provider configured. Repository access does not imply registry access.

<a id="the-wrong-profile-or-account-is-selected"></a>

## The wrong profile or account is selected

An explicit `--profile` wins over `THRUPUT_PROFILE`, which wins over project and global defaults. A profile-specific key or selected wallet can also override the global key. Inspect both configuration and `wallet ls --profile NAME` before changing them.

Use [Profiles and networks](configuration.md) and [Keys and wallets](wallets.md) to change the intended layer. Preserve existing keys rather than generating replacements to hide a selection error.

<a id="the-local-runtime-is-missing-or-incompatible"></a>

## The local runtime is missing or incompatible

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

Check for an intentional `THRUPUT_DEVNODE_BINARY` override or an adjacent binary. The installed CLI’s catalog chooses a compatible managed runtime. A protocol-token override does not fix a wire-format mismatch. See [runtime selection](local-node.md#runtime-selection).

On Linux, a missing shared-library error identifies the system dependency to install. See [CLI installation](install.md) for runtime-library guidance.

<a id="the-node-restarted-and-the-deployment-disappeared"></a>

## The node restarted and the deployment disappeared

An ephemeral local node loses chain state on shutdown. Restarting it does not restore the old wallets, balances, or deployments, even when local configuration still has their aliases. Redeploy on the new chain, or use a persistent [data directory](local-node.md#preserve-state).

<a id="deployment-needs-funding"></a>

## Deployment needs funding

Native deployment requires an explicit `--fund` amount. The sender needs funds for the transfer and scheduling capacity; the deployed contract needs funds for its own storage. Inspect the sender with `thruput balance --profile NAME`, then request appropriate test funding or reduce the operation. See [Deploy and call](deploy-and-call.md).

<a id="submission-timed-out-or-status-is-unknown"></a>

## Submission timed out or status is unknown

Keep the transaction hash and original network. Run `thruput tx show TX_HASH --profile NAME` to inspect it. A timeout is not proof of failure. Do not automatically repeat a deployment or sign a replacement call.

<a id="a-view-or-call-cannot-resolve-a-method"></a>

## A view or call cannot resolve a method

Use the correct contract alias and the spec from the matching build. Rebuild after interface changes. At a Cargo workspace root, select the package with `-p`. Explicit entrypoint calls require the matching encoded calldata; changing only the entrypoint does not adapt an incompatible interface.

<a id="the-integration-target-is-missing"></a>

## The integration target is missing

Current CLI projects include `tests/integration.rs` and its activation wiring. Compare an older project with a fresh scaffold before adding them; do not replace its dependency configuration blindly. See [Test contracts](../programming-model/testing.md#what-the-scaffold-gives-you).
