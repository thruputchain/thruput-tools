<a id="_top"></a>

# Generate TypeScript bindings

Source: <https://www.thruput.network/docs/cli/codegen/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Generate typed application bindings from a built contract's canonical specification.

Generate bindings from the same contract build you deploy. Bindings provide method descriptors, argument types, result decoders, and declared event and error types.

Use the [current Thruput CLI](install.md) and the [public `@thruputchain` packages](../typescript/setup.md) together. The generator emits imports from those packages.

<a id="generate-during-a-build"></a>

## Generate during a build

```bash
thruput build --bindings ts
```

The build prints the generated binding path alongside the contract artifacts. Use `-p PACKAGE` when selecting a workspace member.

<a id="write-bindings-into-an-application"></a>

## Write bindings into an application

Build first, then select the binary spec sidecar:

```bash
thruput build
mkdir -p web/src/contracts
thruput codegen ts target/thruput/my_counter.spec.xdr \
  --output web/src/contracts/my-counter.ts
```

Replace `my_counter` with your artifact’s name and the output directory with your application’s location. `codegen ts` accepts `.spec.xdr`, not the readable `.spec.json` or the deployable `.rv32a` file.

<a id="keep-code-and-deployment-aligned"></a>

## Keep code and deployment aligned

Regenerate bindings when the contract interface changes. Use the address from the matching deployment rather than an address copied from another example.

Do not edit generated files. Put application wrappers next to them so regeneration does not overwrite application logic.

Continue with [Use contract bindings](../typescript/bindings.md) for descriptors and typed calls, or [Read events](../typescript/events.md) for filters and decoding.
