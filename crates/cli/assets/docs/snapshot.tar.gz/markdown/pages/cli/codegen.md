<a id="_top"></a>

# Generate TypeScript bindings

Source: <https://docs.groundhog.dev/cli/codegen/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Generate typed application bindings from a built contract's canonical specification.

Generate bindings from the same contract build you deploy. Bindings provide method descriptors, argument types, result decoders, and declared event and error types.

<a id="generate-during-a-build"></a>

## Generate during a build

```bash
groundhog build --bindings ts
```

The build prints the generated binding path alongside the contract artifacts. Use `-p PACKAGE` when selecting a workspace member.

<a id="write-bindings-into-an-application"></a>

## Write bindings into an application

Build first, then select the binary spec sidecar:

```bash
groundhog build
mkdir -p web/src/contracts
groundhog codegen ts target/groundhog/my_counter.spec.xdr \
  --output web/src/contracts/my-counter.ts
```

Replace `my_counter` with your artifact’s name and the output directory with your application’s location. `codegen ts` accepts `.spec.xdr`, not the readable `.spec.json` or the deployable `.rv32a` file.

<a id="keep-code-and-deployment-aligned"></a>

## Keep code and deployment aligned

Regenerate bindings when the contract interface changes. Use the address from the matching deployment rather than an address copied from another example.

Keep generated files out of manual edits. Put application wrappers next to them so regeneration does not overwrite application logic.

Continue with [Use contract bindings](../tools/typescript-bindings.md) for descriptors and typed calls, or [Read events](../typescript/events.md) for filters and decoding.
