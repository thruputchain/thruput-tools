<a id="_top"></a>

# Create a project

Source: <https://docs.groundhog.dev/cli/create-project/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Create a contract project and keep its generated compiler, build, and test configuration together.

Use `groundhog new` to create a Rust contract project. If this is your first setup, [install the CLI](install.md) and run `groundhog init` first.

<a id="choose-a-template"></a>

## Choose a template

```bash
groundhog new my-counter
cd my-counter
```

The default `counter` template includes contract methods, an event, an error, and tests. To start with less example logic, use the `stub` template instead:

```bash
groundhog new my-contract --template stub
```

Both templates include the files needed for native tests, RV32 builds, and integration tests. Keep the generated `Cargo.toml`, `rust-toolchain.toml`, and `.cargo/` configuration together. You do not need to select SDK or compiler versions yourself.

<a id="find-the-code"></a>

## Find the code

- `src/implementation.rs`: contract logic and storage.
- `tests/test.rs`: native logic tests.
- `tests/test_rv32.rs`: artifact tests.
- `tests/integration.rs`: RPC integration test entry point.
- `groundhog.toml`: project profiles and deployment aliases.

See [Project structure](../contracts/project-structure.md) for the complete layout and generated artifacts.

<a id="select-a-network"></a>

## Select a network

The scaffold selects the local profile by default. Use an explicit profile when deploying to Devnet:

```bash
groundhog config get devnet --sources
```

Builds and native/artifact tests run on your machine regardless of the profile. Deployments and calls use its network settings. See [Profiles and networks](configuration.md).

<a id="work-in-a-cargo-workspace"></a>

## Work in a Cargo workspace

Keep shared `groundhog.toml`, `.cargo/`, and `rust-toolchain.toml` files at the workspace root. Select a package when building from that root:

```bash
groundhog build -p my-counter
groundhog test -p my-counter
```
