<a id="_top"></a>

# Create a project

Source: <https://www.thruput.network/docs/cli/create-project/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Create a contract project and keep its generated compiler, build, and test configuration together.

Use `thruput new` to create a Rust contract project. If this is your first setup, [install the CLI](install.md) and run `thruput init` first.

<a id="choose-a-template"></a>

## Choose a template

```bash
thruput new my-counter --template counter
cd my-counter
```

The explicit `counter` template includes counter methods, an event, an error, and tests. Without `--template`, the CLI creates a minimal contract:

```bash
thruput new my-contract
```

The minimal project and named templates include the files needed for native tests, RV32 builds, and integration tests. Keep the generated `Cargo.toml`, `rust-toolchain.toml`, and `.cargo/` configuration together. You do not need to select SDK or compiler versions yourself.

Discover named templates and their prerequisites without network access:

```bash
thruput templates list
thruput templates show counter-app
```

`counter-app` adds a local React application, generated bindings, and a temporary browser wallet. It separates contract deployment (`npm run contract:deploy`) from frontend startup (`npm run dev`). Use [Build a counter](../tutorials/build-a-counter.md) to build the application step by step instead.

Run `thruput new` without a name for interactive setup, or pass `--path PATH` to select a destination. The destination must be new or empty.

<a id="find-the-code"></a>

## Find the code

- `src/implementation.rs`: contract logic and storage.
- `tests/test.rs`: native logic tests.
- `tests/test_rv32.rs`: artifact tests.
- `tests/integration.rs`: RPC integration test entry point.
- `thruput.toml`: project profiles and deployment aliases.

See [Project structure](../contracts/project-structure.md) for the complete layout and generated artifacts.

<a id="select-a-network"></a>

## Select a network

New projects omit `default_profile` and follow your global selection. After `thruput config use futurenet --global`, new projects use Futurenet. Inspect the selected profile before deploying:

```bash
thruput config get --sources
```

Use `thruput config use futurenet --project` to set a project override, or `--profile futurenet` for one command. Builds and native/artifact tests run on your machine regardless of the profile. See [Profiles and networks](configuration.md).

<a id="work-in-a-cargo-workspace"></a>

## Work in a Cargo workspace

Keep shared `thruput.toml`, `.cargo/`, and `rust-toolchain.toml` files at the workspace root. Select a package when building from that root:

```bash
thruput build -p my-counter
thruput test -p my-counter
```

Each project pins its own toolchain in `rust-toolchain.toml`: a nightly with the RV32 target and `rust-src`. Run `thruput status` in the project; it reports a missing toolchain or component and prints the `rustup` command that installs it.
