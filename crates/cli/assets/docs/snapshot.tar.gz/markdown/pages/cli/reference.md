<a id="_top"></a>

# Command reference

Source: <https://thruput.network/cli/reference/>

Documentation source: `d89a8eac8de7a71bf60ed8ff38614a3cfc51ca12`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Thruput CLI commands, common options, and links to task instructions.

<a id="which-command-should-i-use"></a><a id="common-workflow"></a><a id="foundry-mental-model"></a>

<a id="first-run-setup"></a>

## First-Run Setup

| Command                                                              | Purpose                                                                       | Usage                                                    |
| -------------------------------------------------------------------- | ----------------------------------------------------------------------------- | -------------------------------------------------------- |
| `thruput --version`                                                  | Print the installed release                                                   | [Install](install.md)                                    |
| `thruput init`                                                       | Initialize profiles and check setup; offer initial key creation interactively | [CLI quickstart](../get-started/cli.md)                  |
| `thruput init --non-interactive --generate-key`                      | Explicitly authorize initial key creation without prompts                     | [Automation](automation.md)                              |
| `thruput status [--profile NAME]`                                    | Inspect project, key, compiler, and runtime readiness                         | [Troubleshooting](troubleshooting.md)                    |
| `thruput new [NAME] [--path PATH] [--template counter\|counter-app]` | Create a minimal contract by default; omit the name for interactive setup     | [Create a project](create-project.md)                    |
| `thruput templates list` / `thruput templates show NAME`             | Discover named templates and their prerequisites offline                      | [Choose a template](create-project.md#choose-a-template) |
| `thruput completion SHELL`                                           | Print shell completions                                                       | `thruput completion --help`                              |
| `thruput COMMAND --help`                                             | Print the installed command’s options                                         | Available on each command                                |

<a id="configuration"></a>

## Configuration

| Command                                 | Purpose                                             | Usage                                                               |
| --------------------------------------- | --------------------------------------------------- | ------------------------------------------------------------------- |
| `config profiles`                       | List persisted profiles                             | [Profiles and networks](configuration.md)                           |
| `config get [NAME] [--sources]`         | Inspect merged persisted settings and their origins | [Inspect settings](configuration.md#inspect-the-current-settings)   |
| `config new NAME --network NETWORK`     | Create a profile in one layer                       | [Add an endpoint](configuration.md#add-another-endpoint)            |
| `config set FIELD VALUE --profile NAME` | Set one typed field in an existing profile layer    | [Overrides](configuration.md#global-settings-and-project-overrides) |
| `config unset FIELD --profile NAME`     | Remove a field from one layer                       | [Overrides](configuration.md#global-settings-and-project-overrides) |
| `config use NAME`                       | Set the layer’s default profile                     | [Select a profile](configuration.md#choose-a-profile)               |
| `config rm NAME`                        | Remove a profile from one layer                     | Requires confirmation; `--force` for an intended automated removal  |
| `--global` / `--project`                | Choose the layer for a configuration mutation       | Required inside a project; mutually exclusive                       |

<a id="keys-and-wallets"></a>

## Keys and Wallets

| Command                                    | Purpose                                              | Usage                                                 |
| ------------------------------------------ | ---------------------------------------------------- | ----------------------------------------------------- |
| `keys generate [NAME]`                     | Generate a stored Ed25519 key                        | [Keys and wallets](wallets.md)                        |
| `keys import NAME`                         | Import key material through the supported input flow | `thruput keys import --help`                          |
| `keys ls` / `keys use NAME`                | List or select a global key                          | [Select an account](wallets.md#select-an-account)     |
| `keys export NAME`                         | Print private key material                           | Intended export only; exclude from logs               |
| `keys rm NAME`                             | Delete a local key                                   | Requires confirmation                                 |
| `wallet create [--key NAME] [--name NAME]` | Derive and save an empty native account binding      | [Create a wallet](wallets.md#create-a-key-and-wallet) |
| `wallet ls` / `wallet use NAME`            | List or select a profile wallet                      | [Select an account](wallets.md#select-an-account)     |
| `wallet rm NAME`                           | Remove a local binding                               | Does not remove onchain state                         |
| `balance [TARGET]`                         | Read the native-token balance                        | [Funding](wallets.md#fund-and-transfer)               |
| `airdrop [RECIPIENT]`                      | Request test funding                                 | [Faucet](../tools/faucet.md)                          |
| `transfer RECIPIENT AMOUNT`                | Transfer native tokens from the selected account     | [Funding and transfers](wallets.md#fund-and-transfer) |

<a id="build-and-test"></a>

## Build and Test

| Command or option                        | Purpose                                       | Usage                                                                             |
| ---------------------------------------- | --------------------------------------------- | --------------------------------------------------------------------------------- |
| `build [-p PACKAGE]`                     | Build a deployable RV32 artifact              | [Build and test](build-and-test.md)                                               |
| `build --bindings ts`                    | Also generate TypeScript bindings             | [Code generation](codegen.md)                                                     |
| `build --stack-size SIZE`                | Set guest stack size within configured memory | `thruput build --help`                                                            |
| `test [-p PACKAGE]`                      | Build and run the RV32 artifact test target   | [Test modes](build-and-test.md#choose-a-test-boundary)                            |
| `test --integration`                     | Run an isolated local-node integration target | [Integration tests](../programming-model/testing.md#integration-test-environment) |
| `test --workspace`                       | Run eligible workspace members                | [Workspace runs](build-and-test.md#integration-and-workspace-runs)                |
| `test --match-test TEXT` / `--skip TEXT` | Filter test names                             | [Focused runs](build-and-test.md#focus-a-test-run)                                |
| `test --rerun` / `--watch`               | Repeat failures or watch files                | Not supported with `--integration`                                                |
| `test --show-output` / `--no-capture`    | Control test output                           | [Focused runs](build-and-test.md#focus-a-test-run)                                |

<a id="local-node"></a>

## Local Node

| Command or option                                         | Purpose                                 | Usage                                                                |
| --------------------------------------------------------- | --------------------------------------- | -------------------------------------------------------------------- |
| `node`                                                    | Start an ephemeral local node           | [Run a local node](local-node.md)                                    |
| `node --data-dir PATH`                                    | Preserve chain state                    | [Persistent state](local-node.md#preserve-state)                     |
| `node --port PORT` / `--host ADDRESS`                     | Configure the public listener           | [Endpoint and logging](local-node.md#change-the-endpoint-or-logging) |
| `node --verbose`                                          | Forward node diagnostics                | [Troubleshooting](troubleshooting.md)                                |
| `node --network-config NAME=VALUE`                        | Override a supported genesis parameter  | Repeatable; preserve settings when reopening a data directory        |
| `node --dev-account-count N` / `--dev-account-hog AMOUNT` | Configure local-user bootstrap accounts | Does not configure the faucet allocation                             |
| `toolchain list` / `install` / `which`                    | Inspect or acquire managed runtimes     | [Local runtime setup](install.md#set-up-the-local-runtime)           |
| `toolchain use VERSION` / `clean VERSION`                 | Select or remove a managed version      | `thruput toolchain --help`                                           |
| `chain dump --data-dir PATH --output FILE`                | Back up a stopped local chain           | [Persistent state](local-node.md#preserve-state)                     |
| `chain restore --data-dir PATH --input FILE`              | Restore a stopped local chain           | Requires confirmation before replacing populated state               |

<a id="deploy-and-interact"></a>

## Deploy and Interact

| Command or option                       | Purpose                                                                                                                      | Usage                                                              |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `deploy --fund AMOUNT`                  | Deploy and fund a contract with native tokens                                                                                | [Deploy and call](deploy-and-call.md)                              |
| `deploy --estimate [--json]`            | Read deployment collateral and configuration context without loading a signing key or submitting                             | [Estimate funding](deploy-and-call.md#estimate-deployment-funding) |
| `deploy --fund minimum`                 | Fund a fresh deployment’s balance-item deposit and code collateral; leaves no free balance and cannot include initialization | [Minimum funding](deploy-and-call.md#estimate-deployment-funding)  |
| `deploy --init METHOD --init-arg VALUE` | Initialize atomically with deployment                                                                                        | [Initialization](deploy-and-call.md#include-initialization)        |
| `deploy --artifact PATH --alias NAME`   | Select an artifact and saved alias                                                                                           | [Deployment](deploy-and-call.md#deploy-an-artifact)                |
| `call CONTRACT METHOD [ARGS...]`        | Submit a signed contract invocation                                                                                          | [Calls](deploy-and-call.md#submit-a-call)                          |
| `view CONTRACT METHOD [ARGS...]`        | Run a sandboxed read without submitting                                                                                      | [Views](deploy-and-call.md#read-without-submitting)                |
| `storage CONTRACT KEY`                  | Read a raw committed storage item                                                                                            | [Views and storage](deploy-and-call.md#read-without-submitting)    |
| `--dry-run`                             | Prepare deploy/call transactions without broadcast                                                                           | Still requires signing context and network access                  |
| `--force`                               | Confirm an intended write without a prompt                                                                                   | [Automation](automation.md#confirm-intended-writes)                |
| `--profile NAME` / `--rpc-url URL`      | Select configuration or override the endpoint                                                                                | [Profiles](configuration.md)                                       |

<a id="transactions-events-and-tokens"></a>

## Transactions, Events, and Tokens

| Command                         | Purpose                                         | Usage                                                           |
| ------------------------------- | ----------------------------------------------- | --------------------------------------------------------------- |
| `tx show HASH`                  | One public status and receipt lookup            | [Inspect transactions](transactions.md#look-up-one-transaction) |
| `tx list [TARGET]`              | One page of root-invocation history             | [History](transactions.md#list-history)                         |
| `events list CONTRACT`          | One page of raw or spec-decoded contract events | [Events](transactions.md#read-contract-events)                  |
| `token transfers TOKEN`         | One page of token transfer records              | [Token transfers](transactions.md#inspect-token-transfers)      |
| `--limit N` / `--cursor CURSOR` | Control a historical list page                  | [Pagination](transactions.md#continue-a-page)                   |

<a id="typescript-bindings"></a>

## TypeScript Bindings

| Command                   | Input/output                                                     | Usage                                                              |
| ------------------------- | ---------------------------------------------------------------- | ------------------------------------------------------------------ |
| `build --bindings ts`     | Contract build plus generated bindings                           | [Generate bindings](codegen.md)                                    |
| `codegen ts SPEC -o FILE` | Canonical `.spec.xdr` to TypeScript; stdout if output is omitted | [Write into an app](codegen.md#write-bindings-into-an-application) |

<a id="local-documentation"></a>

<a id="skills-and-local-documentation"></a>

## Skills and Local Documentation

| Command                                              | Purpose                                                                                                     | Usage                                                              |
| ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `thruput skill install [--global] [--agent NAME]`    | Install the maintained skill through `npx skills`; `--agent` is repeatable                                  | [Install the skill](agent-tools.md#install-the-maintained-skill)   |
| `thruput skill update [--global]`                    | Update only the `thruput` skill in the selected scope; requires an existing installation                    | [Update the skill](agent-tools.md#update-an-installed-skill)       |
| `skill install --yes` / `skill update --yes`         | Authorize npm execution and skill changes; unattended installation also needs `--agent`                     | [Automate setup](agent-tools.md#automate-skill-setup)              |
| `thruput skill show [TOPIC] [--global]`              | Read an installed skill file offline; current-directory installation before global unless `--global` is set | [Read guidance](agent-tools.md#read-installed-guidance-offline)    |
| `thruput skill list [--global]`                      | List reference names from the selected installed skill                                                      | [Read guidance](agent-tools.md#read-installed-guidance-offline)    |
| `thruput docs [--foreground] [--port PORT]`          | Serve the bundled site in the foreground; default port `4321`, `0` selects a free port                      | [Serve docs](agent-tools.md#serve-local-documentation)             |
| `thruput docs --dir PATH`                            | Serve a trusted local snapshot                                                                              | [Snapshot override](agent-tools.md#use-a-trusted-site-snapshot)    |
| `thruput docs --background [--port PORT]`            | Start or reuse a matching background server; conflicts with `--foreground`                                  | [Serve docs](agent-tools.md#serve-local-documentation)             |
| `thruput docs status`                                | Inspect the current user’s background server and log path                                                   | [Serve docs](agent-tools.md#serve-local-documentation)             |
| `thruput docs stop`                                  | Stop the managed background server while retaining extracted Markdown                                       | [Serve docs](agent-tools.md#serve-local-documentation)             |
| `thruput docs export --output PATH [--dir SNAPSHOT]` | Export portable Markdown into a new directory without serving                                               | [Export Markdown](agent-tools.md#export-markdown-without-a-server) |

<a id="shared-flags"></a>

## Shared Flags

| Global flag             | Effect                                                                                                  |
| ----------------------- | ------------------------------------------------------------------------------------------------------- |
| `--non-interactive`     | Disable prompts and terminal UI; does not grant confirmation                                            |
| `--json`                | Emit structured output                                                                                  |
| `--quiet`               | Suppress status messages                                                                                |
| `--show-cargo-commands` | Print Cargo invocations                                                                                 |
| `--offline`             | Disable managed runtime downloads and skill installation/updates; does not disable RPC or Cargo traffic |

<a id="json-output"></a>

### JSON output

| Output concern      | Rule                                                        | Usage                                                        |
| ------------------- | ----------------------------------------------------------- | ------------------------------------------------------------ |
| Success and failure | Check exit status and `ok`; command failures may use stderr | [Use the CLI in scripts](automation.md)                      |
| Payload shape       | Check command-specific `data.schemaVersion`                 | [Structured output](automation.md#request-structured-output) |
| Watch mode          | One JSON record per completed test run                      | [Structured output](automation.md#request-structured-output) |
