<a id="_top"></a>

# Run a local node

Source: <https://www.thruput.network/docs/cli/local-node/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Start an isolated development chain, select its accounts, and preserve or inspect local state.

Use a local node for disposable development and RPC tests. For a first hosted deployment, follow the [Futurenet contract quickstart](../get-started/contract.md).

<a id="start-the-node"></a>

## Start the node

```bash
thruput node
```

Keep this terminal running. The CLI starts its managed `hog-devnode` and exposes JSON-RPC at `http://127.0.0.1:9545` by default. If the selected runtime is missing, the CLI can download its verified bundle.

The CLI records the active endpoint and runtime manifest so commands using a local profile can find the node.

The node funds the selected project/global key. If local and Futurenet profiles use different keys, run `THRUPUT_PROFILE=local thruput node` so startup uses the key selected by local commands. `--key NAME` explicitly selects a stored key.

<a id="select-a-local-account"></a>

## Select a local account

From another terminal in your project:

```bash
thruput status --profile local
thruput balance --profile local
```

`status` shows the effective key. On a fresh chain, the node gives that key’s account 100 native tokens. `thruput balance` then shows slightly less, because the account’s first storage deposit comes out of that allocation. Use `thruput node --initial-account-tokens AMOUNT` to change the amount. The faucet key is private to the node, and the node creates no other accounts. An ML-DSA-65 key gets no genesis allocation. To fund it, or any other key, run `thruput airdrop NAME --profile local`.

If the profile already selects a saved wallet, key selection alone does not replace that wallet. Inspect `thruput status --profile local` and [wallet selection](wallets.md#select-an-account) before submitting.

You can now use the normal [deployment and call commands](deploy-and-call.md) with `--profile local`.

<a id="preserve-state"></a>

## Preserve state

Without a data directory, stopping the node discards its chain state. Stored signing keys and project configuration remain, but the local deployments and balances do not.

```bash
thruput node --data-dir .thruput/node
```

Restart with the same data directory to reuse the chain. Repeat the same `--network-config` overrides, and omit `--init-network-hash`. A runtime older than `0.1.31-rc.10` created data directories that the current runtime cannot open. Use a new directory for them.

Stop the node before backing up or restoring that directory:

```bash
thruput chain dump --data-dir .thruput/node --output chain-backup.json
thruput chain restore --data-dir .thruput/node --input chain-backup.json
```

Restore asks before replacing populated state. Use `--yes` only when that replacement is intended.

<a id="change-the-endpoint-or-logging"></a>

## Change the endpoint or logging

```bash
thruput node --port 9546
thruput node --verbose
```

Choose logging before reproducing a problem: restarting an ephemeral node to enable it loses the old state. `RUST_LOG` provides finer control and overrides the verbose preset.

The public listener binds to loopback by default. `--host` changes that listener for container or VM access; exposing it beyond loopback exposes an unauthenticated development RPC endpoint.

From thruput CLI 0.47.0, the listener allows CORS requests from any origin, so a browser app can call the node without a proxy. Any web page you open can then call it, including its funding and `dev_` methods. `--allow-origin ORIGIN` (repeatable) allows only the listed origins, and `--no-cors` turns CORS off. Both apply to HTTP only, not WebSocket connections.

<a id="control-blocks-and-time"></a>

## Control blocks and time

Contracts that depend on time, such as vesting, expiry, auctions, and interest, need days of chain time in a test that runs for seconds. A local node can produce blocks on request and move block time forward. These controls need thruput CLI 0.46.0 or later.

`--block-driver` selects how the node produces blocks:

| Mode                | Blocks                                                           |
| ------------------- | ---------------------------------------------------------------- |
| `instant` (default) | One block for each accepted transaction submission               |
| `interval`          | One block every `--block-interval-ms` milliseconds, empty or not |
| `manual`            | Only on request                                                  |

```bash
thruput node --block-driver manual
```

In every mode, these local-only JSON-RPC methods control blocks and block time. They follow Anvil’s mining and time methods:

| Method                      | Anvil                             | Effect                                                                                                  |
| --------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------- |
| `dev_produceBlock`          | `evm_mine`                        | Produce one block now. It can be empty. An optional `blockTimepoint` sets its time                      |
| `dev_produceBlocks`         | `anvil_mine`                      | Produce 1 to 1000 blocks, optionally `intervalNanoseconds` apart                                        |
| `dev_setNextBlockTimepoint` | `evm_setNextBlockTimestamp`       | Set the time of the next block                                                                          |
| `dev_increaseTime`          | `evm_increaseTime`                | Move the clock forward for every later block. Produces no block                                         |
| `dev_setBlockTimeStep`      | `anvil_setBlockTimestampInterval` | Step each later block from its parent’s time instead of the wall clock. A step of `0` freezes the clock |
| `dev_setBlockDriver`        | `evm_setAutomine`                 | Change the block driver mode. Switching to `instant` mines pending transactions                         |

Block time follows these rules:

- Timepoints are Unix nanoseconds as decimal strings, the value contracts read with `get_block_timepoint()`.
- After a time change, later blocks continue from the new time. They do not fall back to the wall clock.
- Blocks never move backward. A timepoint earlier than the chain tip’s returns `-32602`.
- A contract view runs at the time the next block would get, so it sees a time change at once. This needs thruput CLI 0.47.0 or later; see the note below.

For example, move 30 days ahead and produce a block at the new time:

```bash
curl -s http://127.0.0.1:9545 -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"dev_increaseTime","params":{"nanoseconds":"2592000000000000"}}'
curl -s http://127.0.0.1:9545 -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":2,"method":"dev_produceBlock","params":{}}'
```

To make block time deterministic, start the node with `--block-time-step-ms`. Each block without a pinned time then gets its parent’s time plus the step, and `0` freezes the clock until the next time change. `dev_setBlockTimeStep` changes the step on a running node.

> **Note**
>
> Before thruput CLI 0.47.0, contract views ran at the later of the wall clock and the tip’s time, so a chain dated in the past showed today’s date in views.

The TypeScript RPC client has typed methods with the same names. Timepoints and durations are `bigint` nanoseconds:

```ts
import { createRpcClient, HttpTransport } from "@thruputchain/client";

const rpc = await createRpcClient({
  transport: new HttpTransport("http://127.0.0.1:9545"),
  requiredMethods: ["dev_increaseTime", "dev_produceBlock"],
});
const thirtyDays = 30n * 24n * 60n * 60n * 1_000_000_000n;
await rpc.dev_increaseTime({ nanoseconds: thirtyDays });
const block = await rpc.dev_produceBlock();
console.log(block.blockHeight, block.blockTimepoint);
```

`requiredMethods` makes client creation fail with an [`rpcIncompatible`](../typescript/reference/errors.md#rpcincompatible) error when the endpoint does not serve the methods, for example on a hosted network.

The [JSON-RPC reference](../reference/json-rpc-api.md#block-and-time-methods) lists the parameters and results. In Rust, [testkit](../contracts/testing.md#testkit) wraps these methods on `Network`.

<a id="runtime-selection"></a>

## Runtime selection

The CLI selects a default from its bundled runtime catalog. See [local runtime setup](install.md#set-up-the-local-runtime) to inspect and install managed runtimes.

To inspect the effective configuration:

```bash
thruput status --json
```

An explicit `--hog-devnode-binary`, `THRUPUT_DEVNODE_BINARY`, or adjacent binary can take precedence over managed selection. Use `--hog-devnode-version VERSION` when intentionally selecting an exact catalog entry. `--offline` prevents managed downloads, not RPC or Cargo traffic.

If the runtime is incompatible, select matching binaries. `--hogd-protocol` changes a handshake token only; it does not make different wire formats compatible.

For isolated automated runs, prefer [integration tests](build-and-test.md#integration-and-workspace-runs) rather than managing a long-running node yourself.
