<a id="_top"></a>

# Install the CLI

Source: <https://www.thruput.network/docs/cli/install/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Install the latest Thruput CLI and the local runtime for contract development.

Install the latest `thruput` release. The CLI selects the dependencies and compiler settings for projects it creates; you do not need to choose SDK or node versions.

<a id="before-you-start"></a>

## Before you start

Install Rust with [rustup](https://rustup.rs/).

Check that Cargo is available:

```bash
cargo --version
```

<a id="install-with-cargo"></a>

## Install with Cargo

The CLI, SDK, and testkit are published on [crates.io](https://crates.io/crates/thruput).

```bash
cargo install thruput --locked
thruput --version
```

The first command installs the latest CLI with its release’s dependency lockfile. The second should print the installed CLI version.

For Futurenet platform 0.1.38, use CLI 0.48.0. Its wallet commands use the network’s current default-wallet transaction format.

Cargo installs executables in `~/.cargo/bin`. If `thruput` is not found, add that directory to your shell’s `PATH` and open a new terminal.

<a id="set-up-the-local-runtime"></a>

## Set up the local runtime

Local nodes and RPC integration tests use `hog-devnode`. The CLI selects a compatible runtime from its bundled catalog and can download it when needed. To inspect available versions and install the selected runtime in advance:

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

`list` shows the runtime catalog and installed versions. `install` downloads and verifies the selected runtime bundle. `which` shows the selected binary’s path.

CLI 0.48.0 uses hog-devnode 0.1.37. The managed Linux builds support x86-64 and ARM64, require glibc 2.38 or later, and include jemalloc and Snappy through static linking. The managed Mac build requires Apple silicon and macOS 26 or later.

If you previously pinned an older runtime, select the matching one with `thruput toolchain use 0.1.37`.

These commands manage the local-node runtime. Rust is managed through `rustup`, and the CLI is installed separately as shown above. You do not need a local node to use Futurenet.

See [runtime selection](local-node.md#runtime-selection) for version and binary overrides.

<a id="update-an-existing-installation"></a>

## Update an existing installation

Run the same `cargo install` command to install the latest release. Keep the `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml` generated for each project rather than replacing them with files from another example.

If an older executable is still selected, check its location:

```bash
command -v thruput
thruput --version
```
