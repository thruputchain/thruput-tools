<a id="_top"></a>

# Install the CLI

Source: <https://thruput.network/docs/cli/install/>

Documentation source: `53198a762a9adc3260457997acb6ad86b75d9932`. Hosted docs may be newer than this snapshot.

Install the latest Thruput CLI and prepare Cargo access for contract development.

Install the latest `thruput` release. The CLI selects the dependencies and compiler settings for projects it creates; you do not need to choose SDK or node versions.

<a id="before-you-start"></a>

## Before you start

- Install Rust with [rustup](https://rustup.rs/). Each project pins its own toolchain in `rust-toolchain.toml`: a nightly with the RV32 target and `rust-src`. Run `thruput status` in the project; it reports a missing toolchain or component and prints the `rustup` command that installs it.
- Obtain access to the Project Thruput Cargo registry from your onboarding contact. Repository access alone does not grant package access.

Check that Cargo is available:

```bash
cargo --version
```

<a id="configure-cargo-access"></a>

## Configure Cargo access

Set the registry address and credential provider in your shell:

```bash
export CARGO_REGISTRIES_THRUPUT_INDEX="sparse+https://crates.thruput.network/api/v1/crates/"
export CARGO_REGISTRIES_THRUPUT_CREDENTIAL_PROVIDER=cargo:token
```

Supply `CARGO_REGISTRIES_THRUPUT_TOKEN` through your credential manager or onboarding environment. Keep the token out of project files and agent prompts. If you already use a Cargo credential manager for this registry, keep its provider instead.

Use the same registry access in terminals where you build contracts. The generated project includes the registry address, but it does not include your credentials.

<a id="install-with-cargo"></a>

## Install with Cargo

```bash
cargo install thruput-cli --registry thruput --locked
thruput --version
```

The first command installs the latest CLI with its release’s dependency lockfile. The second should print the installed CLI version.

Cargo installs executables in `~/.cargo/bin`. If `thruput` is not found, add that directory to your shell’s `PATH` and open a new terminal.

<a id="set-up-the-local-runtime"></a>

## Set up the local runtime

Local nodes and RPC integration tests use `hog-devnode`. The CLI selects a compatible runtime from its bundled catalog and can download it when needed. To inspect available versions and install the selected runtime in advance:

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

`list` shows the runtime catalog and installed versions. `install` downloads and verifies the selected runtime bundle. `which` shows the selected binary’s path.

On Linux, a local node requires the system jemalloc and Snappy libraries. If an error names `libjemalloc.so.2` or `libsnappy.so.1`, install your distribution’s corresponding packages (`libjemalloc2` and `libsnappy1v5` on Ubuntu).

These commands manage the local-node runtime. Rust is managed through `rustup`, and the CLI is installed separately as shown above. You do not need a local node to use Futurenet.

See [runtime selection](local-node.md#runtime-selection) for version and binary overrides.

<a id="update-an-existing-installation"></a>

## Update an existing installation

Run the same `cargo install` command to install the latest release. Keep the `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml` generated for each project rather than replacing them with files from another example.

If an older executable is still selected, check its location:

```bash
command -v thruput
thruput --version
```
