<a id="_top"></a>

# For Distributed Systems Developers

Source: <https://thruput.network/docs/start/for-distributed-systems-developers/>

Documentation source: `245ae77a61dbf80ce178bf622622c0e73f1230a6`. Hosted docs may be newer than this snapshot.

Understand Project Thruput's use of commutative updates within consensus blocks.

Project Thruput uses commutative operations to combine concurrent changes within a block. The storage model supports parallel execution; consensus selects the result validators commit.

<a id="your-head-start"></a>

## Your Head Start

Additions such as `+5` and `+3` have the same sum in either order. Project Thruput’s [`Balance`](../programming-model/storage-types.md#balance) and [`NNInt`](../programming-model/nnint.md) expose relative updates with explicit bounds. `Map<K, V>` gives separate keys independent storage locations.

The similarity to counters and maps in CRDT systems is useful, but the coordination model differs.

<a id="coordination-at-block-boundaries"></a>

## Coordination at Block Boundaries

CRDTs can reconcile independently updated replicas. Project Thruput instead executes transactions against a common committed snapshot, reserves compatible typed changes, and uses [consensus](../how-it-works/consensus.md) to select a finalized block.

- **Merge rules operate within a proposal.** Applications do not maintain vector clocks to reconcile ordinary balance or map updates.
- **Bounds still apply.** A balance cannot commit below zero. If concurrent debits exceed the available value, an overdrawing attempt is excluded from the proposal. Requeue and reported status depend on later processing. See [Transaction Lifecycle](../how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission).
- **Consensus selects one result.** Validators verify the proposed state transition. Nodes that have applied the same finalized block agree on that state.
- **Readers can see different heights.** A node may lag while receiving or replaying blocks. Check the returned read height when freshness matters.

<a id="if-you-dont-know-any-of-this"></a>

## If You Don’t Know Any of This

You can write contracts without implementing a concurrency algorithm. Choose the storage type for the updates your application needs, then use its ordinary Rust methods. The [backend-developer guide](for-backend-developers.md) explains the same model through database concepts.

<a id="next-steps"></a>

## Next Steps

- [Contract Execution](../programming-model/execution.md): snapshots, deltas, and exclusion
- [Storage Types](../programming-model/storage-types.md): data-model choices
- [How Conflicts Are Resolved](../how-it-works/execution-model.md#how-conflicts-are-resolved): engine reservation details
- [Contract quickstart](../get-started/contract.md): build and deploy a counter
