<a id="_top"></a>

# For Distributed Systems Developers

Source: <https://docs.groundhog.dev/start/for-distributed-systems-developers/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Map your distributed systems experience to Groundhog's programming model.

Commutative operations are a useful starting point for Groundhog. Its typed deltas combine changes within a consensus block, rather than reconciling independently writable replicas.

***

<a id="your-head-start"></a>

## Your Head Start

You already think in terms of commutative operations. You know that `x + 5` and `x + 3` produce the same result in any order. You know that operations on independent keys don’t interact. You’ve designed systems around these properties.

That instinct is exactly right for Groundhog. [`Balance`](../programming-model/storage-types.md#balance) exposes checked and lazy increases and decreases for non-negative values. Lower-level [`NNInt`](../programming-model/storage-types.md#nnint) works like a counter whose signed changes combine additively. `Map<K, V>` gives you key-level independence. If you’ve ever reached for a PN-Counter or a per-key CRDT map, you already know why these primitives exist.

The key distinction is where coordination happens.

***

<a id="coordination-at-block-boundaries"></a>

## Coordination at Block Boundaries

**Groundhog has consensus.** CRDTs solve the problem of replicas that diverge and must eventually agree without coordination. Groundhog has a consensus protocol. Every block is agreed upon by the network. The types don’t exist to achieve convergence across unsynchronized replicas. They exist to enable parallel execution *within* a single consensus round.

All transactions in a block execute against the same frozen snapshot. They produce typed changes, called [deltas](../programming-model/execution.md#merged-deltas). The runtime checks which changes can coexist, and each finalized block contains one committed result. There’s no divergence to reconcile.

This means:

- **No causal metadata.** No vector clocks, no dot stores, no version vectors. The block boundary is the synchronization point. There’s no partial order to resolve.
- **Balance limits are enforced.** A PN-Counter can go negative. Groundhog’s `Balance` API keeps ordinary balances non-negative, and the runtime checks the combined result when lazy deltas commit. If debits exceed the available value, one or more transactions are excluded and returned to the mempool. No tombstones, no compensating operations.
- **Each block has one result.** There is no continuous merge through anti-entropy or gossip. Nodes that have applied the same finalized block agree on its state.
- **Finalized state.** Nodes may lag while receiving or replaying blocks; applications read the state at the serving node’s available height.

***

<a id="if-you-dont-know-any-of-this"></a>

## If You Don’t Know Any of This

That’s fine. Groundhog doesn’t require distributed systems knowledge. Use `Balance` for balances and allowances, `NNInt` for signed counters or votes, and `Map` for per-key data. The types handle commutativity for you. The [For Backend Developers](for-backend-developers.md) guide maps the same concepts from database experience, which may be a better starting point.

***

<a id="next-steps"></a>

## Next Steps

For the contract-level model, see [Merged Deltas](../programming-model/execution.md#merged-deltas). For the storage type API, see [Storage Types](../programming-model/storage-types.md). For concurrent delta reservation and the engine’s actual conflict timing, see [How Conflicts Are Resolved](../how-it-works/execution-model.md#how-conflicts-are-resolved).

Ready to write code? The [contract quickstart](../get-started/contract.md) walks you through building and deploying your first contract.
