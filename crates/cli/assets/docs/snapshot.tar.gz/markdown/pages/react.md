<a id="_top"></a>

# React

Source: <https://thruput.network/react/>

Documentation source: `d89a8eac8de7a71bf60ed8ff38614a3cfc51ca12`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Use Stellar Thruput's React provider and hooks for wallets and contract data.

Build wallet controls and contract-data interfaces with `@thruputchain/react`. The library supplies state and hooks; you supply the components, styling, and application workflow.

<a id="how-the-layers-fit"></a>

## How the layers fit

- The **TypeScript client** connects to a network and executes typed contract operations.
- **WalletProvider** shares that client and manages wallet discovery, connection, and account selection.
- **TanStack Query** manages read state, caching, and mutations through your application’s `QueryClient`.
- **Contract bindings** describe each contract’s methods, results, errors, and events.

The library manages one configured application network and one selected wallet connection. Public reads work without wallet permission. A connected wallet supplies the signing client for writes.

<a id="start-with-a-read"></a>

## Start with a read

The [React quickstart](get-started/react.md) displays Futurenet’s native-token supply using the supplied ERC-20 binding and contract address. You do not need Rust, the CLI, or your own deployment.

For an existing app, follow [Setup](react/setup.md) and [Providers and clients](react/providers.md). Then use [Read contract data](react/reads.md) or [Read balances](react/balances.md). [Cache and refresh data](react/queries.md) explains the query behavior shared by those hooks.

<a id="add-wallet-actions"></a>

## Add wallet actions

[Connect a wallet](react/wallets.md) covers discovery, account selection, and connection states. [Send transactions](react/transactions.md) and [Track transaction results](react/transaction-status.md) cover the approval-to-receipt flow.

Use the [TypeScript account model](typescript/wallet-clients.md) for shared signing concepts and the [React API reference](react/reference.md) for exact hook inputs and results. Complete application walkthroughs belong in [Guides](guides.md).
