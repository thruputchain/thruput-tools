<a id="_top"></a>

# Guides

Source: <https://docs.groundhog.dev/guides/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Learn Groundhog through contract tutorials, application walkthroughs, and worked designs.

Build a project or work through a design. Choose a guide by the result you want, and use the product sections for individual commands and API details.

<a id="start-with-a-counter"></a>

## Start with a counter

Start with the [contract quickstart](get-started/contract.md) for a working Devnet deployment, then continue with the detailed guides:

1. [Build a Counter](tutorials/build-a-counter.md) explains a small Rust contract, storage, errors, and tests.
2. [Develop Locally](tutorials/develop-locally.md) walks through deploying and calling the counter on a local node.
3. [Work with Groundhog from TypeScript](tutorials/work-with-groundhog-from-typescript.md) connects a typed client to a contract.
4. [Add Events to a Contract](tutorials/add-events-to-a-contract.md) follows an event from its Rust definition through application queries.

For a hosted deployment, follow [Develop on Devnet](tutorials/develop-on-devnet.md).

<a id="explore-another-project"></a>

## Explore another project

- **[Connect a Wallet to Your App](tutorials/connect-a-wallet-to-your-app.md)** builds a vanilla TypeScript interface for connecting a wallet, sending a transfer, and checking its receipt.
- **[Build a Token](tutorials/build-a-token.md)** is a contract tutorial covering storage, an interface implementation, and tests.
- **[Design a Swap](tutorials/design-a-swap.md)** is a design walkthrough covering request acceptance, execution, and batching. Read it for the design decisions rather than a complete application setup.

<a id="find-example-code"></a>

## Find example code

The [Groundhog examples repository](https://github.com/groundhogchain/groundhog-examples) contains contract and application examples. Use each example’s README for its setup, supported dependencies, and checks.

For your first setup, start with [Get Started](get-started.md).
