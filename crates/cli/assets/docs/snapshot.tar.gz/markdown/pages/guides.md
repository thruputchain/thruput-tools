<a id="_top"></a>

# Guides

Source: <https://thruput.network/docs/guides/>

Documentation source: `fd91c2019cd8f984aeda15c0303042679e1c8825`. Hosted docs may be newer than this snapshot.

Build a token, build an AMM, or consume the firehose with runnable examples and verified checkpoints.

Work through a focused project using the [examples repository](https://github.com/thruputchain/thruput-examples):

- [Build a token](guides/build-a-token.md): balances, allowances, supply policy, events, and native/RV32 checks.
- [Build an AMM](guides/build-an-amm.md): pool creation, liquidity, queued swaps, and correlated outcomes, exercised through the contract test environments.
- [Consume the Firehose](guides/consume-the-firehose.md): connect to whole-block delivery, acknowledge durable progress, and resume after a disconnect.

For the full contract-to-application journey, follow the [counter tutorials](tutorials.md).
