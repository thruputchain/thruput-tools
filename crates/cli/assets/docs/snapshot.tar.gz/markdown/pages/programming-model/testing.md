<a id="_top"></a>

# Testing

Source: <https://thruput.network/programming-model/testing/>

Documentation source: `582945cad17772e51e67cf2cb7d0d7cf8f979b0d`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

How to test Stellar Thruput contracts: native logic tests, RV32 integration tests, setup, and error matching.

<a id="test-modes"></a>

## Test Modes

Choose a test path based on the boundary you need to exercise:

| Command                      | What it covers                                                   | Use for                                            |
| ---------------------------- | ---------------------------------------------------------------- | -------------------------------------------------- |
| `cargo test`                 | Native SDK execution in process                                  | Fast logic tests, error-path assertions, debugging |
| `thruput test`               | Executor-backed RV32 artifact test                               | Contract artifact behavior without an RPC node     |
| `thruput test --integration` | Ephemeral `hog-devnode`, deployed RV32 artifact, RPC client path | End-to-end deploy/call tests                       |

Start with `cargo test`, then run `thruput test` against the RV32 artifact. Add `thruput test --integration` when you need to test the same path a partner or app will use: build artifact, local node, deployment, signing profile, RPC URL, and generated client behavior.

`thruput test --integration` builds and deploys RV32, the normal user-contract runtime.

Fresh projects include the integration target and host-only dependencies. The CLI can acquire a compatible catalog-pinned `hog-devnode`; use `thruput toolchain list` to inspect it. `THRUPUT_DEVNODE_BINARY` selects an explicit matching source build.

<a id="what-the-scaffold-gives-you"></a>

## What the Scaffold Gives You

The `counter` and `stub` templates include:

```text
build.rs
tests/
  integration.rs
```

`tests/integration.rs` starts with one ignored RPC smoke test. It checks that the CLI provided a deployed contract, connects to the ephemeral node with `groundhog-json-rpc-client`, and calls `chainTip`. Replace or extend the final placeholder with assertions for your contract.

The starter remains ignored under ordinary `cargo test`, even if you explicitly enable its feature. `thruput test --integration` enables the feature and sets `THRUPUT_INTEGRATION_TEST=1`, which lets the scaffold’s `build.rs` activate the live test. You can rename the module and test functions without changing how activation works.

The generated `thruput-integration-test` feature enables the optional RPC client and Tokio dependencies. Their target-specific Cargo entries keep them out of RV32 guest builds. Preserve the SDK and RPC versions selected together by the scaffold.

The generated `build.rs` contains:

```rust
fn main() {
    println!("cargo:rerun-if-env-changed=THRUPUT_INTEGRATION_TEST");
    println!("cargo:rustc-check-cfg=cfg(thruput_integration_runner)");

    if std::env::var("THRUPUT_INTEGRATION_TEST").as_deref() == Ok("1") {
        println!("cargo:rustc-cfg=thruput_integration_runner");
    }
}
```

> **tip: Projects created with an older scaffold**
>
> Compare with a fresh scaffold, then add `tests/integration.rs`, its feature and host-only dependencies, and the integration activation logic from `build.rs`. If your project already has a build script, merge the activation lines into its existing `main` function. The CLI exits with `integration_test_not_found` when the test target is absent.

<a id="test-setup"></a>

## Test Setup

Your `lib.rs` must include `sdk::declare_mock_contract!()` to generate the `register_mock_contract` function used in tests:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;
pub use implementation::*;
```

<a id="basic-pattern"></a>

## Basic Pattern

```rust
use sdk::*;

use my_counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            client.increment(5);
            assert_eq!(client.get(), 15);
        })
    })
    .assert_success();
}
```

Breaking this down:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()`.
3. **`*test_contract.as_hash()`** copies the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from, and `.run(closure)` executes the closure in a simulated execution context. The returned `TransactResult` records the outcome, return value, and emitted events. `.assert_success()` panics with details if the transaction did not commit.
5. **`deploy_contract`** deploys the contract and returns its address. The nonce makes the address deterministic.
6. **`CounterClient::new`** creates a typed client. Methods return values directly.

<a id="no_cost-vs-default"></a>

## `no_cost` vs `default`

Use [`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost) for most contract logic tests. It disables storage cost enforcement, which keeps tests focused on method behavior, storage mutations, events, and expected exceptions.

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) when the test should exercise the normal storage cost model. This is useful for storage-token behavior, deployment cost checks, or tests that should fail when the caller has not been funded correctly.

Use `TestEnvironment::new(Some(&model))` when the test is specifically about a custom `StorageCostModel`. Use `setup_grant_storage_tokens` to fund accounts in cost-sensitive tests.

For the full generated API, see the [`TestEnvironment` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html) or [Rust API Docs](../tools/rust-api-docs.md).

When a native test needs a custom transaction context, start with `env.transaction()`. The builder currently supports replacing the default authorization claim:

```rust
let result = env
    .transaction()
    .with_auth_claim(auth_claim)
    .transact(|tx| tx.call(&caller).run(|| {
        // contract calls
    }));
```

Finish the builder with `transact` for auto-commit, `transact_manual` for explicit commit or abort control, or `build` to obtain a `MockTransactionHandler` directly. Plain `env.transact(...)` remains the shorthand for the default transaction configuration.

Use `thruput test --integration` when the thing under test is not just contract logic: local node startup, RV32 artifact deployment, profile resolution, signing, RPC environment variables, or generated off-chain client behavior.

<a id="testing-error-cases"></a>

## Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
use my_counter::{CounterClient, register_mock_contract};

assert_eq!(
    client.try_decrement(10).unwrap_err().try_as(),
    Some(LibraryExn::NonNegativeIntUnderflow),
);
```

The `try_decrement` method (generated alongside `decrement` by the `#[contract]` macro) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`, which is the same for every client: a caught exception stays undecoded inside it, and `try_as` decodes it as whichever exception type you name. When more than one type is of interest, `match_exn!` matches several in one place. See [Handle errors](../contracts/errors.md) for the full error model.

<a id="integration-test-environment"></a>

## Integration Test Environment

`thruput test --integration` runs `tests/integration.rs` against an ephemeral `hog-devnode`. The CLI builds and deploys the selected artifact, then sets:

| Variable                   | Value                                       |
| -------------------------- | ------------------------------------------- |
| `THRUPUT_INTEGRATION_TEST` | `1`; activates the scaffolded live test     |
| `THRUPUT_RPC_URL`          | RPC URL for the ephemeral node              |
| `THRUPUT_CONTRACT_ADDRESS` | Deployed contract address                   |
| `THRUPUT_PROFILE`          | `integration`                               |
| `THRUPUT_DEFAULT_KEY`      | Lowest-index `local_user`, normally `dev-1` |
| `THRUPUT_RUNTIME_MANIFEST` | Runtime manifest path, when available       |

The full run is:

1. Build the RV32 artifact.
2. Start an isolated local node.
3. Deploy it with the runtime’s lowest-index `local_user`, normally `dev-1`. `dev-0` remains reserved for the local faucet.
4. Enable `thruput-integration-test` and run only the `integration` Cargo test target with the environment above.
5. Shut down the node after the test run, including after test failures.

Normal test-harness controls such as `--match-test`, `--skip`, `--show-output`, `--no-capture`, and `--test-threads` apply to integration tests. `--watch` and `--rerun` cannot be combined with `--integration` yet.

Integration tests use the same RV32 artifact path as normal builds and deployments.

<a id="named-addresses"></a>

## Named Addresses

`ContractAddress::named("alice")` produces a deterministic address from a string. Same name always returns the same address. The method hashes the name with SHA-256 at runtime, so it cannot initialize a `static` or `const`. Bind it inside the test or a `LazyLock` instead:

```rust
#[test]
fn transfer_between_known_addresses() {
    let alice = ContractAddress::named("alice");
    let bob   = ContractAddress::named("bob");
    // ...
}
```

The `Named` trait that provides this method is re-exported through `sdk::*` when the `dev` feature is enabled.
