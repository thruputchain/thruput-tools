<a id="_top"></a>

# Thruput roadmap

Source: <https://thruput.network/architecture/roadmap/>

Documentation source: `44bc1f66f613eb3dcda6693605fcd1b6d4a41d48`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Candidate improvements, open questions, and ways to help shape Stellar Thruput.

These are candidate improvements to Stellar Thruput, roughly ordered by what they could unblock. The order is provisional. Scope and priorities can change as people build on Futurenet; there are no committed delivery dates.

Last reviewed: October 13, 2026.

<a id="proposed-next-work"></a>

## Proposed next work

<a id="block-and-transaction-history"></a>

### Block and transaction history

Public block queries and recoverable transaction feeds would let explorers and independent indexers discover chain activity without private infrastructure access. Block queries remain incomplete; the supported feed and its recovery contract still need qualification. Indexer requirements and tests for resuming after an outage would help.

<a id="contract-failure-diagnostics"></a>

### Contract failure diagnostics

Failures inside wallet or other nested contract calls can be difficult to locate. The goal is to preserve which call failed and provide more useful runtime fault details through the [public API](../reference/json-rpc-api.md). Small contracts that reproduce difficult failures are useful contributions.

<a id="state-preserving-upgrades"></a>

### State preserving upgrades

Supported upgrade paths and migration tooling would reduce the need to recreate applications after network changes. This work is deferred. Futurenet can still reset, as described in [Get Started](../get-started.md). Upgrade fixtures, compatibility tests, and operator feedback would help define the supported paths.

<a id="exploring"></a>

## Exploring

<a id="post-quantum-readiness"></a>

### Post quantum readiness

Thruput’s authorization model already supports multiple keys per address and is designed to accommodate multiple cryptographic key types. Ed25519 is the currently supported scheme. We’re evaluating post-quantum options and their performance impact. The migration design also needs to cover account and validator keys. Threat-model, performance, and migration-design reviews would help.

<a id="open-to-builders"></a>

## Open to builders

<a id="ecosystem-tooling"></a>

### Ecosystem tooling

Wallet integrations, oracles, and application conventions are areas where builder demand can shape the work. The [wallet integration guide](../tools/wallet-integration.md) is a starting point. Bring an integration or application that exposes a concrete need, and find related projects through the [GitHub community](https://github.com/thruputchain).
