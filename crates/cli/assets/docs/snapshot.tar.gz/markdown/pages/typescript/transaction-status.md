<a id="_top"></a>

# Track transaction results

Source: <https://docs.groundhog.dev/typescript/transaction-status/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.

Submission, commitment, execution, and decoding are separate steps. Keep the transaction hash and network so the application can continue observing the same operation after a timeout or wallet disconnect.

<a id="inspect-a-submitted-transaction"></a>

## Inspect a submitted transaction

Use the public client from [Connect to a network](connect.md). Create `src/status.ts`:

```ts
import { ExecResult, hashFromHex } from "@groundhogchain/client";
import { client } from "./client.js";

const text = process.env.GROUNDHOG_TX_HASH;
if (!text) throw new Error("Set GROUNDHOG_TX_HASH to the submitted transaction hash");
const hash = hashFromHex(text);
const status = await client.getTransactionStatus(hash);

if (status.status === "committed") {
  const receipt = await client.getTransactionReceipt(hash);
  if (!receipt) throw new Error("The committed receipt is not available from this endpoint");
  console.log("Execution succeeded:", receipt.execResult === ExecResult.ExecResultOK);
  console.log("Block:", receipt.height.toString());
} else {
  console.log("Status:", status.status);
}
```

This performs one status check. `waitForTransactionReceipt(hash)` polls for a receipt, but does not itself require successful execution. Check `execResult` or use `waitForExecution(client, hash)` to require success.

<a id="interpret-status"></a>

## Interpret status

| Status               | Application meaning                                              |
| -------------------- | ---------------------------------------------------------------- |
| `pending`            | The gateway knows the transaction; keep waiting                  |
| `committed`          | Fetch the receipt and check execution                            |
| `invalid`            | Show the reported reason                                         |
| `recentFailure`      | Advisory failure of an attempt; the transaction can still commit |
| `unknown` or `other` | No conclusive successful or failed execution result              |

A timeout or canceled observation does not cancel onchain execution. Query the original hash on the original network rather than automatically signing a replacement.

<a id="handle-execution-helper-errors"></a>

## Handle execution-helper errors

| Error                             | What happened                                                     | What to retain                               |
| --------------------------------- | ----------------------------------------------------------------- | -------------------------------------------- |
| `TransactionExecutionError`       | Committed execution failed                                        | `receipt`                                    |
| `TransactionObservationError`     | Observation failed after submission was attempted                 | `txHash`, `cause`, and any `submissionCause` |
| `ExecutionDecodeError`            | Execution succeeded, but child return decoding failed             | Successful `receipt` and decoding cause      |
| `ExecutionReturnUnavailableError` | Execution succeeded, but the wallet did not provide child returns | Successful `receipt`                         |

For example, classify errors from a wallet execution helper:

```ts
import { TransactionExecutionError, TransactionObservationError, toHex0x } from "@groundhogchain/client";

export function describeExecutionError(error: unknown): string {
  if (error instanceof TransactionObservationError) {
    return `Check transaction ${toHex0x(error.txHash)} on its original network`;
  }
  if (error instanceof TransactionExecutionError) {
    return `Committed execution failed: ${error.receipt.execResult}`;
  }
  return error instanceof Error ? error.message : "Transaction operation failed";
}
```

A decoding failure is not a reason to repeat a successful write. Keep the submitted call descriptors if you need to decode the receipt again later.

<a id="decode-the-correct-method"></a>

## Decode the correct method

`decodeReceipt` and `decodeReceiptOutcome` apply to a known **root method**. A wallet-root receipt is not a receipt for the application method it called. Use `executeCallsAndWait` or `decodeExecution(receipt, calls)` for ordered DefaultWallet child returns.

Do not decode a root abort with a child method’s exception schema merely because the transaction contained one child call. The wallet itself may have failed before the child executed.

<a id="restore-application-state"></a>

## Restore application state

After a reload, use the saved hash and network to resume public observation. This does not require the wallet to remain connected. A provider’s `onSigned` callback provides the pre-submission record; see [Send transactions](transactions.md#send-through-a-browser-wallet).

For protocol-level outcomes, see [Transaction Lifecycle](../how-it-works/transaction-lifecycle.md).
