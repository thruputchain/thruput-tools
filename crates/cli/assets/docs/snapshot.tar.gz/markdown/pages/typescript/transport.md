<a id="_top"></a>

# Configure HTTP transport

Source: <https://www.thruput.network/docs/typescript/transport/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Set RPC timeouts, batch independent reads, and classify transport failures.

The client uses HTTP JSON-RPC by default. Supply `HttpTransport` when you need explicit timeout, header, or batching settings.

<a id="set-a-request-timeout"></a>

## Set a request timeout

```ts
import { createThruputClient, futurenet, HttpTransport } from "@thruputchain/client";

const cluster = futurenet();
const client = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, { timeoutMs: 10_000 }),
});
```

The cluster still controls identity checks; the transport controls requests to the endpoint. A timeout ends observation of that request, not an already-submitted transaction.

<a id="http-batching"></a>

## HTTP batching

Batch independent RPC reads into fewer HTTP requests:

```ts
const batched = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, {
    batch: { maxSize: 100, waitMs: 0 },
    timeoutMs: 10_000,
  }),
});
const [tip, version] = await Promise.all([
  batched.getChainTip(),
  batched.getVersionInfo(),
]);
```

Batching is off by default. `batch: true` uses the defaults shown. Concurrent requests are grouped within the scheduling window and split at `maxSize`.

- Responses match by request ID, not array position.
- Per-call RPC errors remain separate. HTTP or malformed-batch failures reject affected requests.
- Cancellation removes one caller; canceling every caller can cancel the shared request.
- HTTP batching does not provide a shared state snapshot or an atomic transaction. Use [shared-snapshot reads](reads.md#read-related-values-from-one-snapshot) when related contract values must come from one state; awaiting separate reads does not make their snapshots match.

Server [array and byte limits](../reference/json-rpc-api.md#json-rpc-arrays) still apply.

<a id="handle-transport-errors"></a>

## Handle transport errors

Errors are `ThruputError`s; check them with `isThruputError(error, code)`.

| Code                                                                                                                                | Boundary                                                          |
| ----------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| [`httpRequestFailed`](reference/errors.md#httprequestfailed)                                                                        | Network request failed                                            |
| [`httpResponseError`](reference/errors.md#httpresponseerror)                                                                        | Non-success HTTP status                                           |
| [`nativeRpcError`](reference/errors.md#nativerpcerror)                                                                              | RPC error response; typed `context.kind` and the raw error        |
| [`rpcResponseInvalid`](reference/errors.md#rpcresponseinvalid)                                                                      | Malformed JSON-RPC reply; retains the raw reply                   |
| [`rpcIncompatible`](reference/errors.md#rpcincompatible)                                                                            | Unsupported wire format, network mismatch, or unadvertised method |
| [`rpcRequestInvalid`](reference/errors.md#rpcrequestinvalid)                                                                        | Invalid local request, rejected before dispatch                   |
| [`rpcValueInvalid`](reference/errors.md#rpcvalueinvalid)                                                                            | Malformed result; retains the raw value                           |
| [`contractViewFailed`](reference/errors.md#contractviewfailed) / [`contractDecodeFailed`](reference/errors.md#contractdecodefailed) | Contract outcome or decoding, not transport                       |

A `nativeRpcError` has `context.kind` from the [error codes](../reference/json-rpc-api.md#error-codes), which narrows `context.data`, or `unrecognized`. Neither grants retry permission. Use `classifyReadError(error, { signal })` when implementing a bounded read-retry policy. See [read cancellation](reads.md#cancel-stale-reads). Do not apply automatic read retries to transaction submission.

<a id="use-a-custom-transport"></a>

## Use a custom transport

Implement the exported `Transport` interface when integrating another request layer. Report failures as a `ThruputError` with code `rpcError`, `httpRequestFailed`, `httpResponseError`, or `rpcResponseInvalid`. A client created with only a transport has no validated cluster identity. For wallet use, provide a trusted signing network hash and verify the endpoint separately, or supply a cluster descriptor as above.
