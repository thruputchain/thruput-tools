<a id="_top"></a>

# Connect to a network

Source: <https://thruput.network/typescript/connect/>

Documentation source: `d89a8eac8de7a71bf60ed8ff38614a3cfc51ca12`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Create a public client, select Futurenet or a local endpoint, and check network identity.

A public client performs RPC reads without signing. Create one per application network and share it across contract bindings and wallet clients.

<a id="connect-to-futurenet"></a>

## Connect to Futurenet

Create `src/client.ts`:

```ts
import { createThruputClient, devnet } from "@thruputchain/client";

export const client = await createThruputClient({ cluster: devnet() });
```

Client creation is asynchronous. It fetches the network identity before returning. Other examples import this client from `./client.js`.

To check the connection, create `src/network.ts`:

```ts
import { toHex0x } from "@thruputchain/client";
import { client } from "./client.js";

const [tip, version] = await Promise.all([
  client.getChainTip(),
  client.getVersion(),
]);
console.log("Network:", toHex0x(client.network.networkHash));
console.log("Block:", tip.height.toString());
console.log("Wire format:", version.wireFormat);
```

```bash
npx tsx src/network.ts
```

No wallet permission or account funding is required.

<a id="select-another-endpoint"></a>

## Select another endpoint

The SDK helper is still named `devnet()` for compatibility. `devnet({ rpcUrl })` overrides the Futurenet endpoint. For a local node, replace the cluster with `localnet()`:

```ts
import { createThruputClient, localnet } from "@thruputchain/client";

const client = await createThruputClient({ cluster: localnet() });
```

Start the node with [the CLI](../cli/local-node.md) first. Local account manifests and RPC endpoints must refer to the same node.

Use `defineCluster()` for a reusable custom descriptor. `mainnet()` requires an explicit endpoint. Cluster capabilities, such as `airdrop`, declare expected services; they are not server capability discovery.

<a id="pin-a-network-identity"></a>

## Pin a network identity

Futurenet is unpinned by default. To require a specific deployment, provide the trusted hash from your environment:

```ts
import { createThruputClient, devnet, hashFromHex, networkHash } from "@thruputchain/client";

const expected = process.env.THRUPUT_NETWORK_HASH;
if (!expected) throw new Error("Set THRUPUT_NETWORK_HASH to the expected 0x-prefixed hash");
const client = await createThruputClient({
  cluster: devnet({ networkHash: networkHash(hashFromHex(expected)) }),
});
```

An identity mismatch throws `NetworkMismatchError`. A Futurenet reset can change the network hash. Update the trusted configuration deliberately rather than accepting a wallet-supplied hash as your application’s network.

<a id="configure-transport-behavior"></a>

## Configure transport behavior

Use [HTTP transport](transport.md) for timeouts, batching, and custom transports. A transport-only client skips cluster identity validation; a wallet bound to it requires an explicit signing network hash.
