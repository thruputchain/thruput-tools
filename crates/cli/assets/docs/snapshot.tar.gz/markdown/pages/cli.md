<a id="_top"></a>

# CLI

Source: <https://docs.groundhog.dev/cli/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Install the Groundhog CLI, configure networks, and build, test, deploy, and call contracts.

`groundhog` is the command-line tool for working with Groundhog projects and networks. Use it to create a project, build and test a contract, run a local node, or interact with a deployed contract.

<a id="projects-and-networks"></a>

## Projects and networks

The CLI works with two kinds of configuration:

- A **project** contains your Rust contract, tests, and build settings.
- A **profile** selects the network and identity used for an interaction.

This lets you build a contract once and use profiles to target a local node or Devnet. You can also use network commands without creating a contract project.

<a id="the-development-loop"></a>

## The development loop

| Task                        | Command            |
| --------------------------- | ------------------ |
| Create a contract project   | `groundhog new`    |
| Build a contract artifact   | `groundhog build`  |
| Run contract artifact tests | `groundhog test`   |
| Start a local node          | `groundhog node`   |
| Deploy a contract           | `groundhog deploy` |
| Call a deployed contract    | `groundhog call`   |

These are command names, not a setup script. Start with [installation](cli/install.md), then follow the [CLI quickstart](get-started/cli.md) for a first Devnet interaction.

The [contract quickstart](get-started/contract.md) adds deployment and calls. Use [Run a local node](cli/local-node.md) when you want a disposable node on your machine.

<a id="look-up-an-option"></a>

## Look up an option

Run `groundhog <command> --help` for the installed version’s options, or use the [command reference](cli/reference.md). [Profiles and networks](cli/configuration.md) explains profile selection and project overrides.

For agent instructions and local documentation, see [Build with an Agent](start/build-with-an-agent.md).
