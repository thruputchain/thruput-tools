<a id="_top"></a>

# CLI

Source: <https://www.thruput.network/docs/cli/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Install the Thruput CLI, configure networks, and build, test, deploy, and call contracts.

`thruput` is the command-line tool for working with Project Thruput projects and networks. Use it to create a project, build and test a contract, run a local node, or interact with a deployed contract.

<a id="projects-and-networks"></a>

## Projects and networks

The CLI works with two kinds of configuration:

- A **project** contains your Rust contract, tests, and build settings.
- A **profile** selects the network and identity used for an interaction.

This lets you build a contract once and use profiles to target a local node or Futurenet. You can also use network commands without creating a contract project.

<a id="the-development-loop"></a>

## The development loop

| Task                        | Command          |
| --------------------------- | ---------------- |
| Create a contract project   | `thruput new`    |
| Build a contract artifact   | `thruput build`  |
| Run contract artifact tests | `thruput test`   |
| Start a local node          | `thruput node`   |
| Deploy a contract           | `thruput deploy` |
| Call a deployed contract    | `thruput call`   |

These are command names, not a setup script. Start with [installation](cli/install.md), then follow the [CLI quickstart](get-started/cli.md) for a first Futurenet interaction.

The [contract quickstart](get-started/contract.md) adds deployment and calls. Use [Run a local node](cli/local-node.md) when you want a disposable node on your machine.

<a id="look-up-an-option"></a>

## Look up an option

Run `thruput <command> --help` for the installed version’s options, or use the [command reference](cli/reference.md). [Profiles and networks](cli/configuration.md) explains profile selection and project overrides.

Use [Skills and local docs](cli/agent-tools.md) to install agent guidance, read bundled references, and serve or export documentation. [Build with an Agent](get-started/build-with-an-agent.md) combines setup with a first-project prompt.
