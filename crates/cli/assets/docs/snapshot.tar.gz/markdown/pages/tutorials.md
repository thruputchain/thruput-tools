<a id="_top"></a>

# Tutorials

Source: <https://www.thruput.network/docs/tutorials/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Build a counter app from an empty directory through contract, TypeScript, React, and wallet connection tutorials.

<a id="build-a-counter-app"></a>

## Build a counter app

One contract and one application across four parts:

1. [Contract](tutorials/build-a-counter.md): write, test, and deploy the counter.
2. [TypeScript](tutorials/work-with-thruput-from-typescript.md): create the client and a server-side development signer.
3. [React](tutorials/build-a-counter-with-react.md): build a working counter interface with development signing and receipt tracking.
4. [Connect a wallet](tutorials/connect-a-wallet-to-your-app.md): switch to wallet-approved updates and return to development signing on explicit disconnect.

Follow the four parts in order, using your own contract and deployment throughout. The [examples repository](https://github.com/thruputchain/thruput-examples) supplies a full-featured counter app for reference.
