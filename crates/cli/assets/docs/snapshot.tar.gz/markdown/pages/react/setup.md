<a id="_top"></a>

# Setup

Source: <https://docs.groundhog.dev/react/setup/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Install the React integration and connect its wallet and query providers to Devnet.

Use the current Node.js LTS release. For a new app, create a React TypeScript project:

```bash
npm create vite@latest my-groundhog-ui -- --template react-ts
cd my-groundhog-ui
npm install
```

Complete the shared [registry access setup](../typescript/setup.md#give-npm-package-access), then install the integration and its client together:

```bash
npm install @groundhogchain/react @groundhogchain/client @groundhogchain/protocol @tanstack/react-query
```

The package manager resolves the React library’s compatible client dependency. Keep the lockfile. In an existing application, satisfy the library’s peer dependencies rather than forcing an incompatible client version. The integration uses React 19 and TanStack Query 5.

<a id="connect-the-application"></a>

## Connect the application

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createGroundhogClient, devnet } from "@groundhogchain/client";
import { WalletProvider } from "@groundhogchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Devnet…</p>);

async function start() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

void start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Devnet"}</p>,
  );
});
```

The public client and query cache are created once, before rendering the app. `WalletProvider` does not request wallet permission automatically.

<a id="check-the-setup"></a>

## Check the setup

Start the development server:

```bash
npm run dev
```

In another terminal, check the production build:

```bash
npm run build
```
