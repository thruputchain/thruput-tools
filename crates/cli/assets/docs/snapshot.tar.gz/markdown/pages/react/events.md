<a id="_top"></a>

# Read events

Source: <https://thruput.network/docs/react/events/>

Documentation source: `53198a762a9adc3260457997acb6ad86b75d9932`. Hosted docs may be newer than this snapshot.

Use the public client and TanStack Query to display typed contract events in React.

Compose the TypeScript client’s event actions with TanStack Query. Generated bindings provide filtering and decoding; React components provide loading, empty, error, and refresh states.

<a id="display-recent-native-token-transfers"></a>

## Display recent native-token transfers

```tsx
import { toBase58 } from "@thruputchain/client";
import { thruput_erc20_if } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { getClientQueryKey, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";

const { TransferEvent } = thruput_erc20_if.v0_1.events;

export function RecentTransfers() {
  const client = useClient();
  const transfers = useQuery({
    queryKey: [...getClientQueryKey(client), "app", "recent-native-token-transfers"],
    queryFn: ({ signal }) => client.getContractEvents({
      event: TransferEvent,
      addresses: [NATIVE_TOKEN_ADDRESS],
      start: { order: "descending", anchor: { kind: "atEnd" } },
      limit: 20,
    }, { signal }),
    staleTime: 10_000,
  });

  return (
    <section aria-label="Recent native-token transfers">
      {transfers.isLoading ? <p>Loading transfers…</p> : null}
      {transfers.error ? <p role="alert">{transfers.error.message}</p> : null}
      {transfers.data?.events.length === 0 ? <p>No transfers in this page.</p> : null}
      <ul>
        {transfers.data?.events.map(event => (
          <li key={`${toBase58(event.transactionHash)}:${event.sequenceNumber}`}>
            {event.fields.amount.toString()} base units at block {event.blockHeight.toString()}
          </li>
        ))}
      </ul>
      <button disabled={transfers.isFetching} onClick={() => void transfers.refetch()}>
        Refresh transfers
      </button>
    </section>
  );
}
```

The query has fixed contract, event, start, and page-size inputs. If you make them configurable, include each input in the key. Include the cursor string when caching separate historical pages.

<a id="choose-a-history-workflow"></a>

## Choose a history workflow

Refreshing the example starts at the head again. A saved `nextCursor` continues an older historical walk; it is not a subscription. Use the TypeScript [event pagination guidance](../typescript/events.md) for iteration and durable checkpoints.

For live refresh, choose an explicit polling policy. Query caching does not create a background indexer or save progress across reloads.

<a id="decode-transaction-events"></a>

## Decode transaction events

A receipt returned by an execution or receipt hook contains events. Use a generated descriptor’s `allFromReceipt` or `singleFromReceipt` with the emitting contract address.

A committed receipt can report failed execution. Check the result before treating its events as successful application activity. See [Track transaction results](transaction-status.md).
