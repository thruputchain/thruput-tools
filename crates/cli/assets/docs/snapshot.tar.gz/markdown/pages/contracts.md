<a id="_top"></a>

# Smart Contracts

Source: <https://www.thruput.network/docs/contracts/>

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Write, test, and understand Project Thruput contracts with the Rust SDK.

Build contract logic with the Rust SDK. Use this section for storage choices, authorization, events, testing, and the contract programming model.

<a id="write-your-first-contract"></a>

## Write your first contract

Follow the [contract quickstart](get-started/contract.md) to deploy a counter on Futurenet. Then read [Build a Counter](tutorials/build-a-counter.md) to understand its code and tests, or [Project structure](contracts/project-structure.md) to find the generated files.

Use the [CLI section](cli.md) for build and deployment commands.

<a id="work-on-a-contract"></a>

## Work on a contract

- [Define methods and interfaces](contracts/methods.md).
- [Choose storage types](contracts/storage-types.md) for your data.
- [Authorize calls](contracts/authorization.md).
- [Define and handle errors](contracts/errors.md).
- [Emit and test events](contracts/events.md).
- [Call another contract](contracts/cross-contract-calls.md).
- [Choose a test mode and write tests](contracts/testing.md).
- [Debug a contract](contracts/debugging.md).
- [Generate client bindings](contracts/client-bindings.md) for application developers.

<a id="understand-the-programming-model"></a>

## Understand the programming model

Read [Contract Execution](contracts/execution.md) first for snapshots, merged changes, and the rules that cause bugs. Then read [Storage Types](contracts/storage-types.md), starting with [Balance](contracts/storage-types.md#balance) for nonnegative counts and amounts. Continue with [NNInt and concurrent updates](contracts/nnint.md) to understand the underlying signed deltas, explicit bases, and merge rules. [Exclusive writes](contracts/storage-types.md#exclusive-writes) and [invocation frames](contracts/invocation-frames.md) cover other storage and call constraints.

Read [Contract artifacts and addresses](contracts/artifacts-and-addresses.md) to understand code hashes, deployment addresses, and immutability.

<a id="look-up-an-api"></a>

## Look up an API

Use the [storage API tables](contracts/reference/storage-types.md), [SDK macros](contracts/reference/sdk-macros.md), [syscalls](contracts/reference/syscalls.md), and [generated Rust API docs](contracts/reference/rust-api-docs.md).

For larger worked examples, visit [Guides](guides.md).
