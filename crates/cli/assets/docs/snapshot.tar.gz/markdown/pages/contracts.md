<a id="_top"></a>

# Smart Contracts

Source: <https://docs.groundhog.dev/contracts/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Write, test, and understand Groundhog contracts with the Rust SDK.

Build contract logic with the Rust SDK. Use this section for storage choices, authorization, events, testing, and the contract programming model.

<a id="write-your-first-contract"></a>

## Write your first contract

Follow the [contract quickstart](get-started/contract.md) to deploy a counter on Devnet. Then read [Build a Counter](tutorials/build-a-counter.md) to understand its code and tests, or [Project structure](contracts/project-structure.md) to find the generated files.

Use the [CLI section](cli.md) for build and deployment commands.

<a id="work-on-a-contract"></a>

## Work on a contract

- [Define methods and interfaces](contracts/methods.md).
- [Choose storage types](programming-model/storage-types.md) for your data.
- [Authorize calls](how-it-works/authorization.md).
- [Define and handle errors](contracts/errors.md).
- [Emit and test events](contracts/events.md).
- [Call another contract](contracts/cross-contract-calls.md).
- [Choose a test mode and write tests](programming-model/testing.md).
- [Debug a contract](contracts/debugging.md).
- [Generate client bindings](contracts/client-bindings.md) for application developers.

<a id="understand-the-programming-model"></a>

## Understand the programming model

Read [execution](programming-model/execution.md) for how contract state changes are applied. Continue with [NNInt and concurrent updates](programming-model/nnint.md), [exclusive writes](programming-model/storage-types.md#exclusive-writes), or [invocation frames](how-it-works/invocation-frames.md) when your design needs that detail.

Read [Contract artifacts and addresses](how-it-works/contracts.md) to understand code hashes, deployment addresses, and immutability.

<a id="look-up-an-api"></a>

## Look up an API

Use the [storage API tables](reference/storage-types.md), [SDK macros](reference/sdk-macros.md), [syscalls](reference/syscalls.md), and [generated Rust API docs](tools/rust-api-docs.md).

For larger worked examples, visit [Guides](guides.md).
