<a id="_top"></a>

# Groundhog

Source: <https://docs.groundhog.dev/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Build Groundhog contracts and applications with the Rust SDK, CLI, and TypeScript client.

<a id="hero"></a>

The blockchain built for\
abundance
---------

Groundhog is an early technology preview of a blockchain designed from first principles. Build a contract, try the developer tools, and help shape what comes next.

## Use a coding agent

```text
Help me deploy my first Groundhog contract to Devnet. Follow https://docs.groundhog.dev/get-started/contract/ using the latest CLI. Read groundhog skill show and its contracts reference, and preserve the project settings it generates. If documentation access is blocked, ask me for a saved copy or use groundhog docs. Keep credentials and signing keys out of this conversation. Set up a funded Devnet wallet, create and test a counter, deploy it, initialize it to 10, increment by 5, and verify that its view returns 15. Do not start a local node. Report actual results and any setup or network errors.
```

<a id="capabilities"></a>

## Programming model

<a id="compute"></a>

01 / COMPUTE

<a id="compute-title"></a>

### [Keep the logic on-chain](programming-model/execution.md)

Match orders, run an auction, or resolve a game turn alongside the assets it moves. Start with the rules your application needs.

Explore execution

<a id="capacity"></a>

02 / CAPACITY

<a id="capacity-title"></a>

### [Compute without gas fees](programming-model/execution.md#gas)

Gas meters execution but costs zero tokens. Hold HOG for capacity and fund storage deposits. Execution still has limits.

Understand capacity

<a id="concurrency"></a>

03 / CONCURRENCY

<a id="concurrency-title"></a>

### [Build on shared state](programming-model/storage-types.md)

Typed storage lets compatible changes merge while contracts execute in parallel. Use the SDK's balance and collection types.

Choose your storage

<a id="resources"></a>

## Development resources

<a id="first-contract"></a>

FIRST CONTRACT

<a id="first-contract-title"></a>

### [Make something work](tutorials/build-a-counter.md)

Build and test a counter. Learn the contract loop before expanding your idea.

<a id="applications"></a>

APPLICATIONS

<a id="applications-title"></a>

### [Connect an interface](tutorials/work-with-groundhog-from-typescript.md)

Use generated TypeScript bindings to call your contract and read its results.

<a id="under-the-hood"></a>

UNDER THE HOOD

<a id="under-the-hood-title"></a>

### [Understand the engine](how-it-works/architecture.md)

Explore execution, consensus, and the storage model behind Groundhog.
