<a id="_top"></a>

# Stellar Thruput

Source: <https://thruput.network/>

Documentation source: `1a24dab12e61451e433e7cf043671d87a3194e81`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Stellar Thruput explores abundant compute through unordered transactions within each block, shared state, and runtime-enforced constraints.

<a id="hero"></a>

Blockchain technology\
built for abundance
-------------------

Parallel execution. Unordered transactions.\
Shared balances without overspending.\
No conventional gas fees.

## Use a coding agent

```text
Help me deploy and use my first Stellar Thruput counter contract on Futurenet.

1. Install the latest Thruput CLI and run thruput init. Use
   thruput --help to see all available commands. Follow the installation
   instructions at https://thruput.network/docs/cli/install/.
2. Install the thruput skill for this project and coding agent with
   thruput skill install, then read the installed skill.
3. Export the documentation into a new folder with thruput docs export.
   Read its index and the relevant setup and contract instructions.
4. Outside a project, run thruput config use futurenet to select the global
   default. Create a wallet with thruput wallet create, then request test funds
   with thruput airdrop. Verify the balance before deployment.
5. Run thruput new counter --template counter, enter the project directory,
   and check thruput config get still selects futurenet. New projects inherit
   the global default. Build the contract and run its tests.
6. Deploy and initialize the counter to 10. Call increment with 5,
   then verify that its read-only view returns 15.

Finish with the project location, contract address, transaction hashes,
verified counter value, and the CLI commands I can use next.
```

01 / A different starting point

<a id="shared-state"></a>

Payments need rules.\
Do they need an order?
----------------------

Stellar Thruput is a moonshot inspired by [Stellar’s mission](https://stellar.org/foundation). It looks a decade ahead, exploring the compute and throughput a globally accessible financial system could need.

Thruput removes transaction order within each block to unlock parallel execution, even across shared balances. Typed storage lets compatible changes combine, while the runtime enforces application constraints and prevents overspending.

Example: Three payments read the same starting balance of 100. Payments of 30 and 40 can land together, leaving 30. Admitting a payment of 50 as well would overspend, so it is excluded. The diagram shows one possible selection.

Blocks still form an ordered history. Within each block, admitted changes combine into the next committed state.

[Explore the execution model](how-it-works/execution-model.md)

Starting balance**100**

Payment &#x41;**−30**Admitted

Payment &#x42;**−40**Admitted

Payment &#x43;**−50**Excluded

Committed balance**30**

One valid outcome: 100 − 30 − 40 = 30

02 / Why Stellar Thruput

<a id="differences"></a>

## More compute. More throughput.

The bet is that removing transaction order within blocks can unlock far more computation for smart contracts. Developers could build the logic their applications need, instead of keeping contracts small to compete for scarce compute within each block. Work pushed offchain by compute limits could move onchain.

Higher throughput follows from the same design, even across shared state. The aim is a new baseline: if an application makes sense onchain, compute and throughput should not hold it back.

<a id="concurrency"></a>

01

### Rules across shared state

A transaction can check its own changes. A capacity constraint can also enforce a shared withdrawal budget across concurrent transactions. The SDK provides storage types for both merge rules and constraints on their combined changes.

[Choose your storage](programming-model/storage-types.md)

<a id="compute"></a>

02

### No conventional gas fees

Gas meters computation without a token fee or burn. We’re exploring whether a trader on Wall Street and a farmer in Kenya can pay the same transaction fee: zero.

[Understand gas limits](programming-model/execution.md#gas)

<a id="capacity"></a>

03

### Balance-based capacity

Thruput tries to get as much work done as capacity allows, instead of rationing it. Under load, unlocked native-token balances determine each account's share of scheduling capacity over time. A root transaction's declared gas limit determines how much capacity it uses.

[Explore scheduling](how-it-works/storage-economics.md#balance-proportional-scheduling)

<a id="storage"></a>

04

### Refundable storage deposits

Stored data locks native tokens as a deposit. Delete the data to reclaim that deposit.

[Understand storage deposits](how-it-works/storage-economics.md#storage-refundable-deposits)

03 / Architecture

<a id="validator-architecture"></a>

## One validator. Many machines.

A Thruput validator is itself a distributed system. A high performance RPC system connects scheduling, authentication, and smart-contract execution across machines.

Authentication and smart-contract execution use this model today. Extending it to state is part of the longer-term plan.

Need more execution capacity? Add executor machines. The goal is to make throughput a hardware-sizing question: start with the work your application needs, then size the compute to match.

[Explore the architecture](how-it-works/architecture.md)

One validator

CoordinatorConsensus with other validators

SchedulerDistribute transaction batches

AuthenticationCheck signatures and claims

Internal RPC

Machine 01

**Contract executor** Run contracts in parallel

Machine 02

**Contract executor** Run contracts in parallel

Machine 03

**Contract executor** Run contracts in parallel

Machine 04

**Contract executor** Run contracts in parallel

Machine 05

**Contract executor** Run contracts in parallel

StateShared snapshots and compatible changes

<a id="scaling-title"></a>

### More machines. More work.

ERC-20 payments / second

**\~3M** payments / sec · 5 machines

1. 700K

   1
2. 1.25M

   2
3. 1.89M

   3
4. 2.42M

   4
5. 2.95M

   5

Machines per validator

<a id="scaling-basis"></a>

Prior ERC-20 execution scaling, normalized to a 700K payments/sec single-machine baseline (64 cores). Multi-machine values are estimates, pending a benchmark rerun.

04 / From contract to application

<a id="developer-experience"></a>

## Write Rust. Build something you can use.

Create, test, deploy, and inspect contracts with a complete CLI. Generate TypeScript bindings to call them from your application. Give your coding agent the `thruput` skill and local docs to work from the same tools and instructions.

[Build a counter, step by step](tutorials/build-a-counter.md)

<a id="counter-panel-0"></a>

### Agent

Agent prompt

```text
Using the thruput skill and local docs,
run thruput new counter --template counter.
Add increment(amount) and decrement(amount) methods
using strict_inc with positive and negative deltas.
Build it and run the native and RV32 tests.
```

<a id="counter-panel-1"></a>

### Rust

**src/implementation.rs**

```rust
pub fn increment(&mut self, amount: u64) {
    self.value.strict_inc(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.strict_inc(-(amount as i128));
}
```

<a id="counter-panel-2"></a>

### TypeScript

**increment.ts**

```ts
const call = Counter.increment.call({
  contract: counterAddress,
  args: { amount: 5n },
  gasLimit: gasAmount(500_000n),
});

await wallet.executeCallsAndWait({
  calls: [call],
  gasLimit: gasAmount(1_000_000n),
});
```

1. 01

   ### [Create](cli/create-project.md)

   Start a project with the CLI.

2. 02

   ### [Write](contracts.md)

   Define contract logic in Rust.

3. 03

   ### [Test](cli/build-and-test.md)

   Check native and RV32 execution.

4. 04

   ### [Deploy](cli/deploy-and-call.md)

   Fund and initialize on Futurenet.

5. 05

   ### [Connect](typescript.md)

   Call with typed bindings.

[![Stellar](../assets/brand/stellar.svg) ![Stellar](../assets/brand/stellar-dark.svg) Thruput](index.md)

A blockchain for abundant compute

Technology preview · alpha-pre.1
