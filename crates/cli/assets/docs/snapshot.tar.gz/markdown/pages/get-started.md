<a id="_top"></a>

# Get Started

Source: <https://thruput.network/docs/get-started/>

Documentation source: `3cc5d07f366f6182e06af875daffd57a90a66e06`. Hosted docs may be newer than this snapshot.

Choose a starting point for Project Thruput contracts, applications, or coding agents.

Get a working result on Futurenet. Choose the tools you want to use; you do not need to follow every path.

<a id="choose-your-path"></a>

## Choose your path

- **[CLI quickstart](get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](get-started/contract.md):** build and test a counter, deploy it to Futurenet, and read its updated value.
- **[TypeScript quickstart](get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.

<a id="work-with-a-coding-agent"></a>

## Work with a coding agent

[Build with an Agent](start/build-with-an-agent.md) gives you one prompt to install the tools, fund a wallet, and deploy and call a counter on Futurenet. For a smaller task, use the prompt in an individual quickstart.

<a id="what-you-need"></a>

## What you need

CLI and contract work use the [Thruput CLI and Cargo registry](cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Futurenet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.

<a id="build-a-complete-application"></a>

## Build a complete application

Follow the four-part [Build a counter](tutorials/build-a-counter.md) guide from contract to TypeScript, React, and a wallet-approved update. Each part builds on the project from the previous part.

For token and AMM contract projects, see [Guides](guides.md). New to the platform? Read the [Introduction](architecture.md) before choosing a path.
