<a id="_top"></a>

# Get Started

Source: <https://docs.groundhog.dev/get-started/>

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Choose a starting point for Groundhog contracts, applications, or coding agents.

Get a working result on Devnet. Choose the tools you want to use; you do not need to follow every path.

<a id="choose-your-path"></a>

## Choose your path

- **[CLI quickstart](get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](get-started/contract.md):** build and test a counter, deploy it to Devnet, and read its updated value.
- **[TypeScript quickstart](get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.

<a id="work-with-a-coding-agent"></a>

## Work with a coding agent

[Build with an Agent](start/build-with-an-agent.md) gives you two setup commands and one prompt for a complete counter application on Devnet. For a smaller task, use the prompt in an individual quickstart.

<a id="what-you-need"></a>

## What you need

CLI and contract work use the [Groundhog CLI and Cargo registry](cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Devnet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.

For a worked project, go to [Guides](guides.md). New to the platform? Read the [Introduction](architecture.md) before choosing a path.
