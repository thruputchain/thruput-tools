# Stellar Thruput documentation

Documentation source: `582945cad17772e51e67cf2cb7d0d7cf8f979b0d`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Get Started

Source: <https://thruput.network/get-started/>

Choose a starting point for Stellar Thruput contracts, applications, or coding agents.

Get a working result on Futurenet. Choose the tools you want to use; you do not need to follow every path.



## Choose your path

- **[CLI quickstart](pages/get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](pages/get-started/contract.md):** build and test a counter, deploy it to Futurenet, and read its updated value.
- **[TypeScript quickstart](pages/get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](pages/get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.



## Work with a coding agent

[Build with an Agent](pages/start/build-with-an-agent.md) gives you one prompt to install the tools, fund a wallet, and deploy and call a counter on Futurenet. For a smaller task, use the prompt in an individual quickstart.



## What you need

CLI and contract work use the [Thruput CLI and Cargo registry](pages/cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](pages/typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Futurenet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.



## Build a complete application

Follow the four-part [Build a counter](pages/tutorials/build-a-counter.md) guide from contract to TypeScript, React, and a wallet-approved update. Each part builds on the project from the previous part.

For token and AMM contract projects, see [Guides](pages/guides.md). New to the platform? Read the [Introduction](pages/architecture.md) before choosing a path.

---

## CLI quickstart

Source: <https://thruput.network/get-started/cli/>

Create a Futurenet wallet, request native test tokens, and inspect your first transaction from the terminal.

Create a wallet on Futurenet, fund it with native test tokens, and inspect the funding transaction. These tokens have no monetary value. You do not need a contract project or a local node.

**Before you start:** [install the latest CLI](pages/cli/install.md). Run these commands outside an existing Stellar Thruput project so they use your global configuration.



## 1. Set up the CLI

```bash
thruput init
thruput config use futurenet
```

On a fresh installation, accept signing-key creation and decline starter-project creation. Setup creates the `default` key and the `local` and `futurenet` network profiles. Selecting `futurenet` sets the global default, so later commands and new projects use it without a `--profile` flag.



## 2. Create a wallet

```bash
thruput wallet create
```

Confirm the prompt. The CLI saves a wallet address for your selected key. Creating this wallet does not fund it or send a transaction.

```bash
thruput wallet ls
```

You should see your wallet’s name and address. With a fresh setup, its name is `default`.



## 3. Request test funds

```bash
thruput airdrop
thruput balance
```

Confirm the airdrop and wait for its result. You should have a positive native-token balance. Save the transaction hash printed by the airdrop command.

The faucet selects the test-token amount; you do not need an amount flag. CLI output currently labels the native token `HOG`.



## 4. Inspect the transaction

Replace `TX_HASH` with the hash from the airdrop:

```bash
thruput tx show TX_HASH
```

Check that the transaction committed successfully. You now have a funded wallet and have verified an onchain result.



## Next

[Deploy your first contract](pages/get-started/contract.md) using this wallet.

If funding is pending, rerun the same airdrop command to resume the request. For network errors or faucet limits, see [Faucet](pages/tools/faucet.md).



## Use a coding agent

Copy this prompt into your agent:

```text
Help me complete the Thruput CLI quickstart:
https://thruput.network/docs/get-started/cli/
Use the latest CLI, install the thruput skill, and read thruput skill show cli.
Run thruput init, then thruput config use futurenet outside a project.
Set up a Futurenet wallet without creating a contract project or running a local node.
Preserve any existing keys and configuration. Request test funds,
check the wallet balance, and inspect the airdrop transaction.
Report success only after checking the committed transaction result.
Ask me to supply any required registry access through my environment,
not in this conversation. Report a network failure rather than bypassing it.
```

---

## Contract quickstart

Source: <https://thruput.network/get-started/contract/>

Create, test, and deploy a Rust counter contract to Stellar Thruput Futurenet.

Deploy a counter to Futurenet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](pages/get-started/cli.md) so you have the latest CLI and a funded Futurenet wallet. Keep your [Cargo registry access](pages/cli/install.md#configure-cargo-access) available in this terminal.



## 1. Create a contract

```bash
thruput new my-counter --template counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`.



## 2. Build and test

```bash
thruput build
thruput test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.

The generated project follows your global Futurenet selection. Check it with `thruput config get` before deploying.



## 3. Deploy to Futurenet

```bash
thruput deploy --estimate
```

Read the reported minimum funding in whole native tokens. Add **10 native test tokens** as this walkthrough’s storage allowance, then replace `TOTAL_FUNDING` below with that decimal total. The allowance is an example budget, not an estimate of initializer writes or a universal requirement. These tokens have no monetary value. See [deployment estimates](pages/cli/deploy-and-call.md#estimate-deployment-funding) for the breakdown.

```bash
thruput deploy --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
```

Confirm the deployment. Funding, deployment, and initialization happen atomically. The CLI prints the contract address and saves the alias `my-counter` in the project’s Futurenet profile. The sender also needs its own storage and scheduling capacity.



## 4. Change the counter

Increase the counter initialized during deployment:

```bash
thruput call my-counter increment 5
```

Confirm the call and wait for success. Do not initialize again: this example method adds the initial amount rather than enforcing one-time initialization.



## 5. Read the result

```bash
thruput view my-counter get
```

The result should be **15**. You have built, tested, deployed, and called a contract on Futurenet.



## Next

[Build a Counter](pages/tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](pages/contracts/project-structure.md).



## Use a coding agent

```text
Help me complete the Stellar Thruput contract quickstart:
https://thruput.network/docs/get-started/contract/
Use the latest CLI, install the thruput skill for this project, and read
thruput skill show contracts. Scaffold with --template counter. Check CLI setup and
Futurenet funding first. Scaffold my-counter, preserve its generated
dependency and compiler settings, then build and test it.
Read the deployment estimate and add the documented storage allowance to its
minimum. Deploy with that explicit total and initialize atomically to 10,
increment by 5, and verify that the view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```

---

## TypeScript quickstart

Source: <https://thruput.network/get-started/typescript/>

Connect to Futurenet and read the native-token contract with a typed TypeScript client.

Read the native token’s total supply from Futurenet with a typed contract call. This experimental token has no monetary value. This path needs Node.js and package access, but no CLI, signing key, or contract deployment.



## 1. Create a project

```bash
mkdir my-thruput-app
cd my-thruput-app
npm init -y
npm pkg set type=module
mkdir -p src
```

Configure [npm package access](pages/typescript/setup.md#give-npm-package-access) in this directory, then install the latest SDK and a TypeScript runner:

```bash
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
```



## 2. Read a contract

Create `src/index.ts`:

```ts
import { createThruputClient, devnet, formatUnits, getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";

async function main() {
  const client = await createThruputClient({ cluster: devnet() });
  const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
  const supply = await hog.totalSupply.view({ args: undefined });

  console.log("Native-token supply:", formatUnits(supply.value, 7));
  console.log("Read at block:", supply.height.toString());
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
```

`devnet()` selects the hosted network. The SDK includes the native-token contract’s standard binding, and `HOG_ADDRESS` is its protocol constant, so you do not need to generate a binding. `supply.value` is a typed integer; formatting it displays whole-token units rather than base units.



## 3. Run it

```bash
npx tsx src/index.ts
```

You should see **Native-token supply** and **Read at block**, each followed by a value. Run the command again to make another read. The values come from Futurenet and can change; there is no fixed expected block number.

This is a read-only call. It does not request wallet permission or submit a transaction.



## Next

Use [Read contract data](pages/typescript/reads.md) for arguments, caller context, and cancellation, or [Connect a wallet](pages/tools/wallet-integration.md) to add signing and transaction submission.



## Use a coding agent

```text
Build the Stellar Thruput TypeScript quickstart:
https://thruput.network/docs/get-started/typescript/
Use the latest published SDK packages and the hosted Futurenet.
Configure package access through my environment. Create the typed native-token
total-supply read shown in the guide and run it. Show the actual supply
and block height, or report the exact error if the request fails.
Do not install the Rust toolchain, deploy a contract, or create a wallet
for this read-only example. Keep the generated package lockfile.
```

---

## React quickstart

Source: <https://thruput.network/get-started/react/>

Display live Futurenet contract data in React with a typed query and a refresh action.

Build a React page that reads the native token’s total supply from Futurenet and refreshes it on demand. This experimental token has no monetary value. You do not need a wallet, the CLI, or your own contract.



## 1. Create the application

Use the current Node.js LTS release:

```bash
npm create vite@latest my-thruput-ui -- --template react-ts
cd my-thruput-ui
```

Configure [npm package access](pages/typescript/setup.md#give-npm-package-access) in this directory, then install the application dependencies:

```bash
npm install
npm install @thruputchain/react @thruputchain/client @thruputchain/protocol @tanstack/react-query
```



## 2. Connect the providers

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, devnet } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Futurenet…</p>);

async function start() {
  const client = await createThruputClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Futurenet"}</p>,
  );
});
```

The client and query cache are created once. `WalletProvider` makes the client available to Stellar Thruput hooks; it does not connect a wallet automatically.



## 3. Display the result

Replace `src/App.tsx`:

```tsx
import { formatUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    contract: HOG_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>Native token on Futurenet</h1>
      {supply.isPending && <p>Reading the contract…</p>}
      {supply.error && <p role="alert">{supply.error.message}</p>}
      {supply.data && (
        <>
          <p>Supply: {formatUnits(supply.data.value, 7)} native tokens</p>
          <p>Read at block: {supply.data.height.toString()}</p>
        </>
      )}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

The hook runs the typed view and exposes loading, error, and data states. Refresh makes another network read; it does not send a transaction.



## 4. Open the app

```bash
npm run dev
```

Open the local URL printed by Vite. The page should show a supply value and block height. Click **Refresh** and confirm that the page finishes another read. Also check that the project builds:

```bash
npm run build
```



## Next

See [Read contract data](pages/react/reads.md) for arguments and query behavior, or [Connect a wallet](pages/react/wallets.md) to add wallet controls. [Send transactions](pages/react/transactions.md) covers approval and execution state.



## Use a coding agent

```text
Build the Stellar Thruput React quickstart:
https://thruput.network/docs/get-started/react/
Use a React TypeScript Vite project, the latest published Stellar Thruput
packages, and hosted Futurenet. Configure package access through my environment.
Display the native-token total supply and its read height with useContractView.
Include loading and error states and a Refresh button. Run the build
and verify the actual page result. No CLI, contract deployment, or wallet
connection is needed for this read-only example. Report package or network
errors rather than forcing incompatible dependencies or faking results.
```

---

## Build with an Agent

Source: <https://thruput.network/start/build-with-an-agent/>

Give your coding agent one prompt to install the Thruput CLI, fund a wallet, and deploy and call a counter contract on Stellar Thruput Futurenet.

Paste this prompt into your coding agent. It will install the CLI and skill, read an exported copy of the docs, and build and verify a counter contract on Futurenet.



## Copy the prompt

```text
Help me deploy and use my first Stellar Thruput counter contract on Futurenet.

1. Install the latest Thruput CLI and run thruput init. Use
   thruput --help to see all available commands. Follow the installation
   instructions at https://thruput.network/docs/cli/install/.
2. Install the thruput skill for this project and coding agent with
   thruput skill install, then read the installed skill.
3. Export the documentation into a new folder with thruput docs export.
   Read its index and the relevant setup and contract instructions.
4. Outside a project, run thruput config use futurenet to select the global
   default. Create a wallet with thruput wallet create, then request test funds
   with thruput airdrop. Verify the balance before deployment.
5. Run thruput new counter --template counter, enter the project directory,
   and check thruput config get still selects futurenet. New projects inherit
   the global default. Build the contract and run its tests.
6. Deploy and initialize the counter to 10. Call increment with 5,
   then verify that its read-only view returns 15.

Finish with the project location, contract address, transaction hashes,
verified counter value, and the CLI commands I can use next.
```

The agent follows the [CLI](pages/get-started/cli.md) and [contract](pages/get-started/contract.md) quickstarts. Provide repository or registry access through your local environment when requested.

See [Skills and local docs](pages/cli/agent-tools.md) for installation requirements, agent selection, and Markdown export. For a smaller task, use the prompt in an individual [quickstart](pages/get-started.md).

---

## Introduction

Source: <https://thruput.network/architecture/>

Learn what Stellar Thruput is and how compatible updates let contracts share state.

Stellar Thruput is a moonshot project exploring how parallel execution can make compute abundant. Transactions record compatible changes to shared state, allowing the network to combine them without requiring sequential execution.

The project’s future is open. No decisions have been made about mainnet or its relationship to Stellar. These docs describe the development network and tools available today.

You write contract logic in Rust and connect applications through the TypeScript client or React library. The runtime combines changes using rules defined by the storage type.



## Record the change

Consider a counter with a value of `100`. Two transactions want to increase it, one by `5` and the other by `3`.

If each transaction replaces the value it read, they propose different results: `105` and `103`. With mergeable integer storage, they record the increases instead:

```text
Starting value:    100
Transaction A:     +5
Transaction B:     +3
Combined value:    108
```

These increases can combine if the rest of the transactions are compatible and network limits permit them. Neither transaction needs to calculate a replacement value that includes the other’s update.

This is useful for shared counters and balances. It does not make every operation independent: replacing a value, enforcing uniqueness, or choosing a winning order can require different rules. Your storage choices determine which changes can combine.

[Parallel Execution](pages/how-it-works/execution-model.md) explains how Stellar Thruput applies these rules. [Storage types](pages/programming-model/storage-types.md) shows how to use them in a contract.



## Build in two layers

**Contracts** define application rules and store onchain state. Use the Rust SDK to write and test them, and the CLI to build, deploy, and inspect them.

**Applications** read contract data and request transactions. The TypeScript client provides network and contract operations. The React library adds wallet connection and balance hooks for interfaces.

You can start with either layer. An application can use an existing contract without implementing one first.



## Where to start

Choose a path in [Get Started](pages/get-started.md) to write code. To explore the platform first, use the [System Overview](pages/how-it-works/architecture.md) as a map, then follow the [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) or read about [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).

---

## System Overview

Source: <https://thruput.network/how-it-works/architecture/>

How Stellar Thruput's public gateway, execution services, storage, and consensus coordinator fit together.

Stellar Thruput separates three responsibilities: serving applications, executing transactions and storing state, and agreeing on blocks. This page maps those responsibilities to the services that handle them.



## Components

```text
Applications and wallets
      |
      v
JSON-RPC gateway
      |
      +-- Reads
      |   State / Views / History
      |
   submits
      v
  Scheduler <--> Coordinator
      |               |
      |         Other validators
      |
      +-- Auth server
      +-- Executors <--> DB shards
      +-- Event server
```

The diagram shows the main service relationships. [Networking](pages/how-it-works/networking.md) covers registration and communication between them.

| Component                              | Responsibility                                                                                                      |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| **JSON-RPC gateway** (`groundhog-rpc`) | Accepts application requests, submits transactions to the scheduler, and routes reads to the relevant service       |
| **Scheduler / mempool** (`hogd`)       | Queues transactions, coordinates authorization, dispatches execution, and orchestrates block production and commits |
| **Auth server**                        | Checks transaction authorization claims and signatures before scheduling                                            |
| **Executors**                          | Run contract code and submit its state changes for reservation against the proposed block                           |
| **DB shards**                          | Serve state snapshots, enforce storage merge rules, and store committed state                                       |
| **Event server and indexer**           | Collect execution results and make transaction history, receipts, and events available for queries                  |
| **Coordinator** (`chuckd`)             | Drives consensus with other validators and asks the execution layer to propose, validate, and commit blocks         |





## Two paths through the gateway

**Transactions** enter through the gateway and reach the scheduler. The scheduler arranges signature checks, selects work, and dispatches it to executors. The execution layer produces a block proposal; the coordinator handles agreement with other validators.

**Reads** use the service appropriate to the request. State and balance queries use the database gateway, read-only contract calls use the view gateway, and receipt and event queries use the indexer. The scheduler supplies information such as the chain tip and pending transaction status.

The public gateway does not participate in consensus. Applications use its [JSON-RPC API](pages/reference/json-rpc-api.md) rather than the internal service interfaces.





## Execution and agreement

The execution layer determines what a proposed block would do. Contracts run against a shared snapshot and produce typed state changes. Executors and DB shards check which changes can be reserved together.

The coordinator drives agreement on which valid proposal to commit. It uses the Stellar Consensus Protocol (SCP); it does not run the contracts itself. Each validator checks the proposed result through its own execution layer before committing it.



Multiple execution workers and database shards distribute work within a node. Consensus coordinates agreement between validators. These are different responsibilities; adding execution capacity does not change the consensus rules.



## Explore the details

- [Parallel Execution](pages/how-it-works/execution-model.md): Snapshots, compatible updates, and conflict reservation
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): Submission, execution outcomes, and commit
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): Scheduling and storage deposits
- [Consensus](pages/how-it-works/consensus.md): Proposals, validation, and finality
- [Networking](pages/how-it-works/networking.md): Component registration and internal interfaces

For the behavior your contract relies on, read [Contract Execution](pages/programming-model/execution.md).

---

## Parallel Execution

Source: <https://thruput.network/how-it-works/execution-model/>

How the engine executes transactions against snapshots and reserves compatible state changes.



## The Core Idea

Every transaction reads from a consistent snapshot and records typed deltas. The storage type determines how those deltas combine.

Commutativity describes operations whose combined result does not depend on their order. Stellar Thruput still enforces resource limits, including gas limits, bounded return values, and a maximum encoded transaction size.

This page explains the engine: snapshots, concurrent reservation, and conflict selection. For the rules your code relies on, read [Contract Execution](pages/programming-model/execution.md).



## Snapshot Isolation

Each transaction sees the ledger as it was at the start of the block. All transactions in a block read from the same snapshot. Ordinary storage reads do not observe other transactions’ writes within that block.

Reads also reflect changes within the current transaction and successful child calls. The database snapshot analogy does not imply identical SQL isolation or conflict rules.

`RetrocausalQueue` also permits observations of concurrent inserts. These are recorded as nondeterministic proposal data and replayed by validators. Its read semantics differ from ordinary snapshot storage.



## Delta Writes

Transactions record typed operations: arithmetic deltas, value replacements, or deletions. Each storage type defines how those operations combine.

Instead of “set balance to 50”, a transaction says “increment balance by 10.” After each root contract call completes, the runtime reserves its delta batch alongside compatible deltas already admitted to the proposed block. The admitted deltas form the next state at commit.

In Solidity, a transfer looks like this:

```solidity
// Solidity: read balances and assign their updated values.
balances[from] = balances[from] - amount;
balances[to] = balances[to] + amount;
```

In Stellar Thruput:

```rust
// Stellar Thruput: write deltas. Two compatible transfers to the same
// account produce two deltas that merge cleanly.
balances.at_mut(&from).decrease(amount);
balances.at_mut(&to).increase(amount);
```

Two compatible increments to the same balance produce the same result regardless of order. `(x + 3) + 5 = (x + 5) + 3`. That is commutativity, and it is why Stellar Thruput can execute transactions in parallel without declared access lists.



## What Commutes and What Doesn’t

Transactions execute concurrently. Storage merge rules determine whether their changes can land together. A conflicting transaction is excluded from the proposal and returned to the mempool.

| Operation                               | Can both changes land? | Why                                                             |
| --------------------------------------- | ---------------------- | --------------------------------------------------------------- |
| Two balance changes on the same counter | When compatible        | Resolved bases must match and aggregate bounds must hold        |
| Two writes to different Map keys        | Yes                    | Independent keys don’t interact                                 |
| Two writes to the same bytestring       | When identical         | Different values conflict                                       |
| Multiple inserts into the same queue    | Yes                    | Entries are sorted; insertion order doesn’t matter              |
| Two deletions of the same key           | Yes                    | Same outcome regardless of order                                |
| A deletion and a write to the same key  | No                     | Different operation types conflict; one transaction is excluded |

These rules describe the listed operations. Other changes in either transaction can still cause a conflict.



### What This Means for Your Data Model

Choose storage around the changes your application needs to combine. Mergeable arithmetic still has bounds; absolute writes can coexist when they store identical values. [Storage Types](pages/programming-model/storage-types.md#choosing-a-type) turns these rules into contract-design choices.



## How Conflicts Are Resolved

The programming model describes a transaction as executing first and then attempting to land its deltas. The engine implements that boundary directly: ordinary storage conflicts are checked after the root contract call returns, before the transaction is committed into the proposed block.



### Concurrent Delta Reservation

Contract execution accumulates writes in the transaction’s `ItemView`. A checked operation such as `Balance::decrease(30)` first loads the snapshot base and can abort immediately if that transaction alone would underflow. A lazy operation skips that load and therefore cannot report a snapshot-bound failure from contract code. Both forms produce an NNInt delta.

After the root call returns successfully, `try_commit_transaction()` submits the transaction’s complete delta batch to hogd. For a lazy `NonnegativeIntAdd`, hogd resolves the set value from the block snapshot. A checked `NonnegativeIntSetAdd` already carries that same snapshot value. Both then use the same NNInt type-class match and aggregate bounds reservation.

For a snapshot balance of 10, the per-key reservation starts with subtraction capacity of 10:

```plaintext
Snapshot: Alice balance = 10
          Subtraction budget = 10

Tx A contract returns with delta -8
      Reserve delta batch: capacity 10 → 2 → admitted

Tx B contract returns with delta -5
      Reserve delta batch: capacity would be -3 → excluded
```

Whichever transaction reserves first wins. The lock is per-key, per-block and is initialized from the snapshot. Reservations on different keys use separate locks. Transactions touching the same key contend for the same aggregate bounds. Reservation can happen concurrently across executor workers; atomic capacity accounting ensures the combined admitted delta remains in range.

Compatible operations, such as two increases within the upper bound or two decreases within the available balance, can both reserve successfully. Checked and lazy operations share these merge rules. Checked operations can detect underflow in contract code; lazy operations leave that check to reservation. Credits from other transactions do not increase the snapshot’s subtraction budget. A lazy decrease cannot rely on another transaction’s same-block credit.



### What Block Close Does

By the time block close runs, all capacity conflicts have been resolved. Block close stages the already-finalized locks into a ChangeSet and computes the block hash. No conflict resolution happens at this stage for Balance, NNInt, Map, Value, or Bytestring operations.

RetrocausalQueue is the exception: it has end-of-block invariant checks that the other storage types do not. RCQ entries from excluded transactions are removed during block finalization.



The proposer records reservation-dependent outcomes so validators can replay and verify the proposed block. Contract code chooses storage operations; it does not manage the engine’s reservation locks.



## Related reading

- [Contract Execution](pages/programming-model/execution.md): The contract-author model
- [Storage Types](pages/programming-model/storage-types.md): API choices and merge rules
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): Gas limits, scheduling, and deposits

---

## Transaction Lifecycle

Source: <https://thruput.network/how-it-works/transaction-lifecycle/>

How a transaction moves from submission to committed state.

Submitting a transaction is the start of the process. A successful submission does not prove that the contract call succeeded. Check the committed receipt’s execution result.



## Outcomes to distinguish

| Outcome                       | What it means                                                                                                              |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Rejected before execution** | Admission or authorization failed; the transaction did not reach contract execution                                        |
| **Committed success**         | The transaction is in a finalized block and its contract changes were applied                                              |
| **Committed abort or fault**  | The failure is recorded in the block, but the contract changes are discarded                                               |
| **Excluded from a proposal**  | The transaction did not land in that proposal; conflicting transactions return to the mempool for possible later inclusion |

A pending or `unknown` status, a timeout, or an advisory `recentFailure` is not proof of a committed failure. Keep the original network and transaction hash, and resume observation instead of automatically signing a replacement. See [Track transaction results](pages/typescript/transaction-status.md) for the application workflow.



## Overview

A transaction passes through six stages:

1. **Submission**: Client submits a signed transaction
2. **Authorization**: Signatures are verified before the transaction enters the scheduling queue
3. **Scheduling**: The transaction is queued and selected for a block
4. **Execution and reservation**: Contract code runs against a snapshot, then its completed delta batch is reserved against the proposal
5. **Block Assembly**: The proposer packages results into a block proposal for consensus
6. **Commit**: Finalized state is written to storage



## Stage 1: Submission

The client signs the domain-separated preimage containing the network hash and inner transaction, then submits the signed wrapper through the JSON-RPC gateway. The network hash prevents replay on another Stellar Thruput network. The gateway submits directly to the hogd scheduler.



## Stage 2: Authorization

The mempool sends the transaction to the auth server, which verifies the root address, auth claim, and signatures. Pubkey claims use the public key embedded in the claim. Source-address claims use the root address’s registered authorization data. This happens before the transaction enters the scheduling queue, not during execution.

- If verification succeeds: the transaction enters the scheduling queue
- If verification fails: the transaction is rejected

See [Authorization](pages/how-it-works/authorization.md) for the signature preimage and admission models.



## Stage 3: Scheduling

Verified transactions are queued by account with balance-proportional scheduling. When the coordinator asks for a block proposal, the mempool selects transactions from accounts whose token-backed capacity has waited longest. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md) for how scheduling priority works.



## Stage 4: Execution

Selected transactions execute in parallel against a **consistent snapshot** of the ledger state. All transactions in a block read from the same snapshot taken at the start of block processing.

When contract code executes:

- It reads state values from the snapshot (via syscalls like `BytestringGet`, `NonnegativeIntGet`)
- Ordinary storage reads do not see writes from other transactions in the block; RCQ consumers can observe concurrent inserts
- It produces deltas describing how to modify state
- It runs until termination (return, abort, or fault)

**Conflict checking follows root execution.** If the root call succeeds, the executor submits its completed delta batch for reservation against the proposed block. An incompatible batch is excluded. Contract execution and reservation can both proceed concurrently across executor workers. See [Parallel Execution: How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the mechanism and the distinction between checked and lazy operations.

See [Invocation Frames](pages/how-it-works/invocation-frames.md) for detailed execution semantics (frame lifecycle, child calls, merge/discard rules).



### Root Frame Completion

When the root frame completes, the runtime checks its status:

- **Return (success)**: the transaction’s deltas are submitted for reservation. They are included only if the transaction remains admissible.
- **Deterministic Abort or Fault**: the failure can be included in the block with the contract’s writes discarded. Protocol bookkeeping, including replay protection, is still recorded. Once committed, this is a final execution result, not a transaction waiting to be retried.

This is distinct from **conflict exclusion** during reservation (Stage 4): the root frame may return successfully, but its completed delta batch can still fail reservation and be returned to the mempool for a future block. Deterministic abort and non-deterministic conflict exclusion are two different failure modes with different on-chain semantics.



## Stage 5: Block Assembly

The proposer packages the included transaction results into a consensus proposal: transaction hashes, nondeterministic execution data, and the computed block hash. The proposal is sent to validators via SCP. See [Consensus](pages/how-it-works/consensus.md) for how the proposer/validator split works.



## Stage 6: Commit

Once consensus confirms the block, each validator commits the verified result to its DB shards. The new ledger state becomes the snapshot for the next block.

Transactions excluded during delta reservation (Stage 4) are returned to the mempool and may be re-evaluated in future blocks, subject to scheduling and expiry. Committed aborts and faults remain in the block with their contract changes discarded.



## Related Documentation

- [Invocation Frames](pages/how-it-works/invocation-frames.md): Execution context
- [Authorization](pages/how-it-works/authorization.md): How signatures are verified
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Code hashes and deployment identities

---

## Compute, Capacity & Storage

Source: <https://thruput.network/how-it-works/storage-economics/>

How the native token provides scheduling capacity and refundable storage deposits without conventional gas fees.

Stellar Thruput has no conventional gas fees. Its native token backs onchain storage and provides scheduling capacity under load. The current experimental network’s native token has no monetary value.

Removing the sequential execution bottleneck is intended to make compute abundant rather than keep it scarce by design. Parallel execution does not remove hardware limits or contention: the network still meters computation and allocates capacity when demand exceeds it.





## The Two Jobs of the Native Token

Each unit of the native token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Locking native tokens for storage reduces the free balance available for scheduling.





## Execution: Metered, Throughput-Allocated

Running contract code has no conventional gas fee. It still uses finite execution and scheduling capacity, backed by the sender’s unlocked native-token balance.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

There is no unused-gas token refund. Metering does not debit or refund the sender’s native-token balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.



### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to unlocked native-token balances over time. If account A holds 1,000 unlocked native tokens and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s unlocked tokens sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, its declared gas limit determines how much token-backed capacity moves from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose capacity has waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

Tokens cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

Native tokens transferred between accounts enter the recipient’s scheduling queue as newly received capacity. They do not carry the sender’s accumulated scheduling age.



## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks native tokens according to the [storage type](pages/programming-model/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees native tokens for other storage or scheduling capacity.



### Cost Accounting

Every contract has a native-token balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts native tokens from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked native tokens to the contract’s free balance.

If an address does not have enough unlocked native tokens to cover a storage change, reservation can fail for insufficient funds. The transaction is excluded from that proposal and returned to the mempool. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.



### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.



### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.



## The Native Token

A sufficient first native-token credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](pages/typescript/accounts.md#request-devnet-funds).

The native token is implemented by a native precompiled contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting. Current tooling calls this token `HOG`; use the existing `HOG_ADDRESS` SDK constant and CLI token alias when writing code or commands.



## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.



## Related Documentation

- [Contract Execution](pages/programming-model/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](pages/how-it-works/execution-model.md): How compatible state changes are admitted
- [System Overview](pages/how-it-works/architecture.md): The component map
- [Storage Types Reference](pages/reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](pages/get-started/contract.md): Deploy your first contract

---

## Consensus

Source: <https://thruput.network/how-it-works/consensus/>

How SCP coordinates proposals, validation, and finalized blocks.



## Overview

Stellar Thruput uses the Stellar Consensus Protocol (SCP) for agreement. Each validator chooses **quorum slices**: sets of validators whose agreement it considers sufficient. Overlapping quorum slices allow validators to agree on a block.

Nomination uses a priority function to favor a proposed value in each round. Validators still need agreement under the configured quorum rules before finalizing a block.

SCP provides finality under its quorum-intersection and fault assumptions. Applications use the finalized block result rather than a probabilistic confirmation count.



## The Coordinator

Consensus is driven by the coordinator (chuckd), which is separate from the execution engine (hogd). The coordinator’s job is to get validators to agree on which block to commit. Contract execution and storage belong to the execution layer, orchestrated by the scheduler. See [System Overview](pages/how-it-works/architecture.md) for the component roles.

Each coordinator is configured with its own quorum set: the list of other validators it trusts for consensus. This peer configuration is managed by the coordinator, not the mempool. The mempool handles intra-node component registration (executors, DB shards, etc.); the coordinator handles inter-node consensus topology. This separation keeps execution concerns and agreement concerns independent.

It runs a state machine called the **baton** that drives the consensus loop.



## Block Production

The baton runs a drive loop after every event:

```plaintext
driveCommit()    →  Commit any externalized block
driveNominate()  →  Propose next block if idle
driveCatchup()   →  Fetch missing blocks from peers
driveLiveness()  →  Detect stuck consensus
```



### Single-Node Flow

On a single validator (e.g. during development):

1. Baton calls `propose_block` on the mempool. The execution layer runs queued transactions and assembles a proposal.
2. SCP externalizes immediately (single-node quorum).
3. Baton calls `commit` on the mempool. The execution layer commits the finalized proposal to storage.
4. Next drive cycle begins.



### Multi-Node Flow

With multiple validators:

1. **Propose.** A validator asks its mempool for a block proposal. The proposal contains the transactions and metadata.
2. **Disseminate.** The full consensus value (nomination + metadata) is broadcast to peers via Dogwood (see below). A compact hash reference (the “cue”) is sent through SCP.
3. **Validate.** Receiving validators ask their own mempool: “is this nomination valid against my state?” Validation runs asynchronously and results are cached.
4. **Converge.** SCP envelope exchange continues until validators agree. Agreement depends on quorum intersection and the configured trust assumptions.
5. **Commit.** Once SCP externalizes a value, each validator commits the block locally via its mempool.



### Execution During Block Production

The proposer and validators execute transactions differently.

**The proposer runs concurrent execution.** Transactions are fanned across multiple executors and coroutines in parallel. After a root call completes, NNInt capacity locks reserve its delta batch via atomic compare-and-swap (see [Parallel Execution: How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved)). Which transaction wins a contested lock depends on thread scheduling. This is non-deterministic: two runs of the same transaction set on the same machine can produce different winners.

**The proposer captures nondeterministic outcomes.** Each transaction produces a `NondeterministicProposalData` payload covering proposal-dependent decisions such as capacity reservation outcomes and retrocausal queue observations. This payload is packaged alongside the transaction hashes in the consensus proposal.

**Validators replay deterministically.** Validators receive the proposer’s nominated transaction list and the nondeterministic data. They reconstruct each transaction from their local mempool, pair it with the proposer’s captured decisions, and replay execution using those decisions as input. Validators do not re-run the concurrent race. They verify that the transactions produce the claimed state transitions, recompute the block hash, and confirm it matches.

|                       | Proposer                                                   | Validator                                 |
| --------------------- | ---------------------------------------------------------- | ----------------------------------------- |
| Execution             | Concurrent across executors                                | Deterministic replay with proposer’s data |
| Conflict resolution   | Non-deterministic thread race                              | Reproduced from captured decisions        |
| Transaction selection | Discretionary (from local mempool)                         | Fixed (from nomination)                   |
| Output                | Nomination: tx hashes + nondeterministic data + block hash | Accept or reject the nomination           |

The proposer has discretion over which transactions to include and which conflicting transaction wins. Validators verify the math of the proposed result, not the policy that produced it. Deterministic replay makes the proposed result verifiable. It does not establish proposer fairness; scheduling and transaction selection are separate from validating state transitions.



## Dissemination: Dogwood

Validators exchange three types of data during consensus:

| Data                 | Description                                                               |
| -------------------- | ------------------------------------------------------------------------- |
| **Transactions**     | Signed transactions gossiped between validators                           |
| **Consensus values** | Full block nominations (transactions + metadata)                          |
| **SCP envelopes**    | Protocol messages for agreement (nominate, prepare, confirm, externalize) |

Dogwood is the dissemination layer. It uses **erasure-coded multicast**: data is split into chunks, encoded with redundancy, and broadcast over BFS multicast trees. Receivers can reconstruct the original data from a subset of chunks, reducing bandwidth requirements while tolerating packet loss.

Each data type is tagged and demultiplexed on receipt. Transactions are forwarded to the mempool. Consensus values are cached locally for validation. SCP envelopes are fed to the embedded SCP kernel.



## Finality Model

Under the required quorum assumptions, loss of enough validators can stop progress without invalidating finalized blocks. Incorrect or disjoint trust configurations can violate those assumptions.

Practical implications:

- **No confirmation count.** A confirmed transaction is final. There is no “wait for 6 blocks” or “99.9% probability of finality.”
- **Finalized blocks.** Under the consensus safety assumptions, finalized blocks are not replaced by competing blocks.
- **Halt recovery.** If the network halts due to quorum loss, it resumes from the last committed block once enough validators return. Nodes may need to catch up before participating again.



## Catchup and Repair

Validators that fall behind (new nodes, network partitions, restarts) catch up by fetching missing blocks from peers. The catchup agent requests blocks by height, validates them, and replays them locally.

A separate repair agent handles missing data during active consensus: if a validator receives a hash reference it cannot resolve (a consensus value or SCP envelope it hasn’t seen), it requests the full data from the originating peer.



## Related Documentation

- [Networking](pages/how-it-works/networking.md): Node topology and how the coordinator connects to the mempool
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Parallel Execution](pages/how-it-works/execution-model.md): How transactions execute against snapshots
- [System Overview](pages/how-it-works/architecture.md): The component map

---

## Networking

Source: <https://thruput.network/how-it-works/networking/>

Node topology, component registration, and how transactions reach the mempool.

The [System Overview](pages/how-it-works/architecture.md#components) maps the main components. This page explains how they find each other and communicate.



## Topology

Stellar Thruput’s services are organized into an execution layer and a consensus layer.

The **coordinator** (chuckd, written in Go) sits above the execution layer. It drives consensus with other validators, manages peer topology, and tells the local mempool when to produce and commit blocks.

The **mempool** (scheduler, part of hogd) is the hub of the execution layer. All execution components register with it: executors, DB shards, event server, auth server. The mempool orchestrates block production, transaction execution, and state commits.

Separately, the **RPC gateway** (groundhog-rpc) provides external API access. It connects to the scheduler, indexer, database gateway, and view gateway but does not participate in consensus. It can be scaled independently of the validator.

Within the execution layer, no component discovers peers independently. The mempool is the registry for intra-node communication. When a component registers, it gets back the addresses of everything else it needs to talk to.

The coordinator manages inter-node consensus and transaction gossip using its configured peers and quorum sets. See [Consensus](pages/how-it-works/consensus.md) for how coordinators reach agreement.



## Component Registration

Components register their addresses and readiness with the scheduler. Most use an “intro” RPC; the event server uses a prepare/activate handshake. The scheduler waits for the required components before dispatching work.

Registration interfaces:

1. **DB shards** register via `scheddb_intro_shard`. Multiple shards can register (horizontal storage scaling).
2. **Event server** registers via `schedevent_prepare_event` and `schedevent_activate_event`. One per node.
3. **Executors** register via `schedexec_intro_exec`. Multiple executors can register (parallel transaction execution).
4. **Auth server** registers via `mempoolauth_intro_auth`. Handles transaction signature verification.
5. **Coordinator** registers via `schedulercoord_intro_coord`. Drives consensus and block production.

The listed execution-layer interfaces use XDR-RPC over TCP. Protocol definitions live in `.x` files (XDR IDL) and are compiled to C++ (hogd), Rust (groundhog-rpc), TypeScript, and Go bindings.



## The Mempool as Orchestrator

The mempool (scheduler) is more than a transaction pool. It orchestrates the block lifecycle:

- Receives client transactions directly from the RPC gateway and peer transactions from the coordinator
- Verifies transactions through the auth server
- Maintains per-account transaction queues with balance-proportional scheduling
- Assembles block nominations when the coordinator requests them
- Dispatches transactions to executors for parallel execution
- Collects execution results after executors have submitted their deltas to the database for reservation
- Notifies DB shards of state changes at commit

The coordinator requests proposals and commits. The scheduler coordinates the execution services that perform the work.



## Coordinator Connection

The coordinator (chuckd) is the consensus participant. It connects to the mempool and drives block production through these RPC calls:

| Call                            | Purpose                                           |
| ------------------------------- | ------------------------------------------------- |
| `schedulercoord_propose_block`  | ”Build a proposal for this block”                 |
| `schedulercoord_validate_block` | ”Is this peer’s proposed block valid?”            |
| `schedulercoord_commit_block`   | ”Finalize this block”                             |
| `schedulercoord_submit_vetted`  | Forward peer-gossiped transactions to the mempool |

The mempool also calls back to the coordinator via a reverse RPC channel to notify it when transactions pass vetting (triggering dissemination to peers).



## External Access

Clients submit transactions and query state through the public gateway.

**JSON-RPC gateway.** Exposes JSON-RPC 2.0 over HTTP and routes requests to the relevant execution-layer service. See [JSON-RPC API](pages/reference/json-rpc-api.md) for the method reference.

**Wallet integration.** Wallets sign transactions client-side and submit them through the JSON-RPC gateway. See [Wallet Integration](pages/tools/wallet-integration.md) for the application-facing flow.



## Transaction Flow

Client submissions reach the scheduler through the gateway; peer-gossiped transactions arrive through the coordinator. The coordinator then drives proposal, validation, and commit through the interfaces above. Follow [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) for the complete sequence and its possible outcomes.



## Related Documentation

- [Consensus](pages/how-it-works/consensus.md): How the coordinator reaches agreement with peers
- [Parallel Execution](pages/how-it-works/execution-model.md): How transactions execute against snapshots and produce deltas
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): The six stages from submission to commit
- [System Overview](pages/how-it-works/architecture.md): The component map

---

## For Blockchain Developers

Source: <https://thruput.network/start/for-blockchain-developers/>

Understand Stellar Thruput's storage and execution rules through a familiar token transfer.

The contract lifecycle is familiar: write, test, deploy, and call. The main changes are how storage updates combine and how execution and storage are funded. This page introduces those shifts using a Solidity transfer as the starting point.

***



## Token Transfers

A token transfer on Solidity:

```solidity
function transfer(address to, uint256 amount) public {
    require(balances[msg.sender] >= amount, "insufficient");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

The same transfer on Stellar Thruput:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The code stays familiar. `balances` is a `Map<ContractAddress, Balance>`. Calling `at_mut(address)` selects the balance that will change and returns a mutable handle. Selecting it does not load the balance.

`decrease(amount)` loads the sender’s snapshot balance because the contract needs to fail immediately when funds are insufficient. `lazy_increase(amount)` skips the receiver load because the contract does not need an immediate overflow result. Its bound is checked when the transaction’s completed delta batch is admitted. Both calls produce deltas that can merge with compatible transactions. `Balance` accepts only nonnegative amounts and exposes no absolute `set` operation.

[Build a Token](pages/tutorials/build-a-token.md) uses this pattern in a complete contract. [Merged Deltas](pages/programming-model/execution.md#merged-deltas) explains how Stellar Thruput combines changes across a block.

***



## Reentrancy and Balance Checks

`Balance::decrease` checks the transaction’s current balance view. The runtime also checks aggregate bounds when concurrent deltas are reserved. This does not replace authorization or application-specific checks.

Contract calls also have different reentrancy rules from the EVM. See the [EVM reentrancy comparison](pages/ecosystem/evm.md#reentrancy) for that call pattern, and [Authorization](pages/how-it-works/authorization.md) for caller checks and signed permissions.

***



## Resource and Transaction Rules

Stellar Thruput exposes these rules to contract developers:

- **Gas price estimation.** Gas limits exist for metering, but gas costs zero. The declared gas limit still consumes scheduling capacity.
- **Ordering-sensitive balance updates.** Commutative balance deltas have the same merged outcome in any execution order. Application flows that conflict still need protocol-aware design.
- **Nonces.** Replay protection uses a unique expiry-height and nonce pair, without a sequential account counter.
- **Access lists.** Stellar Thruput discovers storage access during execution. Compare [Solana account declarations](pages/ecosystem/solana.md#access-lists-vs-type-based-parallelism) with Ethereum’s optional [EIP-2930 access lists](https://eips.ethereum.org/EIPS/eip-2930).
- **Storage slot packing.** Typed fields via `#[sdk::storage]`. No manual layout, no packing variables into 256-bit slots.
- **TTL management.** No storage expiry. Data persists as long as its native-token deposit is held. Delete the data, get the deposit back.

***



## The Programming Model in Brief

Choose operations that express the change you intend. Use `Balance` for ordinary balance adjustments, `Map` for separate records, and other storage types when the application needs different merge rules. Compatible arithmetic can combine, but ordering-sensitive workflows still need an explicit design.

[Contract Execution](pages/programming-model/execution.md) explains snapshots and deltas. [Storage Types](pages/programming-model/storage-types.md) covers the available APIs, and [NNInt and concurrent updates](pages/programming-model/nnint.md) covers the lower-level integer model.

***



## Storage Choices and Parallelism

The transfer example uses relative balance adjustments so compatible transfers can share a block. Replacing those adjustments with absolute values changes the conflict rules. Review your data model, not just the syntax, when adapting an existing contract.

***



## Next Steps

Continue in layers:

1. [Contract quickstart](pages/get-started/contract.md) builds and deploys your first contract.
2. [Build a Token](pages/tutorials/build-a-token.md) applies checked and lazy balance operations in a complete ERC-20-style contract.
3. [Contract Execution](pages/programming-model/execution.md) and [Storage Types](pages/programming-model/storage-types.md) give the full contract-author model.
4. [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) explains the engine’s reservation machinery.

For a detailed mapping from Solidity to Stellar Thruput, see [EVM & Solidity](pages/ecosystem/evm.md).

---

## EVM & Solidity

Source: <https://thruput.network/ecosystem/evm/>

Translate Solidity contract patterns into Stellar Thruput storage, calls, and authorization.

The contract lifecycle remains write, test, deploy, and call. The main differences are typed storage updates, the call runtime, and resource accounting. This page compares those mechanisms, not network performance.



## The Contract Lifecycle



| Task       | Stellar Thruput path                                                     |
| ---------- | ------------------------------------------------------------------------ |
| Write      | Rust with SDK storage handles and contract macros                        |
| Compile    | `thruput build` produces an RV32 artifact and contract-spec sidecars     |
| Deploy     | Fund the new contract’s storage and deploy with the CLI or wallet client |
| Initialize | Call an ordinary method, optionally atomically through `deploy --init`   |
| Call       | Use generated Rust or TypeScript bindings                                |
| Read       | Use a typed view through the public client or `thruput view`             |

Stellar Thruput entrypoints use 8-byte IDs and CXS arguments. Ethereum contract calls commonly use a 4-byte selector and ABI arguments; see [Ethereum transactions](https://ethereum.org/en/developers/docs/transactions/). Use bindings rather than constructing either encoding manually.

Stellar Thruput deployment addresses derive from the deployer, nonce, and code hash. This resembles `CREATE2` in allowing address prediction, but uses a different preimage. See [Contract artifacts and addresses](pages/how-it-works/contracts.md).



## Mental Model Shifts

| Solidity / EVM pattern               | Stellar Thruput pattern                                                                                |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| Mapping of token balances            | `Map<ContractAddress, Balance>`                                                                        |
| Read-modify-write balance assignment | Checked or lazy relative balance changes                                                               |
| `require` or `revert`                | `ensure` or a typed contract exception                                                                 |
| `msg.sender`                         | `get_caller()`, the immediate caller                                                                   |
| Constructor                          | An ordinary initializer with a contract-defined guard                                                  |
| Solidity interface and ABI           | Shared Rust interface and generated contract spec                                                      |
| `view` / `pure`                      | Rust receiver choice does not enforce runtime read-only behavior; use the call’s read-only restriction |



## Execution Differences



### Reentrancy

An EVM external call can call back into a contract already on the stack; see [Solidity external calls](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls).

Stellar Thruput rejects invocation of a contract already on the call stack. For A → B → A, the last call is rejected as reentrant. This runtime check is separate from snapshot isolation. Reads within a transaction can still observe its own earlier changes and successful child calls.

Use [recoverable calls](pages/contracts/cross-contract-calls.md#error-handling) when the parent should inspect a child failure rather than propagate it.



### Ordering and MEV

Compatible arithmetic changes have the same merged value regardless of execution order. Conflicting operations do not all land together, and the proposer still selects transactions and conflict winners. This is not a guarantee that every application is free from ordering-dependent outcomes or MEV.



### Gas Limits and Gas Price Estimation

Ethereum transactions specify gas limits and fee parameters. Stellar Thruput gas meters execution but costs zero tokens, so no gas price estimation is needed. Gas usage still matters: the declared root limit consumes scheduling capacity, and exceeding it faults execution.

Unlocked native-token balances provide capacity; stored data requires separate deposits. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).



### Nonce Management

Ethereum account transactions use a sequential nonce. Stellar Thruput replay protection uses an expiry-height and nonce pair, unique for the originating address. It need not increase sequentially. That permits independent transactions from one address without a sequential account counter.



### Integer Overflow/Underflow

`Balance` accepts nonnegative amounts. Its checked methods reject underflow or overflow during execution; lazy methods defer snapshot-bound checks to reservation. The runtime also enforces aggregate bounds across concurrent transactions.



### The `approve()` Race Condition

An absolute allowance replacement can grant new spending authority after the previous allowance has already been spent. The example Stellar Thruput token instead uses relative allowance adjustments. The caller requests an increase or decrease, not a replacement amount.

This does not remove the need to inspect outcomes or choose an authorization policy. See the [token implementation](pages/tutorials/build-a-token.md#apply-supply-and-allowance-policy) for its exact allowance methods and exclusive-update option.



## Pattern Adaptations



### Balance Transfer

In a token implementation, use balance deltas:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution. The lazy credit skips a balance load and defers its bound check. Other changes and resource limits still determine whether complete transactions can land together.



### Access Control

Store an owner or role policy and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Define `Error` with `#[contract_exception]`. A forwarding contract becomes the immediate caller; it does not inherit the original user’s identity. See [Authorization](pages/how-it-works/authorization.md).



### Constructor and Initialization

Stellar Thruput does not invoke `initialize` automatically or make it once-only. Guard initialization in contract storage when required. The CLI’s [atomic initialization](pages/cli/deploy-and-call.md#include-initialization) combines funding, deployment, and the initializer call.



### Events

Define events with `#[derive(Event)]`, mark filterable fields with `#[topic]`, and declare emitted types on the contract interface. See [Events](pages/contracts/events.md) for the complete pattern and [Read events](pages/typescript/events.md) for application queries.



[Build a token](pages/tutorials/build-a-token.md) walks through the maintained ERC-20 implementation, including allowances, supply policy, events, and tests.



## What Doesn’t Exist

| EVM feature                               | Stellar Thruput approach                                    |
| ----------------------------------------- | ----------------------------------------------------------- |
| `msg.value`                               | Transfer tokens explicitly through their contract interface |
| `delegatecall` and proxy code replacement | Deploy a new immutable contract at a new address            |
| `selfdestruct`                            | No equivalent contract-removal operation                    |
| Solidity `receive` / `fallback` dispatch  | Use declared methods in the generated SDK dispatcher        |
| Storage-slot packing                      | Use typed storage paths                                     |

Block context and gas inspection do exist: `get_block_timepoint()`, `get_block_height()`, and `stats::gas_remaining()`. Artifact and transaction bounds are network constraints, not EVM limits; see [Contract artifacts](pages/how-it-works/contracts.md).



## Next Steps

- [Contract quickstart](pages/get-started/contract.md): build and deploy a counter
- [Build a token](pages/tutorials/build-a-token.md): maintained token code and tests
- [Contract Execution](pages/programming-model/execution.md): snapshots and deltas
- [Storage Types](pages/programming-model/storage-types.md): choose a storage API

---

## Solana & Anchor

Source: <https://thruput.network/ecosystem/solana/>

Translate Solana account, storage, and CPI patterns into Stellar Thruput contracts.

Both ecosystems support Rust contract development. Stellar Thruput changes how a contract addresses state and how concurrent writes combine. The comparison below follows Solana’s [account model](https://solana.com/docs/core/accounts) and [CPI rules](https://solana.com/docs/core/cpi).



## Accounts vs. Storage

Solana state lives in accounts with an address, owner, lamport balance, and data. Instructions receive declared accounts; Anchor expresses their expected types and constraints.

Stellar Thruput stores typed fields under contract addresses. For example, a token implementation uses `Map<ContractAddress, Balance>` rather than receiving separate token-account objects for each balance. Contract code still checks caller authority and application rules.



## Access Lists vs. Type-Based Parallelism

Solana transactions declare account access before execution. The runtime uses read/write access to schedule work; transactions that contend for a writable account cannot execute together in that schedule.

Stellar Thruput discovers storage access during execution. Typed merge rules allow compatible changes to the same location to combine. Different map keys use separate locations, but other shared writes and storage-funding limits can still conflict.



## The Contract Lifecycle



### Writing

| Anchor concept                    | Stellar Thruput SDK concept                                                  |
| --------------------------------- | ---------------------------------------------------------------------------- |
| `#[program]`                      | `#[contract]` on an interface or implementation                              |
| Account-data structure            | Typed fields under `#[sdk::storage]`                                         |
| `#[derive(Accounts)]` constraints | Explicit argument and authorization checks; no caller-supplied account array |
| Initialization instruction        | Ordinary initializer, optionally called atomically with deployment           |



### Compiling

Solana programs compile to SBF. Stellar Thruput contracts compile to RV32 through:

```bash
thruput build
```

The build produces a deployable artifact and contract spec. Keep the generated toolchain and dependencies together.



### Deploying

Stellar Thruput deployment derives an address from the deployer, nonce, and code hash. This shares a PDA’s predictability, not its derivation or authorization model. See [Contract artifacts and addresses](pages/how-it-works/contracts.md).



### Calling

Use a generated client for another contract:

```rust
let token = ERC20Client::new(&token_address);
token.transfer(&recipient, amount);
```

The receiver sees the calling contract as its immediate caller. [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) covers gas limits and recoverable errors.



## Mental Model Shifts

| Solana / Anchor pattern              | Stellar Thruput pattern                                          |
| ------------------------------------ | ---------------------------------------------------------------- |
| Per-user state account               | Often a `Map` entry under the contract                           |
| Serialized account data              | Typed storage handles                                            |
| Account-level write conflicts        | Storage-type merge rules, including compatible shared-key deltas |
| Rent-exempt storage balance          | Storage deposit backed by native tokens                          |
| Compute-unit budget                  | Gas limit, with no token fee for gas                             |
| Signer privileges passed through CPI | Immediate caller identity and explicit runtime auth tokens       |



## Account and Call Patterns



### Account Arrays and Validation

Stellar Thruput has no caller-supplied account array. That removes account-list construction, not authorization. Validate caller identities, contract addresses, amounts, and application conditions before applying changes.



### Rent and Account Lifecycle

Solana accounts hold a refundable minimum lamport balance for their storage. Stellar Thruput storage also requires funding: it locks native tokens according to the data’s type and size, and releases the deposit when data is deleted. The runtime accounts for it, but the owning address must have enough funds.



### Compute Unit Budgets

Stellar Thruput gas limits bound computation, including child calls. Gas costs zero tokens, but a root transaction’s declared limit consumes scheduling capacity. Account funding and execution bounds still matter. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).



### PDA Seed Management

A PDA used only for per-user state often maps to a `Map` entry. A PDA used as an authority needs an authorization design as well; replacing its storage with a map does not reproduce its signing role.



### Signer Propagation in CPIs

Solana CPI passes existing signer and writable privileges to the callee. `invoke_signed` additionally supplies seeds when the calling program must authorize a PDA. Ordinary CPI does not always require signer seeds.

Stellar Thruput’s `get_caller()` returns the immediate calling contract, not the root signer. Use contract policy, allowances, or [typed auth tokens](pages/how-it-works/authorization.md#auth-tokens-and-signedt) when authority must pass through several calls.



## Pattern Adaptations



### PDA State Accounts → Map Fields

```rust
#[sdk::storage]
pub struct Registry {
    user_states: Map<ContractAddress, Value<UserState>>,
}
```

`UserState` is your serializable application type. Access an entry with `at` or `at_mut`; first writes create storage and require its deposit. See [Storage Types](pages/programming-model/storage-types.md).



### Token Transfer

Inside a token implementation:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

This updates the token’s own balance map. To transfer another contract’s token, call its generated client rather than writing its storage directly.



### Cross-Program Invocation → Cross-Contract Call

```rust
let token = ERC20Client::new(&token_address);
let result = token.try_mint(&recipient, amount);
```

The callee applies its own authorization policy. `try_mint` returns a `Result`; the direct `mint` method propagates failure. See [Handle errors](pages/contracts/errors.md).



### Error Handling

Define errors with `#[contract_exception]` and check conditions with `ensure`:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Unlike signer-account validation, this checks the immediate contract caller. A failure aborts the frame and discards its contract effects.



## What Doesn’t Exist

Stellar Thruput does not use Solana account arrays, associated token accounts, PDA bump seeds, or account `space`/`realloc` arguments. It has its own contract-address, storage, and authorization models. These are pattern translations, not wire or tooling compatibility.



## Next Steps

- [Contract quickstart](pages/get-started/contract.md): build and deploy a counter
- [Build a token](pages/tutorials/build-a-token.md): token state and tests
- [Storage Types](pages/programming-model/storage-types.md): map and balance APIs
- [Authorization](pages/how-it-works/authorization.md): caller and auth-token rules

---

## Stellar & Soroban

Source: <https://thruput.network/ecosystem/stellar/>

Translate Stellar operations and Soroban contract patterns into Stellar Thruput applications.



## Who This Guide Is For

For Stellar developers, distinguish classic operations from Soroban contracts before comparing either with Stellar Thruput. Stellar Thruput exposes contract calls and typed storage; payment, trust, and exchange policy belongs in contracts.



## Mental Model Shifts

| Starting point                        | Stellar Thruput approach                              |
| ------------------------------------- | ----------------------------------------------------- |
| Classic payments and token operations | Call a token contract                                 |
| Account trustlines and asset policy   | Implement or select a contract’s authorization policy |
| Multiple classic operations           | Compose calls in one transaction                      |
| Built-in offers and path payments     | Use an application-defined exchange                   |
| Soroban storage get/set               | Choose typed storage operations and their merge rules |

These are design translations, not compatibility claims. Stellar Thruput does not automatically provide Stellar’s asset or trustline semantics.



## Pattern Translations



### 1. Simple Payments

Classic Stellar provides a payment operation. A Stellar Thruput token implementation updates typed balances:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution; the lazy credit records a relative change. Compatible transactions can merge if aggregate bounds and their other changes permit it. See [Build a token](pages/tutorials/build-a-token.md) for the complete implementation and events.



### 2. Multi-Operation Transactions

[Classic Stellar transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions) can bundle operations atomically. Soroban transactions contain a single smart-contract operation, which can invoke other contracts.

A Stellar Thruput transaction has one root invocation. That invocation can call several contracts. The native DefaultWallet and its SDK helpers also support [atomic typed call batches](pages/typescript/transactions.md#execute-multiple-calls).

If the root aborts, its contract changes and successful child changes are discarded. A parent using recoverable calls can instead handle a child’s failure and continue. See [Invocation Frames](pages/how-it-works/invocation-frames.md).



### 3. Market Making / Resting Orders

Stellar Thruput has no built-in order book. A contract can store orders by ID in a `Map`, or accept requests through a `RetrocausalQueue`.

Separate order IDs have independent storage locations. Changes to the same order follow its value type’s merge rules. A queue allows concurrent insertion and later ordered processing. Choose according to the venue’s matching and settlement rules.



### 4. DEX Trading / Swaps

Two designs are possible:

- **Synchronous calls:** execute a swap and return its result in one transaction. Reserve-dependent writes to the same pair can conflict.
- **Queued requests:** accept a request first, then process it in a later transaction. The client tracks a request ID through outcome events or stored state.

The maintained [AMM example](pages/tutorials/build-an-amm.md) uses the queued design. Request acceptance is not proof that the swap completed. A synchronous result refers to execution within a transaction, not immediate network confirmation.



### 5. Account & Trust Management

A Stellar Thruput contract can store per-account policy in a map, but a stored trust flag has no effect unless the token or application checks it.

Use [caller checks and auth tokens](pages/how-it-works/authorization.md) to enforce the policy. Use [account authorization](pages/typescript/wallet-clients.md) for signatures that can originate transactions. These are separate responsibilities.



### 6. Soroban Smart Contracts

Both environments support Rust contracts, with different storage and authorization APIs:

| Soroban                                     | Stellar Thruput                                                                           |
| ------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `persistent().get/set`                      | Typed handles such as `Value<T>`, `Map<K, V>`, and `Balance`                              |
| Instance, Persistent, and Temporary storage | One persistent storage model with type-specific operations                                |
| Storage TTL and archival/restoration        | No storage TTL; funded data remains until deleted                                         |
| `require_auth()`                            | Immediate-caller checks or explicit runtime auth tokens, according to the contract policy |
| `#[contractimpl]`                           | `#[contract]` on a Rust interface or implementation                                       |
| Inclusion and resource fees                 | No conventional gas fees; native-token-backed scheduling and storage                      |

Soroban TTL expiry is not the same for every storage type: Temporary data is deleted, while Persistent and Instance entries are archived and can be restored. See [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival).

Stellar Thruput’s storage types determine which concurrent changes can combine. Use [Contract Execution](pages/programming-model/execution.md) for snapshots and [Storage Types](pages/programming-model/storage-types.md) for API choices.



## Pattern Summary

| Pattern                 | Design decision                                                         |
| ----------------------- | ----------------------------------------------------------------------- |
| Payments                | Select the token contract and its transfer policy                       |
| Resting orders          | Choose keyed storage, a queue, or both                                  |
| Trust and authorization | Store policy and enforce it on every relevant action                    |
| Swaps                   | Choose synchronous execution or accepted requests with later settlement |
| Client recovery         | Track transaction hashes and, for queued work, request outcomes         |



## What Doesn’t Change

Applications still need to validate amounts, choose the intended network, authorize writes, and inspect outcomes. A successful submission is not successful execution on either platform.



## Common Questions



### Q: Do I lose atomicity for multi-op transactions?

No. Calls can execute atomically inside one root transaction. A workflow split across several transactions, such as queue acceptance and later settlement, needs application-level outcome tracking.



### Q: When should I use a queued DEX model?

Use it when concurrent request submission and later processing fit the venue. Use a synchronous call when the caller needs the swap result during the same transaction.



### Q: Will my market making bot need major changes?

The venue determines that. A queued venue requires the bot to connect accepted request IDs with later outcomes. It must not treat a successful processing transaction as proof that every queued request succeeded.



## References

- [Stellar operations and transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions)
- [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival)
- [Contract quickstart](pages/get-started/contract.md)
- [Build a token](pages/tutorials/build-a-token.md)
- [Build an AMM](pages/tutorials/build-an-amm.md)

---

## For Backend Developers

Source: <https://thruput.network/start/for-backend-developers/>

Map your Postgres and database experience to Stellar Thruput's programming model.

Database snapshot isolation is a useful starting point for Stellar Thruput. Transactions share a committed block snapshot, but their writes follow typed storage merge rules rather than SQL conflict rules.



## Shared Snapshot

Every transaction in a block starts from the previous block’s committed state. Ordinary storage reads include its own changes and successful child calls, but not other transactions’ writes. `RetrocausalQueue` has separate rules for observing concurrent inserts. Each transaction produces typed changes, called **deltas**. Compatible deltas form the next committed state. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas).



## Deltas, Not Assignments

The core shift from a database: instead of `UPDATE accounts SET balance = 50`, you call `increase(5)`, meaning “adjust this value by +5.” This is `UPDATE accounts SET balance = balance + 5`. You express **how the value should change**, not what it should become.

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);          // checked debit
    self.balances.at_mut(receiver).lazy_increase(amount);    // deferred bound check
}
```

[`Balance`](pages/programming-model/storage-types.md#balance) is the SDK type for this pattern. Both calls record deltas that can merge with concurrent transactions. `decrease()` loads the sender’s balance so an insufficient debit fails during execution. `lazy_increase()` skips the receiver load and defers its bound check until the delta batch is reserved. If two transactions debit 20 and 30 from a balance of 100, both can land and the next balance is 50. Applying the changes in either order gives the same result, so the operations **commute**.

[NNInt and concurrent updates](pages/programming-model/nnint.md) explains the representation behind these balance operations, including base matching and early bound checks.

**Relative updates such as `SET col = col + ?` map naturally to mergeable integer operations.** Compatibility still depends on bounds and the transaction’s other changes. Absolute replacements can conflict when they assign different values.

***



## Conflicts and the Mempool

When deltas conflict, the transaction is excluded and returned to the mempool for possible inclusion in a later block. Contract code does not retry the operation. Clients still need to track confirmation and transaction expiry.

The balance constraint works the same way. If two concurrent withdrawals together exceed the available balance, one or more transactions are excluded. This is `CHECK (balance >= 0)` enforced by the storage model rather than application code.

***



## What’s Different From a Database

- **No ad-hoc queries.** Storage is key-value with typed values. You access data by key, not by query. An indexer provides query capabilities off-chain.
- **No JOINs.** If you need data from two Maps, you read both explicitly.
- **Deterministic execution.** Use block context rather than the host clock. Contract code cannot make HTTP calls or use the host’s random-number generator.
- **Storage deposits.** Stored data locks native tokens according to its type and size. Deleting the data returns the deposit.
- **No conventional gas fees.** Gas meters computation (prevents infinite loops) but no tokens are burned. Your unlocked native-token balance provides scheduling capacity under load. The declared gas limit determines how much capacity the transaction uses.

***



## Next Steps

For storage type details (`Balance`, `NNInt`, `Map`, `Vector`, `Value`, `Bytestring`, `CapacityConstraint`, and `RetrocausalQueue`) and their conflict semantics, see [Programming Model: Storage Types](pages/programming-model/storage-types.md). For the contract-level execution model, see [Merged Deltas](pages/programming-model/execution.md#merged-deltas).

Ready to write code? The [contract quickstart](pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## For Distributed Systems Developers

Source: <https://thruput.network/start/for-distributed-systems-developers/>

Understand Stellar Thruput's use of commutative updates within consensus blocks.

Stellar Thruput uses commutative operations to combine concurrent changes within a block. The storage model supports parallel execution; consensus selects the result validators commit.



## Your Head Start

Additions such as `+5` and `+3` have the same sum in either order. Stellar Thruput’s [`Balance`](pages/programming-model/storage-types.md#balance) and [`NNInt`](pages/programming-model/nnint.md) expose relative updates with explicit bounds. `Map<K, V>` gives separate keys independent storage locations.

The similarity to counters and maps in CRDT systems is useful, but the coordination model differs.



## Coordination at Block Boundaries

CRDTs can reconcile independently updated replicas. Stellar Thruput instead executes transactions against a common committed snapshot, reserves compatible typed changes, and uses [consensus](pages/how-it-works/consensus.md) to select a finalized block.

- **Merge rules operate within a proposal.** Applications do not maintain vector clocks to reconcile ordinary balance or map updates.
- **Bounds still apply.** A balance cannot commit below zero. If concurrent debits exceed the available value, an overdrawing transaction is excluded and returned to the mempool.
- **Consensus selects one result.** Validators verify the proposed state transition. Nodes that have applied the same finalized block agree on that state.
- **Readers can see different heights.** A node may lag while receiving or replaying blocks. Check the returned read height when freshness matters.



## If You Don’t Know Any of This

You can write contracts without implementing a concurrency algorithm. Choose the storage type for the updates your application needs, then use its ordinary Rust methods. The [backend-developer guide](pages/start/for-backend-developers.md) explains the same model through database concepts.



## Next Steps

- [Contract Execution](pages/programming-model/execution.md): snapshots, deltas, and exclusion
- [Storage Types](pages/programming-model/storage-types.md): data-model choices
- [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved): engine reservation details
- [Contract quickstart](pages/get-started/contract.md): build and deploy a counter

---

## Thruput roadmap

Source: <https://thruput.network/architecture/roadmap/>

Candidate improvements, open questions, and ways to help shape Stellar Thruput.

These are candidate improvements to Stellar Thruput, roughly ordered by what they could unblock. The order is provisional. Scope and priorities can change as people build on Futurenet; there are no committed delivery dates.

Last reviewed: October 13, 2026.



## Proposed next work



### Block and transaction history

Public block queries and recoverable transaction feeds would let explorers and independent indexers discover chain activity without private infrastructure access. Block queries remain incomplete; the supported feed and its recovery contract still need qualification. Indexer requirements and tests for resuming after an outage would help.



### Contract failure diagnostics

Failures inside wallet or other nested contract calls can be difficult to locate. The goal is to preserve which call failed and provide more useful runtime fault details through the [public API](pages/reference/json-rpc-api.md). Small contracts that reproduce difficult failures are useful contributions.



### State preserving upgrades

Supported upgrade paths and migration tooling would reduce the need to recreate applications after network changes. This work is deferred. Futurenet can still reset, as described in [Get Started](pages/get-started.md). Upgrade fixtures, compatibility tests, and operator feedback would help define the supported paths.



## Exploring



### Post quantum readiness

Thruput’s authorization model already supports multiple keys per address and is designed to accommodate multiple cryptographic key types. Ed25519 is the currently supported scheme. We’re evaluating post-quantum options and their performance impact. The migration design also needs to cover account and validator keys. Threat-model, performance, and migration-design reviews would help.



## Open to builders



### Ecosystem tooling

Wallet integrations, oracles, and application conventions are areas where builder demand can shape the work. The [wallet integration guide](pages/tools/wallet-integration.md) is a starting point. Bring an integration or application that exposes a concrete need, and find related projects through the [GitHub community](https://github.com/thruputchain).

---

## CLI

Source: <https://thruput.network/cli/>

Install the Thruput CLI, configure networks, and build, test, deploy, and call contracts.

`thruput` is the command-line tool for working with Stellar Thruput projects and networks. Use it to create a project, build and test a contract, run a local node, or interact with a deployed contract.



## Projects and networks

The CLI works with two kinds of configuration:

- A **project** contains your Rust contract, tests, and build settings.
- A **profile** selects the network and identity used for an interaction.

This lets you build a contract once and use profiles to target a local node or Futurenet. You can also use network commands without creating a contract project.



## The development loop

| Task                        | Command          |
| --------------------------- | ---------------- |
| Create a contract project   | `thruput new`    |
| Build a contract artifact   | `thruput build`  |
| Run contract artifact tests | `thruput test`   |
| Start a local node          | `thruput node`   |
| Deploy a contract           | `thruput deploy` |
| Call a deployed contract    | `thruput call`   |

These are command names, not a setup script. Start with [installation](pages/cli/install.md), then follow the [CLI quickstart](pages/get-started/cli.md) for a first Futurenet interaction.

The [contract quickstart](pages/get-started/contract.md) adds deployment and calls. Use [Run a local node](pages/cli/local-node.md) when you want a disposable node on your machine.



## Look up an option

Run `thruput <command> --help` for the installed version’s options, or use the [command reference](pages/cli/reference.md). [Profiles and networks](pages/cli/configuration.md) explains profile selection and project overrides.

Use [Skills and local docs](pages/cli/agent-tools.md) to install agent guidance, read bundled references, and serve or export documentation. [Build with an Agent](pages/start/build-with-an-agent.md) combines setup with a first-project prompt.

---

## Install the CLI

Source: <https://thruput.network/cli/install/>

Install the latest Thruput CLI and prepare Cargo access for contract development.

Install the latest `thruput` release. The CLI selects the dependencies and compiler settings for projects it creates; you do not need to choose SDK or node versions.



## Before you start

- Install the current stable Rust toolchain with [rustup](https://rustup.rs/).
- Obtain access to the Stellar Thruput Cargo registry from your onboarding contact. Repository access alone does not grant package access.

Check that Cargo is available:

```bash
cargo --version
```



## Configure Cargo access

Set the registry address and credential provider in your shell:

```bash
export CARGO_REGISTRIES_THRUPUT_INDEX="sparse+https://crates.thruput.network/api/v1/crates/"
export CARGO_REGISTRIES_THRUPUT_CREDENTIAL_PROVIDER=cargo:token
```

Supply `CARGO_REGISTRIES_THRUPUT_TOKEN` through your credential manager or onboarding environment. Keep the token out of project files and agent prompts. If you already use a Cargo credential manager for this registry, keep its provider instead.

Use the same registry access in terminals where you build contracts. The generated project includes the registry address, but it does not include your credentials.



## Install with Cargo

```bash
cargo install thruput-cli --registry thruput --locked
thruput --version
```

The first command installs the latest CLI with its release’s dependency lockfile. The second should print the installed CLI version.

Cargo installs executables in `~/.cargo/bin`. If `thruput` is not found, add that directory to your shell’s `PATH` and open a new terminal.



## Install a packaged client

Thruput client bundle `0.1.31-rc.5` includes CLI `0.27.0`, `hog-devnode` `0.1.31-rc.2`, and the genesis contract. Choose [macOS Apple Silicon](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/groundhog-client/v0.1.31-rc.5/thruput-client-macos-arm64.tar.gz) or [Linux x86-64](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/groundhog-client/v0.1.31-rc.5/thruput-client-linux-x86_64.tar.gz). The macOS bundle requires macOS 26 or newer on Apple Silicon, includes runtime libraries, and is Developer ID signed and notarized. The Linux bundle is tested on Ubuntu 24.04 and 26.04; Ubuntu 22.04 is unsupported.

Download the archive and its [SHA256SUMS](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/groundhog-client/v0.1.31-rc.5/SHA256SUMS). In the download directory, verify the archive before extracting it:

```bash
# Apple Silicon
shasum -a 256 -c SHA256SUMS --ignore-missing

# Linux x86-64
sha256sum -c SHA256SUMS --ignore-missing
```

Check that the output reports `OK` for the archive you downloaded. Extract it into a directory you own, then add that bundle’s `bin` directory to `PATH`. Keep the complete directory together, including its runtime libraries, contract artifact, and manifest. Moving only `thruput` out of the bundle breaks this layout.

```bash
thruput --version
```

If `command -v thruput` selects an older Cargo installation, put the bundle’s `bin` directory before `~/.cargo/bin` in `PATH`. Contract builds still require Rust and Cargo registry access.

CLI-only [component archives](https://github.com/groundhogchain/groundhog-rpc/releases/latest) are also available to users with repository access. They do not include the local runtime. On Linux, both the client tarball and component installations require system jemalloc and Snappy libraries for a local node. If an error names `libjemalloc.so.2` or `libsnappy.so.1`, install your distribution’s corresponding packages (`libjemalloc2` and `libsnappy1v5` on Ubuntu).



## Set up the local runtime

Local nodes and RPC integration tests use `hog-devnode`. A packaged client includes its compatible runtime. For a Cargo or component installation, the CLI selects a compatible runtime from its bundled catalog and can download it when needed. To inspect available versions and install the selected runtime in advance:

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

`list` shows the runtime catalog and installed versions. `install` downloads and verifies the selected runtime bundle. `which` shows the selected binary’s path.

These commands manage the local-node runtime. Rust is managed through `rustup`, and the CLI is installed separately as shown above. You do not need a local node to use Futurenet.

See [runtime selection](pages/cli/local-node.md#runtime-selection) for version and binary overrides.



## Update an existing installation

For a Cargo installation, run the same `cargo install` command to install the latest release. For a packaged client, download and verify the new complete bundle, then update `PATH` to select its `bin` directory. Keep the `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml` generated for each project rather than replacing them with files from another example.

If an older executable is still selected, check its location:

```bash
command -v thruput
thruput --version
```

---

## Profiles and networks

Source: <https://thruput.network/cli/configuration/>

Select Futurenet, local development, or a custom endpoint and manage global and project configuration.

A profile selects the network, endpoint, and account settings for a command. Global profiles are reusable across projects; a project’s `thruput.toml` can override them.



## Inspect the current settings

```bash
thruput config profiles
thruput config get futurenet --sources
thruput status --profile futurenet
```

`config get` shows persisted configuration and where it came from. `status` adds environment diagnostics, including the effective key and local-runtime selection. Neither command requests funds or deploys a contract.



## Choose a profile

For one command:

```bash
thruput balance --profile futurenet
```

To make Futurenet your global default, including in new projects:

```bash
thruput config use futurenet --global
```

New project templates omit `default_profile`. Existing projects can still have a project default that overrides the global selection. To select Futurenet for one project:

```bash
thruput config use futurenet --project
```

Profile selection checks, in order:

1. `--profile`
2. `THRUPUT_PROFILE`
3. Project `default_profile`
4. Global `default_profile`

If none selects a profile, network commands fail. Offline builds and tests can use a scaffold’s local overlay without a selected default. The name `default` has no special fallback meaning.



## Futurenet

`thruput init` creates `local` and `futurenet`, with `local` as the initial default. Futurenet uses `https://rpc.thruput.network` and `https://faucet.thruput.network`. Initialization preserves existing defaults and custom profile fields. For a first funded account, follow the [CLI quickstart](pages/get-started/cli.md).

The CLI validates the selected network before signing. An explicit `network-hash` pins the network identity. Without a pin, hosted native-account operations use the configured network descriptor and RPC identity. Do not copy a hash from a different deployment; a Futurenet reset can change the identity.

`network = "devnet"` remains a compatibility alias for the hosted network. Existing Devnet profiles and saved wallets keep their names and settings. New installations create only the `futurenet` hosted profile. To add it to an older installation, rerun `thruput init`, then select it with `thruput config use futurenet --global`. Profile names are distinct; the network alias does not copy wallets or contract aliases between profiles. Older CLIs do not recognize `network = "futurenet"` and can fail to update a global config containing it. Upgrade those CLIs or keep their configuration separate.

`config new --network futurenet` stores only the supplied fields. A project overlay inherits omitted endpoints from the same-named global profile.



## Local development

Profiles with `network = "local"` can use the endpoint and runtime manifest recorded by a running `thruput node`. See [Run a local node](pages/cli/local-node.md).

For a one-off endpoint override on an RPC command:

```bash
thruput balance --profile local --rpc-url http://127.0.0.1:9546
```

Commands that use local `dev-N` accounts also need that node’s runtime manifest. Use `--runtime-manifest PATH` when automatic discovery does not apply.



## Global settings and project overrides

| Layer   | Location                        | Purpose                                                   |
| ------- | ------------------------------- | --------------------------------------------------------- |
| Global  | `~/.config/thruput/config.toml` | Shared profiles, key defaults, and wallet bindings        |
| Project | Nearest ancestor `thruput.toml` | Project defaults, profile overrides, and contract aliases |

`XDG_CONFIG_HOME` changes the global configuration root. Same-named profiles merge field by field; project values win. Contract aliases and wallet bindings merge by name.

Inside a project, choose `--global` or `--project` when changing configuration. Outside a project, omitted scope means global.

```bash
thruput config set default-key alice --profile futurenet --project
thruput config unset default-key --profile futurenet --project
```

The second command removes the project override and reveals any inherited value. The editable fields are `network`, `rpc-url`, `network-hash`, `faucet-url`, and `default-key`. Use [wallet commands](pages/cli/wallets.md) to select wallets and deployment commands to create contract aliases.



## Add another endpoint

Replace the example URLs with the RPC and faucet for the same deployment:

```bash
thruput config new staging --network futurenet \
  --rpc-url https://rpc.example.com \
  --faucet-url https://faucet.example.com \
  --global
```

Use `config new` to create a profile in a layer before changing its fields there. `config rm staging --global` removes that layer’s profile, including its saved aliases and wallet bindings. It does not delete onchain state.

---

## Keys and wallets

Source: <https://thruput.network/cli/wallets/>

Create signing keys, save native wallet bindings, select an account, and request test funds.

A **key** signs transactions. A **wallet binding** gives an account address a reusable name within a profile. Keys are global; bindings can be global or project-local.

For first-time setup, the [CLI quickstart](pages/get-started/cli.md) creates and funds a Futurenet account. This page covers account management after that setup.



## Create a key and wallet

```bash
thruput keys generate alice
thruput wallet create --key alice --profile futurenet
```

Confirm wallet creation. The CLI derives a native account and saves its address, owner, and account nonce. It does not deploy a wallet contract or request funds.

An ordinary stored key can also use its native account without a saved binding. Saving a binding is useful when you want a name for selection and inspection. Existing legacy wallet bindings keep their original account identity and transaction format.



## Inspect accounts

```bash
thruput keys ls
thruput wallet ls --profile futurenet
thruput status --profile futurenet
```

Keys live under `${XDG_CONFIG_HOME:-$HOME/.config}/thruput/keys/`. Wallet bindings live in the selected configuration layer. Wallet mutations inside a project update its overlay; outside a project they update global configuration.



## Select an account

```bash
thruput keys use alice
thruput wallet use alice --profile futurenet
thruput balance alice --profile futurenet
```

A profile’s `default-key` can override the global key. Inspect it with `thruput config get futurenet --sources`. Selecting a key does not replace an explicitly selected wallet belonging to another key; the CLI checks ownership rather than silently switching accounts.

For one deployment or call, use `--wallet NAME`. When targets are omitted from `balance`, `airdrop`, or `tx list`, the CLI resolves the effective account from the selected profile and key.



## Fund and transfer

```bash
thruput airdrop alice --profile futurenet
thruput balance alice --profile futurenet
```

The hosted faucet selects the amount. Local-node requests can use `--amount`:

```bash
thruput airdrop alice --profile local --amount 25
```

To transfer native tokens to another saved wallet or an address:

```bash
thruput transfer RECIPIENT 1 --profile futurenet
```

Replace `RECIPIENT` with the destination. Confirm the transaction and inspect its result. A new recipient needs a sufficient first credit to cover its balance storage; funding amounts depend on the network. See [Faucet](pages/tools/faucet.md) and [storage costs](pages/how-it-works/storage-economics.md).



## Remove local records

`thruput wallet rm alice --profile futurenet` removes the saved binding, not the onchain account. `thruput keys rm alice` removes the local signing key and asks for confirmation. Keep a key if you still need it to control an account.

`thruput keys export NAME` prints private key material. Use it only for an intended export, not as a diagnostic or a way to put a signer into browser code.

---

## Create a project

Source: <https://thruput.network/cli/create-project/>

Create a contract project and keep its generated compiler, build, and test configuration together.

Use `thruput new` to create a Rust contract project. If this is your first setup, [install the CLI](pages/cli/install.md) and run `thruput init` first.



## Choose a template

```bash
thruput new my-counter --template counter
cd my-counter
```

The explicit `counter` template includes counter methods, an event, an error, and tests. Without `--template`, the CLI creates a minimal contract:

```bash
thruput new my-contract
```

The minimal project and named templates include the files needed for native tests, RV32 builds, and integration tests. Keep the generated `Cargo.toml`, `rust-toolchain.toml`, and `.cargo/` configuration together. You do not need to select SDK or compiler versions yourself.

Discover named templates and their prerequisites without network access:

```bash
thruput templates list
thruput templates show counter-app
```

`counter-app` adds a local React application, generated bindings, and a temporary browser wallet. It separates contract deployment (`npm run contract:deploy`) from frontend startup (`npm run dev`). Use [Build a counter](pages/tutorials/build-a-counter.md) to build the application step by step instead.

Run `thruput new` without a name for interactive setup, or pass `--path PATH` to select a destination. The destination must be new or empty.



## Find the code

- `src/implementation.rs`: contract logic and storage.
- `tests/test.rs`: native logic tests.
- `tests/test_rv32.rs`: artifact tests.
- `tests/integration.rs`: RPC integration test entry point.
- `thruput.toml`: project profiles and deployment aliases.

See [Project structure](pages/contracts/project-structure.md) for the complete layout and generated artifacts.



## Select a network

New projects omit `default_profile` and follow your global selection. After `thruput config use futurenet --global`, new projects use Futurenet. Inspect the selected profile before deploying:

```bash
thruput config get --sources
```

Use `thruput config use futurenet --project` to set a project override, or `--profile futurenet` for one command. Builds and native/artifact tests run on your machine regardless of the profile. See [Profiles and networks](pages/cli/configuration.md).



## Work in a Cargo workspace

Keep shared `thruput.toml`, `.cargo/`, and `rust-toolchain.toml` files at the workspace root. Select a package when building from that root:

```bash
thruput build -p my-counter
thruput test -p my-counter
```

---

## Build and test

Source: <https://thruput.network/cli/build-and-test/>

Build RV32 artifacts and choose native, artifact, or RPC integration tests.

Run these commands inside a [CLI-generated project](pages/cli/create-project.md) with [Cargo access](pages/cli/install.md#configure-cargo-access) configured.



## Build a deployable artifact

```bash
thruput build
```

The CLI compiles for RV32 and lowers the result into `target/thruput/<package>.rv32a`. It also writes lowering metadata and contract-spec sidecars. Artifact names use the package’s snake-case name. See [Project structure](pages/contracts/project-structure.md#build-artifacts).

Plain `cargo build` targets your host. Use it for Rust tooling and IDE checks, not to produce the deployable artifact.

At a workspace root, select a package:

```bash
thruput build -p my-counter
```

Use `--show-cargo-commands` to inspect the compiler invocation. Arguments after `--` go to Cargo. Keep the scaffold’s compiler and feature configuration instead of recreating the cross-compilation command by hand.



## Choose a test boundary

| Command                      | What it exercises                                                             |
| ---------------------------- | ----------------------------------------------------------------------------- |
| `cargo test`                 | Native contract logic through the SDK test environment                        |
| `thruput test`               | The built RV32 artifact through `tests/test_rv32.rs`                          |
| `thruput test --integration` | Artifact build, disposable local node, deployment, and `tests/integration.rs` |

The first two do not require a running RPC node. Integration mode starts and stops its own node; it does not submit transactions to Futurenet.

```bash
cargo test
thruput test
```

For test code, assertions, and storage-cost setup, use [Test contracts](pages/programming-model/testing.md).



## Focus a test run

```bash
thruput test --match-test counter
thruput test --skip slow
thruput test --show-output
thruput test --no-capture --test-threads 1
```

`--match-test` and `--skip` filter test names. `--show-output` includes output from passing tests; `--no-capture` streams output as tests run.

```bash
thruput test --rerun
thruput test --watch
```

`--rerun` uses the previous failure cache. `--watch` runs immediately, then repeats after source or configuration changes. They can be combined.



## Integration and workspace runs

```bash
thruput test --integration
thruput test --workspace
```

These are separate modes. `--workspace` runs members with a `test_rv32` target in package-name order. It cannot be combined with `-p` or `--integration`. Integration mode does not support `--watch` or `--rerun`.

The CLI can acquire its selected local runtime for integration tests. See [runtime selection](pages/cli/local-node.md#runtime-selection) for explicit overrides, and [Automation](pages/cli/automation.md) for structured test reports.

---

## Run a local node

Source: <https://thruput.network/cli/local-node/>

Start an isolated development chain, select its accounts, and preserve or inspect local state.

Use a local node for disposable development and RPC tests. For a first hosted deployment, follow the [Futurenet contract quickstart](pages/get-started/contract.md).



## Start the node

```bash
thruput node
```

Keep this terminal running. The CLI starts its managed `hog-devnode` and exposes JSON-RPC at `http://127.0.0.1:9545` by default. If the selected runtime is missing, the CLI can download its verified bundle.

The CLI records the active endpoint and runtime manifest so commands using a local profile can find the node.

The node funds the selected project/global key. If local and Futurenet profiles use different keys, run `THRUPUT_PROFILE=local thruput node` so startup uses the key selected by local commands. `--key NAME` explicitly selects a stored key.



## Select a local account

From another terminal in your project:

```bash
thruput config set default-key dev-1 --profile local --project
thruput balance dev-1 --profile local
```

`dev-0` is the local faucet. Normal bootstrap accounts start at `dev-1`; their keys and initial balances come from the runtime manifest. These deterministic accounts are for local development only.

If the profile already selects a saved wallet, key selection alone does not replace that wallet. Inspect `thruput status --profile local` and [wallet selection](pages/cli/wallets.md#select-an-account) before submitting.

You can now use the normal [deployment and call commands](pages/cli/deploy-and-call.md) with `--profile local`.



## Preserve state

Without a data directory, stopping the node discards its chain state. Stored signing keys and project configuration remain, but the local deployments and balances do not.

```bash
thruput node --data-dir .thruput/node
```

Restart with the same data directory to reuse the chain. Preserve any explicit genesis settings used to create it.

Stop the node before backing up or restoring that directory:

```bash
thruput chain dump --data-dir .thruput/node --output chain-backup.json
thruput chain restore --data-dir .thruput/node --input chain-backup.json
```

Restore asks before replacing populated state. Use `--force` only when that replacement is intended.



## Change the endpoint or logging

```bash
thruput node --port 9546
thruput node --verbose
```

Choose logging before reproducing a problem: restarting an ephemeral node to enable it loses the old state. `RUST_LOG` provides finer control and overrides the verbose preset.

The public listener binds to loopback by default. `--host` changes that listener for container or VM access; exposing it beyond loopback exposes an unauthenticated development RPC endpoint.



## Runtime selection

The CLI selects a default from its bundled runtime catalog. See [local runtime setup](pages/cli/install.md#set-up-the-local-runtime) to inspect and install managed runtimes.

To inspect the effective configuration:

```bash
thruput status --json
```

An explicit `--hog-devnode-binary`, `THRUPUT_DEVNODE_BINARY`, or adjacent binary can take precedence over managed selection. Use `--hog-devnode-version VERSION` when intentionally selecting an exact catalog entry. `--offline` prevents managed downloads, not RPC or Cargo traffic.

If the runtime is incompatible, select matching binaries. `--hogd-protocol` changes a handshake token only; it does not make different wire formats compatible.

For isolated automated runs, prefer [integration tests](pages/cli/build-and-test.md#integration-and-workspace-runs) rather than managing a long-running node yourself.

---

## Deploy and call

Source: <https://thruput.network/cli/deploy-and-call/>

Deploy an artifact, fund its storage, call methods, and read committed state.

Run these commands in a contract project with a built artifact. Deployment and calls need a funded account; estimating needs no signing key. Select the intended [profile](pages/cli/configuration.md) explicitly. The examples use Futurenet and the scaffolded counter’s methods.



## Estimate deployment funding

```bash
thruput build
thruput deploy --estimate --profile futurenet
thruput deploy --estimate --profile futurenet --json
```

The estimate reads the network’s authoritative execution rules and storage prices without signing or submitting. It checks the artifact, code, and memory limits and assumes a fresh, unfunded contract address. Unlike `--dry-run`, it does not prepare a signed transaction.

| Report field                             | Meaning                                                                                                                             |
| ---------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `balanceDepositRaw`, `deploymentCostRaw` | First balance-item deposit and code collateral, in native-token base units                                                          |
| `minimumFundingRaw`, `minimumFundingHog` | Their sum, as an integer base-unit string and a whole-token decimal string respectively; one native token has 10,000,000 base units |
| `initializerFundingRaw`                  | `null` when an initializer is requested, because its storage is not estimated; `"0"` when none is requested                         |
| `execution`                              | Observed committed tip, configuration hash, effective limits, and storage prices                                                    |

Missing authoritative rules or prices produce an error, not a zero-cost estimate. The reading applies at its reported configuration; prices can change before inclusion. Re-estimate after rebuilding or changing networks.

For deployment without initialization, the CLI can read and transfer the minimum directly:

```bash
thruput deploy --profile futurenet --fund minimum
```

The minimum leaves **zero free contract balance** for further storage. It excludes initializer writes, later storage growth, the sender’s replay storage, and the sender’s scheduling capacity. `--fund minimum` cannot be combined with `--init`. Use an explicit total amount when initialization or later calls need storage, as in the [counter guide](pages/tutorials/build-a-counter.md#build-deploy-and-initialize).



## Deploy an artifact

```bash
thruput build
thruput deploy --profile futurenet --fund 10
```

Confirm the deployment. The CLI waits for its result, prints the deployed address, and saves an alias using the package name. For a project named `my-counter`, later commands can use that alias instead of the address.

Numeric `--fund` transfers exactly that many native tokens from the sender to the new contract. Set it to the estimated minimum plus an allowance for contract storage. `10` above illustrates the syntax; choose your total from the current estimate rather than treating it as a fixed fee or minimum.

At a workspace root, use `-p PACKAGE`. Use `--artifact PATH` to select an artifact directly and `--alias NAME` when you want a specific alias.



## Include initialization

For a new deployment that initializes the counter in the same transaction, use this instead:

```bash
thruput deploy --profile futurenet --fund 10 \
  --init initialize --init-arg 10
```

Repeat `--init-arg` for additional arguments. The initializer sees the deploying wallet as its caller. Funding, deployment, and initialization succeed together or roll back together.

Initialization is an ordinary contract method. The contract must enforce one-time initialization when its design requires it. The starter counter simply adds the supplied amount, so do not call it again after initializing this example.



## Submit a call

For a counter that has been deployed and initialized:

```bash
thruput call my-counter increment 5 --profile futurenet
```

This signs and submits a transaction. Method names and typed arguments use the contract spec. Without metadata, an explicit entrypoint and raw calldata are required; use generated metadata for normal development.

Use `--gas-limit` when the call needs a different execution budget. The sender must have the corresponding scheduling capacity; gas itself has no token fee.



## Read without submitting

```bash
thruput view my-counter get --profile futurenet
```

`view` runs a sandboxed call against committed state. It does not submit a transaction. Use `--from ADDRESS` when a read needs a simulated caller; this does not prove control of that address.

`thruput storage CONTRACT KEY` reads a raw storage item. Prefer a view when you want the contract’s typed behavior.



## Prepare without broadcasting

```bash
thruput deploy --profile futurenet --fund 10 --dry-run
thruput call my-counter increment 5 --profile futurenet --dry-run
```

A dry run prepares and signs a transaction but does not submit it. It still needs the selected key and network access. It is not a simulation of the state change and does not prove that execution will succeed.



## Inspect an uncertain result

Keep the transaction hash and original network if submission or receipt observation fails:

```bash
thruput tx show TX_HASH --profile futurenet
```

A timeout or `unknown` status does not prove that the transaction failed. Repeating a deployment creates a new nonce and predicted address. Inspect the original transaction before deciding to submit a new operation. See [Inspect transactions and events](pages/cli/transactions.md).

---

## Inspect transactions and events

Source: <https://thruput.network/cli/transactions/>

Inspect receipts, address history, contract events, and token transfers from the CLI.

Use the same profile and network that received the transaction. The commands below are read-only.



## Look up one transaction

```bash
thruput tx show TX_HASH --profile futurenet
```

Replace `TX_HASH` with the submitted hash. This performs one status lookup and fetches the receipt when committed; it does not wait for a pending transaction.

Check the receipt’s execution result. A committed failure is different from a transaction that is still pending or excluded from a proposal. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).



## List history

```bash
thruput tx list my-counter --profile futurenet --limit 25
```

History is indexed by root invocation target. A wallet-wrapped call can appear under the wallet rather than the inner target contract. Use the receipt and contract events to inspect inner activity; absence from an address-history page does not prove an operation did not occur.



## Read contract events

```bash
thruput events list my-counter --profile futurenet --limit 25
```

For decoded events, supply the trusted spec from the same contract build:

```bash
thruput events list my-counter --profile futurenet \
  --spec target/thruput/my_counter.spec.xdr --event PingEvent
```

Use `--topic0`, `--topic1`, or `--topic2` for raw topic filters. Repeated values at one position mean OR; filters across positions mean AND. Use the signature from the generated spec rather than copying one from another contract.



## Inspect token transfers

```bash
thruput token transfers HOG --profile futurenet
```

Use `--account ADDRESS` to restrict the query to an account. Amounts are returned as base-unit values; formatting is separate from the stored amount.



## Continue a page

These list commands return one newest-first page at a time. Pass the returned cursor to the same command with the same target and filters:

```bash
thruput tx list my-counter --profile futurenet --limit 25 --cursor CURSOR
```

Replace `CURSOR` with the exact returned value. An empty page with a non-empty cursor is not the end. The returned cursor `0x` ends that historical walk.

To check for new activity, omit `--cursor` and start at the head again. A saved cursor continues the old walk; it is not a subscription. For forward ingestion and durable checkpoints, use the [event indexing guidance](pages/typescript/events.md#resume-without-missing-events).

The [Explorer](pages/tools/block-explorer.md) provides a browser-based inspection path.

---

## Generate TypeScript bindings

Source: <https://thruput.network/cli/codegen/>

Generate typed application bindings from a built contract's canonical specification.

Generate bindings from the same contract build you deploy. Bindings provide method descriptors, argument types, result decoders, and declared event and error types.

Use Thruput CLI 0.29.0 or newer for applications that import the private `@thruputchain` npm packages. Older generators emit the previous package namespace.



## Generate during a build

```bash
thruput build --bindings ts
```

The build prints the generated binding path alongside the contract artifacts. Use `-p PACKAGE` when selecting a workspace member.



## Write bindings into an application

Build first, then select the binary spec sidecar:

```bash
thruput build
mkdir -p web/src/contracts
thruput codegen ts target/thruput/my_counter.spec.xdr \
  --output web/src/contracts/my-counter.ts
```

Replace `my_counter` with your artifact’s name and the output directory with your application’s location. `codegen ts` accepts `.spec.xdr`, not the readable `.spec.json` or the deployable `.rv32a` file.



## Keep code and deployment aligned

Regenerate bindings when the contract interface changes. Use the address from the matching deployment rather than an address copied from another example.

Do not edit generated files. Put application wrappers next to them so regeneration does not overwrite application logic.

Continue with [Use contract bindings](pages/tools/typescript-bindings.md) for descriptors and typed calls, or [Read events](pages/typescript/events.md) for filters and decoding.

---

## Skills and local docs

Source: <https://thruput.network/cli/agent-tools/>

Install, update, and read the thruput skill, and serve or export local documentation.

Use `thruput skill` for coding-agent instructions and `thruput docs` for the developer documentation. For a first project, follow [Build with an Agent](pages/start/build-with-an-agent.md).



## Install the maintained skill

Installation requires Node.js 22.20 or newer, npm, Git, and access to the private [skill repository](https://github.com/groundhogchain/agent-skills). Configure repository authentication through Git, GitHub CLI, or SSH.

```bash
thruput skill install
```

The installer lets you choose your agents, project or global scope, and installation method. Project scope is the default. To select an agent or use a user-wide installation explicitly:

```bash
thruput skill install --agent opencode
thruput skill install --global --agent claude-code
```

Repeat `--agent` to select more than one agent. These commands run `npx skills` against the maintained source. You can also install directly:

```bash
npx skills add groundhogchain/agent-skills --skill thruput
```

Installing the skill does not configure Cargo or npm access for a contract or application. Follow the relevant [quickstart](pages/get-started.md) for those dependencies.



## Update an installed skill

Run the update in the same scope as the installation:

```bash
thruput skill update
thruput skill update --global
```

Each command updates only the `thruput` skill, not other installed skills. If `thruput` is absent from that scope, run `skill install` there first. A current installation needs no change. Repeating installation uses the installer again; it does not create a second skill name.

For a direct project-scoped update:

```bash
npx skills update thruput --project
```





## Read installed guidance offline

```bash
thruput skill show
thruput skill list
thruput skill show contracts
thruput skill show contracts --global
thruput skill list --global
```

`show` prints the installed `SKILL.md` unchanged. `list` lists the Markdown references in that installation. Select a topic, such as `contracts`, to read its reference. There is no `--all` option; read the entry and the references needed for your task.

By default, these commands look for `.agents/skills/thruput` in the current directory, then under your home directory. Run them from the directory where you installed the project skill. `--global` selects only the home-directory installation. An invalid project installation reports an error rather than falling back to the global copy.

Install the skill before reading it. Once installed, `show` and `list` need no Node.js, npm, Git, or network access. Missing files produce an installation or read error, not bundled fallback content. Add `--json` for the selected scope, file path, and content or topic list.

Updates change the installed files that `show` and `list` read. This is separate from `thruput docs`, which serves a documentation snapshot bundled with the CLI.



## Automate skill setup

For an intended unattended installation or update:

```bash
thruput skill install --agent opencode --yes --non-interactive --json
thruput skill update --yes --non-interactive --json
```

Installation requires an explicit `--agent` when prompts are unavailable. Both operations require `--yes` to authorize npm execution and skill changes. Add `--global` for user-wide scope. `--non-interactive` and `--json` do not grant consent. `--offline` rejects installation and updates before invoking npm.



## Serve local documentation

```bash
thruput docs
```

This serves the CLI’s bundled site on `127.0.0.1:4321` until you press Ctrl-C. `--foreground` makes that mode explicit. The command prints the browser URL, Markdown index path, and snapshot source. It starts no blockchain node.

To keep the server running after the command returns:

```bash
thruput docs --background --port 0
thruput docs status
thruput docs stop
```

Port `0` chooses an available port. Background startup returns only when the server is ready and reports the browser URL, Markdown index, and log path. Repeating the same start command reuses a matching instance. Stop it before changing its port, snapshot, or CLI executable.

`status` and `stop` manage the current user’s background server, not a foreground process. The server does not start automatically after reboot. Stopping it leaves the extracted Markdown available. Add `--json` to start, status, or stop for structured reports.

Use the printed Markdown index to find individual pages under `pages/`, focused bundles under `sections/`, and the complete `full.md`. Agents on the same machine can read these files without keeping the server running. Bundled documentation is a snapshot and can differ from the hosted site.



## Export Markdown without a server

```bash
thruput docs export --output ./thruput-docs
```

The destination must not exist, and its parent directory must exist. The CLI copies the Markdown tree and snapshot identity, then prints the absolute path to `index.md`. It does not start a server or replace an existing export. Choose a new destination for another export.

Share the whole folder with an agent on another machine. Relative links and local assets remain usable away from the website. A remote agent cannot use your local filesystem path or loopback URL directly.



## Use a trusted site snapshot

```bash
thruput docs --dir /path/to/docs-snapshot --port 0
thruput docs export --dir /path/to/docs-snapshot --output ./exported-docs
```

Pass a directory produced by the documentation snapshot build, including its `snapshot.json`. Keep it unchanged while serving. Export requires `markdown/index.md` in that snapshot. The override does not fetch the hosted site.

Serving bundled docs and exporting them work offline. Linked repositories, package registries, and network services can still require network access.

---

## Use the CLI in scripts

Source: <https://thruput.network/cli/automation/>

Use non-interactive commands and structured output without treating output flags as confirmation.

Use `--non-interactive` to disable questions and terminal UI. It does not authorize state changes. Supply the command’s consent option, such as `--force` for deployment or `--yes` for skill setup.



## Set up explicitly

```bash
thruput init --non-interactive --generate-key
```

`--generate-key` authorizes initial key creation when there are no stored keys or explicit selections. It does not replace an existing key. Use `thruput new` separately to create a project in a script.



## Request structured output

```bash
thruput config get futurenet --json
thruput test --json
```

The envelope identifies the command, its `ok` result, warnings, and command data. Payloads carry a command-specific `schemaVersion`; check it before relying on exact fields.

Check the process exit status as well as the envelope. A reported test failure can carry `ok: false` on stdout. Other command failures can emit an error envelope on stderr. Keep the streams separate instead of assuming every failed command produces a successful-data shape on stdout.

With `test --watch --json`, each completed run is a separate JSON record. A long-running `node` or watch command still runs until stopped.



## Confirm intended writes

For a deployment you intend to submit:

```bash
thruput deploy --profile futurenet --fund 10 --non-interactive --force --json
```

For preparation without submission, use `--dry-run` instead. Neither `--quiet` nor `--json` substitutes for confirmation.



## Set up agent tools

```bash
thruput skill install --agent opencode --yes --non-interactive --json
thruput docs --background --port 0 --json
```

Unattended skill installation needs both `--yes` and an explicit agent. Updates need `--yes`; add `--global` to either operation for user-wide scope. See [Skills and local docs](pages/cli/agent-tools.md) for prerequisites, targeted updates, and offline reads.

Background docs reports include `running`, `reused`, `server`, and `logPath` in `data`. Read `server.url` and `server.markdownIndex` when a server is present. Use `thruput docs status --json` to inspect it and `thruput docs stop --json` to stop it. A status with `running: false` is a valid result, not a command failure.

---

## Troubleshooting

Source: <https://thruput.network/cli/troubleshooting/>

Diagnose configuration, build, runtime, funding, and transaction-observation problems.

Start with the command’s error and the selected environment:

```bash
thruput --version
thruput status --profile futurenet
thruput config get futurenet --sources
```

For local work, use `--profile local`. `status` can exit nonzero when it finds warnings; inspect the findings rather than assuming the report itself failed.



## Cargo cannot access packages

Complete [Cargo access setup](pages/cli/install.md#configure-cargo-access) in the terminal running the build. A registry token alone is not enough if Cargo has no credential provider configured. Repository access does not imply registry access.



## The wrong profile or account is selected

An explicit `--profile` wins over `THRUPUT_PROFILE`, which wins over project and global defaults. A profile-specific key or selected wallet can also override the global key. Inspect both configuration and `wallet ls --profile NAME` before changing them.

Use [Profiles and networks](pages/cli/configuration.md) and [Keys and wallets](pages/cli/wallets.md) to change the intended layer. Preserve existing keys rather than generating replacements to hide a selection error.



## The local runtime is missing or incompatible

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

Check for an intentional `THRUPUT_DEVNODE_BINARY` override or an adjacent binary. The installed CLI’s catalog chooses a compatible managed runtime. A protocol-token override does not fix a wire-format mismatch. See [runtime selection](pages/cli/local-node.md#runtime-selection).

On Linux, a missing shared-library error identifies the system dependency to install. See [CLI installation](pages/cli/install.md) for runtime-library guidance.



## The node restarted and the deployment disappeared

An ephemeral local node loses chain state on shutdown. Restarting it does not restore the old wallets, balances, or deployments, even when local configuration still has their aliases. Redeploy on the new chain, or use a persistent [data directory](pages/cli/local-node.md#preserve-state).



## Deployment needs funding

Native deployment requires an explicit `--fund` amount. The sender needs funds for the transfer and scheduling capacity; the deployed contract needs funds for its own storage. Inspect the sender with `thruput balance --profile NAME`, then request appropriate test funding or reduce the operation. See [Deploy and call](pages/cli/deploy-and-call.md).



## Submission timed out or status is unknown

Keep the transaction hash and original network. Run `thruput tx show TX_HASH --profile NAME` to inspect it. A timeout is not proof of failure. Do not automatically repeat a deployment or sign a replacement call.



## A view or call cannot resolve a method

Use the correct contract alias and the spec from the matching build. Rebuild after interface changes. At a Cargo workspace root, select the package with `-p`. Explicit entrypoint calls require the matching encoded calldata; changing only the entrypoint does not adapt an incompatible interface.



## The integration target is missing

Current CLI projects include `tests/integration.rs` and its activation wiring. Compare an older project with a fresh scaffold before adding them; do not replace its dependency configuration blindly. See [Test contracts](pages/programming-model/testing.md#what-the-scaffold-gives-you).

---

## Command reference

Source: <https://thruput.network/cli/reference/>

Thruput CLI commands, common options, and links to task instructions.





## First-Run Setup

| Command                                                              | Purpose                                                                       | Usage                                                              |
| -------------------------------------------------------------------- | ----------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `thruput --version`                                                  | Print the installed release                                                   | [Install](pages/cli/install.md)                                    |
| `thruput init`                                                       | Initialize profiles and check setup; offer initial key creation interactively | [CLI quickstart](pages/get-started/cli.md)                         |
| `thruput init --non-interactive --generate-key`                      | Explicitly authorize initial key creation without prompts                     | [Automation](pages/cli/automation.md)                              |
| `thruput status [--profile NAME]`                                    | Inspect project, key, compiler, and runtime readiness                         | [Troubleshooting](pages/cli/troubleshooting.md)                    |
| `thruput new [NAME] [--path PATH] [--template counter\|counter-app]` | Create a minimal contract by default; omit the name for interactive setup     | [Create a project](pages/cli/create-project.md)                    |
| `thruput templates list` / `thruput templates show NAME`             | Discover named templates and their prerequisites offline                      | [Choose a template](pages/cli/create-project.md#choose-a-template) |
| `thruput completion SHELL`                                           | Print shell completions                                                       | `thruput completion --help`                                        |
| `thruput COMMAND --help`                                             | Print the installed command’s options                                         | Available on each command                                          |



## Configuration

| Command                                 | Purpose                                             | Usage                                                                         |
| --------------------------------------- | --------------------------------------------------- | ----------------------------------------------------------------------------- |
| `config profiles`                       | List persisted profiles                             | [Profiles and networks](pages/cli/configuration.md)                           |
| `config get [NAME] [--sources]`         | Inspect merged persisted settings and their origins | [Inspect settings](pages/cli/configuration.md#inspect-the-current-settings)   |
| `config new NAME --network NETWORK`     | Create a profile in one layer                       | [Add an endpoint](pages/cli/configuration.md#add-another-endpoint)            |
| `config set FIELD VALUE --profile NAME` | Set one typed field in an existing profile layer    | [Overrides](pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config unset FIELD --profile NAME`     | Remove a field from one layer                       | [Overrides](pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config use NAME`                       | Set the layer’s default profile                     | [Select a profile](pages/cli/configuration.md#choose-a-profile)               |
| `config rm NAME`                        | Remove a profile from one layer                     | Requires confirmation; `--force` for an intended automated removal            |
| `--global` / `--project`                | Choose the layer for a configuration mutation       | Required inside a project; mutually exclusive                                 |



## Keys and Wallets

| Command                                    | Purpose                                              | Usage                                                           |
| ------------------------------------------ | ---------------------------------------------------- | --------------------------------------------------------------- |
| `keys generate [NAME]`                     | Generate a stored Ed25519 key                        | [Keys and wallets](pages/cli/wallets.md)                        |
| `keys import NAME`                         | Import key material through the supported input flow | `thruput keys import --help`                                    |
| `keys ls` / `keys use NAME`                | List or select a global key                          | [Select an account](pages/cli/wallets.md#select-an-account)     |
| `keys export NAME`                         | Print private key material                           | Intended export only; exclude from logs                         |
| `keys rm NAME`                             | Delete a local key                                   | Requires confirmation                                           |
| `wallet create [--key NAME] [--name NAME]` | Derive and save an empty native account binding      | [Create a wallet](pages/cli/wallets.md#create-a-key-and-wallet) |
| `wallet ls` / `wallet use NAME`            | List or select a profile wallet                      | [Select an account](pages/cli/wallets.md#select-an-account)     |
| `wallet rm NAME`                           | Remove a local binding                               | Does not remove onchain state                                   |
| `balance [TARGET]`                         | Read the native-token balance                        | [Funding](pages/cli/wallets.md#fund-and-transfer)               |
| `airdrop [RECIPIENT]`                      | Request test funding                                 | [Faucet](pages/tools/faucet.md)                                 |
| `transfer RECIPIENT AMOUNT`                | Transfer native tokens from the selected account     | [Funding and transfers](pages/cli/wallets.md#fund-and-transfer) |



## Build and Test

| Command or option                        | Purpose                                       | Usage                                                                                |
| ---------------------------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------ |
| `build [-p PACKAGE]`                     | Build a deployable RV32 artifact              | [Build and test](pages/cli/build-and-test.md)                                        |
| `build --bindings ts`                    | Also generate TypeScript bindings             | [Code generation](pages/cli/codegen.md)                                              |
| `build --stack-size SIZE`                | Set guest stack size within configured memory | `thruput build --help`                                                               |
| `test [-p PACKAGE]`                      | Build and run the RV32 artifact test target   | [Test modes](pages/cli/build-and-test.md#choose-a-test-boundary)                     |
| `test --integration`                     | Run an isolated local-node integration target | [Integration tests](pages/programming-model/testing.md#integration-test-environment) |
| `test --workspace`                       | Run eligible workspace members                | [Workspace runs](pages/cli/build-and-test.md#integration-and-workspace-runs)         |
| `test --match-test TEXT` / `--skip TEXT` | Filter test names                             | [Focused runs](pages/cli/build-and-test.md#focus-a-test-run)                         |
| `test --rerun` / `--watch`               | Repeat failures or watch files                | Not supported with `--integration`                                                   |
| `test --show-output` / `--no-capture`    | Control test output                           | [Focused runs](pages/cli/build-and-test.md#focus-a-test-run)                         |



## Local Node

| Command or option                                         | Purpose                                 | Usage                                                                          |
| --------------------------------------------------------- | --------------------------------------- | ------------------------------------------------------------------------------ |
| `node`                                                    | Start an ephemeral local node           | [Run a local node](pages/cli/local-node.md)                                    |
| `node --data-dir PATH`                                    | Preserve chain state                    | [Persistent state](pages/cli/local-node.md#preserve-state)                     |
| `node --port PORT` / `--host ADDRESS`                     | Configure the public listener           | [Endpoint and logging](pages/cli/local-node.md#change-the-endpoint-or-logging) |
| `node --verbose`                                          | Forward node diagnostics                | [Troubleshooting](pages/cli/troubleshooting.md)                                |
| `node --network-config NAME=VALUE`                        | Override a supported genesis parameter  | Repeatable; preserve settings when reopening a data directory                  |
| `node --dev-account-count N` / `--dev-account-hog AMOUNT` | Configure local-user bootstrap accounts | Does not configure the faucet allocation                                       |
| `toolchain list` / `install` / `which`                    | Inspect or acquire managed runtimes     | [Local runtime setup](pages/cli/install.md#set-up-the-local-runtime)           |
| `toolchain use VERSION` / `clean VERSION`                 | Select or remove a managed version      | `thruput toolchain --help`                                                     |
| `chain dump --data-dir PATH --output FILE`                | Back up a stopped local chain           | [Persistent state](pages/cli/local-node.md#preserve-state)                     |
| `chain restore --data-dir PATH --input FILE`              | Restore a stopped local chain           | Requires confirmation before replacing populated state                         |



## Deploy and Interact

| Command or option                       | Purpose                                                                                                                      | Usage                                                                        |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `deploy --fund AMOUNT`                  | Deploy and fund a contract with native tokens                                                                                | [Deploy and call](pages/cli/deploy-and-call.md)                              |
| `deploy --estimate [--json]`            | Read deployment collateral and configuration context without loading a signing key or submitting                             | [Estimate funding](pages/cli/deploy-and-call.md#estimate-deployment-funding) |
| `deploy --fund minimum`                 | Fund a fresh deployment’s balance-item deposit and code collateral; leaves no free balance and cannot include initialization | [Minimum funding](pages/cli/deploy-and-call.md#estimate-deployment-funding)  |
| `deploy --init METHOD --init-arg VALUE` | Initialize atomically with deployment                                                                                        | [Initialization](pages/cli/deploy-and-call.md#include-initialization)        |
| `deploy --artifact PATH --alias NAME`   | Select an artifact and saved alias                                                                                           | [Deployment](pages/cli/deploy-and-call.md#deploy-an-artifact)                |
| `call CONTRACT METHOD [ARGS...]`        | Submit a signed contract invocation                                                                                          | [Calls](pages/cli/deploy-and-call.md#submit-a-call)                          |
| `view CONTRACT METHOD [ARGS...]`        | Run a sandboxed read without submitting                                                                                      | [Views](pages/cli/deploy-and-call.md#read-without-submitting)                |
| `storage CONTRACT KEY`                  | Read a raw committed storage item                                                                                            | [Views and storage](pages/cli/deploy-and-call.md#read-without-submitting)    |
| `--dry-run`                             | Prepare deploy/call transactions without broadcast                                                                           | Still requires signing context and network access                            |
| `--force`                               | Confirm an intended write without a prompt                                                                                   | [Automation](pages/cli/automation.md#confirm-intended-writes)                |
| `--profile NAME` / `--rpc-url URL`      | Select configuration or override the endpoint                                                                                | [Profiles](pages/cli/configuration.md)                                       |



## Transactions, Events, and Tokens

| Command                         | Purpose                                         | Usage                                                                     |
| ------------------------------- | ----------------------------------------------- | ------------------------------------------------------------------------- |
| `tx show HASH`                  | One public status and receipt lookup            | [Inspect transactions](pages/cli/transactions.md#look-up-one-transaction) |
| `tx list [TARGET]`              | One page of root-invocation history             | [History](pages/cli/transactions.md#list-history)                         |
| `events list CONTRACT`          | One page of raw or spec-decoded contract events | [Events](pages/cli/transactions.md#read-contract-events)                  |
| `token transfers TOKEN`         | One page of token transfer records              | [Token transfers](pages/cli/transactions.md#inspect-token-transfers)      |
| `--limit N` / `--cursor CURSOR` | Control a historical list page                  | [Pagination](pages/cli/transactions.md#continue-a-page)                   |



## TypeScript Bindings

| Command                   | Input/output                                                     | Usage                                                                        |
| ------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `build --bindings ts`     | Contract build plus generated bindings                           | [Generate bindings](pages/cli/codegen.md)                                    |
| `codegen ts SPEC -o FILE` | Canonical `.spec.xdr` to TypeScript; stdout if output is omitted | [Write into an app](pages/cli/codegen.md#write-bindings-into-an-application) |





## Skills and Local Documentation

| Command                                              | Purpose                                                                                                     | Usage                                                                        |
| ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `thruput skill install [--global] [--agent NAME]`    | Install the maintained skill through `npx skills`; `--agent` is repeatable                                  | [Install the skill](pages/cli/agent-tools.md#install-the-maintained-skill)   |
| `thruput skill update [--global]`                    | Update only the `thruput` skill in the selected scope; requires an existing installation                    | [Update the skill](pages/cli/agent-tools.md#update-an-installed-skill)       |
| `skill install --yes` / `skill update --yes`         | Authorize npm execution and skill changes; unattended installation also needs `--agent`                     | [Automate setup](pages/cli/agent-tools.md#automate-skill-setup)              |
| `thruput skill show [TOPIC] [--global]`              | Read an installed skill file offline; current-directory installation before global unless `--global` is set | [Read guidance](pages/cli/agent-tools.md#read-installed-guidance-offline)    |
| `thruput skill list [--global]`                      | List reference names from the selected installed skill                                                      | [Read guidance](pages/cli/agent-tools.md#read-installed-guidance-offline)    |
| `thruput docs [--foreground] [--port PORT]`          | Serve the bundled site in the foreground; default port `4321`, `0` selects a free port                      | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs --dir PATH`                            | Serve a trusted local snapshot                                                                              | [Snapshot override](pages/cli/agent-tools.md#use-a-trusted-site-snapshot)    |
| `thruput docs --background [--port PORT]`            | Start or reuse a matching background server; conflicts with `--foreground`                                  | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs status`                                | Inspect the current user’s background server and log path                                                   | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs stop`                                  | Stop the managed background server while retaining extracted Markdown                                       | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs export --output PATH [--dir SNAPSHOT]` | Export portable Markdown into a new directory without serving                                               | [Export Markdown](pages/cli/agent-tools.md#export-markdown-without-a-server) |



## Shared Flags

| Global flag             | Effect                                                                                                  |
| ----------------------- | ------------------------------------------------------------------------------------------------------- |
| `--non-interactive`     | Disable prompts and terminal UI; does not grant confirmation                                            |
| `--json`                | Emit structured output                                                                                  |
| `--quiet`               | Suppress status messages                                                                                |
| `--show-cargo-commands` | Print Cargo invocations                                                                                 |
| `--offline`             | Disable managed runtime downloads and skill installation/updates; does not disable RPC or Cargo traffic |



### JSON output

| Output concern      | Rule                                                        | Usage                                                                  |
| ------------------- | ----------------------------------------------------------- | ---------------------------------------------------------------------- |
| Success and failure | Check exit status and `ok`; command failures may use stderr | [Use the CLI in scripts](pages/cli/automation.md)                      |
| Payload shape       | Check command-specific `data.schemaVersion`                 | [Structured output](pages/cli/automation.md#request-structured-output) |
| Watch mode          | One JSON record per completed test run                      | [Structured output](pages/cli/automation.md#request-structured-output) |

---

## Smart Contracts

Source: <https://thruput.network/contracts/>

Write, test, and understand Stellar Thruput contracts with the Rust SDK.

Build contract logic with the Rust SDK. Use this section for storage choices, authorization, events, testing, and the contract programming model.



## Write your first contract

Follow the [contract quickstart](pages/get-started/contract.md) to deploy a counter on Futurenet. Then read [Build a Counter](pages/tutorials/build-a-counter.md) to understand its code and tests, or [Project structure](pages/contracts/project-structure.md) to find the generated files.

Use the [CLI section](pages/cli.md) for build and deployment commands.



## Work on a contract

- [Define methods and interfaces](pages/contracts/methods.md).
- [Choose storage types](pages/programming-model/storage-types.md) for your data.
- [Authorize calls](pages/how-it-works/authorization.md).
- [Define and handle errors](pages/contracts/errors.md).
- [Emit and test events](pages/contracts/events.md).
- [Call another contract](pages/contracts/cross-contract-calls.md).
- [Choose a test mode and write tests](pages/programming-model/testing.md).
- [Debug a contract](pages/contracts/debugging.md).
- [Generate client bindings](pages/contracts/client-bindings.md) for application developers.



## Understand the programming model

Read [execution](pages/programming-model/execution.md) for how contract state changes are applied. Continue with [NNInt and concurrent updates](pages/programming-model/nnint.md), [exclusive writes](pages/programming-model/storage-types.md#exclusive-writes), or [invocation frames](pages/how-it-works/invocation-frames.md) when your design needs that detail.

Read [Contract artifacts and addresses](pages/how-it-works/contracts.md) to understand code hashes, deployment addresses, and immutability.



## Look up an API

Use the [storage API tables](pages/reference/storage-types.md), [SDK macros](pages/reference/sdk-macros.md), [syscalls](pages/reference/syscalls.md), and [generated Rust API docs](pages/tools/rust-api-docs.md).

For larger worked examples, visit [Guides](pages/guides.md).

---

## Project structure

Source: <https://thruput.network/contracts/project-structure/>

Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.

`thruput new` creates a minimal Cargo contract project by default. Use `thruput new my-counter --template counter` for the counter layout below, including its example methods and tests. Keep the generated dependency versions, compiler settings, and CLI configuration together.



## Generated files

```text
my-counter/
  Cargo.toml              # Package, SDK dependencies, and build features
  AGENTS.md               # Instructions for coding agents
  build.rs                # Integration-test setup
  thruput.toml          # Project profiles and contract aliases
  rust-toolchain.toml     # Selected compiler and targets
  .cargo/
    config.toml           # Registry and Cargo configuration
    contract.toml         # Contract-build configuration
  src/
    lib.rs                # Library modules
    implementation.rs     # Contract logic, storage, errors, and events
    main.rs               # Contract entrypoint wrapper
  tests/
    test.rs               # Native logic tests
    test_rv32.rs          # Contract artifact tests
    integration.rs        # Tests against a running node
```

The `.gitignore` excludes build output and project-local runtime state.



## Build artifacts

`thruput build` compiles the entrypoint for RV32, Stellar Thruput’s 32-bit RISC-V contract target. It lowers the compiler output into an artifact the node can execute.

For `my-counter`, the output under `target/thruput/` includes:

- `my_counter.rv32a`: deployable contract artifact.
- `my_counter.rv32.json`: lowering metadata.
- `my_counter.spec.xdr`: binary contract specification.
- `my_counter.spec.json`: readable contract specification.

The specification describes the contract interface and supports [TypeScript binding generation](pages/tools/typescript-bindings.md).



## Test modes

- `cargo test` runs the native contract tests.
- `thruput test` runs the RV32 artifact tests.
- `thruput test --integration` manages a local node for the integration tests.

See [Testing](pages/programming-model/testing.md) for the execution modes, generated integration environment, and how to add assertions.



## SDK layers

Generated projects start with the SDK’s contract and storage macros. Use typed storage handles for normal state access. Lower-level syscall wrappers are available when you need a custom abstraction.

These layers can be combined within a contract. Use [Storage Types](pages/programming-model/storage-types.md) to choose an API, [SDK Macros](pages/reference/sdk-macros.md) for macro reference, and [Rust API Docs](pages/tools/rust-api-docs.md) for exact signatures.

---

## Methods and interfaces

Source: <https://thruput.network/contracts/methods/>

Define contract state, expose methods, and share typed interfaces with Rust callers.

Start with a [generated project](pages/cli/create-project.md) so its host tests and RV32 entrypoint are configured.



## Define state and behavior

```rust
use sdk::storage::NNInt;
use sdk::*;

#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}

#[contract]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.try_get().none_if_missing().unwrap_or(0)
    }
}
```

`#[sdk::storage]` assigns each field a storage path. The field is a handle to persisted data, not an in-memory integer that you must save manually. `#[contract]` generates entrypoints, a `CounterClient`, and interface metadata.

`none_if_missing()` gives the never-written counter a zero default while preserving other storage errors. Do not turn every read error into zero with `unwrap_or(0)` on the original `Result`.



## Expose methods

Public methods on an inherent implementation become entrypoints. Private helper methods stay internal. Use `&mut self` to update through mutable storage handles and `&self` to read through shared handles. A method without a receiver does not need the generated storage struct.

Rust receiver mutability is separate from runtime call restrictions. Use [read-only child calls](pages/contracts/cross-contract-calls.md#gas-limits) when the runtime must reject state changes.

Exported methods return their normal values. Use [contract exceptions](pages/contracts/errors.md) for failures.



## Share an interface

Put a trait in a shared interface crate when callers need the interface without importing its implementation:

```rust
use sdk::*;

#[contract]
pub trait CounterApi {
    fn increment(&mut self, amount: u64);
    fn get(&self) -> i128;
}
```

This generates `CounterApiClient`. Mark the trait implementation with `#[contract]` too. Declare `throws` and `emits` on the trait definition, not again on its implementation.

For a self-contained contract, the inherent implementation in the first example is enough. The [macro reference](pages/reference/sdk-macros.md#contract) lists parameters and reserved method names.



## Define argument and return types

```rust
#[contract_type]
pub struct CounterSummary {
    pub value: i128,
    pub owner: ContractAddress,
}
```

`#[contract_type]` supplies serialization and spec metadata. Use `Value<T>` when plain data must persist; choose other [storage types](pages/programming-model/storage-types.md) for other update patterns.



## Initialize and generate bindings

Initialization is an ordinary method, not an automatic constructor. Enforce one-time initialization when required and [initialize atomically with deployment](pages/cli/deploy-and-call.md#include-initialization).

Rust callers use generated clients. [Generate client bindings](pages/contracts/client-bindings.md) to share the built contract interface with TypeScript applications. Keep bindings and deployment addresses from the same interface build.

---

## Contract Execution

Source: <https://thruput.network/programming-model/execution/>

The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.

Your contract reads from a frozen snapshot and produces typed storage changes, called deltas. Ordinary storage reads do not see other transactions’ writes. The runtime checks whether each transaction’s deltas can coexist with the other changes landing in the block. Deltas that can coexist form the next committed state. Transactions with conflicting deltas are excluded and returned to the mempool.

This page is the contract-author model. Read it before choosing storage types. It explains the behavior your contract relies on without requiring the engine’s lock and reservation implementation.



## Snapshot Isolation

All transactions in a block read the same committed state from the previous block. Ordinary storage reads do not see another transaction’s writes within the block. Reads include changes made within your transaction, including successful child calls. Other transactions cannot change the snapshot you read.

The shared snapshot is a useful database analogy, but Stellar Thruput has its own typed delta merge rules.

`RetrocausalQueue` has separate observation rules: a consumer can observe concurrent inserts in the same block. The proposer records these observations for validator replay.



## Merged Deltas

A delta describes how one transaction changes a storage location. It is not necessarily an arithmetic difference. The storage type gives the delta its meaning and defines whether it can coexist with other changes to the same location.

For a `Balance`, the delta is an increase or decrease. When you write:

```rust
self.balance.lazy_increase(5);
```

This says “add 5 to the balance.” It does not say “set the balance to 105.”

Suppose two transactions read a balance of 100:

```text
Tx A: lazy_decrease(20)
Tx B: lazy_decrease(30)
Both land: 100 - 20 - 30 = 50
```

Both changes can land because addition gives the same result in either order and the combined debit fits within the balance. We say the operations **commute**, and the runtime can merge their deltas. If the transactions instead try to debit 80 and 30, the combined debit is too large, so one or more transactions are excluded.

Merge rules depend on the storage type:

- `Balance` combines increases and decreases while keeping the committed value non-negative.
- `NNInt` exposes lower-level signed changes and explicit bases.
- Changes to different `Map` keys are independent.
- Two `Value` writes to the same key can coexist only when they store the same value.

In these docs, **compatible deltas** means the storage type allows both changes to land. See [`Balance`](pages/programming-model/storage-types.md#balance) for the ordinary balance API and [NNInt and concurrent updates](pages/programming-model/nnint.md) for the underlying `set_add` rules.



## Block Lifecycle

1. **Read and execute:** your contract reads the block snapshot plus its own changes and successful child calls. It records typed deltas.
2. **Reserve:** after the root call succeeds, the runtime checks whether the complete delta batch can coexist with the proposal’s other changes.
3. **Commit or exclude:** admissible transactions contribute to the finalized block. Conflicting transactions return to the mempool.

Your contract does not control these phases. [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) covers submission through finalization; [Parallel Execution](pages/how-it-works/execution-model.md) explains the reservation machinery.



## Exclusion

From your contract’s perspective, a conflicting transaction simply doesn’t land. Your code runs, produces deltas, and the system determines whether that completed delta batch is compatible with other transactions in the block. Incompatible transactions are excluded and returned to the mempool. See [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the engine-level details.

Clients keep the submitted hash and observe its outcome. A pending result is not a reason to sign a replacement transaction. See [Track transaction results](pages/typescript/transaction-status.md). Storage choices determine which changes can coexist; see [Storage Types](pages/programming-model/storage-types.md).



## Gas

Transactions and cross-contract calls specify a gas limit. Gas bounds computation, including work in child calls, but costs zero tokens.

For root transactions, the gas limit is the scheduling quantity. The scheduler accounts for the amount you declare whether execution uses all of it or only part of it. If execution exceeds the limit, the transaction faults and its contract changes are discarded.

Unused child-call gas can return to the caller’s execution budget. That is not a token refund and does not change the root transaction’s scheduling amount.

```rust
let client = TokenClient::new(&token_address);
client.with_gas_limit(100_000).transfer(&to, amount);
```

Gas has no token fee, but lower gas limits use less scheduling capacity. Choose a limit that covers execution and design storage operations to avoid unnecessary conflicts.

Stellar Thruput needs no gas price estimation because the token price of gas is zero. Gas usage still matters when choosing an execution limit.



## Throughput

Your unlocked native-token balance provides scheduling capacity. Compatible storage changes do not guarantee inclusion in the next block: admission, capacity, propagation, and expiry still matter. See [Balance-Proportional Scheduling](pages/how-it-works/storage-economics.md#balance-proportional-scheduling) for the allocation rules.



## Storage Costs

The address that owns stored data funds its deposit. The runtime accounts for storage changes; your contract does not calculate the deposit itself. See [Storage: Refundable Deposits](pages/how-it-works/storage-economics.md#storage-refundable-deposits) for funding and cost rules.

Next, [Storage Types](pages/programming-model/storage-types.md) turns this model into concrete API choices.

---

## Storage Types

Source: <https://thruput.network/programming-model/storage-types/>

SDK storage types, their conflict semantics, and how to choose between them.

The SDK storage layer exposes the types you use to model contract state. The type you choose determines whether concurrent writes merge, conflict, or ignore each other. At the protocol level, the primitives are `NNInt`, `Bytestring`, and `RetrocausalQueue`. `Balance` and `CapacityConstraint` provide narrower APIs over the integer primitive. `Map`, `Value`, `Vector`, and `Node` provide typed composition.

This page explains behavior and tradeoffs. For exact method signatures, see [Storage Types Reference](pages/reference/storage-types.md) or [`sdk::storage` Rustdoc](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html).



## NNInt

Integer storage for signed changes that concurrent transactions can combine. Use it for counters or state models that need signed adjustments or an explicit `set`.

```rust
use sdk::storage::NNInt;

#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}
```

With a snapshot value of `100`, these changes can merge:

```rust
// Two transactions run against a snapshot value of 100:
self.value.strict_inc(5);    // Tx A: "add 5"
self.value.strict_inc(-3);   // Tx B: "subtract 3"
// If both transactions are admitted, the result is 102.
```

Pass negative values to `strict_inc` to subtract. With a nonnegative base, the runtime prevents concurrent decrements from driving the value below zero. `NNInt` also permits an explicit negative `set`, which changes its commit-time floor. Use `Balance` when negative values and absolute replacement should not be part of the contract API.

See [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the contract-level model. The underlying `set_add` representation and exact commutativity rules are covered in [NNInt and concurrent updates](pages/programming-model/nnint.md).



## Balance

Nonnegative, zero-defaulting storage for balances, allowances, and supply. `Balance` uses `i128` amounts, rejects negative inputs, and exposes no signed adjustment or absolute `set`.

```rust
use sdk::storage::{Balance, Map};

#[derive(Debug)]
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

Each direction has a checked and lazy form:

```rust
let sender = get_caller();

// Load the sender and fail during execution if funds are insufficient.
self.balances.at_mut(&sender).decrease(amount);

// Skip the receiver load and defer its bound check.
self.balances.at_mut(receiver).lazy_increase(amount);
```

All four adjustment methods record deltas that can merge with compatible transactions:

| Method                  | Snapshot base      | Snapshot-bound result                        | Deltas merge? |
| ----------------------- | ------------------ | -------------------------------------------- | ------------- |
| `increase(amount)`      | Loaded if needed   | Overflow detected during contract execution  | Yes           |
| `decrease(amount)`      | Loaded if needed   | Underflow detected during contract execution | Yes           |
| `lazy_increase(amount)` | Not forced to load | Overflow decided during delta reservation    | Yes           |
| `lazy_decrease(amount)` | Not forced to load | Underflow decided during delta reservation   | Yes           |

The `try_` variants report errors that are available during contract execution, so a contract can translate an immediate failure into a domain error. Lazy variants cannot report a snapshot-bound failure that they deliberately did not load. They can still report conversion and transaction-local accumulated-delta errors.



## Map\<K, V>

Key-value store. Different keys use independent storage locations. Same-key behavior follows the value type’s rules. Other shared writes or storage-funding limits can still prevent the complete transactions from landing together.

```rust
use sdk::storage::{Balance, Map};

#[derive(Debug)]
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

```rust
// Different keys: always independent, never conflict
self.balances.at_mut(&alice).lazy_increase(10);  // Tx A
self.balances.at_mut(&bob).lazy_increase(20);    // Tx B, no interaction

// Same key: follows Balance rules (compatible deltas merge)
self.balances.at_mut(&alice).increase(10);       // Tx A
self.balances.at_mut(&alice).lazy_increase(20);  // Tx B, merges to +30
```

Maps can nest: `Map<K, Map<K2, Balance>>` gives composite keys with independent conflict domains at each level. The ERC-20 allowance pattern uses this for owner and spender pairs.



## Bytestring

Raw bytes. Concurrent writes of the same value commute. Concurrent writes of different values conflict.

```rust
use sdk::storage::Bytestring;

#[derive(Debug)]
#[sdk::storage]
pub struct Config {
    owner: Bytestring,
}
```

```rust
self.owner.set(&new_owner);    // Tx A
self.owner.set(&other_owner);  // Tx B -- conflict, one excluded
```

Use Bytestring for raw configuration or metadata. Writers of different values to the same location conflict; writers of identical values can coexist.



## RCQ\<T> / RetrocausalQueue

Multi-producer queue. Inserts commute; consumption is sequential. Persisted entries are ordered by queue block, then lexicographically within that block. Concurrent observations follow the proposer-recorded order.

```rust
// These two transactions can both land:
self.requests.insert(&entry_a);  // Tx A
self.requests.insert(&entry_b);  // Tx B -- no conflict

// Consumes pull from the front of the queue
let entry = self.requests.try_consume();
```

Use `RCQ<T>` when producers are concurrent but consumers process items in order. Lower-level raw functions are available when you need byte-level control.



## CapacityConstraint

A commit-time limit shared by changes from multiple transactions. Use it when one transaction cannot determine whether a block-wide linear constraint will still hold, such as an aggregate withdrawal limit.

```rust
use sdk::storage::CapacityConstraint;

#[sdk::storage]
pub struct WithdrawalLimit {
    remaining: CapacityConstraint,
}
```

```rust
// Reset at the start of a period.
self.remaining.set_capacity(period_limit);

// Each withdrawal consumes capacity without loading competing withdrawals.
self.remaining.consume_capacity(amount);
```

Consumption is staged on the handle and written when the handle is flushed or dropped. The runtime enforces that the committed remaining capacity does not fall below its floor. `set_capacity` must be the first write to that constraint in the transaction, except that repeating the same value is allowed.



## Vector\<S>

Ordered collection. Each element is an independent storage slot. Internally backed by a `Map<u32, S>` for elements and a length counter.

```rust
use sdk::storage::{Vector, Node, Value};

#[derive(Storage)]
pub struct Item {
    value: Value<u64>,
}

#[derive(Debug)]
#[sdk::storage]
pub struct Registry {
    items: Vector<Node<Item>>,
}
```

```rust
// Push a new element
self.items.push_with(|item| {
    item.value.set(&42);
});

// Read by index (bounds-checked)
let val = self.items.at(0).value.get();

// Mutate by index
*self.items.at_mut(0).value.load_mut() = 99;

// Iterate
for item in &self.items {
    let v = item.value.get();
}
```

Different indices are independent and never conflict (same as Map). Same-index writes follow the element type’s rules. Pushes conflict with other pushes (the length counter is not an NNInt, so concurrent length changes are mutually exclusive).

Use Vector for ordered collections where elements are accessed by index. Wrap compound structs in `Node<T>` so storage derivation works through the nesting. For hot concurrent writes, Map with application-managed keys is more parallelism-friendly than Vector with pushes.



## Value\<T>

Typed storage slot. Stores any CXS-serializable value. Conflict semantics are the same as Bytestring: concurrent writes of the same value commute, different values conflict.

```rust
use sdk::storage::Value;

#[derive(Debug)]
#[sdk::storage]
pub struct Config {
    owner: Value<ContractAddress>,
    threshold: Value<u64>,
}
```

```rust
let owner = self.owner.get();             // read (aborts if unset)
let result = self.threshold.try_get();    // read without aborting
self.owner.set(&new_owner);               // write
*self.threshold.load_mut() = 10;          // read-modify-write
```

Use `Value<T>` for typed single-slot storage. Use `Bytestring` when you need raw byte access or variable-length data without a fixed schema.



## Choosing a Type

| If your write pattern is…                       | Use                | Why                                                            |
| ----------------------------------------------- | ------------------ | -------------------------------------------------------------- |
| Nonnegative balance, allowance, or supply       | Balance            | Nonnegative amounts, zero default, and checked or lazy deltas. |
| Signed delta or explicit integer base           | NNInt              | Signed deltas merge and `set` controls the base.               |
| Block-wide linear limit                         | CapacityConstraint | Concurrent transactions consume shared commit-time capacity.   |
| `INSERT INTO ... (key, value)` with unique keys | Map                | Different keys are independent.                                |
| Ordered list, accessed by index                 | Vector             | Per-element independence. Pushes are exclusive.                |
| Store a typed value                             | Value\<T>          | Typed Bytestring. Same conflict rules.                         |
| `col = absolute_value` (raw bytes)              | Bytestring         | Accept that concurrent writes conflict.                        |
| Append to a log or work queue                   | RCQ\<T>            | Inserts merge, consumers are sequential.                       |



## Exclusive Writes

Use exclusive writes when an operation needs sole write access to a storage location for the duration of a block. Compatible deltas normally merge; an exclusive write prevents concurrent modifications to that key.

- `Value<T>::set_exclusive(&v)`: typed slot, exclusive write.
- `Map::at_mut_exclusive(&key)`: exclusive mutator on a Map entry.
- `NNInt` and `Bytestring` honour the **exclusive keypath flag** set on the field at storage-derivation time, or via the lower-level free functions `non_negative_int_set_exclusive` / `bytestring_set_exclusive`.

```rust
self.config.set_exclusive(&new_value);          // Value<Config>
self.counters.at_mut_exclusive(&owner).set(v);  // Map<_, NNInt>
```

If two concurrent transactions write exclusively to the same key, one is excluded. Mixing exclusive and non-exclusive writes to the same key in the same block excludes the non-exclusive writers. Prefer `Balance` or `NNInt` deltas when the operation can tolerate concurrent updates.



### Lock Requests

An exclusive write requests `ExclusiveLock` after the write succeeds. Later ordinary writes to the key in the same transaction keep the request, including writes from other call frames. The admitted transaction then holds the key’s exclusive lock for the whole block. `clear_flags` withdraws the request.

```rust
self.counters.at_mut_exclusive(&owner).set(0);
self.counters.at_mut(&owner).inc(1);  // The lock request remains.
```

Leaf handles (`Value`, `NNInt`, `Balance`, and `Bytestring`) implement `Flaggable`. Import it with `use sdk::storage::Flaggable;`. `flags()` reads the flags, `set_flags(flags)` adds flags, and `clear_flags()` removes them. Setting flags requires a pending write to that key in the current call frame.

The raw-key functions `storage_flags`, `set_storage_flags`, and `clear_storage_flags` provide the same operations for a `StorageKey`. A reverted frame or failed `try_invoke` discards its flag changes along with its writes. See [Storage Flags](pages/reference/syscalls.md#storage-flags) for the host API.

If `Balance` covers your state model, you do not need its lower-level representation. Read [NNInt and concurrent updates](pages/programming-model/nnint.md) when you need signed changes, an explicit base, or the exact `set_add` commutativity rules. For runtime reservation details, continue to [Parallel Execution](pages/how-it-works/execution-model.md).

---

## NNInt and concurrent updates

Source: <https://thruput.network/programming-model/nnint/>

The set_add primitive underneath NNInt and why concurrent transactions merge.

`NNInt` is the lower-level signed-integer storage API underneath [`Balance`](pages/programming-model/storage-types.md#balance). This page explains its `set_add` representation and why concurrent transactions can merge safely.

Most contracts should use `Balance` for balances, allowances, and supply. Read this page when you need signed changes, an explicit integer base, or the exact representation that makes checked and lazy balance deltas compatible.

For exact SDK method signatures, see [Rust API Docs](pages/tools/rust-api-docs.md) or [Storage Types Reference](pages/reference/storage-types.md#nnint).



## The set_add Primitive

Every NNInt storage location maintains two pending values during a transaction:

- **set**: `i128`. The absolute base value.
- **add**: `i128`. The accumulated delta.

The low-level operation is `set_add(set_value, add_value)`. It replaces both pending values. The final committed value is `set + add`, subject to overflow, reservation, and floor checks.

Despite the protocol name `NonnegativeInt`, current source allows an explicit negative `set`. The storage invariant is:

```text
value >= min(set, 0)
```

So `set(-5)` may commit `-5`, and `set_add(-5, 10)` may commit `5`. The engine still rejects subtracting from an already-negative explicit base, such as `set_add(-5, -1)`. Use `Balance` for ordinary balances. Use `NNInt` when the state model needs signed changes or an explicit base.

The storage handle exposes `strict_inc`, `inc`, and `set`. These methods map to the lower-level `set_add` operation.



## The One Rule

Two concurrent `set_add` calls commute **if and only if their resolved set values are equal**.

The bases must match each other; they do not have to equal the snapshot value.

| Tx A              | Tx B                         | Result                                                  |
| ----------------- | ---------------------------- | ------------------------------------------------------- |
| `set_add(S, x)`   | `set_add(S, y)`              | Merge: same base, adds combine to `x + y`               |
| `set_add(100, x)` | `set_add(100, y)`            | Merge: same explicit base, even if snapshot != 100      |
| `set_add(A, x)`   | `set_add(B, y)` where A != B | **Conflict**: different bases, one transaction excluded |

Same base + different deltas = merge. Different bases = conflict. The merged value still has to fit in `i128` and satisfy `value >= min(set, 0)`.



## The None Path

`set_add` also accepts `None` as the set value: `set_add(None, add_value)`. This means “I don’t need to choose the base in this invocation. Let the runtime resolve it from the snapshot.”

The runtime resolves `None` to the start-of-block value internally. This is a performance optimization: it produces the same result as forcing the snapshot read yourself when the key already contains an NNInt, but skips that read in the contract invocation. If the key is absent or not an NNInt, the `None` path resolves to `0`.

Since `None` resolves to the start-of-block value, commutativity depends on what the other transaction does:

| Tx A               | Tx B                                | Commutes? | Why                                                                 |
| ------------------ | ----------------------------------- | --------- | ------------------------------------------------------------------- |
| `set_add(None, x)` | `set_add(None, y)`                  | Yes       | Both resolve to the same start-of-block value. Same effective base. |
| `set_add(None, x)` | `set_add(S, y)` where S = snapshot  | Yes       | None resolves to the snapshot NNInt value. Same effective base.     |
| `set_add(None, x)` | `set_add(S, y)` where S != snapshot | **No**    | Different resolved bases. Conflict.                                 |



## How the API Maps to set_add

| Method              | Effective call                                       | Loads the base if needed? | Commutes?                                         |
| ------------------- | ---------------------------------------------------- | ------------------------- | ------------------------------------------------- |
| `strict_inc(delta)` | `set_add(Some(base), accumulated + delta)`           | Yes                       | When resolved bases match                         |
| `inc(delta)`        | `set_add(existing_set_or_None, accumulated + delta)` | No                        | When resolved bases match                         |
| `set(value)`        | `set_add(Some(value), 0)`                            | No                        | Only if all concurrent callers set the same value |

**strict_inc(delta)**: loads the current base (pending explicit set, snapshot NNInt, or `0` for an empty key), checks that this invocation’s total is nonnegative, then calls `set_add(Some(base), accumulated + delta)`. Aborts immediately if this invocation’s result would be negative. Use this when lower-level integer state needs an early underflow check.

**inc(delta)**: preserves the pending set value if one already exists in this invocation; otherwise calls `set_add(None, accumulated + delta)`. Skips the forced snapshot read. Underflow is caught later by runtime reservation/floor checks when no explicit base has been loaded, which can be harder to debug.

**set(value)**: calls `set_add(Some(value), 0)`. Replaces the base and clears the delta. Negative values are allowed, and a negative set value becomes the floor. `set` commutes only when all concurrent callers set the same value. `set(100)` vs `set(100)` merges. `set(100)` vs `set(200)` conflicts. `set(100)` vs `strict_inc(5)` conflicts if the snapshot is not 100, commutes if it is. Reserve `set` for initialization or admin operations.

`strict_inc` and `inc` can merge when their resolved bases match. Choose between them based on the read cost and need for early underflow detection.



## Negative Set Values

Use a negative base only when the state model needs an explicit lower floor:

```rust
non_negative_int_set(key, -5);
non_negative_int_inc(key, 1);  // The value becomes -4.
```

An increment can move a negative base upward without making the result nonnegative. The commit-time floor remains `value >= min(set, 0)`. `strict_inc`, however, rejects an invocation total that remains negative.

Use `Balance` for ordinary balances and allowances. Use nonnegative NNInt bases for ordinary counters.



## Why This Matters

For NNInt writes that resolve to the same base, transaction ordering does not affect the merged value. The deltas are addition, and addition commutes.

Matching bases are required, but do not guarantee inclusion: aggregate bounds and other transaction changes still matter. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the contract-level model.

---

## Authorization

Source: <https://thruput.network/how-it-works/authorization/>

How transaction signatures, address auth data, caller identity, and auth tokens work in Stellar Thruput.

Stellar Thruput treats addresses uniformly. An address can hold code, store auth data, receive calls, and originate transactions through either supported admission model.

Authorization has two layers:

1. **Transaction admission**: hogd checks the transaction’s auth claim and signatures before execution.
2. **Runtime authorization**: contracts use caller identity, explicit signature checks, and typed auth tokens while executing.

These layers are related but separate. Transaction admission decides whether the root transaction may enter the block. Runtime authorization decides what authority a contract gives to a caller or token it receives.



## Authorize an application operation

For an owner-controlled method, store the owner in `Value<ContractAddress>` and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), AccessError::NotOwner);
```

Define `AccessError` with [a contract exception](pages/contracts/errors.md#defining-errors). Initialize the owner through a guarded method and [deploy and initialize atomically](pages/cli/deploy-and-call.md#include-initialization) if the first caller becomes the owner.

`get_caller()` identifies the immediate caller. A forwarded call identifies the forwarding contract, not the original user. For authority passed through several frames, use the [typed auth-token model](pages/how-it-works/authorization.md#auth-tokens-and-signedt) below and validate its minter and payload.



## Transaction Admission

A `SignedTransaction` contains an inner transaction plus decorated signatures:

```text
struct DecoratedSignature {
  unsigned int public_key_id;
  Signature signature;
};

struct SignedTransaction {
  Transaction tx;
  DecoratedSignature signatures<>;
};
```

The source address is the root invocation’s `invoked_address`. Every transaction signature covers this preimage:

```text
cxs(DomainSeparator("Transaction")) || networkHash || txs(transaction)
```

`txs(value)` denotes its standard XDR encoding. The domain separator prevents a transaction signature from being interpreted as a signature over another object. The network hash binds the signature to one Stellar Thruput network and prevents cross-network replay.

The canonical transaction hash is `sha256(txs(transaction))`. It identifies the inner transaction and excludes signatures. It is distinct from both the signature preimage and the encoded `SignedTransaction` wrapper.



## Admission Models

The transaction’s `AuthClaim` selects one of two admission models:

```text
enum AuthClaim switch (AuthClaimType claim_type) {
case kSourceAddressAuthData:
  struct {
    BitMap allowed_keys;
    Weight required_weight;
  } source_address_claim;

case kPubkeySignature:
  PubkeyAccountPreimage pubkey_preimage;
};
```



### Pubkey Accounts

`kPubkeySignature` authorizes an account whose address is derived from `PubkeyAccountPreimage { pubkey, nonce }`. hogd accepts the claim only when:

- the derived address equals the root invocation’s `invoked_address`;
- the source address has no registered `AddressAuthData`;
- the transaction has exactly one Ed25519 signature, with `public_key_id` 0;
- that signature verifies against the public key in the preimage.

During root execution at an undeployed pubkey-account address, the runtime falls back to the network’s configured DefaultWallet contract. This gives a new pubkey account wallet behavior without first deploying code at its derived address. The fallback applies only to the root invocation.



### Source-Address Accounts

`kSourceAddressAuthData` authorizes the root invocation from auth data stored at its source address. The source address must have `AddressAuthData`; a source-address claim without it is rejected.

hogd checks:

- `allowed_keys` does not set bits beyond `kMaxSigners = 21`.
- Every signature’s `public_key_id` appears in `allowed_keys`.
- Signature `public_key_id` values are strictly increasing, so duplicates and out-of-order signatures are rejected.
- Each referenced key exists in the source address’s `AddressAuthData`.
- Each signature verifies against its registered public key. The current helper path supports Ed25519.
- The sum of matched key weights is at least `max(address.required_weight, claim.required_weight)`.

The threshold is `max(address.required_weight, claim.required_weight)`. This lets the address set a standing minimum while each transaction can require an equal or higher threshold.

Contracts can inspect the root transaction’s auth claim with [`get_auth_claim()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/auth_claim/fn.get_auth_claim.html), but admission has already happened by the time contract code runs.



## Address Auth Data

`AddressAuthData` is stored under `StorageKeyType::AuthData` for an address:

```text
struct PublicKeyConfig {
  PublicKey key;
  Weight max_weight;
};

struct AddressAuthData {
  PublicKeyConfigOpt public_keys[21];
  Weight required_weight;
  BlockHeight last_written_height;
};
```

Each key slot is optional. Empty slots do not contribute weight.

An address can mutate only its own auth data. The SDK exposes the current syscalls as:

```rust
use sdk::{
    add_address_public_key,
    remove_address_public_key,
    set_address_required_weight,
};

add_address_public_key(0, public_key, 1)?;
set_address_required_weight(1)?;
remove_address_public_key(0)?;
```

Use these for source-address accounts, wallet contracts, and contracts that are meant to originate later transactions. Replay protection is transaction-level, through the transaction `Uniquifier`. `AddressAuthData` does not contain nonce policy or gas-sponsorship policy fields.



## Caller Identity

Inside a contract, [`get_caller()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_caller.html) returns the direct caller of the current invocation frame:

```rust
use sdk::get_caller;

let caller = get_caller();
```

This is Stellar Thruput’s equivalent of `msg.sender`: immediate caller identity. It is not a signer set and it does not tell you which key signed the root transaction. A root frame has no caller, so the underlying syscall errors there.

Use [`get_current_address()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_current_address.html) when a contract needs its own address.



## Contract Signature Checks

Contracts can verify arbitrary messages with [`verify_signature_ed25519()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/crypto/fn.verify_signature_ed25519.html):

```rust
use sdk::verify_signature_ed25519;

let ok = verify_signature_ed25519(&public_key, &signature, message);
```

This is runtime logic, separate from transaction admission. A wallet contract can use it to accept an off-chain signature, apply its own policy, and then mint an auth token in the wallet contract’s name.



## Auth Tokens and `Signed<T>`

The SDK’s [`Signed<T>`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/struct.Signed.html) is a typed runtime auth-token handle. It is not a cryptographic signature and it is not a durable bearer token.

An auth token carries:

- **Minter**: set by the host to the current contract address at mint time.
- **Consumer**: the contract address allowed to consume the token.
- **Payload**: CXS-encoded typed data from the SDK.
- **Expiry height**: the token is valid through this block height.
- **Child nodes**: nested auth tokens that materialize when the parent is consumed.

`Signed<T>` is a handle to this runtime token. The handle travels out-of-band alongside calldata; it does not serialize the payload into the method argument bytes. Contract specifications represent it as a `SignedToken` node containing the payload type.

To make a payload type usable in a token, mark it as a contract type:

```rust
use sdk::*;

#[contract_type]
pub struct TransferAuth {
    pub to: ContractAddress,
    pub amount: i128,
}
```

Mint with [`mint_auth_token()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/fn.mint_auth_token.html):

```rust
use sdk::*;

let token: Signed<TransferAuth> = mint_auth_token(
    expiry,
    AuthTokenPreimage {
        consumer: token_contract,
        data: TransferAuth { to, amount },
    },
);
```

Consume with `Signed<T>::consume()`:

```rust
use sdk::*;

pub fn transfer_from(
    amount: i128,
    to: &ContractAddress,
    auth: Signed<TransferAuth>,
) {
    let (claim, minter) = auth.consume();

    assert!(minter == expected_wallet(), "unauthorized minter");
    assert!(claim.to == *to, "unauthorized recipient");
    assert!(amount <= claim.amount, "exceeds authorized amount");

    // Move funds from `minter` to `to`.
}
```

Consuming proves only two things: the token was minted by the returned `minter`, and the token was destined for the current contract. Any contract can mint a token whose payload decodes as `TransferAuth`. Always check the returned minter against an address your contract trusts before acting on the payload.



## Passing Auth Tokens

Auth tokens never flow implicitly across contract calls. Generated clients collect `Signed<T>` handles from arguments and pass those token ids to `Invoke` beside calldata. A callee receives only the tokens that appeared in its arguments.

Frame ownership works like this:

- When a parent forwards a token to a child call, the child owns that token while it runs.
- If the child returns the token in its return value, the parent receives it back.
- If the child aborts or the parent handles a reverted child frame, forwarded tokens are restored to the parent.
- If the child succeeds without returning a forwarded token, the parent does not automatically regain it.
- Consuming a token removes it. Any child tokens become fresh handles owned by the consuming frame.

This makes method signatures part of the authorization surface: a function that does not take a `Signed<T>` argument cannot consume that token.

Generated clients assign returned token handles to `Signed<T>` fields in the return value. Lower-level callers that receive a `Vec<Signed<Opaque>>` can use `AssumeTokens::try_assume_tokens` to convert an exact number of opaque handles into a typed tuple. A count mismatch returns `CallingError::DecodingSuccess`; `AssumeTokens::assume_tokens` is the throwing convenience form.



## Nested Auth Tokens

A token payload can contain `Signed<U>` fields. When the outer token is consumed, the runtime creates child-token handles for those fields. Child tokens keep the same minter and expiry as the parent, but each child has its own consumer address and payload.

```rust
use sdk::*;

#[contract_type]
pub struct DexIntent {
    pub pool: ContractAddress,
    pub deadline: BlockHeight,
    pub min_received: i128,
    pub transfer: Signed<TransferAuth>,
}

pub fn execute_swap(intent: Signed<DexIntent>) {
    let (intent, trader) = intent.consume();

    assert!(trader == expected_wallet(), "unauthorized trader");
    assert!(get_block_height() <= intent.deadline, "intent expired");

    // The nested transfer token is now a fresh handle that can be passed to
    // the token contract selected as its consumer.
    token_client.transfer_from(amount_in, &intent.pool, intent.transfer);
}
```

The outer token might be consumed only by the DEX. The nested transfer token might be consumed only by the token contract. Attribution stays with the original minter through the chain.



## Limits

The protocol currently caps an auth-token payload at 256 bytes, tree depth at 4, and child nodes per token at 4. `MintAuthToken` rejects malformed token nodes, expired-at-mint tokens, and tokens that would exceed runtime caps. `ConsumeAuthToken` rejects tokens not owned by the current frame, expired tokens, and already-consumed handles.



## Not Landed

Do not rely on these patterns yet:

- Detached admission-time signatures that directly become `Signed<T>` values.
- Nonce or gas-sponsorship policy fields in `AddressAuthData`.
- Durable, storable, or off-chain portable `Signed<T>` handles. A `Signed<T>` is a runtime handle owned by invocation frames inside a transaction.



## See Also

- [Invocation Frames](pages/how-it-works/invocation-frames.md)
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)
- [Syscalls](pages/reference/syscalls.md)
- [SDK Macros](pages/reference/sdk-macros.md)
- [Rust API Docs](pages/tools/rust-api-docs.md)

---

## Handle errors

Source: <https://thruput.network/contracts/errors/>

How errors work in Stellar Thruput contracts.

Exported Stellar Thruput contract methods return their declared values and signal failure by throwing an exception. The frame aborts, all state changes in that frame are discarded, and control returns to the caller. Private helpers may use `Result` when they translate failures into a contract or library exception.

You cannot catch a thrown exception within the same frame. Use `Result`-returning helpers for local fallible work and generated `try_*` client methods for another contract. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md).

For exact SDK signatures, see [Rust API Docs](pages/tools/rust-api-docs.md).



## Defining Errors

Use `#[contract_exception]` to define error types. It generates `Debug`, `PartialEq`, serialization and spec traits, and the `Exn` implementation. Add `Clone` yourself if the type needs it.



### `thiserror` and `anyhow`

You can use `thiserror` with `#[contract_exception]` when you want `Display` messages for logs, tests, or off-chain tooling. Put `#[derive(thiserror::Error)]` on the exception type and use `#[error("...")]` on each variant:

```rust
use sdk::*;

#[derive(thiserror::Error)]
#[contract_exception]
pub enum CounterError {
    #[error("not authorized")]
    NotAuthorized = 1,
}
```

Do not copy the usual `#[derive(Error, Debug)]` pattern from generic Rust examples. `#[contract_exception]` already generates `Debug` and `PartialEq`; deriving them again creates duplicate implementations.

For contract crates, configure `thiserror` without the default `std` feature:

```toml
thiserror = { version = "2", default-features = false }
```

Avoid `anyhow` for contract exception types and public contract method surfaces. `anyhow::Error` is an erased application error type, while contract exceptions need concrete CXS-serializable types that appear in the contract spec. `anyhow` is fine in off-chain tools, build scripts, tests, or CLI code. Inside a contract, private helpers may use `Result` if they immediately convert failures into concrete contract exceptions with `throw`, `ensure`, or `or_throw`.



### Enum errors

Enum errors carry variant-level meaning. Each variant gets an explicit `i32` discriminant. The macro adds `#[repr(i32)]` for you.

```rust
use sdk::*;

#[contract_exception]
pub enum ERC20Error {
    AlreadyInitialized = 1,
    MustBeContractOwner = 2,
    TooLarge = 3,
    Internal = 100,
}
```



### Struct errors

Struct errors work when you only need a single error type with no variants.

```rust
use sdk::*;

#[contract_exception]
pub struct Unauthorized;
```

Structs with fields work too:

```rust
#[contract_exception]
pub struct InsufficientBalance {
    pub balance: u64,
}
```



## Throwing Errors



### `throw(exn)`

Aborts the current frame with the given error. Never returns.

```rust
use sdk::*;

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    if amount == 0 {
        throw(ERC20Error::TooLarge);
    }
    // ...
}
```



### `ensure(condition, error)`

Throws `error` if `condition` is false. A convenience wrapper around `throw`.

```rust
use sdk::*;

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    ensure(
        caller == self._contract_owner(),
        ERC20Error::MustBeContractOwner,
    );

    let diff = amount_to_diff(amount);
    self._adjust_balance(receiver, diff);
    self._adjust_total_supply(diff);
}
```



### `result.or_throw(exn)`

Extension method on `Result`. Returns the `Ok` value, or throws `exn` on `Err`. Useful for converting fallible operations into contract exceptions.

```rust
use sdk::*;

pub fn amount_to_diff(n: u128) -> i128 {
    n.try_into().or_throw(ERC20Error::TooLarge)
}
```



## Automatic Aborts

The SDK throws `LibraryExn` errors automatically when internal preconditions fail. You do not need to define error variants for these.

| Operation                                 | Throws when                                                                                         |
| ----------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `strict_inc(delta)`                       | Result would be negative (`NonNegativeIntUnderflow`)                                                |
| `strict_inc(delta)`                       | Result would overflow (`NonNegativeIntOverflow`)                                                    |
| `Balance::decrease(amount)`               | Balance is insufficient (`NonNegativeIntUnderflow`)                                                 |
| `Balance::increase(amount)`               | Balance would overflow (`NonNegativeIntOverflow`)                                                   |
| `CapacityConstraint::set_capacity(value)` | Another non-idempotent write already occurred this transaction (`CapacityConstraintAlreadyWritten`) |
| `bytestring_get_sized`                    | Stored length does not match expected (`BytestringWrongSize`)                                       |
| Storage read                              | Key does not exist (syscall error)                                                                  |

```rust
// Aborts automatically if balance would go below zero.
// No error handling code needed.
balance.decrease(amount);
```

Every public SDK function whose name starts with `try_` reports its own failures through `Option` or `Result` instead of aborting. Storage `try_` getters return `Result<T, LibraryExn>`. Use `error.is_storage_missing()` to identify absence, or `.none_if_missing()` to convert only absence into `None` while re-throwing other failures.



## LibraryExn

`LibraryExn` is the SDK’s built-in error enum. It covers all errors generated by SDK internals and runtime operations.

| Variant                                              | Discriminant | Trigger                                                                                                                                                                                                 |
| ---------------------------------------------------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Syscall(SyscallExn)`                                | 0            | A host syscall returned an error (e.g. storage key not found)                                                                                                                                           |
| `Handling(HandlingError)`                            | 1            | Error while handling an incoming contract call (decoding args, encoding result)                                                                                                                         |
| `Calling(CallingError)`                              | 2            | Error while making an outgoing contract call: encoding args, decoding the result, or the runtime refusing the invoke as reentrant (`Reentrance`) or past the cross-invoke depth bound (`DepthExceeded`) |
| `Called(FaultString)`                                | 3            | The called contract reverted                                                                                                                                                                            |
| `AuthToken(AuthTokenError)`                          | 4            | Error encoding or consuming an authorization token                                                                                                                                                      |
| `BytestringWrongSize { expected, found }`            | 5            | A fixed-size bytestring read found a different length                                                                                                                                                   |
| `NonNegativeIntUnderflow`                            | 6            | An integer or balance operation would violate its lower bound                                                                                                                                           |
| `NonNegativeIntOverflow`                             | 7            | An integer or balance operation would overflow                                                                                                                                                          |
| `StorageSerialization`                               | 8            | A typed storage value could not be serialized or deserialized                                                                                                                                           |
| `StorageIndexOutOfBounds { len, access }`            | 9            | A vector index was outside its logical extent                                                                                                                                                           |
| `StorageKeypathOverflow`                             | 10           | A no-allocation storage keypath exceeded its fixed budget                                                                                                                                               |
| `RetrocausalQueueEntryWrongSize { expected, found }` | 11           | A fixed-size queue read found a different entry length                                                                                                                                                  |
| `CapacityConstraintAlreadyWritten`                   | 12           | `set_capacity` followed an incompatible write in the same transaction                                                                                                                                   |
| `UnknownMethod`                                      | 13           | The callee has no entrypoint for the invoked method ID                                                                                                                                                  |

`LibraryExn` is `#[non_exhaustive]`: when matching, always include a wildcard arm.

Generated `try_*` calls can return a `LibraryExn` thrown by the callee. See [Library errors](pages/contracts/errors.md#library-errors) below for an example.



## Cross-Contract Errors

A thrown exception travels as `[selector][payload]`, where the selector is derived from the exception *type*, not from the interface that threw it. Callers match on that selector, so what a caller can catch does not depend on what the callee’s interface declared.

`throws` declares an interface’s error contract: it is published in the contract spec and tells callers what to expect. It does not gate catching.



### Declaring thrown errors

Single error type:

```rust
#[contract(client = CounterClient, throws = CounterError)]
impl Counter {
    // ...
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    // ...
}
```



### Catching errors with `try_*` methods

Every method on the generated client has a `try_` variant returning `Result<T, CallError>` instead of aborting. `CallError` is the same type for every client; a caught exception stays undecoded inside it, and `match_exn!` decodes it against the types you name:

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(val) => {
        // Success
    }
    Err(CallError::Fault(f)) => {
        // The called contract panicked
    }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => {
            // Handle the expected error
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Fault`, `Invalid`, and encode/decode failures with ordinary `match` arms on `CallError`. `match_exn!` handles only the typed part, and its arms are tried in order, so a final `_` arm is required.



### Library errors

`LibraryExn` is matched like any other exception type. There is no special wrapper variant:

```rust
match client.try_do_something() {
    Err(e) => match_exn!(e, {
        LibraryExn::NonNegativeIntUnderflow => {
            // The called contract underflowed an NNInt
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```



### Non-try calls and re-throwing

Non-try client methods (e.g. `client.do_something()` without the `try_` prefix) automatically re-throw any exception from the called contract. The error propagates through the call chain with its original selector intact.



### Undeclared errors

An error type absent from `throws` is caught exactly like a declared one. The selector identifies it either way:

```rust
match client.try_throw_undeclared() {
    Err(e) => match_exn!(e, {
        SecretError => {
            // Never declared by the interface; matched all the same
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```

This is what lets an extension define errors the base interface does not declare. `ERC20PausableError::EnforcedPause` can come back from `ERC20::transfer`, and an `ERC20Client` caller matches it in the same `match_exn!` as `ERC20Error`, no separate decode step, and no coupling of the base interface to the extension.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&to, 1).unwrap_err().try_as(),
    Some(ERC20PausableError::EnforcedPause),
);
```

`None` covers all three ways this can miss: no exception, a different type, or a payload that failed to decode. Use `try_decode` when the last of those must be distinguished from the other two. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one), which also explains how this can occur through semver-compatible evolution.

See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) for the full calling patterns.

---

## Events

Source: <https://thruput.network/contracts/events/>

Define, declare, emit, and test typed events in a Rust contract.

Events expose contract activity to applications. A contract emits topics for filtering and a payload for the data consumers need to read. Use storage for state your contract must read later; contracts cannot read events back.



## Define an event

```rust
use sdk::*;

#[derive(Event, Clone, Debug)]
pub struct CounterIncremented {
    #[topic]
    pub by: ContractAddress,
    pub amount: u64,
}
```

`#[derive(Event)]` generates the event signature, topic encoding, and a payload type. Topic 0 is the signature. Up to two fields can use `#[topic]`; fields without it go into the CXS-encoded payload.

Here, consumers can filter on `by` and read `amount` from the payload. Strings and byte slices used as topics retain only a hash, so also include them in the payload if consumers need their original values. The total size of topics and payload is limited to 1,024 bytes.



## Declare and emit it

Add the event to a counter method to record the amount and caller:

```rust
use sdk::storage::NNInt;

#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}

#[contract(emits(CounterIncremented))]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
        log_event(&CounterIncremented {
            by: get_caller(),
            amount,
        });
    }
}
```

`get_caller()` identifies the immediate caller of this frame. For a forwarded call, that is the forwarding contract.

`emits(...)` records the event in the contract spec. Put it on the inherent implementation or interface trait definition, not on a trait implementation. When adding an event to an existing contract, retain its other event and error declarations.



## Test an emitted event

Export the event alongside the generated client from your contract library. In a native test, call `increment` and inspect the returned `TransactResult`:

```rust
let result = env.transact(|tx| {
    tx.call(&caller).run(|| {
        CounterClient::new(&address).increment(5);
    })
});
result.assert_success();
result.assert_event_count(1);
result.assert_event::<CounterIncremented>(0, |event| {
    assert_eq!(event.topic(0), Some(CounterIncremented::SIGNATURE));
    let by: &ContractAddress = event.topic(1).unwrap().into();
    assert_eq!(by, &caller);
    assert_eq!(event.payload().amount, 5);
});
```

Here, `env` is the test environment, `caller` is the calling address, and `address` is the deployed test contract. See [Testing](pages/programming-model/testing.md#basic-pattern) for registration and deployment setup.

The event count covers all contracts called by the test transaction. Assert both topics and payload so the test checks the event’s content, not only its presence.



## Include the event in the interface

Rebuild after changing an event declaration. The generated spec records its name, signature, topic layout, and payload layout. [Client bindings](pages/contracts/client-bindings.md) use that metadata to expose the event to applications.

For library-emitted events that no interface declares, `#[event_spec(export)]` explicitly includes the type in the linked contract’s spec. See the [event macro reference](pages/reference/sdk-macros.md#deriveevent) for the generated API.

Use [Read events](pages/typescript/events.md) for application queries, receipt decoding, and pagination.

---

## Cross-Contract Calls

Source: <https://thruput.network/contracts/cross-contract-calls/>

Calling other contracts from your contract.

Use a generated Rust client to call another contract through its interface. Direct calls propagate failures; `try_*` calls let your contract inspect them. These are onchain clients, separate from the TypeScript clients used by applications.



## Client Generation

On a trait definition or inherent impl, `#[contract]` generates a client struct, named `{Interface}Client` unless you override it with `client = CustomName`. The client mirrors every public method on the trait or impl block.

For interface design, see [Methods and interfaces](pages/contracts/methods.md). For macro parameters, see [SDK Macros](pages/reference/sdk-macros.md#contract).

Single error type:

```rust
#[contract(client = ERC20Client, throws = ERC20Error)]
pub trait ERC20 {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount);
    fn get_balance_of(&self, addr: &ContractAddress) -> Amount;
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    fn succeed() -> u32;
    fn throw_alpha_not_found();
    fn throw_beta_denied();
}
```

For each method `foo`, the generated client provides:

| Method         | Signature                            | On error                                                                                                 |
| -------------- | ------------------------------------ | -------------------------------------------------------------------------------------------------------- |
| `foo(...)`     | Same return type as the trait method | Re-throws. Your contract aborts too.                                                                     |
| `try_foo(...)` | `Result<T, CallError>`               | Returns the error for inspection. Match it with `match_exn!`, or decode it with `try_as` / `try_decode`. |



## Making Calls

Construct a client with the target contract’s address, then call methods on it.

```rust
let token = ERC20Client::new(&token_addr);
let balance = token.get_balance_of(&account);
token.transfer(&recipient, 100);
```

Client methods take `&self` (not `&mut self`). Clients are lightweight value types holding an address and configuration.



## Gas Limits

Use `with_gas_limit` to cap how much computation the callee can perform. It returns a new client instance (non-mutating).

```rust
let token = ERC20Client::new(&token_addr);
let capped = token.with_gas_limit(500_000);
capped.transfer(&recipient, 100);
```

The default request is `u64::MAX`; the child is still bounded by the caller’s remaining gas. Use an explicit cap when the callee should receive less. See [Contract Execution](pages/programming-model/execution.md#gas) for details.

| Method                      | Signature                               | Description                                                                                               |
| --------------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `new(address)`              | `fn new(&ContractAddress) -> Self`      | Create a client for the given contract address.                                                           |
| `with_gas_limit(gas_limit)` | `fn with_gas_limit(&self, u64) -> Self` | Return a new client with the specified gas limit.                                                         |
| `with_commit_locking()`     | `fn with_commit_locking(&self) -> Self` | Ask the child frame to acquire its commit locks before returning, so a `try_` call can handle a conflict. |
| `with_read_only()`          | `fn with_read_only(&self) -> Self`      | Prevent the child frame from modifying state.                                                             |

`with_commit_locking()` and `with_read_only()` return a configured copy of the client. They can be combined:

```rust
let result = ERC20Client::new(&token_addr)
    .with_commit_locking()
    .with_read_only()
    .try_get_balance_of(&account);
```

Commit locking performs early conflict detection at the child-frame boundary. If lock acquisition fails, the child reverts and a `try_` method can inspect the failure. Read-only calls may read storage but cannot write, deploy a contract, or perform another state-changing operation.



## Error Handling



### Direct calls (re-throw)

Direct calls propagate errors automatically. If the callee throws, your contract throws the same exception to its own caller. No error handling needed or possible.

```rust
let client = MultiClient::new(&addr);

// If this throws AlphaError::NotFound, your contract
// re-throws the same error to whoever called you.
client.throw_alpha_not_found();
```



### try\_ calls (inspect)

Prefixing any method with `try_` returns a `Result` you can match on. The error type is the SDK’s `CallError`, the same type for every client.

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(()) => { /* success */ }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => { /* handle this error */ }
        _ => e.re_throw(),
    }),
}
```



### CallError

`try_*` does not pre-decode the exception into a per-interface enum. A caught exception stays a `RawException`, and `CallError` describes only how the call failed:

```rust
pub enum CallError {
    Invalid,
    Reentrance,
    DepthExceeded,
    InvokeRejected(SysErr),
    Exception(RawException),
    Fault(FaultInfo),
    UnparseableReturn(FaultString),
    UnparseableAbort(FaultString),
    UnparseableAuthHandles(FaultString),
    EncodingArgs(FaultString),
}
```

| Variant                               | When it appears                                                                                                                                                                                                                                       |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Invalid`                             | The call could not be made (e.g. invalid contract address before the call dispatched).                                                                                                                                                                |
| `Reentrance`                          | The target already had a frame open on the invocation stack, so the runtime refused the call as reentrant. See [`Reentrance`](pages/reference/syscalls.md) in the syscall errors.                                                                     |
| `DepthExceeded`                       | Admitting the call would have exceeded the network’s cross-invoke depth bound. The same call succeeds from a shallower frame.                                                                                                                         |
| `InvokeRejected(SysErr)`              | The invoke syscall was refused for another reason, carrying the raw syscall error.                                                                                                                                                                    |
| `Exception(RawException)`             | The callee threw. Any exception type, declared in `throws` or not, including the SDK’s own `LibraryExn`.                                                                                                                                              |
| `Fault(FaultInfo)`                    | The callee panicked, trapped, or exhausted gas. Child faults carry no diagnostic message across the call boundary. `FaultInfo` exists on every target and is zero-sized without `dev`; only a native root-frame panic can retain harness diagnostics. |
| `UnparseableReturn(FaultString)`      | The callee committed but its return buffer could not be decoded as the expected type.                                                                                                                                                                 |
| `UnparseableAbort(FaultString)`       | The callee aborted but the abort payload could not be parsed.                                                                                                                                                                                         |
| `UnparseableAuthHandles(FaultString)` | The callee committed but the returned auth-token handle list was malformed.                                                                                                                                                                           |
| `EncodingArgs(FaultString)`           | The caller’s arguments could not be encoded before dispatch.                                                                                                                                                                                          |

The first four variants mean the callee never ran: the invoke syscall was refused before any child frame opened, so the call was a complete no-op that observed nothing and wrote nothing. `CallError::is_rejected_before_call()` tests for exactly that set, which is the distinction to reach for when a retry or a fallback is only safe if the callee did not execute.



### Matching exceptions with `match_exn!`

An exception carries a selector derived from its type, independent of any interface’s `throws` list. `match_exn!` matches on that, so errors from different interfaces are peers:

```rust
match client.try_transfer(&recipient, 100) {
    Ok(()) => { /* transfer succeeded */ }
    Err(CallError::Fault(f)) => {
        // The callee panicked
    }
    Err(e) => match_exn!(e, {
        ERC20Error::MustBeContractOwner => {
            // Caller is not the owner
        }
        ERC20PausableError::EnforcedPause => {
            // Declared by an extension the ERC20 interface knows nothing
            // about, matched here exactly like a declared error
        }
        LibraryExn::NonNegativeIntUnderflow => {
            // SDK-level failure inside the callee
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Ok`, `Fault`, `Invalid`, and encode/decode failures with an ordinary `match`. `match_exn!` only does typed downcasting, and its arms are tried in order, so it requires a final `_` arm.

Two rules follow from how the macro infers the type from each arm’s pattern:

- Every typed arm must be path-rooted (`Type::Variant`, `Type::Variant { .. }`, or a unit-struct `Type`). A bare identifier would be a binding, leaving nothing to infer the type from; `_` is the untyped escape hatch, and the error value is still in scope there.
- `|` cannot combine patterns of different exception types. Alternates within one type are fine.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&recipient, 100).unwrap_err().try_as(),
    Some(ERC20Error::MustBeContractOwner),
);
```

`None` covers all three ways this can miss: the failure carried no exception, it carried a different type, or the payload failed to decode.



### Telling a corrupt error from an unknown one

`try_as` returns `None` both for a selector belonging to another type and for a matching selector whose payload will not decode, and `match_exn!` sweeps both into `_`. `try_decode` separates them:

```rust
match client.try_call_something().unwrap_err().try_decode::<SomeKnownError>() {
    Some(Ok(err)) => { /* decoded */ }
    Some(Err(_)) => { /* right selector, payload did not decode */ }
    None => { /* no exception, or a different type */ }
}
```

A version change can cause this distinction. An exception’s selector uses the first 8 bytes of `sha256(major_version :: crate :: type)`, not the payload layout. Adding an enum variant leaves the selector unchanged, but an older caller cannot decode that new variant. Use `try_decode` if your contract must distinguish an unknown type from an undecodable payload of a known type.

The reverse direction is not detectable at all: decoding reads a *prefix*, so a callee that **appends a field** to a struct exception is accepted silently by an older caller, which decodes the shorter shape and drops the extra data.



### Raw inspection

`RawException` also exposes `selector()` and `payload()` for inspecting bytes directly, and `re_throw()` to propagate the original abort verbatim.



## Error Forwarding

When contract A calls contract B with a direct (non-try) call and B throws, the error propagates through A to A’s caller with the original selector and payload intact. This means callers further up the chain can still decode the original error.

```rust
fn forward_alpha(target: ContractAddress) {
    // If target throws AlphaError::NotFound, this contract
    // re-throws it unchanged. Our caller sees AlphaError::NotFound.
    MultiClient::new(&target).throw_alpha_not_found();
}
```



## Full Example

A contract that calls an ERC20 token contract:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

pub use groundhog_erc20_if as erc20_if;

use erc20_if::Amount;
use erc20_if::ERC20Client;
use sdk::storage::Value;
use sdk::*;

#[storage]
pub struct Caller {
    token_contract: Value<ContractAddress>,
}

#[contract(client = CallerClient)]
impl Caller {
    pub fn initialize(&mut self, token_contract: &ContractAddress) {
        self.token_contract.set(token_contract);
    }

    pub fn check_balance(&self, account: &ContractAddress) -> Amount {
        let token = ERC20Client::new(&self.token_contract.get());
        token.get_balance_of(account)
    }
}
```

See [Handle errors](pages/contracts/errors.md) for defining error types with `#[contract_exception]`.

---

## Invocation Frames

Source: <https://thruput.network/how-it-works/invocation-frames/>

How contract calls track state, return results, and merge or discard child effects.

An invocation frame is the execution context for one contract call. A transaction begins with a root frame. A [cross-contract call](pages/contracts/cross-contract-calls.md) creates a child frame and returns control to its parent when it finishes.

The same model applies to RV32 contracts and native system contracts.



## Frame Structure

| Part          | Contents                                                                          |
| ------------- | --------------------------------------------------------------------------------- |
| Call context  | Contract address, entrypoint, calldata, invocation flags, and gas budget          |
| State changes | Storage operations and deployments made by this frame and its successful children |
| Events        | Events emitted by this frame and its successful children                          |
| Child result  | Status and return bytes from the most recent child call                           |
| Resource use  | Gas consumed by this frame and its children                                       |

A transaction’s root invocation has no child-call flags. A child’s gas budget is capped by its parent’s remaining budget. See [Invocation configuration](pages/contracts/cross-contract-calls.md) for SDK controls.



## Call Stack

```text
Root: wallet.execute
  Child: counter.increment
    Nested child: another contract method
```

Each child has its own execution context. Its ordinary reads use the block snapshot plus visible changes from the current transaction. A child call is part of that transaction, not a separate transaction or a separate block.



## Frame Lifecycle



### 1. Creation

The runtime creates a frame with the call context and an empty record of local changes and events.



### 2. Execution

Contract code uses [syscalls](pages/reference/syscalls.md) to read state, record changes, emit events, and call other contracts. Child calls can create further frames.



### 3. Completion

| Result           | Return bytes                                  | Contract effects                      |
| ---------------- | --------------------------------------------- | ------------------------------------- |
| **Return** (`0`) | Returned to the caller                        | Preserved for merging into the parent |
| **Fault** (`1`)  | Empty                                         | Discarded                             |
| **Abort** (`2`)  | Returned to the caller, usually as error data | Discarded                             |

A fault can result from an invalid instruction, invalid memory access, or exhausted gas. An abort is an explicit revert. SDK-generated wrappers use the Return syscall with its revert flag to produce a return or abort. Gas consumed before either failure remains consumed; it is computation metering, not a token fee.



### 4. Merge into Parent (or Finalize for Root)

On a successful child return, its storage changes, deployments, and events become part of the parent frame. They have not committed to the ledger yet. On a child abort or fault, those effects are discarded.

In either case, the parent receives the child’s status and return buffer and accounts for its gas use. A recoverable SDK call lets the parent inspect the failure. A throwing call propagates an unhandled failure. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md#error-handling).

When the root returns successfully, the transaction’s changes must still pass reservation against the proposed block. A committed root abort or fault records the failure while discarding contract effects; protocol bookkeeping such as replay protection remains. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#root-frame-completion).



### 5. Pop and Return

The runtime discards the completed frame’s guest memory, registers, and stack. Control returns to the parent, or execution ends for the root. Only state written through the storage APIs can persist beyond execution.



## Example: Nested Contract Calls

Suppose contract A calls B, C, and D using recoverable calls:

| Step                         | Outcome                                          | Changes retained by A |
| ---------------------------- | ------------------------------------------------ | --------------------- |
| A writes `AAA`               | A continues                                      | `AAA`                 |
| B writes `BBB` and returns   | Child effects merge                              | `AAA`, `BBB`          |
| C writes `CCC` and aborts    | Child effects are discarded; A handles the error | `AAA`, `BBB`          |
| D writes `DDD` and faults    | Child effects are discarded; A handles the fault | `AAA`, `BBB`          |
| A writes `FINAL` and returns | Root changes enter reservation                   | `AAA`, `BBB`, `FINAL` |

If the transaction is admitted and committed, the ledger contains `AAA`, `BBB`, and `FINAL`. C’s and D’s writes never commit. If A instead propagates either child failure, A’s contract effects are discarded too.



## Related Documentation

- [Cross-Contract Calls](pages/contracts/cross-contract-calls.md): SDK call and error-handling patterns
- [Authorization](pages/how-it-works/authorization.md#passing-auth-tokens): Auth-token ownership across frames
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): Reservation and final outcomes
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Code and deployment identities

---

## Testing

Source: <https://thruput.network/programming-model/testing/>

How to test Stellar Thruput contracts: native logic tests, RV32 integration tests, setup, and error matching.



## Test Modes

Choose a test path based on the boundary you need to exercise:

| Command                      | What it covers                                                   | Use for                                            |
| ---------------------------- | ---------------------------------------------------------------- | -------------------------------------------------- |
| `cargo test`                 | Native SDK execution in process                                  | Fast logic tests, error-path assertions, debugging |
| `thruput test`               | Executor-backed RV32 artifact test                               | Contract artifact behavior without an RPC node     |
| `thruput test --integration` | Ephemeral `hog-devnode`, deployed RV32 artifact, RPC client path | End-to-end deploy/call tests                       |

Start with `cargo test`, then run `thruput test` against the RV32 artifact. Add `thruput test --integration` when you need to test the same path a partner or app will use: build artifact, local node, deployment, signing profile, RPC URL, and generated client behavior.

`thruput test --integration` builds and deploys RV32, the normal user-contract runtime.

Fresh projects include the integration target and host-only dependencies. The CLI can acquire a compatible catalog-pinned `hog-devnode`; use `thruput toolchain list` to inspect it. `THRUPUT_DEVNODE_BINARY` selects an explicit matching source build.



## What the Scaffold Gives You

The `counter` and `stub` templates include:

```text
build.rs
tests/
  integration.rs
```

`tests/integration.rs` starts with one ignored RPC smoke test. It checks that the CLI provided a deployed contract, connects to the ephemeral node with `groundhog-json-rpc-client`, and calls `chainTip`. Replace or extend the final placeholder with assertions for your contract.

The starter remains ignored under ordinary `cargo test`, even if you explicitly enable its feature. `thruput test --integration` enables the feature and sets `THRUPUT_INTEGRATION_TEST=1`, which lets the scaffold’s `build.rs` activate the live test. You can rename the module and test functions without changing how activation works.

The generated `thruput-integration-test` feature enables the optional RPC client and Tokio dependencies. Their target-specific Cargo entries keep them out of RV32 guest builds. Preserve the SDK and RPC versions selected together by the scaffold.

The generated `build.rs` contains:

```rust
fn main() {
    println!("cargo:rerun-if-env-changed=THRUPUT_INTEGRATION_TEST");
    println!("cargo:rustc-check-cfg=cfg(thruput_integration_runner)");

    if std::env::var("THRUPUT_INTEGRATION_TEST").as_deref() == Ok("1") {
        println!("cargo:rustc-cfg=thruput_integration_runner");
    }
}
```

> **tip: Projects created with an older scaffold**
>
> Compare with a fresh scaffold, then add `tests/integration.rs`, its feature and host-only dependencies, and the integration activation logic from `build.rs`. If your project already has a build script, merge the activation lines into its existing `main` function. The CLI exits with `integration_test_not_found` when the test target is absent.



## Test Setup

Your `lib.rs` must include `sdk::declare_mock_contract!()` to generate the `register_mock_contract` function used in tests:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;
pub use implementation::*;
```



## Basic Pattern

```rust
use sdk::*;

use my_counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            client.increment(5);
            assert_eq!(client.get(), 15);
        })
    })
    .assert_success();
}
```

Breaking this down:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()`.
3. **`*test_contract.as_hash()`** copies the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from, and `.run(closure)` executes the closure in a simulated execution context. The returned `TransactResult` records the outcome, return value, and emitted events. `.assert_success()` panics with details if the transaction did not commit.
5. **`deploy_contract`** deploys the contract and returns its address. The nonce makes the address deterministic.
6. **`CounterClient::new`** creates a typed client. Methods return values directly.



## `no_cost` vs `default`

Use [`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost) for most contract logic tests. It disables storage cost enforcement, which keeps tests focused on method behavior, storage mutations, events, and expected exceptions.

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) when the test should exercise the normal storage cost model. This is useful for storage-token behavior, deployment cost checks, or tests that should fail when the caller has not been funded correctly.

Use `TestEnvironment::new(Some(&model))` when the test is specifically about a custom `StorageCostModel`. Use `setup_grant_storage_tokens` to fund accounts in cost-sensitive tests.

For the full generated API, see the [`TestEnvironment` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html) or [Rust API Docs](pages/tools/rust-api-docs.md).

When a native test needs a custom transaction context, start with `env.transaction()`. The builder currently supports replacing the default authorization claim:

```rust
let result = env
    .transaction()
    .with_auth_claim(auth_claim)
    .transact(|tx| tx.call(&caller).run(|| {
        // contract calls
    }));
```

Finish the builder with `transact` for auto-commit, `transact_manual` for explicit commit or abort control, or `build` to obtain a `MockTransactionHandler` directly. Plain `env.transact(...)` remains the shorthand for the default transaction configuration.

Use `thruput test --integration` when the thing under test is not just contract logic: local node startup, RV32 artifact deployment, profile resolution, signing, RPC environment variables, or generated off-chain client behavior.



## Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
use my_counter::{CounterClient, register_mock_contract};

assert_eq!(
    client.try_decrement(10).unwrap_err().try_as(),
    Some(LibraryExn::NonNegativeIntUnderflow),
);
```

The `try_decrement` method (generated alongside `decrement` by the `#[contract]` macro) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`, which is the same for every client: a caught exception stays undecoded inside it, and `try_as` decodes it as whichever exception type you name. When more than one type is of interest, `match_exn!` matches several in one place. See [Handle errors](pages/contracts/errors.md) for the full error model.



## Integration Test Environment

`thruput test --integration` runs `tests/integration.rs` against an ephemeral `hog-devnode`. The CLI builds and deploys the selected artifact, then sets:

| Variable                   | Value                                       |
| -------------------------- | ------------------------------------------- |
| `THRUPUT_INTEGRATION_TEST` | `1`; activates the scaffolded live test     |
| `THRUPUT_RPC_URL`          | RPC URL for the ephemeral node              |
| `THRUPUT_CONTRACT_ADDRESS` | Deployed contract address                   |
| `THRUPUT_PROFILE`          | `integration`                               |
| `THRUPUT_DEFAULT_KEY`      | Lowest-index `local_user`, normally `dev-1` |
| `THRUPUT_RUNTIME_MANIFEST` | Runtime manifest path, when available       |

The full run is:

1. Build the RV32 artifact.
2. Start an isolated local node.
3. Deploy it with the runtime’s lowest-index `local_user`, normally `dev-1`. `dev-0` remains reserved for the local faucet.
4. Enable `thruput-integration-test` and run only the `integration` Cargo test target with the environment above.
5. Shut down the node after the test run, including after test failures.

Normal test-harness controls such as `--match-test`, `--skip`, `--show-output`, `--no-capture`, and `--test-threads` apply to integration tests. `--watch` and `--rerun` cannot be combined with `--integration` yet.

Integration tests use the same RV32 artifact path as normal builds and deployments.



## Named Addresses

`ContractAddress::named("alice")` produces a deterministic address from a string. Same name always returns the same address. The method hashes the name with SHA-256 at runtime, so it cannot initialize a `static` or `const`. Bind it inside the test or a `LazyLock` instead:

```rust
#[test]
fn transfer_between_known_addresses() {
    let alice = ContractAddress::named("alice");
    let bob   = ContractAddress::named("bob");
    // ...
}
```

The `Named` trait that provides this method is re-exported through `sdk::*` when the `dev` feature is enabled.

---

## Debug a contract

Source: <https://thruput.network/contracts/debugging/>

Isolate failures in native tests, RV32 artifact tests, and submitted transactions.

Start at the boundary that failed. A compiler error, a contract exception, and an uncertain network submission need different checks.



## Reproduce the logic

Use the smallest input that reproduces the problem:

```bash
RUST_BACKTRACE=1 cargo test test_counter -- --nocapture
```

Native tests provide Rust diagnostics and work with host debugging tools. Use generated `try_*` client methods to assert on expected errors.

Once the logic passes, run `thruput test` to check the RV32 artifact. A passing host test does not replace the artifact test.



## Inspect the build or artifact test

```bash
thruput --show-cargo-commands build
thruput test --match-test counter --show-output
```

Confirm the package, toolchain, and features. In a workspace, use `-p PACKAGE`. See [Build and test](pages/cli/build-and-test.md).



## Classify a deployed failure

| Observation            | Next check                                                                           |
| ---------------------- | ------------------------------------------------------------------------------------ |
| Submission rejected    | Inspect the signing account, profile, network identity, and reported admission error |
| Committed exception    | Decode the typed error; check input and authorization conditions                     |
| Committed fault        | Reproduce in tests; inspect execution limits and panics                              |
| Pending or unknown     | Observe the original transaction on the same network                                 |
| Unexpected view result | Check address, interface/spec, read height, and simulated caller                     |

```bash
thruput tx show TX_HASH --profile futurenet
```

See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish) for outcomes and [CLI troubleshooting](pages/cli/troubleshooting.md) for configuration checks.



## Reproduce through RPC

Start a local node with `thruput node --verbose` and retain its logs while reproducing the problem. CLI transaction inspection shows public status and receipt data, not a full execution trace.

For repeatable build, deployment, and RPC checks, use `thruput test --integration` and add contract-specific assertions to the generated test.

---

## Generate client bindings

Source: <https://thruput.network/contracts/client-bindings/>

Deliver a contract's typed interface to TypeScript application developers.

Client bindings let an application use your contract’s methods, types, errors, and events. Generate them from the contract spec produced by the same build you deploy:

```bash
thruput build --bindings ts
```

The spec describes the exported interface. Bindings turn that description into TypeScript code for application developers.



## Keep the interface and deployment together

- Regenerate bindings when methods, argument or return types, errors, or events change.
- Give application developers the bindings and the matching deployment address and network.
- Keep generated files separate from application code so regeneration does not overwrite manual changes.

See [Generate TypeScript bindings](pages/cli/codegen.md) for output paths and generation from an existing spec, and [Use contract bindings](pages/tools/typescript-bindings.md) for consuming the generated interface in an application.

---

## Contract artifacts and addresses

Source: <https://thruput.network/how-it-works/contracts/>

Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.

An artifact is compiled contract code. Its code hash identifies that code; a deployment address identifies one instance with its own storage. The same artifact can be deployed at multiple addresses.

This page explains those identities and the rules of deployment. For deployment commands, see [Deploy and call](pages/cli/deploy-and-call.md).

User contracts compile to RV32, Stellar Thruput’s 32-bit RISC-V contract target. Native system contracts serve separate purposes, described below.



## Contract Types



### RV32 Contracts

`thruput build` compiles the contract’s RV32 entrypoint wrapper for `riscv32im-unknown-none-elf`, lowers that ELF into a deployable `.rv32a` artifact, and finalizes its contract-spec sidecars.

For a crate named `counter`, the default build writes:

```txt
target/thruput/counter.rv32a
target/thruput/counter.rv32.json
target/thruput/counter.spec.xdr
target/thruput/counter.spec.json
```

The `.rv32a` file is the executable contract artifact. `thruput deploy` wraps those bytes in the protocol’s `Contract::kRv32` variant before signing and submitting the deploy transaction.

Deployment must satisfy the network’s limits on attached contract size, RV32 code, guest memory, and new contracts per transaction. Client and gateway submission limits also apply. Use the selected network’s configuration rather than assuming a fixed maximum.



#### Entrypoints

Every callable method is identified by an 8-byte `ContractEntrypointID`. The SDK’s `#[contract]` macro emits one dispatch record per method into a link-time `GROUNDHOG_RV32_ENTRYPOINTS` registry.

When hogd invokes an RV32 contract, it enters the guest at `_start` with the method ID in registers. The RV32 runtime dispatches by scanning the registry, then calls the generated wrapper for the matching method. That wrapper decodes calldata, calls the Rust method, and returns through the Return syscall.

Entrypoint IDs can be arbitrary 8-byte values at the protocol layer. The SDK provides the normal convention: derive a 6-byte interface prefix from the interface name and version, then use a method-specific 2-byte suffix. See [SDK Macros](pages/reference/sdk-macros.md) and the [contract spec reference](pages/reference/contract-spec.md) for the developer-facing shape.



#### Artifact Shape

Most developers should let the [Thruput CLI](pages/cli/build-and-test.md) produce RV32 artifacts. Under the hood, the RV32 lowerer:

- Parses the `riscv32im-unknown-none-elf` contract binary.
- Validates the layout expected by the Stellar Thruput RV32 runtime.
- Packs code, initial memory, metadata, and section digests into the `.rv32a` artifact.
- Self-verifies the artifact before writing it.

The node executes the lowered artifact through the RV32 runtime. Contract state does not live in guest memory. Durable state must be written through Stellar Thruput storage APIs.



### Native Precompiled Contracts

Native precompiled contracts are implemented directly inside the Stellar Thruput runtime. They are used for trusted system behavior, such as the native token contract, and can have permissions that user-deployed guest contracts do not have.

Users cannot deploy native contracts. Network configuration assigns system contract addresses; implementations are identified by values from `HogexecPrecompiledNativeContracts`.



## Contract Deployment

Contracts are deployed by the DeployContract [system call](pages/reference/syscalls.md). In normal CLI usage, `thruput deploy` invokes the active wallet contract, and the wallet contract calls DeployContract with the artifact hash and deployment nonce.



### Contract Identification

Contracts are identified by the SHA256 hash of the XDR-encoded `Contract` union. For an RV32 artifact, the deploy hash is:

```txt
SHA256(XDR(Contract::kRv32 {
    rv32_contract: ContractBlob {
        data: <.rv32a artifact bytes>
    }
}))
```

This is not just the SHA256 hash of the raw `.rv32a` bytes. The XDR wrapper and `kRv32` type tag are part of the hash preimage.



### DeployContract Syscall

To deploy a contract, the caller invokes DeployContract with two arguments:

- `nonce`: a 32-byte value chosen by the caller
- `contract_hash`: the SHA256 hash identifying the contract artifact to deploy

The system then:

1. Verifies that the contract identified by `contract_hash` is available for deployment.
2. Computes the deployment address: `ContractAddress = SHA256(XDR(ContractDeploymentHashPreimage))`.
3. Writes `AddressMetadata` at the computed address.
4. Stores the contract code separately in the deduplicated contract code store.



### Deterministic Address Derivation

The address to which a contract is deployed is computed from the deployer address, nonce, and contract hash. Anyone can predict the address before deployment.

A single contract artifact can be deployed at many addresses. Each deployment has separate metadata and separate storage.



### Deployment Preimage

```rust
pub struct ContractDeploymentHashPreimage {
    /// Address of the contract performing the deployment.
    pub deployer_address: ContractAddress,

    /// Arbitrary 32-byte nonce chosen by the deployer.
    pub nonce: SHA256Hash,

    /// SHA256 hash of the contract artifact.
    pub contract_hash: SHA256Hash,
}
```

Under XDR encoding, this structure serializes as the concatenation of its fields:

```txt
XDR(ContractDeploymentHashPreimage) = deployer_address || nonce || contract_hash
```



### Example

A wallet contract at address `0x1234...` deploys `counter.rv32a`:

```txt
deployer_address = 0x1234...
nonce            = 0x5678...
contract_hash    = SHA256(XDR(Contract::kRv32 {
                       rv32_contract: ContractBlob { data: bytes(counter.rv32a) }
                   }))
                 = 0xabcd...

ContractAddress  = SHA256(0x1234... || 0x5678... || 0xabcd...)
                 = 0x9999...
```

The deployed counter contract’s address is now `0x9999...`.

This scheme is analogous to Ethereum’s `CREATE2` opcode because the address can be calculated before deployment.



## Deployment Eligibility

To be deployed via DeployContract, a contract identified by `contract_hash` must be available in the context of the current transaction.

A contract is available if either of the following holds:

- The contract code already exists in the on-chain contract code store.
- The contract is included in the `contracts_to_deploy` field of the current transaction.

```rust
pub struct Transaction {
    pub invocation: Invocation,
    pub uniquifier: Uniquifier,

    /// New contract code to make available for deployment.
    pub contracts_to_deploy: VecM<Contract>,

    /// Authorization claim specifying required signatures.
    pub auth_claim: AuthClaim,
}
```

`contracts_to_deploy` makes contract code available, but it does not deploy the code to an address by itself. Deployment to a specific address happens when a contract invokes DeployContract.

Example flow:

1. The transaction includes `contracts_to_deploy: [Contract::kRv32 { rv32_contract: ContractBlob { data: <artifact bytes> } }]`.
2. The contract code becomes available under its `contract_hash`.
3. During execution, a contract calls `DeployContract(nonce, contract_hash)`.
4. The system computes the deployed address and writes its metadata.



## Address Metadata

When a contract is deployed, the system writes `AddressMetadata` to the storage key `(contract_address, StorageKeyType::Metadata)`.

```rust
pub struct AddressMetadata {
    pub deployed_contract: DeployedContractHash,
}

pub struct DeployedContractHash {
    /// SHA256 hash of the contract code.
    pub hash: SHA256Hash,

    /// Size of the contract in bytes.
    pub contract_size: u32,

    /// Type of contract: kRv32 or kNative.
    pub contract_type: ContractType,
}
```

This metadata allows the executor and off-chain tools to:

- Verify what code is running at an address.
- Determine the contract type without loading bytecode.
- Calculate storage costs from the contract size.

The metadata is set during deployment and persists for the lifetime of the contract address.



## Deployment Concurrency

Multiple transactions may deploy the same contract to the same address in the same block. Stellar Thruput does not consider concurrent deployments of the same contract to the same address to be in conflict. Collision resistance of SHA256 implies that different contracts cannot be deployed to the same address.

If a contract requires one-time initialization, implement that guard in contract storage.



## Redeployment and Immutability

Once a contract is deployed to an address, that address’s `AddressMetadata` cannot be changed. Deployed contracts are immutable.



## Related Documentation

- [Thruput CLI](pages/cli.md): RV32 builds, local nodes, deployment, and codegen
- [Invocation Frames](pages/how-it-works/invocation-frames.md): execution context and call stack management
- [Syscalls](pages/reference/syscalls.md): system calls available to contracts
- [SDK Macros](pages/reference/sdk-macros.md): SDK entrypoint IDs and generated clients
- [Contract Spec](pages/reference/contract-spec.md): generated method, type, event, and error metadata
- [System Overview](pages/how-it-works/architecture.md): the component map

---

## Rust API Docs

Source: <https://thruput.network/tools/rust-api-docs/>

Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.

Use Rustdoc for exact signatures, trait bounds, and source links. Use this site for contract tasks and the programming model.



## Match your project

The hosted links below select one SDK release. If your project’s dependency differs, select its version at [crates.thruput.network](https://crates.thruput.network) or build its resolved SDK documentation locally:

```bash
cargo doc -p sdk --no-deps --open
```

Run this from the generated contract project after [Cargo access setup](pages/cli/install.md#configure-cargo-access). Hosted Rustdoc may require your onboarding credentials.



## Common Links

| Need                        | Rustdoc                                                                                                                                                                                                                                                    |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| SDK overview and re-exports | [`sdk`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/index.html)                                                                                                                                                                                 |
| Contract types              | [`ContractAddress`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.ContractAddress.html), [`SHA256Hash`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.SHA256Hash.html)                                         |
| Native tests                | [`TestEnvironment`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/struct.TestEnvironment.html)                                                                                                                                                    |
| Storage types and traits    | [`sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html)                                                                                                                                                                |
| Balances and counters       | [`Balance`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/balance/struct.Balance.html), [`NNInt`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/nnint/struct.NNInt.html)                                                 |
| Shared capacity             | [`CapacityConstraint`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/capacity_constraint/struct.CapacityConstraint.html)                                                                                                                  |
| Keyed and indexed storage   | [`Map`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/map/struct.Map.html), [`Vector`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/vector/struct.Vector.html)                                                          |
| Typed and raw values        | [`Value`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/value/struct.Value.html), [`Bytestring`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/bytestring/struct.Bytestring.html)                                        |
| Queues and nested state     | [`RCQ`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/rcq/struct.RCQ.html), [`Node`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/node/struct.Node.html)                                                                |
| Contract and storage macros | [`#[contract]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract.html), [`#[storage]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.storage.html)                                                                       |
| Error macro                 | [`#[contract_exception]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract_exception.html)                                                                                                                                             |
| Events                      | [`Event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/derive.Event.html), [`log_event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/event/fn.log_event.html)                                                                         |
| Error helpers               | [`throw`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.throw.html), [`ensure`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.ensure.html), [`OrThrow`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/trait.OrThrow.html) |
| Deployment                  | [`deploy_contract`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/deploy/fn.deploy_contract.html)                                                                                                                                                 |
| Mock registration           | [`declare_mock_contract!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.declare_mock_contract.html)                                                                                                                                        |
| Compile-time hashes         | [`sha256_static!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.sha256_static.html), [`hash_ident!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.hash_ident.html)                                                         |



## How to Use These Docs

- Start with [Testing](pages/programming-model/testing.md) to choose native, artifact, or RPC tests.
- Use [storage API tables](pages/reference/storage-types.md) for common operations and [storage guidance](pages/programming-model/storage-types.md) to choose a type.
- Use [SDK Macros](pages/reference/sdk-macros.md) for parameters and generated items.
- Follow Rustdoc source links when you need the implementation behind an API.

---

## Storage Types

Source: <https://thruput.network/reference/storage-types/>

API reference for Stellar Thruput storage types.

| Area                                  | Links                                                                                                                                      |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| Type choice and conflict semantics    | [Storage guidance](pages/programming-model/storage-types.md)                                                                               |
| Generated type, guard, and trait APIs | [`sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html), [Rust API Docs](pages/tools/rust-api-docs.md) |
| Encoding                              | CXS; serialization traits retain the names `ReadXDR` and `WriteXDR`                                                                        |



## NNInt

| Property         | Value                                                                                                                                 |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Data model       | Signed changes, explicit `set`, and a commit-time floor                                                                               |
| Decrement        | Negative `inc` or `strict_inc` argument                                                                                               |
| Exclusive writes | Keypath flag, or `non_negative_int_set_exclusive` in `sdk::sys_exn::nnint`; no handle `set_exclusive` method                          |
| Traits           | `Deletable`                                                                                                                           |
| Usage            | [Merged deltas](pages/programming-model/execution.md#merged-deltas), [NNInt and concurrent updates](pages/programming-model/nnint.md) |

| Method           | Signature                                                                 | Description                                                                                                                     |
| ---------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `get`            | `fn get(&self) -> i128`                                                   | Read current value. Aborts if the location has never been set.                                                                  |
| `try_get`        | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read current value without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.                      |
| `set`            | `fn set(&mut self, set_value: i128)`                                      | Set the value. Uses the keypath’s locking mode.                                                                                 |
| `inc`            | `fn inc(&mut self, increment: i128)`                                      | Add `increment` without forcing a snapshot read. Underflow is caught by later runtime checks, not immediately.                  |
| `strict_inc`     | `fn strict_inc(&mut self, increment: i128)`                               | Add `increment`, loading the current base for early underflow detection. Aborts immediately if the result would be negative.    |
| `try_strict_inc` | `fn try_strict_inc(&mut self, increment: i128) -> Result<(), LibraryExn>` | Checked increment that reports overflow, underflow, or storage failure instead of aborting. Leaves storage unmodified on `Err`. |



## Balance

| Property        | Value                                          |
| --------------- | ---------------------------------------------- |
| Representation  | `i128`, backed by NNInt                        |
| Range           | `0..=i128::MAX`; `Balance::MAX` is `i128::MAX` |
| Missing value   | Zero                                           |
| Negative amount | Rejected with `NonNegativeIntUnderflow`        |
| Operations      | No absolute `set` or signed adjustment         |
| Traits          | `Deletable`                                    |

| Method              | Signature                                                                 | Description                                                                                                   |
| ------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> i128`                                                   | Read the balance. A never-written location returns zero.                                                      |
| `try_get`           | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read without aborting. A never-written location returns `Ok(0)`.                                              |
| `increase`          | `fn increase(&mut self, amount: i128)`                                    | Load and increase the balance. Aborts immediately on overflow.                                                |
| `try_increase`      | `fn try_increase(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked increase that leaves storage unmodified on `Err`.                                                     |
| `decrease`          | `fn decrease(&mut self, amount: i128)`                                    | Load and decrease the balance. Aborts immediately if funds are insufficient.                                  |
| `try_decrease`      | `fn try_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked decrease that leaves storage unmodified on `Err`.                                                     |
| `lazy_increase`     | `fn lazy_increase(&mut self, amount: i128)`                               | Record an increase without loading the committed balance. Aggregate overflow is checked during reservation.   |
| `try_lazy_increase` | `fn try_lazy_increase(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta overflow.                                                       |
| `lazy_decrease`     | `fn lazy_decrease(&mut self, amount: i128)`                               | Record a decrease without loading the committed balance. Aggregate sufficiency is checked during reservation. |
| `try_lazy_decrease` | `fn try_lazy_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta underflow.                                                      |



## CapacityConstraint

| Property | Value                                                         |
| -------- | ------------------------------------------------------------- |
| Purpose  | Commit-time capacity for a contract-defined linear constraint |
| Flush    | Staged changes are written on flush or drop                   |
| Traits   | `Deletable`                                                   |

| Method                       | Signature                                                                    | Description                                                                                                                |
| ---------------------------- | ---------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `get_remaining_capacity`     | `fn get_remaining_capacity(&self) -> i128`                                   | Return the committed capacity plus changes staged in this transaction and handle. A never-written location starts at zero. |
| `try_get_remaining_capacity` | `fn try_get_remaining_capacity(&self) -> Result<i128, LibraryExn>`           | Read remaining capacity without aborting.                                                                                  |
| `consume_capacity`           | `fn consume_capacity(&mut self, amount: i128)`                               | Stage consumption for commit-time enforcement. A negative amount releases capacity.                                        |
| `try_consume_capacity`       | `fn try_consume_capacity(&mut self, amount: i128) -> Result<(), LibraryExn>` | Stage consumption and report arithmetic overflow instead of aborting.                                                      |
| `set_capacity`               | `fn set_capacity(&mut self, capacity: i128)`                                 | Set the capacity. Must be the first write in the transaction, except for an idempotent repeat.                             |
| `try_set_capacity`           | `fn try_set_capacity(&mut self, capacity: i128) -> Result<(), LibraryExn>`   | Set capacity and report invalid write ordering instead of aborting.                                                        |
| `flush`                      | `fn flush(&mut self)`                                                        | Merge staged changes into pending storage immediately.                                                                     |
| `try_flush`                  | `fn try_flush(&mut self) -> Result<(), LibraryExn>`                          | Flush staged changes and report failure. On error, changes remain staged and drop retries the flush.                       |



## Map\<K, V>

| Property        | Value                                                             |
| --------------- | ----------------------------------------------------------------- |
| Bounds          | `K: WriteXDR`, `V: StorageType`                                   |
| Enumeration     | Not supported; no `keys()` or iterator                            |
| Deletion        | Does not implement `Deletable`                                    |
| Disjoint access | Compares derived keypaths, not `PartialEq`; duplicate slots panic |

| Method                      | Signature                                                                                                      | Description                                                                                                                                   |
| --------------------------- | -------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `at`                        | `fn at(&self, entry_key: &K) -> SlotRef<'_, Self, V>`                                                          | Read-only borrow of the value at `entry_key`. Returns a `SlotRef` that derefs to `V`.                                                         |
| `at_mut`                    | `fn at_mut(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                                  | Mutable borrow of the value at `entry_key`. Returns a `SlotMut` that derefs to `V`.                                                           |
| `at_mut_exclusive`          | `fn at_mut_exclusive(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                        | Mutable borrow with an exclusive lock. One writer per key per block. Later writes to the entry in the same transaction keep the lock request. |
| `at_disjoint_mut`           | `fn at_disjoint_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>`                  | Mutably borrow N elements at once. Panics if any keys are equal.                                                                              |
| `at_disjoint_unchecked_mut` | `unsafe fn at_disjoint_unchecked_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>` | Mutably borrow N elements without duplicate checking. Caller must ensure all keys are disjoint.                                               |
| `keypath`                   | `fn keypath(&self) -> &Keypath`                                                                                | Reference to the map’s root keypath.                                                                                                          |



### DisjointMut\<Owner, S, N>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `at_disjoint_mut`                                              |
| Borrow   | Exclusive borrow of the parent map                             |
| Traits   | `Deref<Target = [S; N]>`, `DerefMut`; supports direct indexing |



## Vector\<S>

| Property       | Value                                                                                                    |
| -------------- | -------------------------------------------------------------------------------------------------------- |
| Representation | `Map<u32, S>` and a separate length; `S: StorageType`                                                    |
| Sparse slots   | Deleting element storage does not shrink `len`; an in-bounds slot can be missing                         |
| Iterators      | `Iterator`, `ExactSizeIterator`, `DoubleEndedIterator`; `IntoIterator` for shared and mutable references |
| Deletion       | `Deletable` when `S: Deletable`; deletes elements, then length                                           |

| Method            | Signature                                                      | Description                                                                                                                  |
| ----------------- | -------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `len`             | `fn len(&self) -> u32`                                         | Current logical length. Returns 0 if never set.                                                                              |
| `is_empty`        | `fn is_empty(&self) -> bool`                                   | True if `len() == 0`.                                                                                                        |
| `at`              | `fn at(&self, index: u32) -> SlotRef<'_, Self, S>`             | Read-only borrow at `index`. Bounds-checked.                                                                                 |
| `at_mut`          | `fn at_mut(&mut self, index: u32) -> SlotMut<'_, Self, S>`     | Mutable borrow at `index`. Bounds-checked.                                                                                   |
| `push_empty_slot` | `fn push_empty_slot(&mut self) -> SlotMut<'_, Self, S>`        | Increment `len` and return a mutable handle to the new slot. Marked `#[must_use]`.                                           |
| `push_with`       | `fn push_with<R>(&mut self, f: impl FnOnce(&mut S) -> R) -> R` | Initialize a new slot through the closure `f`, then increment `len`. If `f` traps, neither the data nor `len` are committed. |
| `pop`             | `fn pop(&mut self)`                                            | Delete the last element and decrement `len`. Aborts if empty. Requires `S: Deletable`.                                       |
| `iter`            | `fn iter(&self) -> VectorIter<'_, S>`                          | Read-only iterator. Yields `SlotRef` handles. Shared borrow prevents structural modifications.                               |
| `iter_mut`        | `fn iter_mut(&mut self) -> VectorIterMut<'_, S>`               | Mutable iterator. Yields `SlotMut` handles. Exclusive borrow on the vector.                                                  |
| `keypath`         | `fn keypath(&self) -> &Keypath`                                | Reference to the vector’s root keypath.                                                                                      |



## Value\<T>

| Property | Value                                            |
| -------- | ------------------------------------------------ |
| Data     | One serialized typed value                       |
| Bounds   | `T: WriteXDR` for writes, `T: ReadXDR` for reads |
| Traits   | `Deletable`                                      |

| Method              | Signature                                                              | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> T`                                                   | Deserialize and return the stored value. Aborts if the key does not exist.                                    |
| `try_get`           | `fn try_get(&self) -> Result<T, LibraryExn>`                           | Deserialize without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.           |
| `set`               | `fn set(&mut self, value: &T)`                                         | Serialize and store the value. Uses the keypath’s locking mode.                                               |
| `try_set`           | `fn try_set(&mut self, value: &T) -> Result<(), LibraryExn>`           | Serialize and store without aborting. Leaves storage unmodified on `Err`.                                     |
| `set_exclusive`     | `fn set_exclusive(&mut self, value: &T)`                               | Serialize and store the value with an exclusive lock, regardless of keypath flag.                             |
| `try_set_exclusive` | `fn try_set_exclusive(&mut self, value: &T) -> Result<(), LibraryExn>` | Exclusive store that reports failure instead of aborting.                                                     |
| `load_mut`          | `fn load_mut(&mut self) -> ValueMut<'_, T>`                            | Load the value and return a mutable guard. Flushes back to storage on drop. Requires `T: WriteXDR + ReadXDR`. |
| `key`               | `fn key(&self) -> &StorageKey`                                         | Reference to the value’s resolved storage key.                                                                |



### ValueMut\<T>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `load_mut`                                                     |
| Traits   | `Deref<Target = T>`, `DerefMut`                                |
| Drop     | Writes back after mutable access; a clean guard does not write |

| Method      | Signature                                           | Description                                                                                            |
| ----------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `flush`     | `fn flush(&mut self)`                               | Write a dirty value immediately. A clean guard is a no-op.                                             |
| `try_flush` | `fn try_flush(&mut self) -> Result<(), LibraryExn>` | Flush and report serialization or storage failure. On error, the guard remains dirty and drop retries. |



## Bytestring

| Property         | Value                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------- |
| Data             | Raw bytes                                                                                                   |
| Exclusive writes | Keypath flag, or `bytestring_set_exclusive` in `sdk::sys_exn::bytestring`; no handle `set_exclusive` method |
| Traits           | `Deletable`                                                                                                 |

| Method      | Signature                                            | Description                                                                                  |
| ----------- | ---------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `len`       | `fn len(&self) -> usize`                             | Length in bytes.                                                                             |
| `is_empty`  | `fn is_empty(&self) -> bool`                         | True if length is zero.                                                                      |
| `exists`    | `fn exists(&self) -> bool`                           | True if a bytestring exists. Returns false for a missing key.                                |
| `get`       | `fn get(&self) -> Box<[u8]>`                         | Read stored bytes as a heap-allocated slice.                                                 |
| `try_get`   | `fn try_get(&self) -> Result<Box<[u8]>, LibraryExn>` | Read without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`. |
| `get_sized` | `fn get_sized<const N: usize>(&self) -> [u8; N]`     | Read into a fixed-size array. Aborts if length does not match `N`.                           |
| `set`       | `fn set(&mut self, buf: &[u8])`                      | Write bytes. Uses the keypath’s locking mode (exclusive if the keypath flag is set).         |



## RCQ\<T>

| Property    | Value                                                                     |
| ----------- | ------------------------------------------------------------------------- |
| Data        | CXS-encoded `T`; multi-producer queue                                     |
| Concurrency | Inserts commute; consumes are sequential                                  |
| Traits      | `StorageType`, `Deletable`                                                |
| Modules     | Typed wrapper in `sdk::storage`; raw-key functions in `sdk::sys_exn::rcq` |

| Method              | Signature                                                                        | Description                                                                                        |
| ------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `insert`            | `fn insert(&mut self, entry: &T)` where `T: WriteXDR`                            | CXS-encode and insert the entry.                                                                   |
| `insert_raw`        | `fn insert_raw(&mut self, queue_entry: &[u8])`                                   | Insert raw bytes; bypasses CXS encoding.                                                           |
| `consume`           | `fn consume(&mut self) -> T` where `T: ReadXDROwned`                             | Consume the next entry and decode it. Aborts if the queue is empty or the entry cannot be decoded. |
| `try_consume`       | `fn try_consume(&mut self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`     | Consume and decode without aborting. A decode failure leaves the entry in the queue.               |
| `consume_raw`       | `fn consume_raw(&mut self) -> Box<[u8]>`                                         | Consume the next entry as raw bytes. Aborts if the queue is empty.                                 |
| `try_consume_raw`   | `fn try_consume_raw(&mut self) -> Result<Box<[u8]>, LibraryExn>`                 | Consume raw bytes without aborting.                                                                |
| `consume_sized`     | `fn consume_sized<const N: usize>(&mut self) -> [u8; N]`                         | Consume into a fixed-size array. Aborts on size mismatch.                                          |
| `try_consume_sized` | `fn try_consume_sized<const N: usize>(&mut self) -> Result<[u8; N], LibraryExn>` | Consume without aborting. A wrong-size entry is left in the queue.                                 |
| `peek`              | `fn peek(&self) -> T` where `T: ReadXDROwned`                                    | Read the next entry without consuming. Aborts if empty.                                            |
| `try_peek`          | `fn try_peek(&self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`            | Read and decode without aborting or consuming.                                                     |
| `peek_raw`          | `fn peek_raw(&self) -> Box<[u8]>`                                                | Raw-bytes peek. Aborts if empty.                                                                   |
| `try_peek_raw`      | `fn try_peek_raw(&self) -> Result<Box<[u8]>, LibraryExn>`                        | Raw-bytes peek without aborting.                                                                   |
| `peek_sized`        | `fn peek_sized<const N: usize>(&self) -> [u8; N]`                                | Fixed-size peek. Aborts on size mismatch.                                                          |
| `try_peek_sized`    | `fn try_peek_sized<const N: usize>(&self) -> Result<[u8; N], LibraryExn>`        | Fixed-size peek without aborting.                                                                  |
| `key`               | `fn key(&self) -> &StorageKey`                                                   | Reference to the queue’s resolved storage key.                                                     |



### Lower-level free functions (`sdk::sys_exn::rcq`)

| Function                              | Signature                                                                                                 | Description                                                         |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `retrocausal_queue_insert`            | `fn retrocausal_queue_insert(key: &StorageKey, queue_entry: &[u8])`                                       | Insert raw bytes.                                                   |
| `retrocausal_queue_consume_sized`     | `fn retrocausal_queue_consume_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                         | Consume a fixed-size entry. Aborts on size mismatch or empty queue. |
| `retrocausal_queue_try_consume_sized` | `fn retrocausal_queue_try_consume_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>` | Consume a fixed-size entry without aborting.                        |
| `retrocausal_queue_peek_sized`        | `fn retrocausal_queue_peek_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                            | Peek a fixed-size entry.                                            |
| `retrocausal_queue_try_peek_sized`    | `fn retrocausal_queue_try_peek_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>`    | Peek a fixed-size entry without aborting.                           |
| `retrocausal_queue_consume`           | `fn retrocausal_queue_consume(key: &StorageKey) -> Box<[u8]>`                                             | Consume a raw entry.                                                |
| `retrocausal_queue_try_consume`       | `fn retrocausal_queue_try_consume(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                     | Consume a raw entry without aborting.                               |
| `retrocausal_queue_peek`              | `fn retrocausal_queue_peek(key: &StorageKey) -> Box<[u8]>`                                                | Peek a raw entry.                                                   |
| `retrocausal_queue_try_peek`          | `fn retrocausal_queue_try_peek(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                        | Peek a raw entry without aborting.                                  |



## Slot Types

| Type                    | Implements                       | Description                                              |
| ----------------------- | -------------------------------- | -------------------------------------------------------- |
| `SlotRef<'a, Owner, S>` | `Deref<Target = S>`              | Read-only handle. Holds a shared borrow on the parent.   |
| `SlotMut<'a, Owner, S>` | `Deref<Target = S>` + `DerefMut` | Mutable handle. Holds an exclusive borrow on the parent. |

| Access                | Lifetime                  | Syntax                                    |
| --------------------- | ------------------------- | ----------------------------------------- |
| Map or vector element | Tied to parent collection | `*slot` or direct field access; no unwrap |



## Node\<T>

| Property           | Value                                                      |
| ------------------ | ---------------------------------------------------------- |
| Data               | Compound storage field group and its root keypath          |
| Bound              | `T: From<Keypath>`                                         |
| Access             | `Deref<Target = T>`, `DerefMut`                            |
| Collection support | Implements `StorageType` for use in maps and vectors       |
| Deletion           | `Deletable` when `T: Deletable`; delegates to inner fields |

| Method    | Signature                       | Description                           |
| --------- | ------------------------------- | ------------------------------------- |
| `keypath` | `fn keypath(&self) -> &Keypath` | Reference to the node’s root keypath. |



## Deletable Trait

| Implementor                                                     | Behavior                                               |
| --------------------------------------------------------------- | ------------------------------------------------------ |
| `Balance`, `NNInt`, `CapacityConstraint`, `Value`, `Bytestring` | Delete one key                                         |
| `Node`, `Vector`                                                | Delete recursively when elements implement `Deletable` |
| `Map`                                                           | Not implemented; entries cannot be enumerated          |

| Method             | Signature                        | Description                                                |
| ------------------ | -------------------------------- | ---------------------------------------------------------- |
| `delete`           | `fn delete(&mut self)`           | Delete using the keypath’s own locking semantics.          |
| `delete_exclusive` | `fn delete_exclusive(&mut self)` | Delete with an exclusive lock, regardless of keypath flag. |



## Flaggable Trait

| Property     | Value                                                |
| ------------ | ---------------------------------------------------- |
| Implementors | `Value`, `NNInt`, `Balance`, `Bytestring`            |
| Scope        | Current transaction’s requested flags for a leaf key |
| Type         | `StorageFlags` aliases `StorageDeltaFlags`           |
| Flag         | `ExclusiveLock`                                      |

| Method        | Signature                                      | Description                                                                                      |
| ------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| `flags`       | `fn flags(&self) -> StorageFlags`              | The key’s flags as seen by the current call frame. `None` if the key has no pending write.       |
| `set_flags`   | `fn set_flags(&mut self, flags: StorageFlags)` | Add `flags` (bitwise OR). Throws unless a write to the key is pending in the current call frame. |
| `clear_flags` | `fn clear_flags(&mut self)`                    | Remove every flag. Does nothing if the key has no pending write.                                 |



### Raw-key functions

| Function              | Signature                                                          | Description                                                    |
| --------------------- | ------------------------------------------------------------------ | -------------------------------------------------------------- |
| `storage_flags`       | `fn storage_flags(key: &StorageKey) -> StorageDeltaFlags`          | Read the key’s flags.                                          |
| `set_storage_flags`   | `fn set_storage_flags(key: &StorageKey, flags: StorageDeltaFlags)` | Add flags. Throws if no write is pending or a flag is unknown. |
| `clear_storage_flags` | `fn clear_storage_flags(key: &StorageKey)`                         | Remove every flag.                                             |

| Module                   | Behavior                                                                |
| ------------------------ | ----------------------------------------------------------------------- |
| `sdk::sys_exn::flags`    | Throwing versions, re-exported at crate root                            |
| `sdk::sys_result::flags` | Non-throwing versions returning `Result`                                |
| Usage                    | [Lock requests](pages/programming-model/storage-types.md#lock-requests) |

---

## SDK Macros

Source: <https://thruput.network/reference/sdk-macros/>

Macro targets, parameters, generated APIs, and constraints for the Rust SDK.

| Task                          | Guide                                                           |
| ----------------------------- | --------------------------------------------------------------- |
| Define state and methods      | [Methods and interfaces](pages/contracts/methods.md)            |
| Choose storage                | [Storage types](pages/programming-model/storage-types.md)       |
| Declare and handle failures   | [Handle errors](pages/contracts/errors.md)                      |
| Call another contract         | [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) |
| Define, emit, and test events | [Events](pages/contracts/events.md)                             |
| Register a test contract      | [Testing](pages/programming-model/testing.md)                   |
| Find complete generated APIs  | [Rust API Docs](pages/tools/rust-api-docs.md)                   |



## `#[contract]`



### Applies to

| Target                  | Generates                                               |
| ----------------------- | ------------------------------------------------------- |
| Trait definition        | Client struct and interface metadata                    |
| Trait implementation    | Export functions and mock registration                  |
| Inherent implementation | Export functions, client struct, and interface metadata |
| Free function           | Export function, no client                              |



### Parameters

| Parameter                                    | Default                 | Meaning                                                                                |
| -------------------------------------------- | ----------------------- | -------------------------------------------------------------------------------------- |
| `throws = Error` or `throws(ErrorA, ErrorB)` | None                    | Error types recorded in the spec; does not restrict which exceptions callers can catch |
| `emits(EventA, EventB)`                      | None                    | Event types recorded in the spec                                                       |
| `client = ClientName`                        | `{Interface}Client`     | Generated client name                                                                  |
| `interface = "Name"`                         | Trait or self-type name | Interface identity used for entrypoints                                                |
| `version = "0.1.0"`                          | `CARGO_PKG_VERSION`     | Version used for entrypoint identity                                                   |
| `exports = "name"`                           | Generated               | Internal exports module name                                                           |



### `throws` rules

| Constraint | Rule                                                                                       |
| ---------- | ------------------------------------------------------------------------------------------ |
| Placement  | Trait definition or inherent implementation; rejected on trait implementations             |
| Duplicates | The same type cannot be listed twice; different paths with the same final name are allowed |
| Runtime    | A known exception can be caught whether or not it is declared in `throws`                  |



### `emits` rules

| Constraint       | Rule                                                                                                    |
| ---------------- | ------------------------------------------------------------------------------------------------------- |
| Placement        | Trait definition or inherent implementation; rejected on trait implementations                          |
| Type             | Must implement `Event`                                                                                  |
| Spec             | Records name, signature, topics, and payload layout                                                     |
| Undeclared event | May be emitted; use `#[event_spec(export)]` to include a library event without an interface declaration |



### Generated client

| Method                                           | Behavior                                                                                |
| ------------------------------------------------ | --------------------------------------------------------------------------------------- |
| `ClientName::new(&ContractAddress)`              | Construct a client                                                                      |
| `with_gas_limit(&self, u64) -> Self`             | Return a configured copy with a child gas cap                                           |
| `with_commit_locking(&self) -> Self`             | Request commit locks before the child returns                                           |
| `with_read_only(&self) -> Self`                  | Reject child state changes                                                              |
| `method(&self, ...) -> T`                        | Return the value or propagate failure                                                   |
| `try_method(&self, ...) -> Result<T, CallError>` | Return the value or an inspectable failure                                              |
| Reserved names                                   | `new`, `with_gas_limit`, `with_commit_locking`, `with_read_only`, and the `try_` prefix |



### Inspecting errors

| API                 | Purpose                                                                                               |
| ------------------- | ----------------------------------------------------------------------------------------------------- |
| `match_exn!`        | Match typed exceptions; requires a final `_` arm                                                      |
| `try_as::<E>()`     | Decode one known exception type; returns `None` for a different type or failed decoding               |
| `try_decode::<E>()` | Distinguish unknown type from malformed payload                                                       |
| Usage               | [Error matching examples](pages/contracts/cross-contract-calls.md#matching-exceptions-with-match_exn) |



### Method behavior

| Method                      | Behavior                                                                                 |
| --------------------------- | ---------------------------------------------------------------------------------------- |
| Public inherent method      | Exported                                                                                 |
| Private inherent method     | Internal helper                                                                          |
| Trait implementation method | Exported                                                                                 |
| Storage receiver            | Uses generated storage handles; see [Methods and interfaces](pages/contracts/methods.md) |



## `#[contract_exception]`

| Property            | Value                                                               |
| ------------------- | ------------------------------------------------------------------- |
| Targets             | Structs and enums; no generics                                      |
| Generated derives   | `Debug`, `PartialEq`, `ReadXDR`, `WriteXDR`, `ContractTypeSpec`     |
| Generated traits    | `Exn` and `ContractTypeName`                                        |
| Enum representation | Adds `#[repr(i32)]`; variants require explicit discriminants        |
| `version = "0.1.0"` | Override `CARGO_PKG_VERSION` for identity                           |
| `name = "Name"`     | Override the Rust type name for identity                            |
| `Clone`             | Add the derive explicitly if needed                                 |
| Examples            | [Enum and struct errors](pages/contracts/errors.md#defining-errors) |



### Selector computation

| Component       | Rule                                                                                                                                                                                        |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Selector        | First 8 bytes of `sha256(MAJOR_VERSION :: CRATE_NAME :: TYPE_NAME)`                                                                                                                         |
| `MAJOR_VERSION` | Leftmost nonzero version component: `1.2.3` → `1`, `0.9.2` → `0.9`, `0.0.2` → `0.0.2`                                                                                                       |
| `CRATE_NAME`    | `CARGO_PKG_NAME`                                                                                                                                                                            |
| `TYPE_NAME`     | Type name or explicit `name`                                                                                                                                                                |
| Compatibility   | Stable selector does not guarantee an older caller can decode every new payload; see [decoding errors](pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one) |



## `#[exn]`

| Property                   | Value                                                                             |
| -------------------------- | --------------------------------------------------------------------------------- |
| Purpose                    | Low-level `Exn` implementation with computed selector                             |
| Derives and representation | Supplied by the author; prefer `#[contract_exception]` for normal contract errors |
| `version`                  | Optional selector-version override                                                |



## `#[storage]` / `#[derive(Storage)]`

| Property    | Value                                                                     |
| ----------- | ------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                      |
| Output      | `From<Keypath>` implementation assigning each field a subpath             |
| Fields      | Storage handles; wrap plain data in `Value<T>`                            |
| Collections | Use `Node<T>` to place a compound storage struct inside `Map` or `Vector` |
| Usage       | [Storage types](pages/programming-model/storage-types.md)                 |



## `#[derive(Deletable)]`

| Property    | Value                                                                               |
| ----------- | ----------------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                                |
| Requirement | Every field must implement `Deletable`; `Map` does not                              |
| Output      | Calls each field’s `delete_internal()`; exposes `delete()` and `delete_exclusive()` |



## `#[derive(Event)]`

| Property                     | Value                                                                                                           |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Target                       | Named-field struct                                                                                              |
| `#[topic]`                   | Mark an indexed field; at most two fields, in addition to the signature at topic 0                              |
| Direct topics                | `ContractAddress`, `SHA256Hash`, `[u8; 32]`, `U256`, `I256`, `u32`, `u64`, `u128`, `i32`, `i64`, `i128`, `bool` |
| Integer topics               | Fixed 32-byte big-endian encoding with zero or sign extension                                                   |
| String and byte-slice topics | Hashed; filterable but not recoverable from the topic                                                           |
| Payload                      | Non-topic fields, serialized by the generated `WriteXDR` implementation                                         |
| `#[event_spec(export)]`      | Include the event in the linked contract spec without `emits(...)`                                              |
| `SIGNATURE`                  | Full 32-byte hash of version, defining crate, and type identity                                                 |
| `Event` implementation       | Topic access and payload decoding                                                                               |
| `{Name}Payload`              | Companion payload type with `ReadXDR`                                                                           |
| Usage                        | [Event definitions, emission, and tests](pages/contracts/events.md)                                             |



## Utility Macros

| Macro                                      | Output / usage                                                                                                      |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| `static_key!("slot")`                      | Compile-time SHA-256 `StorageKey`                                                                                   |
| `sha256_static!("text")`                   | Compile-time `SHA256Hash`                                                                                           |
| `sha256_ident!(Name)`                      | `SHA256Hash` of an identifier                                                                                       |
| `hash_ident! { static NAME: SHA256Hash; }` | Named hash static; also supports `ContractAddress` and visibility                                                   |
| `sha256_array_ident!(Name)`                | Identifier hash as `[u8; 32]`                                                                                       |
| `hash_to_array!("text")`                   | String or byte-string hash as `[u8; 32]`                                                                            |
| `declare_mock_contract!()`                 | Crate-root mock registration when `dev` is enabled; see [test setup](pages/programming-model/testing.md#test-setup) |



## `#[contract_type]`

| Property                | Value                                                                                                            |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Targets                 | Named, tuple, or unit structs and enums                                                                          |
| Output                  | Serialization derives and `ContractTypeSpec`                                                                     |
| `name = "Name"`         | Override spec type name                                                                                          |
| `export`                | Include an otherwise unreachable type in the spec                                                                |
| Enum variants           | Explicit discriminants required                                                                                  |
| Generic type parameters | Not supported                                                                                                    |
| Spec inclusion          | Types reachable through method signatures, errors, events, or other reachable types; otherwise requires `export` |
| Spec kind               | Struct, enum without payloads, or union with payloads                                                            |
| Examples                | [Argument and return types](pages/contracts/methods.md#define-argument-and-return-types)                         |



## `#[derive(ContractTypeSpec)]`

| Property                        | Value                                                              |
| ------------------------------- | ------------------------------------------------------------------ |
| Targets                         | Structs and enums                                                  |
| Output                          | `ContractTypeSpec` only; serialization must be supplied separately |
| `#[contract_type_spec(export)]` | Include an otherwise unreachable type in the spec                  |

---

## Syscalls

Source: <https://thruput.network/reference/syscalls/>

Host function numbers, parameters, and errors for Stellar Thruput contracts.

These are the host functions available to Stellar Thruput guest contracts. Most developers use the SDK rather than calling syscalls directly. See [Programming Model: Storage Types](pages/programming-model/storage-types.md) for the high-level API.

The tables below describe the protocol’s logical typed interface. The generated low-level bindings map it to each guest target’s ABI. User contracts use RV32. Variable-length buffers are passed as spans.

The return value is a `SyscallErrorCode`. Any syscall can return `Fault` (1) if a pointer argument is out of guest memory bounds, or `NoSyscall` (2) if the syscall number is not supported. Per-syscall error codes are listed with each entry below, and the full enum is at the bottom of this page.



## Hashing



### SHA256

|            |   |
| ---------- | - |
| **Number** | 0 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |
| out       | `hash`   | `SHA256Hash`  |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the SHA-256 hash of the input buffer.



### SHA256Update

|            |    |
| ---------- | -- |
| **Number** | 26 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `index`  | `u32`         |
| in        | `buffer` | `[u8]` (span) |
| in        | `reset`  | `bool`        |

Errors:

- `InvalidSyscallInput` if the indexed hash buffer does not exist and `reset` is false, the buffer becomes too large, or there are too many active hash buffers.

Updates the SHA-256 hash computation at the specified index with the supplied bytes. If `reset` is true, the hash state is cleared before the update.



### SHA256Finalize

|            |    |
| ---------- | -- |
| **Number** | 27 |

| Direction | Name     | Type         |
| --------- | -------- | ------------ |
| in        | `index`  | `u32`        |
| out       | `output` | `SHA256Hash` |

Errors:

- `InvalidSyscallInput` if the queried hash buffer does not exist (for example, calling finalize twice on the same buffer without an intervening reset).

Finalizes the SHA-256 hash computation at the specified index, returns the digest, and removes the buffer.



### SHA256Copy

|            |    |
| ---------- | -- |
| **Number** | 33 |

| Direction | Name        | Type  |
| --------- | ----------- | ----- |
| in        | `src_index` | `u32` |
| in        | `dst_index` | `u32` |

Errors:

- `InvalidSyscallInput` if the hash computation at `src_index` does not exist, or if `dst_index` does not already hold a hash computation and there are too many active hash buffers.

Copies the in-progress SHA-256 hash computation at `src_index` to `dst_index`, replacing any hash computation already at `dst_index`. Both computations can then be extended and finalized independently. Copying an index onto itself succeeds and changes nothing.



## Calldata



### GetCalldataLen

|            |   |
| ---------- | - |
| **Number** | 2 |

| Direction | Name               | Type                  |
| --------- | ------------------ | --------------------- |
| out       | `len`              | `RuntimeMemoryLength` |
| out       | `auth_token_count` | `u32`                 |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the length of the calldata supplied to the invocation associated with the current call frame, plus the number of auth tokens supplied to that invocation.



### GetCalldata

|            |   |
| ---------- | - |
| **Number** | 3 |

| Direction | Name                     | Type                                  |
| --------- | ------------------------ | ------------------------------------- |
| out       | `buffer`                 | `[u8]` (span)                         |
| out       | `written_len`            | `RuntimeMemoryLength`                 |
| out       | `auth_token_list`        | `[u8]` (span, interpreted as `[u32]`) |
| out       | `auth_token_written_len` | `RuntimeMemoryLength`                 |

Errors:

- `InvalidSyscallInput` if the `auth_token_list` output span byte length is not a multiple of the size of a `u32`.

Returns the calldata and the auth-token id list supplied to the invocation associated with the current call frame.



## Logging



### ConsoleLog

|            |   |
| ---------- | - |
| **Number** | 4 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Logs the input buffer to the console. No-op on release builds and on-chain; calling it from a production contract is harmless but pointless.



### LogEvent

|            |    |
| ---------- | -- |
| **Number** | 24 |

| Direction | Name     | Type                         |
| --------- | -------- | ---------------------------- |
| in        | `topic0` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic1` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic2` | `Option<Topic>` (`[u8; 32]`) |
| in        | `data`   | `[u8]` (span)                |

Errors:

- `InvalidSyscallInput` if the event data exceeds the maximum event length, or if topics are not supplied as a continuous prefix (e.g., supplying `topic0` and `topic2` but not `topic1`).

Emits an event with up to three 32-byte topics and a data payload. The serialized event is `topic0 || topic1 || topic2 || data`, with a separate `num_topics` field that lets downstream indexers filter on the leading topic chunks. Events are accumulated into a per-block merkle-patricia trie.



## Invocation



### Invoke

|            |   |
| ---------- | - |
| **Number** | 5 |

| Direction | Name                        | Type                                                                                     |
| --------- | --------------------------- | ---------------------------------------------------------------------------------------- |
| in        | `address`                   | `ContractAddress`                                                                        |
| in        | `calldata`                  | `[u8]` (span)                                                                            |
| in        | `owned_auth_token_ids_list` | `[u8]` (span, interpreted as `[u32]`)                                                    |
| in        | `inputs`                    | `CopyableInvokeInputs` (`entrypoint_id`, `gas_limit`, `flags`)                           |
| out       | `outputs`                   | `CopyableInvokeOutputs` (`return_buffer_len`, `returned_auth_token_len`, `frame_status`) |

Errors:

- `InvalidSyscallInput` if the call is rejected before a child frame runs: the target is missing, the flags are invalid, or an auth-token id is malformed, duplicated, or not owned by the current frame.
- `Reentrance` if the invoked address is already on the call stack.
- `InvokeDepthExceeded` if the transaction already holds the maximum number of invocation frames open. Like `Reentrance`, the call is rejected before any child frame runs and the syscall is a no-op. This is a resource limit rather than a malformed call: the same invocation succeeds from a shallower frame.

Invokes the specified entrypoint of the contract at `address` with the supplied calldata and auth tokens, creating a new call frame. The new frame is capped at `min(gas_limit, remaining gas in current frame)`; unused child-frame gas returns to the caller’s execution budget. This is not a token refund. The SDK defaults `gas_limit` to `u64::MAX` so the child inherits everything the parent has left.

`entrypoint_id` is the little-endian interpretation of an 8-byte `ContractEntrypointID`. `frame_status` is `Return`, `Abort`, or `Fault`; it reports the outcome after a child frame actually runs. A nonzero syscall error means the call was rejected before the child ran and the output struct is untouched.



### GetMsgSender

|            |   |
| ---------- | - |
| **Number** | 1 |

| Direction | Name     | Type              |
| --------- | -------- | ----------------- |
| out       | `sender` | `ContractAddress` |

Errors:

- `IsRootTransaction` if there is no caller (the syscall was made from a root transaction frame).

Returns the contract address of the contract that invoked the current call frame.



### GetCurrentAddress

|            |    |
| ---------- | -- |
| **Number** | 19 |

| Direction | Name      | Type              |
| --------- | --------- | ----------------- |
| out       | `address` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the contract address of the current call frame.



## Return



### Return

|            |   |
| ---------- | - |
| **Number** | 6 |

| Direction | Name                      | Type                                  |
| --------- | ------------------------- | ------------------------------------- |
| in        | `buffer`                  | `[u8]` (span)                         |
| in        | `revert_frame`            | `bool`                                |
| in        | `returned_auth_token_ids` | `[u8]` (span, interpreted as `[u32]`) |

Errors: none beyond the universal `Fault` / `NoSyscall`. Does not return to the caller (terminates execution of the current guest invocation).

Returns data and a set of auth-token ids from the current call frame and optionally marks the frame for revert. The return buffer is made available to the caller via `GetReturnedBuffer`. If the supplied buffer is too large, the entire invocation is reverted with a deterministic error.



### GetReturnedBuffer

|            |   |
| ---------- | - |
| **Number** | 7 |

| Direction | Name                                  | Type                                  |
| --------- | ------------------------------------- | ------------------------------------- |
| out       | `buffer`                              | `[u8]` (span)                         |
| out       | `written_len`                         | `RuntimeMemoryLength`                 |
| out       | `restored_auth_token_ids`             | `[u8]` (span, interpreted as `[u32]`) |
| out       | `restored_auth_token_ids_written_len` | `RuntimeMemoryLength`                 |

Errors:

- `NoReturnBufferAvailable` if no return buffer is available (either the most recent subcall failed, or no subcall has been made in this frame).
- `InvalidSyscallInput` if the `restored_auth_token_ids` output span byte length is not a multiple of the size of a `u32`.

Returns the return buffer and any restored auth-token ids from the most recent successful subcall invocation.



### Exit

|            |   |
| ---------- | - |
| **Number** | 8 |

No inputs. No outputs. Does not return.

Errors: none beyond the universal `Fault` / `NoSyscall`.

Terminates the current call frame immediately. The frame reverts and the caller sees a deterministic error with no return buffer available.



## Storage



### BytestringGetLen

|            |    |
| ---------- | -- |
| **Number** | 13 |

| Direction | Name     | Type                     |
| --------- | -------- | ------------------------ |
| in        | `key`    | `StorageKeyContractData` |
| out       | `length` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist in the current transaction view.
- `InvalidSyscallInput` if the key exists but holds a different storage type (e.g. NNInt rather than bytestring).

Returns the length of the bytestring stored at `key`.



### BytestringGet

|            |    |
| ---------- | -- |
| **Number** | 14 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| out       | `bytestring`  | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted.
- `InvalidSyscallInput` if the key exists but holds a different storage type.

Retrieves the bytestring stored at `key`.



### BytestringSet

|            |    |
| ---------- | -- |
| **Number** | 15 |

| Direction | Name         | Type                     |
| --------- | ------------ | ------------------------ |
| in        | `key`        | `StorageKeyContractData` |
| in        | `bytestring` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the bytestring is too long.

Writes the bytestring value at `key`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged.



### NonnegativeIntGet

|            |    |
| ---------- | -- |
| **Number** | 16 |

| Direction | Name                       | Type                     |
| --------- | -------------------------- | ------------------------ |
| in        | `key`                      | `StorageKeyContractData` |
| in        | `force_load_from_snapshot` | `bool`                   |
| out       | `current_set`              | `i128`                   |
| out       | `current_set_opt`          | `bool`                   |
| out       | `current_add`              | `i128`                   |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted (only returned when `force_load_from_snapshot` is true).
- `InvalidSyscallInput` if the key exists but holds a different storage type (only returned when `force_load_from_snapshot` is true).

Retrieves the NNInt value at `key`.

If `force_load_from_snapshot` is true, `current_set` will never be null: the syscall reads the snapshot value. A snapshot that is not an NNInt, or a prior write on this key that is not an NNInt, returns `InvalidSyscallInput`. A snapshot that does not exist, or was deleted by a prior write, returns `StorageKeyNotExist`.

If `force_load_from_snapshot` is false, the prior snapshot state is ignored unless the prior write on `key` is itself an NNInt write (in which case the parameters of that write are returned). If the prior write is not an NNInt or was a deletion, the syscall returns `(None, 0)` without error.



### NonnegativeIntSetAdd

|            |    |
| ---------- | -- |
| **Number** | 17 |

| Direction | Name        | Type                     |
| --------- | ----------- | ------------------------ |
| in        | `key`       | `StorageKeyContractData` |
| in        | `set_value` | `Option<i128>`           |
| in        | `add_value` | `i128`                   |

Errors:

- `InvalidSyscallInput` if the operation would always violate the NNInt floor (for example `set_add(1, -2)` or `set_add(-1, -1)`).

Sets or modifies the NNInt at `key`. `set_value` (if `Some`) supplies the base, and `add_value` is added as a delta. The resolved value must satisfy `value >= min(set, 0)`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged. See [Programming Model: NNInt](pages/programming-model/nnint.md) for commutativity rules.



### DeleteObject

|            |    |
| ---------- | -- |
| **Number** | 18 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Deletes the object at `key`. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged.



## Storage Flags

A transaction keeps one `StorageDeltaFlagSet` per storage key, separate from its writes. Every change the transaction commits on a key carries that key’s flags. `ExclusiveLock` (`0x1`) is the only flag: it gives the key’s change an exclusive lock for the whole block, so no concurrent transaction in the block can modify the key.

Writes never change a key’s flags. A lock requested after one write stays on the key through later writes in the same transaction, including writes from other call frames, until `ClearStorageFlags` withdraws it. Flag changes follow call frames like writes do: a successful frame passes them to its caller, and a reverted frame or failed `try_invoke` discards them.

Each flag syscall costs the same storage access gas as a write and does not read the ledger.



### SetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 36 |

| Direction | Name    | Type                                    |
| --------- | ------- | --------------------------------------- |
| in        | `key`   | `StorageKeyContractData`                |
| in        | `flags` | `StorageDeltaFlagSet` (`u32`, by value) |

Errors:

- `InvalidSyscallInput` if `flags` contains an unknown flag, or no write to `key` is pending in the current call frame’s view of the transaction.

Adds `flags` (bitwise OR) to the flags the transaction requests for `key`. A pending write is one made earlier in this frame, or inherited from a caller or a successful callee. A pending deletion counts. A value that exists only in the block snapshot does not.



### GetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 37 |

| Direction | Name    | Type                     |
| --------- | ------- | ------------------------ |
| in        | `key`   | `StorageKeyContractData` |
| out       | `flags` | `StorageDeltaFlagSet`    |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the flags the transaction requests for `key`, as visible in the current call frame. A key with no pending write returns `None` (`0`). Allowed in read-only frames.



### ClearStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 38 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Removes every flag the transaction requests for `key`, as visible in the current call frame. Does nothing if no write to `key` is pending.



## Retrocausal Queue



### RetrocausalQueueInsert

|            |    |
| ---------- | -- |
| **Number** | 20 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `queue_entry` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type that cannot be converted to a retrocausal queue, if the entry is too large, or if too many entries are inserted in the current transaction.

Inserts an entry into the retrocausal queue at `key`.



### RetrocausalQueueConsume

|            |    |
| ---------- | -- |
| **Number** | 21 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `peek`        | `bool`                   |
| out       | `queue_entry` | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `NoRetrocausalQueueEntry` if the queue is empty.
- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Consumes (or with `peek = true`, only inspects) the next entry from the retrocausal queue at `key`.



### RetrocausalQueuePeekLen

|            |    |
| ---------- | -- |
| **Number** | 30 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |
| out       | `len` | `RuntimeMemoryLength`    |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `NoRetrocausalQueueEntry` if the queue is empty.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Returns the length (in bytes) of the next entry in the retrocausal queue at `key`.



## Auth



### VerifySignature

|            |    |
| ---------- | -- |
| **Number** | 12 |

| Direction | Name         | Type                        |
| --------- | ------------ | --------------------------- |
| in        | `scheme`     | `i32` (CryptographicScheme) |
| in        | `signature`  | `[u8]` (span)               |
| in        | `public_key` | `[u8]` (span)               |
| in        | `message`    | `[u8]` (span)               |

No outputs: the result is the `SyscallErrorCode` itself (`None` on success).

Errors:

- `InvalidSyscallInput` if verification fails or the inputs are malformed (wrong key/signature size for the chosen scheme, unsupported scheme, etc.).

Verifies a cryptographic signature against a public key and message.



### GetAuthClaim

|            |    |
| ---------- | -- |
| **Number** | 25 |

| Direction | Name         | Type        |
| --------- | ------------ | ----------- |
| out       | `auth_claim` | `AuthClaim` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the authentication claim associated with the current transaction. Takes no input.



### ChangePublicKeyRegistration

|            |    |
| ---------- | -- |
| **Number** | 23 |

| Direction | Name         | Type                                |
| --------- | ------------ | ----------------------------------- |
| in        | `key_index`  | `u32`                               |
| in        | `key_scheme` | `Option<i32>` (CryptographicScheme) |
| in        | `key_bytes`  | `[u8]` (span)                       |
| in        | `key_weight` | `Option<u32>`                       |

Errors:

- `InvalidSyscallInput` if the registration is invalid or `key_index` is out of bounds.

Changes the public key registration for the current contract address at `key_index`. If `key_scheme` is `None`, the key is removed. Otherwise the key is set with the supplied scheme, bytes, and weight.



### WriteAddressRequiredWeight

|            |    |
| ---------- | -- |
| **Number** | 28 |

| Direction | Name              | Type                       |
| --------- | ----------------- | -------------------------- |
| in        | `required_weight` | `Weight` (`u32`, by value) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Writes the required-weight threshold for the current contract address. This is the minimum total weight of signing keys needed to authorize a transaction from this address.



### MintAuthToken

|            |    |
| ---------- | -- |
| **Number** | 31 |

| Direction | Name                    | Type          |
| --------- | ----------------------- | ------------- |
| in        | `expiry_height`         | `BlockHeight` |
| in        | `serialized_auth_token` | `[u8]` (span) |
| out       | `token_id`              | `u32`         |

Errors:

- `InvalidSyscallInput` if the serialized token fails to parse as a valid `AuthToken`, `expiry_height` is in the past, or minting would exceed the per-transaction auth-token cap.

Mints an authentication token for the current contract address.



### ConsumeAuthToken

|            |    |
| ---------- | -- |
| **Number** | 32 |

| Direction | Name                       | Type                  |
| --------- | -------------------------- | --------------------- |
| in        | `token_id`                 | `u32`                 |
| out       | `auth_payload`             | `[u8]` (span)         |
| out       | `token_minter`             | `ContractAddress`     |
| out       | `auth_payload_written_len` | `RuntimeMemoryLength` |
| out       | `unwrapped_token_id_start` | `u32`                 |
| out       | `unwrapped_token_id_count` | `u32`                 |

Errors:

- `InvalidSyscallInput` if the token is not owned by the current contract address, or the token has expired.

Consumes an authentication token owned by the current contract address. Returns the token’s auth payload, its minter, and the id range of any nested tokens unwrapped as a side effect.



## Address



### GetDeployAddress

|            |   |
| ---------- | - |
| **Number** | 9 |

| Direction | Name             | Type              |
| --------- | ---------------- | ----------------- |
| in        | `caller_address` | `ContractAddress` |
| in        | `nonce`          | `SHA256Hash`      |
| in        | `contract_hash`  | `SHA256Hash`      |
| out       | `to_be_deployed` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Computes the address that would be deployed for a contract with the given deployer address, nonce, and contract hash. Pure computation; does not deploy anything.



### DeployContract

|            |    |
| ---------- | -- |
| **Number** | 10 |

| Direction | Name               | Type              |
| --------- | ------------------ | ----------------- |
| in        | `nonce`            | `SHA256Hash`      |
| in        | `contract_hash`    | `SHA256Hash`      |
| out       | `deployed_address` | `ContractAddress` |

Errors:

- `InvalidSyscallInput` if the requested contract is not available for deployment, or the contract is a special precompiled (native) contract that cannot be deployed. A contract must either already exist on chain or be supplied in the transaction’s `contracts_to_deploy` field.
- `ContractAlreadyDeployed` if a contract with the same nonce and contract hash has already been deployed at the computed address in a previous block or earlier in this transaction. A contract can be deployed multiple times concurrently in the same block; if a contract must initialize only once, gate the initialization on a semaphore.

Deploys a contract with the specified nonce and contract hash at the computed address.



## Block



### GetBlockHeight

|            |    |
| ---------- | -- |
| **Number** | 29 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| out       | `result` | `BlockHeight` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the current block height.



### GetBlockTimepoint

|            |    |
| ---------- | -- |
| **Number** | 35 |

| Direction | Name              | Type        |
| --------- | ----------------- | ----------- |
| out       | `block_timepoint` | `TimePoint` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the timepoint of the block currently executing. The value is fixed by the coordinator before execution begins and is carried in the block’s `ProposalHeader`, so it is part of the block identity and is identical for every invocation in the block.

Like a block height, this is consensus data rather than a trusted clock: it is chosen by the proposer within whatever bounds the network’s validators enforce. Contracts should treat it as coarse-grained wall-clock time, suitable for expiries, vesting schedules, and deadlines, and must not rely on it for fine-grained ordering or as a source of randomness.



## Network



### GetNetworkHash

|            |    |
| ---------- | -- |
| **Number** | 34 |

| Direction | Name           | Type          |
| --------- | -------------- | ------------- |
| out       | `network_hash` | `NetworkHash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the network name, the identifier that separates this network’s blocks from those of every other network. It is fixed for the life of the network, so it is constant across every block and every invocation.

Transaction signatures already commit to this value (the signature preimage is `cxs(DomainSeparator("Transaction")) || network_hash || xdr(tx)`). Exposing it to contracts lets a contract bind its own off-chain signed messages to this network the same way, so a message signed for one network cannot be replayed against a contract at the same address on another.



## Transaction



### GetSourceTransactionHash

|            |    |
| ---------- | -- |
| **Number** | 11 |

| Direction | Name             | Type         |
| --------- | ---------------- | ------------ |
| out       | `source_tx_hash` | `SHA256Hash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the transaction that initiated the current execution.



### GetTransactionStatistics

|            |    |
| ---------- | -- |
| **Number** | 22 |

| Direction | Name        | Type                   |
| --------- | ----------- | ---------------------- |
| in        | `statistic` | `TransactionStatistic` |
| out       | `result`    | `u64`                  |

Errors:

- `InvalidSyscallInput` if the requested statistic does not exist or is not available in this configuration.

Returns a transaction statistic. Statistics may be disabled in release builds or production execution, and may be nondeterministic in test configurations. Nondeterministic stats are disabled in production settings.



## Error Codes

The full `SyscallErrorCode` enum, from `protocol/syscall_error.x`:

| Code | Name                               | Description                                                                                                                                                                                                                              |
| ---- | ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 0    | `None`                             | Success.                                                                                                                                                                                                                                 |
| 1    | `Fault`                            | A pointer argument is out of guest memory bounds. Any syscall can return this.                                                                                                                                                           |
| 2    | `NoSyscall`                        | The supplied syscall number is not supported. Any syscall can return this.                                                                                                                                                               |
| 3    | `IsRootTransaction`                | Cannot call `GetMsgSender` from a root invocation.                                                                                                                                                                                       |
| 4    | `Reentrance`                       | Reentrance guard violation: the invoked address is already on the call stack.                                                                                                                                                            |
| 5    | `ContractAlreadyDeployed`          | Attempt to deploy a contract twice (same nonce, contract hash, and deployer).                                                                                                                                                            |
| 6    | `NoReturnBufferAvailable`          | No return buffer from a child call frame. Either the most recent subcall failed or no subcall has been made in this frame.                                                                                                               |
| 7    | `InvalidSyscallInput`              | Invalid input to a syscall (type mismatch, value out of range, data too long, unknown storage flag, etc.).                                                                                                                               |
| 8    | `StorageKeyNotExist`               | The storage key does not exist in the current view.                                                                                                                                                                                      |
| 9    | `NoRetrocausalQueueEntry`          | The retrocausal queue is empty.                                                                                                                                                                                                          |
| 10   | `RetrocausalQueueReadLimitReached` | The transaction reached its concurrent RCQ read limit. The contract may use this as a stop condition.                                                                                                                                    |
| 11   | `InvokeDepthExceeded`              | The transaction already holds the maximum number of invocation frames open, so another would exceed the network’s cross-invoke depth bound. A resource limit, not a malformed call: the same invocation succeeds from a shallower frame. |

---

## TypeScript

Source: <https://thruput.network/typescript/>

Connect applications and services to Stellar Thruput with the TypeScript client and typed contract bindings.

Build browser applications, Node.js services, and scripts with `@thruputchain/client`. You can read an existing contract without a wallet, signing key, Rust installation, or deployment.



## The application model

A **public client** connects to an RPC endpoint and reads network data. A **contract binding** describes methods, arguments, results, errors, and events. Together they provide typed contract reads.

Writes also need an **account** and authorization. A browser app connects to the user’s wallet provider. A script or service can manage a signer directly. A wallet client wraps application calls into a transaction, signs it, submits it, and observes its result.

```text
Read:   contract binding + public client → typed result
Write:  contract binding + wallet client → signed transaction → receipt
```



## How the packages fit

| Package or entry point           | Role                                                                                    |
| -------------------------------- | --------------------------------------------------------------------------------------- |
| `@thruputchain/client`           | RPC clients, accounts, wallet helpers, amounts, and contract runtime                    |
| `@thruputchain/client/contracts` | Standard contract bindings supplied with the client, including ERC-20 and DefaultWallet |
| `@thruputchain/protocol`         | Wire types, serialization, and protocol constants such as `HOG_ADDRESS`                 |
| `@thruputchain/contract-spec`    | Contract schema tooling; most applications use the generated binding instead            |
| `@thruputchain/react`            | React integration over the client and wallet model; see [React](pages/react.md)         |

Generated bindings are application files, not a replacement for the client package. They import its contract runtime.



## Start with an existing contract

The [TypeScript quickstart](pages/get-started/typescript.md) reads Futurenet’s native-token contract using its supplied binding and address. [Read contract data](pages/typescript/reads.md) uses the same checkpoint, so you can learn the application APIs without first writing a contract.

For a custom contract, obtain its generated bindings, deployment address, and network from its author. [Use contract bindings](pages/tools/typescript-bindings.md) explains how those pieces fit.

[Read events](pages/typescript/events.md) completes the read-only path with filters, decoding, and historical pagination. It also needs no wallet or signer.



## Add writes

Read [Accounts and wallet clients](pages/typescript/wallet-clients.md) to understand account identity, authorization, and call wrapping. Then choose one integration path for your application:

- [Connect a wallet](pages/tools/wallet-integration.md) when the user’s browser wallet manages approval and signing.
- [Use a signer in scripts](pages/typescript/accounts.md) when your Node.js process manages the account key.

These are alternatives, not consecutive setup steps. Both lead to [Send transactions](pages/typescript/transactions.md) and [Track transaction results](pages/typescript/transaction-status.md). [Deploy a contract](pages/typescript/deployment.md) builds on that transaction flow when your application needs to create a deployment.

Complete applications live in [Guides](pages/guides.md). This section covers individual tasks; [Client API reference](pages/tools/typescript-sdk.md) and [Wallet provider reference](pages/tools/wallet-provider.md) provide lookup tables.

---

## Package setup

Source: <https://thruput.network/typescript/setup/>

Configure access to Stellar Thruput's JavaScript packages for TypeScript and React applications.

The private `@thruputchain` TypeScript client and React library are distributed through GitHub Packages. Configure registry access once, then install the packages your application imports.



## Before you start

- Install Node.js 22.12 or newer and npm.
- Obtain access to Stellar Thruput’s GitHub packages.
- Install the [GitHub CLI](https://cli.github.com/) and sign in with `gh auth login`.



## Give npm package access

Authorize package reads, then make the token available to npm in this terminal:

```bash
gh auth refresh -h github.com -s read:packages
export NODE_AUTH_TOKEN="$(gh auth token)"
```

Create a `.npmrc` file in the application directory:

```ini
@thruputchain:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Keep `${NODE_AUTH_TOKEN}` as a literal reference in this file. Do not replace it with the token. If your environment already supplies a package-read token, use that instead of the GitHub CLI commands.

Use the latest packages when starting a new project and keep the generated lockfile. A package-access error needs an account or token with the required permissions; repository access alone may not be enough.



## Install the TypeScript client

In a new application directory:

```bash
npm init -y
npm pkg set type=module
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src
```

In an existing application, keep its package configuration and add the dependencies you need. `tsx` runs the Node.js examples; browser apps can use their existing bundler.

The client re-exports common types and constructors. Install the protocol package directly when you import protocol-only constants such as `HOG_ADDRESS`. Schema tooling can import `@thruputchain/contract-spec`; ordinary generated bindings use the client runtime.



## Type-check an application

For the Node.js examples, create `tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "skipLibCheck": true,
    "noEmit": true
  },
  "include": ["src/**/*.ts"]
}
```

```bash
npx tsc
```

The examples use ESM imports and `.js` paths for local TypeScript modules. Browser projects should keep the module settings required by their bundler.

---

## Connect to a network

Source: <https://thruput.network/typescript/connect/>

Create a public client, select Futurenet or a local endpoint, and check network identity.

A public client performs RPC reads without signing. Create one per application network and share it across contract bindings and wallet clients.



## Connect to Futurenet

Create `src/client.ts`:

```ts
import { createThruputClient, devnet } from "@thruputchain/client";

export const client = await createThruputClient({ cluster: devnet() });
```

Client creation is asynchronous. It fetches the network identity before returning. Other examples import this client from `./client.js`.

To check the connection, create `src/network.ts`:

```ts
import { toHex0x } from "@thruputchain/client";
import { client } from "./client.js";

const [tip, version] = await Promise.all([
  client.getChainTip(),
  client.getVersion(),
]);
console.log("Network:", toHex0x(client.network.networkHash));
console.log("Block:", tip.height.toString());
console.log("Wire format:", version.wireFormat);
```

```bash
npx tsx src/network.ts
```

No wallet permission or account funding is required.



## Select another endpoint

The SDK helper is still named `devnet()` for compatibility. `devnet({ rpcUrl })` overrides the Futurenet endpoint. For a local node, replace the cluster with `localnet()`:

```ts
import { createThruputClient, localnet } from "@thruputchain/client";

const client = await createThruputClient({ cluster: localnet() });
```

Start the node with [the CLI](pages/cli/local-node.md) first. Local account manifests and RPC endpoints must refer to the same node.

Use `defineCluster()` for a reusable custom descriptor. `mainnet()` requires an explicit endpoint. Cluster capabilities, such as `airdrop`, declare expected services; they are not server capability discovery.



## Pin a network identity

Futurenet is unpinned by default. To require a specific deployment, provide the trusted hash from your environment:

```ts
import { createThruputClient, devnet, hashFromHex, networkHash } from "@thruputchain/client";

const expected = process.env.THRUPUT_NETWORK_HASH;
if (!expected) throw new Error("Set THRUPUT_NETWORK_HASH to the expected 0x-prefixed hash");
const client = await createThruputClient({
  cluster: devnet({ networkHash: networkHash(hashFromHex(expected)) }),
});
```

An identity mismatch throws `NetworkMismatchError`. A Futurenet reset can change the network hash. Update the trusted configuration deliberately rather than accepting a wallet-supplied hash as your application’s network.



## Configure transport behavior

Use [HTTP transport](pages/typescript/transport.md) for timeouts, batching, and custom transports. A transport-only client skips cluster identity validation; a wallet bound to it requires an explicit signing network hash.

---

## Configure HTTP transport

Source: <https://thruput.network/typescript/transport/>

Set RPC timeouts, batch independent reads, and classify transport failures.

The client uses HTTP JSON-RPC by default. Supply `HttpTransport` when you need explicit timeout, header, or batching settings.



## Set a request timeout

```ts
import { createThruputClient, devnet, HttpTransport } from "@thruputchain/client";

const cluster = devnet();
const client = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, { timeoutMs: 10_000 }),
});
```

The cluster still controls identity checks; the transport controls requests to the endpoint. A timeout ends observation of that request, not an already-submitted transaction.



## HTTP batching

Batch independent RPC reads into fewer HTTP requests:

```ts
const batched = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, {
    batch: { maxSize: 100, waitMs: 0 },
    timeoutMs: 10_000,
  }),
});
const [tip, version] = await Promise.all([
  batched.getChainTip(),
  batched.getVersion(),
]);
```

Batching is off by default. `batch: true` uses the defaults shown. Concurrent requests are grouped within the scheduling window and split at `maxSize`.

- Responses match by request ID, not array position.
- Per-call RPC errors remain separate. HTTP or malformed-batch failures reject affected requests.
- Cancellation removes one caller; canceling every caller can cancel the shared request.
- HTTP batching does not provide a shared state snapshot or an atomic transaction. Use [shared-snapshot reads](pages/typescript/reads.md#read-related-values-from-one-snapshot) when related contract values must come from one state; awaiting separate reads does not make their snapshots match.

Server [array and byte limits](pages/reference/json-rpc-api.md#json-rpc-arrays) still apply.



## Handle transport errors

| Error                                       | Boundary                                                        |
| ------------------------------------------- | --------------------------------------------------------------- |
| `HttpRequestError`                          | Network request failed                                          |
| `HttpResponseError`                         | Non-success HTTP status                                         |
| `JsonRpcError`                              | RPC error response; includes `code`, `data`, and method context |
| `ContractViewError` / `ContractDecodeError` | Contract outcome or decoding, not transport                     |

Use `classifyReadError(error, { signal })` when implementing a bounded read-retry policy. See [read cancellation](pages/typescript/reads.md#cancel-stale-reads). Do not apply automatic read retries to transaction submission.



## Use a custom transport

Implement the exported `Transport` interface when integrating another request layer. A client created with only a transport has no validated cluster identity. For wallet use, provide a trusted signing network hash and verify the endpoint separately, or supply a cluster descriptor as above.

---

## Addresses and amounts

Source: <https://thruput.network/typescript/values/>

Parse and display exact amounts, addresses, and hashes in a TypeScript application.

Contract integers are JavaScript `bigint` values. Addresses and hashes are typed byte arrays. Convert at the application’s input and display boundaries.



## Parse and display amounts

```ts
import { parseUnits, formatUnits } from "@thruputchain/client";

const amount = parseUnits("12.05", 2); // 1205n
console.log(formatUnits(amount, 2));  // "12.05"
const oneHog = parseUnits("1", 7);    // 10000000n
```

Both helpers support 0–255 decimals and signed amounts. Parsing rejects whitespace, exponents, and excess precision rather than rounding. `ParseUnitsError.code` is `malformed` or `precision`; invalid decimal counts throw `RangeError`.

The native token has seven decimal places. Other tokens choose their own decimals. Check positivity and the contract’s integer bounds separately. Avoid converting amounts to `number`, which can lose precision.



## Convert addresses and hashes

```ts
import { addressFromHex, hashFromHex, toHex0x } from "@thruputchain/client";

export function parseInputs(addressText: string, transactionText: string) {
  const address = addressFromHex(addressText);
  const txHash = hashFromHex(transactionText);
  return { address, txHash, displayAddress: toHex0x(address) };
}
```

These inputs use `0x`-prefixed hex. Provider session network hashes use a different wire format: 64 lowercase hex characters without `0x`. Convert explicitly when crossing the [wallet provider](pages/tools/wallet-provider.md#canonical-data-and-limits) boundary.

Use `gasAmount(500_000n)` for a typed gas budget. A gas amount is a computation limit, not a native-token amount.



## Store values in application data

JavaScript’s default JSON serializer does not accept `bigint`. For application-owned storage, use decimal strings for integers and a defined byte encoding for addresses, hashes, and cursors. The client handles RPC serialization itself.

---

## Use contract bindings

Source: <https://thruput.network/tools/typescript-bindings/>

Select a generated interface, bind a deployment address, and work with typed arguments and results.

Bindings describe a contract’s API. The client runtime uses them to encode arguments and decode results, exceptions, and events. A binding does not select a network or deployment address.



## Obtain the binding

The client supplies standard bindings such as `ERC20` through `@thruputchain/client/contracts`. For a custom contract, obtain its generated `.ts` file, address, and network from the contract author.

Generate a binding yourself only when you have its build or canonical spec. See [CLI code generation](pages/cli/codegen.md) and [the contract-side handoff](pages/contracts/client-bindings.md).



Regenerate when methods, argument or return types, declared exceptions, or events change. Keep the generated file and deployment from the same interface build. Put application wrappers in separate files.



## Select an Interface Version

```ts
import { ERC20 } from "@thruputchain/client/contracts";

const tokenInterface = ERC20.v0_1;
```

Methods and their types live under an interface’s compatibility major. A generated counter might export `Counter.v0_1`; use the actual exports in its generated file rather than reconstructing names.

```ts
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;
const args: CounterVersions.v0_1.IncrementArgs = { amount: 1n };
```

The value alias does not create a TypeScript type namespace. Keep the full path for explicit type annotations.



## Bind a deployment

```ts
import { getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
const supply = await hog.totalSupply.view({ args: undefined });
```

`getContract` binds the descriptor to an address and client. It does not deploy or authorize anything. Use [Read contract data](pages/typescript/reads.md) for view behavior and caller context.



## Method Descriptors

| API                                                               | Purpose                                                                                                         |
| ----------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `method.invocation(contract, gasLimit, args)`                     | Build calldata and the target invocation                                                                        |
| `method.call({ contract, gasLimit, args })`                       | Retain result and exception decoders with the invocation                                                        |
| `method.view({ client, contract, args, minHeight?, signal? })`    | Read a typed value with height, gas use, and events; optional freshness floor                                   |
| `method.viewOutcome(...)`                                         | Return a typed return/abort/fault outcome                                                                       |
| `method.viewRequest({ contract, args, caller? })`                 | Prepare an independent read with its decoder for `client.readViews`; no I/O, and freshness belongs to the group |
| `method.decodeArgs(bytes)`                                        | Decode complete calldata                                                                                        |
| `method.decodeReturn(bytes)` / `decodeException(bytes)`           | Decode known method output                                                                                      |
| `method.decodeReceipt(receipt)` / `decodeReceiptOutcome(receipt)` | Decode a receipt for that root method                                                                           |

Direct descriptor calls can omit absent arguments. Bound argumentless views use `{ args: undefined }`. Public argument names use camelCase; ABI names remain in metadata. Contract integers use `bigint`.

Existing generated bindings gain `viewRequest()` through the client runtime; this feature needs no new codegen metadata. See [shared-snapshot reads](pages/typescript/reads.md#read-related-values-from-one-snapshot) for grouped calls and [minimum heights](pages/typescript/reads.md#read-after-confirmation) for single reads.



## Execute and Decode

Build calls with `.call(...)` when the application needs typed return values, then pass them to a wallet’s `executeCallsAndWait`. Returned values follow call order. See [Send transactions](pages/typescript/transactions.md).

Receipt decoders require the known root method. For wallet-wrapped calls, use the wallet execution helpers or `decodeExecution(receipt, calls)` instead of treating the receipt as the child’s receipt. See [Track transaction results](pages/typescript/transaction-status.md#decode-the-correct-method).



## Exceptions

Each interface exposes declared and unknown exception types. A declared exception has `kind: "declared"`, selector, name, decoded value, and a symbolic variant for enum errors. An unknown selector has `kind: "unknown"`, selector, and its raw data.

Return and declared-exception decoders reject trailing bytes. Unknown exceptions retain the bytes they cannot interpret. A successful transaction whose result cannot be decoded is still a successful execution.



## Events



Events use their defining crate, version, module, and type path. A descriptor builds topic filters, decodes event rows, and selects events from receipts. See [Read events](pages/typescript/events.md) for examples and pagination.



## Type Mapping

Bindings describe structs, enum variants, unions, tuples, and optional values. Use the generated types rather than rebuilding their shapes or encoding calldata manually.

| Contract type              | TypeScript type                        |
| -------------------------- | -------------------------------------- |
| Void                       | `void`                                 |
| Bool                       | `boolean`                              |
| Integer                    | `bigint`                               |
| String                     | `string`                               |
| Address                    | `ContractAddress`                      |
| Bytes / vector of u8       | `Uint8Array`                           |
| Other vectors              | `T[]`                                  |
| Fixed bytes                | `FixedBytes<N>`                        |
| Fixed arrays of length 0–3 | Exact readonly tuple                   |
| Longer fixed arrays        | `FixedArray<T, N>`                     |
| Tuple                      | Readonly tuple                         |
| Option                     | `T \| null`                            |
| Named struct               | Interface in its spec-ID namespace     |
| Enum                       | Bigint value union and const object    |
| Union                      | Discriminated `{ case, value? }` union |
| SignedToken                | `SignedToken<T>` placeholder           |

`fixedBytes` validates and brands mutable bytes; `fixedArray` returns a frozen copy. `signedToken<T>()` supplies a zero-byte placeholder, not authorization. See [Addresses and amounts](pages/typescript/values.md) for input conversion.



## Standard Bindings

The client includes versioned DefaultWallet and ERC-20 interfaces, plus related metadata, permit, and signed-operation interfaces. Use the [generated client API](https://client-ts.thruput.network/) for the complete export list.

---

## Read contract data

Source: <https://thruput.network/typescript/reads/>

Read typed contract values, require a minimum height, and group related reads at one committed snapshot.

A view simulates a contract call against committed state without submitting a transaction. It needs a public client and a binding, not a signer.





## Read the existing native-token contract

Use the `src/client.ts` from [Connect to a network](pages/typescript/connect.md). Create `src/read.ts`:

```ts
import { formatUnits, getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
const result = await hog.totalSupply.view({ args: undefined });
console.log("Native-token supply:", formatUnits(result.value, 7));
console.log("Read at block:", result.height.toString());
```

```bash
npx tsx src/read.ts
```

The client supplies the standard ERC-20 binding, and the protocol package supplies the deployed native-token address as `HOG_ADDRESS`. No Rust contract or generated application file is needed for this example.



## Pass arguments and caller context

For an address held by your application:

```ts
import { addressFromHex } from "@thruputchain/client";

export async function readBalance(ownerText: string, signal?: AbortSignal) {
  const owner = addressFromHex(ownerText);
  return hog.getBalanceOf.view({ args: { addr: owner }, signal });
}
```

A view result includes the typed `value`, snapshot `height`, `gasUsed`, and simulated `events`. Independent reads can use different snapshots or lag a recent transaction receipt.

Pass `caller` when the method needs a simulated caller. This changes call context; it does not prove control of that address or authorize a transaction.



## Read after confirmation

Pass a successful receipt’s `height` as `minHeight` when the read must include that committed transaction:

```ts
export async function readBalanceAtLeast(ownerText: string, minHeight: bigint, signal?: AbortSignal) {
  return hog.getBalanceOf.view({
    args: { addr: addressFromHex(ownerText) },
    minHeight,
    signal,
  });
}
```

`minHeight` is an optional nonnegative `bigint` freshness floor, not an exact historical height. The same option works with generated `.view()`, `.viewOutcome()`, bound views, and raw `client.view()`. Omit it for an unconstrained read.

A backend whose selected snapshot is behind returns `ViewHeightUnavailable` (`-32011`) with requested and observed heights. The request does not wait for a block or force a refresh, and the client does not poll or retry it. Keep the confirmed receipt and decide when to retry the read; this error is not a reason to repeat the write.



## Read related values from one snapshot

Prepare calls with `viewRequest()` and send them together through `readViews()`:

```ts
export async function readTokenSnapshot(ownerText: string, minHeight?: bigint, signal?: AbortSignal) {
  const owner = addressFromHex(ownerText);
  const snapshot = await client.readViews({
    calls: [
      ERC20.v0_1.totalSupply.viewRequest({ contract: HOG_ADDRESS }),
      ERC20.v0_1.getBalanceOf.viewRequest({
        contract: HOG_ADDRESS,
        args: { addr: owner },
      }),
    ],
    minHeight,
  }, { signal });

  const [supply, balance] = snapshot.results;
  if (supply.kind === "return" && balance.kind === "return") {
    console.log("Shared snapshot:", snapshot.height.toString());
    console.log("Supply and balance:", supply.value, balance.value);
  } else {
    console.error("Read outcomes:", supply.kind, balance.kind);
  }
  return snapshot;
}
```

`viewRequest()` performs no I/O. `readViews()` returns results in input order, retaining each call’s inferred return and exception types, events, and gas use. Each result is `return`, `abort`, or `fault`. Transport, freshness, and decoding failures reject the group.

All calls use one committed snapshot, and simulated writes stay within their own call. Put `minHeight` on the group, not on individual prepared calls. Two separate reads with the same minimum height can still use different snapshots.

Shared reads require a batch-capable RPC endpoint and runtime. Inspect `(await client.getServerLimits()).viewBatch` for advertised call, gas, calldata, response-size, and timeout limits. The client never splits a group or falls back to separate views. [HTTP batching](pages/typescript/transport.md#http-batching) alone does not provide this guarantee. Raw requests use `client.viewBatch({ calls, minHeight }, { signal })`.



## Handle contract outcomes

`view()` throws `ContractViewError` for an abort or fault. Use `viewOutcome()` when those outcomes belong in your application’s normal control flow:

```ts
const outcome = await hog.totalSupply.viewOutcome({ args: undefined });
if (outcome.kind === "return") {
  console.log(outcome.value);
} else {
  console.error("Contract view failed:", outcome.kind);
}
```

Malformed contract bytes throw `ContractDecodeError`. Transport and RPC failures remain separate from contract outcomes.



## Cancel stale reads

```ts
import { classifyReadError } from "@thruputchain/client";

export async function refreshSupply(signal: AbortSignal) {
  try {
    return await hog.totalSupply.view({ args: undefined, signal });
  } catch (error) {
    if (classifyReadError(error, { signal }) === "cancelled") return;
    throw error;
  }
}
```

Create an `AbortController` for the operation and call `abort()` when its result is no longer needed. RPC actions, including `readViews`, take `{ signal }` as request options; bound views take it inside their options object. Canceling a group ends the client’s wait but does not guarantee that backend execution has stopped.

`classifyReadError` returns `transient`, `permanent`, `cancelled`, or `unknown`. It does not retry or replace the error. Applications choose retry limits; an unclassified `TypeError` is not proof of a network failure.

---

## Read events

Source: <https://thruput.network/typescript/events/>

Filter and decode contract events, walk historical pages, and save progress without missing rows.

Use a generated event descriptor to build filters and decode payloads. This page uses the supplied ERC-20 `TransferEvent`; a custom contract uses the event exported by its generated bindings.



## Query events

With the client from [Connect to a network](pages/typescript/connect.md), create `src/events.ts`:

```ts
import { groundhog_erc20_if } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const { TransferEvent } = groundhog_erc20_if.v0_1.events;
const page = await client.getContractEvents({
  event: TransferEvent,
  contractAddresses: [HOG_ADDRESS],
  order: "descending",
  limit: 20,
});
for (const event of page.events) {
  console.log(event.blockHeight, event.sequenceNumber, event.fields.amount);
}
```

This fetches one typed page. An empty page is a valid result. Each row retains the emitting contract address, transaction hash, position, topics, and decoded fields.



## Filter topics

Add `topics: { to: owner }` to restrict transfers to a typed address. A named topic accepts one value or `{ oneOf: [...] }`. Filters require one to five contract addresses; each topic alternative list accepts 1–16 values.

Addresses, fixed 32-byte values, supported integer scalars, `U256`, `I256`, and bool have direct encodings. Strings and byte slices are hashed. Use the generated filter’s input types; do not reconstruct topic bytes or assume a hashed value can be read back.



## Walk historical pages

For raw event pages, use the descriptor’s filter and decoder:

```ts
const query = {
  filters: [TransferEvent.filter({ contractAddresses: [HOG_ADDRESS] })],
  order: "ascending" as const,
  anchor: "beginning" as const,
  limit: 20,
};
for await (const page of client.iterateEventPages(query)) {
  for (const row of page.events) {
    const decoded = TransferEvent.decode(row.event);
    console.log(row.blockHeight, decoded);
  }
}
```

The iterator requests pages on demand. It follows empty pages with non-empty continuation cursors and stops on an empty `Uint8Array`. Repeated cursors and RPC errors throw. `decode` returns `null` for a different signature and throws for malformed matching data.

Pass `{ signal }` as the iterator’s second argument to cancel an in-flight read. Breaking the loop stops future requests. There is no automatic retry, polling, subscription, or persistence.



## Resume without missing events

A cursor continues one historical walk; it does not follow later blocks. Keep the network, target, and filters fixed. Store rows and progress in the same database transaction, deduplicating by `(txHash, sequenceNumber)` within that network and query.

After exhausting an ascending walk, start a new walk inclusively at the last stored row’s block height. Replay and deduplicate that block so a partially processed block does not lose rows. `latestBlock` is the indexer’s head, not proof that your application processed every row through that height. Check `oldestBlock` for a retention gap.

For a latest-first UI, refresh from the head rather than continuing an old cursor.

For durable ascending ingestion, provide an application-owned store. `loadProgress()` returns `{ height: bigint, cursor: Uint8Array }` or `undefined`; `savePage()` upserts rows by stable identity and saves progress in the same database transaction:

```ts
const saved = await store.loadProgress();
let height = saved?.height ?? 0n;

for await (const page of client.iterateEventPages({
  ...query,
  anchor: { height },
  cursor: saved?.cursor ?? new Uint8Array(),
})) {
  if (page.oldestBlock > height) {
    throw new Error("History gap: required blocks are no longer retained");
  }
  const last = page.events.at(-1);
  if (last) height = last.blockHeight;
  await store.savePage(page.events, { height, cursor: page.cursor.slice() });
}
```

The store methods are application code, not SDK APIs. A non-empty saved cursor resumes the previous walk; an empty cursor starts a new scan at the saved height. Serialize heights and cursor bytes exactly. If a block spans pages, restart inclusively at that block and deduplicate instead of skipping to the next height.

Raw JSON-RPC represents an empty cursor as `"0x"` and still requires `order` and `anchor` on continuation requests. Preserve cursor bytes rather than decoding or editing them. Corrupted cursors can resemble exhaustion on some indexers; retention bounds and a cursor alone do not prove complete or recoverable history.



## Decode receipt events

Use `TransferEvent.allFromReceipt(receipt, { contractAddress: HOG_ADDRESS })` to decode matching events in a receipt. `singleFromReceipt` requires exactly one matching event. Both select the emitter as well as the event type; a transaction can call several contracts that emit the same event.

---

## Accounts and wallet clients

Source: <https://thruput.network/typescript/wallet-clients/>

Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.

A public client connects to the network. An account describes the identity and authorization used for a transaction. A wallet client combines that account with the operations needed to prepare, sign, and submit transactions.

Account authorization and wallet call behavior are separate. Authorization determines which signatures can originate a transaction. An invocation adapter determines how a wallet contract wraps calls to other contracts.



## Choose an account model

|                 | Pubkey account                                        | Source-address account                                               |
| --------------- | ----------------------------------------------------- | -------------------------------------------------------------------- |
| Constructor     | `createPubkeyAccount`                                 | `createSourceAddressAccount`                                         |
| Address         | Derived from an Ed25519 public key and account nonce  | Existing address supplied by the application                         |
| Authorization   | One Ed25519 signer matching the account preimage      | Signer entries and a claim checked against stored authorization data |
| Wallet behavior | DefaultWallet adapter selected automatically          | Application-call wrapping requires an appropriate adapter            |
| Typical use     | A script account without a separate wallet deployment | An existing account contract with configured signer policy           |

Both constructors create local JavaScript objects. They do not fund an address, deploy code, or change authorization data on chain.



## Create a pubkey account

Given an existing `Signer` named `signer`:

```ts
import { createPubkeyAccount } from "@thruputchain/client";

const account = createPubkeyAccount({ signer, nonce: 0n });
```

The same public key and account nonce produce the same address. The nonce defaults to zero and is separate from each transaction’s replay-protection nonce.

An undeployed pubkey account uses the network’s DefaultWallet behavior for its root invocation. No separate wallet deployment is needed. See [Use a signer in scripts](pages/typescript/accounts.md) for key loading and funding.



## Describe a source-address account

For an existing account whose stored policy authorizes your signer at key slot zero with sufficient weight:

```ts
import { createSourceAddressAccount } from "@thruputchain/client";
import { bitMap, weight } from "@thruputchain/protocol";

const account = createSourceAddressAccount({
  address: walletAddress,
  signers: [{ signer, publicKeyId: 0n }],
  allowedKeys: bitMap(0x01n),
  requiredWeight: weight(1n),
});
```

Here, `walletAddress` is the existing account address, not an application contract you want to call. `publicKeyId` identifies a stored signer slot; `allowedKeys` selects slots for the authorization claim. The signatures must satisfy both the stored policy and the claim’s required weight.

The constructor does not register signers or set their weights. Those must already be configured on chain. See [Authorization](pages/how-it-works/authorization.md#source-address-accounts) for the protocol rules.



## Bind an account to a client

With a pubkey `account` and the cluster-aware public client from [Connect to a network](pages/typescript/connect.md):

```ts
import { createWalletClient } from "@thruputchain/client";
import { client } from "./client.js";

const wallet = createWalletClient({ client, account });
```

The wallet is a separate object. It retains public-client operations and adds signing and account operations. Pubkey accounts also receive DefaultWallet execution helpers such as `executeAndWait` and `executeCallsAndWait`. Multiple accounts can share the original public client.

For a source-address account, `createWalletClient` provides transaction preparation and signing, but does not infer how its account contract wraps application calls. Supply an `invocationAdapter` that matches that contract to obtain the execution helpers. Do not select an adapter from the authorization model alone. Custom implementations use `defineWalletInvocationAdapter`; see [Client API reference](pages/tools/typescript-sdk.md#choose-an-account-model).

A cluster-aware client supplies its validated signing network hash. A transport-only client requires an explicit `networkHash` when creating the wallet client.



## Bind a browser wallet provider

In a browser app, the wallet provider manages signing. Use an authorized account returned by its session:

```ts
import { createProviderWalletClient } from "@thruputchain/client/wallet";

const wallet = createProviderWalletClient({
  client,
  provider,
  account: selectedAccount,
  networkHash: expectedNetworkHash,
});
```

`selectedAccount` is the provider’s wire `WalletAccount`, containing its address, public key, and derivation nonce. It is not the signer-backed account object returned by the constructors above. The provider integration supports pubkey accounts and DefaultWallet behavior; it does not expose a raw signer.

`expectedNetworkHash` is the application’s trusted network identity in provider format, without `0x`. The factory does not request connection permission. Follow [Connect a wallet](pages/tools/wallet-integration.md) for discovery, account selection, and session cleanup.

---

## Connect a wallet

Source: <https://thruput.network/tools/wallet-integration/>

Discover browser wallets, connect an account on the intended network, and manage its session.

A browser wallet provider owns account access and transaction approval. Your application receives authorized account information and requests signatures without handling the user’s private key.

For installation and test funds, follow [Wallet Extension](pages/tools/wallet-extension.md).



## Choose the Integration

This page covers the provider-backed path described in [Accounts and wallet clients](pages/typescript/wallet-clients.md). For a Node.js process that manages its own key, use [Use a signer in scripts](pages/typescript/accounts.md). Wallet implementers should use [Wallet provider reference](pages/tools/wallet-provider.md).



## Discover and Connect

Start discovery when the wallet picker mounts and let the user select a provider:

```ts
import { discoverWalletProviders, type WalletProvider } from "@thruputchain/client/provider";

export function mountWalletPicker(showChoice: (provider: WalletProvider) => void) {
  return discoverWalletProviders(showChoice);
}
```

Call the returned cleanup function when the picker unmounts. Discovery supports either load order and reports each provider ID once. Provider IDs and names are display metadata, not proof of identity; render names as text.

Connect from the user’s chosen-wallet action. This helper accepts a public client, the application’s trusted network hash, and an account picker:

```ts
import type { CoreThruputClient } from "@thruputchain/client";
import { parseWalletSession, type WalletAccount, type WalletProvider } from "@thruputchain/client/provider";
import { createProviderWalletClient } from "@thruputchain/client/wallet";

export async function connectWallet(
  client: CoreThruputClient,
  provider: WalletProvider,
  expectedNetworkHash: string,
  chooseAccount: (accounts: readonly WalletAccount[]) => WalletAccount,
) {
  const session = parseWalletSession(await provider.request({ method: "connect" }));
  if (session.networkHash !== expectedNetworkHash) {
    throw new Error("Select the application's network in your wallet");
  }
  if (session.accounts.length === 0) throw new Error("No authorized account");
  const account = chooseAccount(session.accounts);
  if (!session.accounts.includes(account)) throw new Error("Choose an authorized account");

  const wallet = createProviderWalletClient({
    client, provider, account, networkHash: expectedNetworkHash,
  });
  return { wallet, account };
}
```

For a [cluster-aware client](pages/typescript/connect.md), convert its validated network identity with `toHex0x(client.network.networkHash).slice(2)`. Provider network hashes are 64 lowercase hex characters without `0x`. Do not adopt the wallet’s network as the application’s expected network.

`connect` prompts for access; `getSession` reads existing access without prompting. A disconnected session has no accounts but still reports the wallet’s current network. The adapter does not switch networks.



## Handle Changes and Cleanup

Every provider `change` invalidates the current adapter. A failed session read or mismatched session also invalidates it. Stop offering actions through that binding, update the account/network UI, and construct a new adapter for a newly authorized session.

```ts
import type { WalletProvider } from "@thruputchain/client/provider";
import type { ProviderWalletClient } from "@thruputchain/client/wallet";

export function watchWallet(
  provider: WalletProvider,
  wallet: ProviderWalletClient,
  resetAccountUI: () => void,
) {
  const stopChanges = provider.on("change", () => {
    wallet.dispose();
    resetAccountUI();
  });
  return () => {
    stopChanges();
    wallet.dispose();
  };
}
```

Application callbacks should handle their own UI errors. Call cleanup when the binding is no longer needed. `dispose()` invalidates the adapter but does not revoke wallet permission. The user’s Disconnect action calls `provider.request({ method: "disconnect" })`.



## Prepare, Sign, Save, Submit, Observe

For routine writes, use [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet). The provider helpers require `onSigned` to save the approved transaction before broadcast.

For explicit control, the sequence is:

1. `wallet.prepareExecution(request)` builds the unsigned transaction.
2. `wallet.signTransaction(transaction)` requests approval and verifies the returned bytes, signature, and hash. It does not broadcast.
3. Your application saves the signed result, account, and original network.
4. `wallet.submitTransaction(signed)` broadcasts the latest verified approval once.
5. The public client observes the hash and checks execution.

The adapter allows one in-flight operation. A session change invalidates pending work; do not automatically re-sign it. Signature verification requires Web Crypto, available in browsers on HTTPS or localhost.



## Recover an Ambiguous Submission

Once submission begins, an error may arrive after broadcast. Use the saved hash and original network to [track the transaction](pages/typescript/transaction-status.md), including after disconnect or reload. Do not create a replacement merely because observation timed out.

Use `parseWalletProviderError` for provider errors across browser contexts rather than relying on `instanceof`. The [error table](pages/tools/wallet-provider.md#errors) distinguishes rejection, authorization, network, and transport errors.

For a complete counter interface with wallet-approved updates, follow [Counter, part 4: Connect a wallet](pages/tutorials/connect-a-wallet-to-your-app.md).

---

## Use a signer in scripts

Source: <https://thruput.network/typescript/accounts/>

Bind a Node.js signer to a native account, request Futurenet funds, and use local bootstrap accounts.

Use a signer when your Node.js script or service manages an account’s key. This page sets up a pubkey account. See [Accounts and wallet clients](pages/typescript/wallet-clients.md) for account models and client construction, or [Connect a wallet](pages/tools/wallet-integration.md) for a browser application.



## Bind a signer

Supply a 32-byte Ed25519 private-key seed through your process environment as `THRUPUT_PRIVATE_KEY`, using `0x`-prefixed hex. For a disposable Futurenet test account, generate one once in your terminal:

```bash
export THRUPUT_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep that environment for the funding and send commands. Generating another seed selects another account. For a persistent account, load the existing seed from your secret configuration.

Create `src/wallet.ts`:

```ts
import {
  PrivateKeySigner, createPubkeyAccount, createWalletClient, fromHex0x,
} from "@thruputchain/client";
import { client } from "./client.js";

const secret = process.env.THRUPUT_PRIVATE_KEY;
if (!secret) throw new Error("Set THRUPUT_PRIVATE_KEY for this script account");

export const account = createPubkeyAccount({
  signer: new PrivateKeySigner(fromHex0x(secret)),
});
export const wallet = createWalletClient({ client, account });
```

Keep the key in the process’s secret configuration, not browser code or committed files.





## Request Futurenet funds

Create `src/fund.ts`:

```ts
import { toHex0x } from "@thruputchain/client";
import { account, wallet } from "./wallet.js";

const result = await wallet.requestAirdrop();
if (result.status.result !== "ok") {
  throw new Error(`Airdrop execution failed: ${result.status.result}`);
}
console.log("Account:", toHex0x(account.address));
console.log("Funding transaction:", toHex0x(result.txHash));
```

```bash
npx tsx src/fund.ts
```

The client must use a cluster that declares airdrop support. The hosted faucet selects the allocation. `requestAirdrop` polls one attempt with a stable nonce; retain an explicit `clientNonce` if your application must recover the request across process restarts. `requestAirdropAttempt` exposes application-controlled polling.



## Use a local development account

For a node started by [the CLI](pages/cli/local-node.md), create a disposable signer and fund it from the local faucet. In the terminal that runs the script:

```bash
export THRUPUT_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

```ts
import { createThruputClient, createPubkeyAccount, createWalletClient, fromHex0x, localnet, PrivateKeySigner } from "@thruputchain/client";

const seed = process.env.THRUPUT_SIGNING_PRIVATE_KEY;
if (!seed) throw new Error("Set THRUPUT_SIGNING_PRIVATE_KEY");
const client = await createThruputClient({ cluster: localnet() });
const signer = new PrivateKeySigner(fromHex0x(seed));
const account = createPubkeyAccount({ signer });
const wallet = createWalletClient({ client, account });
await wallet.requestAirdrop();
```

`localnet()` selects the local endpoint and checks its network identity. Keep the signer seed in this terminal environment for later calls. Use an existing seed from secret configuration when the account must persist. The SDK does not load CLI account files or runtime manifests.

---

## Send transactions

Source: <https://thruput.network/typescript/transactions/>

Build typed calls, execute them through a wallet, and distinguish submission from successful execution.

A binding builds an application call. A wallet wraps that call into an authorized transaction. Use the wallet’s execution helper instead of submitting a contract method directly as the transaction root.



## Send from a script

Set up and fund the account from [Use a signer in scripts](pages/typescript/accounts.md). For this small-transfer example, choose a recipient that already has native tokens. Create `src/send.ts`:

```ts
import { addressFromHex, gasAmount, parseUnits, toHex0x } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { wallet } from "./wallet.js";

const recipient = process.env.THRUPUT_RECIPIENT;
if (!recipient) throw new Error("Set THRUPUT_RECIPIENT to a funded address");

const transfer = ERC20.v0_1.transfer.call({
  contract: HOG_ADDRESS,
  gasLimit: gasAmount(500_000n),
  args: {
    receiver: addressFromHex(recipient),
    amount: parseUnits("0.0001", 7),
  },
});
const { txHash, receipt, values } = await wallet.executeCallsAndWait({
  calls: [transfer],
  gasLimit: gasAmount(1_000_000n),
});
console.log("Committed:", toHex0x(txHash), receipt.height.toString());
console.log("Return value:", values[0]); // transfer returns void
```

```bash
npx tsx src/send.ts
```

The helper waits for successful committed execution and decodes child returns in call order. A returned receipt and a decoded result are separate guarantees; see [Track transaction results](pages/typescript/transaction-status.md) for failures at either boundary.



## Send through a browser wallet

Use the adapter returned by [Connect a wallet](pages/tools/wallet-integration.md). The same typed call works, but the provider helper also requires an `onSigned` callback:

```ts
import type { ContractAddress } from "@thruputchain/client";
import { gasAmount, parseUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import type { ProviderWalletClient, ProviderExecutionOptions } from "@thruputchain/client/wallet";

export function sendHog(
  wallet: ProviderWalletClient,
  receiver: ContractAddress,
  onSigned: ProviderExecutionOptions["onSigned"],
) {
  const transfer = ERC20.v0_1.transfer.call({
    contract: HOG_ADDRESS,
    gasLimit: gasAmount(500_000n),
    args: { receiver, amount: parseUnits("0.0001", 7) },
  });
  return wallet.executeCallsAndWait({
    calls: [transfer],
    gasLimit: gasAmount(1_000_000n),
  }, { onSigned });
}
```

Call this from the user’s send action. Your `onSigned` implementation must finish saving the signed bytes, hash, account, and network before it resolves. A failed save prevents submission. The SDK does not provide that storage layer.



## Choose an execution helper

| Need                                                                 | Helper                                     |
| -------------------------------------------------------------------- | ------------------------------------------ |
| Submit and require successful execution                              | `executeAndWait({ invocation, gasLimit })` |
| Also decode typed child returns                                      | `executeCallsAndWait({ calls, gasLimit })` |
| Get a submitted hash and observe separately in a signer-based script | `execute({ invocation, gasLimit })`        |
| Inspect the transaction before signing                               | `prepareExecution(...)`                    |

Provider-backed helpers require the additional lifecycle options shown above. Their explicit prepare/sign/submit path is covered in [Wallet integration](pages/tools/wallet-integration.md#prepare-sign-save-submit-observe).



## Execute multiple calls

Pass an ordered list to `executeCallsAndWait` to execute calls atomically. If a call fails, the transaction does not commit earlier calls’ state changes. The returned `values` follow the same order.

For a provider wallet, await `getCapabilities()` and inspect the returned `atomicBatch` before offering a multi-call action. `null` means unsupported; `maxCalls` gives the advertised limit. The adapter checks support during preparation as well. One atomic wallet transaction is different from [HTTP request batching](pages/typescript/transport.md#http-batching).

The SDK requests capabilities only when the provider advertises `getCapabilities`. No advertisement or a `4200` response means unsupported batching. Permission errors, transport failures, malformed responses, and account/network mismatches must remain errors. Refresh capability state after a session change; see [batch capability requirements](pages/tools/wallet-provider.md#optional-atomic-batch-capabilities).

Keep a batch within the wallet’s advertised limit, up to 16 calls. For explicit preparation, `prepareBatchExecution({ invocations, gasLimit })` builds one unsigned transaction; use the same [sign, save, submit, and observe flow](pages/tools/wallet-integration.md#prepare-sign-save-submit-observe) as a single call.

If batching is unsupported, offer a single-call action only when it meets the user’s intended operation. Do not split an operation that requires atomicity. After a batch is rejected or its submission is uncertain, never fall back to individual transactions. Retain its signed evidence and [inspect the original hash](pages/typescript/transaction-status.md).

A batch that enqueues requests commits their acceptance, not their later execution. Track the resulting request IDs and outcomes as described in [Build an AMM](pages/tutorials/build-an-amm.md#understand-acceptance-and-execution).



## Set gas and funding

Each child call has a budget; the root needs enough gas for the wallet wrapper and its child calls. The numbers above are example transfer budgets, not universal defaults. `walletGasLimit(invocations, overhead)` sums invocation budgets and an overhead that you have measured for your workload. For typed calls, pass each call’s `invocation` field.

There are no conventional gas fees, but the declared root limit uses scheduling capacity backed by the sender’s unlocked native tokens. Storage deposits are separate. A new recipient’s first credit must cover its balance storage, so a small first transfer can fail. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).

---

## Track transaction results

Source: <https://thruput.network/typescript/transaction-status/>

Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.

Submission, commitment, execution, and decoding are separate steps. Keep the transaction hash and network so the application can continue observing the same operation after a timeout or wallet disconnect.



## Inspect a submitted transaction

Use the public client from [Connect to a network](pages/typescript/connect.md). Create `src/status.ts`:

```ts
import { ExecResult, hashFromHex } from "@thruputchain/client";
import { client } from "./client.js";

const text = process.env.THRUPUT_TX_HASH;
if (!text) throw new Error("Set THRUPUT_TX_HASH to the submitted transaction hash");
const hash = hashFromHex(text);
const status = await client.getTransactionStatus(hash);

if (status.status === "committed") {
  const receipt = await client.getTransactionReceipt(hash);
  if (!receipt) throw new Error("The committed receipt is not available from this endpoint");
  console.log("Execution succeeded:", receipt.execResult === ExecResult.ExecResultOK);
  console.log("Block:", receipt.height.toString());
} else {
  console.log("Status:", status.status);
}
```

This performs one status check. `waitForTransactionReceipt(hash)` polls for a receipt, but does not itself require successful execution. Check `execResult` or use `waitForExecution(client, hash)` to require success.



## Interpret status

| Status               | Application meaning                                                                             |
| -------------------- | ----------------------------------------------------------------------------------------------- |
| `pending`            | The gateway knows the transaction; keep waiting                                                 |
| `committed`          | Fetch the receipt and check execution; status `height` can be absent until indexing supplies it |
| `invalid`            | Show the reported reason                                                                        |
| `recentFailure`      | Advisory failure of an attempt; the transaction can still commit                                |
| `retry`              | Scheduler processing failed; resubmitting the same signed transaction may succeed               |
| `dropped`            | Scheduler processing failed permanently; modify the transaction before resubmitting             |
| `unknown` or `other` | No conclusive successful or failed execution result                                             |

A timeout or canceled observation does not cancel onchain execution. Query the original hash on the original network rather than automatically signing a replacement.



## Handle scheduler processing errors

`waitForTransactionReceipt()` throws `TransactionProcessingError` on `retry` or `dropped`. It stops polling and never resubmits. Keep the hash, status, and scheduler diagnostics:

```ts
import { TransactionProcessingError } from "@thruputchain/client";

try {
  const receipt = await client.waitForTransactionReceipt(hash);
  console.log("Execution succeeded:", receipt.execResult === ExecResult.ExecResultOK);
} catch (error) {
  if (error instanceof TransactionProcessingError) {
    console.error({ txHash: error.txHash, status: error.status, error: error.error });
  }
  throw error;
}
```

`error.error` is a `SchedulerTransactionError`: `source` is `auth`, `scheduler`, `executor`, or `other`, and `code` is a signed 32-bit number. Interpret the code using that source’s protocol error enum. The client maps unrecognized sources to `other` and preserves the code.



## Handle execution-helper errors

| Error                             | What happened                                                     | What to retain                               |
| --------------------------------- | ----------------------------------------------------------------- | -------------------------------------------- |
| `TransactionExecutionError`       | Committed execution failed                                        | `receipt`                                    |
| `TransactionObservationError`     | Observation failed after submission was attempted                 | `txHash`, `cause`, and any `submissionCause` |
| `ExecutionDecodeError`            | Execution succeeded, but child return decoding failed             | Successful `receipt` and decoding cause      |
| `ExecutionReturnUnavailableError` | Execution succeeded, but the wallet did not provide child returns | Successful `receipt`                         |

For example, classify errors from a wallet execution helper:

```ts
import { TransactionExecutionError, TransactionObservationError, toHex0x } from "@thruputchain/client";

export function describeExecutionError(error: unknown): string {
  if (error instanceof TransactionObservationError) {
    return `Check transaction ${toHex0x(error.txHash)} on its original network`;
  }
  if (error instanceof TransactionExecutionError) {
    return `Committed execution failed: ${error.receipt.execResult}`;
  }
  return error instanceof Error ? error.message : "Transaction operation failed";
}
```

A decoding failure is not a reason to repeat a successful write. Keep the submitted call descriptors if you need to decode the receipt again later.



## Decode the correct method

`decodeReceipt` and `decodeReceiptOutcome` apply to a known **root method**. A wallet-root receipt is not a receipt for the application method it called. Use `executeCallsAndWait` or `decodeExecution(receipt, calls)` for ordered DefaultWallet child returns.

Do not decode a root abort with a child method’s exception schema merely because the transaction contained one child call. The wallet itself may have failed before the child executed.



## Restore application state

After a reload, use the saved hash and network to resume public observation. This does not require the wallet to remain connected. A provider’s `onSigned` callback provides the pre-submission record; see [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet).

For protocol-level outcomes, see [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md).

---

## Deploy a contract

Source: <https://thruput.network/typescript/deployment/>

Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.

Use this task when an application or service deploys a supplied contract artifact. You do not need to write Rust, but you do need the `.rv32a` artifact and the bindings from its build. For ordinary developer deployment, use [the CLI](pages/cli/deploy-and-call.md).



## Prepare the deployment identity

For the generated counter, place its artifact and binding in your project. This Node.js example uses the funded account from [Use a signer in scripts](pages/typescript/accounts.md):

```ts
import { readFile } from "node:fs/promises";
import { gasAmount, parseUnits, prepareContractDeployment, toHex0x } from "@thruputchain/client";
import { Counter } from "./contracts/my-counter.js";
import { account, wallet } from "./wallet.js";

const artifact = await readFile("artifacts/my_counter.rv32a");
const deployment = prepareContractDeployment({
  deployer: account.address,
  contract: artifact,
});
console.log("Predicted address:", toHex0x(deployment.address));
```

Preparation hashes the artifact and predicts its address without signing or submitting. Retain the deployment nonce if you need to reproduce that identity. It differs from the transaction nonce used for replay protection.



## Fund, deploy, and initialize

```ts
const result = await wallet.deployContractAndWait(deployment, {
  gasLimit: gasAmount(10_000_000n),
  amount: parseUnits("10", 7),
  initializer: Counter.v0_1.initialize.invocation(
    deployment.address,
    gasAmount(500_000n),
    { initialValue: 10n },
  ),
});
console.log("Deployed:", toHex0x(result.address));
```

`amount` is explicit native-token funding in base units for the target contract. The example allocation and gas budgets are not universal costs. `0n` skips the funding transfer. The sender still needs scheduling capacity for the root transaction.

Funding, deployment, and the optional initializer form one atomic operation. The initializer targets the predicted address and sees the wallet as its caller. If it fails, the operation rolls back. The helper waits for success and verifies the returned deployment address.



## Deploy through a provider wallet

The provider adapter supports the same deployment plan and options, with an additional `{ onSigned }` lifecycle argument. Use the authorized provider account’s address as `deployer`. See [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet) for persistence before submission.

Inspect the original transaction hash if observation fails rather than generating a new deployment attempt. See [Track transaction results](pages/typescript/transaction-status.md).

---

## Client API reference

Source: <https://thruput.network/tools/typescript-sdk/>

TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.

| Reference                                                      | Purpose                                |
| -------------------------------------------------------------- | -------------------------------------- |
| [Generated client API](https://client-ts.thruput.network/)     | Complete types, overloads, and exports |
| [Generated protocol API](https://protocol-ts.thruput.network/) | Protocol types and codecs              |
| [JSON-RPC API](pages/reference/json-rpc-api.md)                | Wire methods and responses             |
| [TypeScript overview](pages/typescript.md)                     | Application model and task guides      |



## Install

| Package                       | Use                                     | Instructions                                      |
| ----------------------------- | --------------------------------------- | ------------------------------------------------- |
| `@thruputchain/client`        | Application client and contract runtime | [Package setup](pages/typescript/setup.md)        |
| `@thruputchain/protocol`      | Protocol-only constants and wire types  | [Package setup](pages/typescript/setup.md)        |
| `@thruputchain/contract-spec` | Schema tooling                          | [Contract spec](pages/reference/contract-spec.md) |



## Connect to a Cluster

| API                                            | Behavior                                                                                                                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createThruputClient({ cluster, transport? })` | Async client creation with network identity validation                                                                                                                          |
| `devnet(options?)`                             | Hosted development network; unpinned unless given `networkHash`; declares airdrop support                                                                                       |
| `localnet(options?)`                           | Local endpoint and default local identity; override with the matching runtime identity                                                                                          |
| `mainnet(options)`                             | Requires an explicit endpoint                                                                                                                                                   |
| `defineCluster(descriptor)`                    | Custom name, endpoint, hash pin, and expected capabilities                                                                                                                      |
| `getChainTip()` / `getVersion()`               | Current tip and release/wire identity                                                                                                                                           |
| `getChainConfig()`                             | Stated limits plus optional `execution` with `observedTip`, `configHash`, runtime-resolved limits, and exact `bigint` storage prices; absent execution context is not zero cost |
| Usage                                          | [Connect to a network](pages/typescript/connect.md)                                                                                                                             |



## Exact Amounts and Common Types

| API                                          | Result / rule                                                           |
| -------------------------------------------- | ----------------------------------------------------------------------- |
| `parseUnits(text, decimals)`                 | Exact signed `bigint`; rejects malformed input and excess precision     |
| `formatUnits(value, decimals)`               | Decimal string                                                          |
| `addressFromHex(text)` / `hashFromHex(text)` | Typed address or hash from `0x` hex                                     |
| `toHex0x(bytes)`                             | `0x`-prefixed display encoding                                          |
| `gasAmount(bigint)`                          | Typed computation budget                                                |
| `ParseUnitsError`                            | `code: "malformed" \| "precision"`; invalid decimals throw `RangeError` |
| Usage                                        | [Addresses and amounts](pages/typescript/values.md)                     |



## Choose an Account Model



| API                                                                             | Inputs / behavior                                                                                                                                                     |
| ------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createPubkeyAccount({ signer, nonce? })`                                       | Ed25519 signer; address nonce defaults to `0n`                                                                                                                        |
| `createSourceAddressAccount({ address, signers, allowedKeys, requiredWeight })` | Existing stored-auth account; does not write auth data                                                                                                                |
| `createWalletClient({ client, account, invocationAdapter? })`                   | Separate signer-bound client; pubkey accounts default to DefaultWallet                                                                                                |
| `networkHash` wallet option                                                     | Required for a client without validated network identity                                                                                                              |
| `createProviderWalletClient(...)`                                               | External wallet adapter; see [provider API](pages/tools/wallet-provider.md#sdk-adapter-behavior)                                                                      |
| Usage                                                                           | [Accounts and wallet clients](pages/typescript/wallet-clients.md), [script setup](pages/typescript/accounts.md), [browser wallets](pages/tools/wallet-integration.md) |



## Fund and Execute a Call

| API                                                  | Result / behavior                                                                                            |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `requestAirdrop(options?)`                           | Poll one funding attempt; account-defaulted on an airdrop-capable signer wallet                              |
| `requestAirdropAttempt(request)`                     | Single application-controlled funding attempt                                                                |
| `prepareExecution(request)`                          | Unsigned wallet-root transaction                                                                             |
| `execute(request)`                                   | Submitted hash; signer-based wallet                                                                          |
| `executeAndWait(request, options?)`                  | Successful committed receipt and hash                                                                        |
| `executeCallsAndWait({ calls, gasLimit }, options?)` | Successful receipt plus ordered typed child values                                                           |
| `walletGasLimit(invocations, overhead)`              | Sum invocation budgets, checking u64 bounds; pass `call.invocation` for typed calls; does not estimate usage |
| Usage                                                | [Send transactions](pages/typescript/transactions.md)                                                        |



## Typed Calls and Observation Recovery

| API / error                                 | Meaning                                                                                                             |
| ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `getTransactionStatus(hash)`                | One status lookup; committed `height` is optional                                                                   |
| `getTransactionReceipt(hash)`               | One committed-receipt lookup; `null` when unavailable                                                               |
| `waitForTransactionReceipt(hash, options?)` | Wait for a receipt, including failed execution; throws on `retry` or `dropped`, never resubmits                     |
| `waitForExecution(client, hash, options?)`  | Wait and require successful execution                                                                               |
| `TransactionProcessingError`                | Scheduler `retry` or `dropped` outcome; retains `txHash`, `status`, and `error`                                     |
| `SchedulerTransactionError`                 | `source`: `auth`, `scheduler`, `executor`, or `other`; `code`: signed 32-bit number; unknown sources map to `other` |
| `TransactionExecutionError`                 | Failed committed `receipt`                                                                                          |
| `TransactionObservationError`               | Known `txHash` plus observation and optional submission causes                                                      |
| `ExecutionDecodeError`                      | Successful receipt whose child return data failed decoding                                                          |
| `ExecutionReturnUnavailableError`           | Successful receipt without child returns                                                                            |
| Usage                                       | [Track transaction results](pages/typescript/transaction-status.md)                                                 |



## Use a Local Account



| API                               | Result / requirement                                                                       |
| --------------------------------- | ------------------------------------------------------------------------------------------ |
| `localnet(options?)`              | Local endpoint and pinned local network identity                                           |
| `PrivateKeySigner(seed)`          | Explicit signer seed from the application environment                                      |
| `createPubkeyAccount({ signer })` | Native pubkey account derived from the signer                                              |
| `wallet.requestAirdrop()`         | Fund the account through the local faucet                                                  |
| Usage                             | [Local development accounts](pages/typescript/accounts.md#use-a-local-development-account) |



## Deploy Through a Wallet

| API                                                                   | Result / requirement                                                                   |
| --------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `prepareContractDeployment({ deployer, contract, deploymentNonce? })` | Contract hash, nonce, and predicted address; no submission                             |
| `rv32Contract(artifact)`                                              | Protocol wrapper for nonempty artifact bytes                                           |
| `DeploymentOptions`                                                   | Required `gasLimit` and native-token `amount` in base units; optional `initializer`    |
| `prepareDeployment(deployment, options)`                              | Unsigned deployment transaction                                                        |
| `deployContract(deployment, options)`                                 | Submitted hash and predicted address; signer wallet                                    |
| `deployContractAndWait(deployment, options, controls?)`               | Successful deployment with verified address; provider form requires lifecycle controls |
| Usage                                                                 | [Deploy a contract](pages/typescript/deployment.md)                                    |



## Typed Views

| API                                                                                    | Result / behavior                                                                                    |
| -------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `getContract({ binding, address, client })`                                            | Bound method collection                                                                              |
| `method.view(options)`                                                                 | Typed value, height, gas use, and events; supports `minHeight` and `signal`                          |
| `method.viewOutcome(options)`                                                          | `return`, `abort`, or `fault`; also supports `minHeight`                                             |
| `method.viewRequest({ contract, args?, caller? })`                                     | Prepare a typed read without I/O; arguments follow the method’s generated types                      |
| `client.readViews({ calls, minHeight? }, options?)`                                    | Tuple-typed outcomes in input order at one shared `height`; no splitting or separate-read fallback   |
| `client.view(request, options?)` / `client.viewBatch({ calls, minHeight? }, options?)` | Raw single/grouped simulations; `minHeight` goes on the single request or whole group                |
| `minHeight`                                                                            | Optional nonnegative `bigint` freshness floor; no waiting, forced refresh, or automatic client retry |
| `(await client.getServerLimits()).viewBatch`                                           | Optional advertised batch limits                                                                     |
| `ViewHeightUnavailable` (`-32011`)                                                     | RPC freshness error with requested and observed heights; not a contract outcome                      |
| `ContractViewError`                                                                    | Contract abort or fault                                                                              |
| `ContractDecodeError`                                                                  | Malformed contract data                                                                              |
| Usage                                                                                  | [Read contract data](pages/typescript/reads.md), [bindings](pages/tools/typescript-bindings.md)      |



## Cancellation and Read Errors

| API                                    | Rule                                                                       |
| -------------------------------------- | -------------------------------------------------------------------------- |
| `signal`                               | Request options for actions; inside view options for generated/bound views |
| `classifyReadError(error, { signal })` | `transient`, `permanent`, `cancelled`, or `unknown`; no automatic retry    |
| Cancellation                           | Cancels observation, not onchain execution                                 |
| Usage                                  | [Read cancellation](pages/typescript/reads.md#cancel-stale-reads)          |



## HTTP Batching

| Option                                              | Default / meaning                                         |
| --------------------------------------------------- | --------------------------------------------------------- |
| `HttpTransport(url, { timeoutMs, headers, batch })` | Configure the HTTP request layer                          |
| `batch`                                             | Off by default; `true` selects default batching settings  |
| `maxSize`                                           | 100 entries; allowed range 1–1,000                        |
| `waitMs`                                            | 0ms scheduling window                                     |
| Usage                                               | [Configure HTTP transport](pages/typescript/transport.md) |



## Event Pages

| API                                                                            | Result / behavior                                     |
| ------------------------------------------------------------------------------ | ----------------------------------------------------- |
| `getContractEvents({ event, contractAddresses, topics?, ...query }, options?)` | One typed page with event identity and indexer bounds |
| `iterateEventPages(query, options?)`                                           | Raw pages on demand; empty cursor ends the walk       |
| `Event.filter(input)` / `Event.decode(raw)`                                    | Generated topic filter and payload decoder            |
| `Event.allFromReceipt(...)` / `singleFromReceipt(...)`                         | Matching receipt events, filtered by emitter          |
| Usage                                                                          | [Read events](pages/typescript/events.md)             |



## Receipt Decoding

| API                                             | Requirement                                                                                   |
| ----------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `decodeExecution(receipt, calls, adapter?)`     | Successful wallet receipt and retained ordered call descriptors                               |
| `method.decodeReceipt` / `decodeReceiptOutcome` | Descriptor must identify the root method                                                      |
| Usage                                           | [Decode the correct method](pages/typescript/transaction-status.md#decode-the-correct-method) |



## Low-Level Signing

| API                                                  | Role                                                                              |
| ---------------------------------------------------- | --------------------------------------------------------------------------------- |
| `prepareTransaction`                                 | Build a root transaction and its authorization claim                              |
| `signTransaction(transaction, signers, networkHash)` | Sign the network-bound preimage                                                   |
| `sendTransaction(signed)`                            | Submit signed bytes                                                               |
| Transaction hash                                     | SHA-256 of unsigned transaction XDR, separate from the signing preimage           |
| Usage                                                | Prefer [wallet execution](pages/typescript/transactions.md) for application calls |



## Public Entry Points

| Import                             | Use for                                                          |
| ---------------------------------- | ---------------------------------------------------------------- |
| `@thruputchain/client`             | Clients, clusters, accounts, actions, amounts, common primitives |
| `@thruputchain/client/contracts`   | Standard contract and event descriptors                          |
| `@thruputchain/client/contract`    | Descriptor runtime, codecs, fixed-length helpers                 |
| `@thruputchain/client/transport`   | HTTP/mock transports and errors                                  |
| `@thruputchain/client/actions`     | Standalone actions                                               |
| `@thruputchain/client/wallet`      | Execution and provider adapters                                  |
| `@thruputchain/client/provider`    | Provider wire types, validation, discovery                       |
| `@thruputchain/client/transaction` | Construction, signing, serialization                             |
| `@thruputchain/client/signers`     | Signer interface and private-key signer                          |
| `@thruputchain/client/signed-op`   | Network-bound offchain signed operations                         |



## Maintained Examples

| Source                                                                               | Purpose                                                                       |
| ------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| [Client examples](https://github.com/thruputchain/thruput-sdk-ts/tree/main/examples) | Runnable SDK examples; use dependencies matching the selected source revision |
| [Guides](pages/guides.md)                                                            | Complete contract and application walkthroughs                                |

---

## Wallet provider reference

Source: <https://thruput.network/tools/wallet-provider/>

Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.

| Audience                       | Entry point                                                                                                  |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| Application developers         | [Connect a wallet](pages/tools/wallet-integration.md), [Send transactions](pages/typescript/transactions.md) |
| Wallet and bridge implementers | Provider contract `1.0.0`; requirements below apply at the wallet boundary                                   |
| Complete signatures            | [Generated client API](https://client-ts.thruput.network/)                                                   |
| Imports                        | Wire types and validators: `/provider`; application adapter: `/wallet`                                       |



## Interface and Methods

| Type / member                      | Shape                                                                            |
| ---------------------------------- | -------------------------------------------------------------------------------- |
| `WalletAccount`                    | `{ address: string; publicKey: string; nonce: string }`                          |
| `WalletSession`                    | `{ networkHash: string; accounts: readonly WalletAccount[] }`                    |
| `WalletProvider.info`              | `{ id: string; name: string; version: "1.0.0" }`                                 |
| `WalletProvider.supportedMethods?` | Optional readonly method-name list                                               |
| `request(request)`                 | `Promise<unknown>`; validate each result                                         |
| `on("change", listener)`           | Subscribe to a full session snapshot; returns an idempotent unsubscribe function |

| Request method               | Parameters                                    | Result / requirement                                                                                 |
| ---------------------------- | --------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `connect`                    | None                                          | Prompt for origin-scoped access; successful session has at least one account                         |
| `getSession`                 | None                                          | Non-interactive session snapshot; never grants access                                                |
| `disconnect`                 | None                                          | `null`; idempotently revokes origin permission and pending approvals                                 |
| `getCapabilities` (optional) | `{ account, networkHash }`                    | `WalletCapabilities`; requires an authorized account on that network; never prompts or grants access |
| `signTransaction`            | `{ account, networkHash, transaction }`       | `{ signedTransaction, hash }`; approval and signing only                                             |
| `submitTransaction`          | `{ account, networkHash, signedTransaction }` | `{ hash }`; broadcast acknowledgement, not an execution receipt                                      |

| Rule           | Requirement                                                                                             |
| -------------- | ------------------------------------------------------------------------------------------------------- |
| Request shape  | Exactly the method’s defined fields, including nested `params`                                          |
| Selection      | Explicit account and network; no implicit network switch                                                |
| Batch contract | [Optional Atomic Batch Capabilities](pages/tools/wallet-provider.md#optional-atomic-batch-capabilities) |



## Canonical Data and Limits

| Value                       | Required format / bound                                                                                        |
| --------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Address, public key, hash   | 32-byte lowercase `0x`-prefixed hex                                                                            |
| Network hash                | 64 lowercase hex characters without `0x`                                                                       |
| Account nonce               | Canonical decimal u64, at most `18446744073709551615`; address derivation, not transaction replay nonce        |
| Session accounts            | At most 32 unique addresses                                                                                    |
| Provider ID                 | 1–64 ASCII letters, digits, dots, underscores, or hyphens                                                      |
| Provider name               | 1–80 characters; no controls or surrounding whitespace; render as text                                         |
| Provider version            | Exactly `"1.0.0"`                                                                                              |
| Provider `supportedMethods` | Optional array of at most 32 strings; unknown names are opaque, including names with punctuation or namespaces |
| Error message               | At most 1,024 characters                                                                                       |
| Unsigned transaction        | Canonical classic XDR, at most 1,048,500 decoded bytes                                                         |
| Signed transaction          | Canonical classic XDR, at most 1,048,576 decoded bytes                                                         |
| Transaction hex             | Lowercase, even-length, `0x`-prefixed; at most 2,097,002 unsigned or 2,097,154 signed characters               |
| Account derivation          | Protocol pubkey account matching its public key and nonce; Ed25519 key must be non-small-order and prime-order |

| Validation boundary | Requirement                                                                                |
| ------------------- | ------------------------------------------------------------------------------------------ |
| Canonical values    | Reject malformed values rather than normalizing                                            |
| XDR                 | Consume all input; re-encoding must reproduce the supplied bytes                           |
| Before approval     | Enforce unsigned size limit; 76 bytes are reserved for one decorated signature             |
| Bridges             | Bound raw messages before parsing and bound pending requests; allow for JSON envelope size |
| Data parsers        | Return snapshots                                                                           |
| Provider parser     | Preserves the live object’s identity and method receivers; does not establish trust        |



## Permissions and Session Events

| Event / state                                              | Requirement                                                                      |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Unauthorized or disconnected origin                        | Empty accounts, current network hash retained                                    |
| Accounts, permission, account metadata, or network changes | Emit `change` with a full session snapshot                                       |
| Subscription                                               | Does not emit an initial snapshot; call `getSession`                             |
| Connect/disconnect ordering                                | Page-facing changes arrive before the request resolves, including across bridges |
| Pending operation                                          | Recheck authorization before signing or broadcasting                             |
| Session change                                             | Clear approvals; old approval cannot survive a changed session                   |



## Optional Atomic Batch Capabilities

| Item                           | Requirement                                                                                                                                                       |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Advertisement                  | Providers implementing `getCapabilities` must include that exact name in top-level `supportedMethods`, separate from `info` and `WalletSession`                   |
| Unknown advertised method      | Ignore the name; it does not invalidate the provider                                                                                                              |
| Unadvertised capability method | Clients must not probe it; the SDK reports unsupported batching without making that request                                                                       |
| Response shape                 | Exactly `{ account, networkHash, atomicBatch: { maxCalls: number } \| null }`                                                                                     |
| Scope                          | Response account and network must match the request’s canonical account and network; provider verifies current origin/account authorization and network           |
| Side effects                   | Capability queries must not prompt, grant access, sign, or broadcast                                                                                              |
| Unsupported batching           | `atomicBatch: null`, no advertisement, or an advertised capability request returning `4200`                                                                       |
| Other failures                 | Permission and transport errors propagate; malformed responses or mismatched scope are errors, not unsupported capability                                         |
| Call limit                     | `maxCalls` is an integer from 1 to 16; a batch must contain at least one call and stay within the advertised limit                                                |
| Atomicity                      | Ordered, all-or-nothing calls inside one `DefaultWallet.execute` transaction, not multiple independent transactions; an inner abort or fault rolls back the batch |
| Queued work                    | A successful batch that enqueues work does not establish the outcome of later processing                                                                          |
| Session changes                | Discard capability state when the account/network session changes; check support again before batch preparation                                                   |
| Approval                       | Use the existing `signTransaction` and `submitTransaction` requests; one approval covers only that exact batch transaction                                        |
| Persistence and recovery       | Save signed bytes, hash, account, and network before submission; inspect the original hash after uncertainty                                                      |
| Fallback                       | Never split a rejected or uncertain batch into individual transactions                                                                                            |
| Application usage              | [Execute multiple calls](pages/typescript/transactions.md#execute-multiple-calls)                                                                                 |



## Signing and Transaction Identity

| Item          | Requirement                                                                                                |
| ------------- | ---------------------------------------------------------------------------------------------------------- |
| Root identity | Transaction root address and complete pubkey claim match the selected account                              |
| Signed bytes  | Preserve unsigned transaction byte-for-byte                                                                |
| Signature     | Exactly one Ed25519 signature with public-key ID zero                                                      |
| Preimage      | `cxs(DomainSeparator("Transaction")) \|\| networkHash \|\| txs(transaction)`                               |
| Verification  | Strict Ed25519 with ZIP-215 disabled; public key and signature point R are non-small-order and prime-order |
| Signing       | Sign the preimage directly, without an extra pre-hash                                                      |
| Result hash   | `0x` plus lowercase SHA-256 of unsigned transaction XDR; excludes signatures and network                   |
| Web Crypto    | Required by SDK signature verification; HTTPS or localhost in browsers                                     |



## Approval and Submission

| Boundary                    | Requirement                                                                                                      |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Trusted caller              | Derive origin in trusted wallet/bridge code, not page-supplied parameters                                        |
| Retained approval           | Bind exact signed bytes to origin, account, and network                                                          |
| Submission                  | Reject bytes outside the retained approval; return the approved canonical hash                                   |
| Approval lifecycle          | Clear on disconnect/session change; bound retained approvals; fail closed after eviction, restart, or lost state |
| Application persistence     | Save signed result, hash, account, and original network before broadcast                                         |
| Uncertain submission        | Observe the saved hash on the original network; do not automatically sign a replacement                          |
| Identical-byte resubmission | Requires an explicit recovery policy and still-valid provider approval                                           |
| Usage                       | [Transaction observation](pages/typescript/transaction-status.md)                                                |



## Errors

| Code     | Meaning                                                         |
| -------- | --------------------------------------------------------------- |
| `4001`   | User rejected the request                                       |
| `4100`   | Unauthorized origin/account, stale session, or missing approval |
| `4200`   | Unsupported method                                              |
| `4900`   | Provider disconnected or transport unavailable                  |
| `4901`   | Requested network does not match                                |
| `-32602` | Invalid parameters, encoding, or limits                         |
| `-32603` | Internal error or invalid provider result                       |
| `-32002` | Another operation is pending                                    |

| Rule                    | Requirement                                                                         |
| ----------------------- | ----------------------------------------------------------------------------------- |
| Across contexts         | Preserve numeric code and message; use `parseWalletProviderError`, not `instanceof` |
| Unknown method          | Return `4200`                                                                       |
| Malformed known request | Return `-32602`                                                                     |



## Multiple-Provider Discovery

| API / rule                                           | Behavior                                                                |
| ---------------------------------------------------- | ----------------------------------------------------------------------- |
| `registerWalletProvider(provider, target = window)`  | Validate, announce immediately, and respond to provider requests        |
| `discoverWalletProviders(listener, target = window)` | Subscribe before requesting announcements; validate and deduplicate IDs |
| Request event                                        | `groundhog:requestProvider`                                             |
| Announcement event                                   | `groundhog:announceProvider`; `detail` is the provider itself           |
| Discovery limits                                     | At most 32 IDs; first valid announcement for an ID wins                 |
| Cleanup                                              | Idempotent; removes listeners, but does not disconnect sessions         |
| Registration removal                                 | Does not retract an already discovered provider                         |
| Outside browsers                                     | Imports are safe; supply an `EventTarget` to discovery helpers          |
| Trust                                                | Shape validation is not wallet identity or origin authorization         |



## Validation Helpers

| Helper                                                                  | Validates / returns                                                                                                       |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `parseWalletAccount`, `parseWalletSession`, `parseWalletProviderInfo`   | Canonical data and frozen snapshots; separately require nonempty accounts after connect                                   |
| `parseWalletProvider`                                                   | Metadata and callable methods on the live object                                                                          |
| `parseWalletHex32`, `parseWalletNetworkHash`                            | Distinct hex encodings                                                                                                    |
| `parseWalletCapabilities`                                               | Exact scoped response shape and DefaultWallet call-count bounds; authorization and expected-scope comparison are separate |
| `parseProviderRequest`                                                  | Exact request union and bounded XDR                                                                                       |
| `parseTransactionHex`, `parseSignedTransactionHex`                      | Canonical decoded objects, without signature verification                                                                 |
| `parseSignTransactionResult`, `parseSubmitTransactionResult`            | Result shape; not signature, approval, or broadcast verification                                                          |
| `assertWalletTransaction(tx, account)`                                  | Root address and complete pubkey claim; mismatch is `4100`                                                                |
| `verifySignTransactionResult(value, transaction, account, networkHash)` | Exact bytes, account claim, strict signature, and hash; invalid result is `-32603`                                        |
| `parseWalletProviderError`                                              | Recognized code and bounded message                                                                                       |

| Constant                         | Value       |
| -------------------------------- | ----------- |
| `MAX_TRANSACTION_BYTES`          | `1_048_576` |
| `MAX_UNSIGNED_TRANSACTION_BYTES` | `1_048_500` |
| `MAX_WALLET_ACCOUNTS`            | `32`        |
| `MAX_DISCOVERED_PROVIDERS`       | `32`        |
| `MAX_DEFAULT_WALLET_CALLS`       | `16`        |



## SDK Adapter Behavior

| API                                                                                   | Result / behavior                                                                                                                             |
| ------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `createProviderWalletClient({ client, provider, account, networkHash })`              | Synchronous separate binding for an authorized wire account; does not connect or mutate client                                                |
| `getCapabilities()`                                                                   | Fresh account/network capabilities when advertised; absence or `4200` means unsupported batching                                              |
| `prepareExecution(request)`                                                           | Unsigned DefaultWallet transaction with nonce, expiry, and size handling                                                                      |
| `prepareBatchExecution(request)`                                                      | Unsigned DefaultWallet transaction containing ordered `invocations`; snapshots inputs before async work and validates fresh capability limits |
| `signTransaction(transaction)`                                                        | Verified approval; never broadcasts                                                                                                           |
| `submitTransaction(signed)`                                                           | Consumes latest approval once, including on failure; verifies response hash                                                                   |
| `executeAndWait(request, controls)`                                                   | Prepare, sign, save through `onSigned`, submit, and observe successful execution                                                              |
| `executeCallsAndWait(request, controls)`                                              | Atomic typed calls and ordered decoded results                                                                                                |
| `prepareDeployment(plan, options)` / `deployContractAndWait(plan, options, controls)` | Explicit funding and optional atomic initialization                                                                                           |
| `dispose()`                                                                           | Idempotently unsubscribe and permanently invalidate; does not revoke permission                                                               |

| Lifecycle rule     | Behavior                                                                                                              |
| ------------------ | --------------------------------------------------------------------------------------------------------------------- |
| Inputs             | Snapshot configuration and inputs before async work; validate account derivation and client network identity          |
| Session            | Check before preparation/signing/submission; every change or failed/mismatched session read invalidates the adapter   |
| Concurrency        | One in-flight operation; overlapping work fails with `-32002`                                                         |
| New approval       | Clears the previous approval after local transaction validation; refusal does not restore it                          |
| Execution controls | Required `onSigned` persistence callback; optional `wait` settings and cancellation signal                            |
| Cleanup            | No automatic reconnect/retry, UI deadline, or provider-request cancellation; late results cannot reactivate or submit |
| Usage              | [Connect a wallet](pages/tools/wallet-integration.md), [Send transactions](pages/typescript/transactions.md)          |



## Design References

| Reference                                                                                                                                                                       | Relationship                                                                                                                                                  |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [EIP-1193](https://eips.ethereum.org/EIPS/eip-1193), [EIP-6963](https://eips.ethereum.org/EIPS/eip-6963), [Wallet Standard](https://github.com/wallet-standard/wallet-standard) | Design influences, not compatibility claims                                                                                                                   |
| Scope                                                                                                                                                                           | No arbitrary-message signing, implicit network addition, WalletConnect, hardware-wallet protocol, or source-address account support in this provider contract |

---

## React

Source: <https://thruput.network/react/>

Use Stellar Thruput's React provider and hooks for wallets and contract data.

Build wallet controls and contract-data interfaces with `@thruputchain/react`. The library supplies state and hooks; you supply the components, styling, and application workflow.



## How the layers fit

- The **TypeScript client** connects to a network and executes typed contract operations.
- **WalletProvider** shares that client and manages wallet discovery, connection, and account selection.
- **TanStack Query** manages read state, caching, and mutations through your application’s `QueryClient`.
- **Contract bindings** describe each contract’s methods, results, errors, and events.

The library manages one configured application network and one selected wallet connection. Public reads work without wallet permission. A connected wallet supplies the signing client for writes.



## Start with a read

The [React quickstart](pages/get-started/react.md) displays Futurenet’s native-token supply using the supplied ERC-20 binding and contract address. You do not need Rust, the CLI, or your own deployment.

For an existing app, follow [Setup](pages/react/setup.md) and [Providers and clients](pages/react/providers.md). Then use [Read contract data](pages/react/reads.md) or [Read balances](pages/react/balances.md). [Cache and refresh data](pages/react/queries.md) explains the query behavior shared by those hooks.



## Add wallet actions

[Connect a wallet](pages/react/wallets.md) covers discovery, account selection, and connection states. [Send transactions](pages/react/transactions.md) and [Track transaction results](pages/react/transaction-status.md) cover the approval-to-receipt flow.

Use the [TypeScript account model](pages/typescript/wallet-clients.md) for shared signing concepts and the [React API reference](pages/react/reference.md) for exact hook inputs and results. Complete application walkthroughs belong in [Guides](pages/guides.md).

---

## Setup

Source: <https://thruput.network/react/setup/>

Install the React integration and connect its wallet and query providers to Futurenet.

Use the current Node.js LTS release. For a new app, create a React TypeScript project:

```bash
npm create vite@latest my-thruput-ui -- --template react-ts
cd my-thruput-ui
npm install
```

Complete the shared [registry access setup](pages/typescript/setup.md#give-npm-package-access), then install the integration and its client together:

```bash
npm install @thruputchain/react @thruputchain/client @thruputchain/protocol @tanstack/react-query
```

The package manager resolves the React library’s compatible client dependency. Keep the lockfile. In an existing application, satisfy the library’s peer dependencies rather than forcing an incompatible client version. The integration uses React 19 and TanStack Query 5.



## Connect the application

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, devnet } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Futurenet…</p>);

async function start() {
  const client = await createThruputClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

void start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Futurenet"}</p>,
  );
});
```

The public client and query cache are created once, before rendering the app. `WalletProvider` does not request wallet permission automatically.



## Check the setup

Start the development server:

```bash
npm run dev
```

In another terminal, check the production build:

```bash
npm run build
```

---

## Providers and clients

Source: <https://thruput.network/react/providers/>

Understand the React contexts, public and signing clients, and their lifetimes.

The [setup page](pages/react/setup.md) mounts two contexts. They have different responsibilities:

| Provider              | Responsibility                                                                                  |
| --------------------- | ----------------------------------------------------------------------------------------------- |
| `WalletProvider`      | Public client, wallet discovery, authorized session, selected account, signing-client lifecycle |
| `QueryClientProvider` | Read cache, query state, refresh policies, and mutations                                        |

`WalletProvider`, `useClient`, `useWallet`, and `useWalletClient` work without TanStack Query context. Balance, contract-view, receipt, and execution hooks require both providers.

The React `WalletProvider` is a context component. A discovered wallet provider is the external wallet object that handles permission and signing requests. See [Accounts and wallet clients](pages/typescript/wallet-clients.md) for that shared model.



## Use the public client

`useClient()` returns the initialized client supplied to `WalletProvider`. It remains available while disconnected and stays on the application’s network when the wallet changes networks.

Use it with SDK actions or [custom queries](pages/react/events.md). Contract reads do not require a connected wallet.

Choose a cluster or pin its identity through the TypeScript [network configuration](pages/typescript/connect.md), then supply that cluster-validated client to `WalletProvider`.

Configure HTTP timeouts and batching through the [client transport](pages/typescript/transport.md). Configure caching and refresh behavior through [TanStack Query](pages/react/queries.md).



## Use the signing client

`useWalletClient()` returns the current provider-backed signing client, or `null` when unavailable. `useWallet()` exposes the connection state and selection actions.

Enable writes only when `wallet.status === "connected"`. An account address can still be present in a wrong-network session, so an address alone is not evidence that signing is available.

The provider owns the signing client’s lifecycle. Session changes invalidate the old binding immediately and create a fresh binding after event dispatch when the session is valid. Use the current hook result for new operations.



## Keep identities stable

Create the public client and `QueryClient` once for the application’s lifetime. Replacing the public client starts a disconnected wallet lifecycle, even when the new client points to the same network. Reads through different client instances have separate cache identities.

Unmounting `WalletProvider` disposes its signing binding without revoking remote permission. The user’s [Disconnect action](pages/react/wallets.md) requests permission revocation. Calling the current signing client’s `dispose()` also clears the local React connection.



## Use a client-rendered boundary

In a server-rendered framework, initialize the client and mount these providers in the application’s client-rendered boundary. Server rendering starts disconnected; browser discovery runs after mounting.

Stellar Thruput query keys contain in-memory client identities. Use them within one query-cache lifetime, not as persisted keys or server-to-browser hydration identifiers. See [Cache and refresh data](pages/react/queries.md) for cache scope and reusable query factories.

---

## Read contract data

Source: <https://thruput.network/react/reads/>

Display a typed contract view with loading, error, data, and refresh states.

`useContractView` reads a generated method descriptor and infers its arguments and result. Mount the [application providers](pages/react/setup.md) first.





## Display native-token supply

Use this as `src/App.tsx`. The binding and deployed address are supplied by the SDK packages:

```tsx
import { formatUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    contract: HOG_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>Native-token supply</h1>
      {supply.isLoading ? <p>Reading the contract…</p> : null}
      {supply.error ? <p role="alert">{supply.error.message}</p> : null}
      {supply.data ? (
        <>
          <p>{formatUnits(supply.data.value, 7)} native tokens</p>
          <p>Read at block {supply.data.height.toString()}</p>
        </>
      ) : null}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

No wallet, signer, or new deployment is needed. The result retains `value`, `height`, and simulated `events`.



## Pass method arguments

For a method with arguments, pass its generated argument object:

```tsx
import type { ContractAddress } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export function RawBalance({ owner }: { owner: ContractAddress }) {
  const balance = useContractView({
    method: ERC20.v0_1.getBalanceOf,
    contract: HOG_ADDRESS,
    args: { addr: owner },
  });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Reading balance…</p>;
  return <p>{balance.data.value.toString()} base units</p>;
}
```

Pass `caller` when a view needs simulated caller context. It does not authorize a transaction. Custom contracts use their own [generated bindings](pages/tools/typescript-bindings.md).



## Control when a read runs

`enabled: false` disables automatic reads and retains cached data. `staleTime` controls freshness. Arguments must still be valid: the hook encodes them while constructing the query, even when disabled. Mount a read component only after required inputs are ready.

Keep generated descriptors stable. Cache identity includes the client, method decoder, contract, encoded arguments, and caller. Equivalent argument values share a query; changing an input selects a different query.



## Handle refresh and cancellation

Use `isLoading` for the first active fetch and `isFetching` for any active fetch, including refresh. A disabled query can be pending without loading. Display read errors separately from cached data when a refresh fails.

Query cancellation aborts contract-view requests and ignores late results from custom transports. Independent views can use different snapshots. After a write, check that a view has reached the receipt’s height before treating its data as post-transaction state.

---

## Read balances

Source: <https://thruput.network/react/balances/>

Read native-token and contract-token balances for a connected account or an explicit address.

Use `useBalance` for the native token and `useTokenBalance` for a standard ERC-20 contract. Both return query state, a `queryKey`, and data containing `rawBalance` and `height`.



## Follow the connected account

```tsx
import { formatUnits } from "@thruputchain/client";
import { useBalance } from "@thruputchain/react";

export function NativeBalance() {
  const balance = useBalance();
  if (balance.isLoading) return <p>Loading balance…</p>;
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Connect a wallet on this network to see its balance.</p>;
  return <p>{formatUnits(balance.data.rawBalance, 7)} native tokens</p>;
}
```

With no address, the hook follows the selected account only while the wallet is connected to the application’s network. Account changes select a different query rather than displaying the previous account’s balance.



## Read an explicit address

Pass an address to read without wallet permission:

```tsx
import { formatUnits } from "@thruputchain/client";
import { useTokenBalance, type BalanceAddress } from "@thruputchain/react";

export function TokenBalance({ token, owner, decimals }: {
  token: BalanceAddress;
  owner: BalanceAddress;
  decimals: number;
}) {
  const balance = useTokenBalance({ token, address: owner });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Loading token balance…</p>;
  return (
    <p>{formatUnits(balance.data.rawBalance, decimals)} at block {balance.data.height.toString()}</p>
  );
}
```

Addresses accept hex strings or SDK-branded bytes. Equivalent inputs share a key. The hook does not fetch token metadata or choose decimals; supply those from the application or a metadata read. The native token has seven decimals.



## Handle missing inputs

| Input                          | Behavior                                                               |
| ------------------------------ | ---------------------------------------------------------------------- |
| Omitted or undefined `address` | Resolve the connected account on the app’s network                     |
| Explicit address               | Read even while disconnected or while the wallet is on another network |
| `address: null`                | Disable account resolution and fetching                                |
| Missing or null `token`        | Disable token fetching                                                 |

Missing-input queries are idle with `isLoading: false`. Invalid addresses surface through query error state.



## Set refresh behavior

Pass options through `query`, for example `{ staleTime: 10_000, refetchInterval: 15_000 }`. The balance hooks also support retry, garbage-collection, focus/reconnect, and `select` options. Defaults come from your QueryClient and TanStack Query.

Abandoned balance results are discarded, but their underlying RPC may still finish. Use [Cache and refresh data](pages/react/queries.md) for polling, reusable query options, and invalidation after writes.

---

## Cache and refresh data

Source: <https://thruput.network/react/queries/>

Share query results, reuse query factories, and refresh the original data after a transaction.

Stellar Thruput query hooks use your application’s TanStack Query cache. Keep the public client and QueryClient stable so components reading the same inputs can share data and in-flight requests.



## Understand cache scope

Keys include network and public-client instance identity. Balance keys also include owner and token where applicable. Contract-view keys include the method decoder, target, encoded arguments, and caller.

Different client instances do not share cached reads, even on the same network. Use the `queryKey` returned by a hook or factory rather than constructing a library-owned key yourself.

`staleTime` controls when data becomes stale. Polling and post-transaction invalidation are explicit application choices. Independent queries do not guarantee a common read height.



## Reuse query options

Factories work outside components when given an initialized client and explicit inputs:

```ts
import type { ConnectedThruputClient } from "@thruputchain/client";
import { tokenBalanceQueryOptions, type BalanceAddress } from "@thruputchain/react";
import type { QueryClient } from "@tanstack/react-query";

export function prefetchBalance(
  queries: QueryClient,
  client: ConnectedThruputClient,
  owner: BalanceAddress,
  token: BalanceAddress,
) {
  return queries.prefetchQuery(tokenBalanceQueryOptions({
    client,
    address: owner,
    token,
    query: { staleTime: 10_000 },
  }));
}
```

The same client and inputs produce the key used by `useTokenBalance`. Factories also exist for native balances, contract views, and receipts.

Balance factories do not resolve the connected wallet. Missing inputs produce a skipped query for hook use; call imperative `fetchQuery` or `prefetchQuery` only when inputs are present. `enabled` controls observers, not imperative fetching. `select` transforms observer data, not the cache’s raw data.



## Read a dynamic list

Use one balance component per token, or compose factory options with `useQueries`:

```tsx
import { toHex0x } from "@thruputchain/client";
import { useQueries } from "@tanstack/react-query";
import { tokenBalanceQueryOptions, useClient, useWallet, type BalanceAddress } from "@thruputchain/react";

export function TokenBalances({ tokens }: { tokens: BalanceAddress[] }) {
  const client = useClient();
  const wallet = useWallet();
  const tokenKeys = tokens.map(token => typeof token === "string" ? token.toLowerCase() : toHex0x(token));
  const balances = useQueries({
    queries: tokenKeys.map(token => tokenBalanceQueryOptions({
      client,
      address: wallet.status === "connected" ? wallet.address : null,
      token,
      query: { staleTime: 10_000 },
    })),
  });

  return (
    <ul>
      {balances.map((balance, index) => (
        <li key={tokenKeys[index]}>
          {balance.isLoading ? "Loading…" : balance.error ? balance.error.message : balance.data?.rawBalance.toString() ?? "No balance loaded"}
        </li>
      ))}
    </ul>
  );
}
```

Pass a list of unique tokens. These are independent queries, not one atomic read or a concurrency-limited batch. Use a grouped application query and check heights when several values must describe the same snapshot.



## Refresh after a write

After observing a committed transaction, invalidate the key for the account and token that operation affected:

```ts
import type { QueryClient } from "@tanstack/react-query";
import type { BalanceQueryKey } from "@thruputchain/react";

export function refreshBalance(queries: QueryClient, originalKey: BalanceQueryKey) {
  return queries.invalidateQueries({ queryKey: originalKey, exact: true });
}
```

Capture the original key when starting the operation. An account change while waiting should not redirect the refresh to the newly selected account. Invalidating a query requests another read; check its height when the application needs post-transaction state.

For custom queries, append an application namespace and every read input to `getClientQueryKey(client)`. Canonicalize byte arrays and bigints into stable strings. [Read events](pages/react/events.md) shows a custom query with fixed inputs.



## Keep persistence separate

Query keys contain in-memory identities and are not portable across server/browser processes or persisted cache sessions. Store application records, such as pending transaction hashes and their networks, separately from the query cache. See [Track transaction results](pages/react/transaction-status.md).

---

## Read events

Source: <https://thruput.network/react/events/>

Use the public client and TanStack Query to display typed contract events in React.

Compose the TypeScript client’s event actions with TanStack Query. Generated bindings provide filtering and decoding; React components provide loading, empty, error, and refresh states.





## Display recent native-token transfers

```tsx
import { toHex0x } from "@thruputchain/client";
import { groundhog_erc20_if } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { getClientQueryKey, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";

const { TransferEvent } = groundhog_erc20_if.v0_1.events;

export function RecentTransfers() {
  const client = useClient();
  const transfers = useQuery({
    queryKey: [...getClientQueryKey(client), "app", "recent-hog-transfers"],
    queryFn: ({ signal }) => client.getContractEvents({
      event: TransferEvent,
      contractAddresses: [HOG_ADDRESS],
      order: "descending",
      limit: 20,
    }, { signal }),
    staleTime: 10_000,
  });

  return (
    <section aria-label="Recent native-token transfers">
      {transfers.isLoading ? <p>Loading transfers…</p> : null}
      {transfers.error ? <p role="alert">{transfers.error.message}</p> : null}
      {transfers.data?.events.length === 0 ? <p>No transfers in this page.</p> : null}
      <ul>
        {transfers.data?.events.map(event => (
          <li key={`${toHex0x(event.txHash)}:${event.sequenceNumber}`}>
            {event.fields.amount.toString()} base units at block {event.blockHeight.toString()}
          </li>
        ))}
      </ul>
      <button disabled={transfers.isFetching} onClick={() => void transfers.refetch()}>
        Refresh transfers
      </button>
    </section>
  );
}
```

The query has fixed contract, event, ordering, and page-size inputs. If you make them configurable, include each input in the key. Include a cursor when caching separate historical pages.



## Choose a history workflow

Refreshing the example starts at the head again. A saved cursor continues an older historical walk; it is not a subscription. Use the TypeScript [event pagination guidance](pages/typescript/events.md) for iteration and durable checkpoints.

For live refresh, choose an explicit polling policy. Query caching does not create a background indexer or save progress across reloads.



## Decode transaction events

A receipt returned by an execution or receipt hook contains events. Use a generated descriptor’s `allFromReceipt` or `singleFromReceipt` with the emitting contract address.

A committed receipt can report failed execution. Check the result before treating its events as successful application activity. See [Track transaction results](pages/react/transaction-status.md).

---

## Connect a wallet

Source: <https://thruput.network/react/wallets/>

Build wallet and account selectors with explicit connection, network, and error states.

`useWallet` exposes discovered wallets, the selected account, and connection actions. `WalletProvider` manages discovery and session listeners; your components render the controls.

To install and fund a wallet for testing, follow [Wallet Extension](pages/tools/wallet-extension.md).



## Select and connect a wallet

```tsx
import { useWallet } from "@thruputchain/react";

export function WalletControls() {
  const wallet = useWallet();
  const busy = wallet.status === "connecting" || wallet.status === "disconnecting";
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";

  return (
    <section aria-label="Wallet connection">
      <select
        aria-label="Wallet"
        value={wallet.provider?.info.id ?? ""}
        disabled={busy || wallet.providers.length === 0}
        onChange={event => wallet.selectProvider(event.target.value)}
      >
        <option value="" disabled>Choose a wallet</option>
        {wallet.providers.map(provider => (
          <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>
        ))}
      </select>
      {wallet.providers.length === 0 ? <p>No wallet provider detected.</p> : null}
      {authorized ? (
        <button disabled={busy} onClick={() => void wallet.disconnect()}>Disconnect</button>
      ) : (
        <button disabled={busy || !wallet.provider} onClick={() => void wallet.connect()}>
          {wallet.status === "connecting" ? "Connecting…" : "Connect wallet"}
        </button>
      )}
      {wallet.status === "wrongNetwork" ? <p>Switch your wallet to the application's network.</p> : null}
      {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
    </section>
  );
}
```

Discovery selects the first provider without prompting. The user grants access through `connect()`. Provider names and IDs are display metadata, not proof of identity. The library supplies no branded buttons or wallet installation links.



## Select an authorized account

```tsx
import { useWallet } from "@thruputchain/react";

export function AccountSelector() {
  const wallet = useWallet();
  if (!wallet.session?.accounts.length) return null;

  return (
    <select
      aria-label="Account"
      value={wallet.address ?? ""}
      onChange={event => wallet.selectAccount(event.target.value)}
    >
      {wallet.session.accounts.map(account => (
        <option key={account.address} value={account.address}>{account.address}</option>
      ))}
    </select>
  );
}
```

Selection does not prompt. An unauthorized address or unknown provider sets `error` while preserving the current binding. Selecting another provider clears the local binding without revoking the previous provider’s permission.



## Interpret connection state

| State           | UI behavior                                                 |
| --------------- | ----------------------------------------------------------- |
| `disconnected`  | Offer connection when a provider is available               |
| `connecting`    | Show progress and prevent duplicate connection requests     |
| `connected`     | Enable supported signing actions                            |
| `disconnecting` | Local authorization is already cleared; wait for revocation |
| `wrongNetwork`  | Ask the user to switch networks; keep signing disabled      |

`connect()` and `disconnect()` resolve after handling the request. Read failures from `wallet.error`; those actions do not throw provider request failures. Signing and submission operations do reject on failure.



## Handle changes and cleanup

Session changes invalidate old signing bindings immediately. The provider binds a fresh client after event dispatch when possible, retaining the selected account if still authorized. Do not retain an old signing client for future operations.

Disconnect clears local authorization immediately. If remote revocation fails, the UI remains disconnected and exposes an error. Unmounting disposes the local binding without requesting revocation. Connection is explicit; there is no automatic reconnect or persisted connection.

Use the shared [wallet-provider error codes](pages/tools/wallet-provider.md#errors) for application-specific messages. Do not infer transaction failure from a disconnected wallet; [receipt observation](pages/react/transaction-status.md) uses the public client.

---

## Send transactions

Source: <https://thruput.network/react/transactions/>

Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.

`useExecute` runs a wallet-backed transaction from a user action. It prepares, signs, awaits your persistence callback, submits once, and waits for successful execution. Both [providers](pages/react/providers.md) are required.



## Execute a typed call

This component sends a small native-token transfer to an already funded recipient. The application supplies `savePending`, which must durably save the approved transaction before resolving:

```tsx
import { gasAmount, parseUnits, toHex0x, TransactionObservationError, type ContractAddress } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { useExecute, useWallet, type ExecuteVariables } from "@thruputchain/react";

type SavePending = ExecuteVariables["options"]["onSigned"];

export function SendHog({ receiver, savePending }: {
  receiver: ContractAddress;
  savePending: SavePending;
}) {
  const wallet = useWallet();
  const execution = useExecute();
  const unresolved = execution.error instanceof TransactionObservationError;

  function send() {
    execution.mutate({
      request: {
        invocation: ERC20.v0_1.transfer.invocation(HOG_ADDRESS, gasAmount(500_000n), {
          receiver,
          amount: parseUnits("0.0001", 7),
        }),
        gasLimit: gasAmount(1_000_000n),
      },
      options: { onSigned: savePending, wait: { timeoutMs: 60_000 } },
    });
  }

  return (
    <section aria-label="Send native tokens">
      <button disabled={wallet.status !== "connected" || execution.isPending || unresolved} onClick={send}>
        {execution.isPending ? "Waiting for approval or confirmation…" : "Send native tokens"}
      </button>
      {execution.error ? <p role="alert">{execution.error.message}</p> : null}
      {unresolved ? <p>Check the saved transaction before starting another transfer.</p> : null}
      {execution.data ? <p>Committed: {toHex0x(execution.data.txHash)}</p> : null}
    </section>
  );
}
```

`mutate` exposes failures through mutation state. Use `mutateAsync` when an event handler needs to await the result, and handle its rejected promise. Trigger writes from user actions, not render effects.

The example budgets apply to this transfer, not every contract. See [gas and funding](pages/typescript/transactions.md#set-gas-and-funding) for root and child limits and first-address storage funding.



## Save before submission

`onSigned` receives signed bytes, the canonical hash, account, and original network. Await the application’s durable write. A rejected callback prevents broadcast.

The query cache is not the pending-transaction store. Keep the saved record available after a reload, account change, or disconnect. Use it to [observe the original transaction](pages/react/transaction-status.md) rather than automatically signing a replacement.



## Handle mutation state

| State       | Meaning                                                                               |
| ----------- | ------------------------------------------------------------------------------------- |
| `isPending` | Preparation, approval, persistence, submission, or receipt observation is in progress |
| `data`      | Successful committed execution with `txHash` and `receipt`                            |
| `error`     | Inspect the error boundary; an observation failure is not proof of failed execution   |

Mutation retries are disabled, including when the QueryClient’s defaults enable retries. A wallet change invalidates the captured signing binding; observation after broadcast can continue on the original network.

`reset()` clears mutation UI state. It does not cancel a transaction or resolve an unknown outcome. See the shared [execution error model](pages/typescript/transaction-status.md#handle-execution-helper-errors).



## Decode returns and refresh reads

For typed child returns, use the current `useWalletClient()` binding’s `executeCallsAndWait` with the required persistence options. Keep its promise and UI state in the application’s write handler; `useExecute` returns the root execution result.

After commitment, explicitly [invalidate affected queries](pages/react/queries.md#refresh-after-a-write). Capture their original account/token keys before starting the operation so a later account selection does not change the refresh target.

---

## Track transaction results

Source: <https://thruput.network/react/transaction-status/>

Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.

`useWaitForTransactionReceipt` observes a hash through the public client. It works while the wallet is disconnected. Use a client on the transaction’s original network.



## Display a receipt

```tsx
import { ExecResult } from "@thruputchain/client";
import { useWaitForTransactionReceipt } from "@thruputchain/react";

export function TransactionStatus({ hash }: { hash: string | null }) {
  const receipt = useWaitForTransactionReceipt({
    hash: hash || null,
    wait: { timeoutMs: 60_000, pollingIntervalMs: 500 },
  });

  if (!hash) return <p>No transaction selected.</p>;
  if (receipt.error) {
    return (
      <section>
        <p role="alert">Observation stopped: {receipt.error.message}</p>
        <button disabled={receipt.isFetching} onClick={() => void receipt.refetch()}>
          Check again
        </button>
      </section>
    );
  }
  if (!receipt.data) return <p>Waiting for a committed receipt…</p>;

  const succeeded = receipt.data.execResult === ExecResult.ExecResultOK;
  return (
    <p>
      {succeeded ? "Execution succeeded" : "Execution failed"}
      {" at block "}{receipt.data.height.toString()}
    </p>
  );
}
```

A failed committed execution is **receipt data**, not a query error. A query timeout means observation stopped, not that the transaction failed.



## Resume observation

Restore the saved hash and its network from the application’s pending record. Missing hashes disable the query. Refetch explicitly to resume after a timeout; do not submit a new operation merely to obtain a result.

The SDK owns polling. The receipt query disables retries and automatic focus/reconnect refetching. Committed receipts have infinite stale time. Observers of the same hash share the query, so configure their timeout and polling settings consistently.

Canceling the query cancels observation, never the transaction.



## Interpret contract results

The receipt is for the transaction’s root method. A wallet-wrapped application call must be decoded through the wallet’s child results, not by treating the root as the application method. Use the [TypeScript receipt model](pages/typescript/transaction-status.md#decode-the-correct-method).

Generated event descriptors can select receipt events by emitter and type. The application decides whether commitment completes its workflow; a queued request may require later events before the requested action is complete.

---

## React API reference

Source: <https://thruput.network/react/reference/>

Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.

| Entry point                                                   | Purpose                                                                                               |
| ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `@thruputchain/react`                                         | All public React exports below                                                                        |
| [Setup](pages/react/setup.md)                                 | Installation and context wiring                                                                       |
| [TypeScript client reference](pages/tools/typescript-sdk.md)  | Shared SDK concepts and operations; use the client supported by the React package’s peer dependencies |
| [React source](https://github.com/thruputchain/thruput-react) | Public declarations and implementation                                                                |



## WalletProvider

| Prop               | Type / behavior                                                                   |
| ------------------ | --------------------------------------------------------------------------------- |
| `client`           | Initialized `ConnectedThruputClient` with validated cluster identity; keep stable |
| `children`         | `ReactNode`                                                                       |
| `discoveryTarget?` | `EventTarget`; browser default is `window` after mounting                         |

| Context behavior   | Rule                                                                        |
| ------------------ | --------------------------------------------------------------------------- |
| Scope              | One application network and selected wallet connection                      |
| Discovery          | Automatic after mounting; first provider selected without prompting         |
| Connection         | Explicit; no automatic reconnect or persisted connection                    |
| Client replacement | Dispose binding and start disconnected, including same-network replacements |
| Server rendering   | Disconnected initial state; browser discovery after mount                   |
| Usage              | [Providers and clients](pages/react/providers.md)                           |



## Wallet hooks

| Hook                | Result                                                           |
| ------------------- | ---------------------------------------------------------------- |
| `useClient()`       | The configured public client, including while disconnected       |
| `useWallet()`       | `WalletConnection`: reactive state and stable connection actions |
| `useWalletClient()` | Current provider-backed signing client or `null`                 |
| Context requirement | `WalletProvider`; no QueryClient required for these three hooks  |



### WalletConnection

| Field / action               | Meaning                                                                    |
| ---------------------------- | -------------------------------------------------------------------------- |
| `providers` / `provider`     | Discovered providers and selected provider                                 |
| `session`                    | Validated network and authorized accounts, or `null`                       |
| `account` / `address`        | Selected wire account and canonical hex address, or `null`                 |
| `networkHash`                | Expected application network, without `0x`                                 |
| `status`                     | `disconnected`, `connecting`, `connected`, `disconnecting`, `wrongNetwork` |
| `error`                      | Latest connection/selection error, or `null`                               |
| `connect()` / `disconnect()` | `Promise<void>`; request failures appear in `error`                        |
| `selectProvider(id)`         | Select a discovered provider without prompting                             |
| `selectAccount(address)`     | Select an authorized account and recreate the binding                      |
| Usage                        | [Connect a wallet](pages/react/wallets.md)                                 |



## Contract reads

| API                               | Inputs / result                                                                            |
| --------------------------------- | ------------------------------------------------------------------------------------------ |
| `useContractView(input)`          | Generated `method`, `contract`, typed `args`, optional `caller`, `enabled`, `staleTime`    |
| `contractViewQueryOptions(input)` | Same inputs plus explicit initialized `client`; reusable TanStack options                  |
| Result                            | Query state and `queryKey`; data is `ContractView<R>` with `value`, `height`, and `events` |
| Defaults                          | `enabled: true`, `staleTime: 0`; other query behavior follows the QueryClient              |
| Key                               | Client/network, decoder identity, contract, entrypoint, encoded arguments, caller          |
| Cancellation                      | Abort the view request and discard late results                                            |
| Validation                        | Arguments are encoded while constructing the query, even when disabled                     |
| Usage                             | [Read contract data](pages/react/reads.md)                                                 |



## Balances

| API                                             | Inputs / result                                                                    |
| ----------------------------------------------- | ---------------------------------------------------------------------------------- |
| `useBalance({ address?, query? }?)`             | Native-token balance                                                               |
| `useTokenBalance({ token?, address?, query? })` | Standard ERC-20 balance                                                            |
| `BalanceAddress`                                | Hex string or SDK-branded address bytes                                            |
| `BalanceData`                                   | `{ rawBalance: bigint; height: bigint }`                                           |
| Hook result                                     | TanStack Query state plus `queryKey`; `query.select` can change observer data type |
| Omitted `address`                               | Connected account on the application’s network                                     |
| Explicit address                                | Read without wallet permission                                                     |
| Null address / missing token                    | Skip fetching                                                                      |
| Invalid address                                 | Query error state                                                                  |
| Cancellation                                    | Discard abandoned results; underlying balance RPC may finish                       |
| Usage                                           | [Read balances](pages/react/balances.md)                                           |



### Balance query options

| Option                                                         | Behavior                                                     |
| -------------------------------------------------------------- | ------------------------------------------------------------ |
| `enabled`                                                      | Control automatic observer fetching                          |
| `staleTime`, `gcTime`                                          | Freshness and cache retention                                |
| `refetchInterval`, `refetchIntervalInBackground`               | Explicit polling                                             |
| `refetchOnMount`, `refetchOnReconnect`, `refetchOnWindowFocus` | Refresh triggers                                             |
| `retry`, `retryDelay`                                          | Read retry policy                                            |
| `select`                                                       | Transform observer data; cache remains raw `BalanceData`     |
| Key / fetch function                                           | Owned by the library; not configurable through these options |



## Transaction execution

| API / field                | Behavior                                                                          |
| -------------------------- | --------------------------------------------------------------------------------- |
| `useExecute()`             | TanStack mutation through the current wallet                                      |
| `ExecuteVariables.request` | SDK `PrepareExecutionRequest`: inner invocation, root budget, transaction options |
| `ExecuteVariables.options` | Required `onSigned`; optional `wait` observation controls                         |
| `mutate(variables)`        | Start from an event handler; expose mutation state                                |
| `mutateAsync(variables)`   | Await execution; rejects on failure                                               |
| Successful data            | `{ txHash, receipt }` after successful committed execution                        |
| Retry                      | Always disabled by the hook                                                       |
| Invalidation               | Application-owned; no automatic balance refresh                                   |
| Typed child results        | Use the signing client’s `executeCallsAndWait`                                    |
| Usage                      | [Send transactions](pages/react/transactions.md)                                  |



## Receipt observation

| API / option                                      | Behavior                                                                        |
| ------------------------------------------------- | ------------------------------------------------------------------------------- |
| `useWaitForTransactionReceipt({ hash?, wait? }?)` | Public observation; wallet connection not required                              |
| `hash`                                            | Hex string; `null` or `undefined` skips fetching                                |
| `wait.timeoutMs` / `pollingIntervalMs`            | SDK observation settings; configure consistently for the same hash              |
| Data                                              | `TransactionReceipt`, including failed committed execution                      |
| Query error                                       | Observation failure, not proof of failed execution                              |
| `queryKey`                                        | Client/network-scoped canonical hash                                            |
| Defaults                                          | Infinite stale time; no query retry, focus/reconnect refetch, or retry on mount |
| Cancellation                                      | Cancels observation, never the transaction                                      |
| Usage                                             | [Track transaction results](pages/react/transaction-status.md)                  |



## Query factories and keys

| Export                           | Inputs / purpose                                                                         |
| -------------------------------- | ---------------------------------------------------------------------------------------- |
| `balanceQueryOptions`            | Explicit client, address, optional balance-query settings                                |
| `tokenBalanceQueryOptions`       | Explicit client, address, token, optional balance-query settings                         |
| `contractViewQueryOptions`       | Explicit client and typed view inputs                                                    |
| `transactionReceiptQueryOptions` | Explicit client, hash, and wait settings                                                 |
| `getClientQueryKey(client)`      | Stable-value network/client prefix for custom query keys                                 |
| Factory context                  | No hook or provider required; use the same client instance to share cache entries        |
| Missing balance inputs           | Skipped query; do not use imperative fetch with missing inputs                           |
| Cache lifetime                   | In-memory client identity; not portable for persisted caches or server/browser hydration |
| Usage                            | [Cache and refresh data](pages/react/queries.md)                                         |

---

## Guides

Source: <https://thruput.network/guides/>

Build a counter app, a token contract, or an AMM with runnable examples and verified checkpoints.

Build a project with a visible result or passing check. The counter series starts from an empty directory. The [examples repository](https://github.com/thruputchain/thruput-examples) supplies the token and AMM contracts and a full-featured counter app for reference.



## Build a counter app

One contract and one application across four parts:

1. [Contract](pages/tutorials/build-a-counter.md): write, test, and deploy the counter.
2. [TypeScript](pages/tutorials/work-with-thruput-from-typescript.md): create the client and a server-side development signer.
3. [React](pages/tutorials/build-a-counter-with-react.md): build a working counter interface with development signing and receipt tracking.
4. [Connect a wallet](pages/tutorials/connect-a-wallet-to-your-app.md): switch to wallet-approved updates and return to development signing on explicit disconnect.

Follow the four parts in order, using your own contract and deployment throughout.



## Build another contract

- [Build a token](pages/tutorials/build-a-token.md): balances, allowances, supply policy, events, and native/RV32 checks.
- [Build an AMM](pages/tutorials/build-an-amm.md): pool creation, liquidity, queued swaps, and correlated outcomes, exercised through the contract test environments.

Use the CLI, Smart Contracts, TypeScript, and React sections for individual tasks and API details. Network setup, event APIs, and wallet connection have their canonical instructions there.

---

## Build a counter, part 1: Contract

Source: <https://thruput.network/tutorials/build-a-counter/>

Create, test, and deploy the contract for a counter application, starting from an empty directory.

Build a small counter application from scratch. Across four parts, you will create a contract, add a TypeScript development signer, build a React interface, and let users switch to their own wallet.

You can also explore the [full counter example on GitHub](https://github.com/thruputchain/thruput-examples/tree/main/apps/counter).



## Create the contract

Complete [CLI installation and Cargo access](pages/cli/install.md). For deployment, use a funded Futurenet account from the [CLI quickstart](pages/get-started/cli.md).

```bash
thruput new counter --template counter
cd counter
```

Keep the generated manifest and toolchain settings. Open `src/implementation.rs`. The scaffold includes the counter used by this guide; focus on its storage and these methods.



## Store a relative count

```rust
#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}
```

`value` is a persistent storage handle. Increment and decrement record signed deltas:

```rust
pub fn increment(&mut self, amount: u64) {
    self.value.strict_inc(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.strict_inc(-(amount as i128));
}
```

`strict_inc` checks the invocation for underflow and records the relative change. Compatible deltas can merge across concurrent transactions. See [NNInt and concurrent updates](pages/programming-model/nnint.md) for the merge rules.

The read defaults only missing storage to zero:

```rust
pub fn get(&self) -> u64 {
    self.value.try_get().none_if_missing().unwrap_or(0) as u64
}
```

The scaffold’s `initialize` method adds its initial amount. It is an ordinary method, so call it once during this deployment flow. This teaching counter allows any caller to update it. Leave the extra scaffold event and error methods in place; the app does not need them.



## Run both test modes

```bash
cargo test
thruput test
```

The native tests exercise contract logic and underflow handling. The artifact test runs the compiled RV32 contract. Neither needs a running RPC node.

**Checkpoint:** the counter tests pass, including a decrement that is expected to fail.



## Build, deploy, and initialize

```bash
thruput build
thruput deploy --estimate --profile futurenet
```

Add **10 native test tokens** to the reported minimum funding in whole-token units as an example allowance for initializer storage and later writes. This is a budget, not an exact estimate of those writes or a universal requirement. Replace `TOTAL_FUNDING` with the decimal sum. The minimum alone covers only the first balance-item deposit and deployment collateral, leaving no free contract balance. See [Estimate deployment funding](pages/cli/deploy-and-call.md#estimate-deployment-funding).

```bash
thruput deploy --profile futurenet --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
thruput view counter get --profile futurenet
```

Funding, deployment, and initialization happen in one transaction. The sender still needs its own storage and scheduling capacity. Your new counter should read `10`.

Save the printed deployment address. Part 2 uses this address and the contract spec produced by the build.



## Check a change

```bash
thruput call counter increment 1 --profile futurenet
thruput view counter get --profile futurenet
```

On your otherwise unchanged counter, the value is now `11`. Keep the same address and project for [part 2](pages/tutorials/work-with-thruput-from-typescript.md).

For isolated local work, follow [Run a local node](pages/cli/local-node.md) and use its profile, endpoint, and network identity consistently.



## Work with an agent

```text
Follow Build a counter, part 1:
https://thruput.network/docs/tutorials/build-a-counter/
Start with thruput new counter --template counter, without cloning an examples repo.
Run the native and RV32 checks, build, and read the deployment estimate.
Add the documented storage allowance to the minimum and deploy with that
explicit total using my configured Futurenet account. Initialize atomically to 10.
Report the actual address, transaction hash,
and read value. Keep the generated dependency configuration and report
failed checks rather than inventing results.
```

---

## Build a counter, part 2: TypeScript

Source: <https://thruput.network/tutorials/work-with-thruput-from-typescript/>

Create a typed client and a small server-side development signer for the counter, without cloning a repository.

Build the TypeScript layer for the contract from [part 1](pages/tutorials/build-a-counter.md). It will read the counter and prepare signed updates with a funded development key. The key stays in Node.js. Part 3 adds a React interface that can start counting immediately.



## Create the app directory

Inside the `counter` project from part 1:

```bash
mkdir app
cd app
npm init -y
npm pkg set type=module
```

Configure [npm registry access](pages/typescript/setup.md#give-npm-package-access), then install the TypeScript dependencies:

```bash
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src/contracts
```

Keep the generated lockfile. Add these entries to `.gitignore`:

**.gitignore**

```text
node_modules/
dist/
.env
```



## Generate the TypeScript binding

Use Thruput CLI 0.29.0 or newer. Its TypeScript generator imports the `@thruputchain` packages used by this app. Generate the binding from the contract spec built in part 1. Run this from `app`:

```bash
thruput codegen ts ../target/thruput/counter.spec.xdr \
  --output src/contracts/counter.ts
```

The binding provides typed methods and decodes the contract’s results. Regenerate it when the contract interface changes.



## Configure the client

Create `.env`. Set `COUNTER_ADDRESS` to the deployment address from part 1 and use the endpoint and network hash for that deployment:

**.env**

```dotenv
RPC_URL=https://rpc.thruput.network
NETWORK_HASH=0xabb9cdbc56285d0e71c9845273ca06211fedf7ee2f58c43cfac6060f9402aa0f
COUNTER_ADDRESS=<your-deployed-counter-address>
```

These public values identify one deployment. A different network needs its own endpoint, hash, and contract address.

**chain.ts**

```ts
import {
  addressFromHex, createThruputClient, createPubkeyAccount, createWalletClient,
  defineCluster, fromHex0x, hashFromHex, networkHash, PrivateKeySigner,
} from "@thruputchain/client";
import { Counter } from "./src/contracts/counter.js";

function required(name: string) {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} in .env or the process environment`);
  return value;
}

export const rpcUrl = required("RPC_URL");
export const contract = addressFromHex(required("COUNTER_ADDRESS"));
export const client = await createThruputClient({
  cluster: defineCluster({
    rpcUrl,
    networkHash: networkHash(hashFromHex(required("NETWORK_HASH"))),
    capabilities: ["airdrop"],
  }),
});
export { Counter };

export function developmentWallet() {
  const signer = new PrivateKeySigner(fromHex0x(required("COUNTER_SIGNING_PRIVATE_KEY")));
  return createWalletClient({ client, account: createPubkeyAccount({ signer }) });
}
```



## Read and fund

**read.ts**

```ts
import { client, contract, Counter } from "./chain.js";

const result = await Counter.v0_1.get.view({ client, contract });
console.log("Counter:", result.value.toString());
console.log("Read at block:", result.height.toString());
```

```bash
node --env-file=.env --import tsx read.ts
```

For a disposable development signer, generate a seed once in this terminal:

```bash
export COUNTER_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep this terminal environment for funding and the server. A persistent account should load its existing seed from secret configuration. Never put this key in a browser file or a `VITE_` variable.

**fund.ts**

```ts
import { toHex0x } from "@thruputchain/client";
import { developmentWallet } from "./chain.js";

const wallet = developmentWallet();
const funding = await wallet.requestAirdrop();
if (funding.status.result !== "ok") throw new Error("Funding did not execute successfully");
console.log("Development signer:", toHex0x(wallet.account.address));
console.log("Funding transaction:", toHex0x(funding.txHash));
```

```bash
node --env-file=.env --import tsx fund.ts
```



## Add the development server

The server exposes public configuration, proxies the app’s RPC requests, and prepares only a `+1` or `-1` call to the configured counter. Preparation signs but does not broadcast. The browser can therefore retain the hash before submission.

**server.ts**

```ts
import { createServer, type ServerResponse } from "node:http";
import { gasAmount, serializeSignedTransaction, toHex0x } from "@thruputchain/client";
import { client, contract, Counter, developmentWallet, rpcUrl } from "./chain.js";

const wallet = process.env.COUNTER_SIGNING_PRIVATE_KEY ? developmentWallet() : null;
const allowed = new Set([
  "groundhog_networkInfo", "groundhog_chainTip", "groundhog_view",
  "groundhog_getBalance", "groundhog_getTransactionStatus",
  "groundhog_getTransactionReceipt", "groundhog_sendRawTransaction",
]);
function json(response: ServerResponse, status: number, value: unknown) {
  response.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  response.end(JSON.stringify(value));
}

createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/api/config") {
      return json(response, 200, {
        counterAddress: toHex0x(contract), networkId: toHex0x(client.network.networkHash),
        signerAddress: wallet ? toHex0x(wallet.account.address) : null,
      });
    }
    if (request.method !== "POST") return json(response, 404, { error: "Not found" });
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 65_536) return json(response, 413, { error: "Request too large" });
      chunks.push(Buffer.from(chunk));
    }
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (request.url === "/api/prepare") {
      if (!wallet) return json(response, 503, { error: "Development signer unavailable" });
      if (body?.direction !== "increment" && body?.direction !== "decrement") {
        return json(response, 400, { error: "Choose increment or decrement" });
      }
      const direction: "increment" | "decrement" = body.direction;
      const transaction = await wallet.prepareExecution({
        invocation: Counter.v0_1[direction].invocation(contract, gasAmount(500_000n), { amount: 1n }),
        gasLimit: gasAmount(1_000_000n),
      });
      const signed = await wallet.signTransaction(transaction);
      return json(response, 200, { transaction: toHex0x(serializeSignedTransaction(signed)) });
    }
    if (request.url === "/thruput-rpc" && allowed.has(body?.method)) {
      const upstream = await fetch(rpcUrl, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body), signal: AbortSignal.timeout(10_000),
      });
      return json(response, upstream.status, await upstream.json());
    }
    json(response, 404, { error: "Not found" });
  } catch (error) {
    json(response, 500, { error: error instanceof Error ? error.message : "Request failed" });
  }
}).listen(3001, "127.0.0.1", () => console.log("Counter API: http://127.0.0.1:3001"));
```

Run it in the terminal holding the development key:

```bash
node --env-file=.env --import tsx server.ts
```

**Checkpoint:** the typed read works, the development account is funded, and the API is running. The server keeps its private key; `/api/config` exposes only public identity. Part 3 turns these pieces into a usable React counter.

This server is for local development.



## Work with an agent

```text
Follow Build a counter, part 2:
https://thruput.network/docs/tutorials/work-with-thruput-from-typescript/
Generate the binding from my part-1 contract spec and create the listed
files using my deployment address. Verify the read, funding, and
public configuration endpoint. Keep the development key server-side.
Do not claim success for failed checks or submit replacement transactions
merely because observation failed.
```

---

## Build a counter, part 3: React

Source: <https://thruput.network/tutorials/build-a-counter-with-react/>

Build a small React counter that can read and update the contract immediately through the development signer.

Add a React interface to the project from [part 2](pages/tutorials/work-with-thruput-from-typescript.md). It will work through the funded development signer as soon as you open it. There is no wallet connection requirement yet.

Keep the API server running on port 3001. All files below are inside the `app` directory you created in part 2.



## Install React

From `app`, install the React packages and browser tooling:

```bash
npm install @thruputchain/react @tanstack/react-query react react-dom
npm install --save-dev vite @types/react @types/react-dom
```



## Add the browser entry point

```bash
npm pkg set scripts.dev="vite" scripts.build="tsc --noEmit && vite build"
```

**tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022", "module": "ESNext", "moduleResolution": "Bundler",
    "jsx": "react-jsx", "strict": true, "noUncheckedIndexedAccess": true,
    "skipLibCheck": true, "noEmit": true, "types": ["vite/client", "node"]
  },
  "include": ["*.ts", "src"]
}
```

**vite.config.ts**

```ts
import { defineConfig } from "vite";

export default defineConfig({
  server: {
    host: "127.0.0.1",
    proxy: {
      "/api": "http://127.0.0.1:3001",
      "/thruput-rpc": "http://127.0.0.1:3001",
    },
  },
});
```

**index.html**

```html
<!doctype html>
<html lang="en">
  <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Counter</title></head>
  <body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body>
</html>
```



## Connect the public client

**src/main.tsx**

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, defineCluster, hashFromHex, networkHash } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { App } from "./App";
import type { Config } from "./updates";
import "./style.css";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting…</p>);

async function start() {
  const response = await fetch("/api/config");
  if (!response.ok) throw new Error("Could not load counter configuration");
  const config: Config = await response.json();
  const client = await createThruputClient({
    cluster: defineCluster({
      rpcUrl: new URL("/thruput-rpc", location.origin).href,
      networkHash: networkHash(hashFromHex(config.networkId)),
      capabilities: [],
    }),
  });
  const queries = new QueryClient();
  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}><App config={config} /></WalletProvider>
    </QueryClientProvider>,
  );
}
void start().catch((error: unknown) => root.render(
  <p role="alert">{error instanceof Error ? error.message : "Could not start the app"}</p>,
));
```

The React provider shares the public client and discovers wallet providers without asking for permission. The next part uses that wallet context. The development signer remains on the API server.

Add a small stylesheet to keep the example readable on narrow screens:

**src/style.css**

```css
body { margin: 0; font-family: system-ui, sans-serif; }
main { max-width: 48rem; margin: auto; padding: 1.5rem; }
section { margin-block: 1.5rem; }
p { overflow-wrap: anywhere; }
button, select { max-width: 100%; margin: .25rem; padding: .5rem .75rem; font: inherit; }
output { font-size: 3rem; font-variant-numeric: tabular-nums; }
```



## Separate preparation from submission

Create a small shared update module. It retains the hash before submitting and can observe a saved operation after a reload:

**src/updates.ts**

```ts
import { useRef, useState } from "react";
import { deserializeSignedTransaction, fromHex0x, hashSignedTransaction, toHex0x, type ConnectedThruputClient } from "@thruputchain/client";
import { parseSignTransactionResult } from "@thruputchain/client/provider";
import { useClient, useWaitForTransactionReceipt } from "@thruputchain/react";

export type Config = { networkId: string; counterAddress: string; signerAddress: string | null };
export type Direction = "increment" | "decrement";
export type Pending = { hash: string; signedTransaction: string; account: string; networkId: string };
export type Prepared = { record: Pending; submit(): Promise<unknown> };

export async function archiveExpiredUpdate(client: ConnectedThruputClient, record: Pending, key: string, storage: Pick<Storage, "setItem" | "removeItem">) {
  if (toHex0x(client.network.networkHash) !== record.networkId) throw new Error("Select the original network before recovery");
  const signed = deserializeSignedTransaction(fromHex0x(record.signedTransaction));
  const hash = hashSignedTransaction(signed);
  if (toHex0x(hash) !== record.hash) throw new Error("Saved transaction hash does not match its bytes");
  const tip = await client.getChainTip();
  if (tip.height < signed.tx.uniquifier.block_expiry_height) throw new Error("The transaction has not expired; keep observing it");
  if (await client.getTransactionReceipt(hash)) throw new Error("A receipt is available; check the transaction and finish it");
  // Expiry prevents future inclusion, but a missing receipt does not prove it never committed.
  storage.setItem(`${key}:archived:${record.hash}`, JSON.stringify({ ...record, outcome: "unresolved", archivedAtHeight: tip.height.toString() }));
  storage.removeItem(key);
}

export async function prepareDevelopment(client: ConnectedThruputClient, config: Config, direction: Direction): Promise<Prepared> {
  if (!config.signerAddress) throw new Error("Development signer unavailable");
  const response = await fetch("/api/prepare", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ direction }),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Preparation failed");
  const signed = deserializeSignedTransaction(fromHex0x(body.transaction));
  return {
    record: { hash: toHex0x(hashSignedTransaction(signed)), signedTransaction: body.transaction, account: config.signerAddress, networkId: config.networkId },
    submit: () => client.sendTransaction(signed),
  };
}

export function useUpdate(config: Config) {
  const client = useClient();
  const key = `counter:${config.networkId}:${config.counterAddress}`;
  const [state, setState] = useState<{ record: Pending | null; error: string | null }>(() => {
    try {
      const text = localStorage.getItem(key);
      if (!text) return { record: null, error: null };
      const value = JSON.parse(text);
      const signed = parseSignTransactionResult({ hash: value.hash, signedTransaction: value.signedTransaction });
      if (value.networkId !== config.networkId || typeof value.account !== "string") throw new Error("Invalid saved transaction");
      return { record: { ...signed, account: value.account, networkId: value.networkId }, error: null };
    } catch { return { record: null, error: "Cannot read the saved transaction. Check browser storage before sending." }; }
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const lock = useRef(false);
  const receipt = useWaitForTransactionReceipt({ hash: busy ? null : state.record?.hash ?? null });

  async function send(prepare: () => Promise<Prepared>) {
    if (lock.current || state.record || state.error) return;
    lock.current = true; setBusy(true); setError(null); setNotice(null);
    try {
      const update = await prepare();
      localStorage.setItem(key, JSON.stringify(update.record));
      setState({ record: update.record, error: null });
      await update.submit();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Update failed");
    } finally { lock.current = false; setBusy(false); }
  }
  function finish() {
    if (!receipt.data) return;
    try { localStorage.removeItem(key); setState({ record: null, error: null }); setError(null); }
    catch { setError("Could not clear the saved record"); }
  }
  async function archiveExpired() {
    if (lock.current || !state.record) return;
    const record = state.record;
    if (!window.confirm("Archive this expired update? Its past outcome may still be unknown. This does not resend or cancel it. Inspect its original hash before repeating the operation.")) return;
    lock.current = true; setBusy(true); setError(null);
    try {
      await archiveExpiredUpdate(client, record, key, localStorage);
      setState({ record: null, error: null });
      setNotice(`Archived ${record.hash} in browser storage. Its outcome is unresolved; inspect this hash before repeating the operation.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Recovery failed");
    } finally { lock.current = false; setBusy(false); }
  }
  return { pending: state.record, error: state.error ?? error, notice, busy, blocked: busy || Boolean(state.record || state.error), receipt, send, finish, archiveExpired };
}
```

The preparer returns a signed record and a submission function. This keeps the UI independent of how the signature was obtained. A failed storage write stops before submission. A later submission error retains the hash for observation.



## Build the small components

**src/Counter.tsx**

```tsx
import { addressFromHex, ExecResult } from "@thruputchain/client";
import { contractViewQueryOptions, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";
import { Counter } from "./contracts/counter";
import type { Direction, useUpdate } from "./updates";

export function CounterPanel({ address, disabled, send }: {
  address: string; disabled: boolean; send(direction: Direction): void;
}) {
  const client = useClient();
  const counter = useQuery({
    ...contractViewQueryOptions({ client, method: Counter.v0_1.get, contract: addressFromHex(address) }),
    refetchInterval: 2_000,
  });
  return <section>
    {counter.isLoading ? <p>Reading counter…</p> : null}
    {counter.error ? <p role="alert">{counter.error.message}</p> : null}
    <p><output aria-label="Counter value">{counter.data?.value.toString() ?? "Not loaded"}</output></p>
    <button type="button" disabled={disabled || !counter.data || counter.data.value === 0n} onClick={() => send("decrement")}>Decrement</button>
    <button type="button" disabled={disabled || !counter.data} onClick={() => send("increment")}>Increment</button>
  </section>;
}

export function UpdateStatus({ update }: { update: ReturnType<typeof useUpdate> }) {
  return <section aria-label="Transaction">
    {update.busy ? <p>Preparing or submitting…</p> : null}
    {update.error ? <p role="alert">{update.error}</p> : null}
    {update.notice ? <p role="status">{update.notice}</p> : null}
    {update.pending ? <>
      <p>Original signer: {update.pending.account}</p>
      <p>Transaction: {update.pending.hash}</p>
      {update.receipt.data ? <>
        <p role="status">{update.receipt.data.execResult === ExecResult.ExecResultOK ? "Update committed" : "Execution failed"}</p>
        <button type="button" onClick={update.finish}>Finish</button>
      </> : <>
        <p>Waiting for a result. A timeout does not cancel the transaction.</p>
        {update.receipt.error ? <p role="alert">{update.receipt.error.message}</p> : null}
        <button type="button" disabled={update.busy || update.receipt.isFetching} onClick={() => void update.receipt.refetch()}>Check transaction</button>
        <button type="button" disabled={update.busy} onClick={() => void update.archiveExpired()}>Archive expired update</button>
      </>}
    </> : null}
  </section>;
}
```

**src/App.tsx**

```tsx
import { useClient } from "@thruputchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { prepareDevelopment, useUpdate, type Config } from "./updates";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const update = useUpdate(config);
  return <main>
    <h1>Counter</h1>
    <p>Using development signer: {config.signerAddress ?? "Not configured"}</p>
    <CounterPanel address={config.counterAddress} disabled={update.blocked || !config.signerAddress}
      send={direction => void update.send(() => prepareDevelopment(client, config, direction))} />
    <UpdateStatus update={update} />
  </main>;
}
```



## Run and verify

In a second terminal inside `app`, leaving the API server running:

```bash
npm run dev
```

Open Vite’s URL. Click **Increment**, wait for **Update committed**, and confirm the refreshed counter value. Click **Finish** before another update. Try **Decrement** too.

The public read refreshes independently of signing. An error or timeout does not cause another transaction to be submitted. A saved hash remains available after reload; this minimal example keeps one unresolved update per counter and network in one browser tab.

If submission was stopped after signing, a receipt may never arrive. **Archive expired update** checks the original network, signed bytes, expiry height, and receipt before releasing the active slot. It preserves the complete record under `counter:NETWORK:CONTRACT:archived:HASH` in browser storage. It does not resend the transaction or prove it never committed: an unavailable or lagging indexer can still hide a past receipt. Inspect the original hash before repeating the operation. Recovery errors, including a failed archive write, keep the active record.

```bash
npm run build
```

**Checkpoint:** a working React counter using a server-held development signer. No wallet connection or keyboard/concurrency machinery is needed. Part 4 adds a different signing path to these same components.



## Work with an agent

```text
Follow Build a counter, part 3:
https://thruput.network/docs/tutorials/build-a-counter-with-react/
Create the listed files in my existing app directory. Do not clone an
examples repo. Verify reads, increment/decrement, transaction feedback,
and the build. Keep the development key on the server and retain an
unresolved transaction's hash instead of submitting a replacement.
```

---

## Build a counter, part 4: Connect a wallet

Source: <https://thruput.network/tutorials/connect-a-wallet-to-your-app/>

Let the user switch from the development signer to a connected wallet in the same counter application.

Keep the app from [part 3](pages/tutorials/build-a-counter-with-react.md). It already works through the development signer. Add wallet controls so a successful connection switches new updates to the user’s wallet; explicit disconnect returns to the development signer.

The display, contract, public client, and transaction-status component stay the same. Only preparation and submission differ.



## Prepare the wallet

Install the [Wallet Extension](pages/tools/wallet-extension.md) and select the app’s network. Request native test tokens for that wallet’s account; it is independent of the server’s development signer.

`WalletProvider` is already mounted from part 3. It discovers providers without requesting permission.



## Add wallet controls

**src/WalletControls.tsx**

```tsx
import { useWallet } from "@thruputchain/react";

export function WalletControls({ busy, walletMode, disconnect }: {
  busy: boolean; walletMode: boolean; disconnect(): void;
}) {
  const wallet = useWallet();
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  return <section aria-label="Wallet connection">
    <label>Wallet <select name="wallet" value={wallet.provider?.info.id ?? ""}
      disabled={busy || connecting || wallet.providers.length === 0}
      onChange={event => wallet.selectProvider(event.target.value)}>
      <option value="" disabled>No wallet detected</option>
      {wallet.providers.map(provider => <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>)}
    </select></label>
    <button type="button" disabled={busy || connecting || !wallet.provider || wallet.status === "connected"}
      onClick={() => void wallet.connect()}>Connect wallet</button>
    {walletMode ? <button type="button" disabled={busy || connecting} onClick={disconnect}>Disconnect wallet</button> : null}
    {wallet.session && wallet.session.accounts.length > 1 ? <label>Account
      <select name="account" value={wallet.address ?? ""} disabled={busy || connecting}
        onChange={event => wallet.selectAccount(event.target.value)}>
        {wallet.session.accounts.map(account => <option key={account.address} value={account.address}>{account.address}</option>)}
      </select>
    </label> : null}
    {wallet.status === "wrongNetwork" ? <p role="alert">Select the app's network in your wallet.</p> : null}
    {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
  </section>;
}
```



## Add the wallet preparer

**src/wallet-update.ts**

```ts
import { addressFromHex, gasAmount } from "@thruputchain/client";
import type { ProviderWalletClient } from "@thruputchain/client/wallet";
import { Counter } from "./contracts/counter";
import type { Config, Direction, Prepared } from "./updates";

export async function prepareWallet(wallet: ProviderWalletClient, account: string, config: Config, direction: Direction): Promise<Prepared> {
  const transaction = await wallet.prepareExecution({
    invocation: Counter.v0_1[direction].invocation(addressFromHex(config.counterAddress), gasAmount(500_000n), { amount: 1n }),
    gasLimit: gasAmount(1_000_000n),
  });
  const signed = await wallet.signTransaction(transaction);
  return {
    record: { ...signed, account, networkId: config.networkId },
    submit: () => wallet.submitTransaction(signed),
  };
}
```

The same `useUpdate` hook saves the signed record before invoking `submit`. A wallet rejection prevents submission. The application never receives the wallet’s private key.



## Switch signing paths

Replace `src/App.tsx`:

**src/App.tsx**

```tsx
import { useEffect, useState } from "react";
import { useClient, useWallet, useWalletClient } from "@thruputchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { WalletControls } from "./WalletControls";
import { prepareDevelopment, useUpdate, type Config, type Direction } from "./updates";
import { prepareWallet } from "./wallet-update";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const wallet = useWallet();
  const signingClient = useWalletClient();
  const update = useUpdate(config);
  const [selected, setSelected] = useState<"development" | "wallet">("development");
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";
  useEffect(() => { if (authorized) setSelected("wallet"); }, [authorized]);
  const walletMode = authorized || selected === "wallet";
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  const canSend = walletMode ? wallet.status === "connected" && signingClient !== null : config.signerAddress !== null;

  function disconnect() {
    void wallet.disconnect();
    setSelected("development");
  }
  function send(direction: Direction) {
    if (!canSend || connecting || update.blocked) return;
    if (walletMode) {
      if (!signingClient || !wallet.address) return;
      const originalClient = signingClient;
      const originalAccount = wallet.address;
      void update.send(() => prepareWallet(originalClient, originalAccount, config, direction));
    } else {
      void update.send(() => prepareDevelopment(client, config, direction));
    }
  }
  return <main>
    <h1>Counter</h1>
    <p>{walletMode ? "Using connected wallet" : "Using development signer"}: {walletMode ? wallet.address ?? "Unavailable" : config.signerAddress ?? "Unavailable"}</p>
    <WalletControls busy={update.busy} walletMode={walletMode} disconnect={disconnect} />
    <CounterPanel address={config.counterAddress} disabled={!canSend || connecting || update.blocked} send={send} />
    <UpdateStatus update={update} />
  </main>;
}
```

A successful connection selects wallet signing immediately. A later session loss or wrong network keeps wallet mode selected and pauses writes. It does not silently send through the development key. Explicit disconnect opts back into development signing.

Each update captures its original signing client and account. A receipt is observed through the public client, so disconnecting does not cancel an already-submitted transaction.



## Verify both paths

1. Open the app disconnected. Increment with the development signer and inspect its hash and result.
2. Connect your wallet on the correct network. Confirm the displayed account changes.
3. Increment again and approve the request in the wallet. Wait for the receipt and refreshed value.
4. Reject another approval. The page should show the error without sending through the development signer.
5. Disconnect explicitly. The development-signer label and immediate-update path return.

After a committed result, **Finish** clears its saved record. For an unresolved result, **Check transaction** observes the original hash without submitting again. Reload with a saved hash to verify recovery.

A session change can stop submission after the signed record was saved. Once the signed transaction expires, use **Archive expired update** from part 3 to preserve its evidence and release the active slot. This never switches signers, resubmits, or treats a missing receipt as proof of failure.

```bash
npm run build
```

**Checkpoint:** a small, complete app built without a repository clone. Its default signer is convenient for development, and connected users can approve their own transactions.

You can also explore the [full counter example on GitHub](https://github.com/thruputchain/thruput-examples/tree/main/apps/counter).



## Work with an agent

```text
Follow Build a counter, part 4:
https://thruput.network/docs/tutorials/connect-a-wallet-to-your-app/
Extend my part-3 app using the listed files. Keep development signing
as the default, switch on wallet connection, and return only on explicit
disconnect. Let me approve wallet requests. Verify both paths, rejection,
wrong-network handling, receipt recovery, and the build. Do not clone
the examples repo or add keyboard/concurrency features to this tutorial.
```

---

## Build a token

Source: <https://thruput.network/tutorials/build-a-token/>

Build and test an ERC-20 contract with balances, allowances, administrator-controlled supply, and standard events.

Build the `erc20` contract in the [examples repository](https://github.com/thruputchain/thruput-examples/tree/main/contracts/erc20). You will trace a transfer, exercise minting and allowances, and test both native and RV32 execution.

This is a contract guide. The [counter series](pages/tutorials/build-a-counter.md) covers the full contract-to-application journey; [TypeScript](pages/typescript.md) covers application interactions.



## Prepare the project

Complete [CLI and Cargo setup](pages/cli/install.md), then clone the examples repository if you do not already have it:

```bash
git clone https://github.com/thruputchain/thruput-examples.git
cd thruput-examples
```

Use the workspace’s manifests, toolchain, and lockfile together. The token implements the shared interface crates rather than copying their definitions.



## Model the token state

Open `contracts/erc20/src/implementation.rs`:

```rust
pub struct TokenContract {
    config: Value<Config>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Allowance>>,
    total_supply: Balance,
}
```

The storage attribute derives paths for these handles:

| Field          | Job                                             |
| -------------- | ----------------------------------------------- |
| `config`       | Administrator and optional token metadata       |
| `balances`     | Each account’s nonnegative token amount         |
| `allowances`   | An owner/spender pair’s remaining authorization |
| `total_supply` | Outstanding tokens                              |

Different map keys are independent. Balance changes use deltas instead of replacing a shared absolute value. See [Storage Types](pages/programming-model/storage-types.md) for the merge rules.



## Follow a transfer

The implementation takes the payer from the direct caller:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let owner = get_caller();
    self._decrease_balance(&owner, amount);
    self._lazy_increase_balance(receiver, amount);
    TransferEvent::new(&owner, receiver, amount_to_diff(amount)).log();
}
```

The checked debit reports insufficient balance during execution. The credit records a relative increase. The event records the movement for applications; it is not the source of the contract’s balance state.

`transfer_from` first spends the caller’s allowance, then performs the same debit and credit. An allowance belongs to a specific owner/spender pair, not to every caller.



## Apply supply and allowance policy

Read the `mint`, `burn`, and `adjust_allowance` implementations:

- Minting and burning require the configured administrator.
- Initialization records that administrator and rejects a later initialization.
- Allowances change by a signed `difference`. A positive value adds authority; a negative value removes it.
- An exclusive allowance update requests sole write access to that entry for the block. It does not make a prior offchain read current.
- `clear_allowance` deletes an allowance; `clear_balance` requires an empty balance before deleting its row.

The metadata feature adds name, symbol, and decimals. The permit feature adds signed-operation authorization. Keep the basic transfer policy clear before extending either surface.



## Exercise the contract

```bash
cargo test -p erc20 --locked
```

`tests/test_native.rs` deploys the contract in the SDK environment and runs the shared scenarios under `tests/common`. Inspect those scenarios for administrator checks, minting, transfers, allowance spending, cleanup, and expected exceptions.

`tests/same_block.rs` tests behavior that a serial-only token test would miss:

| Scenario                                                  | Expected result                                             |
| --------------------------------------------------------- | ----------------------------------------------------------- |
| Compatible credits to one balance                         | Deltas merge                                                |
| Debits covered by the balance                             | Both can commit                                             |
| Combined debits exceed the balance                        | Reservation excludes an overdrawing transaction             |
| Read during the same block                                | Reads the block snapshot                                    |
| Approval and a separate spending transaction in one block | The new approval is not already spendable from the snapshot |

Run a specific case while inspecting the corresponding code:

```bash
cargo test -p erc20 --test same_block same_block_credits_merge --locked
```

**Checkpoint:** the native tests pass, including expected failure paths. A test that deliberately catches a contract exception can still be a passing test.



## Build and test the guest artifact

```bash
thruput build -p erc20
thruput test -p erc20
```

The build writes `target/thruput/erc20.rv32a` and spec sidecars. The artifact test exercises the compiled guest implementation. Keep it as well as the native tests.

You now have a deployable token artifact. Use [Deploy and call](pages/cli/deploy-and-call.md) for network deployment and [Use contract bindings](pages/tools/typescript-bindings.md) for typed application calls. The repository’s standard-token and factory examples add a fixed launch configuration for the separate launchpad application.



## Work with an agent

```text
Follow Build a token:
https://thruput.network/docs/tutorials/build-a-token/
Use contracts/erc20 in groundhog-examples with its workspace lockfile.
Trace administrator checks, transfers, allowances, and events in source.
Run the native, same-block, and RV32 tests. Report actual results and
artifact paths. Do not replace the standard interface with invented APIs.
```

---

## Build an AMM

Source: <https://thruput.network/tutorials/build-an-amm/>

Build and exercise a queued constant-product AMM, including liquidity, swaps, request outcomes, and RV32 tests.

Build the AMM contract suite in [thruput-examples](https://github.com/thruputchain/thruput-examples). This guide creates pools, adds and removes liquidity, and executes swaps through its native and RV32 test environments. You will also verify that a failed queued request does not become a false success.

Read [Build a token](pages/tutorials/build-a-token.md) first. Complete [CLI and Cargo setup](pages/cli/install.md). Commands run from the examples repository root with its checked-in manifests and lockfile.



## Assemble the components

| Source                   | Responsibility                                      |
| ------------------------ | --------------------------------------------------- |
| `interfaces/swap-if`     | Shared methods, request types, errors, and clients  |
| `engines/swap-pair`      | Constant-product math and reserve operations        |
| `contracts/swap-handler` | Apply a request, move tokens, and update pair state |
| `contracts/swap-driver`  | Queue and process requests                          |
| `contracts/swap-factory` | Create and connect a pool’s contracts               |
| `contracts/swap-router`  | User-facing liquidity and swap requests             |
| `helpers/batch-driver`   | Shared queue capacity and processing logic          |

The pair is an internal engine used by the handler, not another public contract entry point. The suite adapts [Uniswap V2 pair operations](https://github.com/Uniswap/v2-core/blob/master/contracts/UniswapV2Pair.sol) to Stellar Thruput’s execution model.



## Create a pool

Run the factory’s deployment scenario:

```bash
cargo test -p swap-factory --test factory create_pair_brings_up_pool --locked
```

Open `contracts/swap-factory/src/factory.rs` and `tests/factory.rs`. Creation derives and funds three addresses, deploys the LP token, handler, and driver, initializes their relationships, and records the pair. The tests verify the resulting pool and funding rules.

The factory takes funding from the caller through an allowance. It does not let arbitrary pool creators spend the factory’s own native tokens. Pool addresses are deterministic for the token pair and configured code hashes.

**Checkpoint:** a pool is created in the test environment with its contracts connected correctly.



## Add liquidity

```bash
cargo test -p swap-router --test add_liquidity --locked -- --nocapture
```

In `contracts/swap-router/tests/add_liquidity.rs`, the fixture establishes token balances, authorizes the handler, submits a liquidity request, and processes it. The test helper named `etx` is example test code, not an SDK API:

```rust
etx.user_allow_for_pair(user, amounts_desired)?;
etx.advance_block();
etx.user_add_liquidity(ALICE, amounts_desired)?;
etx.process_outstanding_requests(1)?;
```

The tests also separate the purchaser from the recipient: Alice can supply tokens while Bob receives LP tokens. Assertions check both the mint event and the actual LP balance.



## Execute a swap

```bash
cargo test -p swap-router --test swap carol_swap_exact_tokens_for_tokens --locked -- --nocapture
```

Open `contracts/swap-router/tests/swap.rs`. The exact-input scenario:

1. Establishes pool reserves.
2. Calculates expected output independently of the router.
3. Grants the handler an allowance for the input amount.
4. Submits a request with a minimum output.
5. Processes the queue.
6. Checks both token balances, the consumed allowance, and unchanged LP ownership.

The corresponding exact-output test checks that the requested output is received without exceeding the input cap.

**Checkpoint:** the swap tests pass with real state and event assertions, not just a successful method return.



## Understand acceptance and execution



Every swap changes reserves. Concurrent transactions using the same snapshot cannot all replace those reserves with different values. The implementation separates accepting requests from executing reserve-dependent work:

```text
users → router → driver queue
                    ↓
             process_requests
                    ↓
                 handler → pair engine
```

Queue inserts can merge. Processing consumes requests serially inside one transaction, so each operation sees earlier updates in that transaction. The handler accepts work from its driver, and the driver accepts requests from the configured router.

An accepted request is not a completed swap. Submission returns a request ID and emits `RequestAccepted`. A later operation event or `RequestFailed` identifies its outcome.



## Verify failures and request IDs



```bash
cargo test -p swap-router --test request_id --locked
cargo test -p swap-router --test swap swap_limits_respected --locked
cargo test -p swap-driver --test authorization --locked
```

These checks verify that request IDs reach terminal events, slippage failures leave the user’s funds unchanged, and unauthorized calls cannot bypass the router/driver/handler chain.

Each request is handled with a gas cap and commit locking. A handled failure can roll back that request without taking down other requests in the processing transaction.



## Bound the queue and processing work



Queue capacity bounds pending storage. Consumption is checked during reservation across concurrent requests. An excluded submission returns to the mempool; it is not guaranteed a place in the next block.

Processing is permissionless and bounded by gas. The driver requires enough budget for the waiting work up to its configured minimum batch. It does not consume a request and then discard it merely because no processing budget remains.

```bash
cargo test -p swap-driver --test admission --locked
cargo test -p swap-driver --test min_batch --locked
cargo test -p swap-driver --test same_block --locked
```

These cases check queue limits, the minimum processing budget, and interactions with withdrawals and allowance changes. The source’s `process_requests_gas` helper supplies the budget calculation; do not copy a gas number from an unrelated operation.



## Remove liquidity

```bash
cargo test -p swap-router --test remove_liquidity --locked
```

The tests verify redemption and the distinction between the LP-token owner and the recipient of the withdrawn tokens. Run the complete native suite before changing the design:

```bash
cargo test -p swap-factory -p swap-router -p swap-driver -p swap-pair --locked
```



## Verify compiled contracts

Build the guest contracts used by the suite:

```bash
thruput build -p erc20
thruput build -p swap-factory
thruput build -p swap-handler
thruput build -p swap-driver
thruput build -p swap-router
cargo test -p swap-driver -p swap-router -p swap-factory --features guest_test --locked
```

`guest_test` runs the scenarios against the compiled RV32 implementations in the SDK test environment. It does not start a browser application or submit to Futurenet.

**Checkpoint:** you have built the AMM and verified pool creation, liquidity, swaps, and failure behavior through native and guest execution. The repository also contains an application under `apps/swap`; this guide focuses on the contract suite.



## Work with an agent

```text
Follow Build an AMM:
https://thruput.network/docs/tutorials/build-an-amm/
Use the existing swap contract suite in thruput-examples. Run pool,
liquidity, swap, slippage, request-ID, authorization, and queue tests.
Build the guest artifacts and rerun with guest_test. Explain how the
assertions establish each outcome. Do not equate request acceptance or
a successful processing transaction with completion of a specific swap.
```

---

## Faucet

Source: <https://thruput.network/tools/faucet/>

Request native test tokens for a Futurenet wallet and check the funding result.

Use the [hosted faucet](https://thruput-faucet.up.railway.app) to fund a Futurenet wallet or contract address with native test tokens. These tokens have no monetary value. The faucet’s interface currently labels them HOG.



## Request funds in the browser

1. Copy your public address from the [Wallet Extension](pages/tools/wallet-extension.md) or your [CLI wallet](pages/cli/wallets.md#create-a-key-and-wallet).
2. Open the [faucet](https://thruput-faucet.up.railway.app).
3. Paste the address into **Wallet address**. Use the full `0x`-prefixed value with 64 hexadecimal characters after `0x`.
4. Click **Request … HOG**, using the amount shown by the button.
5. Wait for **Airdrop confirmed**, then check the receiving wallet’s balance. Use **View transaction** when offered to inspect the result in the explorer.

The faucet needs only a public address. Amounts, cooldowns, and quotas depend on the deployment; follow the values and errors shown by the service.



## Request funds in the wallet

In [Thruput Wallet](pages/tools/wallet-extension.md#select-devnet-and-get-test-hog), select **Devnet** (the wallet extension’s label for Futurenet), open **Assets**, and click **Request test HOG**. The request funds the selected wallet account.



## CLI

With a Futurenet wallet already configured:

```bash
thruput airdrop --profile futurenet
thruput balance --profile futurenet
```

The faucet selects the amount, so omit `--amount` for remote requests. For initial key and wallet setup, follow the [CLI quickstart](pages/get-started/cli.md).

The CLI retains a nonce for a pending remote airdrop. If the outcome is unclear, rerun the same command to resume that request. A timeout does not prove that funding failed.



## TypeScript

Use the client or wallet’s `requestAirdrop` action. [Script accounts](pages/typescript/accounts.md) covers funding and retaining a request nonce for recovery. The client must use a cluster with airdrop support.

For Localnet, use your local node’s airdrop through the [CLI](pages/cli/local-node.md) or SDK rather than the hosted Futurenet faucet.



## If funding does not appear

- Check that the recipient address and wallet network match the request.
- Follow the displayed cooldown before requesting again.
- If you have a transaction hash, inspect it in the [Explorer](pages/tools/block-explorer.md). A committed transaction must also have a successful execution result.
- If the browser lost its connection, check the balance before starting a new request.

---

## Explorer

Source: <https://thruput.network/tools/block-explorer/>

Use the Futurenet explorer to look up transactions, inspect receipts and events, and check address activity.

Use the [Futurenet explorer](https://explorer.thruput.network/) to look up transactions, inspect receipts and events, and check address balances and recent activity. Sign in if prompted.



## Look Up a Transaction or Address

1. Open the [Futurenet explorer](https://explorer.thruput.network/).
2. Paste a transaction hash or address into the search field. Use the full `0x`-prefixed, 32-byte value (64 hexadecimal characters after `0x`).
3. Select **Search**.

The home page also lists recent native-token transfers. Select a transaction to inspect it, or follow an address link to view that address.



### Transactions

The transaction page shows:

- Transaction status and, once committed, block height and execution result.
- Receipt events, including decoded token transfers, mints, and burns where supported.
- Raw receipt data for debugging.

Events without a supported decoder appear as raw topics and data.



### Addresses and Tokens

The address page shows the native-token balance. For non-token addresses, it also shows recent transactions and sent or received native-token transfers. Recognized token contracts show token metadata and token transfer history. Other contracts can show their emitted events.

Address transaction history combines transactions whose root invocation targets the address with native-token transfer activity. It does not cover every nested invocation or every token transfer involving the address.



### Share a Result

Copy the page URL to share a transaction or address:

```text
https://explorer.thruput.network/tx/<transaction-hash>
https://explorer.thruput.network/address/<address>
```



## Inspect State Without an Explorer

Use the CLI for terminal workflows, local nodes, or when the explorer is unavailable:

```bash
thruput balance <wallet-or-address> --profile futurenet
thruput tx show <transaction-hash> --profile futurenet
thruput view <contract-or-alias> <method> --profile futurenet
thruput storage <contract-or-alias> 0x<32-byte-key> --profile futurenet
```

These commands use Futurenet. For a local node, use `--profile local` instead. The hosted explorer does not show your local node’s transactions.

Use the [JSON-RPC API](pages/reference/json-rpc-api.md) directly for receipts, status, address-rooted history, and event pagination.



## If a result is missing

Check the full hash or address and the network that produced it. Indexer-backed history can lag, so use `thruput tx show` for the original transaction before submitting another one. A pending or missing result does not prove failure.

---

## Wallet Extension

Source: <https://thruput.network/tools/wallet-extension/>

Install the wallet for Stellar Thruput in Chrome, create a test wallet, and connect it to a Devnet app.

The Stellar Thruput wallet extension supports Devnet and Localnet. It appears as **Thruput Wallet** in Chrome. The prebuilt download needs no Node.js, Rust, or package-registry access. Use a test wallet for development.

The hosted network is now called Futurenet. The wallet extension and the screenshots below still use the Devnet label.



## Download and extract

[Download Thruput Wallet](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/wallet/f877c655c6778b195a651c61cc8e6f2da055d2bba33f621a9841a76f81fe0c80/thruput-wallet.zip) · [SHA-256 checksum](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/wallet/f877c655c6778b195a651c61cc8e6f2da055d2bba33f621a9841a76f81fe0c80/SHA256SUMS)

Extract the ZIP. The `thruput-wallet` folder contains `manifest.json`, `index.html`, and the extension scripts. Keep that folder in a stable location; Chrome loads the extension from it.



## Load it in Chrome

1. Open `chrome://extensions` in the address bar.
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select the extracted **thruput-wallet** folder, not the ZIP or its parent folder.
5. Open the puzzle-piece menu beside Chrome’s address bar. Find **Thruput Wallet** and click its pin button to keep it in the toolbar.

![Chrome's Extensions page with Developer mode enabled, Load unpacked, and Thruput Wallet enabled](assets/images/wallet/wallet-install.png)

If Chrome cannot find the manifest, select the folder that directly contains `manifest.json`.



## Create a test wallet

Open the wallet from the toolbar. Select **New wallet**, enter and confirm a password of at least 12 characters, then click **Create wallet**. The password unlocks the wallet on this device.

![Thruput Wallet's New wallet screen with password and confirmation fields and the Create wallet button](assets/images/wallet/wallet-create.png)

Follow the prompt to back up your recovery phrase in **Settings**. Keep the phrase private. Use **Restore wallet** if you already have a test recovery phrase you want to use.





## Select Devnet and get native test tokens

Check the network dropdown. New wallets start on **Devnet**; existing wallets keep their saved selection.

Open **Assets** and click **Request test HOG**, the wallet’s label for native test tokens. Wait for the balance to update. These tokens have no monetary value. They fund storage deposits and provide scheduling capacity under load; there are no conventional gas fees.

![Wallet showing the Devnet selector, Assets tab, and Request test HOG button](assets/images/wallet/wallet-devnet.png)

| Network  | RPC endpoint                  | Use                                |
| -------- | ----------------------------- | ---------------------------------- |
| Devnet   | `https://rpc.thruput.network` | Hosted apps and shared development |
| Localnet | `http://127.0.0.1:9545`       | A node running on your computer    |

For local work, [start a local node](pages/cli/local-node.md) before selecting Localnet. Changing networks clears app connections and pending approvals. Reconnect from the app afterward.

You can also copy the wallet’s public address and use the [hosted faucet](pages/tools/faucet.md).



## Connect to an app

1. Open the app and choose its wallet connection action. Select **Thruput Wallet** if it offers a wallet picker.
2. In the approval popup, check the site and choose the account to share.
3. Click **Connect**. The app should display the connected account.
4. For an update, review and approve the separate transaction request in the wallet.

Closing the connection popup cancels that connection request. Connecting an account does not approve future transactions. Use the app’s disconnect control when finished.

Try this with [counter part 4](pages/tutorials/connect-a-wallet-to-your-app.md). To add wallet support to your own app, use the [TypeScript integration](pages/tools/wallet-integration.md) or [React wallet hooks](pages/react/wallets.md).



## Update or build from source

After replacing the extension files, click **Reload** on its card in `chrome://extensions`, then refresh app tabs so they load the current provider.

For a source build, follow the [wallet README](https://github.com/thruputchain/thruput-examples/tree/main/apps/wallet-extension). That path needs repository and package access; load its generated `dist` folder in Chrome.



## If something does not work

| Symptom                                         | Check                                                                                                                                                                     |
| ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| The app does not detect a wallet                | Enable the extension, allow it on the site, and refresh the app tab.                                                                                                      |
| Chrome cannot find the manifest                 | Select the extracted `thruput-wallet` folder, or `dist` for a source build.                                                                                               |
| Wrong network                                   | Select the app’s network in the wallet, then reconnect from the app.                                                                                                      |
| Connection no longer works after a Devnet reset | Select Devnet again to refresh its network identity, then reconnect.                                                                                                      |
| No native test tokens yet                       | Wait for the request to finish and follow any displayed cooldown or error.                                                                                                |
| A transaction has a hash but no result          | Inspect that hash in the [Explorer](pages/tools/block-explorer.md) or with [the CLI](pages/cli/transactions.md#look-up-one-transaction) before submitting another update. |

---

## JSON-RPC API

Source: <https://thruput.network/reference/json-rpc-api/>

Stellar Thruput JSON-RPC methods, wire types, and error codes.

| API property  | Value                                                                                                                                                                                          |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Wire format   | `11.1.0`                                                                                                                                                                                       |
| Compatibility | Breaking wire changes increase the major version of `groundhog_version.wireFormat`                                                                                                             |
| Schema        | [Generated OpenRPC specification](https://github.com/groundhogchain/groundhog-rpc/blob/main/crates/json-rpc/open-rpc-spec/snapshots/groundhog-spec.json) for method signatures and field types |

The Stellar Thruput gateway exposes JSON-RPC 2.0 over HTTP. For its place in the node topology, see [Networking](pages/how-it-works/networking.md).



## Request Format

```json
{
  "jsonrpc": "2.0",
  "method": "groundhog_chainTip",
  "params": [],
  "id": 1
}
```

Public response fields use camelCase. Addresses, hashes, calldata, event topics, and other byte fields use `0x`-prefixed lowercase hex.

| Integer field                                                                                  | JSON representation                                  | TypeScript client representation   |
| ---------------------------------------------------------------------------------------------- | ---------------------------------------------------- | ---------------------------------- |
| 64-bit and wider integers, including heights, nanosecond timestamps, gas, counts, and balances | Canonical decimal string, including `"0"` and `"42"` | `bigint`                           |
| Smaller bounded integers, including protocol versions, page limits, and event sequence numbers | JSON number                                          | Protocol-specific type or `number` |

The wide-integer rule applies to requests, responses, and structured error data. Numeric JSON is rejected for wide fields, even for small values. Strings must fit the field’s signed or unsigned range and must not contain leading zeros, a leading `+`, negative zero, whitespace, fractions, or exponent notation. CLI JSON reports follow the same precision policy. Binary XDR and CXS encodings are unchanged.



## JSON-RPC Arrays

| Property        | Contract                                                                                                                               |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Maximum entries | 1,000 per array on the supported embedded node and standalone gateway                                                                  |
| Correlation     | Match responses by request ID; response order is not execution order                                                                   |
| Errors          | Per-entry RPC errors remain independent; transport failures can affect the shared exchange                                             |
| Guarantees      | No shared snapshot, ordering, or atomicity between independent requests                                                                |
| Other limits    | Request/response byte limits and concurrency settings are separate                                                                     |
| Client defaults | Opt-in HTTP batching uses 100 entries and a 0ms scheduling window; see [client transport](pages/typescript/transport.md#http-batching) |



## Wire Design

Stellar Thruput returns JSON-native objects with typed fields. Transactions use classic XDR; contract arguments and return values use CXS. Clients use the corresponding codecs for those bytes. RPC responses themselves are JSON. See [XDR Protocol](pages/reference/xdr-protocol.md) for the encoding boundary.

Storage reads preserve the protocol value kind:

```json
{
  "blockHeight": "4567",
  "item": {
    "kind": "nonnegativeInt",
    "value": "1000000000"
  }
}
```

Clients switch on tags such as `item.kind` and `status.result`. This avoids reconstructing storage types from packed slots or decoding a universal XDR value for routine reads.

If you are coming from another ecosystem, see [EVM and Solidity](pages/ecosystem/evm.md) or [Stellar and Soroban](pages/ecosystem/stellar.md).



## Methods



### `groundhog_sendRawTransaction`

Submit a signed transaction to the scheduler.

| Parameter | Type   | Description                                       |
| --------- | ------ | ------------------------------------------------- |
| `tx_hex`  | string | `0x`-prefixed XDR encoding of `SignedTransaction` |

**Returns:** `TxHash`, the `0x`-prefixed hash of the inner transaction.

A successful response acknowledges scheduler admission, not commitment or execution. Authentication rejection returns `TX_REJECTED`; retryable admission pressure returns `OVERLOADED`. After a timeout, query the original hash before preparing a replacement.

Transactions whose `blockExpiryHeight` is at or below the current chain tip are rejected when the tip is available.



### `groundhog_getTransactionReceipt`

Get a committed transaction’s execution result and events.

| Parameter | Type     | Description                    |
| --------- | -------- | ------------------------------ |
| `tx_hash` | `TxHash` | `0x`-prefixed transaction hash |

**Returns:** `TransactionReceipt` or `null` if no committed receipt exists.

```json
{
  "txHash": "0x<64 lowercase hex characters>",
  "height": "12345",
  "status": { "result": "ok" },
  "events": [],
  "returnData": "0x42",
  "gasUsed": "1500"
}
```

`returnData` is optional and appears for successful transactions when recorded by the executing chain version. `abortData` is optional and may appear for reverted transactions.

**Execution status values:**

| Status                                           | Meaning                                             |
| ------------------------------------------------ | --------------------------------------------------- |
| `{"result":"ok"}`                                | Root execution succeeded                            |
| `{"result":"reverted","message":"..."}`          | The root call reverted; `message` may be `null`     |
| `{"result":"deterministicError","kind":"fault"}` | The execution engine reported a deterministic fault |
| `{"result":"nonDeterministicError"}`             | Proposal-time storage conflict or race              |
| `{"result":"failedGasSponsorship"}`              | Gas sponsorship failed                              |
| `{"result":"other"}`                             | Unrecognized result from the backend                |

A receipt proves that the transaction committed. Only `status.result: "ok"` proves successful execution.

| Field       | Meaning                                                                                                                                                               |
| ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `gasUsed`   | Consumed root/child execution gas plus pre-execution validation of attached contracts; an unsigned 64-bit decimal string, parsed as `bigint` by the TypeScript client |
| Gas billing | No token fee or unused-gas refund; declared root gas remains the scheduling quantity                                                                                  |



### `groundhog_getTransactionStatus`

Check committed history first, then the scheduler’s retained outcomes when needed.

| Parameter | Type     | Description                    |
| --------- | -------- | ------------------------------ |
| `tx_hash` | `TxHash` | `0x`-prefixed transaction hash |

**Returns:** `TransactionStatus`.

| `status`        | Meaning                                                                                                                                         |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `pending`       | In the scheduler, not committed                                                                                                                 |
| `committed`     | Included in a block; scheduler commitment can omit `height`; indexed commitment includes the actual height as a decimal string, including `"0"` |
| `invalid`       | Rejected; includes `reason`                                                                                                                     |
| `recentFailure` | Recent two-phase-commit conflict; includes `attemptHeight` and `conflict`                                                                       |
| `retry`         | Scheduler processing failed; includes `error`; resubmitting the same signed transaction may succeed                                             |
| `dropped`       | Scheduler processing failed permanently; includes `error`; modify the transaction before resubmitting                                           |
| `unknown`       | Absent from both scheduler and committed history                                                                                                |
| `other`         | Status from a newer server version                                                                                                              |

`recentFailure` is advisory. A later retry of the same transaction may commit. If the scheduler is unavailable and committed history has no record, the gateway returns `BACKEND_UNAVAILABLE` instead of `unknown`.

| Scheduler error field | Contract                                                                                                        |
| --------------------- | --------------------------------------------------------------------------------------------------------------- |
| `error.source`        | `auth`, `scheduler`, `executor`, or `other`                                                                     |
| `error.code`          | Signed 32-bit JSON number from `AuthErrorCode`, `SchedulerErrorCode`, or `ExecResult` for the indicated source  |
| Usage                 | [Handle scheduler processing errors](pages/typescript/transaction-status.md#handle-scheduler-processing-errors) |



### `groundhog_chainTip`

Get the current committed chain tip.

**Parameters:** None.

**Returns:** `{ "height": "42", "blockHash": "0x..." }`. Height is a signed 64-bit decimal string.



### `groundhog_chainConfig`

| Property                    | Contract                                                                                                                                                                                                                                     |
| --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Parameters                  | None                                                                                                                                                                                                                                         |
| Result                      | `ChainConfig`: explicitly stated execution parameters, plus optional authoritative `execution` context                                                                                                                                       |
| Optional integer fields     | `maxSha256Buffers`, `maxCrossInvokeDepth`, `maxNewContractsPerTx`, `maxBytestringLen`, `maxContractSizeBytes`, `maxSavepointDepth`, `maxAuthTokenDepth`, `maxRv32CodeBytes`, `maxRv32MemoryBytes`                                            |
| Integer encoding            | These bounds are `u32` JSON numbers                                                                                                                                                                                                          |
| Missing field               | Unspecified by this config, not zero and not an SDK-selected default                                                                                                                                                                         |
| `execution.observedTip`     | Committed `height` and `blockHash` read together with the rules                                                                                                                                                                              |
| `execution.configHash`      | Configuration and storage-model commitment for that reading                                                                                                                                                                                  |
| `execution.effectiveLimits` | Runtime-resolved limits; omitted fields are unavailable, not zero                                                                                                                                                                            |
| `execution.storageCosts`    | `baseDataItemCost`, `bytestringCostPerByte`, `baseContractDeploymentCost`, `contractDeploymentCostPerByte`, `authPerKeyCost`, `rcqCostPerEntry`, `replayCacheCostPerEntry`, and `balanceCost`, in native-token base units as decimal strings |
| Reading freshness           | `execution` is fetched during the request without stale-cache fallback; later transaction inclusion may use newer rules                                                                                                                      |
| Missing `execution`         | Backend cannot supply authoritative rules; do not infer zero prices from its absence                                                                                                                                                         |
| Usage                       | [Estimate deployment funding](pages/cli/deploy-and-call.md#estimate-deployment-funding)                                                                                                                                                      |



### `groundhog_serverLimits`

| Property                                                                         | Contract                                                                                                                       |
| -------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| Parameters                                                                       | None                                                                                                                           |
| Result                                                                           | Endpoint request limits, returned without contacting a backend                                                                 |
| Scope                                                                            | Operator settings; values can differ between endpoints on the same chain                                                       |
| `maxViewGas`                                                                     | Maximum `view` gas limit and default when `gasLimit` is omitted; `u64` decimal string                                          |
| `maxViewCalldataBytes`                                                           | Maximum view calldata size in bytes; `u64` decimal string                                                                      |
| `maxEventsPerPage`                                                               | Maximum event-query `limit`; `u32` JSON number                                                                                 |
| `maxTransactionsPerPage`                                                         | Maximum address-transaction-query `limit`; `u32` JSON number                                                                   |
| `maxCursorBytes`                                                                 | Maximum pagination cursor size in bytes; `u64` decimal string                                                                  |
| `viewBatch`                                                                      | Optional batch-limit object; omitted when shared-read limits are not advertised                                                |
| `viewBatch.maxCalls`, `viewBatch.maxCalldataBytes`, `viewBatch.maxResponseBytes` | `u32` JSON numbers; the response bound covers encoded backend results, including events, before JSON encoding                  |
| `viewBatch.maxGas`, `viewBatch.timeoutMs`                                        | `u64` decimal strings; aggregate gas budget per attempt and response-wait limit; per-call view and transport limits also apply |
| Consensus limits                                                                 | Reported separately by `groundhog_chainConfig`                                                                                 |



### `groundhog_networkInfo`

Get the network identity used for transaction signing.

**Parameters:** None.

**Returns:**

```json
{
  "networkHash": "0x<64 lowercase hex characters>"
}
```

Clients should compare `networkHash` with the expected network before signing. The hash is part of every transaction signature preimage. See [Authorization](pages/how-it-works/authorization.md).



### `groundhog_requestAirdrop`

Request an idempotent native-token airdrop.

| Parameter             | Type    | Description                                                         |
| --------------------- | ------- | ------------------------------------------------------------------- |
| `request.recipient`   | address | Recipient address as `0x`-prefixed 32-byte hex                      |
| `request.clientNonce` | string  | Caller-selected idempotency nonce as `0x`-prefixed 1-to-32-byte hex |

| Availability               | Contract                                        |
| -------------------------- | ----------------------------------------------- |
| Configured airdrop backend | Method is registered                            |
| No airdrop backend         | Standard JSON-RPC `Method not found` (`-32601`) |

The same recipient and `clientNonce` identify the same logical attempt on a network. Poll a pending attempt by repeating the exact request. Do not generate a new nonce for that attempt.

**Pending response:**

```json
{
  "attemptStatus": "pending",
  "recipient": "0x<64 lowercase hex characters>",
  "rawAmount": "100000000",
  "txHash": "0x<64 lowercase hex characters>",
  "retryAfterSeconds": "5"
}
```

`txHash` is optional while pending.

**Succeeded response:**

```json
{
  "attemptStatus": "succeeded",
  "recipient": "0x<64 lowercase hex characters>",
  "txHash": "0x<64 lowercase hex characters>",
  "rawAmount": "100000000",
  "height": "12345",
  "status": { "result": "ok" }
}
```

`succeeded` means the transaction committed. Inspect `status.result` to confirm execution success. A client timeout does not prove that the airdrop failed. Retry the same request to recover the attempt’s state.



### `groundhog_version`

Get wire, implementation, build, and packaging-platform versions.

**Parameters:** None.

| Response field         | Contract                                                                                      |
| ---------------------- | --------------------------------------------------------------------------------------------- |
| `wireFormat`           | Wire-format SemVer, `"11.1.0"` for this contract; clients may use it for compatibility checks |
| `implementation`       | Diagnostic implementation version                                                             |
| `commitHash`           | Diagnostic build commit or `null`                                                             |
| `platformVersion`      | Optional packaging-platform version, independent of validated release identity                |
| `releaseVersion`       | Present when the binary matches a validated installed release bundle; otherwise omitted       |
| `bundleManifestDigest` | Validated bundle manifest digest; otherwise omitted                                           |



### `groundhog_view`

Execute a read-only contract invocation against committed state. The invocation does not enter the scheduler.

| Parameter            | Type                         | Description                                                                                    |
| -------------------- | ---------------------------- | ---------------------------------------------------------------------------------------------- |
| `request.contract`   | address                      | `0x`-prefixed 32-byte contract address                                                         |
| `request.entrypoint` | bytes                        | `0x`-prefixed 8-byte entrypoint ID                                                             |
| `request.calldata`   | bytes                        | `0x`-prefixed call input                                                                       |
| `request.caller`     | address                      | Optional simulated caller                                                                      |
| `request.gasLimit`   | `u64` decimal string         | Optional positive gas budget, at most `serverLimits.maxViewGas`; omission selects that maximum |
| `request.minHeight`  | signed 64-bit decimal string | Optional nonnegative minimum committed snapshot height; not an exact-height selector           |

| Response field or case     | Contract                                                                                                                           |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| `output`                   | Root output tagged by `result`: `return` with `returnData`, `abort` with `abortData`, or `fault`                                   |
| `events`                   | Events emitted during the simulation                                                                                               |
| `height`                   | Committed snapshot height as a signed 64-bit decimal string; requests cannot select a past height                                  |
| `gasUsed`                  | Required `u64` decimal string for gas consumed by the root and child invocations; equals the selected limit on an out-of-gas fault |
| Invalid gas limit          | Zero or above the endpoint maximum returns invalid params (`-32602`)                                                               |
| Snapshot below `minHeight` | `-32011` with `{ requested, observed }` decimal-string heights; does not wait or request a refresh                                 |
| No view backend            | Returns `-32052`                                                                                                                   |



### `groundhog_viewBatch`

| Parameter           | Contract                                                                                                                             |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `request.calls`     | Nonempty ordered array of independent calls, within the endpoint’s advertised batch limits                                           |
| Each call           | Required `contract`, 8-byte `entrypoint`, and `calldata`; optional `caller` and positive `gasLimit`, encoded as for `groundhog_view` |
| `request.minHeight` | Optional nonnegative signed 64-bit decimal string; freshness applies to the group, never an individual call                          |

| Response field or case                                                 | Contract                                                                                                   |
| ---------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| `height`                                                               | One committed snapshot height as a signed 64-bit decimal string                                            |
| `results`                                                              | Exactly one result per call, in input order; each contains `output`, `events`, and `gasUsed`               |
| `output`                                                               | `return`, `abort`, or `fault`, using the single-view output shape                                          |
| `gasUsed`                                                              | Per-call consumed gas as a `u64` decimal string                                                            |
| Isolation                                                              | All calls read the same snapshot; simulated writes do not pass between calls                               |
| Contract abort or fault                                                | Per-call outcome, not a whole-group RPC failure                                                            |
| Insufficient snapshot height                                           | `-32011` with `{ requested, observed }`; no waiting or request-driven refresh                              |
| Invalid request or exceeded input limits                               | Invalid params (`-32602`)                                                                                  |
| Exhausted snapshot retries, deadline, or malformed/incomplete response | Fail the group rather than return mixed or partial results; backend work can outlive the response deadline |
| Unsupported backend                                                    | `-32052`; a server without the method can return standard `Method not found` (`-32601`)                    |
| Usage                                                                  | [Read related values from one snapshot](pages/typescript/reads.md#read-related-values-from-one-snapshot)   |



### `groundhog_getBalance`

Read the latest committed native-token balance.

| Parameter | Type    | Description                   |
| --------- | ------- | ----------------------------- |
| `address` | address | `0x`-prefixed 32-byte address |

**Returns:**

```json
{
  "address": "0x<64 lowercase hex characters>",
  "rawBalance": "1000000000",
  "height": "4567"
}
```

`rawBalance` is a decimal string in indivisible protocol units.



### `groundhog_getStorageAt`

Read the latest committed storage item at an address and key.

| Parameter | Type    | Description                            |
| --------- | ------- | -------------------------------------- |
| `address` | address | `0x`-prefixed 32-byte contract address |
| `key`     | bytes   | `0x`-prefixed 32-byte storage key      |

**Returns:** `StorageItemRead { blockHeight, item }`. `item` is `null` when the key has no value. `blockHeight` identifies the snapshot used for either result.

`item.kind` is one of `nonnegativeInt`, `bytestring`, `deployedContract`, `authData`, `retrocausalQueue`, `replayCacheEntry`, or `unknown`. Large integer values use decimal strings. `unknown` includes `typeId` for a storage kind added after the client’s wire version.



### `groundhog_getBlockByNumber`

Get block information by height.

| Parameter | Type           | Description                                    |
| --------- | -------------- | ---------------------------------------------- |
| `height`  | decimal string | Signed 64-bit block height, for example `"42"` |

**Returns:** `BlockInfo` or `null`.

```json
{
  "blockHash": "0x...",
  "protocol": 1,
  "networkHash": "0x...",
  "configHash": "0x...",
  "proposer": "0x...",
  "blockTimepoint": "1791200000000000001",
  "blockHeight": "42",
  "txsHash": "0x...",
  "storageHash": "0x...",
  "eventsHash": "0x...",
  "prevBlockHash": "0x...",
  "proposalTxsHash": "0x...",
  "upgrades": ["0x..."]
}
```

> **caution: Not Yet Implemented**
>
> The hosted gateway (`hog-gateway`) has no block query backend yet and returns `-32052` for this method.



### `groundhog_pendingTransactionCount`

Get the number of transactions in the scheduler.

**Parameters:** None.

**Returns:** unsigned 64-bit decimal string, for example `"0"`.

> **caution: Gateway Only**
>
> The hosted gateway (`hog-gateway`) returns `-32052` for this method. `thruput node` serves it for the local chain.



### `groundhog_getEvents`

Query contract events with cursor pagination and topic filters.

| Parameter | Type         | Description                                                                    |
| --------- | ------------ | ------------------------------------------------------------------------------ |
| `query`   | `EventQuery` | Order, anchor, cursor, limit, contract addresses, and positional topic filters |

**Returns:** `EventPage` with events, the next cursor, latest indexed block, and oldest retained block.

| Pagination field                                        | JSON type                    |
| ------------------------------------------------------- | ---------------------------- |
| `anchor.height` for `{"kind":"atHeight","height":"42"}` | Signed 64-bit decimal string |
| `latestBlock`, `oldestBlock`, and event `blockHeight`   | Signed 64-bit decimal string |
| `limit` and event `sequenceNumber`                      | Unsigned 32-bit JSON number  |

`query.filters` uses OR across filters and AND within each filter. Contract-address filters are required. Topic filters are positional: `topic0`, `topic1`, and `topic2`. See [Read events](pages/typescript/events.md#query-events) for typed filters and queries.



### `groundhog_getTransactionsByAddress`

Query transactions whose root invocation targets an address.

| Parameter | Type                      | Description                               |
| --------- | ------------------------- | ----------------------------------------- |
| `query`   | `AddressTransactionQuery` | Address, order, anchor, cursor, and limit |

**Returns:** `TransactionRefPage` with transaction hashes and heights, the next cursor, latest indexed block, and oldest retained block. Hydrate a reference with `groundhog_getTransactionReceipt`.

Anchor heights, reference heights, `latestBlock`, and `oldestBlock` use decimal strings, as in `groundhog_getEvents`.

The initial cursor is `"0x"`. A limit of `0` selects the server default of 50. Values above the configured cap, normally 200, are rejected. Nested calls to the address do not match.



## Pagination Contract

| Field or case                | Rule for event and address-transaction pages                                                                                     |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| Initial cursor               | Send `"0x"`; TypeScript actions use an empty `Uint8Array` or an omitted initial cursor                                           |
| Non-empty cursor             | Continue the same historical walk with the same network, target, and filters                                                     |
| `order` and `anchor`         | Required raw request fields even when the cursor supplies continuation state                                                     |
| Returned `"0x"`              | This walk is exhausted; it does not subscribe to future blocks                                                                   |
| Empty rows, non-empty cursor | Continue; row count alone does not indicate exhaustion                                                                           |
| `latestBlock`                | Indexer’s head at response time, not an application coverage checkpoint                                                          |
| `oldestBlock`                | Retained-history lower bound; detect/report a gap if a checkpoint is older                                                       |
| Event identity               | Transaction hash plus event sequence number, scoped to the network/query                                                         |
| Transaction-ref identity     | Transaction hash; address history matches only root invocation targets                                                           |
| Later ascending scan         | Start a new ascending walk with an empty cursor at the last stored row height from ascending ingestion; deduplicate that block   |
| Descending refresh           | Start a new descending walk with an empty cursor and `atEnd` anchor; the last (oldest) row is not a forward-ingestion checkpoint |
| Persistence                  | Save rows and progress together; never advance past a partially processed block                                                  |
| Invalid filters              | Empty filter lists or empty contract-address lists return invalid params, not all-contract results                               |
| Cursor validity              | Opaque backend format; current malformed-cursor handling can report false exhaustion, so explicit rejection is not guaranteed    |

For the executable application pattern and retention limitations, see [Resume without missing events](pages/typescript/events.md#resume-without-missing-events).



## Error Codes

Standard JSON-RPC 2.0 errors apply. The gateway also defines:

| Code     | Name                    | Meaning                                                                                                       |
| -------- | ----------------------- | ------------------------------------------------------------------------------------------------------------- |
| `-32602` | Invalid params          | Malformed or invalid parameters                                                                               |
| `-32000` | TX_INVALID              | Transaction bytes could not be decoded or validated; resource-limit failures include a typed `data.reason`    |
| `-32001` | TX_REJECTED             | Scheduler or airdrop backend rejected the transaction                                                         |
| `-32002` | TX_NOT_FOUND            | Transaction not found                                                                                         |
| `-32010` | BLOCK_NOT_FOUND         | Block not found at the requested height                                                                       |
| `-32011` | VIEW_HEIGHT_UNAVAILABLE | Selected view snapshot is below `minHeight`; `data` carries `requested` and `observed` decimal-string heights |
| `-32050` | BACKEND_UNAVAILABLE     | Required backend is unavailable                                                                               |
| `-32051` | BACKEND_TIMEOUT         | Backend did not respond before the deadline                                                                   |
| `-32052` | NOT_IMPLEMENTED         | Method is not implemented by the backend                                                                      |
| `-32053` | OVERLOADED              | Gateway or backend is overloaded; retry with backoff                                                          |



## Client Libraries

The `@thruputchain/client` packages provide TypeScript transports, codecs, and higher-level actions. See [TypeScript SDK](pages/tools/typescript-sdk.md).

Rust clients can use `groundhog-json-rpc-client` and its `GroundhogApiClient` trait.



## Related Documentation

- [Networking](pages/how-it-works/networking.md)
- [Authorization](pages/how-it-works/authorization.md)
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)
- [Storage Types](pages/reference/storage-types.md)

---

## Contract Spec

Source: <https://thruput.network/reference/contract-spec/>

Canonical contract metadata, structured identities, methods, types, events, and exceptions.

For usage, see [TypeScript Bindings](pages/tools/typescript-bindings.md) and [Build a Counter](pages/tutorials/build-a-counter.md).



## Where the Spec Lives

| Artifact            | Purpose                                                                                                                  |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| `<crate>.spec.xdr`  | Canonical contract API, consumed by standalone TypeScript codegen                                                        |
| `<crate>.spec.json` | Human-readable rendering for inspection; not the codegen input                                                           |
| `<crate>.rv32a`     | Deployable RV32 artifact                                                                                                 |
| Generation          | SDK macros emit fragments; build canonicalizes, sorts, validates, and writes sidecars under `target/thruput/` by default |



## Top-Level Structure

| JSON key     | Contents                                                          |
| ------------ | ----------------------------------------------------------------- |
| `format`     | `gh_contract_spec_v1`, the inspection-rendering tag               |
| `interfaces` | Exported interfaces, methods, and declared exceptions             |
| `type_defs`  | Reachable named type layouts                                      |
| `events`     | Declared event identities, signatures, topics, and payload fields |



## Structured Identity

| Identity field        | Meaning                                                                                                             |
| --------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `crate`               | Declaring crate in the JSON rendering (`crate_name` in the canonical type)                                          |
| `major`               | Compatibility major, such as `1`, `0.1`, or `0.0.2`                                                                 |
| `module_path`         | Module within that crate                                                                                            |
| `declared`            | Declaration name                                                                                                    |
| Used by               | Named type references, type definitions, and event names                                                            |
| TypeScript projection | Crate, compatibility-major namespace, module path, then declaration; interface methods use interface name and major |

The compatibility major is the leftmost non-zero SemVer component. Use canonical IDs and generated descriptors; short declaration names are not globally unique.



## Interfaces

| Field                | Meaning                                                                           |
| -------------------- | --------------------------------------------------------------------------------- |
| `name`               | Interface name from the trait, inherent self type, or explicit override           |
| `version`            | Full interface version                                                            |
| `throws`             | Declared exception selectors and types                                            |
| `methods`            | Exported methods in canonical order                                               |
| Method `name`        | ABI name                                                                          |
| Method `args`        | Ordered fields with `name` and `type`                                             |
| Method `return_type` | Contract type of the result                                                       |
| Entrypoint ID        | Derived by tooling from interface/version/signature; not an additional JSON field |
| Effect metadata      | The spec does not provide an authoritative read-only/initializer capability flag  |



## Type Encoding

| `kind`                                                     | Other JSON fields    | Meaning                                     |
| ---------------------------------------------------------- | -------------------- | ------------------------------------------- |
| `void`, `bool`, `u8`                                       | None                 | Unit, boolean, or byte                      |
| `u32`, `i32`, `u64`, `i64`, `u128`, `i128`, `u256`, `i256` | None                 | Corresponding integer                       |
| `string`, `bytes`, `address`                               | None                 | String, variable bytes, or contract address |
| `option`                                                   | `inner`              | Optional value                              |
| `vec`                                                      | `element`, `max_len` | Variable-length sequence                    |
| `array`                                                    | `element`, `len`     | Fixed-length sequence                       |
| `tuple`                                                    | `items`              | Ordered element types                       |
| `named`                                                    | `name`               | Structured identity of a named type         |
| `signed_token`                                             | `preimage`           | Payload type, or null when erased           |

Contract arguments, results, and exception payloads use CXS. The spec sidecar uses its canonical XDR encoding. JSON is the inspection projection, not either binary encoding.



## Type Definitions

| Kind                | Fields beyond structured `name`                      |
| ------------------- | ---------------------------------------------------- |
| `struct`            | `fields`, each with name/type                        |
| `enum`              | `variants`, each with name/value                     |
| `union`             | `cases`, each with name, discriminant, and case_type |
| Union case `void`   | No payload                                           |
| Union case `tuple`  | `items`                                              |
| Union case `struct` | `fields`                                             |



## Events

| Field       | Meaning                                                                                        |
| ----------- | ---------------------------------------------------------------------------------------------- |
| `name`      | Structured event identity                                                                      |
| `signature` | 32-byte event signature rendered as hex; topic 0 for derived events                            |
| `topics`    | User topic fields and their types                                                              |
| `fields`    | CXS payload fields and their types                                                             |
| Limits      | At most three topics including signature; 1,024 bytes for topics plus payload                  |
| Discovery   | Events must be declared by the interface or explicitly exported through supported SDK metadata |

Use the generated signature rather than copying a literal from another contract. See [Events](pages/contracts/events.md) for emission and [Read events](pages/typescript/events.md) for filtering and restart.



## Errors

| Field or case        | Meaning                                                                                  |
| -------------------- | ---------------------------------------------------------------------------------------- |
| Exception `selector` | Hex rendering of its 64-bit selector                                                     |
| Exception `type`     | Payload type, potentially a structured named reference                                   |
| Known selector       | Generated decoder interprets the declared payload and rejects trailing bytes             |
| Unknown selector     | Client preserves selector and raw abort bytes                                            |
| Runtime fault        | May have no contract exception payload; do not infer a child ABI from root failure bytes |



## Related Documentation

- [SDK Macros](pages/reference/sdk-macros.md)
- [TypeScript Bindings](pages/tools/typescript-bindings.md)
- [XDR Protocol](pages/reference/xdr-protocol.md)

---

## XDR Protocol

Source: <https://thruput.network/reference/xdr-protocol/>

Encoding boundaries and source definitions for the Stellar Thruput protocol.



## Encodings

| Surface                                                                      | Encoding                                                             | Reference                                                                                                    |
| ---------------------------------------------------------------------------- | -------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `Transaction`, `SignedTransaction`, contract spec sidecars                   | Classic XDR                                                          | Protocol definitions below                                                                                   |
| Contract arguments, return values, exceptions, typed storage, event payloads | CXS, the compact encoding used by the SDK                            | [Contract Spec](pages/reference/contract-spec.md), [TypeScript Bindings](pages/tools/typescript-bindings.md) |
| Transaction signing preimage                                                 | CXS domain separator, raw network hash, then classic XDR transaction | [Authorization](pages/how-it-works/authorization.md)                                                         |
| Public JSON-RPC requests and responses                                       | JSON, with hex byte fields and decimal strings for large integers    | [JSON-RPC API](pages/reference/json-rpc-api.md)                                                              |

The Rust traits retain the names `ReadXDR` and `WriteXDR` for both encodings. Use generated SDK clients and TypeScript bindings for contract payloads; a classic XDR encoder produces different bytes.



## Source Definitions

| Source baseline            | Value                    |
| -------------------------- | ------------------------ |
| Rust protocol package      | `groundhog-xdr` `0.43.0` |
| Embedded protocol revision | `hogp/dc6e80b6472d0ed`   |

| Definition                                                                                                                                      | Types                                                                |
| ----------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| [transaction.x](https://github.com/groundhogchain/protocol/blob/dc6e80b6472d0eda0440eab190c24b20233c839c/transaction.x)                         | `Invocation`, `Transaction`, `SignedTransaction`, invocation outputs |
| [types.x](https://github.com/groundhogchain/protocol/blob/dc6e80b6472d0eda0440eab190c24b20233c839c/types.x)                                     | Addresses, hashes, signatures, protocol scalar types                 |
| [storage_item.x](https://github.com/groundhogchain/protocol/blob/dc6e80b6472d0eda0440eab190c24b20233c839c/storage_item.x)                       | Storage items and deltas                                             |
| [header.x](https://github.com/groundhogchain/protocol/blob/dc6e80b6472d0eda0440eab190c24b20233c839c/header.x)                                   | Proposal header                                                      |
| [consensus.x](https://github.com/groundhogchain/protocol/blob/dc6e80b6472d0eda0440eab190c24b20233c839c/consensus.x)                             | Consensus values                                                     |
| [groundhog_contract_spec.x](https://github.com/groundhogchain/protocol/blob/dc6e80b6472d0eda0440eab190c24b20233c839c/groundhog_contract_spec.x) | Contract types, methods, events, and interface metadata              |

---

## Stellar Thruput

Source: <https://thruput.network/>

Stellar Thruput explores abundant compute through unordered transactions within each block, shared state, and runtime-enforced constraints.



Blockchain technology\
built for abundance
-------------------

Parallel execution. Unordered transactions.\
Shared balances without overspending.\
No conventional gas fees.

## Use a coding agent

```text
Help me deploy and use my first Stellar Thruput counter contract on Futurenet.

1. Install the latest Thruput CLI and run thruput init. Use
   thruput --help to see all available commands. Follow the installation
   instructions at https://thruput.network/docs/cli/install/.
2. Install the thruput skill for this project and coding agent with
   thruput skill install, then read the installed skill.
3. Export the documentation into a new folder with thruput docs export.
   Read its index and the relevant setup and contract instructions.
4. Outside a project, run thruput config use futurenet to select the global
   default. Create a wallet with thruput wallet create, then request test funds
   with thruput airdrop. Verify the balance before deployment.
5. Run thruput new counter --template counter, enter the project directory,
   and check thruput config get still selects futurenet. New projects inherit
   the global default. Build the contract and run its tests.
6. Deploy and initialize the counter to 10. Call increment with 5,
   then verify that its read-only view returns 15.

Finish with the project location, contract address, transaction hashes,
verified counter value, and the CLI commands I can use next.
```

01 / A different starting point



Payments need rules.\
Do they need an order?
----------------------

Stellar Thruput is a moonshot inspired by [Stellar’s mission](https://stellar.org/foundation). It looks a decade ahead, exploring the compute and throughput a globally accessible financial system could need.

Thruput removes transaction order within each block to unlock parallel execution, even across shared balances. Typed storage lets compatible changes combine, while the runtime enforces application constraints and prevents overspending.

Example: Three payments read the same starting balance of 100. Payments of 30 and 40 can land together, leaving 30. Admitting a payment of 50 as well would overspend, so it is excluded. The diagram shows one possible selection.

Blocks still form an ordered history. Within each block, admitted changes combine into the next committed state.

[Explore the execution model](pages/how-it-works/execution-model.md)

Starting balance**100**

Payment &#x41;**−30**Admitted

Payment &#x42;**−40**Admitted

Payment &#x43;**−50**Excluded

Committed balance**30**

One valid outcome: 100 − 30 − 40 = 30

02 / Why Stellar Thruput



## More compute. More throughput.

The bet is that removing transaction order within blocks can unlock far more computation for smart contracts. Developers could build the logic their applications need, instead of keeping contracts small to compete for scarce compute within each block. Work pushed offchain by compute limits could move onchain.

Higher throughput follows from the same design, even across shared state. The aim is a new baseline: if an application makes sense onchain, compute and throughput should not hold it back.



01

### Rules across shared state

A transaction can check its own changes. A capacity constraint can also enforce a shared withdrawal budget across concurrent transactions. The SDK provides storage types for both merge rules and constraints on their combined changes.

[Choose your storage](pages/programming-model/storage-types.md)



02

### No conventional gas fees

Gas meters computation without a token fee or burn. We’re exploring whether a trader on Wall Street and a farmer in Kenya can pay the same transaction fee: zero.

[Understand gas limits](pages/programming-model/execution.md#gas)



03

### Balance-based capacity

Thruput tries to get as much work done as capacity allows, instead of rationing it. Under load, unlocked native-token balances determine each account's share of scheduling capacity over time. A root transaction's declared gas limit determines how much capacity it uses.

[Explore scheduling](pages/how-it-works/storage-economics.md#balance-proportional-scheduling)



04

### Refundable storage deposits

Stored data locks native tokens as a deposit. Delete the data to reclaim that deposit.

[Understand storage deposits](pages/how-it-works/storage-economics.md#storage-refundable-deposits)

03 / Architecture



## One validator. Many machines.

A Thruput validator is itself a distributed system. A high performance RPC system connects scheduling, authentication, and smart-contract execution across machines.

Authentication and smart-contract execution use this model today. Extending it to state is part of the longer-term plan.

Need more execution capacity? Add executor machines. The goal is to make throughput a hardware-sizing question: start with the work your application needs, then size the compute to match.

[Explore the architecture](pages/how-it-works/architecture.md)

One validator

CoordinatorConsensus with other validators

SchedulerDistribute transaction batches

AuthenticationCheck signatures and claims

Internal RPC

Machine 01

**Contract executor** Run contracts in parallel

Machine 02

**Contract executor** Run contracts in parallel

Machine 03

**Contract executor** Run contracts in parallel

Machine 04

**Contract executor** Run contracts in parallel

Machine 05

**Contract executor** Run contracts in parallel

StateShared snapshots and compatible changes



### More machines. More work.

ERC-20 payments / second

**\~3M** payments / sec · 5 machines

1. 700K

   1
2. 1.25M

   2
3. 1.89M

   3
4. 2.42M

   4
5. 2.95M

   5

Machines per validator



Prior ERC-20 execution scaling, normalized to a 700K payments/sec single-machine baseline (64 cores). Multi-machine values are estimates, pending a benchmark rerun.

04 / From contract to application



## Write Rust. Build something you can use.

Create, test, deploy, and inspect contracts with a complete CLI. Generate TypeScript bindings to call them from your application. Give your coding agent the `thruput` skill and local docs to work from the same tools and instructions.

[Build a counter, step by step](pages/tutorials/build-a-counter.md)



### Agent

Agent prompt

```text
Using the thruput skill and local docs,
run thruput new counter --template counter.
Add increment(amount) and decrement(amount) methods
using strict_inc with positive and negative deltas.
Build it and run the native and RV32 tests.
```



### Rust

**src/implementation.rs**

```rust
pub fn increment(&mut self, amount: u64) {
    self.value.strict_inc(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.strict_inc(-(amount as i128));
}
```



### TypeScript

**increment.ts**

```ts
const call = Counter.increment.call({
  contract: counterAddress,
  args: { amount: 5n },
  gasLimit: gasAmount(500_000n),
});

await wallet.executeCallsAndWait({
  calls: [call],
  gasLimit: gasAmount(1_000_000n),
});
```

1. 01

   ### [Create](pages/cli/create-project.md)

   Start a project with the CLI.

2. 02

   ### [Write](pages/contracts.md)

   Define contract logic in Rust.

3. 03

   ### [Test](pages/cli/build-and-test.md)

   Check native and RV32 execution.

4. 04

   ### [Deploy](pages/cli/deploy-and-call.md)

   Fund and initialize on Futurenet.

5. 05

   ### [Connect](pages/typescript.md)

   Call with typed bindings.

[![Stellar](assets/brand/stellar.svg) ![Stellar](assets/brand/stellar-dark.svg) Thruput](pages/index.md)

A blockchain for abundant compute

Technology preview · alpha-pre.1
