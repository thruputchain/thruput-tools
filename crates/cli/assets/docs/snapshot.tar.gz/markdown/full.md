# Groundhog documentation

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Introduction

Source: <https://docs.groundhog.dev/architecture/>

Learn what Groundhog is and how compatible updates let contracts share state.

Groundhog is an L1 blockchain for smart contract applications. You write contract logic in Rust and connect applications through the TypeScript client or React library.

Its central idea is that transactions can update shared state by recording compatible changes. The runtime combines those changes using rules defined by the storage type.



## Record the change

Consider a counter with a value of `100`. Two transactions want to increase it, one by `5` and the other by `3`.

If each transaction replaces the value it read, they propose different results: `105` and `103`. With mergeable integer storage, they record the increases instead:

```text
Starting value:    100
Transaction A:     +5
Transaction B:     +3
Combined value:    108
```

These increases can combine if the rest of the transactions are compatible and network limits permit them. Neither transaction needs to calculate a replacement value that includes the other’s update.

This is useful for shared counters and balances. It does not make every operation independent: replacing a value, enforcing uniqueness, or choosing a winning order can require different rules. Your storage choices determine which changes can combine.

[Parallel Execution](pages/how-it-works/execution-model.md) explains how Groundhog applies these rules. [Storage types](pages/programming-model/storage-types.md) shows how to use them in a contract.



## Build in two layers

**Contracts** define application rules and store onchain state. Use the Rust SDK to write and test them, and the CLI to build, deploy, and inspect them.

**Applications** read contract data and request transactions. The TypeScript client provides network and contract operations. The React library adds wallet connection and balance hooks for interfaces.

You can start with either layer. An application can use an existing contract without implementing one first.



## Where to start

Choose a path in [Get Started](pages/get-started.md) to write code. To explore the platform first, use the [System Overview](pages/how-it-works/architecture.md) as a map, then follow the [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) or read about [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).

---

## Use the CLI in scripts

Source: <https://docs.groundhog.dev/cli/automation/>

Use non-interactive commands and structured output without treating output flags as confirmation.

Use `--non-interactive` to disable questions and terminal UI. It does not authorize state changes. Commands that need confirmation still require their own `--force` flag.



## Set up explicitly

```bash
groundhog init --non-interactive --generate-key
```

`--generate-key` authorizes initial key creation when there are no stored keys or explicit selections. It does not replace an existing key. Use `groundhog new` separately to create a project in a script.



## Request structured output

```bash
groundhog config get devnet --json
groundhog test --json
```

The envelope identifies the command, its `ok` result, warnings, and command data. Payloads carry a command-specific `schemaVersion`; check it before relying on exact fields.

Check the process exit status as well as the envelope. A reported test failure can carry `ok: false` on stdout. Other command failures can emit an error envelope on stderr. Keep the streams separate instead of assuming every failed command produces a successful-data shape on stdout.

With `test --watch --json`, each completed run is a separate JSON record. A long-running `node` or watch command still runs until stopped.



## Confirm intended writes

For a deployment you intend to submit:

```bash
groundhog deploy --profile devnet --fund 10 --non-interactive --force --json
```

For preparation without submission, use `--dry-run` instead. Neither `--quiet` nor `--json` substitutes for confirmation.

---

## Build and test

Source: <https://docs.groundhog.dev/cli/build-and-test/>

Build RV32 artifacts and choose native, artifact, or RPC integration tests.

Run these commands inside a [CLI-generated project](pages/cli/create-project.md) with [Cargo access](pages/cli/install.md#configure-cargo-access) configured.



## Build a deployable artifact

```bash
groundhog build
```

The CLI compiles for RV32 and lowers the result into `target/groundhog/<package>.rv32a`. It also writes lowering metadata and contract-spec sidecars. Artifact names use the package’s snake-case name. See [Project structure](pages/contracts/project-structure.md#build-artifacts).

Plain `cargo build` targets your host. Use it for Rust tooling and IDE checks, not to produce the deployable artifact.

At a workspace root, select a package:

```bash
groundhog build -p my-counter
```

Use `--show-cargo-commands` to inspect the compiler invocation. Arguments after `--` go to Cargo. Keep the scaffold’s compiler and feature configuration instead of recreating the cross-compilation command by hand.



## Choose a test boundary

| Command                        | What it exercises                                                             |
| ------------------------------ | ----------------------------------------------------------------------------- |
| `cargo test`                   | Native contract logic through the SDK test environment                        |
| `groundhog test`               | The built RV32 artifact through `tests/test_rv32.rs`                          |
| `groundhog test --integration` | Artifact build, disposable local node, deployment, and `tests/integration.rs` |

The first two do not require a running RPC node. Integration mode starts and stops its own node; it does not submit transactions to Devnet.

```bash
cargo test
groundhog test
```

For test code, assertions, and storage-cost setup, use [Test contracts](pages/programming-model/testing.md).



## Focus a test run

```bash
groundhog test --match-test counter
groundhog test --skip slow
groundhog test --show-output
groundhog test --no-capture --test-threads 1
```

`--match-test` and `--skip` filter test names. `--show-output` includes output from passing tests; `--no-capture` streams output as tests run.

```bash
groundhog test --rerun
groundhog test --watch
```

`--rerun` uses the previous failure cache. `--watch` runs immediately, then repeats after source or configuration changes. They can be combined.



## Integration and workspace runs

```bash
groundhog test --integration
groundhog test --workspace
```

These are separate modes. `--workspace` runs members with a `test_rv32` target in package-name order. It cannot be combined with `-p` or `--integration`. Integration mode does not support `--watch` or `--rerun`.

The CLI can acquire its selected local runtime for integration tests. See [runtime selection](pages/cli/local-node.md#runtime-selection) for explicit overrides, and [Automation](pages/cli/automation.md) for structured test reports.

---

## Generate TypeScript bindings

Source: <https://docs.groundhog.dev/cli/codegen/>

Generate typed application bindings from a built contract's canonical specification.

Generate bindings from the same contract build you deploy. Bindings provide method descriptors, argument types, result decoders, and declared event and error types.



## Generate during a build

```bash
groundhog build --bindings ts
```

The build prints the generated binding path alongside the contract artifacts. Use `-p PACKAGE` when selecting a workspace member.



## Write bindings into an application

Build first, then select the binary spec sidecar:

```bash
groundhog build
mkdir -p web/src/contracts
groundhog codegen ts target/groundhog/my_counter.spec.xdr \
  --output web/src/contracts/my-counter.ts
```

Replace `my_counter` with your artifact’s name and the output directory with your application’s location. `codegen ts` accepts `.spec.xdr`, not the readable `.spec.json` or the deployable `.rv32a` file.



## Keep code and deployment aligned

Regenerate bindings when the contract interface changes. Use the address from the matching deployment rather than an address copied from another example.

Keep generated files out of manual edits. Put application wrappers next to them so regeneration does not overwrite application logic.

Continue with [Use contract bindings](pages/tools/typescript-bindings.md) for descriptors and typed calls, or [Read events](pages/typescript/events.md) for filters and decoding.

---

## Profiles and networks

Source: <https://docs.groundhog.dev/cli/configuration/>

Select Devnet, local development, or a custom endpoint and manage global and project configuration.

A profile selects the network, endpoint, and account settings for a command. Global profiles are reusable across projects; a project’s `groundhog.toml` can override them.



## Inspect the current settings

```bash
groundhog config profiles
groundhog config get devnet --sources
groundhog status --profile devnet
```

`config get` shows persisted configuration and where it came from. `status` adds environment diagnostics, including the effective key and local-runtime selection. Neither command requests funds or deploys a contract.



## Choose a profile

For one command:

```bash
groundhog balance --profile devnet
```

To make Devnet the default for a project:

```bash
groundhog config use devnet --project
```

Profile selection checks, in order:

1. `--profile`
2. `GROUNDHOG_PROFILE`
3. Project `default_profile`
4. Global `default_profile`

If none selects a profile, commands that require one fail. The name `default` has no special fallback meaning.



## Devnet

`groundhog init` creates the built-in Devnet profile with its RPC and faucet settings. For a first funded account, follow the [CLI quickstart](pages/get-started/cli.md).

The CLI validates the selected network before signing. An explicit `network-hash` pins the network identity. Without a pin, hosted native-account operations use the configured network descriptor and RPC identity. Do not copy a hash from a different deployment; a Devnet reset can change the identity.



## Local development

Profiles with `network = "local"` can use the endpoint and runtime manifest recorded by a running `groundhog node`. See [Run a local node](pages/cli/local-node.md).

For a one-off endpoint override on an RPC command:

```bash
groundhog balance --profile local --rpc-url http://127.0.0.1:9546
```

Commands that use local `dev-N` accounts also need that node’s runtime manifest. Use `--runtime-manifest PATH` when automatic discovery does not apply.



## Global settings and project overrides

| Layer   | Location                          | Purpose                                                   |
| ------- | --------------------------------- | --------------------------------------------------------- |
| Global  | `~/.config/groundhog/config.toml` | Shared profiles, key defaults, and wallet bindings        |
| Project | Nearest ancestor `groundhog.toml` | Project defaults, profile overrides, and contract aliases |

`XDG_CONFIG_HOME` changes the global configuration root. Same-named profiles merge field by field; project values win. Contract aliases and wallet bindings merge by name.

Inside a project, choose `--global` or `--project` when changing configuration. Outside a project, omitted scope means global.

```bash
groundhog config set default-key alice --profile devnet --project
groundhog config unset default-key --profile devnet --project
```

The second command removes the project override and reveals any inherited value. The editable fields are `network`, `rpc-url`, `network-hash`, `faucet-url`, and `default-key`. Use [wallet commands](pages/cli/wallets.md) to select wallets and deployment commands to create contract aliases.



## Add another endpoint

Replace the example URLs with the RPC and faucet for the same deployment:

```bash
groundhog config new staging --network devnet \
  --rpc-url https://rpc.example.com \
  --faucet-url https://faucet.example.com \
  --global
```

Use `config new` to create a profile in a layer before changing its fields there. `config rm staging --global` removes that layer’s profile, including its saved aliases and wallet bindings. It does not delete onchain state.

---

## Create a project

Source: <https://docs.groundhog.dev/cli/create-project/>

Create a contract project and keep its generated compiler, build, and test configuration together.

Use `groundhog new` to create a Rust contract project. If this is your first setup, [install the CLI](pages/cli/install.md) and run `groundhog init` first.



## Choose a template

```bash
groundhog new my-counter
cd my-counter
```

The default `counter` template includes contract methods, an event, an error, and tests. To start with less example logic, use the `stub` template instead:

```bash
groundhog new my-contract --template stub
```

Both templates include the files needed for native tests, RV32 builds, and integration tests. Keep the generated `Cargo.toml`, `rust-toolchain.toml`, and `.cargo/` configuration together. You do not need to select SDK or compiler versions yourself.



## Find the code

- `src/implementation.rs`: contract logic and storage.
- `tests/test.rs`: native logic tests.
- `tests/test_rv32.rs`: artifact tests.
- `tests/integration.rs`: RPC integration test entry point.
- `groundhog.toml`: project profiles and deployment aliases.

See [Project structure](pages/contracts/project-structure.md) for the complete layout and generated artifacts.



## Select a network

The scaffold selects the local profile by default. Use an explicit profile when deploying to Devnet:

```bash
groundhog config get devnet --sources
```

Builds and native/artifact tests run on your machine regardless of the profile. Deployments and calls use its network settings. See [Profiles and networks](pages/cli/configuration.md).



## Work in a Cargo workspace

Keep shared `groundhog.toml`, `.cargo/`, and `rust-toolchain.toml` files at the workspace root. Select a package when building from that root:

```bash
groundhog build -p my-counter
groundhog test -p my-counter
```

---

## Deploy and call

Source: <https://docs.groundhog.dev/cli/deploy-and-call/>

Deploy an artifact, fund its storage, call methods, and read committed state.

Run these commands in a contract project with a built artifact and a funded account. Select the intended [profile](pages/cli/configuration.md) explicitly. The examples use Devnet and the scaffolded counter’s methods.



## Deploy an artifact

```bash
groundhog build
groundhog deploy --profile devnet --fund 10
```

Confirm the deployment. The CLI waits for its result, prints the deployed address, and saves an alias using the package name. For a project named `my-counter`, later commands can use that alias instead of the address.

Native deployment requires an explicit `--fund` amount. It transfers HOG from the sender to the new contract to cover deployment and state storage. `10` is an example allocation, not a fixed fee or minimum.

At a workspace root, use `-p PACKAGE`. Use `--artifact PATH` to select an artifact directly and `--alias NAME` when you want a specific alias.



## Include initialization

For a new deployment that initializes the counter in the same transaction, use this instead:

```bash
groundhog deploy --profile devnet --fund 10 \
  --init initialize --init-arg 10
```

Repeat `--init-arg` for additional arguments. The initializer sees the deploying wallet as its caller. Funding, deployment, and initialization succeed together or roll back together.

Initialization is an ordinary contract method. The contract must enforce one-time initialization when its design requires it. The starter counter simply adds the supplied amount, so do not call it again after initializing this example.



## Submit a call

For a counter that has been deployed and initialized:

```bash
groundhog call my-counter increment 5 --profile devnet
```

This signs and submits a transaction. Method names and typed arguments use the contract spec. Without metadata, an explicit entrypoint and raw calldata are required; use generated metadata for normal development.

Use `--gas-limit` when the call needs a different execution budget. The sender must have the corresponding scheduling capacity; gas itself has no token fee.



## Read without submitting

```bash
groundhog view my-counter get --profile devnet
```

`view` runs a sandboxed call against committed state. It does not submit a transaction. Use `--from ADDRESS` when a read needs a simulated caller; this does not prove control of that address.

`groundhog storage CONTRACT KEY` reads a raw storage item. Prefer a view when you want the contract’s typed behavior.



## Prepare without broadcasting

```bash
groundhog deploy --profile devnet --fund 10 --dry-run
groundhog call my-counter increment 5 --profile devnet --dry-run
```

A dry run prepares and signs a transaction but does not submit it. It still needs the selected key and network access. It is not a simulation of the state change and does not prove that execution will succeed.



## Inspect an uncertain result

Keep the transaction hash and original network if submission or receipt observation fails:

```bash
groundhog tx show TX_HASH --profile devnet
```

A timeout or `unknown` status does not prove that the transaction failed. Repeating a deployment creates a new nonce and predicted address. Inspect the original transaction before deciding to submit a new operation. See [Inspect transactions and events](pages/cli/transactions.md).

---

## CLI

Source: <https://docs.groundhog.dev/cli/>

Install the Groundhog CLI, configure networks, and build, test, deploy, and call contracts.

`groundhog` is the command-line tool for working with Groundhog projects and networks. Use it to create a project, build and test a contract, run a local node, or interact with a deployed contract.



## Projects and networks

The CLI works with two kinds of configuration:

- A **project** contains your Rust contract, tests, and build settings.
- A **profile** selects the network and identity used for an interaction.

This lets you build a contract once and use profiles to target a local node or Devnet. You can also use network commands without creating a contract project.



## The development loop

| Task                        | Command            |
| --------------------------- | ------------------ |
| Create a contract project   | `groundhog new`    |
| Build a contract artifact   | `groundhog build`  |
| Run contract artifact tests | `groundhog test`   |
| Start a local node          | `groundhog node`   |
| Deploy a contract           | `groundhog deploy` |
| Call a deployed contract    | `groundhog call`   |

These are command names, not a setup script. Start with [installation](pages/cli/install.md), then follow the [CLI quickstart](pages/get-started/cli.md) for a first Devnet interaction.

The [contract quickstart](pages/get-started/contract.md) adds deployment and calls. Use [Run a local node](pages/cli/local-node.md) when you want a disposable node on your machine.



## Look up an option

Run `groundhog <command> --help` for the installed version’s options, or use the [command reference](pages/cli/reference.md). [Profiles and networks](pages/cli/configuration.md) explains profile selection and project overrides.

For agent instructions and local documentation, see [Build with an Agent](pages/start/build-with-an-agent.md).

---

## Install the CLI

Source: <https://docs.groundhog.dev/cli/install/>

Install the latest Groundhog CLI and prepare Cargo access for contract development.

Install the latest `groundhog` release. The CLI selects the dependencies and compiler settings for projects it creates; you do not need to choose SDK or node versions.



## Before you start

- Install the current stable Rust toolchain with [rustup](https://rustup.rs/).
- Obtain access to the Groundhog Cargo registry from your onboarding contact. Repository access alone does not grant package access.

Check that Cargo is available:

```bash
cargo --version
```



## Configure Cargo access

Set the registry address and credential provider in your shell:

```bash
export CARGO_REGISTRIES_GROUNDHOG_INDEX="sparse+https://crates.thruput.network/api/v1/crates/"
export CARGO_REGISTRIES_GROUNDHOG_CREDENTIAL_PROVIDER=cargo:token
```

Supply `CARGO_REGISTRIES_GROUNDHOG_TOKEN` through your credential manager or onboarding environment. Keep the token out of project files and agent prompts. If you already use a Cargo credential manager for this registry, keep its provider instead.

Use the same registry access in terminals where you build contracts. The generated project includes the registry address, but it does not include your credentials.



## Install

```bash
cargo install groundhog-cli --registry groundhog --locked
groundhog --version
```

The first command installs the latest CLI with its release’s dependency lockfile. The second should print the installed CLI version.

Cargo installs executables in `~/.cargo/bin`. If `groundhog` is not found, add that directory to your shell’s `PATH` and open a new terminal.

Prebuilt archives for supported macOS and Linux systems are also available on the [latest release page](https://github.com/groundhogchain/groundhog-rpc/releases/latest). Contract builds still require Rust and Cargo registry access.

On Linux, tests or a local node may also require your distribution’s jemalloc and Snappy runtime libraries. If an error names `libjemalloc.so.2` or `libsnappy.so.1`, install the corresponding system package. These are separate from the CLI archive.



## Set up the local runtime

Local nodes and RPC integration tests use `hog-devnode`. The CLI selects a compatible runtime from its bundled catalog and can download it when needed. To inspect available versions and install the selected runtime in advance:

```bash
groundhog toolchain list
groundhog toolchain install
groundhog toolchain which
```

`list` shows the runtime catalog and installed versions. `install` downloads and verifies the selected runtime bundle. `which` shows the selected binary’s path.

These commands manage the local-node runtime. Rust is managed through `rustup`, and the CLI is installed separately as shown above. You do not need a local node to use Devnet.

See [runtime selection](pages/cli/local-node.md#runtime-selection) for version and binary overrides.



## Update an existing installation

Run the same `cargo install` command to install the latest release. Keep the `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml` generated for each project rather than replacing them with files from another example.

If an older executable is still selected, check its location:

```bash
command -v groundhog
groundhog --version
```

---

## Run a local node

Source: <https://docs.groundhog.dev/cli/local-node/>

Start an isolated development chain, select its accounts, and preserve or inspect local state.

Use a local node for disposable development and RPC tests. For a first hosted deployment, follow the [Devnet contract quickstart](pages/get-started/contract.md).



## Start the node

```bash
groundhog node
```

Keep this terminal running. The CLI starts its managed `hog-devnode` and exposes JSON-RPC at `http://127.0.0.1:9545` by default. If the selected runtime is missing, the CLI can download its verified bundle.

The CLI records the active endpoint and runtime manifest so commands using a local profile can find the node.



## Select a local account

From another terminal in your project:

```bash
groundhog config set default-key dev-1 --profile local --project
groundhog balance dev-1 --profile local
```

`dev-0` is the local faucet. Normal bootstrap accounts start at `dev-1`; their keys and initial balances come from the runtime manifest. These deterministic accounts are for local development only.

If the profile already selects a saved wallet, key selection alone does not replace that wallet. Inspect `groundhog status --profile local` and [wallet selection](pages/cli/wallets.md#select-an-account) before submitting.

You can now use the normal [deployment and call commands](pages/cli/deploy-and-call.md) with `--profile local`.



## Preserve state

Without a data directory, stopping the node discards its chain state. Stored signing keys and project configuration remain, but the local deployments and balances do not.

```bash
groundhog node --data-dir .groundhog/node
```

Restart with the same data directory to reuse the chain. Preserve any explicit genesis settings used to create it.

Stop the node before backing up or restoring that directory:

```bash
groundhog chain dump --data-dir .groundhog/node --output chain-backup.json
groundhog chain restore --data-dir .groundhog/node --input chain-backup.json
```

Restore asks before replacing populated state. Use `--force` only when that replacement is intended.



## Change the endpoint or logging

```bash
groundhog node --port 9546
groundhog node --verbose
```

Choose logging before reproducing a problem: restarting an ephemeral node to enable it loses the old state. `RUST_LOG` provides finer control and overrides the verbose preset.

The public listener binds to loopback by default. `--host` changes that listener for container or VM access; exposing it beyond loopback exposes an unauthenticated development RPC endpoint.



## Runtime selection

The CLI selects a default from its bundled runtime catalog. See [local runtime setup](pages/cli/install.md#set-up-the-local-runtime) to inspect and install managed runtimes.

To inspect the effective configuration:

```bash
groundhog status --json
```

An explicit `--hog-devnode-binary`, `GROUNDHOG_DEVNODE_BINARY`, or adjacent binary can take precedence over managed selection. Use `--hog-devnode-version VERSION` when intentionally selecting an exact catalog entry. `--offline` prevents managed downloads, not RPC or Cargo traffic.

If the runtime is incompatible, select matching binaries. `--hogd-protocol` changes a handshake token only; it does not make different wire formats compatible.

For isolated automated runs, prefer [integration tests](pages/cli/build-and-test.md#integration-and-workspace-runs) rather than managing a long-running node yourself.

---

## Command reference

Source: <https://docs.groundhog.dev/cli/reference/>

Groundhog CLI commands, common options, and links to task instructions.





## First-Run Setup

| Command                                           | Purpose                                                                       | Usage                                           |
| ------------------------------------------------- | ----------------------------------------------------------------------------- | ----------------------------------------------- |
| `groundhog --version`                             | Print the installed release                                                   | [Install](pages/cli/install.md)                 |
| `groundhog init`                                  | Initialize profiles and check setup; offer initial key creation interactively | [CLI quickstart](pages/get-started/cli.md)      |
| `groundhog init --non-interactive --generate-key` | Explicitly authorize initial key creation without prompts                     | [Automation](pages/cli/automation.md)           |
| `groundhog status [--profile NAME]`               | Inspect project, key, compiler, and runtime readiness                         | [Troubleshooting](pages/cli/troubleshooting.md) |
| `groundhog new NAME [--template counter\|stub]`   | Create a contract project                                                     | [Create a project](pages/cli/create-project.md) |
| `groundhog completion SHELL`                      | Print shell completions                                                       | `groundhog completion --help`                   |
| `groundhog COMMAND --help`                        | Print the installed command’s options                                         | Available on each command                       |



## Configuration

| Command                                 | Purpose                                             | Usage                                                                         |
| --------------------------------------- | --------------------------------------------------- | ----------------------------------------------------------------------------- |
| `config profiles`                       | List persisted profiles                             | [Profiles and networks](pages/cli/configuration.md)                           |
| `config get [NAME] [--sources]`         | Inspect merged persisted settings and their origins | [Inspect settings](pages/cli/configuration.md#inspect-the-current-settings)   |
| `config new NAME --network NETWORK`     | Create a profile in one layer                       | [Add an endpoint](pages/cli/configuration.md#add-another-endpoint)            |
| `config set FIELD VALUE --profile NAME` | Set one typed field in an existing profile layer    | [Overrides](pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config unset FIELD --profile NAME`     | Remove a field from one layer                       | [Overrides](pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config use NAME`                       | Set the layer’s default profile                     | [Select a profile](pages/cli/configuration.md#choose-a-profile)               |
| `config rm NAME`                        | Remove a profile from one layer                     | Requires confirmation; `--force` for an intended automated removal            |
| `--global` / `--project`                | Choose the layer for a configuration mutation       | Required inside a project; mutually exclusive                                 |



## Keys and Wallets

| Command                                    | Purpose                                              | Usage                                                           |
| ------------------------------------------ | ---------------------------------------------------- | --------------------------------------------------------------- |
| `keys generate [NAME]`                     | Generate a stored Ed25519 key                        | [Keys and wallets](pages/cli/wallets.md)                        |
| `keys import NAME`                         | Import key material through the supported input flow | `groundhog keys import --help`                                  |
| `keys ls` / `keys use NAME`                | List or select a global key                          | [Select an account](pages/cli/wallets.md#select-an-account)     |
| `keys export NAME`                         | Print private key material                           | Intended export only; exclude from logs                         |
| `keys rm NAME`                             | Delete a local key                                   | Requires confirmation                                           |
| `wallet create [--key NAME] [--name NAME]` | Derive and save an empty native account binding      | [Create a wallet](pages/cli/wallets.md#create-a-key-and-wallet) |
| `wallet ls` / `wallet use NAME`            | List or select a profile wallet                      | [Select an account](pages/cli/wallets.md#select-an-account)     |
| `wallet rm NAME`                           | Remove a local binding                               | Does not remove onchain state                                   |
| `balance [TARGET]`                         | Read native HOG balance                              | [Funding](pages/cli/wallets.md#fund-and-transfer)               |
| `airdrop [RECIPIENT]`                      | Request test funding                                 | [Faucet](pages/tools/faucet.md)                                 |
| `transfer RECIPIENT AMOUNT`                | Transfer HOG from the selected account               | [Funding and transfers](pages/cli/wallets.md#fund-and-transfer) |



## Build and Test

| Command or option                        | Purpose                                       | Usage                                                                                |
| ---------------------------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------ |
| `build [-p PACKAGE]`                     | Build a deployable RV32 artifact              | [Build and test](pages/cli/build-and-test.md)                                        |
| `build --bindings ts`                    | Also generate TypeScript bindings             | [Code generation](pages/cli/codegen.md)                                              |
| `build --stack-size SIZE`                | Set guest stack size within configured memory | `groundhog build --help`                                                             |
| `test [-p PACKAGE]`                      | Build and run the RV32 artifact test target   | [Test modes](pages/cli/build-and-test.md#choose-a-test-boundary)                     |
| `test --integration`                     | Run an isolated local-node integration target | [Integration tests](pages/programming-model/testing.md#integration-test-environment) |
| `test --workspace`                       | Run eligible workspace members                | [Workspace runs](pages/cli/build-and-test.md#integration-and-workspace-runs)         |
| `test --match-test TEXT` / `--skip TEXT` | Filter test names                             | [Focused runs](pages/cli/build-and-test.md#focus-a-test-run)                         |
| `test --rerun` / `--watch`               | Repeat failures or watch files                | Not supported with `--integration`                                                   |
| `test --show-output` / `--no-capture`    | Control test output                           | [Focused runs](pages/cli/build-and-test.md#focus-a-test-run)                         |



## Local Node

| Command or option                                         | Purpose                                 | Usage                                                                          |
| --------------------------------------------------------- | --------------------------------------- | ------------------------------------------------------------------------------ |
| `node`                                                    | Start an ephemeral local node           | [Run a local node](pages/cli/local-node.md)                                    |
| `node --data-dir PATH`                                    | Preserve chain state                    | [Persistent state](pages/cli/local-node.md#preserve-state)                     |
| `node --port PORT` / `--host ADDRESS`                     | Configure the public listener           | [Endpoint and logging](pages/cli/local-node.md#change-the-endpoint-or-logging) |
| `node --verbose`                                          | Forward node diagnostics                | [Troubleshooting](pages/cli/troubleshooting.md)                                |
| `node --network-config NAME=VALUE`                        | Override a supported genesis parameter  | Repeatable; preserve settings when reopening a data directory                  |
| `node --dev-account-count N` / `--dev-account-hog AMOUNT` | Configure local-user bootstrap accounts | Does not configure the faucet allocation                                       |
| `toolchain list` / `install` / `which`                    | Inspect or acquire managed runtimes     | [Local runtime setup](pages/cli/install.md#set-up-the-local-runtime)           |
| `toolchain use VERSION` / `clean VERSION`                 | Select or remove a managed version      | `groundhog toolchain --help`                                                   |
| `chain dump --data-dir PATH --output FILE`                | Back up a stopped local chain           | [Persistent state](pages/cli/local-node.md#preserve-state)                     |
| `chain restore --data-dir PATH --input FILE`              | Restore a stopped local chain           | Requires confirmation before replacing populated state                         |



## Deploy and Interact

| Command or option                       | Purpose                                            | Usage                                                                     |
| --------------------------------------- | -------------------------------------------------- | ------------------------------------------------------------------------- |
| `deploy --fund HOG`                     | Deploy and fund a contract from a native account   | [Deploy and call](pages/cli/deploy-and-call.md)                           |
| `deploy --init METHOD --init-arg VALUE` | Initialize atomically with deployment              | [Initialization](pages/cli/deploy-and-call.md#include-initialization)     |
| `deploy --artifact PATH --alias NAME`   | Select an artifact and saved alias                 | [Deployment](pages/cli/deploy-and-call.md#deploy-an-artifact)             |
| `call CONTRACT METHOD [ARGS...]`        | Submit a signed contract invocation                | [Calls](pages/cli/deploy-and-call.md#submit-a-call)                       |
| `view CONTRACT METHOD [ARGS...]`        | Run a sandboxed read without submitting            | [Views](pages/cli/deploy-and-call.md#read-without-submitting)             |
| `storage CONTRACT KEY`                  | Read a raw committed storage item                  | [Views and storage](pages/cli/deploy-and-call.md#read-without-submitting) |
| `--dry-run`                             | Prepare deploy/call transactions without broadcast | Still requires signing context and network access                         |
| `--force`                               | Confirm an intended write without a prompt         | [Automation](pages/cli/automation.md#confirm-intended-writes)             |
| `--profile NAME` / `--rpc-url URL`      | Select configuration or override the endpoint      | [Profiles](pages/cli/configuration.md)                                    |



## Transactions, Events, and Tokens

| Command                         | Purpose                                         | Usage                                                                     |
| ------------------------------- | ----------------------------------------------- | ------------------------------------------------------------------------- |
| `tx show HASH`                  | One public status and receipt lookup            | [Inspect transactions](pages/cli/transactions.md#look-up-one-transaction) |
| `tx list [TARGET]`              | One page of root-invocation history             | [History](pages/cli/transactions.md#list-history)                         |
| `events list CONTRACT`          | One page of raw or spec-decoded contract events | [Events](pages/cli/transactions.md#read-contract-events)                  |
| `token transfers TOKEN`         | One page of token transfer records              | [Token transfers](pages/cli/transactions.md#inspect-token-transfers)      |
| `--limit N` / `--cursor CURSOR` | Control a historical list page                  | [Pagination](pages/cli/transactions.md#continue-a-page)                   |



## TypeScript Bindings

| Command                   | Input/output                                                     | Usage                                                                        |
| ------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `build --bindings ts`     | Contract build plus generated bindings                           | [Generate bindings](pages/cli/codegen.md)                                    |
| `codegen ts SPEC -o FILE` | Canonical `.spec.xdr` to TypeScript; stdout if output is omitted | [Write into an app](pages/cli/codegen.md#write-bindings-into-an-application) |



## Local Documentation

| Command                                             | Purpose                                                                    | Usage                                                                      |
| --------------------------------------------------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| `groundhog skill install [--global] [--agent NAME]` | Install the maintained skill through `npx skills`                          | [Build with an Agent](pages/start/build-with-an-agent.md)                  |
| `groundhog skill update [--global]`                 | Update only the installed Groundhog skill in the selected scope            | Add `--yes --non-interactive` for authorized automation                    |
| `groundhog skill show [TOPIC] [--all]`              | Print the bundled entry, one topic, or the complete guide offline          | `TOPIC` and `--all` are mutually exclusive                                 |
| `groundhog skill list`                              | List the bundled skill topics                                              | [Build with an Agent](pages/start/build-with-an-agent.md)                  |
| `groundhog docs [--port PORT]`                      | Serve the bundled local documentation; port `0` selects an available port  | [Build with an Agent](pages/start/build-with-an-agent.md#2-share-the-docs) |
| `groundhog docs --dir PATH`                         | Serve a trusted local site build                                           | Keep the directory unchanged while serving                                 |
| `groundhog docs --background`                       | Start or reuse the background docs server                                  | `docs status` reports its state; `docs stop` stops it                      |
| `groundhog docs export --output PATH`               | Copy the bundled Markdown docs into a new folder without starting a server | Start at the exported `index.md`; relative links work locally              |



## Shared Flags

| Global flag             | Effect                                                                   |
| ----------------------- | ------------------------------------------------------------------------ |
| `--non-interactive`     | Disable prompts and terminal UI; does not grant confirmation             |
| `--json`                | Emit structured output                                                   |
| `--quiet`               | Suppress status messages                                                 |
| `--show-cargo-commands` | Print Cargo invocations                                                  |
| `--offline`             | Disable managed runtime downloads; does not disable RPC or Cargo traffic |



### JSON output

| Output concern      | Rule                                                        | Usage                                                                  |
| ------------------- | ----------------------------------------------------------- | ---------------------------------------------------------------------- |
| Success and failure | Check exit status and `ok`; command failures may use stderr | [Use the CLI in scripts](pages/cli/automation.md)                      |
| Payload shape       | Check command-specific `data.schemaVersion`                 | [Structured output](pages/cli/automation.md#request-structured-output) |
| Watch mode          | One JSON record per completed test run                      | [Structured output](pages/cli/automation.md#request-structured-output) |

---

## Inspect transactions and events

Source: <https://docs.groundhog.dev/cli/transactions/>

Inspect receipts, address history, contract events, and token transfers from the CLI.

Use the same profile and network that received the transaction. The commands below are read-only.



## Look up one transaction

```bash
groundhog tx show TX_HASH --profile devnet
```

Replace `TX_HASH` with the submitted hash. This performs one status lookup and fetches the receipt when committed; it does not wait for a pending transaction.

Check the receipt’s execution result. A committed failure is different from a transaction that is still pending or excluded from a proposal. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).



## List history

```bash
groundhog tx list my-counter --profile devnet --limit 25
```

History is indexed by root invocation target. A wallet-wrapped call can appear under the wallet rather than the inner target contract. Use the receipt and contract events to inspect inner activity; absence from an address-history page does not prove an operation did not occur.



## Read contract events

```bash
groundhog events list my-counter --profile devnet --limit 25
```

For decoded events, supply the trusted spec from the same contract build:

```bash
groundhog events list my-counter --profile devnet \
  --spec target/groundhog/my_counter.spec.xdr --event PingEvent
```

Use `--topic0`, `--topic1`, or `--topic2` for raw topic filters. Repeated values at one position mean OR; filters across positions mean AND. Use the signature from the generated spec rather than copying one from another contract.



## Inspect token transfers

```bash
groundhog token transfers HOG --profile devnet
```

Use `--account ADDRESS` to restrict the query to an account. Amounts are returned as base-unit values; formatting is separate from the stored amount.



## Continue a page

These list commands return one newest-first page at a time. Pass the returned cursor to the same command with the same target and filters:

```bash
groundhog tx list my-counter --profile devnet --limit 25 --cursor CURSOR
```

Replace `CURSOR` with the exact returned value. An empty page with a non-empty cursor is not the end. The returned cursor `0x` ends that historical walk.

To check for new activity, omit `--cursor` and start at the head again. A saved cursor continues the old walk; it is not a subscription. For forward ingestion and durable checkpoints, use the [event indexing guidance](pages/tutorials/add-events-to-a-contract.md#resume-without-missing-events).

The [Block Explorer](pages/tools/block-explorer.md) provides a browser-based inspection path.

---

## Troubleshooting

Source: <https://docs.groundhog.dev/cli/troubleshooting/>

Diagnose configuration, build, runtime, funding, and transaction-observation problems.

Start with the command’s error and the selected environment:

```bash
groundhog --version
groundhog status --profile devnet
groundhog config get devnet --sources
```

For local work, use `--profile local`. `status` can exit nonzero when it finds warnings; inspect the findings rather than assuming the report itself failed.



## Cargo cannot access packages

Complete [Cargo access setup](pages/cli/install.md#configure-cargo-access) in the terminal running the build. A registry token alone is not enough if Cargo has no credential provider configured. Repository access does not imply registry access.



## The wrong profile or account is selected

An explicit `--profile` wins over `GROUNDHOG_PROFILE`, which wins over project and global defaults. A profile-specific key or selected wallet can also override the global key. Inspect both configuration and `wallet ls --profile NAME` before changing them.

Use [Profiles and networks](pages/cli/configuration.md) and [Keys and wallets](pages/cli/wallets.md) to change the intended layer. Preserve existing keys rather than generating replacements to hide a selection error.



## The local runtime is missing or incompatible

```bash
groundhog toolchain list
groundhog toolchain install
groundhog toolchain which
```

Check for an intentional `GROUNDHOG_DEVNODE_BINARY` override or an adjacent binary. The installed CLI’s catalog chooses a compatible managed runtime. A protocol-token override does not fix a wire-format mismatch. See [runtime selection](pages/cli/local-node.md#runtime-selection).

On Linux, a missing shared-library error identifies the system dependency to install. See [CLI installation](pages/cli/install.md) for runtime-library guidance.



## The node restarted and the deployment disappeared

An ephemeral local node loses chain state on shutdown. Restarting it does not restore the old wallets, balances, or deployments, even when local configuration still has their aliases. Redeploy on the new chain, or use a persistent [data directory](pages/cli/local-node.md#preserve-state).



## Deployment needs funding

Native deployment requires an explicit `--fund` amount. The sender needs funds for the transfer and scheduling capacity; the deployed contract needs funds for its own storage. Inspect the sender with `groundhog balance --profile NAME`, then request appropriate test funding or reduce the operation. See [Deploy and call](pages/cli/deploy-and-call.md).



## Submission timed out or status is unknown

Keep the transaction hash and original network. Run `groundhog tx show TX_HASH --profile NAME` to inspect it. A timeout is not proof of failure. Do not automatically repeat a deployment or sign a replacement call.



## A view or call cannot resolve a method

Use the correct contract alias and the spec from the matching build. Rebuild after interface changes. At a Cargo workspace root, select the package with `-p`. Explicit entrypoint calls require the matching encoded calldata; changing only the entrypoint does not adapt an incompatible interface.



## The integration target is missing

Current CLI projects include `tests/integration.rs` and its activation wiring. Compare an older project with a fresh scaffold before adding them; do not replace its dependency configuration blindly. See [Test contracts](pages/programming-model/testing.md#what-the-scaffold-gives-you).

---

## Keys and wallets

Source: <https://docs.groundhog.dev/cli/wallets/>

Create signing keys, save native wallet bindings, select an account, and request test funds.

A **key** signs transactions. A **wallet binding** gives an account address a reusable name within a profile. Keys are global; bindings can be global or project-local.

For first-time setup, the [CLI quickstart](pages/get-started/cli.md) creates and funds a Devnet account. This page covers account management after that setup.



## Create a key and wallet

```bash
groundhog keys generate alice
groundhog wallet create --key alice --profile devnet
```

Confirm wallet creation. The CLI derives a native account and saves its address, owner, and account nonce. It does not deploy a wallet contract or request funds.

An ordinary stored key can also use its native account without a saved binding. Saving a binding is useful when you want a name for selection and inspection. Existing legacy wallet bindings keep their original account identity and transaction format.



## Inspect accounts

```bash
groundhog keys ls
groundhog wallet ls --profile devnet
groundhog status --profile devnet
```

Keys live under `${XDG_CONFIG_HOME:-$HOME/.config}/groundhog/keys/`. Wallet bindings live in the selected configuration layer. Wallet mutations inside a project update its overlay; outside a project they update global configuration.



## Select an account

```bash
groundhog keys use alice
groundhog wallet use alice --profile devnet
groundhog balance alice --profile devnet
```

A profile’s `default-key` can override the global key. Inspect it with `groundhog config get devnet --sources`. Selecting a key does not replace an explicitly selected wallet belonging to another key; the CLI checks ownership rather than silently switching accounts.

For one deployment or call, use `--wallet NAME`. When targets are omitted from `balance`, `airdrop`, or `tx list`, the CLI resolves the effective account from the selected profile and key.



## Fund and transfer

```bash
groundhog airdrop alice --profile devnet
groundhog balance alice --profile devnet
```

The hosted faucet selects the amount. Local-node requests can use `--amount`:

```bash
groundhog airdrop alice --profile local --amount 25
```

To transfer HOG to another saved wallet or an address:

```bash
groundhog transfer RECIPIENT 1 --profile devnet
```

Replace `RECIPIENT` with the destination. Confirm the transaction and inspect its result. A new recipient needs a sufficient first credit to cover its balance storage; funding amounts depend on the network. See [Faucet](pages/tools/faucet.md) and [storage costs](pages/how-it-works/storage-economics.md).



## Remove local records

`groundhog wallet rm alice --profile devnet` removes the saved binding, not the onchain account. `groundhog keys rm alice` removes the local signing key and asks for confirmation. Keep a key if you still need it to control an account.

`groundhog keys export NAME` prints private key material. Use it only for an intended export, not as a diagnostic or a way to put a signer into browser code.

---

## Generate client bindings

Source: <https://docs.groundhog.dev/contracts/client-bindings/>

Deliver a contract's typed interface to TypeScript application developers.

Client bindings let an application use your contract’s methods, types, errors, and events. Generate them from the contract spec produced by the same build you deploy:

```bash
groundhog build --bindings ts
```

The spec describes the exported interface. Bindings turn that description into TypeScript code for application developers.



## Keep the interface and deployment together

- Regenerate bindings when methods, argument or return types, errors, or events change.
- Give application developers the bindings and the matching deployment address and network.
- Keep generated files separate from application code so regeneration does not overwrite manual changes.

See [Generate TypeScript bindings](pages/cli/codegen.md) for output paths and generation from an existing spec, and [Use contract bindings](pages/tools/typescript-bindings.md) for consuming the generated interface in an application.

---

## Cross-Contract Calls

Source: <https://docs.groundhog.dev/contracts/cross-contract-calls/>

Calling other contracts from your contract.

Use a generated Rust client to call another contract through its interface. Direct calls propagate failures; `try_*` calls let your contract inspect them. These are onchain clients, separate from the TypeScript clients used by applications.



## Client Generation

On a trait definition or inherent impl, `#[contract]` generates a client struct, named `{Interface}Client` unless you override it with `client = CustomName`. The client mirrors every public method on the trait or impl block.

For interface design, see [Methods and interfaces](pages/contracts/methods.md). For macro parameters, see [SDK Macros](pages/reference/sdk-macros.md#contract).

Single error type:

```rust
#[contract(client = ERC20Client, throws = ERC20Error)]
pub trait ERC20 {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount);
    fn get_balance_of(&self, addr: &ContractAddress) -> Amount;
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    fn succeed() -> u32;
    fn throw_alpha_not_found();
    fn throw_beta_denied();
}
```

For each method `foo`, the generated client provides:

| Method         | Signature                            | On error                                                                                                 |
| -------------- | ------------------------------------ | -------------------------------------------------------------------------------------------------------- |
| `foo(...)`     | Same return type as the trait method | Re-throws. Your contract aborts too.                                                                     |
| `try_foo(...)` | `Result<T, CallError>`               | Returns the error for inspection. Match it with `match_exn!`, or decode it with `try_as` / `try_decode`. |



## Making Calls

Construct a client with the target contract’s address, then call methods on it.

```rust
let token = ERC20Client::new(&token_addr);
let balance = token.get_balance_of(&account);
token.transfer(&recipient, 100);
```

Client methods take `&self` (not `&mut self`). Clients are lightweight value types holding an address and configuration.



## Gas Limits

Use `with_gas_limit` to cap how much computation the callee can perform. It returns a new client instance (non-mutating).

```rust
let token = ERC20Client::new(&token_addr);
let capped = token.with_gas_limit(500_000);
capped.transfer(&recipient, 100);
```

The default request is `u64::MAX`; the child is still bounded by the caller’s remaining gas. Use an explicit cap when the callee should receive less. See [Contract Execution](pages/programming-model/execution.md#gas) for details.

| Method                      | Signature                               | Description                                                                                               |
| --------------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `new(address)`              | `fn new(&ContractAddress) -> Self`      | Create a client for the given contract address.                                                           |
| `with_gas_limit(gas_limit)` | `fn with_gas_limit(&self, u64) -> Self` | Return a new client with the specified gas limit.                                                         |
| `with_commit_locking()`     | `fn with_commit_locking(&self) -> Self` | Ask the child frame to acquire its commit locks before returning, so a `try_` call can handle a conflict. |
| `with_read_only()`          | `fn with_read_only(&self) -> Self`      | Prevent the child frame from modifying state.                                                             |

`with_commit_locking()` and `with_read_only()` return a configured copy of the client. They can be combined:

```rust
let result = ERC20Client::new(&token_addr)
    .with_commit_locking()
    .with_read_only()
    .try_get_balance_of(&account);
```

Commit locking performs early conflict detection at the child-frame boundary. If lock acquisition fails, the child reverts and a `try_` method can inspect the failure. Read-only calls may read storage but cannot write, deploy a contract, or perform another state-changing operation.



## Error Handling



### Direct calls (re-throw)

Direct calls propagate errors automatically. If the callee throws, your contract throws the same exception to its own caller. No error handling needed or possible.

```rust
let client = MultiClient::new(&addr);

// If this throws AlphaError::NotFound, your contract
// re-throws the same error to whoever called you.
client.throw_alpha_not_found();
```



### try\_ calls (inspect)

Prefixing any method with `try_` returns a `Result` you can match on. The error type is the SDK’s `CallError`, the same type for every client.

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(()) => { /* success */ }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => { /* handle this error */ }
        _ => e.re_throw(),
    }),
}
```



### CallError

`try_*` does not pre-decode the exception into a per-interface enum. A caught exception stays a `RawException`, and `CallError` describes only how the call failed:

```rust
pub enum CallError {
    Invalid,
    Reentrance,
    DepthExceeded,
    InvokeRejected(SysErr),
    Exception(RawException),
    Fault(FaultInfo),
    UnparseableReturn(FaultString),
    UnparseableAbort(FaultString),
    UnparseableAuthHandles(FaultString),
    EncodingArgs(FaultString),
}
```

| Variant                               | When it appears                                                                                                                                                                                                                                       |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Invalid`                             | The call could not be made (e.g. invalid contract address before the call dispatched).                                                                                                                                                                |
| `Reentrance`                          | The target already had a frame open on the invocation stack, so the runtime refused the call as reentrant. See [`Reentrance`](pages/reference/syscalls.md) in the syscall errors.                                                                     |
| `DepthExceeded`                       | Admitting the call would have exceeded the network’s cross-invoke depth bound. The same call succeeds from a shallower frame.                                                                                                                         |
| `InvokeRejected(SysErr)`              | The invoke syscall was refused for another reason, carrying the raw syscall error.                                                                                                                                                                    |
| `Exception(RawException)`             | The callee threw. Any exception type, declared in `throws` or not, including the SDK’s own `LibraryExn`.                                                                                                                                              |
| `Fault(FaultInfo)`                    | The callee panicked, trapped, or exhausted gas. Child faults carry no diagnostic message across the call boundary. `FaultInfo` exists on every target and is zero-sized without `dev`; only a native root-frame panic can retain harness diagnostics. |
| `UnparseableReturn(FaultString)`      | The callee committed but its return buffer could not be decoded as the expected type.                                                                                                                                                                 |
| `UnparseableAbort(FaultString)`       | The callee aborted but the abort payload could not be parsed.                                                                                                                                                                                         |
| `UnparseableAuthHandles(FaultString)` | The callee committed but the returned auth-token handle list was malformed.                                                                                                                                                                           |
| `EncodingArgs(FaultString)`           | The caller’s arguments could not be encoded before dispatch.                                                                                                                                                                                          |

The first four variants mean the callee never ran: the invoke syscall was refused before any child frame opened, so the call was a complete no-op that observed nothing and wrote nothing. `CallError::is_rejected_before_call()` tests for exactly that set, which is the distinction to reach for when a retry or a fallback is only safe if the callee did not execute.



### Matching exceptions with `match_exn!`

An exception carries a selector derived from its type, independent of any interface’s `throws` list. `match_exn!` matches on that, so errors from different interfaces are peers:

```rust
match client.try_transfer(&recipient, 100) {
    Ok(()) => { /* transfer succeeded */ }
    Err(CallError::Fault(f)) => {
        // The callee panicked
    }
    Err(e) => match_exn!(e, {
        ERC20Error::MustBeContractOwner => {
            // Caller is not the owner
        }
        ERC20PausableError::EnforcedPause => {
            // Declared by an extension the ERC20 interface knows nothing
            // about, matched here exactly like a declared error
        }
        LibraryExn::NonNegativeIntUnderflow => {
            // SDK-level failure inside the callee
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Ok`, `Fault`, `Invalid`, and encode/decode failures with an ordinary `match`. `match_exn!` only does typed downcasting, and its arms are tried in order, so it requires a final `_` arm.

Two rules follow from how the macro infers the type from each arm’s pattern:

- Every typed arm must be path-rooted (`Type::Variant`, `Type::Variant { .. }`, or a unit-struct `Type`). A bare identifier would be a binding, leaving nothing to infer the type from; `_` is the untyped escape hatch, and the error value is still in scope there.
- `|` cannot combine patterns of different exception types. Alternates within one type are fine.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&recipient, 100).unwrap_err().try_as(),
    Some(ERC20Error::MustBeContractOwner),
);
```

`None` covers all three ways this can miss: the failure carried no exception, it carried a different type, or the payload failed to decode.



### Telling a corrupt error from an unknown one

`try_as` returns `None` both for a selector belonging to another type and for a matching selector whose payload will not decode, and `match_exn!` sweeps both into `_`. `try_decode` separates them:

```rust
match client.try_call_something().unwrap_err().try_decode::<SomeKnownError>() {
    Some(Ok(err)) => { /* decoded */ }
    Some(Err(_)) => { /* right selector, payload did not decode */ }
    None => { /* no exception, or a different type */ }
}
```

This matters more than “a callee sent garbage” suggests. An exception’s selector is the first 8 bytes of `sha256(major_version :: crate :: type)` and says nothing about the payload’s layout, so a callee that **adds a variant** to an exception enum makes a semver-compatible change that leaves the selector unchanged, and an older caller cannot decode the result. Through `try_as` that is indistinguishable from an error type the caller has never heard of. If confusing the two would change a decision your contract makes, ask `try_decode`.

The reverse direction is not detectable at all: decoding reads a *prefix*, so a callee that **appends a field** to a struct exception is accepted silently by an older caller, which decodes the shorter shape and drops the extra data.



### Raw inspection

`RawException` also exposes `selector()` and `payload()` for inspecting bytes directly, and `re_throw()` to propagate the original abort verbatim.



## Error Forwarding

When contract A calls contract B with a direct (non-try) call and B throws, the error propagates through A to A’s caller with the original selector and payload intact. This means callers further up the chain can still decode the original error.

```rust
fn forward_alpha(target: ContractAddress) {
    // If target throws AlphaError::NotFound, this contract
    // re-throws it unchanged. Our caller sees AlphaError::NotFound.
    MultiClient::new(&target).throw_alpha_not_found();
}
```



## Full Example

A contract that calls an ERC20 token contract:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

pub use groundhog_erc20_if as erc20_if;

use erc20_if::Amount;
use erc20_if::ERC20Client;
use sdk::storage::Value;
use sdk::*;

#[storage]
pub struct Caller {
    token_contract: Value<ContractAddress>,
}

#[contract(client = CallerClient)]
impl Caller {
    pub fn initialize(&mut self, token_contract: &ContractAddress) {
        self.token_contract.set(token_contract);
    }

    pub fn check_balance(&self, account: &ContractAddress) -> Amount {
        let token = ERC20Client::new(&self.token_contract.get());
        token.get_balance_of(account)
    }
}
```

See [Handle errors](pages/contracts/errors.md) for defining error types with `#[contract_exception]`.

---

## Debug a contract

Source: <https://docs.groundhog.dev/contracts/debugging/>

Isolate failures in native tests, RV32 artifact tests, and submitted transactions.

Start at the boundary that failed. A compiler error, a contract exception, and an uncertain network submission need different checks.



## Reproduce the logic

Use the smallest input that reproduces the problem:

```bash
RUST_BACKTRACE=1 cargo test test_counter -- --nocapture
```

Native tests provide Rust diagnostics and work with host debugging tools. Use generated `try_*` client methods to assert on expected errors.

Once the logic passes, run `groundhog test` to check the RV32 artifact. A passing host test does not replace the artifact test.



## Inspect the build or artifact test

```bash
groundhog --show-cargo-commands build
groundhog test --match-test counter --show-output
```

Confirm the package, toolchain, and features. In a workspace, use `-p PACKAGE`. See [Build and test](pages/cli/build-and-test.md).



## Classify a deployed failure

| Observation            | Next check                                                                           |
| ---------------------- | ------------------------------------------------------------------------------------ |
| Submission rejected    | Inspect the signing account, profile, network identity, and reported admission error |
| Committed exception    | Decode the typed error; check input and authorization conditions                     |
| Committed fault        | Reproduce in tests; inspect execution limits and panics                              |
| Pending or unknown     | Observe the original transaction on the same network                                 |
| Unexpected view result | Check address, interface/spec, read height, and simulated caller                     |

```bash
groundhog tx show TX_HASH --profile devnet
```

See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish) for outcomes and [CLI troubleshooting](pages/cli/troubleshooting.md) for configuration checks.



## Reproduce through RPC

Start a local node with `groundhog node --verbose` and retain its logs while reproducing the problem. CLI transaction inspection shows public status and receipt data, not a full execution trace.

For repeatable build, deployment, and RPC checks, use `groundhog test --integration` and add contract-specific assertions to the generated test.

---

## Handle errors

Source: <https://docs.groundhog.dev/contracts/errors/>

How errors work in Groundhog contracts.

Exported Groundhog contract methods return their declared values and signal failure by throwing an exception. The frame aborts, all state changes in that frame are discarded, and control returns to the caller. Private helpers may use `Result` when they translate failures into a contract or library exception.

You cannot catch a thrown exception within the same frame. Use `Result`-returning helpers for local fallible work and generated `try_*` client methods for another contract. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md).

For exact SDK signatures, see [Rust API Docs](pages/tools/rust-api-docs.md).



## Defining Errors

Use `#[contract_exception]` to define error types. It generates `Debug`, `PartialEq`, serialization and spec traits, and the `Exn` implementation. Add `Clone` yourself if the type needs it.



### `thiserror` and `anyhow`

You can use `thiserror` with `#[contract_exception]` when you want `Display` messages for logs, tests, or off-chain tooling. Put `#[derive(thiserror::Error)]` on the exception type and use `#[error("...")]` on each variant:

```rust
use sdk::*;

#[derive(thiserror::Error)]
#[contract_exception]
pub enum CounterError {
    #[error("not authorized")]
    NotAuthorized = 1,
}
```

Do not copy the usual `#[derive(Error, Debug)]` pattern from generic Rust examples. `#[contract_exception]` already generates `Debug` and `PartialEq`; deriving them again creates duplicate implementations.

For contract crates, configure `thiserror` without the default `std` feature:

```toml
thiserror = { version = "2", default-features = false }
```

Avoid `anyhow` for contract exception types and public contract method surfaces. `anyhow::Error` is an erased application error type, while contract exceptions need concrete CXS-serializable types that appear in the contract spec. `anyhow` is fine in off-chain tools, build scripts, tests, or CLI code. Inside a contract, private helpers may use `Result` if they immediately convert failures into concrete contract exceptions with `throw`, `ensure`, or `or_throw`.



### Enum errors

Enum errors carry variant-level meaning. Each variant gets an explicit `i32` discriminant. The macro adds `#[repr(i32)]` for you.

```rust
use sdk::*;

#[contract_exception]
pub enum ERC20Error {
    AlreadyInitialized = 1,
    MustBeContractOwner = 2,
    TooLarge = 3,
    Internal = 100,
}
```



### Struct errors

Struct errors work when you only need a single error type with no variants.

```rust
use sdk::*;

#[contract_exception]
pub struct Unauthorized;
```

Structs with fields work too:

```rust
#[contract_exception]
pub struct InsufficientBalance {
    pub balance: u64,
}
```



## Throwing Errors



### `throw(exn)`

Aborts the current frame with the given error. Never returns.

```rust
use sdk::*;

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    if amount == 0 {
        throw(ERC20Error::TooLarge);
    }
    // ...
}
```



### `ensure(condition, error)`

Throws `error` if `condition` is false. A convenience wrapper around `throw`.

```rust
use sdk::*;

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    ensure(
        caller == self._contract_owner(),
        ERC20Error::MustBeContractOwner,
    );

    let diff = amount_to_diff(amount);
    self._adjust_balance(receiver, diff);
    self._adjust_total_supply(diff);
}
```



### `result.or_throw(exn)`

Extension method on `Result`. Returns the `Ok` value, or throws `exn` on `Err`. Useful for converting fallible operations into contract exceptions.

```rust
use sdk::*;

pub fn amount_to_diff(n: u128) -> i128 {
    n.try_into().or_throw(ERC20Error::TooLarge)
}
```



## Automatic Aborts

The SDK throws `LibraryExn` errors automatically when internal preconditions fail. You do not need to define error variants for these.

| Operation                                 | Throws when                                                                                         |
| ----------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `strict_inc(delta)`                       | Result would be negative (`NonNegativeIntUnderflow`)                                                |
| `strict_inc(delta)`                       | Result would overflow (`NonNegativeIntOverflow`)                                                    |
| `Balance::decrease(amount)`               | Balance is insufficient (`NonNegativeIntUnderflow`)                                                 |
| `Balance::increase(amount)`               | Balance would overflow (`NonNegativeIntOverflow`)                                                   |
| `CapacityConstraint::set_capacity(value)` | Another non-idempotent write already occurred this transaction (`CapacityConstraintAlreadyWritten`) |
| `bytestring_get_sized`                    | Stored length does not match expected (`BytestringWrongSize`)                                       |
| Storage read                              | Key does not exist (syscall error)                                                                  |

```rust
// Aborts automatically if balance would go below zero.
// No error handling code needed.
balance.decrease(amount);
```

Every public SDK function whose name starts with `try_` reports its own failures through `Option` or `Result` instead of aborting. Storage `try_` getters return `Result<T, LibraryExn>`. Use `error.is_storage_missing()` to identify absence, or `.none_if_missing()` to convert only absence into `None` while re-throwing other failures.



## LibraryExn

`LibraryExn` is the SDK’s built-in error enum. It covers all errors generated by SDK internals and runtime operations.

| Variant                                              | Discriminant | Trigger                                                                                                                                                                                                 |
| ---------------------------------------------------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Syscall(SyscallExn)`                                | 0            | A host syscall returned an error (e.g. storage key not found)                                                                                                                                           |
| `Handling(HandlingError)`                            | 1            | Error while handling an incoming contract call (decoding args, encoding result)                                                                                                                         |
| `Calling(CallingError)`                              | 2            | Error while making an outgoing contract call: encoding args, decoding the result, or the runtime refusing the invoke as reentrant (`Reentrance`) or past the cross-invoke depth bound (`DepthExceeded`) |
| `Called(FaultString)`                                | 3            | The called contract reverted                                                                                                                                                                            |
| `AuthToken(AuthTokenError)`                          | 4            | Error encoding or consuming an authorization token                                                                                                                                                      |
| `BytestringWrongSize { expected, found }`            | 5            | A fixed-size bytestring read found a different length                                                                                                                                                   |
| `NonNegativeIntUnderflow`                            | 6            | An integer or balance operation would violate its lower bound                                                                                                                                           |
| `NonNegativeIntOverflow`                             | 7            | An integer or balance operation would overflow                                                                                                                                                          |
| `StorageSerialization`                               | 8            | A typed storage value could not be serialized or deserialized                                                                                                                                           |
| `StorageIndexOutOfBounds { len, access }`            | 9            | A vector index was outside its logical extent                                                                                                                                                           |
| `StorageKeypathOverflow`                             | 10           | A no-allocation storage keypath exceeded its fixed budget                                                                                                                                               |
| `RetrocausalQueueEntryWrongSize { expected, found }` | 11           | A fixed-size queue read found a different entry length                                                                                                                                                  |
| `CapacityConstraintAlreadyWritten`                   | 12           | `set_capacity` followed an incompatible write in the same transaction                                                                                                                                   |
| `UnknownMethod`                                      | 13           | The callee has no entrypoint for the invoked method ID                                                                                                                                                  |

`LibraryExn` is `#[non_exhaustive]`: when matching, always include a wildcard arm.

When calling another contract via a `try_*` method, `LibraryExn` is caught like any other exception type:

```rust
match client.try_do_something() {
    Err(e) => match_exn!(e, {
        LibraryExn::NonNegativeIntUnderflow => {
            // The called contract underflowed an NNInt
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```



## Cross-Contract Errors

A thrown exception travels as `[selector][payload]`, where the selector is derived from the exception *type*, not from the interface that threw it. Callers match on that selector, so what a caller can catch does not depend on what the callee’s interface declared.

`throws` declares an interface’s error contract: it is published in the contract spec and tells callers what to expect. It does not gate catching.



### Declaring thrown errors

Single error type:

```rust
#[contract(client = CounterClient, throws = CounterError)]
impl Counter {
    // ...
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    // ...
}
```



### Catching errors with `try_*` methods

Every method on the generated client has a `try_` variant returning `Result<T, CallError>` instead of aborting. `CallError` is the same type for every client; a caught exception stays undecoded inside it, and `match_exn!` decodes it against the types you name:

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(val) => {
        // Success
    }
    Err(CallError::Fault(f)) => {
        // The called contract panicked
    }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => {
            // Handle the expected error
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Fault`, `Invalid`, and encode/decode failures with ordinary `match` arms on `CallError`. `match_exn!` handles only the typed part, and its arms are tried in order, so a final `_` arm is required.



### Library errors

`LibraryExn` is matched like any other exception type. There is no special wrapper variant:

```rust
match client.try_do_something() {
    Err(e) => match_exn!(e, {
        LibraryExn::NonNegativeIntUnderflow => {
            // The called contract underflowed an NNInt
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```



### Non-try calls and re-throwing

Non-try client methods (e.g. `client.do_something()` without the `try_` prefix) automatically re-throw any exception from the called contract. The error propagates through the call chain with its original selector intact.



### Undeclared errors

An error type absent from `throws` is caught exactly like a declared one. The selector identifies it either way:

```rust
match client.try_throw_undeclared() {
    Err(e) => match_exn!(e, {
        SecretError => {
            // Never declared by the interface; matched all the same
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```

This is what lets an extension define errors the base interface does not declare. `ERC20PausableError::EnforcedPause` can come back from `ERC20::transfer`, and an `ERC20Client` caller matches it in the same `match_exn!` as `ERC20Error`, no separate decode step, and no coupling of the base interface to the extension.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&to, 1).unwrap_err().try_as(),
    Some(ERC20PausableError::EnforcedPause),
);
```

`None` covers all three ways this can miss: no exception, a different type, or a payload that failed to decode. Use `try_decode` when the last of those must be distinguished from the other two. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one), which also explains how this can occur through semver-compatible evolution.

See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) for the full calling patterns.

---

## Events

Source: <https://docs.groundhog.dev/contracts/events/>

Define, declare, emit, and test typed events in a Rust contract.

Events expose contract activity to applications. A contract emits topics for filtering and a payload for the data consumers need to read. Use storage for state your contract must read later; contracts cannot read events back.



## Define an event

```rust
use sdk::*;

#[derive(Event, Clone, Debug)]
pub struct CounterIncremented {
    #[topic]
    pub by: ContractAddress,
    pub amount: u64,
}
```

`#[derive(Event)]` generates the event signature, topic encoding, and a payload type. Topic 0 is the signature. Up to two fields can use `#[topic]`; fields without it go into the CXS-encoded payload.

Here, consumers can filter on `by` and read `amount` from the payload. Strings and byte slices used as topics retain only a hash, so also include them in the payload if consumers need their original values. The total size of topics and payload is limited to 1,024 bytes.



## Declare and emit it

This self-contained contract records an increment and emits its amount and caller:

```rust
use sdk::storage::NNInt;

#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}

#[contract(emits(CounterIncremented))]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
        log_event(&CounterIncremented {
            by: get_caller(),
            amount,
        });
    }
}
```

`get_caller()` identifies the immediate caller of this frame. For a forwarded call, that is the forwarding contract.

`emits(...)` records the event in the contract spec. Put it on the inherent implementation or interface trait definition, not on a trait implementation. When adding an event to an existing contract, retain its other event and error declarations.



## Test an emitted event

Export the event alongside the generated client from your contract library. In a native test, call `increment` and inspect the returned `TransactResult`:

```rust
let result = env.transact(|tx| {
    tx.call(&caller).run(|| {
        CounterClient::new(&address).increment(5);
    })
});
result.assert_success();
result.assert_event_count(1);
result.assert_event::<CounterIncremented>(0, |event| {
    assert_eq!(event.topic(0), Some(CounterIncremented::SIGNATURE));
    let by: &ContractAddress = event.topic(1).unwrap().into();
    assert_eq!(by, &caller);
    assert_eq!(event.payload().amount, 5);
});
```

Here, `env` is the test environment, `caller` is the calling address, and `address` is the deployed test contract. See [Testing](pages/programming-model/testing.md#basic-pattern) for registration and deployment setup.

The event count covers all contracts called by the test transaction. Assert both topics and payload so the test checks the event’s content, not only its presence.



## Include the event in the interface

Rebuild after changing an event declaration. The generated spec records its name, signature, topic layout, and payload layout. [Client bindings](pages/contracts/client-bindings.md) use that metadata to expose the event to applications.

For library-emitted events that no interface declares, `#[event_spec(export)]` explicitly includes the type in the linked contract’s spec. See the [event macro reference](pages/reference/sdk-macros.md#deriveevent) for the generated API.

The [event walkthrough](pages/tutorials/add-events-to-a-contract.md) follows the complete path from a counter contract to application queries.

---

## Smart Contracts

Source: <https://docs.groundhog.dev/contracts/>

Write, test, and understand Groundhog contracts with the Rust SDK.

Build contract logic with the Rust SDK. Use this section for storage choices, authorization, events, testing, and the contract programming model.



## Write your first contract

Follow the [contract quickstart](pages/get-started/contract.md) to deploy a counter on Devnet. Then read [Build a Counter](pages/tutorials/build-a-counter.md) to understand its code and tests, or [Project structure](pages/contracts/project-structure.md) to find the generated files.

Use the [CLI section](pages/cli.md) for build and deployment commands.



## Work on a contract

- [Define methods and interfaces](pages/contracts/methods.md).
- [Choose storage types](pages/programming-model/storage-types.md) for your data.
- [Authorize calls](pages/how-it-works/authorization.md).
- [Define and handle errors](pages/contracts/errors.md).
- [Emit and test events](pages/contracts/events.md).
- [Call another contract](pages/contracts/cross-contract-calls.md).
- [Choose a test mode and write tests](pages/programming-model/testing.md).
- [Debug a contract](pages/contracts/debugging.md).
- [Generate client bindings](pages/contracts/client-bindings.md) for application developers.



## Understand the programming model

Read [execution](pages/programming-model/execution.md) for how contract state changes are applied. Continue with [NNInt and concurrent updates](pages/programming-model/nnint.md), [exclusive writes](pages/programming-model/storage-types.md#exclusive-writes), or [invocation frames](pages/how-it-works/invocation-frames.md) when your design needs that detail.

Read [Contract artifacts and addresses](pages/how-it-works/contracts.md) to understand code hashes, deployment addresses, and immutability.



## Look up an API

Use the [storage API tables](pages/reference/storage-types.md), [SDK macros](pages/reference/sdk-macros.md), [syscalls](pages/reference/syscalls.md), and [generated Rust API docs](pages/tools/rust-api-docs.md).

For larger worked examples, visit [Guides](pages/guides.md).

---

## Methods and interfaces

Source: <https://docs.groundhog.dev/contracts/methods/>

Define contract state, expose methods, and share typed interfaces with Rust callers.

Start with a [generated project](pages/cli/create-project.md) so its host tests and RV32 entrypoint are configured.



## Define state and behavior

```rust
use sdk::storage::NNInt;
use sdk::*;

#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}

#[contract]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.try_get().none_if_missing().unwrap_or(0)
    }
}
```

`#[sdk::storage]` assigns each field a storage path. The field is a handle to persisted data, not an in-memory integer that you must save manually. `#[contract]` generates entrypoints, a `CounterClient`, and interface metadata.

`none_if_missing()` gives the never-written counter a zero default while preserving other storage errors. Do not turn every read error into zero with `unwrap_or(0)` on the original `Result`.



## Expose methods

Public methods on an inherent implementation become entrypoints. Private helper methods stay internal. Use `&mut self` to update through mutable storage handles and `&self` to read through shared handles. A method without a receiver does not need the generated storage struct.

Rust receiver mutability is separate from runtime call restrictions. Use [read-only child calls](pages/contracts/cross-contract-calls.md#gas-limits) when the runtime must reject state changes.

Exported methods return their normal values. Use [contract exceptions](pages/contracts/errors.md) for failures.



## Share an interface

Put a trait in a shared interface crate when callers need the interface without importing its implementation:

```rust
use sdk::*;

#[contract]
pub trait CounterApi {
    fn increment(&mut self, amount: u64);
    fn get(&self) -> i128;
}
```

This generates `CounterApiClient`. Mark the trait implementation with `#[contract]` too. Declare `throws` and `emits` on the trait definition, not again on its implementation.

For a self-contained contract, the inherent implementation in the first example is enough. The [macro reference](pages/reference/sdk-macros.md#contract) lists parameters and reserved method names.



## Define argument and return types

```rust
#[contract_type]
pub struct CounterSummary {
    pub value: i128,
    pub owner: ContractAddress,
}
```

`#[contract_type]` supplies serialization and spec metadata. Use `Value<T>` when plain data must persist; choose other [storage types](pages/programming-model/storage-types.md) for other update patterns.



## Initialize and generate bindings

Initialization is an ordinary method, not an automatic constructor. Enforce one-time initialization when required and [initialize atomically with deployment](pages/cli/deploy-and-call.md#include-initialization).

Rust callers use generated clients. [Generate client bindings](pages/contracts/client-bindings.md) to share the built contract interface with TypeScript applications. Keep bindings and deployment addresses from the same interface build.

---

## Project structure

Source: <https://docs.groundhog.dev/contracts/project-structure/>

Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.

`groundhog new` creates a Cargo project with a contract, tests, compiler settings, and CLI configuration. Keep its generated dependency versions and toolchain together.



## Generated files

```text
my-counter/
  Cargo.toml              # Package, SDK dependencies, and build features
  AGENTS.md               # Instructions for coding agents
  build.rs                # Integration-test setup
  groundhog.toml          # Project profiles and contract aliases
  rust-toolchain.toml     # Selected compiler and targets
  .cargo/
    config.toml           # Registry and Cargo configuration
    contract.toml         # Contract-build configuration
  src/
    lib.rs                # Library modules
    implementation.rs     # Contract logic, storage, errors, and events
    main.rs               # Contract entrypoint wrapper
  tests/
    test.rs               # Native logic tests
    test_rv32.rs          # Contract artifact tests
    integration.rs        # Tests against a running node
```

The `.gitignore` excludes build output and project-local runtime state.



## Build artifacts

`groundhog build` compiles the entrypoint for RV32, Groundhog’s 32-bit RISC-V contract target. It lowers the compiler output into an artifact the node can execute.

For `my-counter`, the output under `target/groundhog/` includes:

- `my_counter.rv32a`: deployable contract artifact.
- `my_counter.rv32.json`: lowering metadata.
- `my_counter.spec.xdr`: binary contract specification.
- `my_counter.spec.json`: readable contract specification.

The specification describes the contract interface and supports [TypeScript binding generation](pages/tools/typescript-bindings.md).



## Test modes

- `cargo test` runs the native contract tests.
- `groundhog test` runs the RV32 artifact tests.
- `groundhog test --integration` manages a local node for the integration tests.

See [Testing](pages/programming-model/testing.md) for the execution modes, generated integration environment, and how to add assertions.



## SDK layers

Generated projects start with the SDK’s contract and storage macros. Use typed storage handles for normal state access. Lower-level syscall wrappers are available when you need a custom abstraction.

These layers can be combined within a contract. Use [Storage Types](pages/programming-model/storage-types.md) to choose an API, [SDK Macros](pages/reference/sdk-macros.md) for macro reference, and [Rust API Docs](pages/tools/rust-api-docs.md) for exact signatures.

---

## EVM & Solidity

Source: <https://docs.groundhog.dev/ecosystem/evm/>

Groundhog concepts for Solidity and EVM developers.

This guide is for developers who know Solidity and the EVM. It uses familiar EVM concepts to compare Groundhog’s storage and execution rules.

For the foundational concepts (delta operations, commutativity, storage types), see [For Blockchain Developers](pages/start/for-blockchain-developers.md). This page builds on that with concrete patterns and a worked example.



## The Contract Lifecycle

If you’ve deployed and called contracts on Ethereum, the Groundhog lifecycle will feel familiar. The mechanics differ, but the shape is the same: write a contract, compile it, deploy it, call functions on it.



### Writing

Groundhog contracts are written in Rust and compiled to RV32 artifacts by default, not EVM bytecode. RV32 is Groundhog’s 32-bit RISC-V contract target. The SDK provides optional convenience macros, but you can also work directly with raw syscalls. A minimal contract looks like this:

```rust
use sdk::*;
use sdk::storage::NNInt;

#[contract_exception]
pub enum Error {
    NotAuthorized = 1,
}

#[derive(Debug)]
#[sdk::storage]
pub struct MyContract {
    value: NNInt,
}

#[contract(throws = Error)]
impl MyContract {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.try_get().none_if_missing().unwrap_or(0)
    }
}
```

Where Solidity uses `constructor()`, Groundhog contracts commonly expose an ordinary `initialize` method. Deployment does not call it automatically or enforce that it runs once, so the contract must guard one-time initialization when that matters. Where Solidity uses `uint256` state variables, Groundhog uses typed storage fields (`Balance`, `NNInt`, `Map<K, V>`, `Bytestring`). The type you choose determines how concurrent writes merge. This is the core difference: storage types enforce parallelism rules, not the developer.



### Compiling

Solidity compiles to EVM bytecode. Groundhog contracts compile to RV32, a 32-bit RISC-V target, by default:

```bash
groundhog build
```

The output is a `.rv32a` artifact plus [contract spec](pages/reference/contract-spec.md) sidecars, analogous to Solidity’s bytecode + ABI.



### Deploying

On Ethereum, you send a transaction containing bytecode, the EVM executes the constructor, and you get an address back. On Groundhog, deployment submits the contract artifact and creates a contract instance with a nonce:

1. **Include the RV32 artifact** in the deploy transaction.
2. **Create a contract instance** with a nonce. The nonce, combined with the deployer’s address and the contract hash, deterministically produces the contract address.

This is closer to Ethereum’s `CREATE2` than `CREATE`. The address is predictable before deployment.

The same contract artifact can be instantiated multiple times at different addresses. Initialization is a separate contract call unless an application-specific deployer combines deployment and initialization in one parent invocation.



### Calling

On Ethereum, you send a transaction specifying a contract address, a function selector (4-byte hash), and ABI-encoded arguments. On Groundhog, a transaction specifies a contract address, an entrypoint ID (8-byte identifier), and CXS-encoded arguments.

The SDK generates entrypoint IDs from method names and the `#[contract]` macro handles encoding. From a developer’s perspective, calling a contract looks like this:

```rust
let client = MyContractClient::new(&contract_addr);
client.increment(42);
let value = client.get();
```

The generated client handles serialization. You don’t construct raw calldata.



### Reading State

On Ethereum, you call `view` functions or read storage slots directly via `eth_getStorageAt`. On Groundhog, typed reads normally use `&self` methods through `groundhog_view`. The gateway also exposes `groundhog_getStorageAt` for low-level reads of a specific 32-byte contract-data key.

Transactions in a block share a starting snapshot. Ordinary storage reads can reflect earlier writes within the same transaction, but not writes from concurrent transactions. `RetrocausalQueue` has separate rules for observing concurrent inserts.



## Mental Model Shifts

| Solidity / EVM                                 | Groundhog                                                                 | Why                                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `balance = newValue`                           | `balance.increase(amount)` or `decrease(amount)`                          | Deltas merge in parallel. Different absolute writes conflict.                              |
| `mapping(address => uint256)`                  | `Map<ContractAddress, Balance>`                                           | Same concept. The value type enforces non-negativity and enables parallel execution.       |
| Gas per operation                              | Gas exists for metering but costs zero. HOG deposit for storage capacity. | Gas limits bound computation, but no tokens are burned.                                    |
| Sequential execution                           | Parallel by default                                                       | Transactions execute concurrently against the same block snapshot.                         |
| `require(condition, "message")`                | `ensure(condition, Error::Variant)`                                       | Typed errors instead of string messages.                                                   |
| `revert()` / `require()`                       | `throw(error)`                                                            | Aborts the transaction. Cannot be caught within the same contract.                         |
| Solidity + EVM bytecode                        | Rust + RV32 artifact                                                      | Different VM and artifact format. Attached Groundhog contract blobs are capped at 256 KiB. |
| `constructor()`                                | Ordinary initialization method                                            | Deployment does not invoke it automatically; guard one-time initialization in storage.     |
| `msg.sender`                                   | `get_caller()`                                                            | Same concept.                                                                              |
| `view` / `pure`                                | `&self` / no self                                                         | Read-only methods don’t produce state changes.                                             |
| `public` / `external` / `internal` / `private` | `pub` / not pub                                                           | Rust visibility. Public methods become contract entrypoints.                               |
| OpenZeppelin inheritance                       | Trait implementations                                                     | Rust uses traits and composition, not inheritance.                                         |



## Execution Differences

The runtime and storage model change how these patterns are implemented.



### Reentrancy

See [Solidity’s contract-call semantics](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls) for the EVM side of this comparison.

On the EVM, calling an external contract hands over execution control. That contract can call back into yours before your state updates are complete. Entire categories of exploits (DAO hack, read-only reentrancy) exist because of this.

Groundhog bans reentrancy at the runtime level. A contract cannot be called while it is already on the call stack. The runtime enforces this: if contract A calls contract B, and B tries to call back into A, the call fails. This is not a convention or a guard you add. It is a protocol-level guarantee.

Within a transaction, reads can observe earlier writes and successful child calls. Snapshot isolation separates concurrent transactions; the explicit runtime check prevents reentrancy.

You do not need a `nonReentrant` guard for contract calls. Application logic and error handling still depend on call order.



### Ordering and MEV

On Ethereum, pending transactions are visible in the mempool. Searchers can insert transactions before yours (front-running), after yours (back-running), or around yours (sandwich attacks). This is because transaction order within a block affects outcomes.

On Groundhog, commutative operations produce the same merged result regardless of execution order. Two compatible credits to the same account therefore produce the same final balance whichever executes first. Operations that conflict do not both land: one is excluded and returned to the mempool. The proposer still controls transaction selection and which contender wins a conflict, so Groundhog does not make a blanket claim that every application is MEV-free.



### Gas Limits and Gas Price Estimation

EVM developers spend significant effort estimating gas, setting gas limits, and handling out-of-gas reverts. Groundhog has gas limits for metering (bounding computation, preventing infinite loops), but gas costs zero tokens. You hold HOG tokens for capacity (compute throughput and storage). There is no gas price to estimate. Exceeding the declared gas limit still faults the transaction, and the declared limit determines its scheduling cost.



### Nonce Management

Every Ethereum transaction requires a sequential nonce per account. Sending transactions in parallel requires careful nonce tracking, and a stuck transaction blocks all subsequent ones. Groundhog has no sequential nonces. Replay protection uses a `Uniquifier` (a per-address value made of a block expiry height and an arbitrary nonce); it just has to be unique, not monotonic, so transactions from the same address can execute concurrently and out of order.



### Integer Overflow/Underflow

Solidity 0.8+ added checked arithmetic by default, but earlier versions required SafeMath. Groundhog’s `Balance` type enforces non-negativity at the storage layer. Checked `increase` and `decrease` abort automatically if the result would overflow or underflow. You don’t write separate arithmetic checks because the type handles them.



### The `approve()` Race Condition

The ERC-20 `approve(spender, amount)` function sets an absolute allowance. If you approve 100, then want to change it to 50, the spender can front-run your second `approve` and spend the original 100 before the new value takes effect.

Groundhog’s ERC-20 pattern uses `adjust_allowance(spender, diff)` instead. You send a delta (+50 or -50), not an absolute value. Concurrent allowance adjustments merge correctly because addition commutes.



## Pattern Adaptations



### Balance Transfer

**Solidity:**

```solidity
mapping(address => uint256) private balances;

function transfer(address to, uint256 amount) external {
    require(balances[msg.sender] >= amount, "Insufficient balance");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

**What changes:** No explicit balance check. `decrease` loads the sender and aborts during contract execution if its snapshot balance is insufficient. `lazy_increase` skips the receiver load and defers its bound check until delta reservation. Both operations produce mergeable deltas. Two transfers from the same account in the same block execute against the snapshot and produce deltas. If the account has enough balance for both, both succeed. If not, one is excluded.



### Access Control

**Solidity:**

```solidity
address public owner;

modifier onlyOwner() {
    require(msg.sender == owner, "Not owner");
    _;
}

function mint(address to, uint256 amount) external onlyOwner {
    balances[to] += amount;
    totalSupply += amount;
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    contract_owner: Value<ContractAddress>,
    // ...
}

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    ensure(get_caller() == self.contract_owner.get(), Error::NotOwner);
    self.total_supply.increase(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

**What changes:** No modifier system. Rust doesn’t have decorators. Use `ensure(condition, error)` at the top of the method. The pattern is the same (check authorization, then act), just expressed differently. For contracts with multiple roles, store a `Map<ContractAddress, Value<Role>>` and check against it.



### Constructor and Initialization

**Solidity:**

```solidity
contract Token {
    address public owner;
    uint256 public totalSupply;

    constructor(uint256 initialSupply) {
        owner = msg.sender;
        totalSupply = initialSupply;
        balances[msg.sender] = initialSupply;
    }
}
```

**Groundhog:**

```rust
use sdk::*;
use sdk::storage::{Balance, Map, Value};
use groundhog_erc20_if::{Amount, MintEvent, log_mint_event};

#[contract_exception]
pub enum Error {
    AlreadyInitialized = 1,
}

#[sdk::storage]
pub struct Token {
    contract_owner: Value<ContractAddress>,
    total_supply: Balance,
    balances: Map<ContractAddress, Balance>,
}

#[contract(throws = Error, emits(MintEvent))]
impl Token {
    pub fn initialize(&mut self, initial_supply: Amount) {
        ensure(
            self.contract_owner.try_get().none_if_missing().is_none(),
            Error::AlreadyInitialized,
        );
        let caller = get_caller();
        self.contract_owner.set_exclusive(&caller);
        self.total_supply.increase(initial_supply);
        self.balances.at_mut(&caller).lazy_increase(initial_supply);
        log_mint_event(&caller, initial_supply);
    }
}
```

The `groundhog_erc20_if` dependency provides the amount type and mint event helpers. See [Build a Token](pages/tutorials/build-a-token.md) for dependency setup and a complete token contract.

**What changes:** Groundhog has no special constructor syntax. Call `initialize` after deployment, or have an application-specific deployer invoke it in the same parent transaction. The runtime does not provide once-only constructor semantics. This example uses the owner field as its initialization marker. The exclusive write prevents concurrent initializations from both landing, even for the same caller. State initialization uses the same storage operations as everything else.



### Events

**Solidity:**

```solidity
event Transfer(address indexed from, address indexed to, uint256 value);

function transfer(address to, uint256 amount) external {
    // ... transfer logic ...
    emit Transfer(msg.sender, to, amount);
}
```

**Groundhog:**

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    // ... transfer logic ...
    log_transfer_event(&caller, receiver, amount);
}
```

**What changes:** Fields marked `#[topic]` become topics on typed events. Interface 0.1.41 uses `TransferEvent` and `AllowanceChangeEvent`, whose `.log()` methods encode the event. Allowance changes carry signed deltas, not absolute approvals. Filtering happens through the indexer/RPC. See [Add Events](pages/tutorials/add-events-to-a-contract.md) and [Contract Spec](pages/reference/contract-spec.md#events).



## ERC-20 Side-by-Side

Here’s how the core of an ERC-20 token compares. This isn’t the full implementation (see [Build a Token](pages/tutorials/build-a-token.md) for that), but it shows the key design differences.

**Solidity (OpenZeppelin-style):**

```solidity
contract ERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;

    function transfer(address to, uint256 amount) public returns (bool) {
        require(_balances[msg.sender] >= amount, "Insufficient");
        _balances[msg.sender] -= amount;
        _balances[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) public returns (bool) {
        _allowances[msg.sender][spender] = amount;  // absolute write
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public returns (bool) {
        require(_allowances[from][msg.sender] >= amount, "Allowance exceeded");
        require(_balances[from] >= amount, "Insufficient");
        _allowances[from][msg.sender] -= amount;
        _balances[from] -= amount;
        _balances[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct TokenContract {
    contract_owner: Value<ContractAddress>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Balance>>,
    total_supply: Balance,
}

#[contract(version = "0.1.5")]
impl ERC20 for TokenContract {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let owner = get_caller();
        self.balances.at_mut(&owner).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
        log_transfer_event(&owner, receiver, amount);
    }

    fn adjust_allowance(&mut self, spender: &ContractAddress, diff: Difference) {
        let owner = get_caller();
        let mut allowances = self.allowances.at_mut(&owner);
        let mut allowance = allowances.at_mut(spender);
        if diff >= 0 {
            allowance.increase(diff as u128);
        } else {
            allowance.decrease(diff.unsigned_abs());
        }
        log_approval_event(&owner, spender, diff);
    }

    fn transfer_from(&mut self, owner: &ContractAddress, receiver: &ContractAddress, amount: Amount) {
        let spender = get_caller();
        self.allowances.at_mut(owner).at_mut(&spender).decrease(amount);
        self.balances.at_mut(owner).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
        log_transfer_event(owner, receiver, amount);
    }
}
```

**Key differences:**

- **No explicit balance checks.** `Balance::decrease` aborts if the result would be negative. The check is built into the type.
- **`adjust_allowance` instead of `approve`.** Deltas instead of absolute writes. Compatible relative adjustments merge. The application must choose this API explicitly.
- **No success boolean.** These ERC-20 methods return unit on success and abort on failure, instead of returning `bool`. Other Groundhog methods can return typed values.
- **No `require` guards.** `Balance` enforces non-negativity. You only need `ensure()` for business logic checks (authorization, etc.), not arithmetic safety.
- **Parallel execution.** Two transfers debiting the same account both run against the snapshot. If the account has enough balance for both, both succeed and their deltas merge. If not, one is excluded and returned to the mempool.

For the full implementation with initialization, minting, burning, and tests, see [Build a Token](pages/tutorials/build-a-token.md).



## What Doesn’t Exist

These EVM features have no Groundhog equivalent. Set your expectations:

| EVM Feature                        | Status on Groundhog                            | Alternative                                                                                |
| ---------------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `msg.value` (send ETH with call)   | Does not exist                                 | Transfer tokens explicitly via a token contract                                            |
| `delegatecall` / proxy patterns    | Does not exist                                 | Contracts are immutable. Deploy new versions at new addresses.                             |
| `selfdestruct`                     | Does not exist                                 | Contracts are permanent                                                                    |
| `receive()` / `fallback()`         | Does not exist                                 | All methods must be explicitly defined                                                     |
| `block.timestamp` / `block.number` | `get_block_timepoint()` / `get_block_height()` | The timepoint is coarse consensus time chosen by the proposer, not a per-transaction clock |
| `gasleft()`                        | `stats::gas_remaining()`                       | Available for execution control, but gas costs zero tokens                                 |
| Contract inheritance               | Does not exist                                 | Use Rust traits and composition                                                            |
| 24KB EVM runtime-code limit        | Different limit                                | Attached Groundhog contract blobs are capped at 256 KiB                                    |
| Storage slot packing               | Does not exist                                 | Each storage field is independent                                                          |



## Next Steps

- [Contract quickstart](pages/get-started/contract.md) for a first deployment, and [Project structure](pages/contracts/project-structure.md) for the generated files
- [Build a Counter](pages/tutorials/build-a-counter.md) for a step-by-step first contract
- [Build a Token](pages/tutorials/build-a-token.md) for the full ERC-20 implementation
- [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the contract-level merge model
- [Storage Types](pages/reference/storage-types.md) for the full `Balance`, `NNInt`, `Map`, and `Bytestring` API

---

## Solana & Anchor

Source: <https://docs.groundhog.dev/ecosystem/solana/>

Groundhog concepts for Solana and Anchor developers.

This guide is for developers who know Solana and Anchor. It uses familiar Solana concepts to compare Groundhog’s storage and call patterns.

For the foundational concepts (delta operations, commutativity, storage types), see [For Blockchain Developers](pages/start/for-blockchain-developers.md). This page builds on that with Solana-specific patterns.



## Accounts vs. Storage

This is the biggest mental model shift. On Solana, state lives in accounts. Each account is a separate object with its own address, lamport balance, owner program, and serialized data. Your program receives an array of accounts, validates them, deserializes them, operates on them, and serializes them back. Anchor’s `#[derive(Accounts)]` automates the validation, but the account array is always there.

Groundhog does not use Solana’s caller-supplied account-array model. State lives under contract addresses in typed storage fields. A token contract doesn’t receive “the sender’s balance account” and “the receiver’s balance account” as separate objects. It has a `Map<ContractAddress, Balance>` field called `balances`, and it reads and writes entries in that map.

**Solana (Anchor):**

```rust
#[derive(Accounts)]
pub struct Transfer<'info> {
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    pub authority: Signer<'info>,
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The method accesses typed storage through `Map`. It still needs application authorization checks.



## Access Lists vs. Type-Based Parallelism

On Solana, you declare every account a transaction will touch before the transaction runs. The runtime uses this manifest to schedule parallel execution: transactions that don’t share writable accounts can run concurrently. This is why you build the account array. It’s not just for validation. It’s how Solana knows what can parallelize.

On Groundhog, you do not declare an account access list. The storage types themselves determine what parallelizes. `Balance` increases and decreases use mergeable deltas. `Map` operations on different keys never interact. The runtime doesn’t need a manifest because the types carry the parallelism rules.

This is a fundamental difference. On Solana, scheduling depends on the accounts and mutability declared by the transaction, and Anchor validates those accounts before instruction logic runs. On Groundhog, the runtime discovers storage access during execution and applies the merge rules of each storage type.



## The Contract Lifecycle

Both platforms separate contract code from address-specific state, and both compile Rust to a deployable binary format: SBF on Solana and RV32 on Groundhog. A Groundhog transaction can attach code and invoke `DeployContract` in the same transaction.



### Writing

Solana programs are written in Rust with Anchor (or native). Groundhog contracts are also Rust, with a different SDK. The macro system has a similar role but different surface area:

| Anchor                | Groundhog SDK                  | Purpose                                                             |
| --------------------- | ------------------------------ | ------------------------------------------------------------------- |
| `#[program]`          | `#[contract]`                  | Marks the implementation block                                      |
| `#[derive(Accounts)]` | *(not needed)*                 | Account validation. Groundhog has no account arrays.                |
| `#[account]`          | `#[sdk::storage]`              | Marks state structure                                               |
| `#[instruction]`      | Method parameters              | Instruction data. Groundhog methods take typed parameters directly. |
| `init` constraint     | Ordinary initialization method | Groundhog deployment does not invoke it automatically.              |



### Compiling

Solana compiles programs for SBF (`cargo build-sbf`). Groundhog compiles to RV32, a 32-bit RISC-V target, by default:

```bash
groundhog build
```



### Deploying

On Solana, you upload the program binary, then initialize accounts for it. On Groundhog, you deploy the RV32 artifact and create a contract instance via `DeployContract` with a nonce. The contract address is deterministically derived from the deployer’s address, the contract hash, and the nonce. Similar to Solana PDAs in predictability, with a different derivation: deployer address, contract hash, and nonce.



### Calling

On Solana, a transaction contains instructions, each specifying a program ID, account array, and serialized instruction data. On Groundhog, a transaction specifies a contract address, an entrypoint ID, and CXS-encoded arguments. No account array needed.

The SDK generates typed clients:

```rust
let client = TokenClient::new(&token_addr);
client.transfer(&recipient, 100);
```



## Mental Model Shifts

| Solana / Anchor                        | Groundhog                                        | Why                                                                                            |
| -------------------------------------- | ------------------------------------------------ | ---------------------------------------------------------------------------------------------- |
| Accounts with serialized data          | Typed storage fields (`Map`, `Balance`, `NNInt`) | State lives inside the contract. No external accounts.                                         |
| `#[derive(Accounts)]` validation       | Typed parameters and explicit authorization      | No caller-supplied account array.                                                              |
| PDAs (seeds + bump)                    | Deterministic address (deployer + nonce + hash)  | Simpler derivation. No seed discovery.                                                         |
| Rent-exempt account funding            | HOG deposit (refundable)                         | Hold tokens for storage capacity. No rent clock.                                               |
| Per-transaction compute budget         | Gas limits exist but cost zero                   | Metering bounds computation. No tokens burned. Hold HOG for throughput capacity.               |
| CPI (cross-program invocation)         | Cross-contract calls                             | Same concept, simpler API, snapshot isolation.                                                 |
| `Signer<'info>` propagation            | Caller identity and explicit auth tokens         | `get_caller()` identifies the immediate caller, not the root signer.                           |
| `balance -= amount; balance += amount` | `decrease(amount); lazy_increase(amount)`        | Deltas merge in parallel. Assignments conflict.                                                |
| Account-level write locks              | Type-level guarantees                            | The type (`Balance`, `Map`, `Bytestring`) enforces correctness; concurrency follows from that. |



## Account and Call Patterns



### Account Arrays and Validation

Solana instructions supply account metadata. Anchor expresses the required accounts and validation constraints in the `Accounts` structure.

Groundhog has addresses and account authorization, but no caller-supplied account array. Contract methods receive typed parameters and access storage under their own address.



### Rent and Account Lifecycle

[Solana accounts](https://solana.com/docs/core/accounts) hold a refundable minimum lamport balance proportional to their data size.

Groundhog uses a capital deposit model for storage. You hold HOG tokens as a deposit while storage is allocated, and the deposit is refundable when storage is freed. No rent clock, no garbage collection, no minimum balance calculations.



### Compute Unit Budgets

Solana transactions have a compute budget that can be adjusted per transaction through compute-budget instructions. Programs must fit within that resource budget, including the work performed by CPIs.

Groundhog has gas limits that meter computation, but gas costs zero tokens. Specify a gas limit to bound execution, but don’t optimize for gas cost. There are no priority fees and no fee-related failures.



### PDA Seed Management

PDAs on Solana require choosing seeds and deriving an off-curve address with a bump. Anchor’s `seeds` and `bump` constraints validate that derivation.

Groundhog contract addresses are derived from deployer + nonce + contract hash. One derivation, deterministic, no bumps. If your Solana program uses PDAs as state accounts (one per user, one per pool), the Groundhog equivalent is a `Map<Key, Value>` field in your contract storage. The map entries replace the PDAs.



### Signer Propagation in CPIs

On Solana, cross-program invocations require passing signer seeds so the runtime can verify PDA authority. The callee receives the signer authority verified by the runtime.

Groundhog cross-contract calls don’t propagate signers. The called contract sees `get_caller()` returning the calling contract’s address. Authorization is the called contract’s responsibility, checked against its own storage. No signer arrays, no PDA signing.



## Pattern Adaptations



### PDA State Accounts → Map Fields

**Solana pattern:** create a PDA account per user to store their state.

```rust
#[derive(Accounts)]
pub struct CreateUserAccount<'info> {
    #[account(
        init,
        payer = user,
        space = 8 + UserState::INIT_SPACE,
        seeds = [b"user", user.key().as_ref()],
        bump,
    )]
    pub user_state: Account<'info, UserState>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}
```

**Groundhog:** a Map field inside the contract. No separate account creation.

```rust
#[sdk::storage]
pub struct MyContract {
    user_states: Map<ContractAddress, Value<UserState>>,
}

fn get_user_state(&self, user: &ContractAddress) -> UserState {
    self.user_states
        .at(user)
        .try_get()
        .none_if_missing()
        .unwrap_or_default()
}
```

No `init` instruction, no `space` calculation, no `payer`, no `system_program`. The map entry is created on first write.



### Token Transfer

**Solana (SPL Token):**

```rust
let cpi_accounts = Transfer {
    from: ctx.accounts.from_token_account.to_account_info(),
    to: ctx.accounts.to_token_account.to_account_info(),
    authority: ctx.accounts.authority.to_account_info(),
};
let cpi_ctx = CpiContext::new(ctx.accounts.token_program.to_account_info(), cpi_accounts);
token::transfer(cpi_ctx, amount)?;
```

**Groundhog:**

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The Groundhog example implements the token contract itself. To transfer another contract’s token, call its generated client. In this implementation, each balance is a map field. Both calls produce mergeable deltas. `decrease` loads and checks the sender during execution, while `lazy_increase` skips the receiver load and defers its bound check.



### Cross-Program Invocation → Cross-Contract Call

**Solana:**

```rust
let cpi_accounts = MintTo {
    mint: ctx.accounts.mint.to_account_info(),
    to: ctx.accounts.token_account.to_account_info(),
    authority: ctx.accounts.authority.to_account_info(),
};
let seeds = &[b"mint_authority", &[bump]];
let signer_seeds = &[&seeds[..]];
let cpi_ctx = CpiContext::new_with_signer(
    ctx.accounts.token_program.to_account_info(),
    cpi_accounts,
    signer_seeds,
);
token::mint_to(cpi_ctx, amount)?;
```

**Groundhog:**

```rust
let token = ERC20Client::new(&token_addr);
token.mint(&recipient, amount);
```

The `#[contract]` macro generates the client. No account arrays, no signer seeds, no CPI context construction. The call executes within the same snapshot. If the called contract aborts, your contract aborts too (or use `try_mint` to handle the error).



### Error Handling

**Solana (Anchor):**

```rust
#[error_code]
pub enum MyError {
    #[msg("Not authorized")]
    NotAuthorized,
    #[msg("Insufficient balance")]
    InsufficientBalance,
}

// In handler:
require!(ctx.accounts.authority.key() == expected, MyError::NotAuthorized);
```

**Groundhog:**

```rust
#[contract_exception]
pub enum Error {
    NotAuthorized = 1,
}

// In method:
ensure(get_caller() == self.contract_owner.get(), Error::NotAuthorized);
```

Similar pattern: define error variants, check conditions. Anchor uses `require!` macro, Groundhog uses `ensure()`. Both abort the transaction on failure. The difference: Groundhog errors are CXS-serialized (for cross-contract error inspection), and `Balance::decrease` aborts automatically on underflow without a separate balance check.



## What Doesn’t Exist

| Solana Feature                                        | Status on Groundhog    | Alternative                                                      |
| ----------------------------------------------------- | ---------------------- | ---------------------------------------------------------------- |
| Caller-supplied account arrays                        | Not used               | State lives in contract storage fields                           |
| `#[derive(Accounts)]`                                 | Does not exist         | No account validation needed                                     |
| PDAs and bump seeds                                   | Does not exist         | Deterministic address from deployer + nonce + contract hash      |
| Rent / rent exemption                                 | Does not exist         | Refundable HOG deposit for storage                               |
| Compute unit budget                                   | Gas limits (cost zero) | Metering exists for bounding computation. No per-operation fees. |
| Priority fees                                         | Does not exist         | Throughput via HOG token holding                                 |
| `Signer<'info>` propagation                           | Does not exist         | `get_caller()` for identity                                      |
| Associated Token Accounts                             | Does not exist         | `Map<ContractAddress, Balance>` in contract storage              |
| Account `space` / `realloc`                           | Does not exist         | Storage grows as needed                                          |
| `system_program`, `token_program`, `rent` as accounts | Does not exist         | No system accounts passed to instructions                        |
| Versioned transactions                                | Does not exist         | One transaction format                                           |
| Address lookup tables                                 | Does not exist         | No account arrays to compress                                    |



## Next Steps

- [Contract quickstart](pages/get-started/contract.md) for a first deployment, and [Project structure](pages/contracts/project-structure.md) for the generated files
- [Build a Counter](pages/tutorials/build-a-counter.md) for a step-by-step first contract
- [Build a Token](pages/tutorials/build-a-token.md) for a full ERC-20 implementation
- [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the contract-level merge model
- [Storage Types](pages/reference/storage-types.md) for the full `Balance`, `NNInt`, `Map`, and `Bytestring` API

---

## Stellar & Soroban

Source: <https://docs.groundhog.dev/ecosystem/stellar/>

Groundhog patterns for developers building in the Stellar ecosystem.



## Who This Guide Is For

This guide is for Stellar and Soroban developers evaluating where Groundhog fits alongside the Stellar economy. It focuses on **pattern translation**: how familiar workflows look when they are expressed with Groundhog’s parallel storage primitives.

***



## Mental Model Shifts

Before diving into specific patterns, here are the main differences in emphasis:

| Aspect                   | Stellar                                                 | Groundhog                                                                    |
| ------------------------ | ------------------------------------------------------- | ---------------------------------------------------------------------------- |
| **Execution model here** | Classic Stellar operations                              | Contract calls with snapshot isolation and delta merge                       |
| **State model**          | Account-centric (balances, trustlines, offers built in) | Contract-centric (you define storage with typed primitives)                  |
| **Error handling**       | Transaction result codes                                | Typed abort with structured errors                                           |
| **DEX execution**        | Built-in offers and synchronous path payments           | Synchronous contracts or queued intent settlement, chosen by the application |
| **Multi-operation**      | Bundle multiple operations in one transaction           | Single root invocation with cross-contract calls                             |

Payments and token operations map directly to Groundhog’s balance deltas. DEX applications can use a synchronous AMM, or use a request queue when they want concurrent submission and later settlement, as shown in [Design a Swap](pages/tutorials/design-a-swap.md).

***



## Pattern Translations



### 1. Simple Payments

**Stellar Pattern:**

```javascript
// Stellar SDK
const payment = Operation.payment({
  destination: "GDEST...",
  asset: Asset.native(),
  amount: "100"
});

transaction.addOperation(payment);
```

**Groundhog Pattern:**

```rust
// Token contract transfer (see Build a Token for the full implementation)
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
    log_transfer_event(&sender, receiver, amount);
}
```

**What This Highlights:**

- You write a token contract with explicit balance primitives instead of using built-in account-level balances
- Both balance updates are delta operations, so transfers to and from the same account can execute in parallel
- Underflow is automatically rejected by `Balance::decrease` (the balance can never go negative)

The token contract in [Build a Token](pages/tutorials/build-a-token.md) shows the full version of this pattern.

***



### 2. Multi-Operation Transactions

Classic Stellar transactions can bundle operations atomically. Soroban transactions have a single smart-contract operation. See [Stellar operations and transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions).

**Stellar Pattern:**

```javascript
// Stellar: All operations execute atomically, sequentially
// Add these to a TransactionBuilder configured for the target network.
transaction
  .addOperation(Operation.payment({ destination: A, asset: Asset.native(), amount: "100" }))
  .addOperation(Operation.payment({ destination: B, asset: Asset.native(), amount: "50" }))
  .addOperation(Operation.changeTrust({ asset: USD }));
```

**Groundhog Pattern:**

```rust
// A contract method that performs multiple operations
fn batch_payment_and_trust(
    &mut self,
    dest_a: &ContractAddress,
    dest_b: &ContractAddress,
    token: &ContractAddress,
) {
    let sender = get_caller();

    // These are delta operations on independent keys, so they commute
    self.balances.at_mut(&sender).decrease(150);
    self.balances.at_mut(dest_a).lazy_increase(100);
    self.balances.at_mut(dest_b).lazy_increase(50);

    // Trust is just contract storage
    self.trustlines.at_mut(&sender).at_mut(token).set(&true);
}
```

**What This Highlights:**

- No operation bundling. You write a contract method that does everything you need
- For cross-contract operations, use [cross-contract calls](pages/contracts/cross-contract-calls.md): your method invokes other contracts
- Groundhog does not require you to declare which state you’ll touch upfront. Ordinary storage conflicts are checked during delta reservation after execution
- Each contract invocation is atomic: if your method aborts, all state changes are discarded

The main shift is organizational: logic that would be represented as a list of Stellar operations becomes a contract method.

***



### 3. Market Making / Resting Orders

Groundhog does not provide a built-in order book. A contract can store orders by ID in a `Map`, or accept order intents through a `RetrocausalQueue` when many producers need to submit concurrently.

**Stellar Pattern:**

```javascript
// Place a new offer
Operation.manageSellOffer({
  selling: XLM,
  buying: USD,
  amount: "1000",
  price: "0.10",
  offerId: 0  // 0 = new offer
});

// Cancel an existing offer
Operation.manageSellOffer({
  selling: XLM,
  buying: USD,
  amount: "0",   // 0 = cancel
  price: "0.10",
  offerId: 12345
});
```

With a map-based book, different order IDs are independent. Changes to the same order follow the stored value type’s conflict rules. With a queue-based design, inserts commute, one consumer sequences matching, and results are reported later through stored state or events. The queue is an application architecture, not a protocol requirement.

***



### 4. DEX Trading / Swaps

There are two useful Groundhog designs, and they make different tradeoffs.

**Stellar Pattern:**

```javascript
// Synchronous path payment: result is immediate
Operation.pathPaymentStrictReceive({
  sendAsset: XLM,
  sendMax: "1000",
  destination: dest,
  destAsset: USD,
  destAmount: "100",
  path: [EUR]  // Optional intermediate assets
});

// After confirmation, inspect the transaction result:
// - Did it execute?
// - What was the actual rate?
// - How much was sent?
```

**Synchronous contract.** A swap method can call token contracts and return in one transaction. The SDK example uses this Uniswap-style shape. Swaps against different pair contracts are independent. Swaps against the same pair usually conflict because each calculates and writes a new reserve value, so only a compatible subset lands in a block.

**Queued intents.** A venue can instead accept intents through `RetrocausalQueue`. Inserts commute, then a consumer matches and settles them later. This shape needs event polling or another application-level result channel, but separates highly concurrent submission from sequential matching.

Use the synchronous model when callers need an immediate contract result. Use a queue when submit-then-settle semantics fit the product.

***



### 5. Account & Trust Management

**Stellar Pattern:**

```javascript
// Create trustline
Operation.changeTrust({
  asset: new Asset("USD", "GISSUER..."),
  limit: "10000"
});

// Configure account
Operation.setOptions({
  homeDomain: "example.com",
  setFlags: AuthRequiredFlag
});
```

**Groundhog Pattern:**

```rust
// Trust and account config are just contract storage
fn set_trustline(&mut self, asset: &ContractAddress, limit: Amount) {
    let account = get_caller();
    self.trustlines.at_mut(&account).at_mut(asset).set(&limit);
}

fn set_options(&mut self, home_domain: &[u8], flags: u32) {
    let account = get_caller();
    self.config.at_mut(&account).set(&serialize_options(home_domain, flags));
}
```

**What This Highlights:**

- Explicit key-value storage instead of built-in account abstraction
- Per-account operations on different accounts are fully parallel (different `Map` keys)
- Different configuration writes to the same account conflict; identical bytestring writes can coexist

***



### 6. Soroban Smart Contracts

If you’re already writing Soroban contracts, Groundhog is best read as an adjacent contract environment with a different storage model. Soroban remains a strong fit for applications that want the Soroban runtime and Stellar integration directly; Groundhog is useful when parallel execution, permanent storage, and delta-oriented state are the shape you want.

**Soroban:**

```rust
#[contractimpl]
impl TokenContract {
    pub fn transfer(env: Env, from: Address, to: Address, amount: i128) {
        from.require_auth();
        assert!(amount >= 0);
        let from_balance: i128 = env.storage().persistent().get(&from).unwrap_or(0);
        let to_balance: i128 = env.storage().persistent().get(&to).unwrap_or(0);
        assert!(from_balance >= amount);
        env.storage().persistent().set(&from, &(from_balance - amount));
        env.storage().persistent().set(&to, &(to_balance + amount));
    }
}
```

**Groundhog:**

```rust
#[contract(throws = TokenError)]
impl TokenContract {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let sender = get_caller();
        self.balances.at_mut(&sender).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
    }
}
```

**Side-by-Side Patterns:**

| Soroban                                                       | Groundhog                                                                                      |
| ------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| `env.storage().persistent().get/set` (read-modify-write)      | `Balance` increase/decrease (delta operation; no absolute rewrite)                             |
| Three storage tiers (Instance, Persistent, Temporary)         | One storage model, no tiers                                                                    |
| TTLs on all storage; must call `extend_ttl()` or data expires | Permanent storage, no TTLs, no expiration                                                      |
| `require_auth()` for caller authorization                     | `ensure(caller == self.owner.get(), err)` pattern                                              |
| `#[contractimpl]`                                             | `#[contract]` with `#[sdk::storage]`                                                           |
| `Env` passed to every function                                | `&self` / `&mut self` with `get_caller()`                                                      |
| Resource limits constrain transaction complexity              | Gas metering exists but costs zero tokens                                                      |
| Sequence numbers serialize transactions per Stellar account   | No sequential nonce; each Groundhog transaction carries a unique `(expiry height, nonce)` pair |
| Fees per transaction (inclusion + resource fees)              | No per-operation fees; available (unlocked) HOG balance determines throughput share            |

The important Groundhog concept is commutativity: which storage operations can merge determines how much parallelism your contract gets. See [Parallel Execution](pages/how-it-works/execution-model.md).

***



## Pattern Summary

| Pattern        | Groundhog Shape       | Notes                                                      |
| -------------- | --------------------- | ---------------------------------------------------------- |
| Payments       | Direct                | Token contract transfers with `Balance` storage            |
| Resting orders | Direct or queued      | Map entries keep orders independent; queue inserts commute |
| Trust/Auth     | Direct                | Explicit key-value model                                   |
| DEX trades     | Synchronous or queued | Direct AMM calls return immediately; queues settle later   |
| Soroban tokens | Direct                | Delta operations instead of read-modify-write              |
| Soroban DEX    | Synchronous or queued | Choose based on contention and product semantics           |

Payments and token operations fit `Balance` directly. DEX applications should deliberately choose between synchronous execution and a queued intent design.

***



## What Doesn’t Change

Despite the differences, many concepts translate directly:

| Stellar Concept             | Groundhog Equivalent                                                  |
| --------------------------- | --------------------------------------------------------------------- |
| Accounts                    | Contract addresses                                                    |
| Assets (XLM, issued tokens) | Token contracts                                                       |
| Trustlines                  | Contract-level authorization                                          |
| Order book DEX              | Application-defined map or queued-intent venue                        |
| Sequence numbers            | Unique expiry-height and nonce pair, not a monotonic account sequence |

***



## Common Questions



### Q: Do I lose atomicity for multi-op transactions?

No. Each Groundhog contract invocation is atomic. If your method aborts, all state changes are discarded. For multi-step workflows that span multiple contracts, use [cross-contract calls](pages/contracts/cross-contract-calls.md): a parent contract calls child contracts, and if the parent aborts, all child changes are reverted too.



### Q: When should I use a queued DEX model?

Use a queue when concurrent intent submission matters more than an immediate result. Poll execution events or read venue state to learn the settlement outcome. If callers need synchronous output, use a direct swap contract instead.



### Q: Will my market making bot need major changes?

That depends on the venue design. A synchronous venue looks like an ordinary contract call. A queued venue requires the bot to correlate submitted intents with later settlement events or state.

***



## References

- [Contract quickstart](pages/get-started/contract.md): Build, test, and deploy a Groundhog contract
- [Build a Token](pages/tutorials/build-a-token.md): Full ERC-20 token walkthrough
- [Merged Deltas](pages/programming-model/execution.md#merged-deltas): How concurrent state changes combine
- [Storage Types](pages/reference/storage-types.md): Balance, NNInt, Map, Vector, Value, Bytestring, RetrocausalQueue API reference

---

## CLI quickstart

Source: <https://docs.groundhog.dev/get-started/cli/>

Create a Devnet wallet, request test HOG, and inspect your first transaction from the terminal.

Create a wallet on Devnet, fund it with test HOG, and inspect the funding transaction. You do not need a contract project or a local node.

**Before you start:** [install the latest CLI](pages/cli/install.md). Run these commands outside an existing Groundhog project so they use your global configuration.



## 1. Set up the CLI

```bash
groundhog init
```

On a fresh installation, accept signing-key creation and decline starter-project creation. Setup creates the `default` key and the built-in network profiles.



## 2. Create a wallet

```bash
groundhog wallet create --profile devnet
```

Confirm the prompt. The CLI saves a wallet address for your selected key. Creating this wallet does not fund it or send a transaction.

```bash
groundhog wallet ls --profile devnet
```

You should see your wallet’s name and address. With a fresh setup, its name is `default`.



## 3. Request test funds

```bash
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Confirm the airdrop and wait for its result. You should have a positive HOG balance. Save the transaction hash printed by the airdrop command.

Devnet HOG is for testing. The faucet selects the amount; you do not need an amount flag.



## 4. Inspect the transaction

Replace `TX_HASH` with the hash from the airdrop:

```bash
groundhog tx show TX_HASH --profile devnet
```

Check that the transaction committed successfully. You now have a funded wallet and have verified an onchain result.



## Next

[Deploy your first contract](pages/get-started/contract.md) using this wallet.

If funding is pending, rerun the same airdrop command to resume the request. For network errors or faucet limits, see [Faucet](pages/tools/faucet.md).



## Use a coding agent

Copy this prompt into your agent:

```text
Help me complete the Groundhog CLI quickstart:
https://docs.groundhog.dev/get-started/cli/
Use the latest CLI and read groundhog skill show cli. Set up a Devnet
wallet without creating a contract project or running a local node.
Preserve any existing keys and configuration. Request test funds,
check the wallet balance, and inspect the airdrop transaction.
Report success only after checking the committed transaction result.
Ask me to supply any required registry access through my environment,
not in this conversation. Report a network failure rather than bypassing it.
```

---

## Contract quickstart

Source: <https://docs.groundhog.dev/get-started/contract/>

Create, test, and deploy a Rust counter contract to Groundhog Devnet.

Deploy a counter to Devnet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](pages/get-started/cli.md) so you have the latest CLI and a funded Devnet wallet. Keep your [Cargo registry access](pages/cli/install.md#configure-cargo-access) available in this terminal.



## 1. Create a contract

```bash
groundhog new my-counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`.



## 2. Build and test

```bash
groundhog build
groundhog test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.



## 3. Deploy to Devnet

```bash
groundhog deploy --profile devnet --fund 10
```

Confirm the deployment. The CLI prints the contract address and saves the alias `my-counter` in the project’s Devnet profile.

`--fund 10` transfers 10 test HOG to the contract for this example’s storage. It is a funding amount, not a fixed deployment fee.



## 4. Change the counter

Initialize this new counter, then increase it:

```bash
groundhog call my-counter initialize 10 --profile devnet
groundhog call my-counter increment 5 --profile devnet
```

Confirm each call and wait for success. Run `initialize` only once for this walkthrough; this example method adds the initial amount rather than enforcing one-time initialization.



## 5. Read the result

```bash
groundhog view my-counter get --profile devnet
```

The result should be **15**. You have built, tested, deployed, and called a contract on Devnet.



## Next

[Build a Counter](pages/tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](pages/contracts/project-structure.md).



## Use a coding agent

```text
Help me complete the Groundhog contract quickstart:
https://docs.groundhog.dev/get-started/contract/
Use the latest CLI and read groundhog skill show contracts. Check CLI setup and
Devnet funding first. Scaffold my-counter, preserve its generated
dependency and compiler settings, then build and test it.
Deploy to Devnet with the documented contract funding, initialize
the new counter to 10, increment by 5, and verify that its view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```

---

## Get Started

Source: <https://docs.groundhog.dev/get-started/>

Choose a starting point for Groundhog contracts, applications, or coding agents.

Get a working result on Devnet. Choose the tools you want to use; you do not need to follow every path.



## Choose your path

- **[CLI quickstart](pages/get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](pages/get-started/contract.md):** build and test a counter, deploy it to Devnet, and read its updated value.
- **[TypeScript quickstart](pages/get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](pages/get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.



## Work with a coding agent

[Build with an Agent](pages/start/build-with-an-agent.md) gives you two setup commands and one prompt for a complete counter application on Devnet. For a smaller task, use the prompt in an individual quickstart.



## What you need

CLI and contract work use the [Groundhog CLI and Cargo registry](pages/cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](pages/typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Devnet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.

For a worked project, go to [Guides](pages/guides.md). New to the platform? Read the [Introduction](pages/architecture.md) before choosing a path.

---

## React quickstart

Source: <https://docs.groundhog.dev/get-started/react/>

Display live Devnet contract data in React with a typed query and a refresh action.

Build a React page that reads the HOG token’s total supply from Devnet and refreshes it on demand. You do not need a wallet, the CLI, or your own contract.



## 1. Create the application

Use the current Node.js LTS release:

```bash
npm create vite@latest my-groundhog-ui -- --template react-ts
cd my-groundhog-ui
```

Complete [package setup](pages/typescript/setup.md) in this directory, then install the application dependencies:

```bash
npm install
npm install @groundhogchain/react @groundhogchain/client @groundhogchain/protocol @tanstack/react-query
```



## 2. Connect the providers

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createGroundhogClient, devnet } from "@groundhogchain/client";
import { WalletProvider } from "@groundhogchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Devnet…</p>);

async function start() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Devnet"}</p>,
  );
});
```

The client and query cache are created once. `WalletProvider` makes the client available to Groundhog hooks; it does not connect a wallet automatically.



## 3. Display the result

Replace `src/App.tsx`:

```tsx
import { formatUnits } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { useContractView } from "@groundhogchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    contract: HOG_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>HOG on Devnet</h1>
      {supply.isPending && <p>Reading the contract…</p>}
      {supply.error && <p role="alert">{supply.error.message}</p>}
      {supply.data && (
        <>
          <p>Supply: {formatUnits(supply.data.value, 7)} HOG</p>
          <p>Read at block: {supply.data.height.toString()}</p>
        </>
      )}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

The hook runs the typed view and exposes loading, error, and data states. Refresh makes another network read; it does not send a transaction.



## 4. Open the app

```bash
npm run dev
```

Open the local URL printed by Vite. The page should show a supply value and block height. Click **Refresh** and confirm that the page finishes another read. Also check that the project builds:

```bash
npm run build
```



## Next

See [Read contract data](pages/react/reads.md) for arguments and query behavior, or [Connect a wallet](pages/react/wallets.md) to add wallet controls. [Send transactions](pages/react/transactions.md) covers approval and execution state.



## Use a coding agent

```text
Build the Groundhog React quickstart:
https://docs.groundhog.dev/get-started/react/
Use a React TypeScript Vite project, the latest published Groundhog
packages, and hosted Devnet. Configure package access through my environment.
Display the HOG total supply and its read height with useContractView.
Include loading and error states and a Refresh button. Run the build
and verify the actual page result. No CLI, contract deployment, or wallet
connection is needed for this read-only example. Report package or network
errors rather than forcing incompatible dependencies or faking results.
```

---

## TypeScript quickstart

Source: <https://docs.groundhog.dev/get-started/typescript/>

Connect to Devnet and read the native HOG contract with a typed TypeScript client.

Read the HOG token’s total supply from Devnet with a typed contract call. This path needs Node.js and package access, but no CLI, signing key, or contract deployment.



## 1. Create a project

```bash
mkdir my-groundhog-app
cd my-groundhog-app
npm init -y
npm pkg set type=module
```

Complete [package setup](pages/typescript/setup.md) in this directory, then install the latest SDK and a TypeScript runner:

```bash
npm install @groundhogchain/client @groundhogchain/protocol
npm install --save-dev typescript tsx @types/node
```



## 2. Read a contract

Create `index.ts`:

```ts
import { createGroundhogClient, devnet, formatUnits, getContract } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";

async function main() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
  const supply = await hog.totalSupply.view({ args: undefined });

  console.log("HOG supply:", formatUnits(supply.value, 7));
  console.log("Read at block:", supply.height.toString());
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
```

`devnet()` selects the hosted network. The SDK includes the HOG contract’s standard binding, so you do not need to generate one. `supply.value` is a typed integer; formatting it displays HOG rather than base units.



## 3. Run it

```bash
npx tsx index.ts
```

You should see **HOG supply** and **Read at block**, each followed by a value. Run the command again to make another read. The values come from Devnet and can change; there is no fixed expected block number.

This is a read-only call. It does not request wallet permission or submit a transaction.



## Next

Use [Read contract data](pages/typescript/reads.md) for arguments, caller context, and cancellation, or [Connect a wallet](pages/tools/wallet-integration.md) to add signing and transaction submission.



## Use a coding agent

```text
Build the Groundhog TypeScript quickstart:
https://docs.groundhog.dev/get-started/typescript/
Use the latest published SDK packages and the hosted Devnet.
Configure package access through my environment. Create the typed HOG
total-supply read shown in the guide and run it. Show the actual supply
and block height, or report the exact error if the request fails.
Do not install the Rust toolchain, deploy a contract, or create a wallet
for this read-only example. Keep the generated package lockfile.
```

---

## Guides

Source: <https://docs.groundhog.dev/guides/>

Learn Groundhog through contract tutorials, application walkthroughs, and worked designs.

Build a project or work through a design. Choose a guide by the result you want, and use the product sections for individual commands and API details.



## Start with a counter

Start with the [contract quickstart](pages/get-started/contract.md) for a working Devnet deployment, then continue with the detailed guides:

1. [Build a Counter](pages/tutorials/build-a-counter.md) explains a small Rust contract, storage, errors, and tests.
2. [Develop Locally](pages/tutorials/develop-locally.md) walks through deploying and calling the counter on a local node.
3. [Work with Groundhog from TypeScript](pages/tutorials/work-with-groundhog-from-typescript.md) connects a typed client to a contract.
4. [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md) follows an event from its Rust definition through application queries.

For a hosted deployment, follow [Develop on Devnet](pages/tutorials/develop-on-devnet.md).



## Explore another project

- **[Connect a Wallet to Your App](pages/tutorials/connect-a-wallet-to-your-app.md)** builds a vanilla TypeScript interface for connecting a wallet, sending a transfer, and checking its receipt.
- **[Build a Token](pages/tutorials/build-a-token.md)** is a contract tutorial covering storage, an interface implementation, and tests.
- **[Design a Swap](pages/tutorials/design-a-swap.md)** is a design walkthrough covering request acceptance, execution, and batching. Read it for the design decisions rather than a complete application setup.



## Find example code

The [Groundhog examples repository](https://github.com/groundhogchain/groundhog-examples) contains contract and application examples. Use each example’s README for its setup, supported dependencies, and checks.

For your first setup, start with [Get Started](pages/get-started.md).

---

## System Overview

Source: <https://docs.groundhog.dev/how-it-works/architecture/>

How Groundhog's public gateway, execution services, storage, and consensus coordinator fit together.

Groundhog separates three responsibilities: serving applications, executing transactions and storing state, and agreeing on blocks. This page maps those responsibilities to the services that handle them.



## Components

```text
Applications and wallets
      |
      v
JSON-RPC gateway
      |
      +-- Reads
      |   State / Views / History
      |
   submits
      v
  Scheduler <--> Coordinator
      |               |
      |         Other validators
      |
      +-- Auth server
      +-- Executors <--> DB shards
      +-- Event server
```

The diagram shows the main service relationships. [Networking](pages/how-it-works/networking.md) covers registration and communication between them.

| Component                              | Responsibility                                                                                                      |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| **JSON-RPC gateway** (`groundhog-rpc`) | Accepts application requests, submits transactions to the scheduler, and routes reads to the relevant service       |
| **Scheduler / mempool** (`hogd`)       | Queues transactions, coordinates authorization, dispatches execution, and orchestrates block production and commits |
| **Auth server**                        | Checks transaction authorization claims and signatures before scheduling                                            |
| **Executors**                          | Run contract code and submit its state changes for reservation against the proposed block                           |
| **DB shards**                          | Serve state snapshots, enforce storage merge rules, and store committed state                                       |
| **Event server and indexer**           | Collect execution results and make transaction history, receipts, and events available for queries                  |
| **Coordinator** (`chuckd`)             | Drives consensus with other validators and asks the execution layer to propose, validate, and commit blocks         |





## Two paths through the gateway

**Transactions** enter through the gateway and reach the scheduler. The scheduler arranges signature checks, selects work, and dispatches it to executors. The execution layer produces a block proposal; the coordinator handles agreement with other validators.

**Reads** use the service appropriate to the request. State and balance queries use the database gateway, read-only contract calls use the view gateway, and receipt and event queries use the indexer. The scheduler supplies information such as the chain tip and pending transaction status.

The public gateway does not participate in consensus. Applications use its [JSON-RPC API](pages/reference/json-rpc-api.md) rather than the internal service interfaces.





## Execution and agreement

The execution layer determines what a proposed block would do. Contracts run against a shared snapshot and produce typed state changes. Executors and DB shards check which changes can be reserved together.

The coordinator drives agreement on which valid proposal to commit. It uses the Stellar Consensus Protocol (SCP); it does not run the contracts itself. Each validator checks the proposed result through its own execution layer before committing it.



Multiple execution workers and database shards distribute work within a node. Consensus coordinates agreement between validators. These are different responsibilities; adding execution capacity does not change the consensus rules.



## Explore the details

- [Parallel Execution](pages/how-it-works/execution-model.md): Snapshots, compatible updates, and conflict reservation
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): Submission, execution outcomes, and commit
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): Scheduling and storage deposits
- [Consensus](pages/how-it-works/consensus.md): Proposals, validation, and finality
- [Networking](pages/how-it-works/networking.md): Component registration and internal interfaces

For the behavior your contract relies on, read [Contract Execution](pages/programming-model/execution.md).

---

## Authorization

Source: <https://docs.groundhog.dev/how-it-works/authorization/>

How transaction signatures, address auth data, caller identity, and auth tokens work in Groundhog.

Groundhog treats addresses uniformly. An address can hold code, store auth data, receive calls, and originate transactions through either supported admission model.

Authorization has two layers:

1. **Transaction admission**: hogd checks the transaction’s auth claim and signatures before execution.
2. **Runtime authorization**: contracts use caller identity, explicit signature checks, and typed auth tokens while executing.

These layers are related but separate. Transaction admission decides whether the root transaction may enter the block. Runtime authorization decides what authority a contract gives to a caller or token it receives.



## Authorize an application operation

For an owner-controlled method, store the owner in `Value<ContractAddress>` and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), AccessError::NotOwner);
```

Define `AccessError` with [a contract exception](pages/contracts/errors.md#defining-errors). Initialize the owner through a guarded method and [deploy and initialize atomically](pages/cli/deploy-and-call.md#include-initialization) if the first caller becomes the owner.

`get_caller()` identifies the immediate caller. A forwarded call identifies the forwarding contract, not the original user. For authority passed through several frames, use the [typed auth-token model](pages/how-it-works/authorization.md#auth-tokens-and-signedt) below and validate its minter and payload.



## Transaction Admission

A `SignedTransaction` contains an inner transaction plus decorated signatures:

```text
struct DecoratedSignature {
  unsigned int public_key_id;
  Signature signature;
};

struct SignedTransaction {
  Transaction tx;
  DecoratedSignature signatures<>;
};
```

The source address is the root invocation’s `invoked_address`. Every transaction signature covers this preimage:

```text
cxs(DomainSeparator("Transaction")) || networkHash || txs(transaction)
```

`txs(value)` denotes its standard XDR encoding. The domain separator prevents a transaction signature from being interpreted as a signature over another object. The network hash binds the signature to one Groundhog network and prevents cross-network replay.

The canonical transaction hash is `sha256(txs(transaction))`. It identifies the inner transaction and excludes signatures. It is distinct from both the signature preimage and the encoded `SignedTransaction` wrapper.



## Admission Models

The transaction’s `AuthClaim` selects one of two admission models:

```text
enum AuthClaim switch (AuthClaimType claim_type) {
case kSourceAddressAuthData:
  struct {
    BitMap allowed_keys;
    Weight required_weight;
  } source_address_claim;

case kPubkeySignature:
  PubkeyAccountPreimage pubkey_preimage;
};
```



### Pubkey Accounts

`kPubkeySignature` authorizes an account whose address is derived from `PubkeyAccountPreimage { pubkey, nonce }`. hogd accepts the claim only when:

- the derived address equals the root invocation’s `invoked_address`;
- the source address has no registered `AddressAuthData`;
- the transaction has exactly one Ed25519 signature, with `public_key_id` 0;
- that signature verifies against the public key in the preimage.

During root execution at an undeployed pubkey-account address, the runtime falls back to the network’s configured DefaultWallet contract. This gives a new pubkey account wallet behavior without first deploying code at its derived address. The fallback applies only to the root invocation.



### Source-Address Accounts

`kSourceAddressAuthData` authorizes the root invocation from auth data stored at its source address. The source address must have `AddressAuthData`; a source-address claim without it is rejected.

hogd checks:

- `allowed_keys` does not set bits beyond `kMaxSigners = 21`.
- Every signature’s `public_key_id` appears in `allowed_keys`.
- Signature `public_key_id` values are strictly increasing, so duplicates and out-of-order signatures are rejected.
- Each referenced key exists in the source address’s `AddressAuthData`.
- Each signature verifies against its registered public key. The current helper path supports Ed25519.
- The sum of matched key weights is at least `max(address.required_weight, claim.required_weight)`.

The threshold is `max(address.required_weight, claim.required_weight)`. This lets the address set a standing minimum while each transaction can require an equal or higher threshold.

Contracts can inspect the root transaction’s auth claim with [`get_auth_claim()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/auth_claim/fn.get_auth_claim.html), but admission has already happened by the time contract code runs.



## Address Auth Data

`AddressAuthData` is stored under `StorageKeyType::AuthData` for an address:

```text
struct PublicKeyConfig {
  PublicKey key;
  Weight max_weight;
};

struct AddressAuthData {
  PublicKeyConfigOpt public_keys[21];
  Weight required_weight;
  BlockHeight last_written_height;
};
```

Each key slot is optional. Empty slots do not contribute weight.

An address can mutate only its own auth data. The SDK exposes the current syscalls as:

```rust
use sdk::{
    add_address_public_key,
    remove_address_public_key,
    set_address_required_weight,
};

add_address_public_key(0, public_key, 1)?;
set_address_required_weight(1)?;
remove_address_public_key(0)?;
```

Use these for source-address accounts, wallet contracts, and contracts that are meant to originate later transactions. Replay protection is transaction-level, through the transaction `Uniquifier`. `AddressAuthData` does not contain nonce policy or gas-sponsorship policy fields.



## Caller Identity

Inside a contract, [`get_caller()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_caller.html) returns the direct caller of the current invocation frame:

```rust
use sdk::get_caller;

let caller = get_caller();
```

This is Groundhog’s equivalent of `msg.sender`: immediate caller identity. It is not a signer set and it does not tell you which key signed the root transaction. A root frame has no caller, so the underlying syscall errors there.

Use [`get_current_address()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_current_address.html) when a contract needs its own address.



## Contract Signature Checks

Contracts can verify arbitrary messages with [`verify_signature_ed25519()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/crypto/fn.verify_signature_ed25519.html):

```rust
use sdk::verify_signature_ed25519;

let ok = verify_signature_ed25519(&public_key, &signature, message);
```

This is runtime logic, separate from transaction admission. A wallet contract can use it to accept an off-chain signature, apply its own policy, and then mint an auth token in the wallet contract’s name.



## Auth Tokens and `Signed<T>`

The SDK’s [`Signed<T>`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/struct.Signed.html) is a typed runtime auth-token handle. It is not a cryptographic signature and it is not a durable bearer token.

An auth token carries:

- **Minter**: set by the host to the current contract address at mint time.
- **Consumer**: the contract address allowed to consume the token.
- **Payload**: CXS-encoded typed data from the SDK.
- **Expiry height**: the token is valid through this block height.
- **Child nodes**: nested auth tokens that materialize when the parent is consumed.

`Signed<T>` is a handle to this runtime token. The handle travels out-of-band alongside calldata; it does not serialize the payload into the method argument bytes. Contract specifications represent it as a `SignedToken` node containing the payload type.

To make a payload type usable in a token, mark it as a contract type:

```rust
use sdk::*;

#[contract_type]
pub struct TransferAuth {
    pub to: ContractAddress,
    pub amount: i128,
}
```

Mint with [`mint_auth_token()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/fn.mint_auth_token.html):

```rust
use sdk::*;

let token: Signed<TransferAuth> = mint_auth_token(
    expiry,
    AuthTokenPreimage {
        consumer: token_contract,
        data: TransferAuth { to, amount },
    },
);
```

Consume with `Signed<T>::consume()`:

```rust
use sdk::*;

pub fn transfer_from(
    amount: i128,
    to: &ContractAddress,
    auth: Signed<TransferAuth>,
) {
    let (claim, minter) = auth.consume();

    assert!(minter == expected_wallet(), "unauthorized minter");
    assert!(claim.to == *to, "unauthorized recipient");
    assert!(amount <= claim.amount, "exceeds authorized amount");

    // Move funds from `minter` to `to`.
}
```

Consuming proves only two things: the token was minted by the returned `minter`, and the token was destined for the current contract. Any contract can mint a token whose payload decodes as `TransferAuth`. Always check the returned minter against an address your contract trusts before acting on the payload.



## Passing Auth Tokens

Auth tokens never flow implicitly across contract calls. Generated clients collect `Signed<T>` handles from arguments and pass those token ids to `Invoke` beside calldata. A callee receives only the tokens that appeared in its arguments.

Frame ownership works like this:

- When a parent forwards a token to a child call, the child owns that token while it runs.
- If the child returns the token in its return value, the parent receives it back.
- If the child aborts or the parent handles a reverted child frame, forwarded tokens are restored to the parent.
- If the child succeeds without returning a forwarded token, the parent does not automatically regain it.
- Consuming a token removes it. Any child tokens become fresh handles owned by the consuming frame.

This makes method signatures part of the authorization surface: a function that does not take a `Signed<T>` argument cannot consume that token.

Generated clients assign returned token handles to `Signed<T>` fields in the return value. Lower-level callers that receive a `Vec<Signed<Opaque>>` can use `AssumeTokens::try_assume_tokens` to convert an exact number of opaque handles into a typed tuple. A count mismatch returns `CallingError::DecodingSuccess`; `AssumeTokens::assume_tokens` is the throwing convenience form.



## Nested Auth Tokens

A token payload can contain `Signed<U>` fields. When the outer token is consumed, the runtime creates child-token handles for those fields. Child tokens keep the same minter and expiry as the parent, but each child has its own consumer address and payload.

```rust
use sdk::*;

#[contract_type]
pub struct DexIntent {
    pub pool: ContractAddress,
    pub deadline: BlockHeight,
    pub min_received: i128,
    pub transfer: Signed<TransferAuth>,
}

pub fn execute_swap(intent: Signed<DexIntent>) {
    let (intent, trader) = intent.consume();

    assert!(trader == expected_wallet(), "unauthorized trader");
    assert!(get_block_height() <= intent.deadline, "intent expired");

    // The nested transfer token is now a fresh handle that can be passed to
    // the token contract selected as its consumer.
    token_client.transfer_from(amount_in, &intent.pool, intent.transfer);
}
```

The outer token might be consumed only by the DEX. The nested transfer token might be consumed only by the token contract. Attribution stays with the original minter through the chain.



## Limits

The protocol currently caps an auth-token payload at 256 bytes, tree depth at 4, and child nodes per token at 4. `MintAuthToken` rejects malformed token nodes, expired-at-mint tokens, and tokens that would exceed runtime caps. `ConsumeAuthToken` rejects tokens not owned by the current frame, expired tokens, and already-consumed handles.



## Not Landed

Do not rely on these patterns yet:

- Detached admission-time signatures that directly become `Signed<T>` values.
- Nonce or gas-sponsorship policy fields in `AddressAuthData`.
- Durable, storable, or off-chain portable `Signed<T>` handles. A `Signed<T>` is a runtime handle owned by invocation frames inside a transaction.



## See Also

- [Invocation Frames](pages/how-it-works/invocation-frames.md)
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)
- [Syscalls](pages/reference/syscalls.md)
- [SDK Macros](pages/reference/sdk-macros.md)
- [Rust API Docs](pages/tools/rust-api-docs.md)

---

## Consensus

Source: <https://docs.groundhog.dev/how-it-works/consensus/>

SCP-based consensus, block production, and irrevocable finality.

> **caution: Draft**
>
> This page describes the current architecture. Some details may change as the protocol matures.



## Overview

Groundhog uses the Stellar Consensus Protocol (SCP) for agreement. SCP is a federated Byzantine agreement protocol: each validator picks its own **quorum slices** (the sets of validators it trusts), and the network converges on a single value without a fixed committee or rotating leader. Nomination uses a priority function to bias which validator’s proposed value is considered first per round, but no validator can unilaterally decide a block; agreement comes from overlapping quorum slices, not from a designated proposer.

SCP provides finality under its quorum-intersection and fault assumptions. Applications use the finalized block result rather than a probabilistic confirmation count.



## The Coordinator

Consensus is driven by the coordinator (chuckd), which is separate from the execution engine (hogd). The coordinator’s job is to get validators to agree on which block to commit. Contract execution and storage belong to the execution layer, orchestrated by the scheduler. See [System Overview](pages/how-it-works/architecture.md) for the component roles.

Each coordinator is configured with its own quorum set: the list of other validators it trusts for consensus. This peer configuration is managed by the coordinator, not the mempool. The mempool handles intra-node component registration (executors, DB shards, etc.); the coordinator handles inter-node consensus topology. This separation keeps execution concerns and agreement concerns independent.

It runs a state machine called the **baton** that drives the consensus loop.



## Block Production

The baton runs a drive loop after every event:

```plaintext
driveCommit()    →  Commit any externalized block
driveNominate()  →  Propose next block if idle
driveCatchup()   →  Fetch missing blocks from peers
driveLiveness()  →  Detect stuck consensus
```



### Single-Node Flow

On a single validator (e.g. during development):

1. Baton calls `propose_block` on the mempool. The execution layer runs queued transactions and assembles a proposal.
2. SCP externalizes immediately (single-node quorum).
3. Baton calls `commit` on the mempool. The execution layer commits the finalized proposal to storage.
4. Next drive cycle begins.



### Multi-Node Flow

With multiple validators:

1. **Propose.** A validator asks its mempool for a block proposal. The proposal contains the transactions and metadata.
2. **Disseminate.** The full consensus value (nomination + metadata) is broadcast to peers via Dogwood (see below). A compact hash reference (the “cue”) is sent through SCP.
3. **Validate.** Receiving validators ask their own mempool: “is this nomination valid against my state?” Validation runs asynchronously and results are cached.
4. **Converge.** SCP envelope exchange continues until validators agree. Agreement depends on quorum intersection and the configured trust assumptions.
5. **Commit.** Once SCP externalizes a value, each validator commits the block locally via its mempool.



### Execution During Block Production

The proposer and validators execute transactions differently.

**The proposer runs concurrent execution.** Transactions are fanned across multiple executors and coroutines in parallel. After a root call completes, NNInt capacity locks reserve its delta batch via atomic compare-and-swap (see [Parallel Execution: How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved)). Which transaction wins a contested lock depends on thread scheduling. This is non-deterministic: two runs of the same transaction set on the same machine can produce different winners.

**The proposer captures nondeterministic outcomes.** Each transaction produces a `NondeterministicProposalData` payload covering proposal-dependent decisions such as capacity reservation outcomes and retrocausal queue observations. This payload is packaged alongside the transaction hashes in the consensus proposal.

**Validators replay deterministically.** Validators receive the proposer’s nominated transaction list and the nondeterministic data. They reconstruct each transaction from their local mempool, pair it with the proposer’s captured decisions, and replay execution using those decisions as input. Validators do not re-run the concurrent race. They verify that the transactions produce the claimed state transitions, recompute the block hash, and confirm it matches.

|                       | Proposer                                                   | Validator                                 |
| --------------------- | ---------------------------------------------------------- | ----------------------------------------- |
| Execution             | Concurrent across executors                                | Deterministic replay with proposer’s data |
| Conflict resolution   | Non-deterministic thread race                              | Reproduced from captured decisions        |
| Transaction selection | Discretionary (from local mempool)                         | Fixed (from nomination)                   |
| Output                | Nomination: tx hashes + nondeterministic data + block hash | Accept or reject the nomination           |

The proposer has discretion over which transactions to include and which conflicting transaction wins. Validators verify the math of the proposed result, not the policy that produced it. Deterministic replay makes the proposed result verifiable. It does not establish proposer fairness; scheduling and transaction selection are separate from validating state transitions.



## Dissemination: Dogwood

Validators exchange three types of data during consensus:

| Data                 | Description                                                               |
| -------------------- | ------------------------------------------------------------------------- |
| **Transactions**     | Signed transactions gossiped between validators                           |
| **Consensus values** | Full block nominations (transactions + metadata)                          |
| **SCP envelopes**    | Protocol messages for agreement (nominate, prepare, confirm, externalize) |

Dogwood is the dissemination layer. It uses **erasure-coded multicast**: data is split into chunks, encoded with redundancy, and broadcast over BFS multicast trees. Receivers can reconstruct the original data from a subset of chunks, reducing bandwidth requirements while tolerating packet loss.

Each data type is tagged and demultiplexed on receipt. Transactions are forwarded to the mempool. Consensus values are cached locally for validation. SCP envelopes are fed to the embedded SCP kernel.



## Finality Model

Under the required quorum assumptions, loss of enough validators can stop progress without invalidating finalized blocks. Incorrect or disjoint trust configurations can violate those assumptions.

Practical implications:

- **No confirmation count.** A confirmed transaction is final. There is no “wait for 6 blocks” or “99.9% probability of finality.”
- **Finalized blocks.** Under the consensus safety assumptions, finalized blocks are not replaced by competing blocks.
- **Halt recovery.** If the network halts due to quorum loss, it resumes from the last committed block once enough validators return. Nodes may need to catch up before participating again.



## Catchup and Repair

Validators that fall behind (new nodes, network partitions, restarts) catch up by fetching missing blocks from peers. The catchup agent requests blocks by height, validates them, and replays them locally.

A separate repair agent handles missing data during active consensus: if a validator receives a hash reference it cannot resolve (a consensus value or SCP envelope it hasn’t seen), it requests the full data from the originating peer.



## Related Documentation

- [Networking](pages/how-it-works/networking.md): Node topology and how the coordinator connects to the mempool
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Parallel Execution](pages/how-it-works/execution-model.md): How transactions execute against snapshots
- [System Overview](pages/how-it-works/architecture.md): The component map

---

## Contract artifacts and addresses

Source: <https://docs.groundhog.dev/how-it-works/contracts/>

Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.

An artifact is compiled contract code. Its code hash identifies that code; a deployment address identifies one instance with its own storage. The same artifact can be deployed at multiple addresses.

This page explains those identities and the rules of deployment. For deployment commands, see [Deploy and call](pages/cli/deploy-and-call.md).

User contracts compile to RV32, Groundhog’s 32-bit RISC-V contract target. Native system contracts and local test mocks serve separate purposes, described below.



## Contract Types



### RV32 Contracts

`groundhog build` compiles the contract’s RV32 entrypoint wrapper for `riscv32im-unknown-none-elf`, lowers that ELF into a deployable `.rv32a` artifact, and finalizes its contract-spec sidecars.

For a crate named `counter`, the default build writes:

```txt
target/groundhog/counter.rv32a
target/groundhog/counter.rv32.json
target/groundhog/counter.spec.xdr
target/groundhog/counter.spec.json
```

The `.rv32a` file is the executable contract artifact. `groundhog deploy` wraps those bytes in the protocol’s `Contract::kRv32` variant before signing and submitting the deploy transaction.

The executor accepts contract code blobs up to 256 KiB. The complete signed transaction also has a 2 MB encoded-size bound, so a deployment transaction must satisfy both limits.



#### Entrypoints

Every callable method is identified by an 8-byte `ContractEntrypointID`. The SDK’s `#[contract]` macro emits one dispatch record per method into a link-time `GROUNDHOG_RV32_ENTRYPOINTS` registry.

When hogd invokes an RV32 contract, it enters the guest at `_start` with the method ID in registers. The RV32 runtime dispatches by scanning the registry, then calls the generated wrapper for the matching method. That wrapper decodes calldata, calls the Rust method, and returns through the Return syscall.

Entrypoint IDs can be arbitrary 8-byte values at the protocol layer. The SDK provides the normal convention: derive a 6-byte interface prefix from the interface name and version, then use a method-specific 2-byte suffix. See [SDK Macros](pages/reference/sdk-macros.md) and the [contract spec reference](pages/reference/contract-spec.md) for the developer-facing shape.



#### Artifact Shape

Most developers should let the [Groundhog CLI](pages/cli/build-and-test.md) produce RV32 artifacts. Under the hood, the RV32 lowerer:

- Parses the `riscv32im-unknown-none-elf` contract binary.
- Validates the layout expected by the Groundhog RV32 runtime.
- Packs code, initial memory, metadata, and section digests into the `.rv32a` artifact.
- Self-verifies the artifact before writing it.

The node executes the lowered artifact through the RV32 runtime. Contract state does not live in guest memory. Durable state must be written through Groundhog storage APIs.



### Native Precompiled Contracts

Native precompiled contracts are implemented directly inside the Groundhog runtime. They are used for trusted system behavior, such as the native token contract, and can have permissions that user-deployed guest contracts do not have.

Users cannot deploy native contracts. Network configuration assigns system contract addresses; implementations are identified by values from `HogexecPrecompiledNativeContracts`.



### Test Mocks

Local test environments can deploy mock contracts that execute host-side test code. Mock contracts are useful for native unit tests and simulation, but they cannot be deployed on chain.



## Contract Deployment

Contracts are deployed by the DeployContract [system call](pages/reference/syscalls.md). In normal CLI usage, `groundhog deploy` invokes the active wallet contract, and the wallet contract calls DeployContract with the artifact hash and deployment nonce.



### Contract Identification

Contracts are identified by the SHA256 hash of the XDR-encoded `Contract` union. For an RV32 artifact, the deploy hash is:

```txt
SHA256(XDR(Contract::kRv32 {
    rv32_contract: ContractBlob {
        data: <.rv32a artifact bytes>
    }
}))
```

This is not just the SHA256 hash of the raw `.rv32a` bytes. The XDR wrapper and `kRv32` type tag are part of the hash preimage.



### DeployContract Syscall

To deploy a contract, the caller invokes DeployContract with two arguments:

- `nonce`: a 32-byte value chosen by the caller
- `contract_hash`: the SHA256 hash identifying the contract artifact to deploy

The system then:

1. Verifies that the contract identified by `contract_hash` is available for deployment.
2. Computes the deployment address: `ContractAddress = SHA256(XDR(ContractDeploymentHashPreimage))`.
3. Writes `AddressMetadata` at the computed address.
4. Stores the contract code separately in the deduplicated contract code store.



### Deterministic Address Derivation

The address to which a contract is deployed is computed from the deployer address, nonce, and contract hash. Anyone can predict the address before deployment.

A single contract artifact can be deployed at many addresses. Each deployment has separate metadata and separate storage.



### Deployment Preimage

```rust
pub struct ContractDeploymentHashPreimage {
    /// Address of the contract performing the deployment.
    pub deployer_address: ContractAddress,

    /// Arbitrary 32-byte nonce chosen by the deployer.
    pub nonce: SHA256Hash,

    /// SHA256 hash of the contract artifact.
    pub contract_hash: SHA256Hash,
}
```

Under XDR encoding, this structure serializes as the concatenation of its fields:

```txt
XDR(ContractDeploymentHashPreimage) = deployer_address || nonce || contract_hash
```



### Example

A wallet contract at address `0x1234...` deploys `counter.rv32a`:

```txt
deployer_address = 0x1234...
nonce            = 0x5678...
contract_hash    = SHA256(XDR(Contract::kRv32 {
                       rv32_contract: ContractBlob { data: bytes(counter.rv32a) }
                   }))
                 = 0xabcd...

ContractAddress  = SHA256(0x1234... || 0x5678... || 0xabcd...)
                 = 0x9999...
```

The deployed counter contract’s address is now `0x9999...`.

This scheme is analogous to Ethereum’s `CREATE2` opcode because the address can be calculated before deployment.



## Deployment Eligibility

To be deployed via DeployContract, a contract identified by `contract_hash` must be available in the context of the current transaction.

A contract is available if either of the following holds:

- The contract code already exists in the on-chain contract code store.
- The contract is included in the `contracts_to_deploy` field of the current transaction.

```rust
pub struct Transaction {
    pub invocation: Invocation,
    pub uniquifier: Uniquifier,

    /// New contract code to make available for deployment.
    pub contracts_to_deploy: VecM<Contract>,

    /// Authorization claim specifying required signatures.
    pub auth_claim: AuthClaim,
}
```

`contracts_to_deploy` makes contract code available, but it does not deploy the code to an address by itself. Deployment to a specific address happens when a contract invokes DeployContract.

Example flow:

1. The transaction includes `contracts_to_deploy: [Contract::kRv32 { rv32_contract: ContractBlob { data: <artifact bytes> } }]`.
2. The contract code becomes available under its `contract_hash`.
3. During execution, a contract calls `DeployContract(nonce, contract_hash)`.
4. The system computes the deployed address and writes its metadata.



## Address Metadata

When a contract is deployed, the system writes `AddressMetadata` to the storage key `(contract_address, StorageKeyType::Metadata)`.

```rust
pub struct AddressMetadata {
    pub deployed_contract: DeployedContractHash,
}

pub struct DeployedContractHash {
    /// SHA256 hash of the contract code.
    pub hash: SHA256Hash,

    /// Size of the contract in bytes.
    pub contract_size: u32,

    /// Runtime contract type.
    pub contract_type: ContractType,
}
```

This metadata allows the executor and off-chain tools to:

- Verify what code is running at an address.
- Determine the contract type without loading bytecode.
- Calculate storage costs from the contract size.

The metadata is set during deployment and persists for the lifetime of the contract address.



## Deployment Concurrency

Multiple transactions may deploy the same contract to the same address in the same block. Groundhog does not consider concurrent deployments of the same contract to the same address to be in conflict. Collision resistance of SHA256 implies that different contracts cannot be deployed to the same address.

If a contract requires one-time initialization, implement that guard in contract storage.



## Redeployment and Immutability

Once a contract is deployed to an address, that address’s `AddressMetadata` cannot be changed. Deployed contracts are immutable.



## Related Documentation

- [Groundhog CLI](pages/cli.md): RV32 builds, local nodes, deployment, and codegen
- [Invocation Frames](pages/how-it-works/invocation-frames.md): execution context and call stack management
- [Syscalls](pages/reference/syscalls.md): system calls available to contracts
- [SDK Macros](pages/reference/sdk-macros.md): SDK entrypoint IDs and generated clients
- [Contract Spec](pages/reference/contract-spec.md): generated method, type, event, and error metadata
- [System Overview](pages/how-it-works/architecture.md): the component map

---

## Parallel Execution

Source: <https://docs.groundhog.dev/how-it-works/execution-model/>

How the engine executes transactions against snapshots and reserves compatible state changes.



## The Core Idea

Every transaction reads from a consistent snapshot and records typed deltas. The storage type determines how those deltas combine.

Commutativity describes operations whose combined result does not depend on their order. Groundhog still enforces resource limits, including gas limits, bounded return values, and a maximum encoded transaction size.

This page explains the engine: snapshots, concurrent reservation, and conflict selection. For the rules your code relies on, read [Contract Execution](pages/programming-model/execution.md).



## Snapshot Isolation

Each transaction sees the ledger as it was at the start of the block. All transactions in a block read from the same snapshot. Ordinary storage reads do not observe other transactions’ writes within that block.

Reads also reflect changes within the current transaction and successful child calls. The database snapshot analogy does not imply identical SQL isolation or conflict rules.

`RetrocausalQueue` also permits observations of concurrent inserts. These are recorded as nondeterministic proposal data and replayed by validators. Its read semantics differ from ordinary snapshot storage.



## Delta Writes

Transactions do not write final values. They produce deltas: descriptions of how to change a value.

Instead of “set balance to 50”, a transaction says “increment balance by 10.” After each root contract call completes, the runtime reserves its delta batch alongside compatible deltas already admitted to the proposed block. The admitted deltas form the next state at commit.

In Solidity, a transfer looks like this:

```solidity
// Solidity: read balances and assign their updated values.
balances[from] = balances[from] - amount;
balances[to] = balances[to] + amount;
```

In Groundhog:

```rust
// Groundhog: write deltas. Two compatible transfers to the same
// account produce two deltas that merge cleanly.
balances.at_mut(&from).decrease(amount);
balances.at_mut(&to).increase(amount);
```

Two compatible increments to the same balance produce the same result regardless of order. `(x + 3) + 5 = (x + 5) + 3`. That is commutativity, and it is why Groundhog can execute transactions in parallel without declared access lists.



## What Commutes and What Doesn’t

Transactions execute concurrently. Storage merge rules determine whether their changes can land together. A conflicting transaction is excluded from the proposal and returned to the mempool.

| Operation                               | Can both changes land? | Why                                                             |
| --------------------------------------- | ---------------------- | --------------------------------------------------------------- |
| Two balance changes on the same counter | When compatible        | Resolved bases must match and aggregate bounds must hold        |
| Two writes to different Map keys        | Yes                    | Independent keys don’t interact                                 |
| Two writes to the same bytestring       | When identical         | Different values conflict                                       |
| Multiple inserts into the same queue    | Yes                    | Entries are sorted; insertion order doesn’t matter              |
| Two deletions of the same key           | Yes                    | Same outcome regardless of order                                |
| A deletion and a write to the same key  | No                     | Different operation types conflict; one transaction is excluded |

These rules describe the listed operations. Other changes in either transaction can still cause a conflict.



### What This Means for Your Data Model

Choose storage around the changes your application needs to combine. Mergeable arithmetic still has bounds; absolute writes can coexist when they store identical values. [Storage Types](pages/programming-model/storage-types.md#choosing-a-type) turns these rules into contract-design choices.



## How Conflicts Are Resolved

The programming model describes a transaction as executing first and then attempting to land its deltas. The engine implements that boundary directly: ordinary storage conflicts are checked after the root contract call returns, before the transaction is committed into the proposed block.



### Concurrent Delta Reservation

Contract execution accumulates writes in the transaction’s `ItemView`. A checked operation such as `Balance::decrease(30)` first loads the snapshot base and can abort immediately if that transaction alone would underflow. A lazy operation skips that load and therefore cannot report a snapshot-bound failure from contract code. Both forms produce an NNInt delta.

After the root call returns successfully, `try_commit_transaction()` submits the transaction’s complete delta batch to hogd. For a lazy `NonnegativeIntAdd`, hogd resolves the set value from the block snapshot. A checked `NonnegativeIntSetAdd` already carries that same snapshot value. Both then use the same NNInt type-class match and aggregate bounds reservation.

For a snapshot balance of 10, the per-key reservation starts with subtraction capacity of 10:

```plaintext
Snapshot: Alice balance = 10
          Subtraction budget = 10

Tx A contract returns with delta -8
      Reserve delta batch: capacity 10 → 2 → admitted

Tx B contract returns with delta -5
      Reserve delta batch: capacity would be -3 → excluded
```

Whichever transaction reserves first wins. The lock is per-key, per-block and is initialized from the snapshot. Reservations on different keys use separate locks. Transactions touching the same key contend for the same aggregate bounds. Reservation can happen concurrently across executor workers; atomic capacity accounting ensures the combined admitted delta remains in range.

For operations that commute (two increases, or two decreases that fit within the balance), both reservations succeed and both transactions land. Checked and lazy operations share this merge behavior. The difference is that checked operations may fail earlier in contract code, while lazy operations leave the snapshot-bound decision to reservation. A lazy adjustment that is invalid against the snapshot can still be admitted if a compatible offsetting delta has already been admitted before its batch is reserved. If the lazy adjustment reserves first, it is excluded. This possibility depends on reservation order, not eventual block-wide netting.



### What Block Close Does

By the time block close runs, all capacity conflicts have been resolved. Block close stages the already-finalized locks into a ChangeSet and computes the block hash. No conflict resolution happens at this stage for Balance, NNInt, Map, Value, or Bytestring operations.

RetrocausalQueue is the exception: it has end-of-block invariant checks that the other storage types do not. RCQ entries from excluded transactions are removed during block finalization.



### Why the Simplified Model Still Holds

From a contract developer’s perspective, the result is the same: your transaction either lands or is excluded. You don’t manage locks, budgets, or reservation order. The programming model (“compatible deltas merge; incompatible transactions are excluded”) is accurate for deciding how to structure your storage. The proposer records reservation-dependent outcomes so validators can replay and verify the proposed block.



## Related reading

- [Contract Execution](pages/programming-model/execution.md): The contract-author model
- [Storage Types](pages/programming-model/storage-types.md): API choices and merge rules
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): Gas limits, scheduling, and deposits

---

## Invocation Frames

Source: <https://docs.groundhog.dev/how-it-works/invocation-frames/>

Execution context, call stack management, and frame lifecycle.

An **Invocation Frame** represents the execution context for a single [contract](pages/how-it-works/contracts.md) method call. A new frame is created:

- When a transaction first starts (the root frame)
- Whenever a contract invokes another contract via the Invoke [syscall](pages/reference/syscalls.md) (a child frame), also known as a [cross-contract call](pages/contracts/cross-contract-calls.md)

Each frame tracks the execution state, resource usage, and state modifications for one contract method invocation. Frames are independent of artifact type. User contracts run on RV32, Groundhog’s 32-bit RISC-V target. The same frame model also covers native contracts and test mocks.



## Frame Structure

An invocation frame contains the following data (pseudocode):

```rust
// Pseudocode - not actual implementation
struct InvocationFrame {
    // Immutable context (set at frame creation)
    contract_address: ContractAddress,
    entrypoint: ContractEntrypointID,     // 8-byte method identifier
    calldata: Vec<u8>,                      // Encoded arguments
    invocation_flags: InvocationFlagSet,  // Behavioral modifiers (e.g., try_invoke, read_only)
                                          // Root frame has no flags set
    max_gas: GasAmount,                   // Capped at parent's remaining gas

    // Mutable state (modified during execution)
    most_recent_child_result: Option<ChildResultState>,  // Result from last child invocation
    deployed_contracts: Vec<(ContractAddress, DeployedContractHash)>,  // Deployments in this frame + committed children
    state_changes: HashMap<AddressAndKey, StorageDelta>,  // Ledger modifications from this frame + committed children
    events: Vec<Event>,  // Events emitted in this frame + committed children
    gas_used: GasAmount,  // Gas consumed so far
}

struct ChildResultState {
    buffer: Vec<u8>,           // Return data from child (empty if **Fault**)
    status: InvocationFrameStatusCode, // **Return**, **Abort**, or **Fault**
}

enum InvocationFrameStatusCode {
    Return = 0,   // Child returned successfully (preserves state)
    Fault  = 1,   // Child hit a **Fault** (discards state)
    Abort  = 2,   // Child **Aborted** (discards state, but returns data)
}

// State changes can be writes, deletes, or other operations
enum StateChange {
    Write_Bytestring(Bytes),
    // Other state operations...
}

type AddressAndKey = (ContractAddress, StorageKey);
```

**Notes:**

- The root frame has no invocation flags set
- Contracts manipulate mutable state via [system calls](pages/reference/syscalls.md)



## Call Stack

Invocation frames are organized as a stack. When a contract invokes another contract, a new frame is pushed onto the stack. When the subinvocation completes, its frame is popped and control returns to the caller.

**Example stack:**

```plaintext
[Root Frame]
  contract: contract_a_address
  entrypoint: 0x1111111111111111

  [Child Frame]
    contract: contract_b_address
    entrypoint: 0x2222222222222222

    [Nested Child Frame]
      contract: contract_c_address
      entrypoint: 0x3333333333333333
```



## Frame Lifecycle

Each invocation frame progresses through five stages:



### 1. Creation

A new frame is created when:

- A transaction begins (root frame)
- A contract calls the Invoke [syscall](pages/reference/syscalls.md) (child frame)

The frame is initialized with:

- Immutable context: contract address, entrypoint ID, calldata, invocation flags, max gas
- Empty mutable state: no child returns, no deployments, no state changes, no events, zero gas used

**Note:** Gas allocated to a child frame is capped at the parent’s remaining gas. The root frame has no invocation flags set.



### 2. Execution

The contract executes in its runtime, RV32 by default, making syscalls to read and write ledger state. All modifications are recorded in the frame’s mutable state.



### 3. Completion

A frame terminates in one of three ways:[1](pages/how-it-works/invocation-frames.md#user-content-fn-termination-syscall)

**a) Fault**

The frame terminates abnormally due to:

- Runtime trap, such as an invalid instruction, bad program counter, bad memory access, breakpoint, or equivalent deterministic guest failure
- Out of gas

When a frame **Faults**: No return buffer, all state changes discarded, gas still consumed

**b) Return**

The contract completes successfully, preserving its state changes.

When a frame **Returns**: Return buffer (may be empty) passed to caller, state changes preserved, gas consumed

**c) Abort**

The contract explicitly aborts its execution, discarding state changes but returning data to the caller.

When a frame **Aborts**: Return buffer passed to caller, state changes discarded, gas consumed



### 4. Merge into Parent (or Finalize for Root)

**For child frames:**

The parent frame is updated:

- Gas: Parent’s `gas_used` increases by child’s `gas_used`

- Result state: Parent’s `most_recent_child_result` is set to child’s result

  - If child hit a **Fault**: status = Fault, buffer = empty
  - If child **Returned**: status = Return, buffer = child’s return buffer
  - If child **Aborted**: status = Abort, buffer = child’s return buffer

State changes:

- If child **Returned**: Parent merges child’s `state_changes`, `deployed_contracts`, and `events` into its own

  - Child writes overwrite parent writes on the same `(ContractAddress, StorageKey)` pair
  - This ensures each frame has at most one delta per storage key
  - Child events are appended to parent’s event list

- If child **Aborted or hit a Fault**: Child’s state changes, deployments, and events are discarded

**For root frame:**

The transaction terminates. The root frame’s `state_changes` map is passed to the conflict checking and commit protocol (see [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)).



### 5. Pop and Return

The frame is removed from the call stack:

- Control returns to the caller (or transaction ends if root frame)
- **All guest execution state is discarded** (memory, registers, stack, program counter)

**WARNING:** Guest memory does not persist across invocation frames. Any data not written to ledger storage is lost when the frame terminates.



## Example: Nested Contract Calls

This example shows contract A calling B, C, and D. A uses recoverable calls and handles C’s abort and D’s fault. A throwing SDK client would instead propagate an unhandled child failure.

**1. Root frame - ContractA.method() created**

Immutable context:

```plaintext
contract: contract_a_address
entrypoint: 0x1111111111111111
calldata: <empty>
flags: (none - root frame has no flags)
max_gas: 1_000_000
```

Initial mutable state:

```plaintext
most_recent_child_result: (none)
deployed_contracts: []
state_changes: {}
gas_used: 0
```

**2. ContractA writes to storage**

ContractA executes a storage write:

```plaintext
state_changes: {
  (contract_a_address, key_0x01): Write_Bytestring('AAA')
}
gas_used: 10_000
```

**3. ContractA calls ContractB - Push new frame**

ContractB frame immutable context:

```plaintext
contract: contract_b_address
entrypoint: 0x2222222222222222
calldata: <empty>
flags: (none)
max_gas: 500_000  // allocated from ContractA's remaining gas
```

ContractB executes and writes to storage:

```plaintext
state_changes: {
  (contract_b_address, key_0x02): Write_Bytestring('BBB')
}
gas_used: 15_000
```

**4. ContractB Returns (preserves state changes)**

ContractB completes successfully, preserving its state:

```plaintext
return_buffer: "success_b"
status: Return
```

ContractA frame updated after ContractB Returns:

```plaintext
most_recent_child_result: { buffer: "success_b", status: Return }
deployed_contracts: []
state_changes: {
  (contract_a_address, key_0x01): Write_Bytestring('AAA'),
  (contract_b_address, key_0x02): Write_Bytestring('BBB')
}  // ContractB's changes merged into parent
gas_used: 25_000  // 10_000 from A + 15_000 from B
```

**5. ContractA calls ContractC - Push new frame**

ContractC frame immutable context:

```plaintext
contract: contract_c_address
entrypoint: 0x3333333333333333
calldata: <empty>
flags: (none)
max_gas: 475_000  // remaining gas from ContractA
```

ContractC executes and writes to storage:

```plaintext
state_changes: {
  (contract_c_address, key_0x03): Write_Bytestring('CCC')
}
gas_used: 20_000
```

**6. ContractC Aborts (discards state)**

ContractC explicitly aborts, discarding its state changes:

```plaintext
return_buffer: "error_c"
status: Abort
```

ContractA frame updated after ContractC Aborts:

```plaintext
most_recent_child_result: { buffer: "error_c", status: Abort }
deployed_contracts: []
state_changes: {
  (contract_a_address, key_0x01): Write_Bytestring('AAA'),
  (contract_b_address, key_0x02): Write_Bytestring('BBB')
}  // ContractC's changes DISCARDED (aborted)
gas_used: 45_000  // gas still consumed
```

**7. ContractA calls ContractD - Push new frame**

ContractD frame immutable context:

```plaintext
contract: contract_d_address
entrypoint: 0x4444444444444444
calldata: <empty>
flags: (none)
max_gas: 455_000
```

ContractD writes to storage:

```plaintext
state_changes: {
  (contract_d_address, key_0x04): Write_Bytestring('DDD')
}
gas_used: 10_000
```

**8. ContractD hits a Fault (unhandled error)**

ContractD hits a runtime trap, such as bad memory access, an invalid instruction, or a breakpoint:

```plaintext
status: Fault
No return buffer
All state changes discarded
```

ContractA frame updated after ContractD hits a Fault:

```plaintext
most_recent_child_result: { buffer: <empty>, status: Fault }
deployed_contracts: []
state_changes: {
  (contract_a_address, key_0x01): Write_Bytestring('AAA'),
  (contract_b_address, key_0x02): Write_Bytestring('BBB')
}  // ContractD's changes DISCARDED (hit a Fault)
gas_used: 55_000  // gas still consumed
```

**9. ContractA makes final storage write**

ContractA writes one more value:

```plaintext
state_changes: {
  (contract_a_address, key_0x01): Write_Bytestring('AAA'),
  (contract_b_address, key_0x02): Write_Bytestring('BBB'),
  (contract_a_address, key_0x05): Write_Bytestring('FINAL')
}
gas_used: 60_000
```

**10. Root frame Returns (ready for reservation)**

ContractA completes successfully. Its deltas still need to pass reservation:

```plaintext
return_buffer: "done"
status: Return
deployed_contracts: []
state_changes: {
  (contract_a_address, key_0x01): Write_Bytestring('AAA'),
  (contract_b_address, key_0x02): Write_Bytestring('BBB'),
  (contract_a_address, key_0x05): Write_Bytestring('FINAL')
}
```

**11. Reservation and commit**

- The root frame’s `state_changes` map is used for reservation and commit
- Each delta is reserved against the block’s accumulated state
- If all reservations succeed, all writes commit atomically to the ledger
- Final ledger state includes AAA, BBB, and FINAL
- CCC and DDD were never committed (ContractC Aborted, ContractD hit a Fault)



## Related Documentation

- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Artifacts and entrypoint IDs
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How transactions progress from submission to commit
- [Syscalls](pages/reference/syscalls.md): How contracts interact with frames
- [Cross-Contract Calls](pages/contracts/cross-contract-calls.md): SDK-level call patterns

1.

   Contracts normally control termination through the Return syscall, which takes an output buffer and a `revert_frame` flag (`false` for Return, `true` for Abort). SDK-generated RV32 entrypoint wrappers use this path. A missing RV32 entrypoint or a wrapper that falls through traps deterministically. The status codes used on this page (`Return = 0`, `Fault = 1`, `Abort = 2`) match `InvocationFrameStatusCode` in `protocol/transaction.x`. [↩](pages/how-it-works/invocation-frames.md#user-content-fnref-termination-syscall)

---

## Networking

Source: <https://docs.groundhog.dev/how-it-works/networking/>

Node topology, component registration, and how transactions reach the mempool.

The [System Overview](pages/how-it-works/architecture.md#components) maps the main components. This page explains how they find each other and communicate.



## Topology

Groundhog’s services are organized into an execution layer and a consensus layer.

The **coordinator** (chuckd, written in Go) sits above the execution layer. It drives consensus with other validators, manages peer topology, and tells the local mempool when to produce and commit blocks.

The **mempool** (scheduler, part of hogd) is the hub of the execution layer. All execution components register with it: executors, DB shards, event server, auth server. The mempool orchestrates block production, transaction execution, and state commits.

Separately, the **RPC gateway** (groundhog-rpc) provides external API access. It connects to the scheduler, indexer, database gateway, and view gateway but does not participate in consensus. It can be scaled independently of the validator.

Within the execution layer, no component discovers peers independently. The mempool is the registry for intra-node communication. When a component registers, it gets back the addresses of everything else it needs to talk to.

Inter-node communication (consensus, transaction gossip) is managed by the coordinator, which maintains its own peer topology via configured quorum sets. The mempool knows nothing about other validators. See [Consensus](pages/how-it-works/consensus.md) for how coordinators find and talk to each other.



## Component Registration

Components register their addresses and readiness with the scheduler. Most use an “intro” RPC; the event server uses a prepare/activate handshake. The scheduler waits for the required components before dispatching work.

Registration interfaces:

1. **DB shards** register via `scheddb_intro_shard`. Multiple shards can register (horizontal storage scaling).
2. **Event server** registers via `schedevent_prepare_event` and `schedevent_activate_event`. One per node.
3. **Executors** register via `schedexec_intro_exec`. Multiple executors can register (parallel transaction execution).
4. **Auth server** registers via `mempoolauth_intro_auth`. Handles transaction signature verification.
5. **Coordinator** registers via `schedulercoord_intro_coord`. Drives consensus and block production.

The listed execution-layer interfaces use XDR-RPC over TCP. Protocol definitions live in `.x` files (XDR IDL) and are compiled to C++ (hogd), Rust (groundhog-rpc), TypeScript, and Go bindings.



## The Mempool as Orchestrator

The mempool (scheduler) is more than a transaction pool. It orchestrates the block lifecycle:

- Receives client transactions directly from the RPC gateway and peer transactions from the coordinator
- Verifies transactions through the auth server
- Maintains per-account transaction queues with balance-proportional scheduling
- Assembles block nominations when the coordinator requests them
- Dispatches transactions to executors for parallel execution
- Collects execution results after executors have submitted their deltas to the database for reservation
- Notifies DB shards of state changes at commit

The coordinator does not execute transactions or manage storage. It asks the mempool “give me a block to propose” and “commit this block.” The mempool handles everything else.



## Coordinator Connection

The coordinator (chuckd) is the consensus participant. It connects to the mempool and drives block production through these RPC calls:

| Call                            | Purpose                                           |
| ------------------------------- | ------------------------------------------------- |
| `schedulercoord_propose_block`  | ”Build a proposal for this block”                 |
| `schedulercoord_validate_block` | ”Is this peer’s proposed block valid?”            |
| `schedulercoord_commit_block`   | ”Finalize this block”                             |
| `schedulercoord_submit_vetted`  | Forward peer-gossiped transactions to the mempool |

The mempool also calls back to the coordinator via a reverse RPC channel to notify it when transactions pass vetting (triggering dissemination to peers).



## External Access

Clients submit transactions and query state through the public gateway.

**JSON-RPC gateway.** A separate service (`groundhog-rpc`) that exposes a JSON-RPC 2.0 API over HTTP. It submits transactions directly to the hogd scheduler. Reads use the scheduler, indexer, database gateway, or view gateway according to the method. The gateway is architecturally separate from the validator. It does not participate in consensus and can be scaled independently. See [JSON-RPC API](pages/reference/json-rpc-api.md) for the method reference.

**Wallet integration.** Wallets sign transactions client-side and submit them through the JSON-RPC gateway. See [Wallet Integration](pages/tools/wallet-integration.md) for the application-facing flow.



## Transaction Flow

Client submissions reach the scheduler through the gateway; peer-gossiped transactions arrive through the coordinator. The coordinator then drives proposal, validation, and commit through the interfaces above. Follow [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) for the complete sequence and its possible outcomes.



## Related Documentation

- [Consensus](pages/how-it-works/consensus.md): How the coordinator reaches agreement with peers
- [Parallel Execution](pages/how-it-works/execution-model.md): How transactions execute against snapshots and produce deltas
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): The six stages from submission to commit
- [System Overview](pages/how-it-works/architecture.md): The component map

---

## Compute, Capacity & Storage

Source: <https://docs.groundhog.dev/how-it-works/storage-economics/>

How HOG provides scheduling capacity and refundable storage deposits, while gas meters execution without a token fee.

Groundhog’s economic model is capital-based, not usage-based. You hold HOG tokens to get capacity. You don’t pay per operation.

HOG has two jobs: providing scheduling capacity and backing stored data.



## The Two Jobs of HOG

Every HOG token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Free HOGs determine how many transactions you can push through the network. Locked HOGs hold your data on-chain. The tradeoff is direct: every HOG you lock for storage is one less HOG contributing to your throughput share.



## Execution: Free, Throughput-Allocated

Running contract code has no token fee. It still uses finite execution and scheduling capacity.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

There is no unused-gas token refund. Metering does not debit or refund the sender’s HOG balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.



### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to free HOG balances over time. If account A holds 1,000 free HOGs and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s free HOGs sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, the transaction’s declared gas limit moves that much HOG capacity from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose HOGs have waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

HOGs cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

HOG transferred between accounts enters the recipient’s scheduling queue as newly received capacity. It does not carry the sender’s accumulated scheduling age.



## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks HOG according to the [storage type](pages/programming-model/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees HOG for other storage or scheduling capacity.



### Cost Accounting

Every contract has a HOG balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts HOG from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked HOG to the contract’s free balance.

If an address does not have enough free HOG to cover a storage change, reservation can fail for insufficient funds. The transaction is excluded from that proposal and returned to the mempool. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.



### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.



### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.



## The Native Token

A sufficient first HOG credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](pages/typescript/accounts.md#request-devnet-funds).

HOG is implemented by a native precompiled token contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting.



## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.



## Related Documentation

- [Contract Execution](pages/programming-model/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](pages/how-it-works/execution-model.md): How compatible state changes are admitted
- [System Overview](pages/how-it-works/architecture.md): The component map
- [Storage Types Reference](pages/reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](pages/get-started/contract.md): Deploy your first contract

---

## Transaction Lifecycle

Source: <https://docs.groundhog.dev/how-it-works/transaction-lifecycle/>

How a transaction moves from submission to committed state.

Submitting a transaction is the start of the process. A successful submission does not prove that the contract call succeeded. Check the committed receipt’s execution result.



## Outcomes to distinguish

| Outcome                       | What it means                                                                                                              |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Rejected before execution** | Admission or authorization failed; the transaction did not reach contract execution                                        |
| **Committed success**         | The transaction is in a finalized block and its contract changes were applied                                              |
| **Committed abort or fault**  | The failure is recorded in the block, but the contract changes are discarded                                               |
| **Excluded from a proposal**  | The transaction did not land in that proposal; conflicting transactions return to the mempool for possible later inclusion |

A pending or `unknown` status, a timeout, or an advisory `recentFailure` is not proof of a committed failure. Keep the original network and transaction hash, and resume observation instead of automatically signing a replacement. See [Track transaction results](pages/typescript/transaction-status.md) for the application workflow.



## Overview

A transaction passes through six stages:

1. **Submission**: Client submits a signed transaction
2. **Authorization**: Signatures are verified before the transaction enters the scheduling queue
3. **Scheduling**: The transaction is queued and selected for a block
4. **Execution and reservation**: Contract code runs against a snapshot, then its completed delta batch is reserved against the proposal
5. **Block Assembly**: The proposer packages results into a block proposal for consensus
6. **Commit**: Finalized state is written to storage



## Stage 1: Submission

The client signs the domain-separated preimage containing the network hash and inner transaction, then submits the signed wrapper through the JSON-RPC gateway. The network hash prevents replay on another Groundhog network. The gateway submits directly to the hogd scheduler.



## Stage 2: Authorization

The mempool sends the transaction to the auth server, which verifies the root address, auth claim, and signatures. Pubkey claims use the public key embedded in the claim. Source-address claims use the root address’s registered authorization data. This happens before the transaction enters the scheduling queue, not during execution.

- If verification succeeds: the transaction enters the scheduling queue
- If verification fails: the transaction is rejected

See [Authorization](pages/how-it-works/authorization.md) for the signature preimage and admission models.



## Stage 3: Scheduling

Verified transactions are queued by account with balance-proportional scheduling. When the coordinator asks for a block proposal, the mempool selects transactions from accounts whose HOGs have waited longest. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md) for how scheduling priority works.



## Stage 4: Execution

Selected transactions execute in parallel against a **consistent snapshot** of the ledger state. All transactions in a block read from the same snapshot taken at the start of block processing.

When contract code executes:

- It reads state values from the snapshot (via syscalls like `BytestringGet`, `NonnegativeIntGet`)
- Ordinary storage reads do not see writes from other transactions in the block; RCQ consumers can observe concurrent inserts
- It produces deltas describing how to modify state
- It runs until termination (return, abort, or fault)

**Conflict checking follows root execution.** If the root call succeeds, the executor submits its completed delta batch for reservation against the proposed block. An incompatible batch is excluded. Contract execution and reservation can both proceed concurrently across executor workers. See [Parallel Execution: How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the mechanism and the distinction between checked and lazy operations.

See [Invocation Frames](pages/how-it-works/invocation-frames.md) for detailed execution semantics (frame lifecycle, child calls, merge/discard rules).



### Root Frame Completion

When the root frame completes, the runtime checks its status:

- **Return (success)**: the transaction’s deltas are submitted for reservation. They are included only if the transaction remains admissible.
- **Deterministic Abort or Fault**: the failure can be included in the block with the contract’s writes discarded. Protocol bookkeeping, including replay protection, is still recorded. Once committed, this is a final execution result, not a transaction waiting to be retried.

This is distinct from **conflict exclusion** during reservation (Stage 4): the root frame may return successfully, but its completed delta batch can still fail reservation and be returned to the mempool for a future block. Deterministic abort and non-deterministic conflict exclusion are two different failure modes with different on-chain semantics.



## Stage 5: Block Assembly

The proposer packages the included transaction results into a consensus proposal: transaction hashes, nondeterministic execution data, and the computed block hash. The proposal is sent to validators via SCP. See [Consensus](pages/how-it-works/consensus.md) for how the proposer/validator split works.



## Stage 6: Commit

Once consensus confirms the block, each validator commits the verified result to its DB shards. The new ledger state becomes the snapshot for the next block.

Transactions excluded during delta reservation (Stage 4) are returned to the mempool and may be re-evaluated in future blocks, subject to scheduling and expiry. Committed aborts and faults remain in the block with their contract changes discarded.



## Related Documentation

- [Invocation Frames](pages/how-it-works/invocation-frames.md): Execution context
- [Authorization](pages/how-it-works/authorization.md): How signatures are verified
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Code hashes and deployment identities

---

## Groundhog

Source: <https://docs.groundhog.dev/>

Build Groundhog contracts and applications with the Rust SDK, CLI, and TypeScript client.



The blockchain built for\
abundance
---------

Groundhog is an early technology preview of a blockchain designed from first principles. Build a contract, try the developer tools, and help shape what comes next.

## Use a coding agent

```text
Help me deploy my first Groundhog contract to Devnet. Follow https://docs.groundhog.dev/get-started/contract/ using the latest CLI. Read groundhog skill show and its contracts reference, and preserve the project settings it generates. If documentation access is blocked, ask me for a saved copy or use groundhog docs. Keep credentials and signing keys out of this conversation. Set up a funded Devnet wallet, create and test a counter, deploy it, initialize it to 10, increment by 5, and verify that its view returns 15. Do not start a local node. Report actual results and any setup or network errors.
```



## Programming model



01 / COMPUTE



### [Keep the logic on-chain](pages/programming-model/execution.md)

Match orders, run an auction, or resolve a game turn alongside the assets it moves. Start with the rules your application needs.

Explore execution



02 / CAPACITY



### [Compute without gas fees](pages/programming-model/execution.md#gas)

Gas meters execution but costs zero tokens. Hold HOG for capacity and fund storage deposits. Execution still has limits.

Understand capacity



03 / CONCURRENCY



### [Build on shared state](pages/programming-model/storage-types.md)

Typed storage lets compatible changes merge while contracts execute in parallel. Use the SDK's balance and collection types.

Choose your storage



## Development resources



FIRST CONTRACT



### [Make something work](pages/tutorials/build-a-counter.md)

Build and test a counter. Learn the contract loop before expanding your idea.



APPLICATIONS



### [Connect an interface](pages/tutorials/work-with-groundhog-from-typescript.md)

Use generated TypeScript bindings to call your contract and read its results.



UNDER THE HOOD



### [Understand the engine](pages/how-it-works/architecture.md)

Explore execution, consensus, and the storage model behind Groundhog.

---

## Contract Execution

Source: <https://docs.groundhog.dev/programming-model/execution/>

The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.

Your contract reads from a frozen snapshot and produces typed storage changes, called deltas. Ordinary storage reads do not see other transactions’ writes. The runtime checks whether each transaction’s deltas can coexist with the other changes landing in the block. Deltas that can coexist form the next committed state. Transactions with conflicting deltas are excluded and returned to the mempool.

This page is the contract-author model. Read it before choosing storage types. It explains the behavior your contract relies on without requiring the engine’s lock and reservation implementation.



## Snapshot Isolation

All transactions in a block read the same committed state from the previous block. Ordinary storage reads do not see another transaction’s writes within the block. Reads include changes made within your transaction, including successful child calls. Other transactions cannot change the snapshot you read.

The shared snapshot is a useful database analogy, but Groundhog has its own typed delta merge rules.

`RetrocausalQueue` has separate observation rules: a consumer can observe concurrent inserts in the same block. The proposer records these observations for validator replay.



## Merged Deltas

A delta describes how one transaction changes a storage location. It is not necessarily an arithmetic difference. The storage type gives the delta its meaning and defines whether it can coexist with other changes to the same location.

For a `Balance`, the delta is an increase or decrease. When you write:

```rust
self.balance.lazy_increase(5);
```

This says “add 5 to the balance.” It does not say “set the balance to 105.”

Suppose two transactions read a balance of 100:

```text
Tx A: lazy_decrease(20)
Tx B: lazy_decrease(30)
Both land: 100 - 20 - 30 = 50
```

Both changes can land because addition gives the same result in either order and the combined debit fits within the balance. We say the operations **commute**, and the runtime can merge their deltas. If the transactions instead try to debit 80 and 30, the combined debit is too large, so one or more transactions are excluded.

Merge rules depend on the storage type:

- `Balance` combines increases and decreases while keeping the committed value non-negative.
- `NNInt` exposes lower-level signed changes and explicit bases.
- Changes to different `Map` keys are independent.
- Two `Value` writes to the same key can coexist only when they store the same value.

In these docs, **compatible deltas** means the storage type allows both changes to land. See [`Balance`](pages/programming-model/storage-types.md#balance) for the ordinary balance API and [NNInt and concurrent updates](pages/programming-model/nnint.md) for the underlying `set_add` rules.



## Block Lifecycle

1. **Read and execute:** your contract reads the block snapshot plus its own changes and successful child calls. It records typed deltas.
2. **Reserve:** after the root call succeeds, the runtime checks whether the complete delta batch can coexist with the proposal’s other changes.
3. **Commit or exclude:** admissible transactions contribute to the finalized block. Conflicting transactions return to the mempool.

Your contract does not control these phases. [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) covers submission through finalization; [Parallel Execution](pages/how-it-works/execution-model.md) explains the reservation machinery.



## Exclusion

From your contract’s perspective, a conflicting transaction simply doesn’t land. Your code runs, produces deltas, and the system determines whether that completed delta batch is compatible with other transactions in the block. Incompatible transactions are excluded and returned to the mempool. See [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the engine-level details.

Your contract writes no retry logic. Client-side, the flow is the same as any other chain: submit a transaction, get a hash, check whether it landed. How conflicts are determined depends on the storage type you choose. See [Storage Types](pages/programming-model/storage-types.md).



## Gas

Transactions and cross-contract calls specify a gas limit. Gas bounds computation, including work in child calls, but costs zero tokens.

For root transactions, the gas limit is the scheduling quantity. The scheduler accounts for the amount you declare whether execution uses all of it or only part of it. If execution exceeds the limit, the transaction faults and its contract changes are discarded.

Unused child-call gas can return to the caller’s execution budget. That is not a token refund and does not change the root transaction’s scheduling amount.

```rust
let client = TokenClient::new(&token_address);
client.with_gas_limit(100_000).transfer(&to, amount);
```

Gas has no token fee, but lower gas limits use less scheduling capacity. Choose a limit that covers execution and design storage operations to avoid unnecessary conflicts.

Groundhog needs no gas price estimation because the token price of gas is zero. Gas usage still matters when choosing an execution limit.



## Throughput

Your free HOG balance provides scheduling capacity. Compatible storage changes do not guarantee inclusion in the next block: admission, capacity, propagation, and expiry still matter. See [Balance-Proportional Scheduling](pages/how-it-works/storage-economics.md#balance-proportional-scheduling) for the allocation rules.



## Storage Costs

The address that owns stored data funds its deposit. The runtime accounts for storage changes; your contract does not calculate the deposit itself. See [Storage: Refundable Deposits](pages/how-it-works/storage-economics.md#storage-refundable-deposits) for funding and cost rules.

Next, [Storage Types](pages/programming-model/storage-types.md) turns this model into concrete API choices.

---

## NNInt and concurrent updates

Source: <https://docs.groundhog.dev/programming-model/nnint/>

The set_add primitive underneath NNInt and why concurrent transactions merge.

`NNInt` is the lower-level signed-integer storage API underneath [`Balance`](pages/programming-model/storage-types.md#balance). This page explains its `set_add` representation and why concurrent transactions can merge safely.

Most contracts should use `Balance` for balances, allowances, and supply. Read this page when you need signed changes, an explicit integer base, or the exact representation that makes checked and lazy balance deltas compatible.

For exact SDK method signatures, see [Rust API Docs](pages/tools/rust-api-docs.md) or [Storage Types Reference](pages/reference/storage-types.md#nnint).



## The set_add Primitive

Every NNInt storage location maintains two pending values during a transaction:

- **set**: `i128`. The absolute base value.
- **add**: `i128`. The accumulated delta.

The low-level operation is `set_add(set_value, add_value)`. It replaces both pending values. The final committed value is `set + add`, subject to overflow, reservation, and floor checks.

Despite the protocol name `NonnegativeInt`, current source allows an explicit negative `set`. The storage invariant is:

```text
value >= min(set, 0)
```

So `set(-5)` may commit `-5`, and `set_add(-5, 10)` may commit `5`. The engine still rejects subtracting from an already-negative explicit base, such as `set_add(-5, -1)`. Use `Balance` for ordinary balances. Use `NNInt` when the state model needs signed changes or an explicit base.

Your contract never calls `set_add` directly. The SDK methods (`strict_inc`, `inc`, `set`) map onto it. But this two-component model is what makes the commutativity rules simple and mechanical.



## The One Rule

Two concurrent `set_add` calls commute **if and only if their resolved set values are equal**.

The set values don’t have to be any particular value. They just have to match each other.

| Tx A              | Tx B                         | Result                                                  |
| ----------------- | ---------------------------- | ------------------------------------------------------- |
| `set_add(S, x)`   | `set_add(S, y)`              | Merge: same base, adds combine to `x + y`               |
| `set_add(100, x)` | `set_add(100, y)`            | Merge: same explicit base, even if snapshot != 100      |
| `set_add(A, x)`   | `set_add(B, y)` where A != B | **Conflict**: different bases, one transaction excluded |

Same base + different deltas = merge. Different bases = conflict. The merged value still has to fit in `i128` and satisfy `value >= min(set, 0)`.



## The None Path

`set_add` also accepts `None` as the set value: `set_add(None, add_value)`. This means “I don’t need to choose the base in this invocation. Let the runtime resolve it from the snapshot.”

The runtime resolves `None` to the start-of-block value internally. This is a performance optimization: it produces the same result as forcing the snapshot read yourself when the key already contains an NNInt, but skips that read in the contract invocation. If the key is absent or not an NNInt, the `None` path resolves to `0`.

Since `None` resolves to the start-of-block value, commutativity depends on what the other transaction does:

| Tx A               | Tx B                                | Commutes? | Why                                                                 |
| ------------------ | ----------------------------------- | --------- | ------------------------------------------------------------------- |
| `set_add(None, x)` | `set_add(None, y)`                  | Yes       | Both resolve to the same start-of-block value. Same effective base. |
| `set_add(None, x)` | `set_add(S, y)` where S = snapshot  | Yes       | None resolves to the snapshot NNInt value. Same effective base.     |
| `set_add(None, x)` | `set_add(S, y)` where S != snapshot | **No**    | Different resolved bases. Conflict.                                 |



## How the API Maps to set_add

| Method              | Effective call                                       | Forces snapshot read? | Commutes?                                               |
| ------------------- | ---------------------------------------------------- | --------------------- | ------------------------------------------------------- |
| `strict_inc(delta)` | `set_add(Some(base), accumulated + delta)`           | Yes                   | Yes, when all callers resolve to the same snapshot base |
| `inc(delta)`        | `set_add(existing_set_or_None, accumulated + delta)` | No                    | Yes, when all callers resolve to the same snapshot base |
| `set(value)`        | `set_add(Some(value), 0)`                            | No                    | Only if all concurrent callers set the same value       |

**strict_inc(delta)**: loads the current base (pending explicit set, snapshot NNInt, or `0` for an empty key), checks that this invocation’s total is nonnegative, then calls `set_add(Some(base), accumulated + delta)`. Aborts immediately if this invocation’s result would be negative. Use this when lower-level integer state needs an early underflow check.

**inc(delta)**: preserves the pending set value if one already exists in this invocation; otherwise calls `set_add(None, accumulated + delta)`. Skips the forced snapshot read. Underflow is caught later by runtime reservation/floor checks when no explicit base has been loaded, which can be harder to debug.

**set(value)**: calls `set_add(Some(value), 0)`. Replaces the base and clears the delta. Negative values are allowed, and a negative set value becomes the floor. `set` commutes only when all concurrent callers set the same value. `set(100)` vs `set(100)` merges. `set(100)` vs `set(200)` conflicts. `set(100)` vs `strict_inc(5)` conflicts if the snapshot is not 100, commutes if it is. Reserve `set` for initialization or admin operations.

`strict_inc` and `inc` are interchangeable from a commutativity standpoint. Mix them freely. The trade-off is read cost vs early underflow detection.



## Negative Set Values

Use a negative base only when the state model needs an explicit lower floor:

```rust
non_negative_int_set(key, -5);
non_negative_int_inc(key, 1);  // The value becomes -4.
```

An increment can move a negative base upward without making the result nonnegative. The commit-time floor remains `value >= min(set, 0)`. `strict_inc`, however, rejects an invocation total that remains negative.

Use `Balance` for ordinary balances and allowances. Use nonnegative NNInt bases for ordinary counters.



## Why This Matters

For NNInt writes that resolve to the same base, transaction ordering does not affect the merged value. The deltas are addition, and addition commutes.

This is what “compatible” means in [Merged Deltas](pages/programming-model/execution.md#merged-deltas): at reservation, the system checks whether all deltas for a given storage location share the same resolved set value. If they do, the adds merge. If they don’t, one transaction is excluded.

Pick the narrowest storage API that fits the state. Use `Balance` for balances and `NNInt` when you need signed changes or explicit bases. The runtime handles their concurrency rules.

---

## Storage Types

Source: <https://docs.groundhog.dev/programming-model/storage-types/>

SDK storage types, their conflict semantics, and how to choose between them.

The SDK storage layer exposes the types you use to model contract state. The type you choose determines whether concurrent writes merge, conflict, or ignore each other. At the protocol level, the primitives are `NNInt`, `Bytestring`, and `RetrocausalQueue`. `Balance` and `CapacityConstraint` provide narrower APIs over the integer primitive. `Map`, `Value`, `Vector`, and `Node` provide typed composition.

This page explains behavior and tradeoffs. For exact method signatures, see [Storage Types Reference](pages/reference/storage-types.md) or [`sdk::storage` Rustdoc](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/storage/index.html).



## NNInt

Integer storage for signed changes that concurrent transactions can combine. Use it for counters or state models that need signed adjustments or an explicit `set`.

```rust
use sdk::storage::NNInt;

#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}
```

Concurrent increments merge automatically:

```rust
// Two transactions run concurrently against the same snapshot:
self.value.strict_inc(5);    // Tx A: "add 5"
self.value.strict_inc(-3);   // Tx B: "subtract 3"
// Both land. Result: original + 2
```

Pass negative values to `strict_inc` to subtract. With a nonnegative base, the runtime prevents concurrent decrements from driving the value below zero. `NNInt` also permits an explicit negative `set`, which changes its commit-time floor. Use `Balance` when negative values and absolute replacement should not be part of the contract API.

See [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the contract-level model. The underlying `set_add` representation and exact commutativity rules are covered in [NNInt and concurrent updates](pages/programming-model/nnint.md).



## Balance

Nonnegative, zero-defaulting storage for balances, allowances, and supply. `Balance` uses `i128` amounts, rejects negative inputs, and exposes no signed adjustment or absolute `set`.

```rust
use sdk::storage::{Balance, Map};

#[derive(Debug)]
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

Each direction has a checked and lazy form:

```rust
let sender = get_caller();

// Load the sender and fail during execution if funds are insufficient.
self.balances.at_mut(&sender).decrease(amount);

// Skip the receiver load and defer its bound check.
self.balances.at_mut(receiver).lazy_increase(amount);
```

All four adjustment methods record deltas that can merge with compatible transactions:

| Method                  | Snapshot base      | Snapshot-bound result                        | Deltas merge? |
| ----------------------- | ------------------ | -------------------------------------------- | ------------- |
| `increase(amount)`      | Loaded if needed   | Overflow detected during contract execution  | Yes           |
| `decrease(amount)`      | Loaded if needed   | Underflow detected during contract execution | Yes           |
| `lazy_increase(amount)` | Not forced to load | Overflow decided during delta reservation    | Yes           |
| `lazy_decrease(amount)` | Not forced to load | Underflow decided during delta reservation   | Yes           |

The `try_` variants report errors that are available during contract execution, so a contract can translate an immediate failure into a domain error. Lazy variants cannot report a snapshot-bound failure that they deliberately did not load. They can still report conversion and transaction-local accumulated-delta errors.



## Map\<K, V>

Key-value store. Different keys are fully independent and never conflict. Same-key behavior follows the value type’s rules.

```rust
use sdk::storage::{Balance, Map};

#[derive(Debug)]
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

```rust
// Different keys: always independent, never conflict
self.balances.at_mut(&alice).lazy_increase(10);  // Tx A
self.balances.at_mut(&bob).lazy_increase(20);    // Tx B, no interaction

// Same key: follows Balance rules (compatible deltas merge)
self.balances.at_mut(&alice).increase(10);       // Tx A
self.balances.at_mut(&alice).lazy_increase(20);  // Tx B, merges to +30
```

Maps can nest: `Map<K, Map<K2, Balance>>` gives composite keys with independent conflict domains at each level. The ERC-20 allowance pattern uses this for owner and spender pairs.



## Bytestring

Raw bytes. Concurrent writes of the same value commute. Concurrent writes of different values conflict.

```rust
use sdk::storage::Bytestring;

#[derive(Debug)]
#[sdk::storage]
pub struct Config {
    owner: Bytestring,
}
```

```rust
self.owner.set(&new_owner);    // Tx A
self.owner.set(&other_owner);  // Tx B -- conflict, one excluded
```

Use Bytestring for config, ownership, or metadata where you accept that concurrent writers to the same location are mutually exclusive. Not for hot paths.



## RCQ\<T> / RetrocausalQueue

Multi-producer queue. Inserts commute; consumption is sequential. Persisted entries are ordered by queue block, then lexicographically within that block. Concurrent observations follow the proposer-recorded order.

```rust
// These two transactions can both land:
self.requests.insert(&entry_a);  // Tx A
self.requests.insert(&entry_b);  // Tx B -- no conflict

// Consumes pull from the front of the queue
let entry = self.requests.try_consume();
```

Use `RCQ<T>` when producers are concurrent but consumers process items in order. Lower-level raw functions are available when you need byte-level control.



## CapacityConstraint

A commit-time limit shared by changes from multiple transactions. Use it when one transaction cannot determine whether a block-wide linear constraint will still hold, such as an aggregate withdrawal limit.

```rust
use sdk::storage::CapacityConstraint;

#[sdk::storage]
pub struct WithdrawalLimit {
    remaining: CapacityConstraint,
}
```

```rust
// Reset at the start of a period.
self.remaining.set_capacity(period_limit);

// Each withdrawal consumes capacity without loading competing withdrawals.
self.remaining.consume_capacity(amount);
```

Consumption is staged on the handle and written when the handle is flushed or dropped. The runtime enforces that the committed remaining capacity does not fall below its floor. `set_capacity` must be the first write to that constraint in the transaction, except that repeating the same value is allowed.



## Vector\<S>

Ordered collection. Each element is an independent storage slot. Internally backed by a `Map<u32, S>` for elements and a length counter.

```rust
use sdk::storage::{Vector, Node, Value};

#[derive(Storage)]
pub struct Item {
    value: Value<u64>,
}

#[derive(Debug)]
#[sdk::storage]
pub struct Registry {
    items: Vector<Node<Item>>,
}
```

```rust
// Push a new element
self.items.push_with(|item| {
    item.value.set(&42);
});

// Read by index (bounds-checked)
let val = self.items.at(0).value.get();

// Mutate by index
*self.items.at_mut(0).value.load_mut() = 99;

// Iterate
for item in &self.items {
    let v = item.value.get();
}
```

Different indices are independent and never conflict (same as Map). Same-index writes follow the element type’s rules. Pushes conflict with other pushes (the length counter is not an NNInt, so concurrent length changes are mutually exclusive).

Use Vector for ordered collections where elements are accessed by index. Wrap compound structs in `Node<T>` so storage derivation works through the nesting. For hot concurrent writes, Map with application-managed keys is more parallelism-friendly than Vector with pushes.



## Value\<T>

Typed storage slot. Stores any CXS-serializable value. Conflict semantics are the same as Bytestring: concurrent writes of the same value commute, different values conflict.

```rust
use sdk::storage::Value;

#[derive(Debug)]
#[sdk::storage]
pub struct Config {
    owner: Value<ContractAddress>,
    threshold: Value<u64>,
}
```

```rust
let owner = self.owner.get();             // read (aborts if unset)
let result = self.threshold.try_get();    // read without aborting
self.owner.set(&new_owner);               // write
*self.threshold.load_mut() = 10;          // read-modify-write
```

Use `Value<T>` for typed single-slot storage. Use `Bytestring` when you need raw byte access or variable-length data without a fixed schema.



## Choosing a Type

| If your write pattern is…                       | Use                | Why                                                            |
| ----------------------------------------------- | ------------------ | -------------------------------------------------------------- |
| Nonnegative balance, allowance, or supply       | Balance            | Nonnegative amounts, zero default, and checked or lazy deltas. |
| Signed delta or explicit integer base           | NNInt              | Signed deltas merge and `set` controls the base.               |
| Block-wide linear limit                         | CapacityConstraint | Concurrent transactions consume shared commit-time capacity.   |
| `INSERT INTO ... (key, value)` with unique keys | Map                | Different keys are independent.                                |
| Ordered list, accessed by index                 | Vector             | Per-element independence. Pushes are exclusive.                |
| Store a typed value                             | Value\<T>          | Typed Bytestring. Same conflict rules.                         |
| `col = absolute_value` (raw bytes)              | Bytestring         | Accept that concurrent writes conflict.                        |
| Append to a log or work queue                   | RCQ\<T>            | Inserts merge, consumers are sequential.                       |



## Exclusive Writes

Use exclusive writes when an operation needs sole write access to a storage location for the duration of a block. Compatible deltas normally merge; an exclusive write prevents concurrent modifications to that key.

- `Value<T>::set_exclusive(&v)`: typed slot, exclusive write.
- `Map::at_mut_exclusive(&key)`: exclusive mutator on a Map entry.
- `NNInt` and `Bytestring` honour the **exclusive keypath flag** set on the field at storage-derivation time, or via the lower-level free functions `non_negative_int_set_exclusive` / `bytestring_set_exclusive`.

```rust
self.config.set_exclusive(&new_value);          // Value<Config>
self.counters.at_mut_exclusive(&owner).set(v);  // Map<_, NNInt>
```

If two concurrent transactions write exclusively to the same key, one is excluded. Mixing exclusive and non-exclusive writes to the same key in the same block excludes the non-exclusive writers. Prefer `Balance` or `NNInt` deltas when the operation can tolerate concurrent updates.



### Lock Requests

An exclusive write requests `ExclusiveLock` after the write succeeds. Later ordinary writes to the key in the same transaction keep the request, including writes from other call frames. The admitted transaction then holds the key’s exclusive lock for the whole block. `clear_flags` withdraws the request.

```rust
self.counters.at_mut_exclusive(&owner).set(0);
self.counters.at_mut(&owner).inc(1);  // The lock request remains.
```

Leaf handles (`Value`, `NNInt`, `Balance`, and `Bytestring`) implement `Flaggable`. Import it with `use sdk::storage::Flaggable;`. `flags()` reads the flags, `set_flags(flags)` adds flags, and `clear_flags()` removes them. Setting flags requires a pending write to that key in the current call frame.

The raw-key functions `storage_flags`, `set_storage_flags`, and `clear_storage_flags` provide the same operations for a `StorageKey`. A reverted frame or failed `try_invoke` discards its flag changes along with its writes. See [Storage Flags](pages/reference/syscalls.md#storage-flags) for the host API.

If `Balance` covers your state model, you do not need its lower-level representation. Read [NNInt and concurrent updates](pages/programming-model/nnint.md) when you need signed changes, an explicit base, or the exact `set_add` commutativity rules. For runtime reservation details, continue to [Parallel Execution](pages/how-it-works/execution-model.md).

---

## Testing

Source: <https://docs.groundhog.dev/programming-model/testing/>

How to test Groundhog contracts: native logic tests, RV32 integration tests, setup, and error matching.



## Test Modes

Choose a test path based on the boundary you need to exercise:

| Command                        | What it covers                                                   | Use for                                            |
| ------------------------------ | ---------------------------------------------------------------- | -------------------------------------------------- |
| `cargo test`                   | Native SDK execution in process                                  | Fast logic tests, error-path assertions, debugging |
| `groundhog test`               | Executor-backed RV32 artifact test                               | Contract artifact behavior without an RPC node     |
| `groundhog test --integration` | Ephemeral `hog-devnode`, deployed RV32 artifact, RPC client path | End-to-end deploy/call tests                       |

Start with `cargo test`, then run `groundhog test` against the RV32 artifact. Add `groundhog test --integration` when you need to test the same path a partner or app will use: build artifact, local node, deployment, signing profile, RPC URL, and generated client behavior.

`groundhog test --integration` builds and deploys RV32, the normal user-contract runtime.

Fresh projects include the integration target and host-only dependencies. The CLI can acquire a compatible catalog-pinned `hog-devnode`; use `groundhog toolchain list` to inspect it. `GROUNDHOG_DEVNODE_BINARY` selects an explicit matching source build.



## What the Scaffold Gives You

The `counter` and `stub` templates include:

```text
build.rs
tests/
  integration.rs
```

`tests/integration.rs` starts with one ignored RPC smoke test. It checks that the CLI provided a deployed contract, connects to the ephemeral node with `groundhog-json-rpc-client`, and calls `chainTip`. Replace or extend the final placeholder with assertions for your contract.

The starter remains ignored under ordinary `cargo test`, even if you explicitly enable its feature. `groundhog test --integration` enables the feature and sets `GROUNDHOG_INTEGRATION_TEST=1`, which lets the scaffold’s `build.rs` activate the live test. You can rename the module and test functions without changing how activation works.

The generated `groundhog-integration-test` feature enables the optional RPC client and Tokio dependencies. Their target-specific Cargo entries keep them out of RV32 guest builds. Preserve the SDK and RPC versions selected together by the scaffold.

The generated `build.rs` contains:

```rust
fn main() {
    println!("cargo:rerun-if-env-changed=GROUNDHOG_INTEGRATION_TEST");
    println!("cargo:rustc-check-cfg=cfg(groundhog_integration_runner)");

    if std::env::var("GROUNDHOG_INTEGRATION_TEST").as_deref() == Ok("1") {
        println!("cargo:rustc-cfg=groundhog_integration_runner");
    }
}
```

> **tip: Projects created with an older scaffold**
>
> Compare with a fresh scaffold, then add `tests/integration.rs`, its feature and host-only dependencies, and the integration activation logic from `build.rs`. If your project already has a build script, merge the activation lines into its existing `main` function. The CLI exits with `integration_test_not_found` when the test target is absent.



## Test Setup

Your `lib.rs` must include `sdk::declare_mock_contract!()` to generate the `register_mock_contract` function used in tests:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;
pub use implementation::*;
```



## Basic Pattern

```rust
use sdk::*;

use my_counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            client.increment(5);
            assert_eq!(client.get(), 15);
        })
    })
    .assert_success();
}
```

Breaking this down:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()`.
3. **`*test_contract.as_hash()`** copies the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from, and `.run(closure)` executes the closure in a simulated execution context. The returned `TransactResult` records the outcome, return value, and emitted events. `.assert_success()` panics with details if the transaction did not commit.
5. **`deploy_contract`** deploys the contract and returns its address. The nonce makes the address deterministic.
6. **`CounterClient::new`** creates a typed client. Methods return values directly.



## `no_cost` vs `default`

Use [`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost) for most contract logic tests. It disables storage cost enforcement, which keeps tests focused on method behavior, storage mutations, events, and expected exceptions.

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) when the test should exercise the normal storage cost model. This is useful for storage-token behavior, deployment cost checks, or tests that should fail when the caller has not been funded correctly.

Use `TestEnvironment::new(Some(&model))` when the test is specifically about a custom `StorageCostModel`. Use `setup_grant_storage_tokens` to fund accounts in cost-sensitive tests.

For the full generated API, see the [`TestEnvironment` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html) or [Rust API Docs](pages/tools/rust-api-docs.md).

When a native test needs a custom transaction context, start with `env.transaction()`. The builder currently supports replacing the default authorization claim:

```rust
let result = env
    .transaction()
    .with_auth_claim(auth_claim)
    .transact(|tx| tx.call(&caller).run(|| {
        // contract calls
    }));
```

Finish the builder with `transact` for auto-commit, `transact_manual` for explicit commit or abort control, or `build` to obtain a `MockTransactionHandler` directly. Plain `env.transact(...)` remains the shorthand for the default transaction configuration.

Use `groundhog test --integration` when the thing under test is not just contract logic: local node startup, RV32 artifact deployment, profile resolution, signing, RPC environment variables, or generated off-chain client behavior.



## Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
use my_counter::{CounterClient, register_mock_contract};

assert_eq!(
    client.try_decrement(10).unwrap_err().try_as(),
    Some(LibraryExn::NonNegativeIntUnderflow),
);
```

The `try_decrement` method (generated alongside `decrement` by the `#[contract]` macro) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`, which is the same for every client: a caught exception stays undecoded inside it, and `try_as` decodes it as whichever exception type you name. When more than one type is of interest, `match_exn!` matches several in one place. See [Handle errors](pages/contracts/errors.md) for the full error model.



## Integration Test Environment

`groundhog test --integration` runs `tests/integration.rs` against an ephemeral `hog-devnode`. The CLI builds and deploys the selected artifact, then sets:

| Variable                     | Value                                       |
| ---------------------------- | ------------------------------------------- |
| `GROUNDHOG_INTEGRATION_TEST` | `1`; activates the scaffolded live test     |
| `GROUNDHOG_RPC_URL`          | RPC URL for the ephemeral node              |
| `GROUNDHOG_CONTRACT_ADDRESS` | Deployed contract address                   |
| `GROUNDHOG_PROFILE`          | `integration`                               |
| `GROUNDHOG_DEFAULT_KEY`      | Lowest-index `local_user`, normally `dev-1` |
| `GROUNDHOG_RUNTIME_MANIFEST` | Runtime manifest path, when available       |

The full run is:

1. Build the RV32 artifact.
2. Start an isolated local node.
3. Deploy it with the runtime’s lowest-index `local_user`, normally `dev-1`. `dev-0` remains reserved for the local faucet.
4. Enable `groundhog-integration-test` and run only the `integration` Cargo test target with the environment above.
5. Shut down the node after the test run, including after test failures.

Normal test-harness controls such as `--match-test`, `--skip`, `--show-output`, `--no-capture`, and `--test-threads` apply to integration tests. `--watch` and `--rerun` cannot be combined with `--integration` yet.

Integration tests use the same RV32 artifact path as normal builds and deployments.



## Named Addresses

`ContractAddress::named("alice")` produces a deterministic address from a string. Same name always returns the same address. The method hashes the name with SHA-256 at runtime, so it cannot initialize a `static` or `const`. Bind it inside the test or a `LazyLock` instead:

```rust
#[test]
fn transfer_between_known_addresses() {
    let alice = ContractAddress::named("alice");
    let bob   = ContractAddress::named("bob");
    // ...
}
```

The `Named` trait that provides this method is re-exported through `sdk::*` when the `dev` feature is enabled.

---

## Read balances

Source: <https://docs.groundhog.dev/react/balances/>

Read native HOG and token balances for a connected account or an explicit address.

Use `useBalance` for native HOG and `useTokenBalance` for a standard ERC-20 contract. Both return query state, a `queryKey`, and data containing `rawBalance` and `height`.



## Follow the connected account

```tsx
import { formatUnits } from "@groundhogchain/client";
import { useBalance } from "@groundhogchain/react";

export function NativeBalance() {
  const balance = useBalance();
  if (balance.isLoading) return <p>Loading balance…</p>;
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Connect a wallet on this network to see its balance.</p>;
  return <p>{formatUnits(balance.data.rawBalance, 7)} HOG</p>;
}
```

With no address, the hook follows the selected account only while the wallet is connected to the application’s network. Account changes select a different query rather than displaying the previous account’s balance.



## Read an explicit address

Pass an address to read without wallet permission:

```tsx
import { formatUnits } from "@groundhogchain/client";
import { useTokenBalance, type BalanceAddress } from "@groundhogchain/react";

export function TokenBalance({ token, owner, decimals }: {
  token: BalanceAddress;
  owner: BalanceAddress;
  decimals: number;
}) {
  const balance = useTokenBalance({ token, address: owner });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Loading token balance…</p>;
  return (
    <p>{formatUnits(balance.data.rawBalance, decimals)} at block {balance.data.height.toString()}</p>
  );
}
```

Addresses accept hex strings or SDK-branded bytes. Equivalent inputs share a key. The hook does not fetch token metadata or choose decimals; supply those from the application or a metadata read. HOG has seven decimals.



## Handle missing inputs

| Input                          | Behavior                                                               |
| ------------------------------ | ---------------------------------------------------------------------- |
| Omitted or undefined `address` | Resolve the connected account on the app’s network                     |
| Explicit address               | Read even while disconnected or while the wallet is on another network |
| `address: null`                | Disable account resolution and fetching                                |
| Missing or null `token`        | Disable token fetching                                                 |

Missing-input queries are idle with `isLoading: false`. Invalid addresses surface through query error state.



## Set refresh behavior

Pass options through `query`, for example `{ staleTime: 10_000, refetchInterval: 15_000 }`. The balance hooks also support retry, garbage-collection, focus/reconnect, and `select` options. Defaults come from your QueryClient and TanStack Query.

Abandoned balance results are discarded, but their underlying RPC may still finish. Use [Cache and refresh data](pages/react/queries.md) for polling, reusable query options, and invalidation after writes.

---

## Read events

Source: <https://docs.groundhog.dev/react/events/>

Use the public client and TanStack Query to display typed contract events in React.

Compose the TypeScript client’s event actions with TanStack Query. Generated bindings provide filtering and decoding; React components provide loading, empty, error, and refresh states.



## Display recent HOG transfers

```tsx
import { toHex0x } from "@groundhogchain/client";
import { groundhog_erc20_if } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { getClientQueryKey, useClient } from "@groundhogchain/react";
import { useQuery } from "@tanstack/react-query";

const { TransferEvent } = groundhog_erc20_if.v0_1.events;

export function RecentTransfers() {
  const client = useClient();
  const transfers = useQuery({
    queryKey: [...getClientQueryKey(client), "app", "recent-hog-transfers"],
    queryFn: ({ signal }) => client.getContractEvents({
      event: TransferEvent,
      contractAddresses: [HOG_ADDRESS],
      order: "descending",
      limit: 20,
    }, { signal }),
    staleTime: 10_000,
  });

  return (
    <section aria-label="Recent HOG transfers">
      {transfers.isLoading ? <p>Loading transfers…</p> : null}
      {transfers.error ? <p role="alert">{transfers.error.message}</p> : null}
      {transfers.data?.events.length === 0 ? <p>No transfers in this page.</p> : null}
      <ul>
        {transfers.data?.events.map(event => (
          <li key={`${toHex0x(event.txHash)}:${event.sequenceNumber}`}>
            {event.fields.amount.toString()} base units at block {event.blockHeight.toString()}
          </li>
        ))}
      </ul>
      <button disabled={transfers.isFetching} onClick={() => void transfers.refetch()}>
        Refresh transfers
      </button>
    </section>
  );
}
```

The query has fixed contract, event, ordering, and page-size inputs. If you make them configurable, include each input in the key. Include a cursor when caching separate historical pages.



## Choose a history workflow

Refreshing the example starts at the head again. A saved cursor continues an older historical walk; it is not a subscription. Use the TypeScript [event pagination guidance](pages/typescript/events.md) for iteration and durable checkpoints.

For live refresh, choose an explicit polling policy. Query caching does not create a background indexer or save progress across reloads.



## Decode transaction events

A receipt returned by an execution or receipt hook contains events. Use a generated descriptor’s `allFromReceipt` or `singleFromReceipt` with the emitting contract address.

A committed receipt can report failed execution. Check the result before treating its events as successful application activity. See [Track transaction results](pages/react/transaction-status.md).

---

## React

Source: <https://docs.groundhog.dev/react/>

Use Groundhog's React provider and hooks for wallets and contract data.

Build wallet controls and contract-data interfaces with `@groundhogchain/react`. The library supplies state and hooks; you supply the components, styling, and application workflow.



## How the layers fit

- The **TypeScript client** connects to a network and executes typed contract operations.
- **WalletProvider** shares that client and manages wallet discovery, connection, and account selection.
- **TanStack Query** manages read state, caching, and mutations through your application’s `QueryClient`.
- **Contract bindings** describe each contract’s methods, results, errors, and events.

The library manages one configured application network and one selected wallet connection. Public reads work without wallet permission. A connected wallet supplies the signing client for writes.



## Start with a read

The [React quickstart](pages/get-started/react.md) displays Devnet’s HOG supply using the supplied ERC-20 binding and contract address. You do not need Rust, the CLI, or your own deployment.

For an existing app, follow [Setup](pages/react/setup.md) and [Providers and clients](pages/react/providers.md). Then use [Read contract data](pages/react/reads.md) or [Read balances](pages/react/balances.md). [Cache and refresh data](pages/react/queries.md) explains the query behavior shared by those hooks.



## Add wallet actions

[Connect a wallet](pages/react/wallets.md) covers discovery, account selection, and connection states. [Send transactions](pages/react/transactions.md) and [Track transaction results](pages/react/transaction-status.md) cover the approval-to-receipt flow.

Use the [TypeScript account model](pages/typescript/wallet-clients.md) for shared signing concepts and the [React API reference](pages/react/reference.md) for exact hook inputs and results. Complete application walkthroughs belong in [Guides](pages/guides.md).

---

## Providers and clients

Source: <https://docs.groundhog.dev/react/providers/>

Understand the React contexts, public and signing clients, and their lifetimes.

The [setup page](pages/react/setup.md) mounts two contexts. They have different responsibilities:

| Provider              | Responsibility                                                                                  |
| --------------------- | ----------------------------------------------------------------------------------------------- |
| `WalletProvider`      | Public client, wallet discovery, authorized session, selected account, signing-client lifecycle |
| `QueryClientProvider` | Read cache, query state, refresh policies, and mutations                                        |

`WalletProvider`, `useClient`, `useWallet`, and `useWalletClient` work without TanStack Query context. Balance, contract-view, receipt, and execution hooks require both providers.

The React `WalletProvider` is a context component. A discovered wallet provider is the external wallet object that handles permission and signing requests. See [Accounts and wallet clients](pages/typescript/wallet-clients.md) for that shared model.



## Use the public client

`useClient()` returns the initialized client supplied to `WalletProvider`. It remains available while disconnected and stays on the application’s network when the wallet changes networks.

Use it with SDK actions or [custom queries](pages/react/events.md). Contract reads do not require a connected wallet.

Choose a cluster or pin its identity through the TypeScript [network configuration](pages/typescript/connect.md), then supply that cluster-validated client to `WalletProvider`.

Configure HTTP timeouts and batching through the [client transport](pages/typescript/transport.md). Configure caching and refresh behavior through [TanStack Query](pages/react/queries.md).



## Use the signing client

`useWalletClient()` returns the current provider-backed signing client, or `null` when unavailable. `useWallet()` exposes the connection state and selection actions.

Enable writes only when `wallet.status === "connected"`. An account address can still be present in a wrong-network session, so an address alone is not evidence that signing is available.

The provider owns the signing client’s lifecycle. Session changes invalidate the old binding immediately and create a fresh binding after event dispatch when the session is valid. Use the current hook result for new operations.



## Keep identities stable

Create the public client and `QueryClient` once for the application’s lifetime. Replacing the public client starts a disconnected wallet lifecycle, even when the new client points to the same network. Reads through different client instances have separate cache identities.

Unmounting `WalletProvider` disposes its signing binding without revoking remote permission. The user’s [Disconnect action](pages/react/wallets.md) requests permission revocation. Calling the current signing client’s `dispose()` also clears the local React connection.



## Use a client-rendered boundary

In a server-rendered framework, initialize the client and mount these providers in the application’s client-rendered boundary. Server rendering starts disconnected; browser discovery runs after mounting.

Groundhog query keys contain in-memory client identities. Use them within one query-cache lifetime, not as persisted keys or server-to-browser hydration identifiers. See [Cache and refresh data](pages/react/queries.md) for cache scope and reusable query factories.

---

## Cache and refresh data

Source: <https://docs.groundhog.dev/react/queries/>

Share query results, reuse query factories, and refresh the original data after a transaction.

Groundhog query hooks use your application’s TanStack Query cache. Keep the public client and QueryClient stable so components reading the same inputs can share data and in-flight requests.



## Understand cache scope

Keys include network and public-client instance identity. Balance keys also include owner and token where applicable. Contract-view keys include the method decoder, target, encoded arguments, and caller.

Different client instances do not share cached reads, even on the same network. Use the `queryKey` returned by a hook or factory rather than constructing a library-owned key yourself.

`staleTime` controls when data becomes stale. Polling and post-transaction invalidation are explicit application choices. Independent queries do not guarantee a common read height.



## Reuse query options

Factories work outside components when given an initialized client and explicit inputs:

```ts
import type { ConnectedGroundhogClient } from "@groundhogchain/client";
import { tokenBalanceQueryOptions, type BalanceAddress } from "@groundhogchain/react";
import type { QueryClient } from "@tanstack/react-query";

export function prefetchBalance(
  queries: QueryClient,
  client: ConnectedGroundhogClient,
  owner: BalanceAddress,
  token: BalanceAddress,
) {
  return queries.prefetchQuery(tokenBalanceQueryOptions({
    client,
    address: owner,
    token,
    query: { staleTime: 10_000 },
  }));
}
```

The same client and inputs produce the key used by `useTokenBalance`. Factories also exist for native balances, contract views, and receipts.

Balance factories do not resolve the connected wallet. Missing inputs produce a skipped query for hook use; call imperative `fetchQuery` or `prefetchQuery` only when inputs are present. `enabled` controls observers, not imperative fetching. `select` transforms observer data, not the cache’s raw data.



## Read a dynamic list

Use one balance component per token, or compose factory options with `useQueries`:

```tsx
import { toHex0x } from "@groundhogchain/client";
import { useQueries } from "@tanstack/react-query";
import { tokenBalanceQueryOptions, useClient, useWallet, type BalanceAddress } from "@groundhogchain/react";

export function TokenBalances({ tokens }: { tokens: BalanceAddress[] }) {
  const client = useClient();
  const wallet = useWallet();
  const tokenKeys = tokens.map(token => typeof token === "string" ? token.toLowerCase() : toHex0x(token));
  const balances = useQueries({
    queries: tokenKeys.map(token => tokenBalanceQueryOptions({
      client,
      address: wallet.status === "connected" ? wallet.address : null,
      token,
      query: { staleTime: 10_000 },
    })),
  });

  return (
    <ul>
      {balances.map((balance, index) => (
        <li key={tokenKeys[index]}>
          {balance.isLoading ? "Loading…" : balance.error ? balance.error.message : balance.data?.rawBalance.toString() ?? "No balance loaded"}
        </li>
      ))}
    </ul>
  );
}
```

Pass a list of unique tokens. These are independent queries, not one atomic read or a concurrency-limited batch. Use a grouped application query and check heights when several values must describe the same snapshot.



## Refresh after a write

After observing a committed transaction, invalidate the key for the account and token that operation affected:

```ts
import type { QueryClient } from "@tanstack/react-query";
import type { BalanceQueryKey } from "@groundhogchain/react";

export function refreshBalance(queries: QueryClient, originalKey: BalanceQueryKey) {
  return queries.invalidateQueries({ queryKey: originalKey, exact: true });
}
```

Capture the original key when starting the operation. An account change while waiting should not redirect the refresh to the newly selected account. Invalidating a query requests another read; check its height when the application needs post-transaction state.

For custom queries, append an application namespace and every read input to `getClientQueryKey(client)`. Canonicalize byte arrays and bigints into stable strings. [Read events](pages/react/events.md) shows a custom query with fixed inputs.



## Keep persistence separate

Query keys contain in-memory identities and are not portable across server/browser processes or persisted cache sessions. Store application records, such as pending transaction hashes and their networks, separately from the query cache. See [Track transaction results](pages/react/transaction-status.md).

---

## Read contract data

Source: <https://docs.groundhog.dev/react/reads/>

Display a typed contract view with loading, error, data, and refresh states.

`useContractView` reads a generated method descriptor and infers its arguments and result. Mount the [application providers](pages/react/setup.md) first.



## Display HOG supply

Use this as `src/App.tsx`. The binding and deployed address are supplied by the SDK packages:

```tsx
import { formatUnits } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { useContractView } from "@groundhogchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    contract: HOG_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>HOG supply</h1>
      {supply.isLoading ? <p>Reading the contract…</p> : null}
      {supply.error ? <p role="alert">{supply.error.message}</p> : null}
      {supply.data ? (
        <>
          <p>{formatUnits(supply.data.value, 7)} HOG</p>
          <p>Read at block {supply.data.height.toString()}</p>
        </>
      ) : null}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

No wallet, signer, or new deployment is needed. The result retains `value`, `height`, and simulated `events`.



## Pass method arguments

For a method with arguments, pass its generated argument object:

```tsx
import type { ContractAddress } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { useContractView } from "@groundhogchain/react";

export function RawBalance({ owner }: { owner: ContractAddress }) {
  const balance = useContractView({
    method: ERC20.v0_1.getBalanceOf,
    contract: HOG_ADDRESS,
    args: { addr: owner },
  });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Reading balance…</p>;
  return <p>{balance.data.value.toString()} base units</p>;
}
```

Pass `caller` when a view needs simulated caller context. It does not authorize a transaction. Custom contracts use their own [generated bindings](pages/tools/typescript-bindings.md).



## Control when a read runs

`enabled: false` disables automatic reads and retains cached data. `staleTime` controls freshness. Arguments must still be valid: the hook encodes them while constructing the query, even when disabled. Mount a read component only after required inputs are ready.

Keep generated descriptors stable. Cache identity includes the client, method decoder, contract, encoded arguments, and caller. Equivalent argument values share a query; changing an input selects a different query.



## Handle refresh and cancellation

Use `isLoading` for the first active fetch and `isFetching` for any active fetch, including refresh. A disabled query can be pending without loading. Display read errors separately from cached data when a refresh fails.

Query cancellation aborts contract-view requests and ignores late results from custom transports. Independent views can use different snapshots. After a write, check that a view has reached the receipt’s height before treating its data as post-transaction state.

---

## React API reference

Source: <https://docs.groundhog.dev/react/reference/>

Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.

| Entry point                                                  | Purpose                                                                                               |
| ------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------- |
| `@groundhogchain/react`                                      | All public React exports below                                                                        |
| [Setup](pages/react/setup.md)                                | Installation and context wiring                                                                       |
| [TypeScript client reference](pages/tools/typescript-sdk.md) | Shared SDK concepts and operations; use the client supported by the React package’s peer dependencies |
| [React source](https://github.com/groundhogchain/react)      | Public declarations and implementation                                                                |



## WalletProvider

| Prop               | Type / behavior                                                                     |
| ------------------ | ----------------------------------------------------------------------------------- |
| `client`           | Initialized `ConnectedGroundhogClient` with validated cluster identity; keep stable |
| `children`         | `ReactNode`                                                                         |
| `discoveryTarget?` | `EventTarget`; browser default is `window` after mounting                           |

| Context behavior   | Rule                                                                        |
| ------------------ | --------------------------------------------------------------------------- |
| Scope              | One application network and selected wallet connection                      |
| Discovery          | Automatic after mounting; first provider selected without prompting         |
| Connection         | Explicit; no automatic reconnect or persisted connection                    |
| Client replacement | Dispose binding and start disconnected, including same-network replacements |
| Server rendering   | Disconnected initial state; browser discovery after mount                   |
| Usage              | [Providers and clients](pages/react/providers.md)                           |



## Wallet hooks

| Hook                | Result                                                           |
| ------------------- | ---------------------------------------------------------------- |
| `useClient()`       | The configured public client, including while disconnected       |
| `useWallet()`       | `WalletConnection`: reactive state and stable connection actions |
| `useWalletClient()` | Current provider-backed signing client or `null`                 |
| Context requirement | `WalletProvider`; no QueryClient required for these three hooks  |



### WalletConnection

| Field / action               | Meaning                                                                    |
| ---------------------------- | -------------------------------------------------------------------------- |
| `providers` / `provider`     | Discovered providers and selected provider                                 |
| `session`                    | Validated network and authorized accounts, or `null`                       |
| `account` / `address`        | Selected wire account and canonical hex address, or `null`                 |
| `networkHash`                | Expected application network, without `0x`                                 |
| `status`                     | `disconnected`, `connecting`, `connected`, `disconnecting`, `wrongNetwork` |
| `error`                      | Latest connection/selection error, or `null`                               |
| `connect()` / `disconnect()` | `Promise<void>`; request failures appear in `error`                        |
| `selectProvider(id)`         | Select a discovered provider without prompting                             |
| `selectAccount(address)`     | Select an authorized account and recreate the binding                      |
| Usage                        | [Connect a wallet](pages/react/wallets.md)                                 |



## Contract reads

| API                               | Inputs / result                                                                            |
| --------------------------------- | ------------------------------------------------------------------------------------------ |
| `useContractView(input)`          | Generated `method`, `contract`, typed `args`, optional `caller`, `enabled`, `staleTime`    |
| `contractViewQueryOptions(input)` | Same inputs plus explicit initialized `client`; reusable TanStack options                  |
| Result                            | Query state and `queryKey`; data is `ContractView<R>` with `value`, `height`, and `events` |
| Defaults                          | `enabled: true`, `staleTime: 0`; other query behavior follows the QueryClient              |
| Key                               | Client/network, decoder identity, contract, entrypoint, encoded arguments, caller          |
| Cancellation                      | Abort the view request and discard late results                                            |
| Validation                        | Arguments are encoded while constructing the query, even when disabled                     |
| Usage                             | [Read contract data](pages/react/reads.md)                                                 |



## Balances

| API                                             | Inputs / result                                                                    |
| ----------------------------------------------- | ---------------------------------------------------------------------------------- |
| `useBalance({ address?, query? }?)`             | Native HOG balance                                                                 |
| `useTokenBalance({ token?, address?, query? })` | Standard ERC-20 balance                                                            |
| `BalanceAddress`                                | Hex string or SDK-branded address bytes                                            |
| `BalanceData`                                   | `{ rawBalance: bigint; height: bigint }`                                           |
| Hook result                                     | TanStack Query state plus `queryKey`; `query.select` can change observer data type |
| Omitted `address`                               | Connected account on the application’s network                                     |
| Explicit address                                | Read without wallet permission                                                     |
| Null address / missing token                    | Skip fetching                                                                      |
| Invalid address                                 | Query error state                                                                  |
| Cancellation                                    | Discard abandoned results; underlying balance RPC may finish                       |
| Usage                                           | [Read balances](pages/react/balances.md)                                           |



### Balance query options

| Option                                                         | Behavior                                                     |
| -------------------------------------------------------------- | ------------------------------------------------------------ |
| `enabled`                                                      | Control automatic observer fetching                          |
| `staleTime`, `gcTime`                                          | Freshness and cache retention                                |
| `refetchInterval`, `refetchIntervalInBackground`               | Explicit polling                                             |
| `refetchOnMount`, `refetchOnReconnect`, `refetchOnWindowFocus` | Refresh triggers                                             |
| `retry`, `retryDelay`                                          | Read retry policy                                            |
| `select`                                                       | Transform observer data; cache remains raw `BalanceData`     |
| Key / fetch function                                           | Owned by the library; not configurable through these options |



## Transaction execution

| API / field                | Behavior                                                                          |
| -------------------------- | --------------------------------------------------------------------------------- |
| `useExecute()`             | TanStack mutation through the current wallet                                      |
| `ExecuteVariables.request` | SDK `PrepareExecutionRequest`: inner invocation, root budget, transaction options |
| `ExecuteVariables.options` | Required `onSigned`; optional `wait` observation controls                         |
| `mutate(variables)`        | Start from an event handler; expose mutation state                                |
| `mutateAsync(variables)`   | Await execution; rejects on failure                                               |
| Successful data            | `{ txHash, receipt }` after successful committed execution                        |
| Retry                      | Always disabled by the hook                                                       |
| Invalidation               | Application-owned; no automatic balance refresh                                   |
| Typed child results        | Use the signing client’s `executeCallsAndWait`                                    |
| Usage                      | [Send transactions](pages/react/transactions.md)                                  |



## Receipt observation

| API / option                                      | Behavior                                                                        |
| ------------------------------------------------- | ------------------------------------------------------------------------------- |
| `useWaitForTransactionReceipt({ hash?, wait? }?)` | Public observation; wallet connection not required                              |
| `hash`                                            | Hex string; `null` or `undefined` skips fetching                                |
| `wait.timeoutMs` / `pollingIntervalMs`            | SDK observation settings; configure consistently for the same hash              |
| Data                                              | `TransactionReceipt`, including failed committed execution                      |
| Query error                                       | Observation failure, not proof of failed execution                              |
| `queryKey`                                        | Client/network-scoped canonical hash                                            |
| Defaults                                          | Infinite stale time; no query retry, focus/reconnect refetch, or retry on mount |
| Cancellation                                      | Cancels observation, never the transaction                                      |
| Usage                                             | [Track transaction results](pages/react/transaction-status.md)                  |



## Query factories and keys

| Export                           | Inputs / purpose                                                                         |
| -------------------------------- | ---------------------------------------------------------------------------------------- |
| `balanceQueryOptions`            | Explicit client, address, optional balance-query settings                                |
| `tokenBalanceQueryOptions`       | Explicit client, address, token, optional balance-query settings                         |
| `contractViewQueryOptions`       | Explicit client and typed view inputs                                                    |
| `transactionReceiptQueryOptions` | Explicit client, hash, and wait settings                                                 |
| `getClientQueryKey(client)`      | Stable-value network/client prefix for custom query keys                                 |
| Factory context                  | No hook or provider required; use the same client instance to share cache entries        |
| Missing balance inputs           | Skipped query; do not use imperative fetch with missing inputs                           |
| Cache lifetime                   | In-memory client identity; not portable for persisted caches or server/browser hydration |
| Usage                            | [Cache and refresh data](pages/react/queries.md)                                         |

---

## Setup

Source: <https://docs.groundhog.dev/react/setup/>

Install the React integration and connect its wallet and query providers to Devnet.

Use the current Node.js LTS release. For a new app, create a React TypeScript project:

```bash
npm create vite@latest my-groundhog-ui -- --template react-ts
cd my-groundhog-ui
npm install
```

Complete the shared [registry access setup](pages/typescript/setup.md#give-npm-package-access), then install the integration and its client together:

```bash
npm install @groundhogchain/react @groundhogchain/client @groundhogchain/protocol @tanstack/react-query
```

The package manager resolves the React library’s compatible client dependency. Keep the lockfile. In an existing application, satisfy the library’s peer dependencies rather than forcing an incompatible client version. The integration uses React 19 and TanStack Query 5.



## Connect the application

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createGroundhogClient, devnet } from "@groundhogchain/client";
import { WalletProvider } from "@groundhogchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Devnet…</p>);

async function start() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

void start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Devnet"}</p>,
  );
});
```

The public client and query cache are created once, before rendering the app. `WalletProvider` does not request wallet permission automatically.



## Check the setup

Start the development server:

```bash
npm run dev
```

In another terminal, check the production build:

```bash
npm run build
```

---

## Track transaction results

Source: <https://docs.groundhog.dev/react/transaction-status/>

Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.

`useWaitForTransactionReceipt` observes a hash through the public client. It works while the wallet is disconnected. Use a client on the transaction’s original network.



## Display a receipt

```tsx
import { ExecResult } from "@groundhogchain/client";
import { useWaitForTransactionReceipt } from "@groundhogchain/react";

export function TransactionStatus({ hash }: { hash: string | null }) {
  const receipt = useWaitForTransactionReceipt({
    hash: hash || null,
    wait: { timeoutMs: 60_000, pollingIntervalMs: 500 },
  });

  if (!hash) return <p>No transaction selected.</p>;
  if (receipt.error) {
    return (
      <section>
        <p role="alert">Observation stopped: {receipt.error.message}</p>
        <button disabled={receipt.isFetching} onClick={() => void receipt.refetch()}>
          Check again
        </button>
      </section>
    );
  }
  if (!receipt.data) return <p>Waiting for a committed receipt…</p>;

  const succeeded = receipt.data.execResult === ExecResult.ExecResultOK;
  return (
    <p>
      {succeeded ? "Execution succeeded" : "Execution failed"}
      {" at block "}{receipt.data.height.toString()}
    </p>
  );
}
```

A failed committed execution is **receipt data**, not a query error. A query timeout means observation stopped, not that the transaction failed.



## Resume observation

Restore the saved hash and its network from the application’s pending record. Missing hashes disable the query. Refetch explicitly to resume after a timeout; do not submit a new operation merely to obtain a result.

The SDK owns polling. The receipt query disables retries and automatic focus/reconnect refetching. Committed receipts have infinite stale time. Observers of the same hash share the query, so configure their timeout and polling settings consistently.

Canceling the query cancels observation, never the transaction.



## Interpret contract results

The receipt is for the transaction’s root method. A wallet-wrapped application call must be decoded through the wallet’s child results, not by treating the root as the application method. Use the [TypeScript receipt model](pages/typescript/transaction-status.md#decode-the-correct-method).

Generated event descriptors can select receipt events by emitter and type. The application decides whether commitment completes its workflow; a queued request may require later events before the requested action is complete.

---

## Send transactions

Source: <https://docs.groundhog.dev/react/transactions/>

Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.

`useExecute` runs a wallet-backed transaction from a user action. It prepares, signs, awaits your persistence callback, submits once, and waits for successful execution. Both [providers](pages/react/providers.md) are required.



## Execute a typed call

This component sends a small HOG transfer to an already funded recipient. The application supplies `savePending`, which must durably save the approved transaction before resolving:

```tsx
import { gasAmount, parseUnits, toHex0x, TransactionObservationError, type ContractAddress } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { useExecute, useWallet, type ExecuteVariables } from "@groundhogchain/react";

type SavePending = ExecuteVariables["options"]["onSigned"];

export function SendHog({ receiver, savePending }: {
  receiver: ContractAddress;
  savePending: SavePending;
}) {
  const wallet = useWallet();
  const execution = useExecute();
  const unresolved = execution.error instanceof TransactionObservationError;

  function send() {
    execution.mutate({
      request: {
        invocation: ERC20.v0_1.transfer.invocation(HOG_ADDRESS, gasAmount(500_000n), {
          receiver,
          amount: parseUnits("0.0001", 7),
        }),
        gasLimit: gasAmount(1_000_000n),
      },
      options: { onSigned: savePending, wait: { timeoutMs: 60_000 } },
    });
  }

  return (
    <section aria-label="Send HOG">
      <button disabled={wallet.status !== "connected" || execution.isPending || unresolved} onClick={send}>
        {execution.isPending ? "Waiting for approval or confirmation…" : "Send HOG"}
      </button>
      {execution.error ? <p role="alert">{execution.error.message}</p> : null}
      {unresolved ? <p>Check the saved transaction before starting another transfer.</p> : null}
      {execution.data ? <p>Committed: {toHex0x(execution.data.txHash)}</p> : null}
    </section>
  );
}
```

`mutate` exposes failures through mutation state. Use `mutateAsync` when an event handler needs to await the result, and handle its rejected promise. Trigger writes from user actions, not render effects.

The example budgets apply to this transfer, not every contract. See [gas and funding](pages/typescript/transactions.md#set-gas-and-funding) for root and child limits and first-address storage funding.



## Save before submission

`onSigned` receives signed bytes, the canonical hash, account, and original network. Await the application’s durable write. A rejected callback prevents broadcast.

The query cache is not the pending-transaction store. Keep the saved record available after a reload, account change, or disconnect. Use it to [observe the original transaction](pages/react/transaction-status.md) rather than automatically signing a replacement.



## Handle mutation state

| State       | Meaning                                                                               |
| ----------- | ------------------------------------------------------------------------------------- |
| `isPending` | Preparation, approval, persistence, submission, or receipt observation is in progress |
| `data`      | Successful committed execution with `txHash` and `receipt`                            |
| `error`     | Inspect the error boundary; an observation failure is not proof of failed execution   |

Mutation retries are disabled, including when the QueryClient’s defaults enable retries. A wallet change invalidates the captured signing binding; observation after broadcast can continue on the original network.

`reset()` clears mutation UI state. It does not cancel a transaction or resolve an unknown outcome. See the shared [execution error model](pages/typescript/transaction-status.md#handle-execution-helper-errors).



## Decode returns and refresh reads

For typed child returns, use the current `useWalletClient()` binding’s `executeCallsAndWait` with the required persistence options. Keep its promise and UI state in the application’s write handler; `useExecute` returns the root execution result.

After commitment, explicitly [invalidate affected queries](pages/react/queries.md#refresh-after-a-write). Capture their original account/token keys before starting the operation so a later account selection does not change the refresh target.

---

## Connect a wallet

Source: <https://docs.groundhog.dev/react/wallets/>

Build wallet and account selectors with explicit connection, network, and error states.

`useWallet` exposes discovered wallets, the selected account, and connection actions. `WalletProvider` manages discovery and session listeners; your components render the controls.



## Select and connect a wallet

```tsx
import { useWallet } from "@groundhogchain/react";

export function WalletControls() {
  const wallet = useWallet();
  const busy = wallet.status === "connecting" || wallet.status === "disconnecting";
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";

  return (
    <section aria-label="Wallet connection">
      <select
        aria-label="Wallet"
        value={wallet.provider?.info.id ?? ""}
        disabled={busy || wallet.providers.length === 0}
        onChange={event => wallet.selectProvider(event.target.value)}
      >
        <option value="" disabled>Choose a wallet</option>
        {wallet.providers.map(provider => (
          <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>
        ))}
      </select>
      {wallet.providers.length === 0 ? <p>No wallet provider detected.</p> : null}
      {authorized ? (
        <button disabled={busy} onClick={() => void wallet.disconnect()}>Disconnect</button>
      ) : (
        <button disabled={busy || !wallet.provider} onClick={() => void wallet.connect()}>
          {wallet.status === "connecting" ? "Connecting…" : "Connect wallet"}
        </button>
      )}
      {wallet.status === "wrongNetwork" ? <p>Switch your wallet to the application's network.</p> : null}
      {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
    </section>
  );
}
```

Discovery selects the first provider without prompting. The user grants access through `connect()`. Provider names and IDs are display metadata, not proof of identity. The library supplies no branded buttons or wallet installation links.



## Select an authorized account

```tsx
import { useWallet } from "@groundhogchain/react";

export function AccountSelector() {
  const wallet = useWallet();
  if (!wallet.session?.accounts.length) return null;

  return (
    <select
      aria-label="Account"
      value={wallet.address ?? ""}
      onChange={event => wallet.selectAccount(event.target.value)}
    >
      {wallet.session.accounts.map(account => (
        <option key={account.address} value={account.address}>{account.address}</option>
      ))}
    </select>
  );
}
```

Selection does not prompt. An unauthorized address or unknown provider sets `error` while preserving the current binding. Selecting another provider clears the local binding without revoking the previous provider’s permission.



## Interpret connection state

| State           | UI behavior                                                 |
| --------------- | ----------------------------------------------------------- |
| `disconnected`  | Offer connection when a provider is available               |
| `connecting`    | Show progress and prevent duplicate connection requests     |
| `connected`     | Enable supported signing actions                            |
| `disconnecting` | Local authorization is already cleared; wait for revocation |
| `wrongNetwork`  | Ask the user to switch networks; keep signing disabled      |

`connect()` and `disconnect()` resolve after handling the request. Read failures from `wallet.error`; those actions do not throw provider request failures. Signing and submission operations do reject on failure.



## Handle changes and cleanup

Session changes invalidate old signing bindings immediately. The provider binds a fresh client after event dispatch when possible, retaining the selected account if still authorized. Do not retain an old signing client for future operations.

Disconnect clears local authorization immediately. If remote revocation fails, the UI remains disconnected and exposes an error. Unmounting disposes the local binding without requesting revocation. Connection is explicit; there is no automatic reconnect or persisted connection.

Use the shared [wallet-provider error codes](pages/tools/wallet-provider.md#errors) for application-specific messages. Do not infer transaction failure from a disconnected wallet; [receipt observation](pages/react/transaction-status.md) uses the public client.

---

## Contract Spec

Source: <https://docs.groundhog.dev/reference/contract-spec/>

Canonical contract metadata, structured identities, methods, types, events, and exceptions.

Source baseline: CLI 0.19.0, SDK/spec-tool 0.41.1. For usage, see [TypeScript Bindings](pages/tools/typescript-bindings.md) and [Build a Counter](pages/tutorials/build-a-counter.md).



## Where the Spec Lives

| Artifact            | Purpose                                                                                                                    |
| ------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `<crate>.spec.xdr`  | Canonical contract API, consumed by standalone TypeScript codegen                                                          |
| `<crate>.spec.json` | Human-readable rendering for inspection; not the codegen input                                                             |
| `<crate>.rv32a`     | Deployable RV32 artifact                                                                                                   |
| Generation          | SDK macros emit fragments; build canonicalizes, sorts, validates, and writes sidecars under `target/groundhog/` by default |



## Top-Level Structure

| JSON key     | Contents                                                          |
| ------------ | ----------------------------------------------------------------- |
| `format`     | `gh_contract_spec_v1`, the inspection-rendering tag               |
| `interfaces` | Exported interfaces, methods, and declared exceptions             |
| `type_defs`  | Reachable named type layouts                                      |
| `events`     | Declared event identities, signatures, topics, and payload fields |



## Structured Identity

| Identity field        | Meaning                                                                                                             |
| --------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `crate`               | Declaring crate in the JSON rendering (`crate_name` in the canonical type)                                          |
| `major`               | Compatibility major, such as `1`, `0.1`, or `0.0.2`                                                                 |
| `module_path`         | Module within that crate                                                                                            |
| `declared`            | Declaration name                                                                                                    |
| Used by               | Named type references, type definitions, and event names                                                            |
| TypeScript projection | Crate, compatibility-major namespace, module path, then declaration; interface methods use interface name and major |

The compatibility major is the leftmost non-zero SemVer component. Use canonical IDs and generated descriptors; short declaration names are not globally unique.



## Interfaces

| Field                | Meaning                                                                           |
| -------------------- | --------------------------------------------------------------------------------- |
| `name`               | Interface name from the trait, inherent self type, or explicit override           |
| `version`            | Full interface version                                                            |
| `throws`             | Declared exception selectors and types                                            |
| `methods`            | Exported methods in canonical order                                               |
| Method `name`        | ABI name                                                                          |
| Method `args`        | Ordered fields with `name` and `type`                                             |
| Method `return_type` | Contract type of the result                                                       |
| Entrypoint ID        | Derived by tooling from interface/version/signature; not an additional JSON field |
| Effect metadata      | The spec does not provide an authoritative read-only/initializer capability flag  |



## Type Encoding

| `kind`                                                     | Other JSON fields    | Meaning                                     |
| ---------------------------------------------------------- | -------------------- | ------------------------------------------- |
| `void`, `bool`, `u8`                                       | None                 | Unit, boolean, or byte                      |
| `u32`, `i32`, `u64`, `i64`, `u128`, `i128`, `u256`, `i256` | None                 | Corresponding integer                       |
| `string`, `bytes`, `address`                               | None                 | String, variable bytes, or contract address |
| `option`                                                   | `inner`              | Optional value                              |
| `vec`                                                      | `element`, `max_len` | Variable-length sequence                    |
| `array`                                                    | `element`, `len`     | Fixed-length sequence                       |
| `tuple`                                                    | `items`              | Ordered element types                       |
| `named`                                                    | `name`               | Structured identity of a named type         |
| `signed_token`                                             | `preimage`           | Payload type, or null when erased           |

Contract arguments, results, and exception payloads use CXS. The spec sidecar uses its canonical XDR encoding. JSON is the inspection projection, not either binary encoding.



## Type Definitions

| Kind                | Fields beyond structured `name`                      |
| ------------------- | ---------------------------------------------------- |
| `struct`            | `fields`, each with name/type                        |
| `enum`              | `variants`, each with name/value                     |
| `union`             | `cases`, each with name, discriminant, and case_type |
| Union case `void`   | No payload                                           |
| Union case `tuple`  | `items`                                              |
| Union case `struct` | `fields`                                             |



## Events

| Field       | Meaning                                                                                        |
| ----------- | ---------------------------------------------------------------------------------------------- |
| `name`      | Structured event identity                                                                      |
| `signature` | 32-byte event signature rendered as hex; topic 0 for derived events                            |
| `topics`    | User topic fields and their types                                                              |
| `fields`    | CXS payload fields and their types                                                             |
| Limits      | At most three topics including signature; 1,024 bytes for topics plus payload                  |
| Discovery   | Events must be declared by the interface or explicitly exported through supported SDK metadata |

Use the generated signature rather than copying a literal from another contract. See [Add Events](pages/tutorials/add-events-to-a-contract.md) for emission, filtering, and restart.



## Errors

| Field or case        | Meaning                                                                                  |
| -------------------- | ---------------------------------------------------------------------------------------- |
| Exception `selector` | Hex rendering of its 64-bit selector                                                     |
| Exception `type`     | Payload type, potentially a structured named reference                                   |
| Known selector       | Generated decoder interprets the declared payload and rejects trailing bytes             |
| Unknown selector     | Client preserves selector and raw abort bytes                                            |
| Runtime fault        | May have no contract exception payload; do not infer a child ABI from root failure bytes |



## Related Documentation

- [SDK Macros](pages/reference/sdk-macros.md)
- [TypeScript Bindings](pages/tools/typescript-bindings.md)
- [XDR Protocol](pages/reference/xdr-protocol.md)

---

## JSON-RPC API

Source: <https://docs.groundhog.dev/reference/json-rpc-api/>

Groundhog JSON-RPC methods, wire types, and error codes.

> **caution: Draft**
>
> This API is under active development. Method signatures and response formats may change; breaking changes bump the major version of `groundhog_version.wireFormat`.

> **note: Version checked**
>
> This page describes `groundhog-rpc` `0.19.0` and JSON-RPC wire format `7.0.0`. Documentation-only corrections do not add methods or change payloads.

The Groundhog gateway exposes JSON-RPC 2.0 over HTTP. For its place in the node topology, see [Networking](pages/how-it-works/networking.md).



## Request Format

```json
{
  "jsonrpc": "2.0",
  "method": "groundhog_chainTip",
  "params": [],
  "id": 1
}
```

Public response fields use camelCase. Addresses, hashes, calldata, event topics, and other byte fields use `0x`-prefixed lowercase hex. Large protocol quantities such as balances use decimal strings. Block heights and other bounded fields use JSON numbers.



## JSON-RPC Arrays

| Property        | Contract                                                                                                                               |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Maximum entries | 1,000 per array on the supported embedded node and standalone gateway                                                                  |
| Correlation     | Match responses by request ID; response order is not execution order                                                                   |
| Errors          | Per-entry RPC errors remain independent; transport failures can affect the shared exchange                                             |
| Guarantees      | No shared snapshot, ordering, or atomicity between independent requests                                                                |
| Other limits    | Request/response byte limits and concurrency settings are separate                                                                     |
| Client defaults | Opt-in HTTP batching uses 100 entries and a 0ms scheduling window; see [client transport](pages/typescript/transport.md#http-batching) |



## Wire Design

Groundhog returns JSON-native objects with typed fields. Transactions use classic XDR; contract arguments and return values use CXS. Clients use the corresponding codecs for those bytes. RPC responses themselves are JSON. See [XDR Protocol](pages/reference/xdr-protocol.md) for the encoding boundary.

Storage reads preserve the protocol value kind:

```json
{
  "blockHeight": 4567,
  "item": {
    "kind": "nonnegativeInt",
    "value": "1000000000"
  }
}
```

Clients switch on tags such as `item.kind` and `status.result`. This avoids reconstructing storage types from packed slots or decoding a universal XDR value for routine reads.

If you are coming from another ecosystem, see [EVM and Solidity](pages/ecosystem/evm.md) or [Stellar and Soroban](pages/ecosystem/stellar.md).



## Methods



### `groundhog_sendRawTransaction`

Submit a signed transaction to the scheduler.

| Parameter | Type   | Description                                       |
| --------- | ------ | ------------------------------------------------- |
| `tx_hex`  | string | `0x`-prefixed XDR encoding of `SignedTransaction` |

**Returns:** `TxHash`, the `0x`-prefixed hash of the inner transaction.

A successful response acknowledges scheduler admission, not commitment or execution. Authentication rejection returns `TX_REJECTED`; retryable admission pressure returns `OVERLOADED`. After a timeout, query the original hash before preparing a replacement.

Transactions whose `blockExpiryHeight` is at or below the current chain tip are rejected when the tip is available.



### `groundhog_getTransactionReceipt`

Get a committed transaction’s execution result and events.

| Parameter | Type     | Description                    |
| --------- | -------- | ------------------------------ |
| `tx_hash` | `TxHash` | `0x`-prefixed transaction hash |

**Returns:** `TransactionReceipt` or `null` if no committed receipt exists.

```json
{
  "txHash": "0x<64 lowercase hex characters>",
  "height": 12345,
  "status": { "result": "ok" },
  "events": [],
  "returnData": "0x42",
  "gasUsed": 1234
}
```

`returnData` is optional and appears for successful transactions when recorded by the executing chain version. `abortData` is optional and may appear for reverted transactions.

**Execution status values:**

| Status                                           | Meaning                                             |
| ------------------------------------------------ | --------------------------------------------------- |
| `{"result":"ok"}`                                | Root execution succeeded                            |
| `{"result":"reverted","message":"..."}`          | The root call reverted; `message` may be `null`     |
| `{"result":"deterministicError","kind":"fault"}` | The execution engine reported a deterministic fault |
| `{"result":"nonDeterministicError"}`             | Proposal-time storage conflict or race              |
| `{"result":"failedGasSponsorship"}`              | Gas sponsorship failed                              |
| `{"result":"other"}`                             | Unrecognized result from the backend                |

A receipt proves that the transaction committed. Only `status.result: "ok"` proves successful execution.

| Field       | Meaning                                                                                                                                          |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| `gasUsed`   | Consumed root/child execution gas plus pre-execution validation of attached contracts; a JSON integer, parsed as bigint by the TypeScript client |
| Gas billing | No token fee or unused-gas refund; declared root gas remains the scheduling quantity                                                             |



### `groundhog_getTransactionStatus`

Check committed history first, then the scheduler mempool when needed.

| Parameter | Type     | Description                    |
| --------- | -------- | ------------------------------ |
| `tx_hash` | `TxHash` | `0x`-prefixed transaction hash |

**Returns:** `TransactionStatus`.

| `status`        | Meaning                                                                   |
| --------------- | ------------------------------------------------------------------------- |
| `pending`       | In the scheduler, not committed                                           |
| `committed`     | Included in a block; includes `height`                                    |
| `invalid`       | Rejected; includes `reason`                                               |
| `recentFailure` | Recent two-phase-commit conflict; includes `attemptHeight` and `conflict` |
| `unknown`       | Absent from both scheduler and committed history                          |
| `other`         | Status from a newer server version                                        |

`recentFailure` is advisory. A later retry of the same transaction may commit. If the scheduler is unavailable and committed history has no record, the gateway returns `BACKEND_UNAVAILABLE` instead of `unknown`.



### `groundhog_chainTip`

Get the current committed chain tip.

**Parameters:** None.

**Returns:** `{ "height": number, "blockHash": "0x..." }`.



### `groundhog_chainConfig`

| Property                | Contract                                                                                                                                                                                          |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Parameters              | None                                                                                                                                                                                              |
| Result                  | `NetworkConfigParams`, the execution parameters explicitly stated by the chain                                                                                                                    |
| Optional integer fields | `maxSha256Buffers`, `maxCrossInvokeDepth`, `maxNewContractsPerTx`, `maxBytestringLen`, `maxContractSizeBytes`, `maxSavepointDepth`, `maxAuthTokenDepth`, `maxRv32CodeBytes`, `maxRv32MemoryBytes` |
| Missing field           | Unspecified by this config, not zero and not an SDK-selected default                                                                                                                              |
| Scope                   | Configured execution limits; not a general storage-cost estimator or a complete list of effective runtime defaults                                                                                |



### `groundhog_networkInfo`

Get the network identity used for transaction signing.

**Parameters:** None.

**Returns:**

```json
{
  "networkHash": "0x<64 lowercase hex characters>"
}
```

Clients should compare `networkHash` with the expected network before signing. The hash is part of every transaction signature preimage. See [Authorization](pages/how-it-works/authorization.md).



### `groundhog_requestAirdrop`

Request an idempotent native HOG airdrop.

| Parameter             | Type    | Description                                                         |
| --------------------- | ------- | ------------------------------------------------------------------- |
| `request.recipient`   | address | Recipient address as `0x`-prefixed 32-byte hex                      |
| `request.clientNonce` | string  | Caller-selected idempotency nonce as `0x`-prefixed 1-to-32-byte hex |

The same recipient and `clientNonce` identify the same logical attempt on a network. Poll a pending attempt by repeating the exact request. Do not generate a new nonce for that attempt.

**Pending response:**

```json
{
  "attemptStatus": "pending",
  "recipient": "0x<64 lowercase hex characters>",
  "rawAmount": "100000000",
  "txHash": "0x<64 lowercase hex characters>",
  "retryAfterSeconds": 5
}
```

`txHash` is optional while pending.

**Succeeded response:**

```json
{
  "attemptStatus": "succeeded",
  "recipient": "0x<64 lowercase hex characters>",
  "txHash": "0x<64 lowercase hex characters>",
  "rawAmount": "100000000",
  "height": 12345,
  "status": { "result": "ok" }
}
```

`succeeded` means the transaction committed. Inspect `status.result` to confirm execution success. A client timeout does not prove that the airdrop failed. Retry the same request to recover the attempt’s state.



### `groundhog_version`

Get wire, implementation, build, and packaging-platform versions.

**Parameters:** None.

**Returns:**

```json
{
  "wireFormat": "7.0.0",
  "implementation": "0.19.0",
  "commitHash": "<commit>",
  "releaseVersion": null,
  "bundleManifestDigest": null
}
```

`releaseVersion` and `bundleManifestDigest` are present only when the serving binary matches an installed release bundle; `platformVersion` is an optional legacy build-time field. It is independent of the validated release identity and may be absent even when `releaseVersion` is present. `commitHash` may be `null`. Consumers may branch on `wireFormat`. `implementation`, `commitHash`, and the release fields are diagnostic.



### `groundhog_view`

Execute a read-only contract invocation against committed state. The invocation does not enter the scheduler.

| Parameter | Type          | Description                                                    |
| --------- | ------------- | -------------------------------------------------------------- |
| `request` | `ViewRequest` | Contract address, entrypoint ID, calldata, and optional caller |

**Returns:** `ViewResponse` with root output, events, and snapshot height. `output.result` is `return`, `abort`, or `fault`. Returns `-32052` when the deployment has no view backend.



### `groundhog_getBalance`

Read the latest committed native HOG balance.

| Parameter | Type    | Description                   |
| --------- | ------- | ----------------------------- |
| `address` | address | `0x`-prefixed 32-byte address |

**Returns:**

```json
{
  "address": "0x<64 lowercase hex characters>",
  "rawBalance": "1000000000",
  "height": 4567
}
```

`rawBalance` is a decimal string in indivisible protocol units.



### `groundhog_getStorageAt`

Read the latest committed storage item at an address and key.

| Parameter | Type    | Description                            |
| --------- | ------- | -------------------------------------- |
| `address` | address | `0x`-prefixed 32-byte contract address |
| `key`     | bytes   | `0x`-prefixed 32-byte storage key      |

**Returns:** `StorageItemRead { blockHeight, item }`. `item` is `null` when the key has no value. `blockHeight` identifies the snapshot used for either result.

`item.kind` is one of `nonnegativeInt`, `bytestring`, `deployedContract`, `authData`, `retrocausalQueue`, `replayCacheEntry`, or `unknown`. Large integer values use decimal strings. `unknown` includes `typeId` for a storage kind added after the client’s wire version.



### `groundhog_getBlockByNumber`

Get block information by height.

| Parameter | Type    | Description  |
| --------- | ------- | ------------ |
| `height`  | integer | Block height |

**Returns:** `BlockInfo` or `null`.

```json
{
  "blockHash": "0x...",
  "protocol": 1,
  "networkHash": "0x...",
  "configHash": "0x...",
  "proposer": "0x...",
  "blockTimepoint": 123,
  "blockHeight": 42,
  "txsHash": "0x...",
  "storageHash": "0x...",
  "eventsHash": "0x...",
  "prevBlockHash": "0x...",
  "proposalTxsHash": "0x...",
  "upgrades": ["0x..."]
}
```

> **caution: Not Yet Implemented**
>
> The hosted gateway (`hog-gateway`) has no block query backend yet and returns `-32052` for this method.



### `groundhog_pendingTransactionCount`

Get the number of transactions in the scheduler.

**Parameters:** None.

**Returns:** nonnegative integer.

> **caution: Gateway Only**
>
> The hosted gateway (`hog-gateway`) returns `-32052` for this method. `groundhog node` serves it for the local chain.



### `groundhog_getEvents`

Query contract events with cursor pagination and topic filters.

| Parameter | Type         | Description                                                                    |
| --------- | ------------ | ------------------------------------------------------------------------------ |
| `query`   | `EventQuery` | Order, anchor, cursor, limit, contract addresses, and positional topic filters |

**Returns:** `EventPage` with events, the next cursor, latest indexed block, and oldest retained block.

`query.filters` uses OR across filters and AND within each filter. Contract-address filters are required. Topic filters are positional: `topic0`, `topic1`, and `topic2`. See [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md#step-5-query-it-on-chain) for an example.



### `groundhog_getTransactionsByAddress`

Query transactions whose root invocation targets an address.

| Parameter | Type                      | Description                               |
| --------- | ------------------------- | ----------------------------------------- |
| `query`   | `AddressTransactionQuery` | Address, order, anchor, cursor, and limit |

**Returns:** `TransactionRefPage` with transaction hashes and heights, the next cursor, latest indexed block, and oldest retained block. Hydrate a reference with `groundhog_getTransactionReceipt`.

The initial cursor is `"0x"`. A limit of `0` selects the server default of 50. Values above the configured cap, normally 200, are rejected. Nested calls to the address do not match.



## Pagination Contract

| Field or case                | Rule for event and address-transaction pages                                                                                     |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| Initial cursor               | Send `"0x"`; TypeScript actions use an empty `Uint8Array` or an omitted initial cursor                                           |
| Non-empty cursor             | Continue the same historical walk with the same network, target, and filters                                                     |
| `order` and `anchor`         | Required raw request fields even when the cursor supplies continuation state                                                     |
| Returned `"0x"`              | This walk is exhausted; it does not subscribe to future blocks                                                                   |
| Empty rows, non-empty cursor | Continue; row count alone does not indicate exhaustion                                                                           |
| `latestBlock`                | Indexer’s head at response time, not an application coverage checkpoint                                                          |
| `oldestBlock`                | Retained-history lower bound; detect/report a gap if a checkpoint is older                                                       |
| Event identity               | Transaction hash plus event sequence number, scoped to the network/query                                                         |
| Transaction-ref identity     | Transaction hash; address history matches only root invocation targets                                                           |
| Later ascending scan         | Start a new ascending walk with an empty cursor at the last stored row height from ascending ingestion; deduplicate that block   |
| Descending refresh           | Start a new descending walk with an empty cursor and `atEnd` anchor; the last (oldest) row is not a forward-ingestion checkpoint |
| Persistence                  | Save rows and progress together; never advance past a partially processed block                                                  |
| Invalid filters              | Empty filter lists or empty contract-address lists return invalid params, not all-contract results                               |
| Cursor validity              | Opaque backend format; current malformed-cursor handling can report false exhaustion, so explicit rejection is not guaranteed    |

For the executable application pattern and retention limitations, see [Resume Without Missing Events](pages/tutorials/add-events-to-a-contract.md#resume-without-missing-events).



## Error Codes

Standard JSON-RPC 2.0 errors apply. The gateway also defines:

| Code     | Name                | Meaning                                                                                                    |
| -------- | ------------------- | ---------------------------------------------------------------------------------------------------------- |
| `-32602` | Invalid params      | Malformed or invalid parameters                                                                            |
| `-32000` | TX_INVALID          | Transaction bytes could not be decoded or validated; resource-limit failures include a typed `data.reason` |
| `-32001` | TX_REJECTED         | Scheduler or airdrop backend rejected the transaction                                                      |
| `-32002` | TX_NOT_FOUND        | Transaction not found                                                                                      |
| `-32010` | BLOCK_NOT_FOUND     | Block not found at the requested height                                                                    |
| `-32050` | BACKEND_UNAVAILABLE | Required backend is unavailable                                                                            |
| `-32051` | BACKEND_TIMEOUT     | Backend did not respond before the deadline                                                                |
| `-32052` | NOT_IMPLEMENTED     | Method is not implemented by the backend                                                                   |
| `-32053` | OVERLOADED          | Gateway or backend is overloaded; retry with backoff                                                       |



## Client Libraries

The `@groundhogchain/client` packages provide TypeScript transports, codecs, and higher-level actions. See [TypeScript SDK](pages/tools/typescript-sdk.md).

Rust clients can use `groundhog-json-rpc-client` and its `GroundhogApiClient` trait.



## Related Documentation

- [Networking](pages/how-it-works/networking.md)
- [Authorization](pages/how-it-works/authorization.md)
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)
- [Storage Types](pages/reference/storage-types.md)

---

## SDK Macros

Source: <https://docs.groundhog.dev/reference/sdk-macros/>

Macro targets, parameters, generated APIs, and constraints for the Rust SDK.

| Task                          | Guide                                                           |
| ----------------------------- | --------------------------------------------------------------- |
| Define state and methods      | [Methods and interfaces](pages/contracts/methods.md)            |
| Choose storage                | [Storage types](pages/programming-model/storage-types.md)       |
| Declare and handle failures   | [Handle errors](pages/contracts/errors.md)                      |
| Call another contract         | [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) |
| Define, emit, and test events | [Events](pages/contracts/events.md)                             |
| Register a test contract      | [Testing](pages/programming-model/testing.md)                   |
| Find complete generated APIs  | [Rust API Docs](pages/tools/rust-api-docs.md)                   |



## `#[contract]`



### Applies to

| Target                  | Generates                                               |
| ----------------------- | ------------------------------------------------------- |
| Trait definition        | Client struct and interface metadata                    |
| Trait implementation    | Export functions and mock registration                  |
| Inherent implementation | Export functions, client struct, and interface metadata |
| Free function           | Export function, no client                              |



### Parameters

| Parameter                                    | Default                 | Meaning                                                                                |
| -------------------------------------------- | ----------------------- | -------------------------------------------------------------------------------------- |
| `throws = Error` or `throws(ErrorA, ErrorB)` | None                    | Error types recorded in the spec; does not restrict which exceptions callers can catch |
| `emits(EventA, EventB)`                      | None                    | Event types recorded in the spec                                                       |
| `client = ClientName`                        | `{Interface}Client`     | Generated client name                                                                  |
| `interface = "Name"`                         | Trait or self-type name | Interface identity used for entrypoints                                                |
| `version = "0.1.0"`                          | `CARGO_PKG_VERSION`     | Version used for entrypoint identity                                                   |
| `exports = "name"`                           | Generated               | Internal exports module name                                                           |



### `throws` rules

| Constraint | Rule                                                                                       |
| ---------- | ------------------------------------------------------------------------------------------ |
| Placement  | Trait definition or inherent implementation; rejected on trait implementations             |
| Duplicates | The same type cannot be listed twice; different paths with the same final name are allowed |
| Runtime    | A known exception can be caught whether or not it is declared in `throws`                  |



### `emits` rules

| Constraint       | Rule                                                                                                    |
| ---------------- | ------------------------------------------------------------------------------------------------------- |
| Placement        | Trait definition or inherent implementation; rejected on trait implementations                          |
| Type             | Must implement `Event`                                                                                  |
| Spec             | Records name, signature, topics, and payload layout                                                     |
| Undeclared event | May be emitted; use `#[event_spec(export)]` to include a library event without an interface declaration |



### Generated client

| Method                                           | Behavior                                                                                |
| ------------------------------------------------ | --------------------------------------------------------------------------------------- |
| `ClientName::new(&ContractAddress)`              | Construct a client                                                                      |
| `with_gas_limit(&self, u64) -> Self`             | Return a configured copy with a child gas cap                                           |
| `with_commit_locking(&self) -> Self`             | Request commit locks before the child returns                                           |
| `with_read_only(&self) -> Self`                  | Reject child state changes                                                              |
| `method(&self, ...) -> T`                        | Return the value or propagate failure                                                   |
| `try_method(&self, ...) -> Result<T, CallError>` | Return the value or an inspectable failure                                              |
| Reserved names                                   | `new`, `with_gas_limit`, `with_commit_locking`, `with_read_only`, and the `try_` prefix |



### Inspecting errors

| API                 | Purpose                                                                                               |
| ------------------- | ----------------------------------------------------------------------------------------------------- |
| `match_exn!`        | Match typed exceptions; requires a final `_` arm                                                      |
| `try_as::<E>()`     | Decode one known exception type; returns `None` for a different type or failed decoding               |
| `try_decode::<E>()` | Distinguish unknown type from malformed payload                                                       |
| Usage               | [Error matching examples](pages/contracts/cross-contract-calls.md#matching-exceptions-with-match_exn) |



### Method behavior

| Method                      | Behavior                                                                                 |
| --------------------------- | ---------------------------------------------------------------------------------------- |
| Public inherent method      | Exported                                                                                 |
| Private inherent method     | Internal helper                                                                          |
| Trait implementation method | Exported                                                                                 |
| Storage receiver            | Uses generated storage handles; see [Methods and interfaces](pages/contracts/methods.md) |



## `#[contract_exception]`

| Property            | Value                                                               |
| ------------------- | ------------------------------------------------------------------- |
| Targets             | Structs and enums; no generics                                      |
| Generated derives   | `Debug`, `PartialEq`, `ReadXDR`, `WriteXDR`, `ContractTypeSpec`     |
| Generated traits    | `Exn` and `ContractTypeName`                                        |
| Enum representation | Adds `#[repr(i32)]`; variants require explicit discriminants        |
| `version = "0.1.0"` | Override `CARGO_PKG_VERSION` for identity                           |
| `name = "Name"`     | Override the Rust type name for identity                            |
| `Clone`             | Add the derive explicitly if needed                                 |
| Examples            | [Enum and struct errors](pages/contracts/errors.md#defining-errors) |



### Selector computation

| Component       | Rule                                                                                                                                                                                        |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Selector        | First 8 bytes of `sha256(MAJOR_VERSION :: CRATE_NAME :: TYPE_NAME)`                                                                                                                         |
| `MAJOR_VERSION` | Leftmost nonzero version component: `1.2.3` → `1`, `0.9.2` → `0.9`, `0.0.2` → `0.0.2`                                                                                                       |
| `CRATE_NAME`    | `CARGO_PKG_NAME`                                                                                                                                                                            |
| `TYPE_NAME`     | Type name or explicit `name`                                                                                                                                                                |
| Compatibility   | Stable selector does not guarantee an older caller can decode every new payload; see [decoding errors](pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one) |



## `#[exn]`

| Property                   | Value                                                                             |
| -------------------------- | --------------------------------------------------------------------------------- |
| Purpose                    | Low-level `Exn` implementation with computed selector                             |
| Derives and representation | Supplied by the author; prefer `#[contract_exception]` for normal contract errors |
| `version`                  | Optional selector-version override                                                |



## `#[storage]` / `#[derive(Storage)]`

| Property    | Value                                                                     |
| ----------- | ------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                      |
| Output      | `From<Keypath>` implementation assigning each field a subpath             |
| Fields      | Storage handles; wrap plain data in `Value<T>`                            |
| Collections | Use `Node<T>` to place a compound storage struct inside `Map` or `Vector` |
| Usage       | [Storage types](pages/programming-model/storage-types.md)                 |



## `#[derive(Deletable)]`

| Property    | Value                                                                               |
| ----------- | ----------------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                                |
| Requirement | Every field must implement `Deletable`; `Map` does not                              |
| Output      | Calls each field’s `delete_internal()`; exposes `delete()` and `delete_exclusive()` |



## `#[derive(Event)]`

| Property                     | Value                                                                                                           |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Target                       | Named-field struct                                                                                              |
| `#[topic]`                   | Mark an indexed field; at most two fields, in addition to the signature at topic 0                              |
| Direct topics                | `ContractAddress`, `SHA256Hash`, `[u8; 32]`, `U256`, `I256`, `u32`, `u64`, `u128`, `i32`, `i64`, `i128`, `bool` |
| Integer topics               | Fixed 32-byte big-endian encoding with zero or sign extension                                                   |
| String and byte-slice topics | Hashed; filterable but not recoverable from the topic                                                           |
| Payload                      | Non-topic fields, serialized by the generated `WriteXDR` implementation                                         |
| `#[event_spec(export)]`      | Include the event in the linked contract spec without `emits(...)`                                              |
| `SIGNATURE`                  | Full 32-byte hash of version, defining crate, and type identity                                                 |
| `Event` implementation       | Topic access and payload decoding                                                                               |
| `{Name}Payload`              | Companion payload type with `ReadXDR`                                                                           |
| Usage                        | [Event definitions, emission, and tests](pages/contracts/events.md)                                             |



## Utility Macros

| Macro                                      | Output / usage                                                                                                      |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| `static_key!("slot")`                      | Compile-time SHA-256 `StorageKey`                                                                                   |
| `sha256_static!("text")`                   | Compile-time `SHA256Hash`                                                                                           |
| `sha256_ident!(Name)`                      | `SHA256Hash` of an identifier                                                                                       |
| `hash_ident! { static NAME: SHA256Hash; }` | Named hash static; also supports `ContractAddress` and visibility                                                   |
| `sha256_array_ident!(Name)`                | Identifier hash as `[u8; 32]`                                                                                       |
| `hash_to_array!("text")`                   | String or byte-string hash as `[u8; 32]`                                                                            |
| `declare_mock_contract!()`                 | Crate-root mock registration when `dev` is enabled; see [test setup](pages/programming-model/testing.md#test-setup) |



## `#[contract_type]`

| Property                | Value                                                                                                            |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Targets                 | Named, tuple, or unit structs and enums                                                                          |
| Output                  | Serialization derives and `ContractTypeSpec`                                                                     |
| `name = "Name"`         | Override spec type name                                                                                          |
| `export`                | Include an otherwise unreachable type in the spec                                                                |
| Enum variants           | Explicit discriminants required                                                                                  |
| Generic type parameters | Not supported                                                                                                    |
| Spec inclusion          | Types reachable through method signatures, errors, events, or other reachable types; otherwise requires `export` |
| Spec kind               | Struct, enum without payloads, or union with payloads                                                            |
| Examples                | [Argument and return types](pages/contracts/methods.md#define-argument-and-return-types)                         |



## `#[derive(ContractTypeSpec)]`

| Property                        | Value                                                              |
| ------------------------------- | ------------------------------------------------------------------ |
| Targets                         | Structs and enums                                                  |
| Output                          | `ContractTypeSpec` only; serialization must be supplied separately |
| `#[contract_type_spec(export)]` | Include an otherwise unreachable type in the spec                  |

---

## Storage Types

Source: <https://docs.groundhog.dev/reference/storage-types/>

API reference for Groundhog storage types.

| Area                                  | Links                                                                                                                                      |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| Type choice and conflict semantics    | [Storage guidance](pages/programming-model/storage-types.md)                                                                               |
| Generated type, guard, and trait APIs | [`sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html), [Rust API Docs](pages/tools/rust-api-docs.md) |
| Encoding                              | CXS; serialization traits retain the names `ReadXDR` and `WriteXDR`                                                                        |



## NNInt

| Property         | Value                                                                                                                                 |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Data model       | Signed changes, explicit `set`, and a commit-time floor                                                                               |
| Decrement        | Negative `inc` or `strict_inc` argument                                                                                               |
| Exclusive writes | Keypath flag, or `non_negative_int_set_exclusive` in `sdk::sys_exn::nnint`; no handle `set_exclusive` method                          |
| Traits           | `Deletable`                                                                                                                           |
| Usage            | [Merged deltas](pages/programming-model/execution.md#merged-deltas), [NNInt and concurrent updates](pages/programming-model/nnint.md) |

| Method           | Signature                                                                 | Description                                                                                                                     |
| ---------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `get`            | `fn get(&self) -> i128`                                                   | Read current value. Aborts if the location has never been set.                                                                  |
| `try_get`        | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read current value without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.                      |
| `set`            | `fn set(&mut self, set_value: i128)`                                      | Set the value. Uses the keypath’s locking mode.                                                                                 |
| `inc`            | `fn inc(&mut self, increment: i128)`                                      | Add `increment` without forcing a snapshot read. Underflow is caught by later runtime checks, not immediately.                  |
| `strict_inc`     | `fn strict_inc(&mut self, increment: i128)`                               | Add `increment`, loading the current base for early underflow detection. Aborts immediately if the result would be negative.    |
| `try_strict_inc` | `fn try_strict_inc(&mut self, increment: i128) -> Result<(), LibraryExn>` | Checked increment that reports overflow, underflow, or storage failure instead of aborting. Leaves storage unmodified on `Err`. |



## Balance

| Property        | Value                                          |
| --------------- | ---------------------------------------------- |
| Representation  | `i128`, backed by NNInt                        |
| Range           | `0..=i128::MAX`; `Balance::MAX` is `i128::MAX` |
| Missing value   | Zero                                           |
| Negative amount | Rejected with `NonNegativeIntUnderflow`        |
| Operations      | No absolute `set` or signed adjustment         |
| Traits          | `Deletable`                                    |

| Method              | Signature                                                                 | Description                                                                                                   |
| ------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> i128`                                                   | Read the balance. A never-written location returns zero.                                                      |
| `try_get`           | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read without aborting. A never-written location returns `Ok(0)`.                                              |
| `increase`          | `fn increase(&mut self, amount: i128)`                                    | Load and increase the balance. Aborts immediately on overflow.                                                |
| `try_increase`      | `fn try_increase(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked increase that leaves storage unmodified on `Err`.                                                     |
| `decrease`          | `fn decrease(&mut self, amount: i128)`                                    | Load and decrease the balance. Aborts immediately if funds are insufficient.                                  |
| `try_decrease`      | `fn try_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked decrease that leaves storage unmodified on `Err`.                                                     |
| `lazy_increase`     | `fn lazy_increase(&mut self, amount: i128)`                               | Record an increase without loading the committed balance. Aggregate overflow is checked during reservation.   |
| `try_lazy_increase` | `fn try_lazy_increase(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta overflow.                                                       |
| `lazy_decrease`     | `fn lazy_decrease(&mut self, amount: i128)`                               | Record a decrease without loading the committed balance. Aggregate sufficiency is checked during reservation. |
| `try_lazy_decrease` | `fn try_lazy_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta underflow.                                                      |



## CapacityConstraint

| Property | Value                                                         |
| -------- | ------------------------------------------------------------- |
| Purpose  | Commit-time capacity for a contract-defined linear constraint |
| Flush    | Staged changes are written on flush or drop                   |
| Traits   | `Deletable`                                                   |

| Method                       | Signature                                                                    | Description                                                                                                                |
| ---------------------------- | ---------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `get_remaining_capacity`     | `fn get_remaining_capacity(&self) -> i128`                                   | Return the committed capacity plus changes staged in this transaction and handle. A never-written location starts at zero. |
| `try_get_remaining_capacity` | `fn try_get_remaining_capacity(&self) -> Result<i128, LibraryExn>`           | Read remaining capacity without aborting.                                                                                  |
| `consume_capacity`           | `fn consume_capacity(&mut self, amount: i128)`                               | Stage consumption for commit-time enforcement. A negative amount releases capacity.                                        |
| `try_consume_capacity`       | `fn try_consume_capacity(&mut self, amount: i128) -> Result<(), LibraryExn>` | Stage consumption and report arithmetic overflow instead of aborting.                                                      |
| `set_capacity`               | `fn set_capacity(&mut self, capacity: i128)`                                 | Set the capacity. Must be the first write in the transaction, except for an idempotent repeat.                             |
| `try_set_capacity`           | `fn try_set_capacity(&mut self, capacity: i128) -> Result<(), LibraryExn>`   | Set capacity and report invalid write ordering instead of aborting.                                                        |
| `flush`                      | `fn flush(&mut self)`                                                        | Merge staged changes into pending storage immediately.                                                                     |
| `try_flush`                  | `fn try_flush(&mut self) -> Result<(), LibraryExn>`                          | Flush staged changes and report failure. On error, changes remain staged and drop retries the flush.                       |



## Map\<K, V>

| Property        | Value                                                             |
| --------------- | ----------------------------------------------------------------- |
| Bounds          | `K: WriteXDR`, `V: StorageType`                                   |
| Enumeration     | Not supported; no `keys()` or iterator                            |
| Deletion        | Does not implement `Deletable`                                    |
| Disjoint access | Compares derived keypaths, not `PartialEq`; duplicate slots panic |

| Method                      | Signature                                                                                                      | Description                                                                                                                                   |
| --------------------------- | -------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `at`                        | `fn at(&self, entry_key: &K) -> SlotRef<'_, Self, V>`                                                          | Read-only borrow of the value at `entry_key`. Returns a `SlotRef` that derefs to `V`.                                                         |
| `at_mut`                    | `fn at_mut(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                                  | Mutable borrow of the value at `entry_key`. Returns a `SlotMut` that derefs to `V`.                                                           |
| `at_mut_exclusive`          | `fn at_mut_exclusive(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                        | Mutable borrow with an exclusive lock. One writer per key per block. Later writes to the entry in the same transaction keep the lock request. |
| `at_disjoint_mut`           | `fn at_disjoint_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>`                  | Mutably borrow N elements at once. Panics if any keys are equal.                                                                              |
| `at_disjoint_unchecked_mut` | `unsafe fn at_disjoint_unchecked_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>` | Mutably borrow N elements without duplicate checking. Caller must ensure all keys are disjoint.                                               |
| `keypath`                   | `fn keypath(&self) -> &Keypath`                                                                                | Reference to the map’s root keypath.                                                                                                          |



### DisjointMut\<Owner, S, N>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `at_disjoint_mut`                                              |
| Borrow   | Exclusive borrow of the parent map                             |
| Traits   | `Deref<Target = [S; N]>`, `DerefMut`; supports direct indexing |



## Vector\<S>

| Property       | Value                                                                                                    |
| -------------- | -------------------------------------------------------------------------------------------------------- |
| Representation | `Map<u32, S>` and a separate length; `S: StorageType`                                                    |
| Sparse slots   | Deleting element storage does not shrink `len`; an in-bounds slot can be missing                         |
| Iterators      | `Iterator`, `ExactSizeIterator`, `DoubleEndedIterator`; `IntoIterator` for shared and mutable references |
| Deletion       | `Deletable` when `S: Deletable`; deletes elements, then length                                           |

| Method            | Signature                                                      | Description                                                                                                                  |
| ----------------- | -------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `len`             | `fn len(&self) -> u32`                                         | Current logical length. Returns 0 if never set.                                                                              |
| `is_empty`        | `fn is_empty(&self) -> bool`                                   | True if `len() == 0`.                                                                                                        |
| `at`              | `fn at(&self, index: u32) -> SlotRef<'_, Self, S>`             | Read-only borrow at `index`. Bounds-checked.                                                                                 |
| `at_mut`          | `fn at_mut(&mut self, index: u32) -> SlotMut<'_, Self, S>`     | Mutable borrow at `index`. Bounds-checked.                                                                                   |
| `push_empty_slot` | `fn push_empty_slot(&mut self) -> SlotMut<'_, Self, S>`        | Increment `len` and return a mutable handle to the new slot. Marked `#[must_use]`.                                           |
| `push_with`       | `fn push_with<R>(&mut self, f: impl FnOnce(&mut S) -> R) -> R` | Initialize a new slot through the closure `f`, then increment `len`. If `f` traps, neither the data nor `len` are committed. |
| `pop`             | `fn pop(&mut self)`                                            | Delete the last element and decrement `len`. Aborts if empty. Requires `S: Deletable`.                                       |
| `iter`            | `fn iter(&self) -> VectorIter<'_, S>`                          | Read-only iterator. Yields `SlotRef` handles. Shared borrow prevents structural modifications.                               |
| `iter_mut`        | `fn iter_mut(&mut self) -> VectorIterMut<'_, S>`               | Mutable iterator. Yields `SlotMut` handles. Exclusive borrow on the vector.                                                  |
| `keypath`         | `fn keypath(&self) -> &Keypath`                                | Reference to the vector’s root keypath.                                                                                      |



## Value\<T>

| Property | Value                                            |
| -------- | ------------------------------------------------ |
| Data     | One serialized typed value                       |
| Bounds   | `T: WriteXDR` for writes, `T: ReadXDR` for reads |
| Traits   | `Deletable`                                      |

| Method              | Signature                                                              | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> T`                                                   | Deserialize and return the stored value. Aborts if the key does not exist.                                    |
| `try_get`           | `fn try_get(&self) -> Result<T, LibraryExn>`                           | Deserialize without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.           |
| `set`               | `fn set(&mut self, value: &T)`                                         | Serialize and store the value. Uses the keypath’s locking mode.                                               |
| `try_set`           | `fn try_set(&mut self, value: &T) -> Result<(), LibraryExn>`           | Serialize and store without aborting. Leaves storage unmodified on `Err`.                                     |
| `set_exclusive`     | `fn set_exclusive(&mut self, value: &T)`                               | Serialize and store the value with an exclusive lock, regardless of keypath flag.                             |
| `try_set_exclusive` | `fn try_set_exclusive(&mut self, value: &T) -> Result<(), LibraryExn>` | Exclusive store that reports failure instead of aborting.                                                     |
| `load_mut`          | `fn load_mut(&mut self) -> ValueMut<'_, T>`                            | Load the value and return a mutable guard. Flushes back to storage on drop. Requires `T: WriteXDR + ReadXDR`. |
| `key`               | `fn key(&self) -> &StorageKey`                                         | Reference to the value’s resolved storage key.                                                                |



### ValueMut\<T>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `load_mut`                                                     |
| Traits   | `Deref<Target = T>`, `DerefMut`                                |
| Drop     | Writes back after mutable access; a clean guard does not write |

| Method      | Signature                                           | Description                                                                                            |
| ----------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `flush`     | `fn flush(&mut self)`                               | Write a dirty value immediately. A clean guard is a no-op.                                             |
| `try_flush` | `fn try_flush(&mut self) -> Result<(), LibraryExn>` | Flush and report serialization or storage failure. On error, the guard remains dirty and drop retries. |



## Bytestring

| Property         | Value                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------- |
| Data             | Raw bytes                                                                                                   |
| Exclusive writes | Keypath flag, or `bytestring_set_exclusive` in `sdk::sys_exn::bytestring`; no handle `set_exclusive` method |
| Traits           | `Deletable`                                                                                                 |

| Method      | Signature                                            | Description                                                                                  |
| ----------- | ---------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `len`       | `fn len(&self) -> usize`                             | Length in bytes.                                                                             |
| `is_empty`  | `fn is_empty(&self) -> bool`                         | True if length is zero.                                                                      |
| `exists`    | `fn exists(&self) -> bool`                           | True if a bytestring exists. Returns false for a missing key.                                |
| `get`       | `fn get(&self) -> Box<[u8]>`                         | Read stored bytes as a heap-allocated slice.                                                 |
| `try_get`   | `fn try_get(&self) -> Result<Box<[u8]>, LibraryExn>` | Read without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`. |
| `get_sized` | `fn get_sized<const N: usize>(&self) -> [u8; N]`     | Read into a fixed-size array. Aborts if length does not match `N`.                           |
| `set`       | `fn set(&mut self, buf: &[u8])`                      | Write bytes. Uses the keypath’s locking mode (exclusive if the keypath flag is set).         |



## RCQ\<T>

| Property    | Value                                                                     |
| ----------- | ------------------------------------------------------------------------- |
| Data        | CXS-encoded `T`; multi-producer queue                                     |
| Concurrency | Inserts commute; consumes are sequential                                  |
| Traits      | `StorageType`, `Deletable`                                                |
| Modules     | Typed wrapper in `sdk::storage`; raw-key functions in `sdk::sys_exn::rcq` |

| Method              | Signature                                                                        | Description                                                                                        |
| ------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `insert`            | `fn insert(&mut self, entry: &T)` where `T: WriteXDR`                            | CXS-encode and insert the entry.                                                                   |
| `insert_raw`        | `fn insert_raw(&mut self, queue_entry: &[u8])`                                   | Insert raw bytes; bypasses CXS encoding.                                                           |
| `consume`           | `fn consume(&mut self) -> T` where `T: ReadXDROwned`                             | Consume the next entry and decode it. Aborts if the queue is empty or the entry cannot be decoded. |
| `try_consume`       | `fn try_consume(&mut self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`     | Consume and decode without aborting. A decode failure leaves the entry in the queue.               |
| `consume_raw`       | `fn consume_raw(&mut self) -> Box<[u8]>`                                         | Consume the next entry as raw bytes. Aborts if the queue is empty.                                 |
| `try_consume_raw`   | `fn try_consume_raw(&mut self) -> Result<Box<[u8]>, LibraryExn>`                 | Consume raw bytes without aborting.                                                                |
| `consume_sized`     | `fn consume_sized<const N: usize>(&mut self) -> [u8; N]`                         | Consume into a fixed-size array. Aborts on size mismatch.                                          |
| `try_consume_sized` | `fn try_consume_sized<const N: usize>(&mut self) -> Result<[u8; N], LibraryExn>` | Consume without aborting. A wrong-size entry is left in the queue.                                 |
| `peek`              | `fn peek(&self) -> T` where `T: ReadXDROwned`                                    | Read the next entry without consuming. Aborts if empty.                                            |
| `try_peek`          | `fn try_peek(&self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`            | Read and decode without aborting or consuming.                                                     |
| `peek_raw`          | `fn peek_raw(&self) -> Box<[u8]>`                                                | Raw-bytes peek. Aborts if empty.                                                                   |
| `try_peek_raw`      | `fn try_peek_raw(&self) -> Result<Box<[u8]>, LibraryExn>`                        | Raw-bytes peek without aborting.                                                                   |
| `peek_sized`        | `fn peek_sized<const N: usize>(&self) -> [u8; N]`                                | Fixed-size peek. Aborts on size mismatch.                                                          |
| `try_peek_sized`    | `fn try_peek_sized<const N: usize>(&self) -> Result<[u8; N], LibraryExn>`        | Fixed-size peek without aborting.                                                                  |
| `key`               | `fn key(&self) -> &StorageKey`                                                   | Reference to the queue’s resolved storage key.                                                     |



### Lower-level free functions (`sdk::sys_exn::rcq`)

| Function                              | Signature                                                                                                 | Description                                                         |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `retrocausal_queue_insert`            | `fn retrocausal_queue_insert(key: &StorageKey, queue_entry: &[u8])`                                       | Insert raw bytes.                                                   |
| `retrocausal_queue_consume_sized`     | `fn retrocausal_queue_consume_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                         | Consume a fixed-size entry. Aborts on size mismatch or empty queue. |
| `retrocausal_queue_try_consume_sized` | `fn retrocausal_queue_try_consume_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>` | Consume a fixed-size entry without aborting.                        |
| `retrocausal_queue_peek_sized`        | `fn retrocausal_queue_peek_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                            | Peek a fixed-size entry.                                            |
| `retrocausal_queue_try_peek_sized`    | `fn retrocausal_queue_try_peek_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>`    | Peek a fixed-size entry without aborting.                           |
| `retrocausal_queue_consume`           | `fn retrocausal_queue_consume(key: &StorageKey) -> Box<[u8]>`                                             | Consume a raw entry.                                                |
| `retrocausal_queue_try_consume`       | `fn retrocausal_queue_try_consume(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                     | Consume a raw entry without aborting.                               |
| `retrocausal_queue_peek`              | `fn retrocausal_queue_peek(key: &StorageKey) -> Box<[u8]>`                                                | Peek a raw entry.                                                   |
| `retrocausal_queue_try_peek`          | `fn retrocausal_queue_try_peek(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                        | Peek a raw entry without aborting.                                  |



## Slot Types

| Type                    | Implements                       | Description                                              |
| ----------------------- | -------------------------------- | -------------------------------------------------------- |
| `SlotRef<'a, Owner, S>` | `Deref<Target = S>`              | Read-only handle. Holds a shared borrow on the parent.   |
| `SlotMut<'a, Owner, S>` | `Deref<Target = S>` + `DerefMut` | Mutable handle. Holds an exclusive borrow on the parent. |

| Access                | Lifetime                  | Syntax                                    |
| --------------------- | ------------------------- | ----------------------------------------- |
| Map or vector element | Tied to parent collection | `*slot` or direct field access; no unwrap |



## Node\<T>

| Property           | Value                                                      |
| ------------------ | ---------------------------------------------------------- |
| Data               | Compound storage field group and its root keypath          |
| Bound              | `T: From<Keypath>`                                         |
| Access             | `Deref<Target = T>`, `DerefMut`                            |
| Collection support | Implements `StorageType` for use in maps and vectors       |
| Deletion           | `Deletable` when `T: Deletable`; delegates to inner fields |

| Method    | Signature                       | Description                           |
| --------- | ------------------------------- | ------------------------------------- |
| `keypath` | `fn keypath(&self) -> &Keypath` | Reference to the node’s root keypath. |



## Deletable Trait

| Implementor                                                     | Behavior                                               |
| --------------------------------------------------------------- | ------------------------------------------------------ |
| `Balance`, `NNInt`, `CapacityConstraint`, `Value`, `Bytestring` | Delete one key                                         |
| `Node`, `Vector`                                                | Delete recursively when elements implement `Deletable` |
| `Map`                                                           | Not implemented; entries cannot be enumerated          |

| Method             | Signature                        | Description                                                |
| ------------------ | -------------------------------- | ---------------------------------------------------------- |
| `delete`           | `fn delete(&mut self)`           | Delete using the keypath’s own locking semantics.          |
| `delete_exclusive` | `fn delete_exclusive(&mut self)` | Delete with an exclusive lock, regardless of keypath flag. |



## Flaggable Trait

| Property     | Value                                                |
| ------------ | ---------------------------------------------------- |
| Implementors | `Value`, `NNInt`, `Balance`, `Bytestring`            |
| Scope        | Current transaction’s requested flags for a leaf key |
| Type         | `StorageFlags` aliases `StorageDeltaFlags`           |
| Flag         | `ExclusiveLock`                                      |

| Method        | Signature                                      | Description                                                                                      |
| ------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| `flags`       | `fn flags(&self) -> StorageFlags`              | The key’s flags as seen by the current call frame. `None` if the key has no pending write.       |
| `set_flags`   | `fn set_flags(&mut self, flags: StorageFlags)` | Add `flags` (bitwise OR). Throws unless a write to the key is pending in the current call frame. |
| `clear_flags` | `fn clear_flags(&mut self)`                    | Remove every flag. Does nothing if the key has no pending write.                                 |



### Raw-key functions

| Function              | Signature                                                          | Description                                                    |
| --------------------- | ------------------------------------------------------------------ | -------------------------------------------------------------- |
| `storage_flags`       | `fn storage_flags(key: &StorageKey) -> StorageDeltaFlags`          | Read the key’s flags.                                          |
| `set_storage_flags`   | `fn set_storage_flags(key: &StorageKey, flags: StorageDeltaFlags)` | Add flags. Throws if no write is pending or a flag is unknown. |
| `clear_storage_flags` | `fn clear_storage_flags(key: &StorageKey)`                         | Remove every flag.                                             |

| Module                   | Behavior                                                                |
| ------------------------ | ----------------------------------------------------------------------- |
| `sdk::sys_exn::flags`    | Throwing versions, re-exported at crate root                            |
| `sdk::sys_result::flags` | Non-throwing versions returning `Result`                                |
| Usage                    | [Lock requests](pages/programming-model/storage-types.md#lock-requests) |

---

## Syscalls

Source: <https://docs.groundhog.dev/reference/syscalls/>

Authoritative reference for the host functions exposed to Groundhog contracts, generated from the protocol's syscalls.yaml.

These are the host functions available to Groundhog guest contracts. Most developers use the SDK rather than calling syscalls directly. See [Programming Model: Storage Types](pages/programming-model/storage-types.md) for the high-level API.

The tables below describe the protocol’s logical typed interface. The generated low-level bindings map it to each guest target’s ABI. User contracts in `0.1.27` use RV32. Variable-length buffers are passed as spans.

The return value is a `SyscallErrorCode`. Any syscall can return `Fault` (1) if a pointer argument is out of guest memory bounds, or `NoSyscall` (2) if the syscall number is not supported. Per-syscall error codes are listed with each entry below, and the full enum is at the bottom of this page.



## Hashing



### SHA256

|            |   |
| ---------- | - |
| **Number** | 0 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |
| out       | `hash`   | `SHA256Hash`  |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the SHA-256 hash of the input buffer.



### SHA256Update

|            |    |
| ---------- | -- |
| **Number** | 26 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `index`  | `u32`         |
| in        | `buffer` | `[u8]` (span) |
| in        | `reset`  | `bool`        |

Errors:

- `InvalidSyscallInput` if the indexed hash buffer does not exist and `reset` is false, the buffer becomes too large, or there are too many active hash buffers.

Updates the SHA-256 hash computation at the specified index with the supplied bytes. If `reset` is true, the hash state is cleared before the update.



### SHA256Finalize

|            |    |
| ---------- | -- |
| **Number** | 27 |

| Direction | Name     | Type         |
| --------- | -------- | ------------ |
| in        | `index`  | `u32`        |
| out       | `output` | `SHA256Hash` |

Errors:

- `InvalidSyscallInput` if the queried hash buffer does not exist (for example, calling finalize twice on the same buffer without an intervening reset).

Finalizes the SHA-256 hash computation at the specified index, returns the digest, and removes the buffer.



### SHA256Copy

|            |    |
| ---------- | -- |
| **Number** | 33 |

| Direction | Name        | Type  |
| --------- | ----------- | ----- |
| in        | `src_index` | `u32` |
| in        | `dst_index` | `u32` |

Errors:

- `InvalidSyscallInput` if the hash computation at `src_index` does not exist, or if `dst_index` does not already hold a hash computation and there are too many active hash buffers.

Copies the in-progress SHA-256 hash computation at `src_index` to `dst_index`, replacing any hash computation already at `dst_index`. Both computations can then be extended and finalized independently. Copying an index onto itself succeeds and changes nothing.



## Calldata



### GetCalldataLen

|            |   |
| ---------- | - |
| **Number** | 2 |

| Direction | Name               | Type                  |
| --------- | ------------------ | --------------------- |
| out       | `len`              | `RuntimeMemoryLength` |
| out       | `auth_token_count` | `u32`                 |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the length of the calldata supplied to the invocation associated with the current call frame, plus the number of auth tokens supplied to that invocation.



### GetCalldata

|            |   |
| ---------- | - |
| **Number** | 3 |

| Direction | Name                     | Type                                  |
| --------- | ------------------------ | ------------------------------------- |
| out       | `buffer`                 | `[u8]` (span)                         |
| out       | `written_len`            | `RuntimeMemoryLength`                 |
| out       | `auth_token_list`        | `[u8]` (span, interpreted as `[u32]`) |
| out       | `auth_token_written_len` | `RuntimeMemoryLength`                 |

Errors:

- `InvalidSyscallInput` if the `auth_token_list` output span byte length is not a multiple of the size of a `u32`.

Returns the calldata and the auth-token id list supplied to the invocation associated with the current call frame.



## Logging



### ConsoleLog

|            |   |
| ---------- | - |
| **Number** | 4 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Logs the input buffer to the console. No-op on release builds and on-chain; calling it from a production contract is harmless but pointless.



### LogEvent

|            |    |
| ---------- | -- |
| **Number** | 24 |

| Direction | Name     | Type                         |
| --------- | -------- | ---------------------------- |
| in        | `topic0` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic1` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic2` | `Option<Topic>` (`[u8; 32]`) |
| in        | `data`   | `[u8]` (span)                |

Errors:

- `InvalidSyscallInput` if the event data exceeds the maximum event length, or if topics are not supplied as a continuous prefix (e.g., supplying `topic0` and `topic2` but not `topic1`).

Emits an event with up to three 32-byte topics and a data payload. The serialized event is `topic0 || topic1 || topic2 || data`, with a separate `num_topics` field that lets downstream indexers filter on the leading topic chunks. Events are accumulated into a per-block merkle-patricia trie.



## Invocation



### Invoke

|            |   |
| ---------- | - |
| **Number** | 5 |

| Direction | Name                        | Type                                                                                     |
| --------- | --------------------------- | ---------------------------------------------------------------------------------------- |
| in        | `address`                   | `ContractAddress`                                                                        |
| in        | `calldata`                  | `[u8]` (span)                                                                            |
| in        | `owned_auth_token_ids_list` | `[u8]` (span, interpreted as `[u32]`)                                                    |
| in        | `inputs`                    | `CopyableInvokeInputs` (`entrypoint_id`, `gas_limit`, `flags`)                           |
| out       | `outputs`                   | `CopyableInvokeOutputs` (`return_buffer_len`, `returned_auth_token_len`, `frame_status`) |

Errors:

- `InvalidSyscallInput` if the call is rejected before a child frame runs: the target is missing, the flags are invalid, or an auth-token id is malformed, duplicated, or not owned by the current frame.
- `Reentrance` if the invoked address is already on the call stack.
- `InvokeDepthExceeded` if the transaction already holds the maximum number of invocation frames open. Like `Reentrance`, the call is rejected before any child frame runs and the syscall is a no-op. This is a resource limit rather than a malformed call: the same invocation succeeds from a shallower frame.

Invokes the specified entrypoint of the contract at `address` with the supplied calldata and auth tokens, creating a new call frame. The new frame is capped at `min(gas_limit, remaining gas in current frame)`; unused child-frame gas returns to the caller’s execution budget. This is not a token refund. The SDK defaults `gas_limit` to `u64::MAX` so the child inherits everything the parent has left.

`entrypoint_id` is the little-endian interpretation of an 8-byte `ContractEntrypointID`. `frame_status` is `Return`, `Abort`, or `Fault`; it reports the outcome after a child frame actually runs. A nonzero syscall error means the call was rejected before the child ran and the output struct is untouched.



### GetMsgSender

|            |   |
| ---------- | - |
| **Number** | 1 |

| Direction | Name     | Type              |
| --------- | -------- | ----------------- |
| out       | `sender` | `ContractAddress` |

Errors:

- `IsRootTransaction` if there is no caller (the syscall was made from a root transaction frame).

Returns the contract address of the contract that invoked the current call frame.



### GetCurrentAddress

|            |    |
| ---------- | -- |
| **Number** | 19 |

| Direction | Name      | Type              |
| --------- | --------- | ----------------- |
| out       | `address` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the contract address of the current call frame.



## Return



### Return

|            |   |
| ---------- | - |
| **Number** | 6 |

| Direction | Name                      | Type                                  |
| --------- | ------------------------- | ------------------------------------- |
| in        | `buffer`                  | `[u8]` (span)                         |
| in        | `revert_frame`            | `bool`                                |
| in        | `returned_auth_token_ids` | `[u8]` (span, interpreted as `[u32]`) |

Errors: none beyond the universal `Fault` / `NoSyscall`. Does not return to the caller (terminates execution of the current guest invocation).

Returns data and a set of auth-token ids from the current call frame and optionally marks the frame for revert. The return buffer is made available to the caller via `GetReturnedBuffer`. If the supplied buffer is too large, the entire invocation is reverted with a deterministic error.



### GetReturnedBuffer

|            |   |
| ---------- | - |
| **Number** | 7 |

| Direction | Name                                  | Type                                  |
| --------- | ------------------------------------- | ------------------------------------- |
| out       | `buffer`                              | `[u8]` (span)                         |
| out       | `written_len`                         | `RuntimeMemoryLength`                 |
| out       | `restored_auth_token_ids`             | `[u8]` (span, interpreted as `[u32]`) |
| out       | `restored_auth_token_ids_written_len` | `RuntimeMemoryLength`                 |

Errors:

- `NoReturnBufferAvailable` if no return buffer is available (either the most recent subcall failed, or no subcall has been made in this frame).
- `InvalidSyscallInput` if the `restored_auth_token_ids` output span byte length is not a multiple of the size of a `u32`.

Returns the return buffer and any restored auth-token ids from the most recent successful subcall invocation.



### Exit

|            |   |
| ---------- | - |
| **Number** | 8 |

No inputs. No outputs. Does not return.

Errors: none beyond the universal `Fault` / `NoSyscall`.

Terminates the current call frame immediately. The frame reverts and the caller sees a deterministic error with no return buffer available.



## Storage



### BytestringGetLen

|            |    |
| ---------- | -- |
| **Number** | 13 |

| Direction | Name     | Type                     |
| --------- | -------- | ------------------------ |
| in        | `key`    | `StorageKeyContractData` |
| out       | `length` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist in the current transaction view.
- `InvalidSyscallInput` if the key exists but holds a different storage type (e.g. NNInt rather than bytestring).

Returns the length of the bytestring stored at `key`.



### BytestringGet

|            |    |
| ---------- | -- |
| **Number** | 14 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| out       | `bytestring`  | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted.
- `InvalidSyscallInput` if the key exists but holds a different storage type.

Retrieves the bytestring stored at `key`.



### BytestringSet

|            |    |
| ---------- | -- |
| **Number** | 15 |

| Direction | Name         | Type                     |
| --------- | ------------ | ------------------------ |
| in        | `key`        | `StorageKeyContractData` |
| in        | `bytestring` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the bytestring is too long.

Writes the bytestring value at `key`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged.



### NonnegativeIntGet

|            |    |
| ---------- | -- |
| **Number** | 16 |

| Direction | Name                       | Type                     |
| --------- | -------------------------- | ------------------------ |
| in        | `key`                      | `StorageKeyContractData` |
| in        | `force_load_from_snapshot` | `bool`                   |
| out       | `current_set`              | `i128`                   |
| out       | `current_set_opt`          | `bool`                   |
| out       | `current_add`              | `i128`                   |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted (only returned when `force_load_from_snapshot` is true).
- `InvalidSyscallInput` if the key exists but holds a different storage type (only returned when `force_load_from_snapshot` is true).

Retrieves the NNInt value at `key`.

If `force_load_from_snapshot` is true, `current_set` will never be null: the syscall reads the snapshot value. A snapshot that is not an NNInt, or a prior write on this key that is not an NNInt, returns `InvalidSyscallInput`. A snapshot that does not exist, or was deleted by a prior write, returns `StorageKeyNotExist`.

If `force_load_from_snapshot` is false, the prior snapshot state is ignored unless the prior write on `key` is itself an NNInt write (in which case the parameters of that write are returned). If the prior write is not an NNInt or was a deletion, the syscall returns `(None, 0)` without error.



### NonnegativeIntSetAdd

|            |    |
| ---------- | -- |
| **Number** | 17 |

| Direction | Name        | Type                     |
| --------- | ----------- | ------------------------ |
| in        | `key`       | `StorageKeyContractData` |
| in        | `set_value` | `Option<i128>`           |
| in        | `add_value` | `i128`                   |

Errors:

- `InvalidSyscallInput` if the operation would always violate the NNInt floor (for example `set_add(1, -2)` or `set_add(-1, -1)`).

Sets or modifies the NNInt at `key`. `set_value` (if `Some`) supplies the base, and `add_value` is added as a delta. The resolved value must satisfy `value >= min(set, 0)`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged. See [Programming Model: NNInt](pages/programming-model/nnint.md) for commutativity rules.



### DeleteObject

|            |    |
| ---------- | -- |
| **Number** | 18 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Deletes the object at `key`. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged.



## Storage Flags

A transaction keeps one `StorageDeltaFlagSet` per storage key, separate from its writes. Every change the transaction commits on a key carries that key’s flags. `ExclusiveLock` (`0x1`) is the only flag: it gives the key’s change an exclusive lock for the whole block, so no concurrent transaction in the block can modify the key.

Writes never change a key’s flags. A lock requested after one write stays on the key through later writes in the same transaction, including writes from other call frames, until `ClearStorageFlags` withdraws it. Flag changes follow call frames like writes do: a successful frame passes them to its caller, and a reverted frame or failed `try_invoke` discards them.

Each flag syscall costs the same storage access gas as a write and does not read the ledger.



### SetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 36 |

| Direction | Name    | Type                                    |
| --------- | ------- | --------------------------------------- |
| in        | `key`   | `StorageKeyContractData`                |
| in        | `flags` | `StorageDeltaFlagSet` (`u32`, by value) |

Errors:

- `InvalidSyscallInput` if `flags` contains an unknown flag, or no write to `key` is pending in the current call frame’s view of the transaction.

Adds `flags` (bitwise OR) to the flags the transaction requests for `key`. A pending write is one made earlier in this frame, or inherited from a caller or a successful callee. A pending deletion counts. A value that exists only in the block snapshot does not.



### GetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 37 |

| Direction | Name    | Type                     |
| --------- | ------- | ------------------------ |
| in        | `key`   | `StorageKeyContractData` |
| out       | `flags` | `StorageDeltaFlagSet`    |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the flags the transaction requests for `key`, as visible in the current call frame. A key with no pending write returns `None` (`0`). Allowed in read-only frames.



### ClearStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 38 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Removes every flag the transaction requests for `key`, as visible in the current call frame. Does nothing if no write to `key` is pending.



## Retrocausal Queue



### RetrocausalQueueInsert

|            |    |
| ---------- | -- |
| **Number** | 20 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `queue_entry` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type that cannot be converted to a retrocausal queue, if the entry is too large, or if too many entries are inserted in the current transaction.

Inserts an entry into the retrocausal queue at `key`.



### RetrocausalQueueConsume

|            |    |
| ---------- | -- |
| **Number** | 21 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `peek`        | `bool`                   |
| out       | `queue_entry` | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `NoRetrocausalQueueEntry` if the queue is empty.
- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Consumes (or with `peek = true`, only inspects) the next entry from the retrocausal queue at `key`.



### RetrocausalQueuePeekLen

|            |    |
| ---------- | -- |
| **Number** | 30 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |
| out       | `len` | `RuntimeMemoryLength`    |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `NoRetrocausalQueueEntry` if the queue is empty.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Returns the length (in bytes) of the next entry in the retrocausal queue at `key`.



## Auth



### VerifySignature

|            |    |
| ---------- | -- |
| **Number** | 12 |

| Direction | Name         | Type                        |
| --------- | ------------ | --------------------------- |
| in        | `scheme`     | `i32` (CryptographicScheme) |
| in        | `signature`  | `[u8]` (span)               |
| in        | `public_key` | `[u8]` (span)               |
| in        | `message`    | `[u8]` (span)               |

No outputs: the result is the `SyscallErrorCode` itself (`None` on success).

Errors:

- `InvalidSyscallInput` if verification fails or the inputs are malformed (wrong key/signature size for the chosen scheme, unsupported scheme, etc.).

Verifies a cryptographic signature against a public key and message.



### GetAuthClaim

|            |    |
| ---------- | -- |
| **Number** | 25 |

| Direction | Name         | Type        |
| --------- | ------------ | ----------- |
| out       | `auth_claim` | `AuthClaim` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the authentication claim associated with the current transaction. Takes no input.



### ChangePublicKeyRegistration

|            |    |
| ---------- | -- |
| **Number** | 23 |

| Direction | Name         | Type                                |
| --------- | ------------ | ----------------------------------- |
| in        | `key_index`  | `u32`                               |
| in        | `key_scheme` | `Option<i32>` (CryptographicScheme) |
| in        | `key_bytes`  | `[u8]` (span)                       |
| in        | `key_weight` | `Option<u32>`                       |

Errors:

- `InvalidSyscallInput` if the registration is invalid or `key_index` is out of bounds.

Changes the public key registration for the current contract address at `key_index`. If `key_scheme` is `None`, the key is removed. Otherwise the key is set with the supplied scheme, bytes, and weight.



### WriteAddressRequiredWeight

|            |    |
| ---------- | -- |
| **Number** | 28 |

| Direction | Name              | Type                       |
| --------- | ----------------- | -------------------------- |
| in        | `required_weight` | `Weight` (`u32`, by value) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Writes the required-weight threshold for the current contract address. This is the minimum total weight of signing keys needed to authorize a transaction from this address.



### MintAuthToken

|            |    |
| ---------- | -- |
| **Number** | 31 |

| Direction | Name                    | Type          |
| --------- | ----------------------- | ------------- |
| in        | `expiry_height`         | `BlockHeight` |
| in        | `serialized_auth_token` | `[u8]` (span) |
| out       | `token_id`              | `u32`         |

Errors:

- `InvalidSyscallInput` if the serialized token fails to parse as a valid `AuthToken`, `expiry_height` is in the past, or minting would exceed the per-transaction auth-token cap.

Mints an authentication token for the current contract address.



### ConsumeAuthToken

|            |    |
| ---------- | -- |
| **Number** | 32 |

| Direction | Name                       | Type                  |
| --------- | -------------------------- | --------------------- |
| in        | `token_id`                 | `u32`                 |
| out       | `auth_payload`             | `[u8]` (span)         |
| out       | `token_minter`             | `ContractAddress`     |
| out       | `auth_payload_written_len` | `RuntimeMemoryLength` |
| out       | `unwrapped_token_id_start` | `u32`                 |
| out       | `unwrapped_token_id_count` | `u32`                 |

Errors:

- `InvalidSyscallInput` if the token is not owned by the current contract address, or the token has expired.

Consumes an authentication token owned by the current contract address. Returns the token’s auth payload, its minter, and the id range of any nested tokens unwrapped as a side effect.



## Address



### GetDeployAddress

|            |   |
| ---------- | - |
| **Number** | 9 |

| Direction | Name             | Type              |
| --------- | ---------------- | ----------------- |
| in        | `caller_address` | `ContractAddress` |
| in        | `nonce`          | `SHA256Hash`      |
| in        | `contract_hash`  | `SHA256Hash`      |
| out       | `to_be_deployed` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Computes the address that would be deployed for a contract with the given deployer address, nonce, and contract hash. Pure computation; does not deploy anything.



### DeployContract

|            |    |
| ---------- | -- |
| **Number** | 10 |

| Direction | Name               | Type              |
| --------- | ------------------ | ----------------- |
| in        | `nonce`            | `SHA256Hash`      |
| in        | `contract_hash`    | `SHA256Hash`      |
| out       | `deployed_address` | `ContractAddress` |

Errors:

- `InvalidSyscallInput` if the requested contract is not available for deployment, or the contract is a special precompiled (native) contract that cannot be deployed. A contract must either already exist on chain or be supplied in the transaction’s `contracts_to_deploy` field.
- `ContractAlreadyDeployed` if a contract with the same nonce and contract hash has already been deployed at the computed address in a previous block or earlier in this transaction. A contract can be deployed multiple times concurrently in the same block; if a contract must initialize only once, gate the initialization on a semaphore.

Deploys a contract with the specified nonce and contract hash at the computed address.



## Block



### GetBlockHeight

|            |    |
| ---------- | -- |
| **Number** | 29 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| out       | `result` | `BlockHeight` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the current block height.



### GetBlockTimepoint

|            |    |
| ---------- | -- |
| **Number** | 35 |

| Direction | Name              | Type        |
| --------- | ----------------- | ----------- |
| out       | `block_timepoint` | `TimePoint` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the timepoint of the block currently executing. The value is fixed by the coordinator before execution begins and is carried in the block’s `ProposalHeader`, so it is part of the block identity and is identical for every invocation in the block.

Like a block height, this is consensus data rather than a trusted clock: it is chosen by the proposer within whatever bounds the network’s validators enforce. Contracts should treat it as coarse-grained wall-clock time, suitable for expiries, vesting schedules, and deadlines, and must not rely on it for fine-grained ordering or as a source of randomness.



## Network



### GetNetworkHash

|            |    |
| ---------- | -- |
| **Number** | 34 |

| Direction | Name           | Type          |
| --------- | -------------- | ------------- |
| out       | `network_hash` | `NetworkHash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the network name, the identifier that separates this network’s blocks from those of every other network. It is fixed for the life of the network, so it is constant across every block and every invocation.

Transaction signatures already commit to this value (the signature preimage is `cxs(DomainSeparator("Transaction")) || network_hash || xdr(tx)`). Exposing it to contracts lets a contract bind its own off-chain signed messages to this network the same way, so a message signed for one network cannot be replayed against a contract at the same address on another.



## Transaction



### GetSourceTransactionHash

|            |    |
| ---------- | -- |
| **Number** | 11 |

| Direction | Name             | Type         |
| --------- | ---------------- | ------------ |
| out       | `source_tx_hash` | `SHA256Hash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the transaction that initiated the current execution.



### GetTransactionStatistics

|            |    |
| ---------- | -- |
| **Number** | 22 |

| Direction | Name        | Type                   |
| --------- | ----------- | ---------------------- |
| in        | `statistic` | `TransactionStatistic` |
| out       | `result`    | `u64`                  |

Errors:

- `InvalidSyscallInput` if the requested statistic does not exist or is not available in this configuration.

Returns a transaction statistic. Statistics may be disabled in release builds or production execution, and may be nondeterministic in test configurations. Nondeterministic stats are disabled in production settings.



## Error Codes

The full `SyscallErrorCode` enum, from `protocol/syscall_error.x`:

| Code | Name                               | Description                                                                                                                                                                                                                              |
| ---- | ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 0    | `None`                             | Success.                                                                                                                                                                                                                                 |
| 1    | `Fault`                            | A pointer argument is out of guest memory bounds. Any syscall can return this.                                                                                                                                                           |
| 2    | `NoSyscall`                        | The supplied syscall number is not supported. Any syscall can return this.                                                                                                                                                               |
| 3    | `IsRootTransaction`                | Cannot call `GetMsgSender` from a root invocation.                                                                                                                                                                                       |
| 4    | `Reentrance`                       | Reentrance guard violation: the invoked address is already on the call stack.                                                                                                                                                            |
| 5    | `ContractAlreadyDeployed`          | Attempt to deploy a contract twice (same nonce, contract hash, and deployer).                                                                                                                                                            |
| 6    | `NoReturnBufferAvailable`          | No return buffer from a child call frame. Either the most recent subcall failed or no subcall has been made in this frame.                                                                                                               |
| 7    | `InvalidSyscallInput`              | Invalid input to a syscall (type mismatch, value out of range, data too long, unknown storage flag, etc.).                                                                                                                               |
| 8    | `StorageKeyNotExist`               | The storage key does not exist in the current view.                                                                                                                                                                                      |
| 9    | `NoRetrocausalQueueEntry`          | The retrocausal queue is empty.                                                                                                                                                                                                          |
| 10   | `RetrocausalQueueReadLimitReached` | The transaction reached its concurrent RCQ read limit. The contract may use this as a stop condition.                                                                                                                                    |
| 11   | `InvokeDepthExceeded`              | The transaction already holds the maximum number of invocation frames open, so another would exceed the network’s cross-invoke depth bound. A resource limit, not a malformed call: the same invocation succeeds from a shallower frame. |

---

## XDR Protocol

Source: <https://docs.groundhog.dev/reference/xdr-protocol/>

Encoding boundaries and protocol definitions selected by Groundhog 0.1.27.



## Encodings

| Surface                                                                      | Encoding                                                             | Reference                                                                                                    |
| ---------------------------------------------------------------------------- | -------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `Transaction`, `SignedTransaction`, contract spec sidecars                   | Classic XDR                                                          | Protocol definitions below                                                                                   |
| Contract arguments, return values, exceptions, typed storage, event payloads | CXS, the compact encoding used by the SDK                            | [Contract Spec](pages/reference/contract-spec.md), [TypeScript Bindings](pages/tools/typescript-bindings.md) |
| Transaction signing preimage                                                 | CXS domain separator, raw network hash, then classic XDR transaction | [Authorization](pages/how-it-works/authorization.md)                                                         |
| Public JSON-RPC requests and responses                                       | JSON, with hex byte fields and decimal strings for large integers    | [JSON-RPC API](pages/reference/json-rpc-api.md)                                                              |

The Rust traits retain the names `ReadXDR` and `WriteXDR` for both encodings. Use generated SDK clients and TypeScript bindings for contract payloads; a classic XDR encoder produces different bytes.



## Source Definitions

These links use the protocol commit selected by bundle `0.1.27`.

| Definition                                                                                                                                      | Types                                                                |
| ----------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| [transaction.x](https://github.com/groundhogchain/protocol/blob/63c9284d8d5727e8355b0b3d01e5e40f15478a89/transaction.x)                         | `Invocation`, `Transaction`, `SignedTransaction`, invocation outputs |
| [types.x](https://github.com/groundhogchain/protocol/blob/63c9284d8d5727e8355b0b3d01e5e40f15478a89/types.x)                                     | Addresses, hashes, signatures, protocol scalar types                 |
| [storage_item.x](https://github.com/groundhogchain/protocol/blob/63c9284d8d5727e8355b0b3d01e5e40f15478a89/storage_item.x)                       | Storage items and deltas                                             |
| [header.x](https://github.com/groundhogchain/protocol/blob/63c9284d8d5727e8355b0b3d01e5e40f15478a89/header.x)                                   | Proposal header                                                      |
| [consensus.x](https://github.com/groundhogchain/protocol/blob/63c9284d8d5727e8355b0b3d01e5e40f15478a89/consensus.x)                             | Consensus values                                                     |
| [groundhog_contract_spec.x](https://github.com/groundhogchain/protocol/blob/63c9284d8d5727e8355b0b3d01e5e40f15478a89/groundhog_contract_spec.x) | Contract types, methods, events, and interface metadata              |

---

## Build with an Agent

Source: <https://docs.groundhog.dev/start/build-with-an-agent/>

Give your coding agent the Groundhog skill and docs, then build a counter application on Devnet with one prompt.

Give your agent the Groundhog instructions and docs, then copy the prompt below. The goal is a working counter application: a Rust contract on Devnet, typed bindings, and a React interface.



## 1. Install the skill

Run:

```bash
groundhog skill install
```

Select your coding agent and installation scope. This requires Node.js 22.20 or newer, npm, Git, and access to the private `groundhogchain/agent-skills` repository. Use existing Git, GitHub CLI, or SSH authentication. If the CLI is missing, start with [Install the CLI](pages/cli/install.md).

For offline reading, your agent can use `groundhog skill show` and then read a topic such as `groundhog skill show contracts`. This reads the CLI’s bundled skill, which can differ from the latest installed skill.



## 2. Share the docs

```bash
groundhog docs --background
```

Give your agent the printed Markdown index path. Open the printed browser URL for your own reading. This serves documentation, not a local blockchain. Use `groundhog docs stop` when you finish; the Markdown files remain available.

For an agent on another machine, use `groundhog docs export --output ./groundhog-docs` and share that folder. The destination must be new. The agent can start with `index.md`, choose a page, or read a bundle under `sections/`. `full.md` contains everything. Bundled docs are a snapshot; use the installed CLI’s help to confirm command behavior.



## 3. Copy the prompt

```text
Build a working Groundhog counter application for me on Devnet.

First read this project's AGENTS.md if present, run groundhog skill show,
and read the documentation at the URL or in the files I share. If you
cannot access the docs, ask me for a copy before guessing at an API.

Use the latest release installation instructions and preserve generated
dependency settings and lockfiles. Work in a new project unless I ask
you to extend an existing one. Preserve existing files, keys, and profiles.
Ask me to provide any missing Cargo or npm access through my environment.
Keep credentials and private keys out of this conversation and browser code.

Build and verify these stages:

1. Set up the CLI and a funded Devnet wallet. Use the hosted network;
   do not start a local blockchain node. A local documentation or app
   development server is fine.

2. Scaffold a Rust counter contract with the CLI. Build it and run its
   tests. Deploy it to Devnet with the funding described in the contract
   quickstart. Initialize the new counter to 10, increment by 5, and
   verify that its read-only view returns 15. Do not repeat initialization
   on a counter that has already been initialized for this walkthrough.

3. Generate TypeScript bindings from that contract's spec. Use the actual
   deployment address and generated methods rather than handwritten
   entrypoint IDs or a hardcoded example address.

4. Build a small React interface that displays the counter and has an
   Increment button. Use the Groundhog React library and typed bindings.
   Include loading, error, and pending-transaction states. Use a compatible
   browser wallet for signing; ask me to install or connect it and approve
   the test transaction when needed. Do not put a CLI signing key in the app.

5. Save the transaction evidence needed for recovery before broadcasting,
   wait for successful committed execution, and refresh the counter.
   Prevent duplicate submissions while a request is pending. If the outcome
   is uncertain, check the original transaction instead of signing another.

6. Run the app's build and test the browser flow. Verify that one successful
   increment changes the displayed counter by one. If wallet approval or
   a network service is unavailable, state which stage remains unverified.
   Do not replace a failed Devnet call with a mock and report success.

Use the CLI and contract quickstarts for setup and deployment, the
TypeScript binding docs for code generation, and the React and wallet
integration docs for the interface. Use groundhog <command> --help to
confirm command options. Adapt the read-only React quickstart to this
counter rather than treating it as a complete wallet application.

Finish with the project location, how to run the app, its contract address,
the transaction hashes you verified, and a short summary of what passed
and what still needs my action.
```

The prompt uses the [CLI](pages/get-started/cli.md) and [contract](pages/get-started/contract.md) quickstarts, [TypeScript bindings](pages/tools/typescript-bindings.md), [React](pages/react.md), and [wallet integration](pages/tools/wallet-integration.md). Your agent can work through them while you provide access and approve wallet interactions.

For a smaller task, use the prompt in an individual [quickstart](pages/get-started.md).

---

## For Backend Developers

Source: <https://docs.groundhog.dev/start/for-backend-developers/>

Map your Postgres and database experience to Groundhog's programming model.

Database snapshot isolation is a useful starting point for Groundhog. Transactions share a committed block snapshot, but their writes follow typed storage merge rules rather than SQL conflict rules.



## Shared Snapshot

Every transaction in a block starts from the previous block’s committed state. Ordinary storage reads include its own changes and successful child calls, but not other transactions’ writes. `RetrocausalQueue` has separate rules for observing concurrent inserts. Each transaction produces typed changes, called **deltas**. Compatible deltas form the next committed state. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas).



## Deltas, Not Assignments

The core shift from a database: instead of `UPDATE accounts SET balance = 50`, you call `increase(5)`, meaning “adjust this value by +5.” This is `UPDATE accounts SET balance = balance + 5`. You express **how the value should change**, not what it should become.

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);          // checked debit
    self.balances.at_mut(receiver).lazy_increase(amount);    // deferred bound check
}
```

[`Balance`](pages/programming-model/storage-types.md#balance) is the SDK type for this pattern. Both calls record deltas that can merge with concurrent transactions. `decrease()` loads the sender’s balance so an insufficient debit fails during execution. `lazy_increase()` skips the receiver load and defers its bound check until the delta batch is reserved. If two transactions debit 20 and 30 from a balance of 100, both can land and the next balance is 50. Applying the changes in either order gives the same result, so the operations **commute**.

That is enough of the model for most contract code. [Merged Deltas](pages/programming-model/execution.md#merged-deltas) explains how storage types decide which concurrent changes can land together. [NNInt and concurrent updates](pages/programming-model/nnint.md) covers the lower-level `set_add` representation behind `Balance`, including base matching and the difference between `strict_inc`, `inc`, and `set`.

**Relative updates such as `SET col = col + ?` map naturally to mergeable integer operations.** Compatibility still depends on bounds and the transaction’s other changes. Absolute replacements can conflict when they assign different values.

***



## Conflicts and the Mempool

When deltas conflict, the transaction is excluded and returned to the mempool for possible inclusion in a later block. Contract code does not retry the operation. Clients still need to track confirmation and transaction expiry.

The balance constraint works the same way. If two concurrent withdrawals together exceed the available balance, one or more transactions are excluded. This is `CHECK (balance >= 0)` enforced by the storage model rather than application code.

***



## What’s Different From a Database

- **No ad-hoc queries.** Storage is key-value with typed values. You access data by key, not by query. An indexer provides query capabilities off-chain.
- **No JOINs.** If you need data from two Maps, you read both explicitly.
- **Deterministic execution.** No `NOW()`, no `RANDOM()`, no HTTP calls.
- **Write costs are deposits, not fees.** Storing data locks HOG tokens proportional to bytes stored. Delete the data, get the tokens back.
- **Gas limits exist but cost zero.** Gas meters computation (prevents infinite loops) but no tokens are burned. Your free HOG balance provides scheduling capacity. The declared gas limit determines how much capacity the transaction uses.

***



## Next Steps

For storage type details (`Balance`, `NNInt`, `Map`, `Vector`, `Value`, `Bytestring`, `CapacityConstraint`, and `RetrocausalQueue`) and their conflict semantics, see [Programming Model: Storage Types](pages/programming-model/storage-types.md). For the contract-level execution model, see [Merged Deltas](pages/programming-model/execution.md#merged-deltas).

Ready to write code? The [contract quickstart](pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## For Blockchain Developers

Source: <https://docs.groundhog.dev/start/for-blockchain-developers/>

Map your Ethereum, Solana, or Move experience to Groundhog's programming model.

The contract lifecycle is familiar: write, test, deploy, and call. The main changes are how storage updates combine and how execution and storage are funded. This page introduces those shifts using a Solidity transfer as the starting point.

***



## Token Transfers

A token transfer on Solidity:

```solidity
function transfer(address to, uint256 amount) public {
    require(balances[msg.sender] >= amount, "insufficient");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

The same transfer on Groundhog:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The code stays familiar. `balances` is a `Map<ContractAddress, Balance>`. Calling `at_mut(address)` selects the balance that will change and returns a mutable handle. Selecting it does not load the balance.

`decrease(amount)` loads the sender’s snapshot balance because the contract needs to fail immediately when funds are insufficient. `lazy_increase(amount)` skips the receiver load because the contract does not need an immediate overflow result. Its bound is checked when the transaction’s completed delta batch is admitted. Both calls produce deltas that can merge with compatible transactions. `Balance` accepts only nonnegative amounts and exposes no absolute `set` operation.

That is enough of the model for this transfer. [Build a Token](pages/tutorials/build-a-token.md) uses this pattern in a complete contract. [Merged Deltas](pages/programming-model/execution.md#merged-deltas) explains how Groundhog combines changes across a block.

***



## Reentrancy and Balance Checks

`Balance::decrease` checks the transaction’s current balance view. The runtime also checks aggregate bounds when concurrent deltas are reserved. This does not replace authorization or application-specific checks.

Contract calls also have different reentrancy rules from the EVM. See the [EVM reentrancy comparison](pages/ecosystem/evm.md#reentrancy) for that call pattern, and [Authorization](pages/how-it-works/authorization.md) for caller checks and signed permissions.

***



## Resource and Transaction Rules

Groundhog exposes these rules to contract developers:

- **Gas price estimation.** Gas limits exist for metering, but gas costs zero. The declared gas limit still consumes scheduling capacity.
- **Ordering-sensitive balance updates.** Commutative balance deltas have the same merged outcome in any execution order. Application flows that conflict still need protocol-aware design.
- **Nonces.** Replay protection uses a unique expiry-height and nonce pair, without a sequential account counter.
- **Fee-driven compute tuning.** Gas limits still bound each transaction and child call, but using more gas does not increase a token fee.
- **Access lists.** Unlike Solana, where every account a transaction touches must be declared up front, Groundhog discovers storage access during execution. (EVM only requires explicit access lists when opting into EIP-2930.)
- **Storage slot packing.** Typed fields via `#[sdk::storage]`. No manual layout, no packing variables into 256-bit slots.
- **TTL management.** No storage expiry. Data persists as long as its HOG deposit is held. Delete the data, get the deposit back.

***



## The Programming Model in Brief

Choose operations that express the change you intend. Use `Balance` for ordinary balance adjustments, `Map` for separate records, and other storage types when the application needs different merge rules. Compatible arithmetic can combine, but ordering-sensitive workflows still need an explicit design.

[Contract Execution](pages/programming-model/execution.md) explains snapshots and deltas. [Storage Types](pages/programming-model/storage-types.md) covers the available APIs, and [NNInt and concurrent updates](pages/programming-model/nnint.md) covers the lower-level integer model.

***



## Storage Choices and Parallelism

The transfer example uses relative balance adjustments so compatible transfers can share a block. Replacing those adjustments with absolute values changes the conflict rules. Review your data model, not just the syntax, when adapting an existing contract.

***



## Next Steps

Continue in layers:

1. [Contract quickstart](pages/get-started/contract.md) builds and deploys your first contract.
2. [Build a Token](pages/tutorials/build-a-token.md) applies checked and lazy balance operations in a complete ERC-20-style contract.
3. [Contract Execution](pages/programming-model/execution.md) and [Storage Types](pages/programming-model/storage-types.md) give the full contract-author model.
4. [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) explains the engine’s reservation machinery.

For a detailed Solidity-to-Groundhog mapping, see [EVM & Solidity](pages/ecosystem/evm.md).

---

## For Distributed Systems Developers

Source: <https://docs.groundhog.dev/start/for-distributed-systems-developers/>

Map your distributed systems experience to Groundhog's programming model.

Commutative operations are a useful starting point for Groundhog. Its typed deltas combine changes within a consensus block, rather than reconciling independently writable replicas.

***



## Your Head Start

You already think in terms of commutative operations. You know that `x + 5` and `x + 3` produce the same result in any order. You know that operations on independent keys don’t interact. You’ve designed systems around these properties.

That instinct is exactly right for Groundhog. [`Balance`](pages/programming-model/storage-types.md#balance) exposes checked and lazy increases and decreases for non-negative values. Lower-level [`NNInt`](pages/programming-model/storage-types.md#nnint) works like a counter whose signed changes combine additively. `Map<K, V>` gives you key-level independence. If you’ve ever reached for a PN-Counter or a per-key CRDT map, you already know why these primitives exist.

The key distinction is where coordination happens.

***



## Coordination at Block Boundaries

**Groundhog has consensus.** CRDTs solve the problem of replicas that diverge and must eventually agree without coordination. Groundhog has a consensus protocol. Every block is agreed upon by the network. The types don’t exist to achieve convergence across unsynchronized replicas. They exist to enable parallel execution *within* a single consensus round.

All transactions in a block execute against the same frozen snapshot. They produce typed changes, called [deltas](pages/programming-model/execution.md#merged-deltas). The runtime checks which changes can coexist, and each finalized block contains one committed result. There’s no divergence to reconcile.

This means:

- **No causal metadata.** No vector clocks, no dot stores, no version vectors. The block boundary is the synchronization point. There’s no partial order to resolve.
- **Balance limits are enforced.** A PN-Counter can go negative. Groundhog’s `Balance` API keeps ordinary balances non-negative, and the runtime checks the combined result when lazy deltas commit. If debits exceed the available value, one or more transactions are excluded and returned to the mempool. No tombstones, no compensating operations.
- **Each block has one result.** There is no continuous merge through anti-entropy or gossip. Nodes that have applied the same finalized block agree on its state.
- **Finalized state.** Nodes may lag while receiving or replaying blocks; applications read the state at the serving node’s available height.

***



## If You Don’t Know Any of This

That’s fine. Groundhog doesn’t require distributed systems knowledge. Use `Balance` for balances and allowances, `NNInt` for signed counters or votes, and `Map` for per-key data. The types handle commutativity for you. The [For Backend Developers](pages/start/for-backend-developers.md) guide maps the same concepts from database experience, which may be a better starting point.

***



## Next Steps

For the contract-level model, see [Merged Deltas](pages/programming-model/execution.md#merged-deltas). For the storage type API, see [Storage Types](pages/programming-model/storage-types.md). For concurrent delta reservation and the engine’s actual conflict timing, see [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved).

Ready to write code? The [contract quickstart](pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## Block Explorer

Source: <https://docs.groundhog.dev/tools/block-explorer/>

Use the devnet explorer to look up transactions, inspect receipts and events, and check address activity.

Use the [devnet explorer](https://explorer.thruput.network/) to look up transactions, inspect receipts and events, and check address balances and recent activity.



## Look Up a Transaction or Address

1. Open the [devnet explorer](https://explorer.thruput.network/).
2. Paste a transaction hash or address into the search field. Use the full `0x`-prefixed, 32-byte value (64 hexadecimal characters after `0x`).
3. Select **Search**.

The home page also lists recent HOG transfers. Select a transaction to inspect it, or follow an address link to view that address.



### Transactions

The transaction page shows:

- Transaction status and, once committed, block height and execution result.
- Receipt events, including decoded token transfers, mints, and burns where supported.
- Raw receipt data for debugging.

Events without a supported decoder appear as raw topics and data.



### Addresses and Tokens

The address page shows the native HOG balance. For non-token addresses, it also shows recent transactions and sent or received HOG transfers. Recognized token contracts show token metadata and token transfer history. Other contracts can show their emitted events.

Address transaction history combines transactions whose root invocation targets the address with HOG transfer activity. It does not cover every nested invocation or every token transfer involving the address.



### Share a Result

Copy the page URL to share a transaction or address:

```text
https://explorer.thruput.network/tx/<transaction-hash>
https://explorer.thruput.network/address/<address>
```



## Inspect State Without an Explorer

Use the CLI for terminal workflows, local nodes, or when the explorer is unavailable:

```bash
groundhog balance <wallet-or-address> --profile devnet
groundhog view <contract-or-alias> <method> --profile devnet
groundhog storage <contract-or-alias> 0x<32-byte-key> --profile devnet
```

These commands use devnet. For a local node, use `--profile local` instead.

Use the [JSON-RPC API](pages/reference/json-rpc-api.md) directly for receipts, status, address-rooted history, and event pagination.

---

## Faucet

Source: <https://docs.groundhog.dev/tools/faucet/>

Request test HOG for a Devnet wallet and check the funding result.

Use the [hosted faucet](https://thruput-faucet.up.railway.app) to request Devnet HOG in your browser.



## CLI

Create a wallet with the CLI, then fund it through the hosted faucet:

- `groundhog wallet create` derives an empty native account for your signing key and saves its local binding. It does not contact the faucet or deploy a wallet contract.
- `groundhog airdrop` funds an existing wallet or address.

Run interactive setup if you have not already:

```bash
groundhog init
groundhog config get devnet --sources
```

Init creates the global `devnet` profile with its RPC and faucet URLs.

The faucet’s `GET /v1/network` descriptor identifies the network, its RPC endpoint, and the `networkHash` used to bind transaction signatures. The CLI checks the descriptor and live RPC identity before requesting hosted funding.

```bash
DEVNET_FAUCET_URL=$(groundhog --json config get devnet | jq -er '.data.faucetUrl')
curl -fsS "$DEVNET_FAUCET_URL/health" | jq .
curl -fsS "$DEVNET_FAUCET_URL/v1/network" | jq .
```

On a fresh setup, accept key generation during init to create and select the key named `default`. The commands below assume that fresh-install path. If you selected another key, substitute its name for `default`.

Create and inspect the wallet:

```bash
groundhog wallet create --profile devnet
groundhog wallet ls --profile devnet
```

With no `--key` or `--name`, wallet creation uses the selected key and gives the wallet the same name. It also establishes the profile’s default wallet when none exists. Wallet creation itself does not fund the address.

Request an airdrop. Once the default wallet exists, omit the recipient:

```bash
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Remote CLI airdrops call `groundhog_requestAirdrop` through the profile’s public RPC endpoint. The faucet selects the amount, so omit `--amount`. Hosted requests are subject to the policy advertised by that deployment. Do not treat current amounts, cooldowns, or quotas as stable Devnet constants.

The CLI stores an idempotency nonce for each remote airdrop attempt. If a request is pending or the outcome is unclear, keep the cache record and rerun the exact same command. This resumes the same logical request instead of creating another transfer. A timeout, cancellation, or network error does not prove that the transfer failed.

A succeeded response means the airdrop transaction committed. Clients must still check `status.result` for execution success.



## TypeScript

Cluster-aware Devnet and Localnet clients expose the high-level `requestAirdrop` action. A full local node serves the same RPC method and funds the request from its `dev-0` faucet. The action creates an idempotency nonce, polls pending attempts, and stops on timeout or cancellation:

```ts
const airdrop = await client.requestAirdrop({
  recipient: account.address,
});

if (airdrop.status.result !== "ok") {
  throw new Error(`Airdrop execution failed: ${airdrop.status.result}`);
}
```

A timeout or cancellation only stops the client from waiting. The request may still commit. Use `requestAirdropAttempt()` when your application must persist and reuse its own `clientNonce`.

Prefer `groundhog_requestAirdrop` for public airdrops because it provides the network’s RPC contract.

For a first wallet and funding transaction, follow the [CLI quickstart](pages/get-started/cli.md). Continue with the [contract quickstart](pages/get-started/contract.md) to deploy and call a contract on Devnet.

---

## Rust API Docs

Source: <https://docs.groundhog.dev/tools/rust-api-docs/>

Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.

Use Rustdoc for exact signatures, trait bounds, and source links. Use this site for contract tasks and the programming model.



## Match your project

The hosted links below select one SDK release. If your project’s dependency differs, select its version at [crates.thruput.network](https://crates.thruput.network) or build its resolved SDK documentation locally:

```bash
cargo doc -p sdk --no-deps --open
```

Run this from the generated contract project after [Cargo access setup](pages/cli/install.md#configure-cargo-access). Hosted Rustdoc may require your onboarding credentials.



## Common Links

| Need                        | Rustdoc                                                                                                                                                                                                                                                    |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| SDK overview and re-exports | [`sdk`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/index.html)                                                                                                                                                                                 |
| Contract types              | [`ContractAddress`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.ContractAddress.html), [`SHA256Hash`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.SHA256Hash.html)                                         |
| Native tests                | [`TestEnvironment`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/struct.TestEnvironment.html)                                                                                                                                                    |
| Storage types and traits    | [`sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html)                                                                                                                                                                |
| Balances and counters       | [`Balance`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/balance/struct.Balance.html), [`NNInt`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/nnint/struct.NNInt.html)                                                 |
| Shared capacity             | [`CapacityConstraint`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/capacity_constraint/struct.CapacityConstraint.html)                                                                                                                  |
| Keyed and indexed storage   | [`Map`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/map/struct.Map.html), [`Vector`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/vector/struct.Vector.html)                                                          |
| Typed and raw values        | [`Value`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/value/struct.Value.html), [`Bytestring`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/bytestring/struct.Bytestring.html)                                        |
| Queues and nested state     | [`RCQ`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/rcq/struct.RCQ.html), [`Node`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/node/struct.Node.html)                                                                |
| Contract and storage macros | [`#[contract]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract.html), [`#[storage]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.storage.html)                                                                       |
| Error macro                 | [`#[contract_exception]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract_exception.html)                                                                                                                                             |
| Events                      | [`Event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/derive.Event.html), [`log_event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/event/fn.log_event.html)                                                                         |
| Error helpers               | [`throw`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.throw.html), [`ensure`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.ensure.html), [`OrThrow`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/trait.OrThrow.html) |
| Deployment                  | [`deploy_contract`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/deploy/fn.deploy_contract.html)                                                                                                                                                 |
| Mock registration           | [`declare_mock_contract!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.declare_mock_contract.html)                                                                                                                                        |
| Compile-time hashes         | [`sha256_static!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.sha256_static.html), [`hash_ident!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.hash_ident.html)                                                         |



## How to Use These Docs

- Start with [Testing](pages/programming-model/testing.md) to choose native, artifact, or RPC tests.
- Use [storage API tables](pages/reference/storage-types.md) for common operations and [storage guidance](pages/programming-model/storage-types.md) to choose a type.
- Use [SDK Macros](pages/reference/sdk-macros.md) for parameters and generated items.
- Follow Rustdoc source links when you need the implementation behind an API.

---

## Use contract bindings

Source: <https://docs.groundhog.dev/tools/typescript-bindings/>

Select a generated interface, bind a deployment address, and work with typed arguments and results.

Bindings describe a contract’s API. The client runtime uses them to encode arguments and decode results, exceptions, and events. A binding does not select a network or deployment address.



## Obtain the binding

The client supplies standard bindings such as `ERC20` through `@groundhogchain/client/contracts`. For a custom contract, obtain its generated `.ts` file, address, and network from the contract author.

Generate a binding yourself only when you have its build or canonical spec. See [CLI code generation](pages/cli/codegen.md) and [the contract-side handoff](pages/contracts/client-bindings.md).



Regenerate when methods, argument or return types, declared exceptions, or events change. Keep the generated file and deployment from the same interface build. Put application wrappers in separate files.



## Select an Interface Version

```ts
import { ERC20 } from "@groundhogchain/client/contracts";

const tokenInterface = ERC20.v0_1;
```

Methods and their types live under an interface’s compatibility major. A generated counter might export `Counter.v0_1`; use the actual exports in its generated file rather than reconstructing names.

```ts
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;
const args: CounterVersions.v0_1.IncrementArgs = { amount: 1n };
```

The value alias does not create a TypeScript type namespace. Keep the full path for explicit type annotations.



## Bind a deployment

```ts
import { getContract } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { client } from "./client.js";

const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
const supply = await hog.totalSupply.view({ args: undefined });
```

`getContract` binds the descriptor to an address and client. It does not deploy or authorize anything. Use [Read contract data](pages/typescript/reads.md) for view behavior and caller context.



## Method Descriptors

| API                                                               | Purpose                                                  |
| ----------------------------------------------------------------- | -------------------------------------------------------- |
| `method.invocation(contract, gasLimit, args)`                     | Build calldata and the target invocation                 |
| `method.call({ contract, gasLimit, args })`                       | Retain result and exception decoders with the invocation |
| `method.view({ client, contract, args })`                         | Read a typed value with height and events                |
| `method.viewOutcome(...)`                                         | Return a typed return/abort/fault outcome                |
| `method.decodeArgs(bytes)`                                        | Decode complete calldata                                 |
| `method.decodeReturn(bytes)` / `decodeException(bytes)`           | Decode known method output                               |
| `method.decodeReceipt(receipt)` / `decodeReceiptOutcome(receipt)` | Decode a receipt for that root method                    |

Direct descriptor calls can omit absent arguments. Bound argumentless views use `{ args: undefined }`. Public argument names use camelCase; ABI names remain in metadata. Contract integers use `bigint`.



## Execute and Decode

Build calls with `.call(...)` when the application needs typed return values, then pass them to a wallet’s `executeCallsAndWait`. Returned values follow call order. See [Send transactions](pages/typescript/transactions.md).

Receipt decoders require the known root method. For wallet-wrapped calls, use the wallet execution helpers or `decodeExecution(receipt, calls)` instead of treating the receipt as the child’s receipt. See [Track transaction results](pages/typescript/transaction-status.md#decode-the-correct-method).



## Exceptions

Each interface exposes declared and unknown exception types. A declared exception has `kind: "declared"`, selector, name, decoded value, and a symbolic variant for enum errors. An unknown selector has `kind: "unknown"`, selector, and its raw data.

Return and declared-exception decoders reject trailing bytes. Unknown exceptions retain the bytes they cannot interpret. A successful transaction whose result cannot be decoded is still a successful execution.



## Events



Events use their defining crate, version, module, and type path. A descriptor builds topic filters, decodes event rows, and selects events from receipts. See [Read events](pages/typescript/events.md) for examples and pagination.



## Type Mapping

Bindings describe structs, enum variants, unions, tuples, and optional values. Use the generated types rather than rebuilding their shapes or encoding calldata manually.

| Contract type              | TypeScript type                        |
| -------------------------- | -------------------------------------- |
| Void                       | `void`                                 |
| Bool                       | `boolean`                              |
| Integer                    | `bigint`                               |
| String                     | `string`                               |
| Address                    | `ContractAddress`                      |
| Bytes / vector of u8       | `Uint8Array`                           |
| Other vectors              | `T[]`                                  |
| Fixed bytes                | `FixedBytes<N>`                        |
| Fixed arrays of length 0–3 | Exact readonly tuple                   |
| Longer fixed arrays        | `FixedArray<T, N>`                     |
| Tuple                      | Readonly tuple                         |
| Option                     | `T \| null`                            |
| Named struct               | Interface in its spec-ID namespace     |
| Enum                       | Bigint value union and const object    |
| Union                      | Discriminated `{ case, value? }` union |
| SignedToken                | `SignedToken<T>` placeholder           |

`fixedBytes` validates and brands mutable bytes; `fixedArray` returns a frozen copy. `signedToken<T>()` supplies a zero-byte placeholder, not authorization. See [Addresses and amounts](pages/typescript/values.md) for input conversion.



## Standard Bindings

The client includes versioned DefaultWallet and ERC-20 interfaces, plus related metadata, permit, and signed-operation interfaces. Use the [generated client API](https://client-ts.thruput.network/) for the complete export list.

---

## Client API reference

Source: <https://docs.groundhog.dev/tools/typescript-sdk/>

TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.

| Reference                                                      | Purpose                                |
| -------------------------------------------------------------- | -------------------------------------- |
| [Generated client API](https://client-ts.thruput.network/)     | Complete types, overloads, and exports |
| [Generated protocol API](https://protocol-ts.thruput.network/) | Protocol types and codecs              |
| [JSON-RPC API](pages/reference/json-rpc-api.md)                | Wire methods and responses             |
| [TypeScript overview](pages/typescript.md)                     | Application model and task guides      |



## Install

| Package                         | Use                                     | Instructions                                      |
| ------------------------------- | --------------------------------------- | ------------------------------------------------- |
| `@groundhogchain/client`        | Application client and contract runtime | [Package setup](pages/typescript/setup.md)        |
| `@groundhogchain/protocol`      | Protocol-only constants and wire types  | [Package setup](pages/typescript/setup.md)        |
| `@groundhogchain/contract-spec` | Schema tooling                          | [Contract spec](pages/reference/contract-spec.md) |



## Connect to a Cluster

| API                                              | Behavior                                                                                  |
| ------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| `createGroundhogClient({ cluster, transport? })` | Async client creation with network identity validation                                    |
| `devnet(options?)`                               | Hosted development network; unpinned unless given `networkHash`; declares airdrop support |
| `localnet(options?)`                             | Local endpoint and default local identity; override with the matching runtime identity    |
| `mainnet(options)`                               | Requires an explicit endpoint                                                             |
| `defineCluster(descriptor)`                      | Custom name, endpoint, hash pin, and expected capabilities                                |
| `getChainTip()` / `getVersion()`                 | Current tip and release/wire identity                                                     |
| Usage                                            | [Connect to a network](pages/typescript/connect.md)                                       |



## Exact Amounts and Common Types

| API                                          | Result / rule                                                           |
| -------------------------------------------- | ----------------------------------------------------------------------- |
| `parseUnits(text, decimals)`                 | Exact signed `bigint`; rejects malformed input and excess precision     |
| `formatUnits(value, decimals)`               | Decimal string                                                          |
| `addressFromHex(text)` / `hashFromHex(text)` | Typed address or hash from `0x` hex                                     |
| `toHex0x(bytes)`                             | `0x`-prefixed display encoding                                          |
| `gasAmount(bigint)`                          | Typed computation budget                                                |
| `ParseUnitsError`                            | `code: "malformed" \| "precision"`; invalid decimals throw `RangeError` |
| Usage                                        | [Addresses and amounts](pages/typescript/values.md)                     |



## Choose an Account Model



| API                                                                             | Inputs / behavior                                                                                                                                                     |
| ------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createPubkeyAccount({ signer, nonce? })`                                       | Ed25519 signer; address nonce defaults to `0n`                                                                                                                        |
| `createSourceAddressAccount({ address, signers, allowedKeys, requiredWeight })` | Existing stored-auth account; does not write auth data                                                                                                                |
| `createWalletClient({ client, account, invocationAdapter? })`                   | Separate signer-bound client; pubkey accounts default to DefaultWallet                                                                                                |
| `networkHash` wallet option                                                     | Required for a client without validated network identity                                                                                                              |
| `createProviderWalletClient(...)`                                               | External wallet adapter; see [provider API](pages/tools/wallet-provider.md#sdk-adapter-behavior)                                                                      |
| Usage                                                                           | [Accounts and wallet clients](pages/typescript/wallet-clients.md), [script setup](pages/typescript/accounts.md), [browser wallets](pages/tools/wallet-integration.md) |



## Fund and Execute a Call

| API                                                  | Result / behavior                                                                                            |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `requestAirdrop(options?)`                           | Poll one funding attempt; account-defaulted on an airdrop-capable signer wallet                              |
| `requestAirdropAttempt(request)`                     | Single application-controlled funding attempt                                                                |
| `prepareExecution(request)`                          | Unsigned wallet-root transaction                                                                             |
| `execute(request)`                                   | Submitted hash; signer-based wallet                                                                          |
| `executeAndWait(request, options?)`                  | Successful committed receipt and hash                                                                        |
| `executeCallsAndWait({ calls, gasLimit }, options?)` | Successful receipt plus ordered typed child values                                                           |
| `walletGasLimit(invocations, overhead)`              | Sum invocation budgets, checking u64 bounds; pass `call.invocation` for typed calls; does not estimate usage |
| Usage                                                | [Send transactions](pages/typescript/transactions.md)                                                        |



## Typed Calls and Observation Recovery

| API / error                                 | Meaning                                                             |
| ------------------------------------------- | ------------------------------------------------------------------- |
| `getTransactionStatus(hash)`                | One status lookup                                                   |
| `getTransactionReceipt(hash)`               | One committed-receipt lookup; `null` when unavailable               |
| `waitForTransactionReceipt(hash, options?)` | Wait for a receipt, including failed execution                      |
| `waitForExecution(client, hash, options?)`  | Wait and require successful execution                               |
| `TransactionExecutionError`                 | Failed committed `receipt`                                          |
| `TransactionObservationError`               | Known `txHash` plus observation and optional submission causes      |
| `ExecutionDecodeError`                      | Successful receipt whose child return data failed decoding          |
| `ExecutionReturnUnavailableError`           | Successful receipt without child returns                            |
| Usage                                       | [Track transaction results](pages/typescript/transaction-status.md) |



## Use a Local Account



| API                             | Result / requirement                                                                   |
| ------------------------------- | -------------------------------------------------------------------------------------- |
| `loadLocalDevAccount(options?)` | Node-only manifest-verified native pubkey address, signer, role, and network hash      |
| `role` / `roleOffset`           | Select role and zero-based position; defaults to first `local_user`                    |
| Manifest selection              | `GROUNDHOG_RUNTIME_MANIFEST`, otherwise active CLI configuration                       |
| Usage                           | [Local bootstrap accounts](pages/typescript/accounts.md#use-a-local-bootstrap-account) |



## Deploy Through a Wallet

| API                                                                   | Result / requirement                                                                   |
| --------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `prepareContractDeployment({ deployer, contract, deploymentNonce? })` | Contract hash, nonce, and predicted address; no submission                             |
| `rv32Contract(artifact)`                                              | Protocol wrapper for nonempty artifact bytes                                           |
| `DeploymentOptions`                                                   | Required `gasLimit` and raw HOG `amount`; optional `initializer`                       |
| `prepareDeployment(deployment, options)`                              | Unsigned deployment transaction                                                        |
| `deployContract(deployment, options)`                                 | Submitted hash and predicted address; signer wallet                                    |
| `deployContractAndWait(deployment, options, controls?)`               | Successful deployment with verified address; provider form requires lifecycle controls |
| Usage                                                                 | [Deploy a contract](pages/typescript/deployment.md)                                    |



## Typed Views

| API                                         | Result / behavior                                                                               |
| ------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| `getContract({ binding, address, client })` | Bound method collection                                                                         |
| `method.view(options)`                      | Typed value, height, and events                                                                 |
| `method.viewOutcome(options)`               | `return`, `abort`, or `fault`                                                                   |
| `ContractViewError`                         | Contract abort or fault                                                                         |
| `ContractDecodeError`                       | Malformed contract data                                                                         |
| Usage                                       | [Read contract data](pages/typescript/reads.md), [bindings](pages/tools/typescript-bindings.md) |



## Cancellation and Read Errors

| API                                    | Rule                                                                       |
| -------------------------------------- | -------------------------------------------------------------------------- |
| `signal`                               | Request options for actions; inside view options for generated/bound views |
| `classifyReadError(error, { signal })` | `transient`, `permanent`, `cancelled`, or `unknown`; no automatic retry    |
| Cancellation                           | Cancels observation, not onchain execution                                 |
| Usage                                  | [Read cancellation](pages/typescript/reads.md#cancel-stale-reads)          |



## HTTP Batching

| Option                                              | Default / meaning                                         |
| --------------------------------------------------- | --------------------------------------------------------- |
| `HttpTransport(url, { timeoutMs, headers, batch })` | Configure the HTTP request layer                          |
| `batch`                                             | Off by default; `true` selects default batching settings  |
| `maxSize`                                           | 100 entries; allowed range 1–1,000                        |
| `waitMs`                                            | 0ms scheduling window                                     |
| Usage                                               | [Configure HTTP transport](pages/typescript/transport.md) |



## Event Pages

| API                                                                            | Result / behavior                                     |
| ------------------------------------------------------------------------------ | ----------------------------------------------------- |
| `getContractEvents({ event, contractAddresses, topics?, ...query }, options?)` | One typed page with event identity and indexer bounds |
| `iterateEventPages(query, options?)`                                           | Raw pages on demand; empty cursor ends the walk       |
| `Event.filter(input)` / `Event.decode(raw)`                                    | Generated topic filter and payload decoder            |
| `Event.allFromReceipt(...)` / `singleFromReceipt(...)`                         | Matching receipt events, filtered by emitter          |
| Usage                                                                          | [Read events](pages/typescript/events.md)             |



## Receipt Decoding

| API                                             | Requirement                                                                                   |
| ----------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `decodeExecution(receipt, calls, adapter?)`     | Successful wallet receipt and retained ordered call descriptors                               |
| `method.decodeReceipt` / `decodeReceiptOutcome` | Descriptor must identify the root method                                                      |
| Usage                                           | [Decode the correct method](pages/typescript/transaction-status.md#decode-the-correct-method) |



## Low-Level Signing

| API                                                  | Role                                                                              |
| ---------------------------------------------------- | --------------------------------------------------------------------------------- |
| `prepareTransaction`                                 | Build a root transaction and its authorization claim                              |
| `signTransaction(transaction, signers, networkHash)` | Sign the network-bound preimage                                                   |
| `sendTransaction(signed)`                            | Submit signed bytes                                                               |
| Transaction hash                                     | SHA-256 of unsigned transaction XDR, separate from the signing preimage           |
| Usage                                                | Prefer [wallet execution](pages/typescript/transactions.md) for application calls |



## Public Entry Points

| Import                               | Use for                                                          |
| ------------------------------------ | ---------------------------------------------------------------- |
| `@groundhogchain/client`             | Clients, clusters, accounts, actions, amounts, common primitives |
| `@groundhogchain/client/contracts`   | Standard contract and event descriptors                          |
| `@groundhogchain/client/contract`    | Descriptor runtime, codecs, fixed-length helpers                 |
| `@groundhogchain/client/transport`   | HTTP/mock transports and errors                                  |
| `@groundhogchain/client/actions`     | Standalone actions                                               |
| `@groundhogchain/client/wallet`      | Execution and provider adapters                                  |
| `@groundhogchain/client/provider`    | Provider wire types, validation, discovery                       |
| `@groundhogchain/client/local-dev`   | Node-only local account loading                                  |
| `@groundhogchain/client/transaction` | Construction, signing, serialization                             |
| `@groundhogchain/client/signers`     | Signer interface and private-key signer                          |
| `@groundhogchain/client/signed-op`   | Network-bound offchain signed operations                         |



## Maintained Examples

| Source                                                                            | Purpose                                                                       |
| --------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| [Client examples](https://github.com/groundhogchain/client-ts/tree/main/examples) | Runnable SDK examples; use dependencies matching the selected source revision |
| [Guides](pages/guides.md)                                                         | Complete contract and application walkthroughs                                |

---

## Connect a wallet

Source: <https://docs.groundhog.dev/tools/wallet-integration/>

Discover browser wallets, connect an account on the intended network, and manage its session.

A browser wallet provider owns account access and transaction approval. Your application receives authorized account information and requests signatures without handling the user’s private key.



## Choose the Integration

This page covers the provider-backed path described in [Accounts and wallet clients](pages/typescript/wallet-clients.md). For a Node.js process that manages its own key, use [Use a signer in scripts](pages/typescript/accounts.md). Wallet implementers should use [Wallet provider reference](pages/tools/wallet-provider.md).



## Discover and Connect

Start discovery when the wallet picker mounts and let the user select a provider:

```ts
import { discoverWalletProviders, type WalletProvider } from "@groundhogchain/client/provider";

export function mountWalletPicker(showChoice: (provider: WalletProvider) => void) {
  return discoverWalletProviders(showChoice);
}
```

Call the returned cleanup function when the picker unmounts. Discovery supports either load order and reports each provider ID once. Provider IDs and names are display metadata, not proof of identity; render names as text.

Connect from the user’s chosen-wallet action. This helper accepts a public client, the application’s trusted network hash, and an account picker:

```ts
import type { CoreGroundhogClient } from "@groundhogchain/client";
import { parseWalletSession, type WalletAccount, type WalletProvider } from "@groundhogchain/client/provider";
import { createProviderWalletClient } from "@groundhogchain/client/wallet";

export async function connectWallet(
  client: CoreGroundhogClient,
  provider: WalletProvider,
  expectedNetworkHash: string,
  chooseAccount: (accounts: readonly WalletAccount[]) => WalletAccount,
) {
  const session = parseWalletSession(await provider.request({ method: "connect" }));
  if (session.networkHash !== expectedNetworkHash) {
    throw new Error("Select the application's network in your wallet");
  }
  if (session.accounts.length === 0) throw new Error("No authorized account");
  const account = chooseAccount(session.accounts);
  if (!session.accounts.includes(account)) throw new Error("Choose an authorized account");

  const wallet = createProviderWalletClient({
    client, provider, account, networkHash: expectedNetworkHash,
  });
  return { wallet, account };
}
```

For a [cluster-aware client](pages/typescript/connect.md), convert its validated network identity with `toHex0x(client.network.networkHash).slice(2)`. Provider network hashes are 64 lowercase hex characters without `0x`. Do not adopt the wallet’s network as the application’s expected network.

`connect` prompts for access; `getSession` reads existing access without prompting. A disconnected session has no accounts but still reports the wallet’s current network. The adapter does not switch networks.



## Handle Changes and Cleanup

Every provider `change` invalidates the current adapter. A failed session read or mismatched session also invalidates it. Stop offering actions through that binding, update the account/network UI, and construct a new adapter for a newly authorized session.

```ts
import type { WalletProvider } from "@groundhogchain/client/provider";
import type { ProviderWalletClient } from "@groundhogchain/client/wallet";

export function watchWallet(
  provider: WalletProvider,
  wallet: ProviderWalletClient,
  resetAccountUI: () => void,
) {
  const stopChanges = provider.on("change", () => {
    wallet.dispose();
    resetAccountUI();
  });
  return () => {
    stopChanges();
    wallet.dispose();
  };
}
```

Application callbacks should handle their own UI errors. Call cleanup when the binding is no longer needed. `dispose()` invalidates the adapter but does not revoke wallet permission. The user’s Disconnect action calls `provider.request({ method: "disconnect" })`.



## Prepare, Sign, Save, Submit, Observe

For routine writes, use [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet). The provider helpers require `onSigned` to save the approved transaction before broadcast.

For explicit control, the sequence is:

1. `wallet.prepareExecution(request)` builds the unsigned transaction.
2. `wallet.signTransaction(transaction)` requests approval and verifies the returned bytes, signature, and hash. It does not broadcast.
3. Your application saves the signed result, account, and original network.
4. `wallet.submitTransaction(signed)` broadcasts the latest verified approval once.
5. The public client observes the hash and checks execution.

The adapter allows one in-flight operation. A session change invalidates pending work; do not automatically re-sign it. Signature verification requires Web Crypto, available in browsers on HTTPS or localhost.



## Recover an Ambiguous Submission

Once submission begins, an error may arrive after broadcast. Use the saved hash and original network to [track the transaction](pages/typescript/transaction-status.md), including after disconnect or reload. Do not create a replacement merely because observation timed out.

Use `parseWalletProviderError` for provider errors across browser contexts rather than relying on `instanceof`. The [error table](pages/tools/wallet-provider.md#errors) distinguishes rejection, authorization, network, and transport errors.

For a complete interface with connection controls and a transfer action, follow [Connect a Wallet to Your App](pages/tutorials/connect-a-wallet-to-your-app.md).

---

## Wallet provider reference

Source: <https://docs.groundhog.dev/tools/wallet-provider/>

Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.

| Audience                       | Entry point                                                                                                  |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| Application developers         | [Connect a wallet](pages/tools/wallet-integration.md), [Send transactions](pages/typescript/transactions.md) |
| Wallet and bridge implementers | Provider contract `1.0.0`; requirements below apply at the wallet boundary                                   |
| Complete signatures            | [Generated client API](https://client-ts.thruput.network/)                                                   |
| Imports                        | Wire types and validators: `/provider`; application adapter: `/wallet`                                       |



## Interface and Methods

| Type / member                      | Shape                                                                            |
| ---------------------------------- | -------------------------------------------------------------------------------- |
| `WalletAccount`                    | `{ address: string; publicKey: string; nonce: string }`                          |
| `WalletSession`                    | `{ networkHash: string; accounts: readonly WalletAccount[] }`                    |
| `WalletProvider.info`              | `{ id: string; name: string; version: "1.0.0" }`                                 |
| `WalletProvider.supportedMethods?` | Optional readonly method-name list                                               |
| `request(request)`                 | `Promise<unknown>`; validate each result                                         |
| `on("change", listener)`           | Subscribe to a full session snapshot; returns an idempotent unsubscribe function |

| Request method      | Parameters                                    | Result / requirement                                                         |
| ------------------- | --------------------------------------------- | ---------------------------------------------------------------------------- |
| `connect`           | None                                          | Prompt for origin-scoped access; successful session has at least one account |
| `getSession`        | None                                          | Non-interactive session snapshot; never grants access                        |
| `disconnect`        | None                                          | `null`; idempotently revokes origin permission and pending approvals         |
| `getCapabilities`   | `{ account, networkHash }`                    | `WalletCapabilities`; requires an authorized account on that network         |
| `signTransaction`   | `{ account, networkHash, transaction }`       | `{ signedTransaction, hash }`; approval and signing only                     |
| `submitTransaction` | `{ account, networkHash, signedTransaction }` | `{ hash }`; broadcast acknowledgement, not an execution receipt              |

| Rule                     | Requirement                                                                                      |
| ------------------------ | ------------------------------------------------------------------------------------------------ |
| Request shape            | Exactly the method’s defined fields, including nested `params`                                   |
| Selection                | Explicit account and network; no implicit network switch                                         |
| `WalletCapabilities`     | `{ account, networkHash, atomicBatch: { maxCalls: number } \| null }`                            |
| Capability advertisement | Include `getCapabilities` in `supportedMethods` to enable the adapter’s capability request       |
| Unsupported capabilities | No advertisement or a `4200` response means unsupported batching; other request errors propagate |
| Atomic batch             | Ordered, all-or-nothing DefaultWallet calls; honor `maxCalls`                                    |



## Canonical Data and Limits

| Value                     | Required format / bound                                                                                        |
| ------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Address, public key, hash | 32-byte lowercase `0x`-prefixed hex                                                                            |
| Network hash              | 64 lowercase hex characters without `0x`                                                                       |
| Account nonce             | Canonical decimal u64, at most `18446744073709551615`; address derivation, not transaction replay nonce        |
| Session accounts          | At most 32 unique addresses                                                                                    |
| Provider ID               | 1–64 ASCII letters, digits, dots, underscores, or hyphens                                                      |
| Provider name             | 1–80 characters; no controls or surrounding whitespace; render as text                                         |
| Provider version          | Exactly `"1.0.0"`                                                                                              |
| Error message             | At most 1,024 characters                                                                                       |
| Unsigned transaction      | Canonical classic XDR, at most 1,048,500 decoded bytes                                                         |
| Signed transaction        | Canonical classic XDR, at most 1,048,576 decoded bytes                                                         |
| Transaction hex           | Lowercase, even-length, `0x`-prefixed; at most 2,097,002 unsigned or 2,097,154 signed characters               |
| Account derivation        | Protocol pubkey account matching its public key and nonce; Ed25519 key must be non-small-order and prime-order |

| Validation boundary | Requirement                                                                                |
| ------------------- | ------------------------------------------------------------------------------------------ |
| Canonical values    | Reject malformed values rather than normalizing                                            |
| XDR                 | Consume all input; re-encoding must reproduce the supplied bytes                           |
| Before approval     | Enforce unsigned size limit; 76 bytes are reserved for one decorated signature             |
| Bridges             | Bound raw messages before parsing and bound pending requests; allow for JSON envelope size |
| Data parsers        | Return snapshots                                                                           |
| Provider parser     | Preserves the live object’s identity and method receivers; does not establish trust        |



## Permissions and Session Events

| Event / state                                              | Requirement                                                                      |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Unauthorized or disconnected origin                        | Empty accounts, current network hash retained                                    |
| Accounts, permission, account metadata, or network changes | Emit `change` with a full session snapshot                                       |
| Subscription                                               | Does not emit an initial snapshot; call `getSession`                             |
| Connect/disconnect ordering                                | Page-facing changes arrive before the request resolves, including across bridges |
| Pending operation                                          | Recheck authorization before signing or broadcasting                             |
| Session change                                             | Clear approvals; old approval cannot survive a changed session                   |



## Signing and Transaction Identity

| Item          | Requirement                                                                                                |
| ------------- | ---------------------------------------------------------------------------------------------------------- |
| Root identity | Transaction root address and complete pubkey claim match the selected account                              |
| Signed bytes  | Preserve unsigned transaction byte-for-byte                                                                |
| Signature     | Exactly one Ed25519 signature with public-key ID zero                                                      |
| Preimage      | `cxs(DomainSeparator("Transaction")) \|\| networkHash \|\| txs(transaction)`                               |
| Verification  | Strict Ed25519 with ZIP-215 disabled; public key and signature point R are non-small-order and prime-order |
| Signing       | Sign the preimage directly, without an extra pre-hash                                                      |
| Result hash   | `0x` plus lowercase SHA-256 of unsigned transaction XDR; excludes signatures and network                   |
| Web Crypto    | Required by SDK signature verification; HTTPS or localhost in browsers                                     |



## Approval and Submission

| Boundary                    | Requirement                                                                                                      |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Trusted caller              | Derive origin in trusted wallet/bridge code, not page-supplied parameters                                        |
| Retained approval           | Bind exact signed bytes to origin, account, and network                                                          |
| Submission                  | Reject bytes outside the retained approval; return the approved canonical hash                                   |
| Approval lifecycle          | Clear on disconnect/session change; bound retained approvals; fail closed after eviction, restart, or lost state |
| Application persistence     | Save signed result, hash, account, and original network before broadcast                                         |
| Uncertain submission        | Observe the saved hash on the original network; do not automatically sign a replacement                          |
| Identical-byte resubmission | Requires an explicit recovery policy and still-valid provider approval                                           |
| Usage                       | [Transaction observation](pages/typescript/transaction-status.md)                                                |



## Errors

| Code     | Meaning                                                         |
| -------- | --------------------------------------------------------------- |
| `4001`   | User rejected the request                                       |
| `4100`   | Unauthorized origin/account, stale session, or missing approval |
| `4200`   | Unsupported method                                              |
| `4900`   | Provider disconnected or transport unavailable                  |
| `4901`   | Requested network does not match                                |
| `-32602` | Invalid parameters, encoding, or limits                         |
| `-32603` | Internal error or invalid provider result                       |
| `-32002` | Another operation is pending                                    |

| Rule                    | Requirement                                                                         |
| ----------------------- | ----------------------------------------------------------------------------------- |
| Across contexts         | Preserve numeric code and message; use `parseWalletProviderError`, not `instanceof` |
| Unknown method          | Return `4200`                                                                       |
| Malformed known request | Return `-32602`                                                                     |



## Multiple-Provider Discovery

| API / rule                                           | Behavior                                                                |
| ---------------------------------------------------- | ----------------------------------------------------------------------- |
| `registerWalletProvider(provider, target = window)`  | Validate, announce immediately, and respond to provider requests        |
| `discoverWalletProviders(listener, target = window)` | Subscribe before requesting announcements; validate and deduplicate IDs |
| Request event                                        | `groundhog:requestProvider`                                             |
| Announcement event                                   | `groundhog:announceProvider`; `detail` is the provider itself           |
| Discovery limits                                     | At most 32 IDs; first valid announcement for an ID wins                 |
| Cleanup                                              | Idempotent; removes listeners, but does not disconnect sessions         |
| Registration removal                                 | Does not retract an already discovered provider                         |
| Outside browsers                                     | Imports are safe; supply an `EventTarget` to discovery helpers          |
| Trust                                                | Shape validation is not wallet identity or origin authorization         |



## Validation Helpers

| Helper                                                                  | Validates / returns                                                                     |
| ----------------------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| `parseWalletAccount`, `parseWalletSession`, `parseWalletProviderInfo`   | Canonical data and frozen snapshots; separately require nonempty accounts after connect |
| `parseWalletProvider`                                                   | Metadata and callable methods on the live object                                        |
| `parseWalletHex32`, `parseWalletNetworkHash`                            | Distinct hex encodings                                                                  |
| `parseWalletCapabilities`                                               | Account, network, and batch capability shape                                            |
| `parseProviderRequest`                                                  | Exact request union and bounded XDR                                                     |
| `parseTransactionHex`, `parseSignedTransactionHex`                      | Canonical decoded objects, without signature verification                               |
| `parseSignTransactionResult`, `parseSubmitTransactionResult`            | Result shape; not signature, approval, or broadcast verification                        |
| `assertWalletTransaction(tx, account)`                                  | Root address and complete pubkey claim; mismatch is `4100`                              |
| `verifySignTransactionResult(value, transaction, account, networkHash)` | Exact bytes, account claim, strict signature, and hash; invalid result is `-32603`      |
| `parseWalletProviderError`                                              | Recognized code and bounded message                                                     |

| Constant                         | Value       |
| -------------------------------- | ----------- |
| `MAX_TRANSACTION_BYTES`          | `1_048_576` |
| `MAX_UNSIGNED_TRANSACTION_BYTES` | `1_048_500` |
| `MAX_WALLET_ACCOUNTS`            | `32`        |
| `MAX_DISCOVERED_PROVIDERS`       | `32`        |



## SDK Adapter Behavior

| API                                                                                   | Result / behavior                                                                                |
| ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| `createProviderWalletClient({ client, provider, account, networkHash })`              | Synchronous separate binding for an authorized wire account; does not connect or mutate client   |
| `getCapabilities()`                                                                   | Fresh account/network capabilities when advertised; absence or `4200` means unsupported batching |
| `prepareExecution(request)`                                                           | Unsigned DefaultWallet transaction with nonce, expiry, and size handling                         |
| `prepareBatchExecution(request)`                                                      | Unsigned atomic batch after support checks                                                       |
| `signTransaction(transaction)`                                                        | Verified approval; never broadcasts                                                              |
| `submitTransaction(signed)`                                                           | Consumes latest approval once, including on failure; verifies response hash                      |
| `executeAndWait(request, controls)`                                                   | Prepare, sign, save through `onSigned`, submit, and observe successful execution                 |
| `executeCallsAndWait(request, controls)`                                              | Atomic typed calls and ordered decoded results                                                   |
| `prepareDeployment(plan, options)` / `deployContractAndWait(plan, options, controls)` | Explicit funding and optional atomic initialization                                              |
| `dispose()`                                                                           | Idempotently unsubscribe and permanently invalidate; does not revoke permission                  |

| Lifecycle rule     | Behavior                                                                                                              |
| ------------------ | --------------------------------------------------------------------------------------------------------------------- |
| Inputs             | Snapshot configuration and inputs before async work; validate account derivation and client network identity          |
| Session            | Check before preparation/signing/submission; every change or failed/mismatched session read invalidates the adapter   |
| Concurrency        | One in-flight operation; overlapping work fails with `-32002`                                                         |
| New approval       | Clears the previous approval after local transaction validation; refusal does not restore it                          |
| Execution controls | Required `onSigned` persistence callback; optional `wait` settings and cancellation signal                            |
| Cleanup            | No automatic reconnect/retry, UI deadline, or provider-request cancellation; late results cannot reactivate or submit |
| Usage              | [Connect a wallet](pages/tools/wallet-integration.md), [Send transactions](pages/typescript/transactions.md)          |



## Design References

| Reference                                                                                                                                                                       | Relationship                                                                                                                                                  |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [EIP-1193](https://eips.ethereum.org/EIPS/eip-1193), [EIP-6963](https://eips.ethereum.org/EIPS/eip-6963), [Wallet Standard](https://github.com/wallet-standard/wallet-standard) | Design influences, not compatibility claims                                                                                                                   |
| Scope                                                                                                                                                                           | No arbitrary-message signing, implicit network addition, WalletConnect, hardware-wallet protocol, or source-address account support in this provider contract |

---

## Add Events to a Contract

Source: <https://docs.groundhog.dev/tutorials/add-events-to-a-contract/>

Tutorial: define an event, emit it from a Groundhog contract, test it, and find it in the contract spec and on chain.

We’re extending the counter from [Build a Counter](pages/tutorials/build-a-counter.md) with a `CounterIncremented` event: define the event type, declare it as part of the contract’s interface, emit it, assert on it in a test, find it in the contract spec, and query it over JSON-RPC.

**Prerequisites:** A working counter contract from [Build a Counter](pages/tutorials/build-a-counter.md). For the application steps, complete [TypeScript package setup](pages/typescript/setup.md) and read [Use contract bindings](pages/tools/typescript-bindings.md) first.

For contract-only guidance, see [Events](pages/contracts/events.md).



## How Events Work on Groundhog

An event is up to three 32-byte **topics** plus a CXS-serialized **payload** (at most 1 KB in total). Topics are indexed: off-chain consumers filter on them via [`groundhog_getEvents`](pages/reference/json-rpc-api.md#groundhog_getevents). The payload is not indexed; it carries the data you want to read back.

Topic 0 is always the event’s **signature**, a hash that identifies the event type, so up to two topics are available for your own fields. There is no `indexed` keyword as in Solidity: you mark struct fields with `#[topic]`.



## Step 1: Define the Event

Add the event type to `src/implementation.rs`:

```rust
#[derive(Event, Clone, Debug)]
pub struct CounterIncremented<'a> {
    #[topic]
    pub by: &'a ContractAddress,
    pub amount: u64,
}
```

- **`#[derive(Event)]`** generates the signature, topic/payload encoding, and typed decoding view. See [SDK Macros](pages/reference/sdk-macros.md#deriveevent) or [`#[derive(Event)]` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/derive.Event.html).
- **`#[topic]`** makes `by` an indexed topic (topic 1), so consumers can filter events by address. Fields without the attribute, here `amount`, go into the payload.
- **The lifetime** lets the topic borrow the address. Addresses, fixed 32-byte values, supported integer scalars, `U256`, `I256`, and bool have direct topic encodings. Strings and byte slices are hashed; keep their original value in the payload if consumers need it. See [topic encodings](pages/typescript/events.md#filter-topics).



## Step 2: Declare and Emit It

Declare the event on the `#[contract]` attribute and emit it from `increment`:

```rust
#[contract(
    throws = CounterError,
    emits(PingEvent, CounterIncremented)
)]
impl Counter {
    pub fn initialize(&mut self, initial_value: u64) {
        self.value.strict_inc(initial_value as i128);
    }

    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
        let caller = get_caller();
        log_event(&CounterIncremented { by: &caller, amount });
    }

    // decrement and get are unchanged
}
```

The generated counter already declares and emits `PingEvent`. Keep it in the `emits(...)` list unless you also remove the scaffold’s `ping` method. Export the new event from `src/lib.rs` so integration tests can import it:

```rust
pub use implementation::CounterIncremented;
```

- **`emits(CounterIncremented)`** declares the event as part of the contract’s interface, which records it in the [contract spec](pages/reference/contract-spec.md#events) so codegen and indexers can decode it. Like `throws`, `emits` belongs on the interface: the trait definition or inherent impl, never a trait impl.
- **[`log_event`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/event/fn.log_event.html)** emits topics and payload through `LogEvent`. Events become part of the block’s event trie; contracts cannot read them back.
- **`get_caller()`** returns the address of the immediate caller, which becomes the event’s indexed topic.



## Step 3: Test It

Every event emitted during a test transaction is captured on the `TransactResult` that `env.transact` returns. Add to `tests/test.rs`:

```rust
use sdk::*;

use counter::{CounterClient, CounterIncremented, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

#[test]
fn test_increment_emits_event() {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();

    let result = env.transact(|tx| {
        tx.call(&ContractAddress::named("test")).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);
            client.initialize(10);
            client.increment(5);
        })
    });
    result.assert_success();

    // initialize emits nothing; increment emits exactly one event
    result.assert_event_count(1);
    result.assert_event::<CounterIncremented>(0, |event| {
        assert_eq!(event.topic(0), Some(CounterIncremented::SIGNATURE));
        let by: &ContractAddress = event.topic(1).unwrap().into();
        assert_eq!(by, &ContractAddress::named("test"));
        assert_eq!(event.payload().amount, 5);
    });
}
```

Walking through the assertions:

1. **`assert_event_count(1)`** counts every event the transaction emitted, across all contracts it touched.
2. **`assert_event::<CounterIncremented>(0, ...)`** decodes the event at index 0 as a `CounterIncremented` and hands you a typed view.
3. **`event.topic(0)`** is the signature; `CounterIncremented::SIGNATURE` is the constant the derive generated.
4. **`event.topic(1)`** is the `by` field. A 32-byte topic converts back to `&ContractAddress` with `.into()`. The caller is the address the transaction originated from: `ContractAddress::named("test")`.
5. **`event.payload()`** is the decoded `CounterIncrementedPayload`; payload fields are read back directly.

Run it:

```bash
cargo test
```



## Step 4: Find It in the Spec

Build the contract:

```bash
groundhog build
```

The build writes `counter.spec.json` for inspection and canonical `counter.spec.xdr` for codegen. Inspect the event’s structured spec identity, signature, topic `by`, and payload field `amount`. Use that generated signature for topic 0 instead of copying a hash from another crate/version. See [Contract Spec](pages/reference/contract-spec.md).

Anything that consumes the spec now understands the event. Generate [TypeScript bindings](pages/tools/typescript-bindings.md) from the RV32 spec sidecar:

```bash
mkdir -p web/src/contracts
groundhog codegen ts target/groundhog/counter.spec.xdr \
  --output web/src/contracts/counter.ts
```

The generated `CounterIncremented` descriptor builds a typed filter, decodes matching events, and extracts events from transaction receipts:

```ts
import { counter } from "./contracts/counter.js";
const { CounterIncremented } = counter.v0_1.implementation;

const filter = CounterIncremented.filter({
  contractAddresses: [contract],
  topics: { by: caller },
});

const decoded = CounterIncremented.decode(event);
if (decoded) {
  console.log(decoded.topics.by, decoded.fields.amount);
}

const matches = CounterIncremented.allFromReceipt(receipt, {
  contractAddress: contract,
});
const match = CounterIncremented.singleFromReceipt(receipt, {
  contractAddress: contract,
});
```

`decode()` returns `null` when the signature differs and throws for malformed data with the matching signature. `allFromReceipt()` returns every matching event from the selected emitter. `singleFromReceipt()` requires exactly one match. Each receipt match retains its emitting `contractAddress`.



## Step 5: Query It On Chain

After deploying (see [Develop Locally with the CLI](pages/tutorials/develop-locally.md#6-dry-run-and-deploy) for the deploy flow) and calling `increment`, the event is queryable through the gateway. Filter on the contract address and the signature from the spec as `topic0`, with a `0x` prefix:

```json
{
  "jsonrpc": "2.0",
  "method": "groundhog_getEvents",
  "params": [
    {
      "filters": [
        {
          "contractAddresses": ["0x<64-character-contract-address>"],
          "topics": {
            "topic0": [
              "0x<signature-from-your-generated-descriptor>"
            ],
            "topic1": [],
            "topic2": []
          }
        }
      ],
      "order": "descending",
      "anchor": { "kind": "atEnd" },
      "cursor": "0x",
      "limit": 50
    }
  ],
  "id": 1
}
```

Each returned event carries its topics (topic 1 is the caller’s address, directly comparable) and the CXS payload (`amount`). To filter on a *specific* caller, put that address in `topic1`. See [`groundhog_getEvents`](pages/reference/json-rpc-api.md#groundhog_getevents) for pagination and filter semantics.

Replace the address and signature placeholders above before sending the request. With the TypeScript client, use the generated filter instead:

```ts
const page = await client.getContractEvents({
  event: CounterIncremented,
  contractAddresses: [contract],
  topics: { by: caller },
  order: "ascending",
  limit: 20,
}, { signal });
for (const event of page.events) {
  console.log(event.txHash, event.blockHeight, event.sequenceNumber, event.fields.amount);
}
```

This fetches exactly one typed page. See [Read events](pages/typescript/events.md) for generated filters, typed decoding, and multi-page iteration. The next section adds application-owned persistence to that query.



## Resume Without Missing Events

A cursor continues one bounded historical walk. It does not follow blocks added later. Raw JSON-RPC uses `"0x"` to start and returns `"0x"` at exhaustion; the TypeScript client uses an empty `Uint8Array`. An empty page alone is not exhaustion. Raw continuation requests still require `order` and `anchor`, even though the cursor contains continuation state. Keep the network, target, and filters fixed.

Store rows and progress in one database transaction. For events, use a unique key of `(txHash, sequenceNumber)` within the network/query’s store. Transaction-reference pages can use `txHash`; their query matches root invocation targets, not every address touched by a transaction.

Use an ascending query with application-owned storage. Use one store per network and query; changing filters needs a separate store or an explicit rebuild.

| Application method               | Responsibility                                                                                                         |
| -------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `store.loadProgress()`           | Return the saved `{ height, cursor }`, or `undefined` for a new scan. Heights are bigint and cursors are `Uint8Array`. |
| `store.savePage(rows, progress)` | Upsert rows by their stable identity and save progress in the **same database transaction**.                           |

```ts
const query = {
  filters: [CounterIncremented.filter({ contractAddresses: [contract] })],
  order: "ascending" as const,
  limit: 20,
};
const saved = await store.loadProgress();
let height = saved?.height ?? 0n;

for await (const page of client.iterateEventPages({
  ...query,
  anchor: { height },
  cursor: saved?.cursor ?? new Uint8Array(),
}, { signal })) {
  if (page.oldestBlock > height) {
    throw new Error("History gap: required blocks are no longer retained");
  }
  const last = page.events.at(-1);
  if (last) height = last.blockHeight;
  await store.savePage(page.events, { height, cursor: page.cursor.slice() });
}
```

The store methods are application code, not SDK APIs. A non-empty saved cursor resumes the old walk. An empty one starts a fresh scan at the saved height. Serialize heights and cursor bytes exactly, and test interruption and replay against your database implementation.

For example, block 100 contains events A and B on different pages:

1. Save A and its continuation cursor together. The last stored row height is 100.
2. If the process stops, resume that exact saved walk when its cursor is valid.
3. If starting a fresh scan, start inclusively at height 100, not 101. Upsert A again and store B. This prevents losing the unfinished part of the block.
4. After exhaustion, a later call starts a new walk at the last stored height. It rereads that block, deduplicates it, and can discover newer blocks.

`latestBlock` is the indexer’s head at response time, not proof that you processed every matching row through that height. Never set the application checkpoint to it. An empty completed walk may leave the last-row checkpoint unchanged.

Check `oldestBlock` before accepting data as complete. If retention has removed needed history, report a gap and choose an explicit rebuild/archive policy. Current indexers do not reliably reject malformed cursors: corrupt bytes can look like an exhausted walk. Preserve cursors exactly; do not decode them in the client or silently restart on arbitrary errors. These checks do not prove that corrupted or pruned history is recoverable.



## Next Steps

- [Contract Spec](pages/reference/contract-spec.md) for the full spec format the event landed in
- [SDK Macros](pages/reference/sdk-macros.md#deriveevent) for `#[derive(Event)]` details, including `#[event_spec(export)]` for library-emitted events
- [TypeScript Bindings](pages/tools/typescript-bindings.md) to generate a typed client that knows about your event
- [Build a Token](pages/tutorials/build-a-token.md) for a contract emitting standard ERC-20 events

---

## Build a Counter

Source: <https://docs.groundhog.dev/tutorials/build-a-counter/>

Tutorial: build a counter contract on Groundhog, step by step.

We’re building the counter contract generated by `groundhog new`. It has initialize, increment, decrement, and get operations, plus a small event example and an explicit error example. The counter demonstrates the core idea: use `strict_inc` to record a change instead of replacing the counter with a newly calculated value. Concurrent changes can then combine.

**Prerequisites:** [Install the CLI](pages/cli/install.md) and configure Cargo access. For a short deployment walkthrough before studying the code, follow the [contract quickstart](pages/get-started/contract.md).

CLI `0.19.0` generates a project pinned to SDK `0.41.1`. Keep the generated files and compiler toolchain; the explanation below is not a replacement scaffold.



## What You’ll Build

A contract with four core counter methods and two scaffold examples:

| Method       | Signature                         | What it does                                                         |
| ------------ | --------------------------------- | -------------------------------------------------------------------- |
| `initialize` | `(&mut self, initial_value: u64)` | Add the initial amount. Call it once after deployment by convention. |
| `increment`  | `(&mut self, amount: u64)`        | Add to the counter                                                   |
| `decrement`  | `(&mut self, amount: u64)`        | Subtract from the counter (aborts if result would be negative)       |
| `get`        | `(&self) -> u64`                  | Read current value                                                   |
| `ping`       | `(&self, tag: u64)`               | Emit a simple event                                                  |
| `error`      | `(&self) -> u64`                  | Throw the declared contract error                                    |



## Step 1: Project Setup

Create a new contract crate:

```bash
groundhog new counter
cd counter
```

Keep the generated `Cargo.toml` and `rust-toolchain.toml`. The manifest declares:

- the library contract and RV32 entrypoint binary;
- separate host and RV32 SDK dependencies, with the versions selected by the CLI;
- the `entrypoints`, `dev`, and `groundhog-integration-test` features used by the tooling;
- a self-dependency that enables `dev` for native tests.

Do not copy a dependency block from another release into this project. Inspect the manifest generated on your machine when you need its exact versions or feature settings.

Your `src/lib.rs`:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;

pub use implementation::Counter;
pub use implementation::CounterClient;
```

The crate is `no_std` whenever the `dev` feature is disabled. The generated self-dependency enables `dev` for native tests; it is not a default feature. The host SDK dependency enables `std`, while the RV32 SDK dependency remains suitable for guest builds.



## Step 2: Define the Error Type

Contracts need a contract exception type only when they declare domain exceptions through `throws`. The generated counter includes one as an example. `#[contract_exception]` derives serialization for CXS encoding, and each variant maps to an integer discriminant.

```rust
use sdk::storage::NNInt;
use sdk::*;

#[contract_exception]
pub enum CounterError {
    NotAuthorized = 1,
}
```

This counter doesn’t use authorization, so `NotAuthorized` is a placeholder exercised by the scaffold’s `error` method. A contract without domain exceptions can omit `throws` and the exception type. Storage failures, such as a counter going below zero, remain SDK library exceptions.

The scaffold also includes a tiny event type:

```rust
#[derive(Event, Clone, Debug)]
pub struct PingEvent {
    #[topic]
    pub tag: u64,
}
```

`#[topic]` marks the field as an indexed event topic. The full event flow is covered in [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md).



## Step 3: Define Storage

```rust
#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}
```

The `#[sdk::storage]` macro derives a storage path for each field. The field’s storage type handles reads and writes. [`NNInt`](pages/programming-model/storage-types.md#nnint) is Groundhog’s integer storage type for signed changes. Those [deltas can merge](pages/programming-model/execution.md#merged-deltas) across concurrent transactions.

One field is all this contract needs. More complex contracts use `Map<K, V>` for key-value storage (see [Build a Token](pages/tutorials/build-a-token.md)).



## Step 4: Implement the Contract

```rust
#[contract(throws = CounterError, emits(PingEvent))]
impl Counter {
    pub fn initialize(&mut self, initial_value: u64) {
        self.value.strict_inc(initial_value as i128);
    }

    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn decrement(&mut self, amount: u64) {
        self.value.strict_inc(-(amount as i128));
    }

    pub fn get(&self) -> u64 {
        self.value.try_get().none_if_missing().unwrap_or(0) as u64
    }

    pub fn ping(&self, tag: u64) {
        log_event(&PingEvent { tag });
    }

    pub fn error(&self) -> u64 {
        throw(CounterError::NotAuthorized);
    }
}
```

Line by line:

- **`#[contract(throws = CounterError, emits(PingEvent))]`** generates contract entrypoints, a `CounterClient` struct for cross-contract calls and testing, and spec metadata for the declared error and event. The client name defaults to `{StructName}Client`. You can override it with `client = CustomName` if needed.

- **`strict_inc(delta)`** records a signed change. `increment(5)` records `+5`, while `decrement(5)` records `-5`. Concurrent calls can combine those changes instead of competing to replace the counter with different final values. `strict_inc` takes `i128`, so the scaffold casts the `u64` amount and negates it for decrements.

- **`strict_inc` aborts on underflow.** If the counter is at 3 and you call `decrement(5)`, the result would be -2. `NNInt` rejects the change and the transaction aborts automatically. You don’t need to check for this.

- **`try_get().none_if_missing().unwrap_or(0)`** reads the current value. `try_get()` returns `Result<i128, LibraryExn>`, so a bare `unwrap_or(0)` would report zero for every read error, not just a never-incremented counter. `none_if_missing()` converts only absence into `None` and re-throws anything else, so a wrong-type slot or an overflowed accumulation surfaces instead of looking like a legitimate zero.

- **`as u64` narrows the stored value.** `NNInt` stores `i128`, so a value above `u64::MAX` would truncate in this scaffold. A production counter should return `i128` or perform a checked conversion with a domain error.

- **`initialize` is not automatic or guarded.** Deployment and initialization are separate calls. Calling `initialize(10)` twice adds 20 because the scaffold does not store an initialized flag.

- **`&self` vs `&mut self`**: `get` takes `&self` (read-only), so it reads from the snapshot without recording a storage change. `initialize`, `increment`, and `decrement` take `&mut self` to update state. `ping` and `error` also take `&self`.

- **`ping` and `error`**: these are scaffold examples for events and explicit exceptions. They are not part of the counter logic, but they give you working code to modify.



## Step 5: Test It

The scaffold creates `tests/test.rs`:

```rust
use sdk::*;

use counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            assert_eq!(client.get(), 10);

            client.increment(5);
            assert_eq!(client.get(), 15);

            client.decrement(3);
            assert_eq!(client.get(), 12);
        })
    })
    .assert_success();
}
```

Breaking down the test setup:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled. Good for logic tests.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()` in your `lib.rs` and available when the `dev` feature is enabled.
3. **`test_contract.as_hash().clone()`** gets the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from; `.assert_success()` panics with details if the transaction did not commit. The returned `TransactResult` also records emitted events. See [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md).
5. **`deploy_contract`** deploys the contract and returns its address. The nonce (`SHA256Hash`) makes the address deterministic across test runs.
6. **`CounterClient::new`** creates a typed client. Methods return values directly (no `Result` unwrapping needed).

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) instead when the test should exercise the normal storage cost model. Use `TestEnvironment::new(Some(&model))` for custom cost-model tests. For the generated SDK reference, see [Rust API Docs](pages/tools/rust-api-docs.md).



### Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
#[test]
fn test_counter_underflow() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter_underflow");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(5);

            // Decrementing by 10 should abort: strict_inc rejects a negative result
            assert_eq!(
                client.try_decrement(10).unwrap_err().try_as(),
                Some(LibraryExn::NonNegativeIntUnderflow),
            );
        })
    })
    .assert_success();
}
```

The `try_decrement` method (generated by the `#[contract]` macro alongside `decrement`) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`; `try_as` decodes the caught exception as whichever exception type you name, here the SDK’s own `LibraryExn`, which is matched exactly like a contract’s error type.



### Native Logic vs RV32 Integration

Run the fast native tests first:

```bash
cargo test
```

Then build the deployable RV32 artifact:

```bash
groundhog build
```

The scaffold includes `tests/integration.rs`. Run it against an ephemeral local node:

```bash
groundhog test --integration
```

That command deploys RV32 with the runtime’s lowest-index `local_user`, normally `dev-1`, and sets `GROUNDHOG_INTEGRATION_TEST=1` to activate the scaffolded test. It also provides `GROUNDHOG_RPC_URL`, `GROUNDHOG_CONTRACT_ADDRESS`, `GROUNDHOG_PROFILE`, `GROUNDHOG_DEFAULT_KEY`, and `GROUNDHOG_RUNTIME_MANIFEST` to the integration test process. Plain `groundhog test` runs the generated executor-backed RV32 test.



## Why This Matters

This counter is small, but the pattern scales. If 1,000 admitted transactions increment the same counter by 1, their changes can combine to `+1000`. Block capacity and scheduling still determine how many transactions are admitted, and decrements still cannot take an ordinary counter below zero.



## Next Steps

- [Build a Token](pages/tutorials/build-a-token.md) for a full ERC-20 implementation using the same patterns
- [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md) to extend this counter with an emitted event
- [Storage Types](pages/programming-model/storage-types.md) for `Balance`, `NNInt`, `CapacityConstraint`, `Map`, `Vector`, `Value`, `Bytestring`, and `RCQ`
- [NNInt and concurrent updates](pages/programming-model/nnint.md) for the underlying merge rules
- [SDK Macros](pages/reference/sdk-macros.md) for details on `#[contract]`, `#[contract_exception]`, `#[storage]`

---

## Build a Token

Source: <https://docs.groundhog.dev/tutorials/build-a-token/>

Build an ERC-20-compatible token with the Groundhog SDK and standard interface crate.

This tutorial builds an ERC-20-compatible token with transfers, allowances, minting, burning, and standard events. Balances, allowances, and total supply use `Balance`, the SDK’s nonnegative, zero-defaulting interface over Groundhog’s mergeable integer storage. Its [deltas can merge](pages/programming-model/execution.md#merged-deltas) across concurrent transfers.

**Prerequisites:** Complete [Build a Counter](pages/tutorials/build-a-counter.md) first.

> **note: Version checked**
>
> This tutorial uses CLI `0.19.0`, SDK `0.41.1`, and `groundhog-erc20-if` `0.1.41`.



## 1. Create the Project

Start from the minimal CLI template:

```bash
groundhog new erc20 --template stub
cd erc20
```

The generated RV32 wrapper and Groundhog profiles can remain unchanged. This tutorial replaces the library implementation and native test. The generated RV32 test only deploys the artifact, so it keeps passing; remove it if you would rather not carry it:

```bash
rm tests/test_rv32.rs
```

Now make two edits to the generated `Cargo.toml`. Extend the `dev` feature so it forwards to the interface crate:

```toml
[features]
dev = ["sdk/dev", "groundhog-erc20-if/dev"]
```

and add the interface crate. The generated manifest declares `sdk` twice, once per target, because it needs `std` on the host and forbids it on the guest. `groundhog-erc20-if` needs no such split, so add it as a plain dependency rather than editing either `[target.'cfg(...)']` block:

```toml
[dependencies]
groundhog-erc20-if = { version = "=0.1.41", registry = "groundhog" }
```

Leave the rest of the generated manifest alone. In particular keep the `groundhog-integration-test` feature and the `[target.'cfg(not(target_arch = "riscv32"))'.dependencies]` block: `tests/integration.rs` is gated on them, and removing them makes `groundhog test --integration` fail with cargo’s “package does not have the feature”.

The interface crate is the source of truth for:

- `ERC20` and `ERC20Client`
- `Amount = u128` and `Difference = i128`
- `ERC20Error`
- `TransferEvent`, `AllowanceChangeEvent`, `MintEvent`, `BurnEvent`, and their `.log()` methods

Its interface declares `ERC20Error` and those four events, so implementations and generated clients share the same wire contract. Version 0.1.41 uses signed allowance deltas with optional exclusive locking and explicit cleanup.



## 2. Wire the Library

Replace `src/lib.rs`:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;

pub use groundhog_erc20_if::{ERC20, ERC20Client};
pub use implementation::TokenContract;
```

`declare_mock_contract!()` generates `register_mock_contract` for native tests. The standard interface remains in its own crate rather than being copied into this project.



## 3. Define Storage

Replace `src/implementation.rs` with these imports and storage types:

```rust
use groundhog_erc20_if::*;
use sdk::storage::{Balance, Deletable, Map, Value};
use sdk::*;

type Allowance = Balance;

#[contract_type]
#[cfg_attr(feature = "dev", derive(Debug))]
pub struct Config {
    pub administrator: ContractAddress,
}

#[sdk::storage]
#[cfg_attr(feature = "dev", derive(Debug))]
pub struct TokenContract {
    config: Value<Config>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Allowance>>,
    total_supply: Balance,
}
```

The fields have distinct jobs:

| Field          | Purpose                                           |
| -------------- | ------------------------------------------------- |
| `config`       | Stores the administrator that can mint and burn.  |
| `balances`     | Maps each account to a zero-defaulting `Balance`. |
| `allowances`   | Maps owner and spender pairs to `Balance` values. |
| `total_supply` | Tracks all outstanding tokens in a `Balance`.     |

[`Value<Config>` and `Map`](pages/programming-model/storage-types.md) provide typed storage and key-derived paths. `Balance` accepts nonnegative `u128` amounts and exposes increase and decrease operations instead of signed arithmetic or an absolute `set`.



## 4. Add Storage Helpers

Continue in `src/implementation.rs`:

```rust
impl TokenContract {
    fn init(&mut self, administrator: &ContractAddress) {
        if self.config.try_get().none_if_missing().is_some() {
            throw(ERC20Error::AlreadyInitialized);
        }

        self.config.set(&Config {
            administrator: *administrator,
        });
    }

    fn administrator(&self) -> ContractAddress {
        self.config.get().administrator
    }

    fn balance_of(&self, owner: &ContractAddress) -> Amount {
        self.balances.at(owner).get()
    }

    fn lazy_increase_balance(
        &mut self,
        owner: &ContractAddress,
        amount: Amount,
    ) {
        self.balances
            .at_mut(owner)
            .try_lazy_increase(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn decrease_balance(&mut self, owner: &ContractAddress, amount: Amount) {
        self.balances
            .at_mut(owner)
            .try_decrease(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn allowance_of(
        &self,
        owner: &ContractAddress,
        spender: &ContractAddress,
    ) -> Amount {
        self.allowances.at(owner).at(spender).get()
    }

    fn adjust_allowance_by(
        &mut self,
        owner: &ContractAddress,
        spender: &ContractAddress,
        diff: Difference,
        exclusive: bool,
    ) {
        let mut owner_allowances = self.allowances.at_mut(owner);
        let mut allowance = if exclusive {
            owner_allowances.at_mut_exclusive(spender)
        } else {
            owner_allowances.at_mut(spender)
        };
        let result = if diff >= 0 {
            allowance.try_increase(diff as u128)
        } else {
            allowance.try_decrease(diff.unsigned_abs())
        };
        result.unwrap_or_else(|_| throw(ERC20Error::TooLarge));

        AllowanceChangeEvent::new(owner, spender, diff).log();
    }

    fn increase_total_supply(&mut self, amount: Amount) {
        self.total_supply
            .try_increase(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn decrease_total_supply(&mut self, amount: Amount) {
        self.total_supply
            .try_decrease(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn supply(&self) -> Amount {
        self.total_supply.get()
    }
}
```

The helpers preserve the interface’s error and storage behavior:

1. A missing `Balance` reads as zero, so balance, allowance, and supply getters do not need missing-storage handling.
2. The standard interface requires overdrafts and overflows to surface as `ERC20Error::TooLarge`. The `try_` methods let the helpers translate SDK library failures into that domain error.
3. Both checked and lazy operations record mergeable deltas. Checked `decrease` loads the sender so insufficient funds fail during contract execution. `lazy_increase` skips the receiver load and leaves its bound check to delta reservation after the contract returns.

> **note: Checked and lazy failures happen at different points**
>
> Suppose a sender’s snapshot balance is 10. `try_decrease(11)` returns `Err` while the contract is running, so `decrease_balance` can translate it into `ERC20Error::TooLarge`.
>
> Now suppose a receiver’s snapshot balance is `Balance::MAX`, with no offsetting debit in the proposed block. `try_lazy_increase(1)` returns `Ok(())` inside the contract because it does not load that snapshot balance. After the contract returns, the completed delta batch cannot satisfy the balance bound, so the transaction is excluded and returned to the mempool.
>
> The distinction is when the snapshot-bound result becomes known. Both checked and lazy calls still produce deltas that can merge with compatible transactions. A lazy call can still reject an amount that cannot be represented or accumulated within the transaction.



## 5. Implement the Interface

Add the implementation below the helpers:

```rust
#[contract(version = "0.1.5")]
impl ERC20 for TokenContract {
    fn initialize(&mut self, administrator: &ContractAddress) {
        self.init(administrator);
    }

    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let owner = get_caller();

        self.decrease_balance(&owner, amount);
        self.lazy_increase_balance(receiver, amount);
        TransferEvent::new(&owner, receiver, amount_to_diff(amount)).log();
    }

    fn transfer_from(
        &mut self,
        owner: &ContractAddress,
        receiver: &ContractAddress,
        amount: Amount,
    ) {
        let spender = get_caller();
        let diff = amount_to_diff(amount);

        if owner != &spender {
            self.adjust_allowance_by(owner, &spender, -diff, false);
        }
        self.decrease_balance(owner, amount);
        self.lazy_increase_balance(receiver, amount);
        TransferEvent::new(owner, receiver, amount_to_diff(amount)).log();
    }

    fn adjust_allowance(
        &mut self,
        spender: &ContractAddress,
        difference: Difference,
        exclusive: bool,
    ) {
        let owner = get_caller();
        self.adjust_allowance_by(&owner, spender, difference, exclusive);
    }

    fn clear_allowance(&mut self, spender: &ContractAddress) {
        let owner = get_caller();
        let remaining = amount_to_diff(self.allowance_of(&owner, spender));
        self.allowances.at_mut(&owner).at_mut(spender).delete_exclusive();
        AllowanceChangeEvent::new(&owner, spender, -remaining).log();
    }

    fn clear_balance(&mut self) {
        let owner = get_caller();
        ensure(self.balance_of(&owner) == 0, ERC20Error::BalanceNotZero);
        self.balances.at_mut(&owner).delete_exclusive();
    }

    fn allowance(
        &self,
        owner: &ContractAddress,
        spender: &ContractAddress,
    ) -> Amount {
        self.allowance_of(owner, spender)
    }

    fn get_balance_of(&self, owner: &ContractAddress) -> Amount {
        self.balance_of(owner)
    }

    fn get_balance(&self) -> Amount {
        self.balance_of(&get_caller())
    }

    fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
        ensure(
            get_caller() == self.administrator(),
            ERC20Error::MustBeContractOwner,
        );

        // Establish the checked supply bound first. Once it holds, the lazy
        // receiver increase cannot overflow an individual balance.
        self.increase_total_supply(amount);
        self.lazy_increase_balance(receiver, amount);
        MintEvent::new(receiver, amount_to_diff(amount)).log();
    }

    fn burn(&mut self, owner: &ContractAddress, amount: Amount) {
        ensure(
            get_caller() == self.administrator(),
            ERC20Error::MustBeContractOwner,
        );

        self.decrease_balance(owner, amount);
        self.decrease_total_supply(amount);
        BurnEvent::new(owner, amount_to_diff(amount)).log();
    }

    fn total_supply(&self) -> Amount {
        self.supply()
    }
}
```

Deployment does not call `initialize` automatically. Call it once afterward. The stored config enforces one-time initialization.

Mint and burn are restricted to the administrator. `transfer_from` spends allowance when caller and owner differ. `clear_allowance` revokes and deletes one pair; `clear_balance` deletes only an empty balance. This minimal token keeps released storage funding at the contract; a production token should define any caller-refund policy explicitly.

Allowance adjustments with `exclusive=false` can merge within bounds. With `exclusive=true`, competing writes to that pair conflict. An off-chain read followed by a signed delta is still not an exact-target update; the read may be old before the transaction starts.



## 6. Test the Contract

Replace `tests/test.rs`:

```rust
use erc20::{register_mock_contract, ERC20Client};
use sdk::*;

static NONCE: SHA256Hash = sdk::sha256_static!("ERC20_TUTORIAL_NONCE");

#[test]
fn transfer_updates_balances_and_supply() {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = test_contract.as_hash().clone();

    let alice = ContractAddress::named("alice");
    let bob = ContractAddress::named("bob");

    env.transact(|tx| {
        tx.call(&alice).run(move || {
            let address = deploy_contract(&NONCE, &contract_hash);
            let token = ERC20Client::new(&address);
            let owner = get_current_address();

            token.initialize(&owner);
            token.mint(&owner, 1_000);
            token.transfer(&bob, 100);

            assert_eq!(token.get_balance_of(&owner), 900);
            assert_eq!(token.get_balance_of(&bob), 100);
            assert_eq!(token.total_supply(), 1_000);

            token.adjust_allowance(&bob, 25, false);
            token.adjust_allowance(&bob, -5, true);
            assert_eq!(token.allowance(&owner, &bob), 20);
            token.clear_allowance(&bob);
            assert_eq!(token.allowance(&owner, &bob), 0);
            token.burn(&owner, 900);
            token.clear_balance();
            assert_eq!(token.get_balance_of(&owner), 0);
            assert_eq!(token.total_supply(), 100);
        })
    })
    .assert_success();
}
```

Run the native test and build the deployable artifact:

```bash
cargo test
groundhog build
```

The RV32 build produces `erc20.rv32a`, lowering metadata, and contract-spec sidecars under `target/groundhog/`.

In the native test’s root transaction, `get_current_address()` is Alice’s root address. `get_caller()` is meaningful inside the nested token invocation.



## Concurrency Semantics

`Balance` records increases and decreases as changes rather than replacing the stored value with a newly calculated result. The transfer path checks the sender with `decrease` and credits the receiver with `lazy_increase`. Allowance adjustments use checked operations in both directions so the interface can report failures immediately.

This is the [merged-delta model](pages/programming-model/execution.md#merged-deltas): the runtime combines changes from concurrent transfers when they can all be applied safely. Changes to different balances or allowances do not conflict. Credits to the same balance can combine, and debits from the same balance or allowance can combine as long as their total does not exceed the available value. If the total is too large, the runtime excludes one or more transactions and returns them to the mempool.



## Next Steps

- [Design a Swap](pages/tutorials/design-a-swap.md) for an application built from cross-contract token calls
- [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md) for event testing and queries
- [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the snapshot, execution, and exclusion model behind this contract
- [Storage Types](pages/programming-model/storage-types.md) for checked and lazy `Balance` operations and other state choices
- [NNInt and concurrent updates](pages/programming-model/nnint.md) for the lower-level `set_add` representation behind `Balance`
- [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the engine’s concurrent reservation machinery
- [Handle errors](pages/contracts/errors.md) for domain and library exception behavior

---

## Connect a Wallet to Your App

Source: <https://docs.groundhog.dev/tutorials/connect-a-wallet-to-your-app/>

Build a small TypeScript dapp that connects an installed wallet and sends a localnet HOG transfer with receipt recovery.

Build a browser dapp that discovers installed wallets, connects an account, and asks the user to approve a **0.1 HOG** transfer. The wallet holds the keys. Your app builds the call, saves the signed transaction before submission, and checks the receipt.



## Before You Start

- Use Node.js `22.12.0` or newer and a browser with an installed Groundhog provider, such as Thruput Wallet.
- Start an isolated local ledger with `groundhog node`. See [Develop Locally](pages/tutorials/develop-locally.md#4-start-the-local-node) for CLI and runtime setup. Keep that process running.
- In Thruput Wallet, select **Localnet** (`http://127.0.0.1:9545`), unlock a test account, and choose **Request test HOG**. Wait for success. Have a second localnet test account’s address ready and fund it too, so the transfer does not need to create an unfunded receiver’s balance storage.

Use this app in one tab on that ledger. Restarting a node started without `--data-dir` discards its state. Localnet’s fixed network hash does not distinguish separate ledger runs, so a saved hash from an earlier run cannot recover a transaction on the new one.



## 1. Create the App

Create a vanilla TypeScript project:

```bash
npm create vite@latest wallet-demo -- --template vanilla-ts
cd wallet-demo
npm install
```

Configure registry access using [Package setup](pages/typescript/setup.md), then install the SDK packages:

```bash
npm install @groundhogchain/client @groundhogchain/protocol
```

Replace `index.html` with:

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Localnet wallet demo</title>
  </head>
  <body>
    <h1>Send 0.1 HOG on Localnet</h1>
    <fieldset id="controls">
      <legend>Wallet actions</legend>
      <div id="wallets">Waiting for an installed wallet.</div>
      <pre id="session">Disconnected</pre>
      <label>Recipient address <input id="recipient" placeholder="0x…" /></label>
      <button id="send" disabled>Send 0.1 HOG</button>
      <button id="check" disabled>Check saved transaction</button>
      <button id="disconnect" disabled>Disconnect</button>
    </fieldset>
    <pre id="status" role="status"></pre>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
```



## 2. Discover and Connect

Replace `src/main.ts` with the following code, then append the next two blocks to the same file. The app uses the first account authorized in the wallet’s connection prompt and displays it before enabling Send.

```ts
import { addressFromHex, createGroundhogClient, localnet, toHex0x } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { discoverWalletProviders, parseWalletSession, type WalletProvider,
  type WalletSession } from "@groundhogchain/client/provider";
import { createProviderWalletClient, type ProviderWalletClient } from "@groundhogchain/client/wallet";
import { ExecResult, HOG_ADDRESS, fromHex, gasAmount, sha256Hash } from "@groundhogchain/protocol";

const controls = document.querySelector<HTMLFieldSetElement>("#controls")!;
const choices = document.querySelector<HTMLDivElement>("#wallets")!;
const details = document.querySelector<HTMLPreElement>("#session")!;
const status = document.querySelector<HTMLPreElement>("#status")!;
const recipient = document.querySelector<HTMLInputElement>("#recipient")!;
const send = document.querySelector<HTMLButtonElement>("#send")!;
const check = document.querySelector<HTMLButtonElement>("#check")!;
const disconnect = document.querySelector<HTMLButtonElement>("#disconnect")!;
const message = (text: string) => { status.textContent = text; };

async function start() {
  const client = await createGroundhogClient({ cluster: localnet() });
  const networkHash = toHex0x(client.network.networkHash).slice(2);
  let provider: WalletProvider | undefined;
  let session: WalletSession | undefined;
  let active: ProviderWalletClient | undefined;
  let stopChanges: (() => void) | undefined;
  let busy = false;
  let closed = false;

  function update(value: unknown) {
    active?.dispose(); // Every change invalidates pending wallet work.
    session = undefined;
    try { if (value !== undefined) session = parseWalletSession(value); }
    catch { message("Invalid wallet session. Reconnect."); }
    const account = session?.accounts[0];
    const matches = session?.networkHash === networkHash;
    details.textContent = session
      ? `Account: ${account?.address ?? "Disconnected"}\nNetwork: ${session.networkHash}`
      : "Disconnected";
    send.disabled = check.disabled = !account || !matches;
    disconnect.disabled = !provider;
    if (session && !matches) message("Select Localnet in the wallet, then reconnect.");
  }

  async function run(action: () => Promise<void>) {
    if (busy || closed) return;
    busy = controls.disabled = true;
    try { await action(); }
    catch (error) { message(error instanceof Error ? error.message : "Wallet request failed."); }
    finally { busy = controls.disabled = false; }
  }

  const stopDiscovery = discoverWalletProviders((choice) => {
    if (!choices.querySelector("button")) choices.textContent = "";
    const button = document.createElement("button");
    button.textContent = `Connect ${choice.info.name}`;
    button.onclick = () => { void run(async () => {
      stopChanges?.();
      provider = choice;
      update(undefined);
      // Subscribe before connect, including changes emitted during its prompt.
      stopChanges = choice.on("change", update);
      const connected = await choice.request({ method: "connect" });
      if (closed) return;
      update(connected);
      if (!session?.accounts[0]) throw new Error("No authorized account. Reconnect.");
      if (session.networkHash === networkHash) message("Connected. Check the account and recipient before sending.");
    }); };
    choices.append(button);
  });
```

`localnet()` pins the RPC network identity. The app compares the wallet session with that verified identity; it does not adopt a network selected by the wallet. Provider names are rendered as text.



## 3. Prepare, Sign, Save, and Submit

Append this code inside `start()`. `ERC20` is a generated binding shipped with the SDK. HOG has seven decimals, so `1_000_000n` base units is 0.1 HOG. `prepareExecution()` wraps this transfer through DefaultWallet; `signTransaction()` requests approval without broadcasting.

```ts
  function selection() {
    const account = session?.accounts[0];
    if (!provider || !account || session?.networkHash !== networkHash) {
      throw new Error("Connect a Localnet account first.");
    }
    return { provider, account, key: `wallet-demo:${networkHash}:${account.address}` };
  }

  async function observe(key: string, hash: string) {
    message(`Checking Localnet transaction ${hash}`);
    try {
      const receipt = await client.waitForTransactionReceipt(
        sha256Hash(fromHex(hash.slice(2))), { timeoutMs: 30_000 },
      );
      const result = receipt.execResult === ExecResult.ExecResultOK
        ? "Transfer succeeded" : `Execution failed: ${ExecResult[receipt.execResult]}`;
      message(`${result}\nLocalnet transaction: ${hash}`);
      try { localStorage.removeItem(key); }
      catch { message(`${result}\n${hash}\nCould not clear the saved record. Check again later.`); }
    } catch {
      message(`Outcome unresolved. Keep this Localnet hash: ${hash}\nUse Check saved transaction. Do not send a replacement.`);
    }
  }

  send.onclick = () => { void run(async () => {
    const { provider, account, key } = selection();
    if (localStorage.getItem(key)) throw new Error("Check the saved transaction before sending again.");
    const receiver = addressFromHex(recipient.value.trim());
    const wallet = createProviderWalletClient({ client, provider, account, networkHash });
    active = wallet;
    let submitting = false;
    let hash = "";
    try {
      const transaction = await wallet.prepareExecution({
        invocation: ERC20.v0_1.transfer.invocation(HOG_ADDRESS, gasAmount(500_000n), {
          receiver, amount: 1_000_000n,
        }),
        gasLimit: gasAmount(10_000_000n),
      });
      message("Review the 0.1 HOG transfer in your wallet.");
      const signed = await wallet.signTransaction(transaction);
      hash = signed.hash;
      localStorage.setItem(key, JSON.stringify({ ...signed, account, networkHash }));
      // If storage fails, submission never starts.
      submitting = true;
      await wallet.submitTransaction(signed);
      await observe(key, hash);
    } catch (error) {
      if (submitting) message(`Broadcast may have occurred. Localnet hash: ${hash}\nUse Check saved transaction.`);
      else throw new Error("No broadcast requested. Check the wallet, recipient, and browser storage.", { cause: error });
    } finally {
      wallet.dispose();
      active = undefined;
    }
  }); };
```

The recovery key includes the original network and account. The record includes the signed bytes and hash. Recovery here only reads receipts. A submission acknowledgment is not execution success. Any error after submission starts leaves the record in place.



## 4. Check Status and Clean Up

Append this final block. It closes `start()` and starts the app:

```ts
  check.onclick = () => { void run(async () => {
    const { key } = selection();
    const saved = localStorage.getItem(key);
    if (!saved) { message("No saved transaction for this Localnet account."); return; }
    const pending: unknown = JSON.parse(saved);
    if (!pending || typeof pending !== "object" || !("hash" in pending) ||
        typeof pending.hash !== "string" || !/^0x[0-9a-f]{64}$/.test(pending.hash)) {
      throw new Error("Invalid saved transaction hash.");
    }
    await observe(key, pending.hash);
  }); };
  disconnect.onclick = () => { void run(async () => {
    active?.dispose();
    await provider?.request({ method: "disconnect" });
    update({ networkHash, accounts: [] });
    message("Disconnected. Saved transaction hashes are kept.");
  }); };
  function cleanup() {
    closed = true;
    active?.dispose();
    stopChanges?.();
    stopDiscovery();
  }
  window.addEventListener("pagehide", cleanup, { once: true });
  window.addEventListener("pageshow", (event) => { if (event.persisted) location.reload(); });
  import.meta.hot?.dispose(cleanup);
}
void start().catch(() => message("Cannot connect to Localnet. Start the node, then reload."));
```

The app creates a fresh adapter for each Send action and disposes it afterward. Account or network changes invalidate pending approval work. Cleanup removes listeners without revoking access; the user’s Disconnect action requests revocation. None of these actions automatically re-signs or retries a transfer.



## 5. Try It

Run `npm run dev` and open the localhost URL printed by Vite. Choose your wallet, approve access, and check the displayed account and network. Paste your funded test recipient’s address, click **Send 0.1 HOG**, and review the amount and recipient in the wallet before approving.

Expect a transaction hash followed by **Transfer succeeded** or **Execution failed**. If the outcome is unresolved, use **Check saved transaction**. After a reload, reconnect the same account on the same running ledger to check its saved hash. Switching accounts leaves the original record intact. Status checks only query RPC; they never sign or submit.

If no wallet appears, enable the extension for this browser profile and reload. If you reject approval, start another Send only when you intend a new transfer. A missing receipt or timeout does not prove that a submitted transaction failed.

This small app keeps one unresolved hash per account and network and blocks another send until it gets a receipt. It does not coordinate multiple tabs or provide a manual resolution screen for transactions that never receive a receipt. Keep the hash and investigate on the original ledger using the [recovery guide](pages/tools/wallet-integration.md#recover-an-ambiguous-submission).



## Next Steps

- [Wallet Integration](pages/tools/wallet-integration.md) covers provider errors, lifecycle rules, and recovery policies for a larger app.
- [Work with Groundhog from TypeScript](pages/tutorials/work-with-groundhog-from-typescript.md) shows how to generate your own contract binding. Replace the ERC-20 invocation with your contract’s typed call and keep the same wallet flow.

---

## Design a Swap

Source: <https://docs.groundhog.dev/tutorials/design-a-swap/>

How a constant-product AMM is built on Groundhog, and why the execution model shapes it.

This page follows the contracts behind a swap application. The implementation adapts Uniswap V2’s [pair operations](https://github.com/Uniswap/v2-core/blob/master/contracts/UniswapV2Pair.sol) and [supporting math libraries](https://github.com/Uniswap/v2-periphery/tree/master/contracts/libraries/) to Groundhog’s snapshot execution model. Requests enter a queue concurrently, then a separate transaction processes them against the pair’s reserves.

**Prerequisites:** [Build a Token](pages/tutorials/build-a-token.md). You should be able to write a contract, deploy it, and call another contract through a generated client.

> **note: Sources**
>
> For your reference while following along, the example swap application currently lives in the `groundhog-examples` repository.



## The problem

For each token-pair that the application manages, it tracks its own reserves of each of the two tokens. Every pair operation reads these balances, computes against them, and writes them back:

```rust
let (reserve0, reserve1) = self.reserves.get();
let amount_out = compute_output(amount_in, reserve0, reserve1);
self.reserves.set(&(reserve0 + amount_in, reserve1 - amount_out));
```

On Groundhog, every transaction in a block reads the same committed snapshot. If two transactions compute different reserve values for the same pair, their writes cannot merge. One transaction can land while the other is excluded and returned to the mempool. Identical writes can coexist, so the reserve field alone does not enforce one operation per pair per block.

A direct port therefore needs to account for both conflicting writes and operations that compute identical reserves. Processing requests sequentially inside one transaction makes each operation use the preceding operation’s updated reserves. See [Parallel Execution](pages/how-it-works/execution-model.md) for the storage merge rules.

> **caution: The serial part stays serial**
>
> Nothing here makes the pair’s operations concurrent. They cannot be: each one genuinely depends on the result of the last. What changes is *when* the serial work happens, and how many operations can be performed in one block.



## Split acceptance from execution

Although a pair operation itself has to be performed serially with respect to other operations on the same pair, accepting a request does not.

So our implementation splits them: instead of performing an operation immediately, user requests (many per block) are accepted into a queue. The queue is processed later, in a transaction of its own.

```plaintext
  many transactions, one block              one transaction, later
  ┌──────────┐
  │ Alice    │──┐
  ├──────────┤  │   ┌───────────┐          ┌────────────────────┐
  │ Bob      │──┼──▶│   queue   │─────────▶│ drain: op, op, op  │
  ├──────────┤  │   └───────────┘          └────────────────────┘
  │ Carol    │──┘   inserts commute      serial execution, as required
  └──────────┘
```

The queue is a Groundhog primitive called `RCQ` (“retro-causal queue”). Inserts **commute**: two transactions inserting in the same block do not conflict. Many requests can be accepted together.

Draining is the other half of the RCQ rule: only one transaction per block may consume from a given queue. That is exactly the serialization the pair needs, and now it costs one transaction per block instead of one per user.

With this arrangement, a single transaction can process multiple operations against updated reserves, bounded by its execution budget.

> **tip: The general lesson**
>
> When two transactions conflict, the fix is usually to change *what you write*, not to add locking. A write that commutes (a queue insert, a balance delta) doesn’t require a transaction to be deferred.



## Batch the serial work

We call processing the request-queue *cranking*, and anyone may do it. `Queue::crank` in the `batch-driver` helper crate takes requests off the queue one at a time and hands each to a closure that knows how to perform it. The swap application provides that closure:

```rust
self.queue.crank(|request, gas_limit| {
    cfg.handler()
        .with_commit_locking()
        .with_gas_limit(gas_limit)
        .try_handle_request(request)
})
```

Some details to explain:

**`with_gas_limit`.** Each request carries its own budget, and the processing loop performed in `crank` checks that the frame can still afford one before taking it off the queue. (A request is never consumed and then dropped for want of gas to handle it.)

**`with_commit_locking`.** A request that fails should not take the batch down with it. “Commit-locking” settles the sub-call’s effects as soon as it returns (instead of waiting until the end of the transaction to check invariants), so a failed request can be rolled back alone and the processing continues to the next one. The closure above catches errors using the `try_*` variant of a cross-contract call, and the loop continues with more requests.



### The gas limit is the batch size

Although a root transaction (the one signed by a sender) declares a gas limit, executing it on Groundhog does not *consume* any tokens; rather, tokens are temporarily reserved while the transaction occupies a portion of the chain’s scheduling capacity. (See [Execution](pages/programming-model/execution.md).)

A crank runs until the queue is empty or the frame’s remaining gas is no longer sufficient to run another request, so **the caller chooses the batch size by choosing a gas limit**. A caller can request a small batch, subject to the minimum described below. Someone clearing a backlog asks for a large one. (The `batch-driver` helper provides `gas_for_batch` for converting a request count into the necessary gas limit.)



## Nobody has to be on duty

Cranking needs no privilege, so the policy can be simple: after submitting a request, send a crank as its own transaction with a short expiry, and stop.

Nothing needs to be polled, timed, or estimated, because every way a crank can turn out is harmless:

| Outcome                             | What happens                                                                        |
| ----------------------------------- | ----------------------------------------------------------------------------------- |
| Another crank won the block         | Yours is excluded and returns to the mempool. It may be included before its expiry. |
| The queue was empty at the snapshot | Yours commits having done nothing, writing no delta and conflicting with nobody.    |
| Otherwise                           | It drains the queue, up to the batch its gas limit allows.                          |

The short expiry keeps the first case from becoming a nuisance: a crank that loses several blocks running should give up rather than land much later as a pointless no-op.

If an operator chooses to provide a queue-keeper mechanism, its operation will compose with this without any reconfiguration. When the keeper’s crank runs, everyone else’s cranks defer harmlessly behind it. If it stops, theirs immediately take up the slack.

> **tip: The general lesson**
>
> An excluded crank leaves no committed effects. It can be considered again until its expiry, without coordinating with other crank callers.



### Minimum batch size

Because batch sizes determine application throughput, we want to ensure that each block’s one opportunity to drain the queue is not wasted on too small a batch. So the application’s policy requires that a crank be able to process what is currently waiting in the queue, up to a configured `min_crank_batch`; otherwise it is refused before the queue is touched.



## A queue costs storage, so it needs a ceiling

Storage on Groundhog is a refundable deposit paid from the contract’s own balance. See [Storage Economics](pages/how-it-works/storage-economics.md). A queue anyone can add to is therefore an unbounded claim on whoever funds the contract.

We represent a ceiling with a `CapacityConstraint`, an SDK type that holds the room *remaining* rather than the number of entries used:

```rust
self.slots.consume_capacity(1);   // take this request's room
```

The constraint mechanism allows transactions to consume capacity (corresponding to slots in the finite-sized queue) without conflict, but prevents exhaustion in any particular block. The ceiling is built into the `Queue` datatype in the `batch-driver` helper crate.



### Early is not the same as failed

Note that a transaction that submits a request and thus consumes a unit of queue capacity (as in the line of code above) does not explicitly check whether any capacity is available. If it did (if the capacity constraint were checked at call time), a request arriving at a full queue would have to fail deterministically. The transaction would be committed with the block, have no effect due to the failure, and not be retried. The user would have to submit a new transaction.

Instead, capacity consumption is checked against all concurrent transactions in aggregate when they are being committed as a block; if a resource would be exhausted, some transaction(s) will be excluded from the block and returned to the mempool. Thus the request can land later, once a crank frees capacity. (A caller who cannot wait indefinitely bounds the wait with the transaction’s expiry height.)



## Getting the answer back

As a request is not served in the transaction that submits it, the submitter cannot be given a result. It is provided an identifier instead.

`UniqueIds` (in the `unique-ids` helper crate) mints that identifier from the submitting transaction’s hash and a stored counter. Both halves are needed: the counter separates requests made in one transaction, and the transaction hash separates requests made in different ones, including concurrent transactions in the same block that observe the same counter because neither can see the other’s delta.

The identifier is returned to the caller and stamped on the queued request, so it reappears on whatever event that request eventually produces:

```plaintext
  submit ──▶ RequestAccepted { request_id }
                    ⋮
  crank  ──▶ SwapEvent { request_id, ... }       // success
         or  RequestFailed { request_id, ... }
```

`RequestAccepted`, `RequestFailed` and `RequestsProcessed` are defined in `batch-driver` and emitted by the queue itself, so every application built on this pattern reports on its queue in the same way.



## Components

| Crate          | Role                                                                                  |
| -------------- | ------------------------------------------------------------------------------------- |
| `swap-if`      | Interfaces only: every trait, client, error, and shared value type                    |
| `swap-pair`    | The fundamental operations. Not a contract; the handler runs it in its own invocation |
| `swap-handler` | Performs one request: prices it against live reserves, moves the assets               |
| `swap-driver`  | Holds the queue, batches requests, forwards each to the handler                       |
| `swap-router`  | Builds requests from user operations and enqueues them with the appropriate driver    |
| `swap-factory` | Creates pairs and keeps a registry                                                    |
| `batch-driver` | The reusable part: `Queue`, its crank policy, and the three events                    |
| `unique-ids`   | `UniqueIds`                                                                           |



## Each link takes work only from its predecessor

A request names the account whose tokens it will spend. Nothing downstream from the directly called contract can check that claim, because it is the only one that can see (via [`get_caller`](pages/how-it-works/invocation-frames.md)) who is submitting the request.

```plaintext
  user ──▶ SwapRouter ──▶ SwapDriver ──▶ SwapHandler ──▶ pair operations
           sees the        accepts        accepts
           caller          only from      only from
                           the router     its driver
```

So the router is the only contract that can attribute a request to an account, and each link afterwards accepts work only from its predecessor. `SwapDriver` checks that its caller is the router before enqueuing; `SwapHandler` checks that its caller is its driver before handling. Without those checks, anyone could enqueue a request naming a victim as the payer and themselves as the recipient, and be paid out of the victim’s standing allowance.

In contrast, `process_requests` takes no privilege at all: cranking is permissionless, because a crank can only perform requests that were already accepted, and the more participants willing to do it the better.



## Next steps

- [Parallel Execution](pages/how-it-works/execution-model.md) for snapshots, conflicts, and exclusion
- [Execution](pages/programming-model/execution.md) for gas, scheduling capacity, and merged deltas
- [Storage Types](pages/programming-model/storage-types.md) for `RCQ`, `NNInt`, and what commutes
- [Storage Economics](pages/how-it-works/storage-economics.md) for deposits and who pays for them

---

## Develop Locally with the CLI

Source: <https://docs.groundhog.dev/tutorials/develop-locally/>

Build, deploy, call, and inspect a Groundhog contract against a local hog-devnode.

This tutorial walks through the complete local CLI loop. You will build and test a counter, start an ephemeral Groundhog node, create and fund a wallet for your signing key, deploy, submit calls, and inspect committed state.

Local development is the fastest way to exercise deployment and RPC behavior. The node provides its own local faucet and RPC endpoint.



## Prerequisites

This detailed walkthrough targets [CLI 0.19.0](https://github.com/groundhogchain/groundhog-rpc/releases/tag/v0.19.0) and its managed node. You also need `jq` and [Cargo access](pages/cli/install.md#configure-cargo-access). For latest-release onboarding, use the [contract quickstart](pages/get-started/contract.md). Keep the generated SDK dependencies and compiler toolchain.



### Verify the Selected Runtime

Inspect the CLI and selected runtime:

```bash
command -v groundhog
groundhog --version
groundhog status --json | jq '.data.environment.devnode'
```

Read the returned path, version, and source. CLI 0.19.0’s catalog selects node 0.1.29-rc.4. An explicit `GROUNDHOG_DEVNODE_BINARY` can override managed selection, so a successful status command alone does not establish the intended runtime.

If an inherited override is unintended, remove it for this terminal and inspect the managed selection:

```bash
unset GROUNDHOG_DEVNODE_BINARY
groundhog toolchain list
groundhog toolchain which
groundhog status --json | jq '.data.environment.devnode'
```

Use the same CLI and environment in the terminal that starts the node. Preserve intentional source-build overrides. A protocol mismatch requires matching binaries and bindings, not merely overriding the protocol token.



## 1. Initialize the CLI

Run the guided environment check if this is your first Groundhog project:

```bash
groundhog init
```

Accept signing-key generation to create the stored key named `default`. Decline starter-project creation because the next step creates it explicitly. Init also creates global `local` and `devnet` profiles.



## 2. Create a Counter Project

From the directory where you keep development projects:

```bash
groundhog new my-counter
cd my-counter
```

The generated `groundhog.toml` sets `default_profile = "local"`, so commands run from this project use the local profile automatically. Only `config set` requires an explicit `--profile local`; the other commands below use the project default. If you previously set `GROUNDHOG_PROFILE`, unset it first because it overrides that default.

The generated project defines the private registry in `.cargo/config.toml`. Complete [Cargo access setup](pages/cli/install.md#configure-cargo-access) before the first build. The SDK downloads its test executor from public storage without FFI credentials.

Check the stored key and select it explicitly for this project’s local profile:

```bash
groundhog keys ls
groundhog config set default-key default --profile local --project
```

You should see `default` in the key list. If you skipped key generation during init, run `groundhog keys generate default` first. If you already use a differently named key, substitute its name in the key-selection command above and in `--key default` in step 5. The wallet created in step 5 will still be named `default`.



## 3. Build and Test Locally

Run the fast native tests, then the executor-backed RV32 test:

```bash
cargo test
groundhog build
groundhog test
```

These commands do not require a running JSON-RPC node:

| Command           | What it checks                                                 |
| ----------------- | -------------------------------------------------------------- |
| `cargo test`      | Native contract logic through the SDK test environment         |
| `groundhog build` | Deployable RV32 artifact, lowering metadata, and contract spec |
| `groundhog test`  | The generated executor-backed `tests/test_rv32.rs` target      |

Inspect the generated artifacts:

```bash
ls -lh target/groundhog/
```

For `my-counter`, expect:

```text
my_counter.rv32a
my_counter.rv32.json
my_counter.spec.xdr
my_counter.spec.json
```



## 4. Start the Local Node

Open a second terminal, keep it running, and start the node:

```bash
groundhog node
```

The command starts one supervised `hog-devnode`, exposes JSON-RPC at `http://127.0.0.1:9545`, and records its runtime manifest. The managed runtime’s artifact layout needs no extra flags. Use `--contract-artifacts-dir <DIR>` only for intentional nonstandard artifact directories.

The node is ephemeral. Deployments and calls share state while this process runs, but stopping it discards chain state and clears the active-runtime record.



## 5. Create and Fund Your Local Wallet

Return to the project terminal and check the active node:

```bash
groundhog status
```

The profile should show `default` as the key and `http://127.0.0.1:9545` as the RPC URL. If no endpoint appears, confirm that `groundhog node` is still running and both terminals use the same user configuration.

Create a wallet owned by your stored key, then select it for this project:

```bash
groundhog wallet create --key default --name default
groundhog wallet use default
groundhog wallet ls
```

Confirm wallet creation when prompted. The key signs transactions; the wallet has the on-chain address and holds HOG. `wallet ls` should show `default` as selected. Its address differs from the address printed by `keys ls`.

Wallet creation prefunds the creation transaction. Request 100 local HOG to cover deployment and the subsequent calls:

```bash
groundhog airdrop default --amount 100
groundhog balance default
```

Confirm the airdrop when prompted. The CLI uses the node’s local faucet automatically. Keep this node running for the remaining steps.



## 6. Dry-Run and Deploy

Prepare a signed deployment without broadcasting it:

```bash
groundhog deploy --dry-run
```

Then deploy the RV32 artifact and confirm when prompted:

```bash
groundhog deploy
```

The CLI prints the contract address and saves `my-counter` as an alias under `[profile.local.contracts]` in `groundhog.toml`.



## 7. Initialize and Call the Counter

Deployment and initialization are separate operations. Initialize the counter once, confirming the call when prompted:

```bash
groundhog call my-counter initialize 10
groundhog view my-counter get
```

The first view should return `10`.

Submit another state change:

```bash
groundhog call my-counter increment 5
groundhog view my-counter get
```

The counter should now return `15`.

Use JSON mode when testing scripts or automation:

```bash
groundhog --json view my-counter get \
  | jq -e '.ok == true and .data.schemaVersion == 1 and .data.returnValue == 15'
```



## 8. Confirm Dry Runs Do Not Commit

Prepare a call without broadcasting it:

```bash
groundhog call my-counter increment 100 --dry-run
groundhog view my-counter get
```

The value should remain `15`.



## Integration Test Mode

`groundhog test --integration` starts its own disposable local node, deploys the RV32 artifact, and runs the scaffolded `tests/integration.rs`. Invoke it like this:

```bash
groundhog test --integration
```

The generated starter stays ignored under ordinary `cargo test`. Add your contract-specific RPC assertions to `tests/integration.rs`. See [Testing](pages/programming-model/testing.md#what-the-scaffold-gives-you) for how the CLI activates the test and which environment variables it provides.

The starter uses `groundhog-json-rpc-client` to connect directly to the node. Use `GROUNDHOG_RPC_URL` and `GROUNDHOG_CONTRACT_ADDRESS` for your own RPC assertions.

Use this integration mode for automated RPC tests. For interactive development across several commands, use the long-running `groundhog node` flow above.



## Troubleshooting



### `hog-devnode` is not found

Use the `groundhog` and `hog-devnode` binaries from the same Groundhog client bundle, preserve the extracted directory layout, and add its `bin` directory to `PATH`. For a custom location, set `GROUNDHOG_DEVNODE_BINARY` to that bundle’s `hog-devnode` executable.



### The wrong key or wallet is selected

From the project directory, repeat the explicit selections:

```bash
groundhog config set default-key default --profile local --project
groundhog wallet use default
```

If the wallet has not been created yet, complete step 5 first. Use your actual key name if it differs from `default`.



### The node was restarted

Stopping the ephemeral node discards its wallets, funds, and deployed contracts. Your stored key and project configuration remain. Repeat wallet creation, funding, deployment, and initialization against the new node before continuing.



### Protocol mismatch

First repeat the [runtime selection check](pages/tutorials/develop-locally.md#verify-the-selected-runtime), including inherited environment overrides. Use a `hog-devnode` build compatible with the CLI. Do not use `--hogd-protocol` to make a mismatched installation appear compatible. That developer diagnostic changes only the handshake token, not the wire format; use it only when token-only compatibility has been independently established.



## Next Steps

- [Develop on Devnet with the CLI](pages/tutorials/develop-on-devnet.md) to create a persistent key-owned wallet and deploy to the hosted network
- [Build a Counter](pages/tutorials/build-a-counter.md) for a line-by-line walkthrough of the generated contract
- [Command reference](pages/cli/reference.md) for commands and flags

---

## Develop on Devnet with the CLI

Source: <https://docs.groundhog.dev/tutorials/develop-on-devnet/>

Create a persistent key-owned wallet, deploy a counter to Devnet, and exercise the Groundhog CLI end to end.

This tutorial moves the local development loop onto Devnet. You will use the signing key and profiles created during setup, create a contract wallet, build and test a counter locally, deploy it to the hosted network, submit calls, and inspect committed state.

Complete [Develop Locally with the CLI](pages/tutorials/develop-locally.md) first if you have not yet built, deployed, and called a contract against `hog-devnode`.

> **note: Hosted version must be discovered**
>
> Use the discovery steps below to match the client bundle to the serving release. A local build or test does not verify the hosted Devnet flow.



## Before You Start

You need:

- Rust and Cargo through [rustup](https://rustup.rs/)
- `curl` and `jq`
- Access to the private Groundhog Cargo registry
- Network access to Groundhog Devnet

> **caution: Persistent development key**
>
> This tutorial writes a signing key to your normal Groundhog configuration. Use a dedicated Devnet key, protect the file like any other development credential, and do not use a key that controls anything valuable.

> **note: Fresh setup**
>
> The commands below assume a fresh Groundhog configuration with no stored keys. If you are reusing an installation, follow [Profiles and networks](pages/cli/configuration.md) and [Keys and wallets](pages/cli/wallets.md) to align selections before adapting this tutorial.

> **caution: Devnet resets**
>
> Devnet may be reset. A reset changes its network hash and removes existing wallets, balances, and deployments. After a reset, repeat the identity configuration below, create the wallet again, request an airdrop, and redeploy the contract.



## 1. Initialize the CLI

Start with the CLI installed in the local tutorial, then check it against the hosted deployment below:

```bash
groundhog --version
```

Run the guided setup on first use:

```bash
groundhog init
```

On a fresh setup with no stored keys, accept key generation. Init creates and selects the key named `default`, and creates global `local` and `devnet` profiles. Decline starter-project creation because step 6 creates it explicitly.



## 2. Configure Devnet Identity

Inspect the Devnet profile created by init:

```bash
groundhog config get devnet --sources
```

Init supplies the network, RPC URL, faucet URL, and HOG contract alias. Read the deployment version and packaging release from that RPC:

```bash
DEVNET_RPC_URL=$(groundhog --json config get devnet | jq -er '.data.rpcUrl')
DEVNET_VERSION_JSON=$(curl -fsS -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"groundhog_version","params":[]}' \
  "$DEVNET_RPC_URL")
echo "$DEVNET_VERSION_JSON" \
  | jq -e '.result | {wireFormat, implementation, releaseVersion}'
DEVNET_RELEASE_VERSION=$(echo "$DEVNET_VERSION_JSON" \
  | jq -r '.result.releaseVersion // "unavailable"')
printf 'Reported packaging release: %s\n' "$DEVNET_RELEASE_VERSION"
```

When present, `releaseVersion` identifies a validated [packaging release](https://github.com/groundhogchain/packaging/releases). It and `bundleManifestDigest` are diagnostics and may be absent. Use `wireFormat` for RPC compatibility, and confirm the deployed contract/interface family before using generated bindings. If deployment identity is unavailable, confirm it with the operator rather than guessing a bundle. The local 0.19.0 test recipe does not prove that Devnet has upgraded. Select any required older client/runtime explicitly and keep its generated bindings coordinated.

Hosted transaction signatures also require the live network hash. Read it from the node, validate its format, remove the RPC’s `0x` prefix, and save it in the Devnet profile:

```bash
DEVNET_NETWORK_HASH=$(curl -fsS -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"groundhog_networkInfo","params":[]}' \
  "$DEVNET_RPC_URL" \
  | jq -er '.result.networkHash | select(test("^0x[0-9a-f]{64}$")) | ltrimstr("0x")')
groundhog config set network-hash "$DEVNET_NETWORK_HASH" \
  --profile devnet \
  --global
```

The signing network hash is not the faucet descriptor’s `genesisHash`. Do not substitute one for the other.

Wallet creation, airdrop, deploy, and call validate the selected RPC’s live network identity. A mismatch fails before the CLI signs a transaction. See [Authorization](pages/how-it-works/authorization.md) for why signatures include the network hash.



## 3. Check the Devnet Signing Key

Confirm that the key created by init is selected:

```bash
groundhog keys ls
```

`default` should be marked as selected. If you skipped key generation, create it with `groundhog keys generate default`. The first generated key becomes the global default automatically.

The private key is stored under the Groundhog configuration directory, normally `~/.config/groundhog/keys/`.



## 4. Inspect the Devnet Profile

Init created the global `devnet` profile with its network, RPC, faucet, and HOG contract settings. Inspect it rather than recreating it:

```bash
groundhog config get devnet --sources
```

The report should show the Devnet RPC and faucet URLs from global config. The globally selected `default` key applies because the fresh Devnet profile does not override it. Later, inside a project, the project’s `devnet` profile merges over this global profile.



## 5. Create a Devnet Wallet

Run wallet creation from a directory outside a Groundhog project so it updates the global Devnet profile:

```bash
groundhog wallet create --profile devnet
groundhog wallet ls --profile devnet
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Wallet creation performs a prefund-first flow through the hosted faucet. The faucet funds the future address, deploys the wallet contract, and initializes it for your public key. It never receives your private key.

That prefund pays for wallet creation only. The airdrop funds the effective wallet before its first application deployment.

With no `--key` or `--name`, the CLI uses the selected key and saves the wallet under the same name. Deploy and call resolve the saved wallet through `default`.

If wallet creation reports a pending attempt, rerun the exact same command:

```bash
groundhog wallet create --profile devnet
```

Keep the CLI cache intact until the attempt completes. Its retry record preserves the request’s idempotency data.



## 6. Create and Test a Counter

From the directory where you keep development projects:

```bash
groundhog new my-counter
cd my-counter
```

Build and run the local test paths before submitting anything to Devnet:

```bash
cargo test
groundhog build --profile devnet
groundhog test --profile devnet
```

These commands build and test locally. They do not submit transactions to Devnet.

Inspect the artifacts:

```bash
ls -lh target/groundhog/
```

Expect:

```text
my_counter.rv32a
my_counter.rv32.json
my_counter.spec.xdr
my_counter.spec.json
```

The project and global `devnet` profiles merge. The project supplies contract aliases while the global wallet binding remains available.



## 7. Dry-Run and Deploy

Prepare a current signed deployment without broadcasting it:

```bash
groundhog deploy --profile devnet --dry-run
```

Then submit the deployment:

```bash
groundhog deploy --profile devnet
```

On success, the CLI prints the contract address and saves `my-counter` under `[profile.devnet.contracts]` in the project’s `groundhog.toml`.



## 8. Initialize, Mutate, and Read State

Deployment does not initialize the counter automatically. Call `initialize` once:

```bash
groundhog call my-counter initialize 10 --profile devnet
groundhog view my-counter get --profile devnet
```

The first view should return `10`.

Submit another state change:

```bash
groundhog call my-counter increment 5 --profile devnet
groundhog view my-counter get --profile devnet
```

The counter should now return `15`.

Check structured output with pipeline failure propagation enabled:

```bash
set -o pipefail
groundhog --json view my-counter get --profile devnet \
  | jq -e '.ok == true and .data.schemaVersion == 1 and .data.returnValue == 15'
groundhog --json balance --profile devnet \
  | jq -e '.ok == true and .command == "balance" and .data.schemaVersion == 1'
```



## 9. Confirm Dry Runs Do Not Commit

Prepare an increment without broadcasting it:

```bash
groundhog call my-counter increment 100 --profile devnet --dry-run
groundhog view my-counter get --profile devnet
```

The value should remain `15`.

Submit a final real mutation:

```bash
groundhog call my-counter decrement 3 --profile devnet
groundhog view my-counter get --profile devnet
```

The final value should be `12`.



## 10. Request More HOG If Needed

Check the effective wallet’s balance before requesting more:

```bash
groundhog balance --profile devnet
```

If a later deployment needs more HOG:

```bash
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Do not pass `--amount` for a hosted Devnet airdrop. The faucet sets the amount and enforces deployment-specific quotas.

Remote airdrops are idempotent. If an airdrop reports a pending attempt, rerun the exact same command and keep the CLI cache intact until it completes.



## Troubleshooting



### RPC and faucet mismatch

The CLI rejects a descriptor, RPC identity, or configured network hash mismatch. Inspect the RPC and faucet identities directly:

```bash
DEVNET_RPC_URL=$(groundhog --json config get devnet | jq -er '.data.rpcUrl')
DEVNET_FAUCET_URL=$(groundhog --json config get devnet | jq -er '.data.faucetUrl')
curl -fsS "$DEVNET_FAUCET_URL/v1/network" \
  | jq '{rpcUrl: .endpoints.rpcUrl, networkHash, genesisHash}'
curl -fsS -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"groundhog_networkInfo","params":[]}' \
  "$DEVNET_RPC_URL" | jq '.result'
```

The RPC and faucet `networkHash` values must agree. `genesisHash` identifies different data and is expected to differ.



### Missing RPC or faucet URL

Run `groundhog config get devnet --sources`. If either value is missing, rerun interactive `groundhog init`, which fills missing built-in profile defaults without replacing existing values.



### No wallet for the selected key

Run `groundhog wallet ls --profile devnet`. On a fresh setup, the saved wallet and selected key are both named `default`. Rerun `groundhog wallet create --profile devnet` if needed.



### Insufficient funds

Check `groundhog balance --profile devnet`, then request one airdrop if needed. Avoid unnecessary requests because quotas apply to shared infrastructure.



## Persistent State and Cleanup

Devnet is shared and persists between ordinary requests, but operators may reset it. Deleting local files does not remove your wallet or deployed contracts from the current chain. A Devnet reset does.

Removing a wallet binding only removes local configuration. Removing the signing key permanently removes your ability to control that wallet unless you backed up the key first. Because this tutorial saved the binding globally, run these commands from outside a Groundhog project:

```bash
groundhog wallet rm default --profile devnet
groundhog keys rm default
```

Both commands remove local data only. `keys rm` asks for confirmation. In non-interactive automation, use `groundhog keys rm default --force` only when permanent key removal is intended.

Do not run those commands as routine tutorial cleanup. Keep the key if you intend to reuse the wallet or deployed contract.



## Next Steps

- [Build a Counter](pages/tutorials/build-a-counter.md) for the generated contract’s implementation details
- [Command reference](pages/cli/reference.md) for commands and flags
- [Faucet](pages/tools/faucet.md) for wallet funding behavior and retries
- [TypeScript SDK](pages/tools/typescript-sdk.md) for the cluster-aware Devnet client flow

---

## Work with Groundhog from TypeScript

Source: <https://docs.groundhog.dev/tutorials/work-with-groundhog-from-typescript/>

Build a contract, generate TypeScript bindings, connect to a local node, and use typed contract APIs.

This tutorial connects the Groundhog CLI, a Rust contract, generated TypeScript bindings, and `@groundhogchain/client` in one local workflow.

Use the latest [CLI](pages/cli/install.md) and [TypeScript packages](pages/typescript/setup.md), and keep their generated project and dependency lockfiles.



## How the Pieces Fit

The CLI and TypeScript packages have different jobs:

```text
Rust contract and #[contract] metadata
                  |
                  | groundhog build
                  v
    .rv32a artifact + .spec.xdr API
                  |
                  | groundhog build --bindings ts
                  | or groundhog codegen ts
                  v
       generated TypeScript binding
                  |
                  | imports @groundhogchain/client/contract
                  v
 typed views, invocations, events, and receipt decoding
```

The generated binding contains the contract-specific API: method names, arguments, returns, declared exceptions, events, and entrypoint IDs. The client package provides the shared runtime, JSON-RPC transport, transaction helpers, and standard contract bindings.

| Job                                       | Owner                                          |
| ----------------------------------------- | ---------------------------------------------- |
| Build and deploy a Rust contract          | Groundhog CLI                                  |
| Produce the canonical contract API        | `.spec.xdr` generated during the build         |
| Generate contract-specific TypeScript     | Groundhog CLI codegen                          |
| Connect to JSON-RPC and run chain actions | `@groundhogchain/client`                       |
| Encode calls and decode contract values   | Generated binding plus client contract runtime |
| Authorize an application write            | Wallet contract and signer                     |

This split is similar to an EVM ABI plus an application client, but Groundhog bindings contain typed method and event descriptors instead of dynamically calling methods by name.



## Before You Start

Complete [Develop Locally with the CLI](pages/tutorials/develop-locally.md) first. You need:

- The Groundhog CLI and its managed local runtime
- Node.js `22.12.0` or newer
- Access to the Groundhog Cargo and GitHub Packages registries

Keep `groundhog node` running in a separate terminal throughout this tutorial.



## 1. Create and Build the Contract

Create the generated counter project and select the local development account:

```bash
groundhog new my-counter
cd my-counter

groundhog config set default-key dev-1 \
  --profile local \
  --project
```

Run the native tests, then build the RV32 artifact and TypeScript binding together:

```bash
cargo test
groundhog build --bindings ts --profile local
```

The build writes these application-facing artifacts:

```text
target/groundhog/my_counter.rv32a
target/groundhog/my_counter.spec.xdr
target/groundhog/my_counter.spec.json
target/groundhog/my_counter.ts
```

The `.rv32a` file is deployable code. The `.spec.xdr` file is the canonical contract API consumed by codegen. The `.ts` file is the generated application binding.

Re-run codegen whenever you change an exported method, argument, return type, declared exception, event, or reachable contract type.



## 2. Deploy and Initialize

With the local node running, deploy the contract:

```bash
groundhog deploy --profile local --fund 10
```

The CLI prints the deployed address and saves `my-counter` as a project alias. Keep the printed `0x...` address for the TypeScript application.

Deployment and initialization are separate calls. Initialize the counter once:

```bash
groundhog call my-counter initialize 10 --profile local
groundhog view my-counter get --profile local
```

The view should return `10`.



## 3. Create the TypeScript Application

Create an application directory inside the contract project and copy the generated binding into it:

```bash
mkdir -p web/src/contracts
cp target/groundhog/my_counter.ts web/src/contracts/my-counter.ts
cd web

npm init -y
npm pkg set type=module
npm pkg set scripts.view="tsx src/view.ts"
npm pkg set scripts.write="tsx src/write.ts"
```

Configure GitHub Packages as described in [Package setup](pages/typescript/setup.md), then install the application dependencies:

```bash
npm install @groundhogchain/client @groundhogchain/protocol

npm install --save-dev typescript tsx @types/node
```

Generated bindings import the client contract runtime and the protocol packages directly. Keep these versions coordinated with the CLI that generated the file.



## 4. Run a Typed View

Create `web/src/view.ts`:

```ts
import {
  HttpTransport,
  addressFromHex,
  createGroundhogClient,
} from "@groundhogchain/client";
import { loadLocalDevAccount } from "@groundhogchain/client/local-dev";
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;

const rpcUrl = process.env.GROUNDHOG_RPC_URL ?? "http://127.0.0.1:9545";
const contractHex = process.env.GROUNDHOG_CONTRACT_ADDRESS;

if (!contractHex) {
  throw new Error("Set GROUNDHOG_CONTRACT_ADDRESS to the deployed counter");
}

const client = await createGroundhogClient({
  transport: new HttpTransport(rpcUrl),
});
const contract = addressFromHex(contractHex);
const { address: caller } = await loadLocalDevAccount();

const result = await Counter.get.view({
  client,
  contract,
  caller,
});

console.log({
  value: result.value.toString(),
  height: result.height.toString(),
  events: result.events.length,
});
```

Run it with the address printed by `groundhog deploy`:

```bash
GROUNDHOG_CONTRACT_ADDRESS="0x..." npm run view
```

The generated `Counter.get` descriptor knows from the Rust contract spec that `get()` returns `u64`. Its `view()` method decodes the returned bytes into a TypeScript `bigint`. The binding handles CXS decoding.

Change the contract through the CLI, then run the application again:

```bash
groundhog call my-counter increment 5 --profile local
GROUNDHOG_CONTRACT_ADDRESS="0x..." npm run view
```

The TypeScript view should now print `15`.



## 5. Build a Typed Invocation

Views simulate a contract call against committed state and do not submit a transaction. A state-changing application starts by building a typed invocation:

```ts
import { gasAmount } from "@groundhogchain/client";

const increment = Counter.increment.invocation(
  contract,
  gasAmount(500_000n),
  { amount: 5n },
);
```

The descriptor validates the argument object and encodes its calldata from the contract spec. `increment` is an application invocation, not yet an authorized transaction.



## 6. Execute Through the Default Wallet

A generated application invocation is not a signed transaction. A wallet client supplies the account’s authorization claim, creates the wallet-root invocation, binds the signature to the connected network, and submits the transaction. Call `waitForTransactionReceipt()` separately to observe execution.

The simplest account type is a pubkey account. Its address is derived from one Ed25519 public key and an address nonce. An undeployed pubkey-account address resolves to Groundhog’s native-compatible DefaultWallet, so creating the account does not require deploying or initializing a wallet contract:

```text
Ed25519 key + address nonce
            |
            v
   pubkey-account address
            |
            | kPubkeySignature auth claim
            v
DefaultWallet.execute         root invocation
            |
            v
Counter.increment             application invocation
```

Create a separate `web/src/write.ts`. This complete program connects to the same local node, binds a fresh pubkey account, funds it, executes the invocation, decodes the wallet and child returns, and reads the committed value:

```ts
import { randomBytes } from "node:crypto";
import {
  PrivateKeySigner,
  addressFromHex,
  createGroundhogClient,
  createPubkeyAccount,
  createWalletClient,
  localnet,
  toHex0x,
} from "@groundhogchain/client";
import { gasAmount } from "@groundhogchain/client";
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;

const contractHex = process.env.GROUNDHOG_CONTRACT_ADDRESS;
if (!contractHex) {
  throw new Error("Set GROUNDHOG_CONTRACT_ADDRESS to the deployed counter");
}

const client = await createGroundhogClient({
  cluster: localnet({ rpcUrl: process.env.GROUNDHOG_RPC_URL }),
});
const account = createPubkeyAccount({
  signer: new PrivateKeySigner(randomBytes(32)),
});
const wallet = createWalletClient({ client, account });
const contract = addressFromHex(contractHex);
const increment = Counter.increment.call({
  contract,
  gasLimit: gasAmount(500_000n),
  args: { amount: 5n },
});

const airdrop = await wallet.requestAirdrop();
if (airdrop.status.result !== "ok") {
  throw new Error(`Airdrop failed with ${airdrop.status.result}`);
}

const { txHash, receipt, values } = await wallet.executeCallsAndWait({
  calls: [increment],
  gasLimit: gasAmount(10_000_000n),
});
// increment returns void. The helper checked execution and decoded its result.
console.log(receipt.gasUsed, values[0]);

const committed = await Counter.get.view({
  client: wallet,
  contract,
  caller: account.address,
});

console.log({
  transaction: toHex0x(txHash),
  value: committed.value.toString(),
});
```

Run the write program with the same contract address:

```bash
GROUNDHOG_CONTRACT_ADDRESS="0x..." npm run write
```

`createPubkeyAccount()` constructs the protocol’s `kPubkeySignature` claim and derives the matching address. `createWalletClient()` selects the DefaultWallet adapter automatically for this account type. Because `localnet()` validates the endpoint’s network identity, the wallet can also use the returned network hash when signing.

Gas costs zero tokens, but declared root gas reserves scheduling capacity against the sender’s free HOG. Storage deposits are separate and belong to the address storing the data. The example checks airdrop execution before submitting. Calibrate gas for other workloads; `gasUsed` is not a token fee.

If observation fails, keep `TransactionObservationError.txHash` and query it on the original network. A timeout or cancellation does not prove the operation failed. Never automatically re-sign or replace the transaction. See [Track transaction results](pages/typescript/transaction-status.md).

Do not submit `Counter.increment` directly as the transaction root. `wallet.execute()` wraps it in `DefaultWallet.execute` and then signs and submits the root transaction.

> **note: Local bootstrap accounts**
>
> `loadLocalDevAccount()` returns a manifest-verified native pubkey account. Bind its signer with `createPubkeyAccount({ signer: local.signer, nonce: 0n })` and use the manifest’s network hash. See [Local bootstrap accounts](pages/typescript/accounts.md#use-a-local-bootstrap-account).

For additional implementation references, see the maintained client examples:

- [Transfer native HOG through a pubkey account and DefaultWallet](https://github.com/groundhogchain/client-ts/blob/main/examples/transfer-hog.ts).
- [Deploy and call a counter](https://github.com/groundhogchain/client-ts/blob/main/examples/deploy-counter.ts)

To use an installed browser wallet, follow [Connect a Wallet to Your App](pages/tutorials/connect-a-wallet-to-your-app.md). This tutorial uses local signers.



## 7. Decode Receipts and Events

Generated descriptors can decode a receipt when the descriptor represents the transaction’s root method. In `write.ts`, the root is `DefaultWallet.execute`:

```ts
import { DefaultWallet } from "@groundhogchain/client/contracts";

const outcome = DefaultWallet.v0_1.execute.decodeReceiptOutcome(receipt);

if (outcome.kind === "return") {
  const [incrementReturn] = outcome.value;
  if (!incrementReturn) {
    throw new Error("Expected one child return");
  }
  const value = Counter.increment.decodeReturn(incrementReturn);
}
```

`decodeReceipt()` is the throwing convenience API. `decodeReceiptOutcome()` returns a typed `return`, `abort`, or `failure` result.

The generated DefaultWallet binding decodes its root return into one raw buffer per child. The earlier `executeCallsAndWait` call supplied descriptors and decoded these automatically. When recovering from a receipt alone, retain the original call descriptors or explicitly select the known child method; the receipt does not identify arbitrary child ABIs.

For a void mutation such as `increment` or ERC-20 `transfer`, successful decoding produces `undefined`. Applications commonly combine the root execution result with typed events and a follow-up view of committed state.

After a wallet-backed `Counter.ping` call, its generated event descriptor can find the nested event by emitting contract address:

```ts
import { my_counter } from "./contracts/my-counter.js";
const { PingEvent } = my_counter.v0_1.implementation;

const ping = PingEvent.singleFromReceipt(receipt, {
  contractAddress: contract,
});

console.log(ping.topics.tag);
```

See [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md) for the complete event flow.



## 8. Work with ERC-20 Tokens

The client ships generated bindings for the standard Groundhog ERC-20 and metadata interfaces. You do not need to run codegen for those interfaces:

```ts
import {
  ERC20 as ERC20Versions,
  ERC20Metadata as ERC20MetadataVersions,
  groundhog_erc20_if,
} from "@groundhogchain/client/contracts";

const ERC20 = ERC20Versions.v0_1;
const ERC20Metadata = ERC20MetadataVersions.v0_1;
const { TransferEvent } = groundhog_erc20_if.v0_1.events;
```

A useful token demonstration follows the contract’s authorization and balance preconditions:

| Call                          | Caller                             | Purpose                                        |
| ----------------------------- | ---------------------------------- | ---------------------------------------------- |
| `initialize`                  | Deployer or intended administrator | Set the administrator once                     |
| `mint`                        | Administrator                      | Create a balance for the sending account       |
| `getBalanceOf`, `totalSupply` | Read-only view                     | Confirm balances and supply                    |
| `transfer`                    | Token holder                       | Send part of the caller’s balance              |
| `adjustAllowance`             | Token holder                       | Change a spender’s allowance by a signed delta |
| `transferFrom`                | Spender                            | Transfer from the owner using allowance        |
| `burn`                        | Administrator                      | Destroy tokens from an account                 |

If the contract includes `ERC20Metadata`, use its initializer to set the administrator, name, symbol, and decimals together. Do not call both initializers on a one-time-initialized token.

Read a balance without submitting a transaction:

```ts
const balance = await ERC20.getBalanceOf.view({
  client,
  contract: token,
  caller,
  args: { addr: holder },
});

console.log(balance.value);
```

Build and execute a transfer through the holder’s wallet:

```ts
const transfer = ERC20.transfer.invocation(token, gasAmount(500_000n), {
  receiver,
  amount: 100n,
});

const txHash = await wallet.execute({
  invocation: transfer,
  gasLimit: gasAmount(10_000_000n),
});
const receipt = await wallet.waitForTransactionReceipt(txHash);
const transferReturn = DefaultWallet.v0_1.execute.decodeReceipt(receipt).value[0];
if (!transferReturn) {
  throw new Error("Expected one child return");
}
ERC20.transfer.decodeReturn(transferReturn);
```

`mint`, `transfer`, `adjustAllowance`, `transferFrom`, and `burn` return `void`. Their useful application results are the committed execution outcome, emitted event, and updated state:

```ts
const event = TransferEvent.singleFromReceipt(receipt, {
  contractAddress: token,
});

console.log(event.topics.from, event.topics.to, event.fields.amount);
```

The standard interface uses `adjustAllowance` arguments `{ spender, difference, exclusive }`. `difference` is signed, and `AllowanceChangeEvent` records that delta. An exclusive change conflicts with concurrent changes to the entry, but cannot make an earlier off-chain read current. Read-then-adjust is not a guarantee of an exact target. `clearAllowance({ spender })` revokes and deletes an allowance; `clearBalance()` deletes the caller’s empty balance entry.

Convert human amounts with `parseUnits(text, decimals)` and format with `formatUnits(value, decimals)`, both from the client root. Obtain token decimals from its metadata rather than applying HOG’s seven decimals to every token.



## CLI, Binding, or Client?

Use this rule of thumb:

| You need to…                                              | Use…                                                      |
| --------------------------------------------------------- | --------------------------------------------------------- |
| Build a contract or manage CLI profiles                   | Groundhog CLI                                             |
| Generate types for your contract                          | `groundhog build --bindings ts` or `groundhog codegen ts` |
| Connect to RPC, create an account, execute, sign, or poll | `@groundhogchain/client`                                  |
| Encode or decode one contract’s methods and events        | Its generated binding                                     |
| Call the standard token interface                         | `@groundhogchain/client/contracts`                        |



## Next Steps

- [TypeScript](pages/typescript.md) for client tasks and API reference
- [TypeScript Bindings](pages/tools/typescript-bindings.md) for generated method, exception, and event APIs
- [Build a Token](pages/tutorials/build-a-token.md) for the Rust implementation behind the standard token interface
- [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md) for typed event generation and queries
- [Wallet Integration](pages/tools/wallet-integration.md) for connecting an external wallet
- [Design a Swap](pages/tutorials/design-a-swap.md) for a larger application built from token and cross-contract calls

---

## Use a signer in scripts

Source: <https://docs.groundhog.dev/typescript/accounts/>

Bind a Node.js signer to a native account, request Devnet funds, and use local bootstrap accounts.

Use a signer when your Node.js script or service manages an account’s key. This page sets up a pubkey account. See [Accounts and wallet clients](pages/typescript/wallet-clients.md) for account models and client construction, or [Connect a wallet](pages/tools/wallet-integration.md) for a browser application.



## Bind a signer

Supply a 32-byte Ed25519 private-key seed through your process environment as `GROUNDHOG_PRIVATE_KEY`, using `0x`-prefixed hex. For a disposable Devnet test account, generate one once in your terminal:

```bash
export GROUNDHOG_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep that environment for the funding and send commands. Generating another seed selects another account. For a persistent account, load the existing seed from your secret configuration.

Create `src/wallet.ts`:

```ts
import {
  PrivateKeySigner, createPubkeyAccount, createWalletClient, fromHex0x,
} from "@groundhogchain/client";
import { client } from "./client.js";

const secret = process.env.GROUNDHOG_PRIVATE_KEY;
if (!secret) throw new Error("Set GROUNDHOG_PRIVATE_KEY for this script account");

export const account = createPubkeyAccount({
  signer: new PrivateKeySigner(fromHex0x(secret)),
});
export const wallet = createWalletClient({ client, account });
```

Keep the key in the process’s secret configuration, not browser code or committed files.



## Request Devnet funds

Create `src/fund.ts`:

```ts
import { toHex0x } from "@groundhogchain/client";
import { account, wallet } from "./wallet.js";

const result = await wallet.requestAirdrop();
if (result.status.result !== "ok") {
  throw new Error(`Airdrop execution failed: ${result.status.result}`);
}
console.log("Account:", toHex0x(account.address));
console.log("Funding transaction:", toHex0x(result.txHash));
```

```bash
npx tsx src/fund.ts
```

The client must use a cluster that declares airdrop support. The hosted faucet selects the allocation. `requestAirdrop` polls one attempt with a stable nonce; retain an explicit `clientNonce` if your application must recover the request across process restarts. `requestAirdropAttempt` exposes application-controlled polling.



## Use a local bootstrap account

For a node started by [the CLI](pages/cli/local-node.md), use this instead of the Devnet signer setup:

```ts
import { createGroundhogClient, createPubkeyAccount, createWalletClient, localnet } from "@groundhogchain/client";
import { loadLocalDevAccount } from "@groundhogchain/client/local-dev";

const local = await loadLocalDevAccount();
const client = await createGroundhogClient({
  cluster: localnet({ networkHash: local.networkHash }),
});
const account = createPubkeyAccount({ signer: local.signer, nonce: 0n });
const wallet = createWalletClient({ client, account });
```

The Node.js-only loader verifies a native pubkey account from the runtime manifest and selects the first `local_user`, normally `dev-1`. It reads `GROUNDHOG_RUNTIME_MANIFEST` or the active CLI configuration. If you override the RPC URL, select the manifest for that same node. These deterministic keys are for local development.

---

## Connect to a network

Source: <https://docs.groundhog.dev/typescript/connect/>

Create a public client, select Devnet or a local endpoint, and check network identity.

A public client performs RPC reads without signing. Create one per application network and share it across contract bindings and wallet clients.



## Connect to Devnet

Create `src/client.ts`:

```ts
import { createGroundhogClient, devnet } from "@groundhogchain/client";

export const client = await createGroundhogClient({ cluster: devnet() });
```

Client creation is asynchronous. It fetches the network identity before returning. Other examples import this client from `./client.js`.

To check the connection, create `src/network.ts`:

```ts
import { toHex0x } from "@groundhogchain/client";
import { client } from "./client.js";

const [tip, version] = await Promise.all([
  client.getChainTip(),
  client.getVersion(),
]);
console.log("Network:", toHex0x(client.network.networkHash));
console.log("Block:", tip.height.toString());
console.log("Wire format:", version.wireFormat);
```

```bash
npx tsx src/network.ts
```

No wallet permission or account funding is required.



## Select another endpoint

`devnet({ rpcUrl })` overrides the Devnet endpoint. For a local node, replace the cluster with `localnet()`:

```ts
import { createGroundhogClient, localnet } from "@groundhogchain/client";

const client = await createGroundhogClient({ cluster: localnet() });
```

Start the node with [the CLI](pages/cli/local-node.md) first. Local account manifests and RPC endpoints must refer to the same node.

Use `defineCluster()` for a reusable custom descriptor. `mainnet()` requires an explicit endpoint. Cluster capabilities, such as `airdrop`, declare expected services; they are not server capability discovery.



## Pin a network identity

Devnet is unpinned by default. To require a specific deployment, provide the trusted hash from your environment:

```ts
import { createGroundhogClient, devnet, hashFromHex, networkHash } from "@groundhogchain/client";

const expected = process.env.GROUNDHOG_NETWORK_HASH;
if (!expected) throw new Error("Set GROUNDHOG_NETWORK_HASH to the expected 0x-prefixed hash");
const client = await createGroundhogClient({
  cluster: devnet({ networkHash: networkHash(hashFromHex(expected)) }),
});
```

An identity mismatch throws `NetworkMismatchError`. A Devnet reset can change the network hash. Update the trusted configuration deliberately rather than accepting a wallet-supplied hash as your application’s network.



## Configure transport behavior

Use [HTTP transport](pages/typescript/transport.md) for timeouts, batching, and custom transports. A transport-only client skips cluster identity validation; a wallet bound to it requires an explicit signing network hash.

---

## Deploy a contract

Source: <https://docs.groundhog.dev/typescript/deployment/>

Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.

Use this task when an application or service deploys a supplied contract artifact. You do not need to write Rust, but you do need the `.rv32a` artifact and the bindings from its build. For ordinary developer deployment, use [the CLI](pages/cli/deploy-and-call.md).



## Prepare the deployment identity

For the generated counter, place its artifact and binding in your project. This Node.js example uses the funded account from [Use a signer in scripts](pages/typescript/accounts.md):

```ts
import { readFile } from "node:fs/promises";
import { gasAmount, parseUnits, prepareContractDeployment, toHex0x } from "@groundhogchain/client";
import { Counter } from "./contracts/my-counter.js";
import { account, wallet } from "./wallet.js";

const artifact = await readFile("artifacts/my_counter.rv32a");
const deployment = prepareContractDeployment({
  deployer: account.address,
  contract: artifact,
});
console.log("Predicted address:", toHex0x(deployment.address));
```

Preparation hashes the artifact and predicts its address without signing or submitting. Retain the deployment nonce if you need to reproduce that identity. It differs from the transaction nonce used for replay protection.



## Fund, deploy, and initialize

```ts
const result = await wallet.deployContractAndWait(deployment, {
  gasLimit: gasAmount(10_000_000n),
  amount: parseUnits("10", 7),
  initializer: Counter.v0_1.initialize.invocation(
    deployment.address,
    gasAmount(500_000n),
    { initialValue: 10n },
  ),
});
console.log("Deployed:", toHex0x(result.address));
```

`amount` is explicit raw HOG funding for the target contract. The example allocation and gas budgets are not universal costs. `0n` skips the funding transfer. The sender still needs scheduling capacity for the root transaction.

Funding, deployment, and the optional initializer form one atomic operation. The initializer targets the predicted address and sees the wallet as its caller. If it fails, the operation rolls back. The helper waits for success and verifies the returned deployment address.



## Deploy through a provider wallet

The provider adapter supports the same deployment plan and options, with an additional `{ onSigned }` lifecycle argument. Use the authorized provider account’s address as `deployer`. See [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet) for persistence before submission.

Inspect the original transaction hash if observation fails rather than generating a new deployment attempt. See [Track transaction results](pages/typescript/transaction-status.md).

---

## Read events

Source: <https://docs.groundhog.dev/typescript/events/>

Filter and decode contract events, walk historical pages, and save progress without missing rows.

Use a generated event descriptor to build filters and decode payloads. This page uses the supplied ERC-20 `TransferEvent`; a custom contract uses the event exported by its generated bindings.



## Query events

With the client from [Connect to a network](pages/typescript/connect.md), create `src/events.ts`:

```ts
import { groundhog_erc20_if } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { client } from "./client.js";

const { TransferEvent } = groundhog_erc20_if.v0_1.events;
const page = await client.getContractEvents({
  event: TransferEvent,
  contractAddresses: [HOG_ADDRESS],
  order: "descending",
  limit: 20,
});
for (const event of page.events) {
  console.log(event.blockHeight, event.sequenceNumber, event.fields.amount);
}
```

This fetches one typed page. An empty page is a valid result. Each row retains the emitting contract address, transaction hash, position, topics, and decoded fields.



## Filter topics

Add `topics: { to: owner }` to restrict transfers to a typed address. A named topic accepts one value or `{ oneOf: [...] }`. Filters require one to five contract addresses; each topic alternative list accepts 1–16 values.

Addresses, fixed 32-byte values, supported integer scalars, `U256`, `I256`, and bool have direct encodings. Strings and byte slices are hashed. Use the generated filter’s input types; do not reconstruct topic bytes or assume a hashed value can be read back.



## Walk historical pages

For raw event pages, use the descriptor’s filter and decoder:

```ts
const query = {
  filters: [TransferEvent.filter({ contractAddresses: [HOG_ADDRESS] })],
  order: "ascending" as const,
  anchor: "beginning" as const,
  limit: 20,
};
for await (const page of client.iterateEventPages(query)) {
  for (const row of page.events) {
    const decoded = TransferEvent.decode(row.event);
    console.log(row.blockHeight, decoded);
  }
}
```

The iterator requests pages on demand. It follows empty pages with non-empty continuation cursors and stops on an empty `Uint8Array`. Repeated cursors and RPC errors throw. `decode` returns `null` for a different signature and throws for malformed matching data.

Pass `{ signal }` as the iterator’s second argument to cancel an in-flight read. Breaking the loop stops future requests. There is no automatic retry, polling, subscription, or persistence.



## Resume without missing events

A cursor continues one historical walk; it does not follow later blocks. Keep the network, target, and filters fixed. Store rows and progress in the same database transaction, deduplicating by `(txHash, sequenceNumber)` within that network and query.

After exhausting an ascending walk, start a new walk inclusively at the last stored row’s block height. Replay and deduplicate that block so a partially processed block does not lose rows. `latestBlock` is the indexer’s head, not proof that your application processed every row through that height. Check `oldestBlock` for a retention gap.

The [event walkthrough](pages/tutorials/add-events-to-a-contract.md#resume-without-missing-events) includes application-owned checkpoint storage. For a latest-first UI, refresh from the head rather than continuing an old cursor.



## Decode receipt events

Use `TransferEvent.allFromReceipt(receipt, { contractAddress: HOG_ADDRESS })` to decode matching events in a receipt. `singleFromReceipt` requires exactly one matching event. Both select the emitter as well as the event type; a transaction can call several contracts that emit the same event.

---

## TypeScript

Source: <https://docs.groundhog.dev/typescript/>

Connect applications and services to Groundhog with the TypeScript client and typed contract bindings.

Build browser applications, Node.js services, and scripts with `@groundhogchain/client`. You can read an existing contract without a wallet, signing key, Rust installation, or deployment.



## The application model

A **public client** connects to an RPC endpoint and reads network data. A **contract binding** describes methods, arguments, results, errors, and events. Together they provide typed contract reads.

Writes also need an **account** and authorization. A browser app connects to the user’s wallet provider. A script or service can manage a signer directly. A wallet client wraps application calls into a transaction, signs it, submits it, and observes its result.

```text
Read:   contract binding + public client → typed result
Write:  contract binding + wallet client → signed transaction → receipt
```



## How the packages fit

| Package or entry point             | Role                                                                                    |
| ---------------------------------- | --------------------------------------------------------------------------------------- |
| `@groundhogchain/client`           | RPC clients, accounts, wallet helpers, amounts, and contract runtime                    |
| `@groundhogchain/client/contracts` | Standard contract bindings supplied with the client, including ERC-20 and DefaultWallet |
| `@groundhogchain/protocol`         | Wire types, serialization, and protocol constants such as `HOG_ADDRESS`                 |
| `@groundhogchain/contract-spec`    | Contract schema tooling; most applications use the generated binding instead            |
| `@groundhogchain/react`            | React integration over the client and wallet model; see [React](pages/react.md)         |

Generated bindings are application files, not a replacement for the client package. They import its contract runtime.



## Start with an existing contract

The [TypeScript quickstart](pages/get-started/typescript.md) reads Devnet’s native HOG contract using its supplied binding and address. [Read contract data](pages/typescript/reads.md) uses the same checkpoint, so you can learn the application APIs without first writing a contract.

For a custom contract, obtain its generated bindings, deployment address, and network from its author. [Use contract bindings](pages/tools/typescript-bindings.md) explains how those pieces fit.

[Read events](pages/typescript/events.md) completes the read-only path with filters, decoding, and historical pagination. It also needs no wallet or signer.



## Add writes

Read [Accounts and wallet clients](pages/typescript/wallet-clients.md) to understand account identity, authorization, and call wrapping. Then choose one integration path for your application:

- [Connect a wallet](pages/tools/wallet-integration.md) when the user’s browser wallet manages approval and signing.
- [Use a signer in scripts](pages/typescript/accounts.md) when your Node.js process manages the account key.

These are alternatives, not consecutive setup steps. Both lead to [Send transactions](pages/typescript/transactions.md) and [Track transaction results](pages/typescript/transaction-status.md). [Deploy a contract](pages/typescript/deployment.md) builds on that transaction flow when your application needs to create a deployment.

Complete applications live in [Guides](pages/guides.md). This section covers individual tasks; [Client API reference](pages/tools/typescript-sdk.md) and [Wallet provider reference](pages/tools/wallet-provider.md) provide lookup tables.

---

## Read contract data

Source: <https://docs.groundhog.dev/typescript/reads/>

Read an existing contract with typed views, handle read failures, and cancel stale requests.

A view simulates a contract call against committed state without submitting a transaction. It needs a public client and a binding, not a signer.



## Read the existing HOG contract

Use the `src/client.ts` from [Connect to a network](pages/typescript/connect.md). Create `src/read.ts`:

```ts
import { formatUnits, getContract } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { client } from "./client.js";

const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
const result = await hog.totalSupply.view({ args: undefined });
console.log("HOG supply:", formatUnits(result.value, 7));
console.log("Read at block:", result.height.toString());
```

```bash
npx tsx src/read.ts
```

The client supplies the standard ERC-20 binding, and the protocol package supplies the deployed HOG address. No Rust contract or generated application file is needed for this example.



## Pass arguments and caller context

For an address held by your application:

```ts
import { addressFromHex } from "@groundhogchain/client";

export async function readBalance(ownerText: string, signal?: AbortSignal) {
  const owner = addressFromHex(ownerText);
  return hog.getBalanceOf.view({ args: { addr: owner }, signal });
}
```

A view result includes the typed `value`, snapshot `height`, and simulated `events`. Independent reads can use different snapshots or lag a recent transaction receipt. When checking state after a write, compare the view’s height with the committed receipt’s height before treating it as the post-transaction state.

Pass `caller` when the method needs a simulated caller. This changes call context; it does not prove control of that address or authorize a transaction.



## Handle contract outcomes

`view()` throws `ContractViewError` for an abort or fault. Use `viewOutcome()` when those outcomes belong in your application’s normal control flow:

```ts
const outcome = await hog.totalSupply.viewOutcome({ args: undefined });
if (outcome.kind === "return") {
  console.log(outcome.value);
} else {
  console.error("Contract view failed:", outcome.kind);
}
```

Malformed contract bytes throw `ContractDecodeError`. Transport and RPC failures remain separate from contract outcomes.



## Cancel stale reads

```ts
import { classifyReadError } from "@groundhogchain/client";

export async function refreshSupply(signal: AbortSignal) {
  try {
    return await hog.totalSupply.view({ args: undefined, signal });
  } catch (error) {
    if (classifyReadError(error, { signal }) === "cancelled") return;
    throw error;
  }
}
```

Create an `AbortController` for the operation and call `abort()` when its result is no longer needed. RPC actions take `{ signal }` as request options; bound views take it inside their options object.

`classifyReadError` returns `transient`, `permanent`, `cancelled`, or `unknown`. It does not retry or replace the error. Applications choose retry limits; an unclassified `TypeError` is not proof of a network failure.

---

## Package setup

Source: <https://docs.groundhog.dev/typescript/setup/>

Configure access to Groundhog's JavaScript packages for TypeScript and React applications.

The TypeScript client and React library are distributed through GitHub Packages. Configure registry access once, then install the packages your application imports.



## Before you start

- Install the current Node.js LTS release and npm.
- Obtain access to Groundhog’s GitHub packages.
- Install the [GitHub CLI](https://cli.github.com/) and sign in with `gh auth login`.



## Give npm package access

Authorize package reads, then make the token available to npm in this terminal:

```bash
gh auth refresh -h github.com -s read:packages
export NODE_AUTH_TOKEN="$(gh auth token)"
```

Create a `.npmrc` file in the application directory:

```ini
@groundhogchain:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Keep `${NODE_AUTH_TOKEN}` as a literal reference in this file. Do not replace it with the token. If your environment already supplies a package-read token, use that instead of the GitHub CLI commands.

Use the latest packages when starting a new project and keep the generated lockfile. A package-access error needs an account or token with the required permissions; repository access alone may not be enough.



## Install the TypeScript client

In a new application directory:

```bash
npm init -y
npm pkg set type=module
npm install @groundhogchain/client @groundhogchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src
```

In an existing application, keep its package configuration and add the dependencies you need. `tsx` runs the Node.js examples; browser apps can use their existing bundler.

The client re-exports common types and constructors. Install the protocol package directly when you import protocol-only constants such as `HOG_ADDRESS`. Schema tooling can import `@groundhogchain/contract-spec`; ordinary generated bindings use the client runtime.



## Type-check an application

For the Node.js examples, create `tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "skipLibCheck": true,
    "noEmit": true
  },
  "include": ["src/**/*.ts"]
}
```

```bash
npx tsc
```

The examples use ESM imports and `.js` paths for local TypeScript modules. Browser projects should keep the module settings required by their bundler. Imports from `@groundhogchain/client/local-dev` are Node.js-only.

---

## Track transaction results

Source: <https://docs.groundhog.dev/typescript/transaction-status/>

Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.

Submission, commitment, execution, and decoding are separate steps. Keep the transaction hash and network so the application can continue observing the same operation after a timeout or wallet disconnect.



## Inspect a submitted transaction

Use the public client from [Connect to a network](pages/typescript/connect.md). Create `src/status.ts`:

```ts
import { ExecResult, hashFromHex } from "@groundhogchain/client";
import { client } from "./client.js";

const text = process.env.GROUNDHOG_TX_HASH;
if (!text) throw new Error("Set GROUNDHOG_TX_HASH to the submitted transaction hash");
const hash = hashFromHex(text);
const status = await client.getTransactionStatus(hash);

if (status.status === "committed") {
  const receipt = await client.getTransactionReceipt(hash);
  if (!receipt) throw new Error("The committed receipt is not available from this endpoint");
  console.log("Execution succeeded:", receipt.execResult === ExecResult.ExecResultOK);
  console.log("Block:", receipt.height.toString());
} else {
  console.log("Status:", status.status);
}
```

This performs one status check. `waitForTransactionReceipt(hash)` polls for a receipt, but does not itself require successful execution. Check `execResult` or use `waitForExecution(client, hash)` to require success.



## Interpret status

| Status               | Application meaning                                              |
| -------------------- | ---------------------------------------------------------------- |
| `pending`            | The gateway knows the transaction; keep waiting                  |
| `committed`          | Fetch the receipt and check execution                            |
| `invalid`            | Show the reported reason                                         |
| `recentFailure`      | Advisory failure of an attempt; the transaction can still commit |
| `unknown` or `other` | No conclusive successful or failed execution result              |

A timeout or canceled observation does not cancel onchain execution. Query the original hash on the original network rather than automatically signing a replacement.



## Handle execution-helper errors

| Error                             | What happened                                                     | What to retain                               |
| --------------------------------- | ----------------------------------------------------------------- | -------------------------------------------- |
| `TransactionExecutionError`       | Committed execution failed                                        | `receipt`                                    |
| `TransactionObservationError`     | Observation failed after submission was attempted                 | `txHash`, `cause`, and any `submissionCause` |
| `ExecutionDecodeError`            | Execution succeeded, but child return decoding failed             | Successful `receipt` and decoding cause      |
| `ExecutionReturnUnavailableError` | Execution succeeded, but the wallet did not provide child returns | Successful `receipt`                         |

For example, classify errors from a wallet execution helper:

```ts
import { TransactionExecutionError, TransactionObservationError, toHex0x } from "@groundhogchain/client";

export function describeExecutionError(error: unknown): string {
  if (error instanceof TransactionObservationError) {
    return `Check transaction ${toHex0x(error.txHash)} on its original network`;
  }
  if (error instanceof TransactionExecutionError) {
    return `Committed execution failed: ${error.receipt.execResult}`;
  }
  return error instanceof Error ? error.message : "Transaction operation failed";
}
```

A decoding failure is not a reason to repeat a successful write. Keep the submitted call descriptors if you need to decode the receipt again later.



## Decode the correct method

`decodeReceipt` and `decodeReceiptOutcome` apply to a known **root method**. A wallet-root receipt is not a receipt for the application method it called. Use `executeCallsAndWait` or `decodeExecution(receipt, calls)` for ordered DefaultWallet child returns.

Do not decode a root abort with a child method’s exception schema merely because the transaction contained one child call. The wallet itself may have failed before the child executed.



## Restore application state

After a reload, use the saved hash and network to resume public observation. This does not require the wallet to remain connected. A provider’s `onSigned` callback provides the pre-submission record; see [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet).

For protocol-level outcomes, see [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md).

---

## Send transactions

Source: <https://docs.groundhog.dev/typescript/transactions/>

Build typed calls, execute them through a wallet, and distinguish submission from successful execution.

A binding builds an application call. A wallet wraps that call into an authorized transaction. Use the wallet’s execution helper instead of submitting a contract method directly as the transaction root.



## Send from a script

Set up and fund the account from [Use a signer in scripts](pages/typescript/accounts.md). For this small-transfer example, choose a recipient that already has HOG. Create `src/send.ts`:

```ts
import { addressFromHex, gasAmount, parseUnits, toHex0x } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { wallet } from "./wallet.js";

const recipient = process.env.GROUNDHOG_RECIPIENT;
if (!recipient) throw new Error("Set GROUNDHOG_RECIPIENT to a funded address");

const transfer = ERC20.v0_1.transfer.call({
  contract: HOG_ADDRESS,
  gasLimit: gasAmount(500_000n),
  args: {
    receiver: addressFromHex(recipient),
    amount: parseUnits("0.0001", 7),
  },
});
const { txHash, receipt, values } = await wallet.executeCallsAndWait({
  calls: [transfer],
  gasLimit: gasAmount(1_000_000n),
});
console.log("Committed:", toHex0x(txHash), receipt.height.toString());
console.log("Return value:", values[0]); // transfer returns void
```

```bash
npx tsx src/send.ts
```

The helper waits for successful committed execution and decodes child returns in call order. A returned receipt and a decoded result are separate guarantees; see [Track transaction results](pages/typescript/transaction-status.md) for failures at either boundary.



## Send through a browser wallet

Use the adapter returned by [Connect a wallet](pages/tools/wallet-integration.md). The same typed call works, but the provider helper also requires an `onSigned` callback:

```ts
import type { ContractAddress } from "@groundhogchain/client";
import { gasAmount, parseUnits } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import type { ProviderWalletClient, ProviderExecutionOptions } from "@groundhogchain/client/wallet";

export function sendHog(
  wallet: ProviderWalletClient,
  receiver: ContractAddress,
  onSigned: ProviderExecutionOptions["onSigned"],
) {
  const transfer = ERC20.v0_1.transfer.call({
    contract: HOG_ADDRESS,
    gasLimit: gasAmount(500_000n),
    args: { receiver, amount: parseUnits("0.0001", 7) },
  });
  return wallet.executeCallsAndWait({
    calls: [transfer],
    gasLimit: gasAmount(1_000_000n),
  }, { onSigned });
}
```

Call this from the user’s send action. Your `onSigned` implementation must finish saving the signed bytes, hash, account, and network before it resolves. A failed save prevents submission. The SDK does not provide that storage layer.



## Choose an execution helper

| Need                                                                 | Helper                                     |
| -------------------------------------------------------------------- | ------------------------------------------ |
| Submit and require successful execution                              | `executeAndWait({ invocation, gasLimit })` |
| Also decode typed child returns                                      | `executeCallsAndWait({ calls, gasLimit })` |
| Get a submitted hash and observe separately in a signer-based script | `execute({ invocation, gasLimit })`        |
| Inspect the transaction before signing                               | `prepareExecution(...)`                    |

Provider-backed helpers require the additional lifecycle options shown above. Their explicit prepare/sign/submit path is covered in [Wallet integration](pages/tools/wallet-integration.md#prepare-sign-save-submit-observe).



## Execute multiple calls

Pass an ordered list to `executeCallsAndWait` to execute calls atomically. If a call fails, the transaction does not commit earlier calls’ state changes. The returned `values` follow the same order.

For a provider wallet, await `getCapabilities()` and inspect the returned `atomicBatch` before offering a multi-call action. `null` means unsupported; `maxCalls` gives the advertised limit. The adapter checks support during preparation as well. One atomic wallet transaction is different from [HTTP request batching](pages/typescript/transport.md#http-batching).



## Set gas and funding

Each child call has a budget; the root needs enough gas for the wallet wrapper and its child calls. The numbers above are example transfer budgets, not universal defaults. `walletGasLimit(invocations, overhead)` sums invocation budgets and an overhead that you have measured for your workload. For typed calls, pass each call’s `invocation` field.

Gas costs zero tokens, but the declared root limit uses scheduling capacity backed by the sender’s free HOG. Storage deposits are separate. A new recipient’s first credit must cover its balance storage, so a small first transfer can fail. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).

---

## Configure HTTP transport

Source: <https://docs.groundhog.dev/typescript/transport/>

Set RPC timeouts, batch independent reads, and classify transport failures.

The client uses HTTP JSON-RPC by default. Supply `HttpTransport` when you need explicit timeout, header, or batching settings.



## Set a request timeout

```ts
import { createGroundhogClient, devnet, HttpTransport } from "@groundhogchain/client";

const cluster = devnet();
const client = await createGroundhogClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, { timeoutMs: 10_000 }),
});
```

The cluster still controls identity checks; the transport controls requests to the endpoint. A timeout ends observation of that request, not an already-submitted transaction.



## HTTP batching

Batch independent RPC reads into fewer HTTP requests:

```ts
const batched = await createGroundhogClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, {
    batch: { maxSize: 100, waitMs: 0 },
    timeoutMs: 10_000,
  }),
});
const [tip, version] = await Promise.all([
  batched.getChainTip(),
  batched.getVersion(),
]);
```

Batching is off by default. `batch: true` uses the defaults shown. Concurrent requests are grouped within the scheduling window and split at `maxSize`.

- Responses match by request ID, not array position.
- Per-call RPC errors remain separate. HTTP or malformed-batch failures reject affected requests.
- Cancellation removes one caller; canceling every caller can cancel the shared request.
- Batching does not provide a shared state snapshot or an atomic transaction. Await dependent reads separately.

Server [array and byte limits](pages/reference/json-rpc-api.md#json-rpc-arrays) still apply.



## Handle transport errors

| Error                                       | Boundary                                                        |
| ------------------------------------------- | --------------------------------------------------------------- |
| `HttpRequestError`                          | Network request failed                                          |
| `HttpResponseError`                         | Non-success HTTP status                                         |
| `JsonRpcError`                              | RPC error response; includes `code`, `data`, and method context |
| `ContractViewError` / `ContractDecodeError` | Contract outcome or decoding, not transport                     |

Use `classifyReadError(error, { signal })` when implementing a bounded read-retry policy. See [read cancellation](pages/typescript/reads.md#cancel-stale-reads). Do not apply automatic read retries to transaction submission.



## Use a custom transport

Implement the exported `Transport` interface when integrating another request layer. A client created with only a transport has no validated cluster identity. For wallet use, provide a trusted signing network hash and verify the endpoint separately, or supply a cluster descriptor as above.

---

## Addresses and amounts

Source: <https://docs.groundhog.dev/typescript/values/>

Parse and display exact amounts, addresses, and hashes in a TypeScript application.

Contract integers are JavaScript `bigint` values. Addresses and hashes are typed byte arrays. Convert at the application’s input and display boundaries.



## Parse and display amounts

```ts
import { parseUnits, formatUnits } from "@groundhogchain/client";

const amount = parseUnits("12.05", 2); // 1205n
console.log(formatUnits(amount, 2));  // "12.05"
const oneHog = parseUnits("1", 7);    // 10000000n
```

Both helpers support 0–255 decimals and signed amounts. Parsing rejects whitespace, exponents, and excess precision rather than rounding. `ParseUnitsError.code` is `malformed` or `precision`; invalid decimal counts throw `RangeError`.

HOG has seven decimal places. Other tokens choose their own decimals. Check positivity and the contract’s integer bounds separately. Avoid converting amounts to `number`, which can lose precision.



## Convert addresses and hashes

```ts
import { addressFromHex, hashFromHex, toHex0x } from "@groundhogchain/client";

export function parseInputs(addressText: string, transactionText: string) {
  const address = addressFromHex(addressText);
  const txHash = hashFromHex(transactionText);
  return { address, txHash, displayAddress: toHex0x(address) };
}
```

These inputs use `0x`-prefixed hex. Provider session network hashes use a different wire format: 64 lowercase hex characters without `0x`. Convert explicitly when crossing the [wallet provider](pages/tools/wallet-provider.md#canonical-data-and-limits) boundary.

Use `gasAmount(500_000n)` for a typed gas budget. A gas amount is a computation limit, not a HOG amount.



## Store values in application data

JavaScript’s default JSON serializer does not accept `bigint`. For application-owned storage, use decimal strings for integers and a defined byte encoding for addresses, hashes, and cursors. The client handles RPC serialization itself.

---

## Accounts and wallet clients

Source: <https://docs.groundhog.dev/typescript/wallet-clients/>

Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.

A public client connects to the network. An account describes the identity and authorization used for a transaction. A wallet client combines that account with the operations needed to prepare, sign, and submit transactions.

Account authorization and wallet call behavior are separate. Authorization determines which signatures can originate a transaction. An invocation adapter determines how a wallet contract wraps calls to other contracts.



## Choose an account model

|                 | Pubkey account                                        | Source-address account                                               |
| --------------- | ----------------------------------------------------- | -------------------------------------------------------------------- |
| Constructor     | `createPubkeyAccount`                                 | `createSourceAddressAccount`                                         |
| Address         | Derived from an Ed25519 public key and account nonce  | Existing address supplied by the application                         |
| Authorization   | One Ed25519 signer matching the account preimage      | Signer entries and a claim checked against stored authorization data |
| Wallet behavior | DefaultWallet adapter selected automatically          | Application-call wrapping requires an appropriate adapter            |
| Typical use     | A script account without a separate wallet deployment | An existing account contract with configured signer policy           |

Both constructors create local JavaScript objects. They do not fund an address, deploy code, or change authorization data on chain.



## Create a pubkey account

Given an existing `Signer` named `signer`:

```ts
import { createPubkeyAccount } from "@groundhogchain/client";

const account = createPubkeyAccount({ signer, nonce: 0n });
```

The same public key and account nonce produce the same address. The nonce defaults to zero and is separate from each transaction’s replay-protection nonce.

An undeployed pubkey account uses the network’s DefaultWallet behavior for its root invocation. No separate wallet deployment is needed. See [Use a signer in scripts](pages/typescript/accounts.md) for key loading and funding.



## Describe a source-address account

For an existing account whose stored policy authorizes your signer at key slot zero with sufficient weight:

```ts
import { createSourceAddressAccount } from "@groundhogchain/client";
import { bitMap, weight } from "@groundhogchain/protocol";

const account = createSourceAddressAccount({
  address: walletAddress,
  signers: [{ signer, publicKeyId: 0n }],
  allowedKeys: bitMap(0x01n),
  requiredWeight: weight(1n),
});
```

Here, `walletAddress` is the existing account address, not an application contract you want to call. `publicKeyId` identifies a stored signer slot; `allowedKeys` selects slots for the authorization claim. The signatures must satisfy both the stored policy and the claim’s required weight.

The constructor does not register signers or set their weights. Those must already be configured on chain. See [Authorization](pages/how-it-works/authorization.md#source-address-accounts) for the protocol rules.



## Bind an account to a client

With a pubkey `account` and the cluster-aware public client from [Connect to a network](pages/typescript/connect.md):

```ts
import { createWalletClient } from "@groundhogchain/client";
import { client } from "./client.js";

const wallet = createWalletClient({ client, account });
```

The wallet is a separate object. It retains public-client operations and adds signing and account operations. Pubkey accounts also receive DefaultWallet execution helpers such as `executeAndWait` and `executeCallsAndWait`. Multiple accounts can share the original public client.

For a source-address account, `createWalletClient` provides transaction preparation and signing, but does not infer how its account contract wraps application calls. Supply an `invocationAdapter` that matches that contract to obtain the execution helpers. Do not select an adapter from the authorization model alone. Custom implementations use `defineWalletInvocationAdapter`; see [Client API reference](pages/tools/typescript-sdk.md#choose-an-account-model).

A cluster-aware client supplies its validated signing network hash. A transport-only client requires an explicit `networkHash` when creating the wallet client.



## Bind a browser wallet provider

In a browser app, the wallet provider manages signing. Use an authorized account returned by its session:

```ts
import { createProviderWalletClient } from "@groundhogchain/client/wallet";

const wallet = createProviderWalletClient({
  client,
  provider,
  account: selectedAccount,
  networkHash: expectedNetworkHash,
});
```

`selectedAccount` is the provider’s wire `WalletAccount`, containing its address, public key, and derivation nonce. It is not the signer-backed account object returned by the constructors above. The provider integration supports pubkey accounts and DefaultWallet behavior; it does not expose a raw signer.

`expectedNetworkHash` is the application’s trusted network identity in provider format, without `0x`. The factory does not request connection permission. Follow [Connect a wallet](pages/tools/wallet-integration.md) for discovery, account selection, and session cleanup.
