# Project Thruput documentation

Documentation source: `53198a762a9adc3260457997acb6ad86b75d9932`. Hosted docs may be newer than this snapshot.

## Get Started

Source: <https://thruput.network/docs/get-started/>

Choose a starting point for Project Thruput contracts, applications, or coding agents.

Get a working result on Futurenet. Choose the tools you want to use; you do not need to follow every path.



## Choose your path

- **[CLI quickstart](pages/get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](pages/get-started/contract.md):** build and test a counter, deploy it to Futurenet, and read its updated value.
- **[TypeScript quickstart](pages/get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](pages/get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.



## Work with a coding agent

[Build with an Agent](pages/start/build-with-an-agent.md) gives you one prompt to install the tools, fund a wallet, and deploy and call a counter on Futurenet. For a smaller task, use the prompt in an individual quickstart.



## What you need

CLI and contract work use the [Thruput CLI and Cargo registry](pages/cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](pages/typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Futurenet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.



## Build a complete application

Follow the four-part [Build a counter](pages/tutorials/build-a-counter.md) guide from contract to TypeScript, React, and a wallet-approved update. Each part builds on the project from the previous part.

For token and AMM contract projects, see [Guides](pages/guides.md). New to the platform? Read the [Introduction](pages/architecture.md) before choosing a path.

---

## CLI quickstart

Source: <https://thruput.network/docs/get-started/cli/>

Create a Futurenet wallet, request native test tokens, and inspect your first transaction from the terminal.

Create a wallet on Futurenet, fund it with native test tokens, and inspect the funding transaction. These tokens have no monetary value. You do not need a contract project or a local node.

**Before you start:** [install the latest CLI](pages/cli/install.md). Run these commands outside an existing Project Thruput project so they use your global configuration.



## 1. Set up the CLI

```bash
thruput init
thruput config use futurenet
```

On a fresh installation, accept signing-key creation and decline starter-project creation. Without a terminal, such as from a script or coding agent, run `thruput init --non-interactive --generate-key` instead. Setup creates the `default` key and the `local` and `futurenet` network profiles. Selecting `futurenet` sets the global default, so later commands and new projects use it without a `--profile` flag.



## 2. Create a wallet

```bash
thruput wallet create
```

Confirm the prompt. The CLI saves a wallet address for your selected key. Creating this wallet does not fund it or send a transaction.

```bash
thruput wallet ls
```

You should see your wallet’s name and address. With a fresh setup, its name is `default`.



## 3. Request test funds

```bash
thruput airdrop
thruput balance
```

Confirm the airdrop and wait for its result. You should have a positive native-token balance. Save the transaction hash printed by the airdrop command.

The faucet selects the test-token amount; you do not need an amount flag.



## 4. Inspect the transaction

Replace `TX_HASH` with the hash from the airdrop:

```bash
thruput tx show TX_HASH
```

Check that the transaction committed successfully. You now have a funded wallet and have verified an onchain result.



## Next

[Deploy your first contract](pages/get-started/contract.md) using this wallet.

If funding is pending, rerun the same airdrop command to resume the request. For network errors or faucet limits, see [Faucet](pages/tools/faucet.md).



## Use a coding agent

Copy this prompt into your agent:

```text
Help me complete the Thruput CLI quickstart:
https://thruput.network/docs/get-started/cli/
Use the latest CLI, install the thruput skill, and read thruput skill show cli.
Run thruput init, then thruput config use futurenet outside a project.
Set up a Futurenet wallet without creating a contract project or running a local node.
Preserve any existing keys and configuration. Request test funds,
check the wallet balance, and inspect the airdrop transaction.
Report success only after checking the committed transaction result.
Ask me to supply any required registry access through my environment,
not in this conversation. Report a network failure rather than bypassing it.
```

---

## Contract quickstart

Source: <https://thruput.network/docs/get-started/contract/>

Create, test, and deploy a Rust counter contract to Project Thruput Futurenet.

Deploy a counter to Futurenet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](pages/get-started/cli.md) so you have the latest CLI and a funded Futurenet wallet. Keep your [Cargo registry access](pages/cli/install.md#configure-cargo-access) available in this terminal.



## 1. Create a contract

```bash
thruput new my-counter --template counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`. The counter uses [Balance](pages/programming-model/storage-types.md#balance) for nonnegative counts.



## 2. Build and test

```bash
thruput build
thruput test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.

The generated project follows your global Futurenet selection. Check it with `thruput config get` before deploying.



## 3. Deploy to Futurenet

```bash
thruput deploy --estimate
```

Read the reported minimum funding in whole native tokens. Add **10 native test tokens** as this walkthrough’s storage allowance, then replace `TOTAL_FUNDING` below with that decimal total. The allowance is an example budget, not an estimate of initializer writes or a universal requirement. These tokens have no monetary value. See [deployment estimates](pages/cli/deploy-and-call.md#estimate-deployment-funding) for the breakdown.

```bash
thruput deploy --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
```

Confirm the deployment. Funding, deployment, and initialization happen atomically. The CLI prints the contract address and saves the alias `my-counter` in the project’s Futurenet profile. The sender also needs its own storage and scheduling capacity.



## 4. Change the counter

Increase the counter initialized during deployment:

```bash
thruput call my-counter increment 5
```

Confirm the call and wait for success. Do not initialize again: this example method adds the initial amount rather than enforcing one-time initialization.



## 5. Read the result

```bash
thruput view my-counter get
```

The result should be **15**. You have built, tested, deployed, and called a contract on Futurenet.



## Next

[Build a Counter](pages/tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](pages/contracts/project-structure.md).



## Use a coding agent

```text
Help me complete the Project Thruput contract quickstart:
https://thruput.network/docs/get-started/contract/
Use the latest CLI. Check CLI setup first: select Futurenet with
thruput config use futurenet if it is not already selected, and confirm
the wallet is funded. Scaffold my-counter with --template counter, then
install the thruput skill in that project and read thruput skill show
contracts. Preserve the generated dependency and compiler settings, then
build and test it.
Read the deployment estimate and add the documented storage allowance to its
minimum. Deploy with that explicit total and initialize atomically to 10,
increment by 5, and verify that the view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```

---

## TypeScript quickstart

Source: <https://thruput.network/docs/get-started/typescript/>

Connect to Futurenet and read the native-token contract with a typed TypeScript client.

Read the native token’s total supply from Futurenet with a typed contract call. This experimental token has no monetary value. This path needs Node.js and package access, but no CLI, signing key, or contract deployment.



## 1. Create a project

```bash
mkdir my-thruput-app
cd my-thruput-app
npm init -y
npm pkg set type=module
mkdir -p src
```

Configure [npm package access](pages/typescript/setup.md#give-npm-package-access) in this directory, then install the SDK and a TypeScript runner. Client 0.24.0 requires protocol 0.19.0, so install these exact versions:

```bash
npm install --save-exact @thruputchain/client@0.24.0 @thruputchain/protocol@0.19.0
npm install --save-dev typescript tsx @types/node
```



## 2. Read a contract

Create `src/index.ts`:

```ts
import { createThruputClient, futurenet, formatUnits, getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";

async function main() {
  const client = await createThruputClient({ cluster: futurenet() });
  const nativeToken = getContract({ binding: ERC20.v0_1, address: NATIVE_TOKEN_ADDRESS, client });
  const supply = await nativeToken.totalSupply.view({ args: undefined });

  console.log("Native-token supply:", formatUnits(supply.value, 7));
  console.log("Read at block:", supply.stateBlockHeight.toString());
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
```

`futurenet()` selects Futurenet. The SDK includes the native-token contract’s standard binding, and `NATIVE_TOKEN_ADDRESS` is its protocol constant, so you do not need to generate a binding. `supply.value` is a typed integer; formatting it displays whole-token units rather than base units.



## 3. Run it

```bash
npx tsx src/index.ts
```

You should see **Native-token supply** and **Read at block**, each followed by a value. Run the command again to make another read. The values come from Futurenet and can change; there is no fixed expected block number.

This is a read-only call. It does not request wallet permission or submit a transaction.



## Next

Use [Read contract data](pages/typescript/reads.md) for arguments, caller context, and cancellation, or [Connect a wallet](pages/tools/wallet-integration.md) to add signing and transaction submission.



## Use a coding agent

```text
Build the Project Thruput TypeScript quickstart:
https://thruput.network/docs/get-started/typescript/
Use @thruputchain/client 0.24.0 with @thruputchain/protocol 0.19.0 and the hosted Futurenet.
Configure package access through my environment. Create the typed native-token
total-supply read shown in the guide and run it. Show the actual supply
and block height, or report the exact error if the request fails.
Do not install the Rust toolchain, deploy a contract, or create a wallet
for this read-only example. Keep the generated package lockfile.
```

---

## React quickstart

Source: <https://thruput.network/docs/get-started/react/>

Display live Futurenet contract data in React with a typed query and a refresh action.

Build a React page that reads the native token’s total supply from Futurenet and refreshes it on demand. This experimental token has no monetary value. You do not need a wallet, the CLI, or your own contract.



## 1. Create the application

Use the current Node.js LTS release:

```bash
npm create vite@latest my-thruput-ui -- --template react-ts
cd my-thruput-ui
```

Configure [npm package access](pages/typescript/setup.md#give-npm-package-access) in this directory, then install the application dependencies:

```bash
npm install
npm install @thruputchain/react @thruputchain/client @thruputchain/protocol @tanstack/react-query
```



## 2. Connect the providers

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, futurenet } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Futurenet…</p>);

async function start() {
  const client = await createThruputClient({ cluster: futurenet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Futurenet"}</p>,
  );
});
```

The client and query cache are created once. `WalletProvider` makes the client available to Project Thruput hooks; it does not connect a wallet automatically.



## 3. Display the result

Replace `src/App.tsx`:

```tsx
import { formatUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    address: NATIVE_TOKEN_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>Native token on Futurenet</h1>
      {supply.isPending && <p>Reading the contract…</p>}
      {supply.error && <p role="alert">{supply.error.message}</p>}
      {supply.data && (
        <>
          <p>Supply: {formatUnits(supply.data.value, 7)} native tokens</p>
          <p>Read at block: {supply.data.stateBlockHeight.toString()}</p>
        </>
      )}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

The hook runs the typed view and exposes loading, error, and data states. Refresh makes another network read; it does not send a transaction.



## 4. Open the app

```bash
npm run dev
```

Open the local URL printed by Vite. The page should show a supply value and block height. Click **Refresh** and confirm that the page finishes another read. Also check that the project builds:

```bash
npm run build
```



## Next

See [Read contract data](pages/react/reads.md) for arguments and query behavior, or [Connect a wallet](pages/react/wallets.md) to add wallet controls. [Send transactions](pages/react/transactions.md) covers approval and execution state.



## Use a coding agent

```text
Build the Project Thruput React quickstart:
https://thruput.network/docs/get-started/react/
Use a React TypeScript Vite project, the latest published Project Thruput
packages, and hosted Futurenet. Configure package access through my environment.
Display the native-token total supply and its read height with useContractView.
Include loading and error states and a Refresh button. Run the build
and verify the actual page result. No CLI, contract deployment, or wallet
connection is needed for this read-only example. Report package or network
errors rather than forcing incompatible dependencies or faking results.
```

---

## Build with an Agent

Source: <https://thruput.network/docs/start/build-with-an-agent/>

Give your coding agent one prompt to install the Thruput CLI, fund a wallet, and deploy and call a counter contract on Project Thruput Futurenet.

Paste this prompt into your coding agent. It will install the CLI and skill, read an exported copy of the docs, and build and verify a counter contract on Futurenet.



## Copy the prompt

```text
Help me deploy and use my first Project Thruput counter contract on Futurenet.

1. Install the latest Thruput CLI and run thruput init. Use
   thruput --help to see all available commands. Follow the installation
   instructions at https://thruput.network/docs/cli/install/.
2. Install the thruput skill user-wide for this coding agent with
   thruput skill install --global, then read the installed skill.
3. Export the documentation into a new folder with thruput docs export.
   Read its index and the relevant setup and contract instructions.
4. Outside a project, run thruput config use futurenet to select the global
   default. Create a wallet with thruput wallet create, then request test funds
   with thruput airdrop. Verify the balance before deployment.
5. Run thruput new counter --template counter, enter the project directory,
   and check thruput config get still selects futurenet. New projects inherit
   the global default. Build the contract and run its tests.
6. Deploy and initialize the counter to 10. Call increment with 5,
   then verify that its read-only view returns 15.

Finish with the project location, contract address, transaction hashes,
verified counter value, and the CLI commands I can use next.
```

The agent follows the [CLI](pages/get-started/cli.md) and [contract](pages/get-started/contract.md) quickstarts. Provide repository or registry access through your local environment when requested.

See [Skills and local docs](pages/cli/agent-tools.md) for installation requirements, agent selection, and Markdown export. For a smaller task, use the prompt in an individual [quickstart](pages/get-started.md).

---

## Introduction

Source: <https://thruput.network/docs/architecture/>

Learn what Project Thruput is and how compatible updates let contracts share state.

Project Thruput is a moonshot project exploring how parallel execution can make compute abundant. Transactions record compatible changes to shared state, allowing the network to combine them without requiring sequential execution.

The project’s future is open. No decisions have been made about timelines or its relationship to Stellar’s existing L1 network. These docs describe the development network and tools available today.

The [whitepapers](pages/whitepapers.md) introduce the system design and research on bridging between Federated Byzantine Agreement blockchains.

You write contract logic in Rust and connect applications through the TypeScript client or React library. The runtime combines changes using rules defined by the storage type.



## Record the change

Consider a counter with a value of `100`. Two transactions want to increase it, one by `5` and the other by `3`.

If each transaction replaces the value it read, they propose different results: `105` and `103`. With mergeable integer storage, they record the increases instead:

```text
Starting value:    100
Transaction A:     +5
Transaction B:     +3
Combined value:    108
```

These increases can combine if the rest of the transactions are compatible and network limits permit them. Neither transaction needs to calculate a replacement value that includes the other’s update.

This is useful for shared counters and balances. It does not make every operation independent: replacing a value, enforcing uniqueness, or choosing a winning order can require different rules. Your storage choices determine which changes can combine.

[Parallel Execution](pages/how-it-works/execution-model.md) explains how Project Thruput applies these rules. [Storage types](pages/programming-model/storage-types.md) shows how to use them in a contract.



## Build in two layers

**Contracts** define application rules and store onchain state. Use the Rust SDK to write and test them, and the CLI to build, deploy, and inspect them.

**Applications** read contract data and request transactions. The TypeScript client provides network and contract operations. The React library adds wallet connection and balance hooks for interfaces.

You can start with either layer. An application can use an existing contract without implementing one first.



## Where to start

Choose a path in [Get Started](pages/get-started.md) to write code. To explore the platform first, use the [System Overview](pages/how-it-works/architecture.md) as a map, then follow the [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) or read about [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).

---

## System Overview

Source: <https://thruput.network/docs/how-it-works/architecture/>

How Project Thruput's public gateway, execution services, storage, and consensus coordinator fit together.

Project Thruput separates three responsibilities: serving applications, executing transactions and storing state, and agreeing on blocks. This page maps those responsibilities to the services that handle them.



## Components

```text
Applications and wallets
      |
      v
JSON-RPC gateway
      |
      +-- Reads
      |   State / Views / History
      |
   submits
      v
  Scheduler <--> Coordinator
      |               |
      |         Other validators
      |
      +-- Auth server
      +-- Executors <--> DB shards
      +-- Event server
```

The diagram shows the main service relationships. [Networking](pages/how-it-works/networking.md) covers registration and communication between them.

| Component                            | Responsibility                                                                                                      |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| **JSON-RPC gateway** (`hog-gateway`) | Accepts application requests, submits transactions to the scheduler, and routes reads to the relevant service       |
| **Scheduler / mempool** (`hogd`)     | Queues transactions, coordinates authorization, dispatches execution, and orchestrates block production and commits |
| **Auth server**                      | Checks transaction authorization claims and signatures before scheduling                                            |
| **Executors**                        | Run contract code and submit its state changes for reservation against the proposed block                           |
| **DB shards**                        | Serve state snapshots, enforce storage merge rules, and store committed state                                       |
| **Event server and indexer**         | Collect execution results and make transaction history, receipts, and events available for queries                  |
| **Coordinator** (`chuckd`)           | Drives consensus with other validators and asks the execution layer to propose, validate, and commit blocks         |



## Two paths through the gateway

**Transactions** enter through the gateway and reach the scheduler. The scheduler arranges signature checks, selects work, and dispatches it to executors. The execution layer produces a block proposal; the coordinator handles agreement with other validators.

**Reads** use the service appropriate to the request. State and balance queries use the database gateway, read-only contract calls use the view gateway, and receipt and event queries use the indexer. The scheduler supplies information such as the chain tip and pending transaction status.

The public gateway does not participate in consensus. Applications use its [JSON-RPC API](pages/reference/json-rpc-api.md) rather than the internal service interfaces.



## Execution and agreement

The execution layer determines what a proposed block would do. Contracts run against a shared snapshot and produce typed state changes. Executors and DB shards check which changes can be reserved together.

The coordinator drives agreement on which valid proposal to commit. It uses the Stellar Consensus Protocol (SCP); it does not run the contracts itself. Each validator checks the proposed result through its own execution layer before committing it.

Multiple execution workers and database shards distribute work within a node. Consensus coordinates agreement between validators. These are different responsibilities; adding execution capacity does not change the consensus rules.



## Explore the details

- [Parallel Execution](pages/how-it-works/execution-model.md): Snapshots, compatible updates, and conflict reservation
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): Submission, execution outcomes, and commit
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): Scheduling and storage deposits
- [Consensus](pages/how-it-works/consensus.md): Proposals, validation, and finality
- [Networking](pages/how-it-works/networking.md): Component registration and internal interfaces

For the behavior your contract relies on, read [Contract Execution](pages/programming-model/execution.md).

---

## Parallel Execution

Source: <https://thruput.network/docs/how-it-works/execution-model/>

How the engine executes transactions against snapshots and reserves compatible state changes.



## The Core Idea

Every transaction reads from a consistent snapshot and records typed deltas. The storage type determines how those deltas combine.

Commutativity describes operations whose combined result does not depend on their order. Project Thruput still enforces resource limits, including gas limits, bounded return values, and a maximum encoded transaction size.

This page explains the engine: snapshots, concurrent reservation, and conflict selection. For the rules your code relies on, read [Contract Execution](pages/programming-model/execution.md).



## Snapshot Isolation

Each transaction sees the ledger as it was at the start of the block. All transactions in a block read from the same snapshot. Ordinary storage reads do not observe other transactions’ writes within that block.

Reads also reflect changes within the current transaction and successful child calls. The database snapshot analogy does not imply identical SQL isolation or conflict rules.

`RetrocausalQueue` also permits observations of concurrent inserts. These are recorded as nondeterministic proposal data and replayed by validators. Its read semantics differ from ordinary snapshot storage.



## Delta Writes

Transactions record typed operations: arithmetic deltas, value replacements, or deletions. Each storage type defines how those operations combine.

Instead of “set balance to 50”, a transaction says “increment balance by 10.” After each root contract call completes, the runtime reserves its delta batch alongside compatible deltas already admitted to the proposed block. The admitted deltas form the next state at commit.

In Solidity, a transfer looks like this:

```solidity
// Solidity: read balances and assign their updated values.
balances[from] = balances[from] - amount;
balances[to] = balances[to] + amount;
```

In Project Thruput:

```rust
// Project Thruput: write deltas. Two compatible transfers to the same
// account produce two deltas that merge cleanly.
balances.at_mut(&from).decrease(amount);
balances.at_mut(&to).increase(amount);
```

Two compatible increments to the same balance produce the same result regardless of order. `(x + 3) + 5 = (x + 5) + 3`. That is commutativity, and it is why Project Thruput can execute transactions in parallel without declared access lists.



## What Commutes and What Doesn’t

Transactions execute concurrently. Storage merge rules determine whether their changes can land together. A conflicting transaction is excluded from that proposal. Exclusion does not guarantee automatic requeue or a `retry` status. See [Exclusion, requeue, and resubmission](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission) for scheduler behavior and client recovery.

| Operation                               | Can both changes land? | Why                                                             |
| --------------------------------------- | ---------------------- | --------------------------------------------------------------- |
| Two balance changes on the same counter | When compatible        | Resolved bases must match and aggregate bounds must hold        |
| Two writes to different Map keys        | Yes                    | Independent keys don’t interact                                 |
| Two writes to the same bytestring       | When identical         | Different values conflict                                       |
| Multiple inserts into the same queue    | Yes                    | Entries are sorted; insertion order doesn’t matter              |
| Two deletions of the same key           | Yes                    | Same outcome regardless of order                                |
| A deletion and a write to the same key  | No                     | Different operation types conflict; one transaction is excluded |

These rules describe the listed operations. Other changes in either transaction can still cause a conflict.



### What This Means for Your Data Model

Choose storage around the changes your application needs to combine. Mergeable arithmetic still has bounds; absolute writes can coexist when they store identical values. [Storage Types](pages/programming-model/storage-types.md#choosing-a-type) turns these rules into contract-design choices.



## How Conflicts Are Resolved

The programming model describes a transaction as executing first and then attempting to land its deltas. The engine implements that boundary directly: ordinary storage conflicts are checked after the root contract call returns, before the transaction is committed into the proposed block.



### Concurrent Delta Reservation

Contract execution accumulates writes in the transaction’s `ItemView`. A checked operation such as `Balance::decrease(30)` first loads the snapshot base and can abort immediately if that transaction alone would underflow. A lazy operation skips that load and therefore cannot report a snapshot-bound failure from contract code. Both forms produce an NNInt delta.

After the root call returns successfully, `try_commit_transaction()` submits the transaction’s complete delta batch to hogd. For a lazy `NonnegativeIntAdd`, hogd resolves the set value from the block snapshot. A checked `NonnegativeIntSetAdd` already carries that same snapshot value. Both then use the same NNInt type-class match and aggregate bounds reservation.

For a snapshot balance of 10, the per-key reservation starts with subtraction capacity of 10:

```plaintext
Snapshot: Alice balance = 10
          Subtraction budget = 10

Tx A contract returns with delta -8
      Reserve delta batch: capacity 10 → 2 → admitted

Tx B contract returns with delta -5
      Reserve delta batch: capacity would be -3 → excluded
```

Whichever transaction reserves first wins. The lock is per-key, per-block and is initialized from the snapshot. Reservations on different keys use separate locks. Transactions touching the same key contend for the same aggregate bounds. Reservation can happen concurrently across executor workers; atomic capacity accounting ensures the combined admitted delta remains in range.

Compatible operations, such as two increases within the upper bound or two decreases within the available balance, can both reserve successfully. Checked and lazy operations share these merge rules. Checked operations can detect underflow in contract code; lazy operations leave that check to reservation. Credits from other transactions do not increase the snapshot’s subtraction budget. A lazy decrease cannot rely on another transaction’s same-block credit.



### What Block Close Does

By the time block close runs, all capacity conflicts have been resolved. Block close stages the already-finalized locks into a ChangeSet and computes the block hash. No conflict resolution happens at this stage for Balance, NNInt, Map, Value, or Bytestring operations.

RetrocausalQueue is the exception: it has end-of-block invariant checks that the other storage types do not. RCQ entries from excluded transactions are removed during block finalization.

The proposer records reservation-dependent outcomes so validators can replay and verify the proposed block. Contract code chooses storage operations; it does not manage the engine’s reservation locks.



## Related reading

- [Contract Execution](pages/programming-model/execution.md): The contract-author model
- [Storage Types](pages/programming-model/storage-types.md): API choices and merge rules
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): Gas limits, scheduling, and deposits

---

## Transaction Lifecycle

Source: <https://thruput.network/docs/how-it-works/transaction-lifecycle/>

How a transaction moves from submission to committed state.

Submitting a transaction is the start of the process. A successful submission does not prove that the contract call succeeded. Check the committed receipt’s execution result.



## Outcomes to distinguish

| Outcome                       | What it means                                                                                                                                                                               |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Rejected before execution** | Admission or authorization failed; the transaction did not reach contract execution                                                                                                         |
| **Committed success**         | The transaction is in a finalized block and its contract changes were applied                                                                                                               |
| **Committed abort or fault**  | The failure is recorded in the block, but the contract changes are discarded                                                                                                                |
| **Excluded from a proposal**  | That attempt did not land in the proposal. Exclusion does not consume its replay nonce or establish its outcome in another proposal. Requeue and reported status depend on later processing |

A pending or `unknown` status, a timeout, or an advisory `recentFailure` is not proof of a committed failure. Keep the original network and transaction hash, and resume observation instead of automatically signing a replacement. See [Track transaction results](pages/typescript/transaction-status.md) for the application workflow.



## Overview

A transaction passes through six stages:

1. **Submission**: Client submits a signed transaction
2. **Authorization**: Signatures are verified before the transaction enters the scheduling queue
3. **Scheduling**: The transaction is queued and selected for a block
4. **Execution and reservation**: Contract code runs against a snapshot, then its completed delta batch is reserved against the proposal
5. **Block Assembly**: The proposer packages results into a block proposal for consensus
6. **Commit**: Finalized state is written to storage



## Stage 1: Submission

The client signs the domain-separated preimage containing the network hash and inner transaction, then submits the signed wrapper through the JSON-RPC gateway. The network hash prevents replay on another Project Thruput network. The gateway submits directly to the hogd scheduler.



## Stage 2: Authorization

The mempool sends the transaction to the auth server, which verifies the root address, auth claim, and signatures. Pubkey claims use the public key attached to the signed transaction (`SignedTransaction.pubkey_claim_key`). Its hash must equal the claim’s `pubkey_hash`. Source-address claims use the root address’s registered authorization data. This happens before the transaction enters the scheduling queue, not during execution.

- If verification succeeds: the transaction enters the scheduling queue
- If verification fails: the transaction is rejected

See [Authorization](pages/how-it-works/authorization.md) for the signature preimage and admission models.



## Stage 3: Scheduling

Verified transactions are queued by account with balance-proportional scheduling. When the coordinator asks for a block proposal, the mempool selects transactions from accounts whose token-backed capacity has waited longest. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md) for how scheduling priority works.



## Stage 4: Execution

Selected transactions execute in parallel against a **consistent snapshot** of the ledger state. All transactions in a block read from the same snapshot taken at the start of block processing.

When contract code executes:

- It reads state values from the snapshot (via syscalls like `BytestringGet`, `NonnegativeIntGet`)
- Ordinary storage reads do not see writes from other transactions in the block; RCQ consumers can observe concurrent inserts
- It produces deltas describing how to modify state
- It runs until termination (return, abort, or fault)

**Conflict checking follows root execution.** If the root call succeeds, the executor submits its completed delta batch for reservation against the proposed block. An incompatible batch is excluded. Contract execution and reservation can both proceed concurrently across executor workers. See [Parallel Execution: How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the mechanism and the distinction between checked and lazy operations.

See [Invocation Frames](pages/how-it-works/invocation-frames.md) for detailed execution semantics (frame lifecycle, child calls, merge/discard rules).



### Root Frame Completion

When the root frame completes, the runtime checks its status:

- **Return (success)**: the transaction’s deltas are submitted for reservation. They are included only if the transaction remains admissible.
- **Deterministic Abort or Fault**: the failure can be included in the block with the contract’s writes discarded. Protocol bookkeeping, including replay protection, is still recorded. Once committed, this is a final execution result, not a transaction waiting to be retried.

This is distinct from **conflict exclusion** during reservation (Stage 4): the root frame may return successfully, but its completed delta batch can still fail reservation and be excluded. Deterministic abort and non-deterministic conflict exclusion are two different failure modes with different on-chain semantics.



## Stage 5: Block Assembly

The proposer packages the included transaction results into a consensus proposal: signed transaction hashes (`SignedTransactionHash`), nondeterministic execution data, and the computed block hash. The proposal is sent to validators via SCP. See [Consensus](pages/how-it-works/consensus.md) for how the proposer/validator split works.



## Stage 6: Commit

Once consensus confirms the block, each validator commits the verified result to its DB shards. The new ledger state becomes the snapshot for the next block.

Committed aborts and faults remain in the block with their contract changes discarded. Their replay nonces are consumed.



## Exclusion, requeue, and resubmission

Exclusion applies to one proposal. It does not guarantee that the transaction will return to the mempool or that the client will observe `retry`.

| What happens to the node’s proposal | What its scheduler does                                                                                      |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Its own proposal commits            | Removes the attempted transactions, including excluded ones. Records retryable execution failures as `retry` |
| A different proposal commits        | Can requeue transactions from its nomination that are absent from the committed block                        |
| Its nomination is rolled back       | Requeues its cached transactions                                                                             |

Automatic requeue in the last two cases does not guarantee later inclusion. After removal in the first case, that scheduler needs another submission to attempt the transaction again.

`retry` is a retained scheduler outcome. The indexer can separately report an advisory `recentFailure`, either as a status or alongside `pending`, `retry`, or `dropped`. It can describe an earlier attempt. Indexed commitment takes priority over these observations. A timeout, `unknown`, or `recentFailure` alone does not prove that the transaction never executed.

Clients retain the signed bytes, transaction hash, and original network. Receipt polling observes the outcome and does not resubmit. When retrying is appropriate, resubmit the same signed transaction while it remains valid. Expiration prevents future inclusion; it does not prove that an earlier attempt never committed. See [Resubmission and replacement](pages/typescript/transaction-status.md#resubmission-and-replacement) for the application workflow.

Sources: engine `0.1.31-rc.16` [commit handling](https://github.com/thruputchain/hogd/blob/fff489c82d0ff28594e9dc8694aa5571787be7fd/hogd/hog_mempool/rpc_from_coord.cc#L3251-L3335) and [nomination rollback](https://github.com/thruputchain/hogd/blob/fff489c82d0ff28594e9dc8694aa5571787be7fd/hogd/hog_mempool/rpc_from_coord.cc#L1246-L1258), and tools `0.40.0` [status composition](https://github.com/thruputchain/thruput-tools/blob/774ea4be4287b096eb38a57aa4aa952b038f5c7b/crates/x23/hogd-backend/src/native/transaction/status.rs#L4-L54).



## Related Documentation

- [Invocation Frames](pages/how-it-works/invocation-frames.md): Execution context
- [Authorization](pages/how-it-works/authorization.md): How signatures are verified
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Code hashes and deployment identities

---

## Compute, Capacity & Storage

Source: <https://thruput.network/docs/how-it-works/storage-economics/>

How the native token provides scheduling capacity and refundable storage deposits without conventional gas fees.

Project Thruput has no conventional gas fees. Its native token backs onchain storage and provides scheduling capacity under load. The current experimental network’s native token has no monetary value.

Removing the sequential execution bottleneck is intended to make compute abundant rather than keep it scarce by design. Parallel execution does not remove hardware limits or contention: the network still meters computation and allocates capacity when demand exceeds it.



## The Two Jobs of the Native Token

Each unit of the native token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Locking native tokens for storage reduces the free balance available for scheduling.



## Execution: Metered, Throughput-Allocated

Running contract code has no conventional gas fee. It still uses finite execution and scheduling capacity, backed by the sender’s unlocked native-token balance.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

A root gas limit above the network’s `max_tx_gas` (default 1,000,000,000) fails validation, and the gateway rejects the transaction at submission. Scheduling reserves one native-token base unit (one ten-millionth of a token) per unit of gas limit. If the gas limit is larger than all of the account’s unlocked native tokens, the scheduler drops the transaction with status `dropped`.

There is no unused-gas token refund. Metering does not debit or refund the sender’s native-token balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.



### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to unlocked native-token balances over time. If account A holds 1,000 unlocked native tokens and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s unlocked tokens sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, its declared gas limit determines how much token-backed capacity moves from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose capacity has waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

Tokens cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

Native tokens transferred between accounts enter the recipient’s scheduling queue as newly received capacity. They do not carry the sender’s accumulated scheduling age.



## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks native tokens according to the [storage type](pages/programming-model/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees native tokens for other storage or scheduling capacity.



### Cost Accounting

Every contract has a native-token balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts native tokens from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked native tokens to the contract’s free balance.

If an address does not have enough unlocked native tokens to cover a storage change, reservation can fail for insufficient funds. That attempt is excluded from the proposal. Exclusion does not guarantee automatic requeue or a `retry` status. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Exclusion, requeue, and resubmission](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.



### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.



### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.



## The Native Token

A sufficient first native-token credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](pages/typescript/accounts.md#request-futurenet-funds).

The native token is implemented by a native precompiled contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting. Use `ADDRESS_NATIVE_TOKEN` in Rust, `NATIVE_TOKEN_ADDRESS` from `@thruputchain/protocol` in TypeScript, and the `NATIVE_TOKEN` contract alias in CLI commands.



## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.



## Related Documentation

- [Contract Execution](pages/programming-model/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](pages/how-it-works/execution-model.md): How compatible state changes are admitted
- [System Overview](pages/how-it-works/architecture.md): The component map
- [Storage Types Reference](pages/reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](pages/get-started/contract.md): Deploy your first contract

---

## Consensus

Source: <https://thruput.network/docs/how-it-works/consensus/>

How SCP coordinates proposals, validation, and finalized blocks.



## Overview

Project Thruput uses the Stellar Consensus Protocol (SCP) for agreement. Each validator chooses **quorum slices**: sets of validators whose agreement it considers sufficient. Overlapping quorum slices allow validators to agree on a block.

Nomination uses a priority function to favor a proposed value in each round. Validators still need agreement under the configured quorum rules before finalizing a block.

SCP provides finality under its quorum-intersection and fault assumptions. Applications use the finalized block result rather than a probabilistic confirmation count.



## The Coordinator

Consensus is driven by the coordinator (chuckd), which is separate from the execution engine (hogd). The coordinator’s job is to get validators to agree on which block to commit. Contract execution and storage belong to the execution layer, orchestrated by the scheduler. See [System Overview](pages/how-it-works/architecture.md) for the component roles.

Each coordinator is configured with its own quorum set: the list of other validators it trusts for consensus. This peer configuration is managed by the coordinator, not the mempool. The mempool handles intra-node component registration (executors, DB shards, etc.); the coordinator handles inter-node consensus topology. This separation keeps execution concerns and agreement concerns independent.

It runs a state machine called the **baton** that drives the consensus loop.



## Block Production

The baton runs a drive loop after every event:

```plaintext
driveCommit()    →  Commit any externalized block
driveNominate()  →  Propose next block if idle
driveCatchup()   →  Fetch missing blocks from peers
driveLiveness()  →  Detect stuck consensus
```



### Single-Node Flow

On a single validator (e.g. during development):

1. Baton calls `schedulercoord_propose_block` on the mempool. The execution layer runs queued transactions and assembles a proposal.
2. SCP externalizes immediately (single-node quorum).
3. Baton calls `schedulercoord_commit_block` on the mempool. The execution layer commits the finalized proposal to storage.
4. Next drive cycle begins.



### Multi-Node Flow

With multiple validators:

1. **Propose.** A validator asks its mempool for a block proposal. The proposal contains the transactions and metadata.
2. **Disseminate.** The full consensus value (nomination + metadata) is broadcast to peers via Dogwood (see below). A compact hash reference (the “cue”) is sent through SCP.
3. **Validate.** Receiving validators ask their own mempool: “is this nomination valid against my state?” Validation runs asynchronously and results are cached.
4. **Converge.** SCP envelope exchange continues until validators agree. Agreement depends on quorum intersection and the configured trust assumptions.
5. **Commit.** Once SCP externalizes a value, each validator commits the block locally via its mempool.



### Execution During Block Production

The proposer and validators execute transactions differently.

**The proposer runs concurrent execution.** Transactions are fanned across multiple executors and coroutines in parallel. After a root call completes, NNInt capacity locks reserve its delta batch via atomic compare-and-swap (see [Parallel Execution: How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved)). Which transaction wins a contested lock depends on thread scheduling. This is non-deterministic: two runs of the same transaction set on the same machine can produce different winners.

**The proposer captures nondeterministic outcomes.** Each transaction produces a `NondeterministicProposalData` payload covering proposal-dependent decisions such as capacity reservation outcomes and retrocausal queue observations. This payload is packaged alongside the signed transaction hashes (`SignedTransactionHash`) in the consensus proposal.

**Validators replay deterministically.** Validators receive the proposer’s nominated transaction list and the nondeterministic data. They reconstruct each transaction from their local mempool, pair it with the proposer’s captured decisions, and replay execution using those decisions as input. Validators do not re-run the concurrent race. They verify that the transactions produce the claimed state transitions, recompute the block hash, and confirm it matches.

|                       | Proposer                                                          | Validator                                 |
| --------------------- | ----------------------------------------------------------------- | ----------------------------------------- |
| Execution             | Concurrent across executors                                       | Deterministic replay with proposer’s data |
| Conflict resolution   | Non-deterministic thread race                                     | Reproduced from captured decisions        |
| Transaction selection | Discretionary (from local mempool)                                | Fixed (from nomination)                   |
| Output                | Nomination: signed tx hashes + nondeterministic data + block hash | Accept or reject the nomination           |

The proposer has discretion over which transactions to include and which conflicting transaction wins. Validators verify the math of the proposed result, not the policy that produced it. Deterministic replay makes the proposed result verifiable. It does not establish proposer fairness; scheduling and transaction selection are separate from validating state transitions.



## Dissemination: Dogwood

Validators exchange three types of data during consensus:

| Data                 | Description                                                               |
| -------------------- | ------------------------------------------------------------------------- |
| **Transactions**     | Signed transactions gossiped between validators                           |
| **Consensus values** | Full block nominations (transactions + metadata)                          |
| **SCP envelopes**    | Protocol messages for agreement (nominate, prepare, confirm, externalize) |

Dogwood is the dissemination layer. It uses **erasure-coded multicast**: data is split into chunks, encoded with redundancy, and broadcast over BFS multicast trees. Receivers can reconstruct the original data from a subset of chunks, reducing bandwidth requirements while tolerating packet loss.

Each data type is tagged and demultiplexed on receipt. Transactions are forwarded to the mempool. Consensus values are cached locally for validation. SCP envelopes are fed to the embedded SCP kernel.



## Finality Model

Under the required quorum assumptions, loss of enough validators can stop progress without invalidating finalized blocks. Incorrect or disjoint trust configurations can violate those assumptions.

Practical implications:

- **No confirmation count.** A confirmed transaction is final. There is no “wait for 6 blocks” or “99.9% probability of finality.”
- **Finalized blocks.** Under the consensus safety assumptions, finalized blocks are not replaced by competing blocks.
- **Halt recovery.** If the network halts due to quorum loss, it resumes from the last committed block once enough validators return. Nodes may need to catch up before participating again.



## Catchup and Repair

Validators that fall behind (new nodes, network partitions, restarts) catch up by fetching missing blocks from peers. The catchup agent requests blocks by height, validates them, and replays them locally.

A separate repair agent handles missing data during active consensus: if a validator receives a hash reference it cannot resolve (a consensus value or SCP envelope it hasn’t seen), it requests the full data from the originating peer.



## Related Documentation

- [Networking](pages/how-it-works/networking.md): Node topology and how the coordinator connects to the mempool
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Parallel Execution](pages/how-it-works/execution-model.md): How transactions execute against snapshots
- [System Overview](pages/how-it-works/architecture.md): The component map

---

## Networking

Source: <https://thruput.network/docs/how-it-works/networking/>

Node topology, component registration, and how transactions reach the mempool.

The [System Overview](pages/how-it-works/architecture.md#components) maps the main components. This page explains how they find each other and communicate.



## Topology

Project Thruput’s services are organized into an execution layer and a consensus layer.

The **coordinator** (chuckd, written in Go) sits above the execution layer. It drives consensus with other validators, manages peer topology, and tells the local mempool when to produce and commit blocks.

The **mempool** (scheduler, part of hogd) is the hub of the execution layer. All execution components register with it: executors, DB shards, event server, auth server. The mempool orchestrates block production, transaction execution, and state commits.

Separately, the **RPC gateway** (`hog-gateway`) provides external API access. It connects to the scheduler, indexer, database gateway, and view gateway but does not participate in consensus. It can be scaled independently of the validator.

Within the execution layer, no component discovers peers independently. The mempool is the registry for intra-node communication. When a component registers, it gets back the addresses of everything else it needs to talk to.

The coordinator manages inter-node consensus and transaction gossip using its configured peers and quorum sets. See [Consensus](pages/how-it-works/consensus.md) for how coordinators reach agreement.



## Component Registration

Components register their addresses and readiness with the scheduler. Most use an “intro” RPC; the event server uses a prepare/activate handshake. The scheduler waits for the required components before dispatching work.

Registration interfaces:

1. **DB shards** register via `scheddb_intro_shard`. Multiple shards can register (horizontal storage scaling).
2. **Event server** registers via `schedevent_prepare_event` and `schedevent_activate_event`. One per node.
3. **Executors** register via `schedexec_intro_exec`. Multiple executors can register (parallel transaction execution).
4. **Auth server** registers via `mempoolauth_intro_auth`. Handles transaction signature verification.
5. **Coordinator** registers via `schedulercoord_intro_coord`. Drives consensus and block production.

The listed execution-layer interfaces use XDR-RPC over TCP. Protocol definitions live in `.x` files (XDR IDL) and are compiled to C++ (hogd), Rust (thruput-protocol-rs crates such as `thruput-xdr`), TypeScript, and Go bindings.



## The Mempool as Orchestrator

The mempool (scheduler) is more than a transaction pool. It orchestrates the block lifecycle:

- Receives client transactions directly from the RPC gateway and peer transactions from the coordinator
- Verifies transactions through the auth server
- Maintains per-account transaction queues with balance-proportional scheduling
- Assembles block nominations when the coordinator requests them
- Dispatches transactions to executors for parallel execution
- Collects execution results after executors have submitted their deltas to the database for reservation
- Notifies DB shards of state changes at commit

The coordinator requests proposals and commits. The scheduler coordinates the execution services that perform the work.



## Coordinator Connection

The coordinator (chuckd) is the consensus participant. It connects to the mempool and drives block production through these RPC calls:

| Call                            | Purpose                                           |
| ------------------------------- | ------------------------------------------------- |
| `schedulercoord_propose_block`  | ”Build a proposal for this block”                 |
| `schedulercoord_validate_block` | ”Is this peer’s proposed block valid?”            |
| `schedulercoord_commit_block`   | ”Finalize this block”                             |
| `schedulercoord_submit_vetted`  | Forward peer-gossiped transactions to the mempool |

The mempool also calls back to the coordinator via a reverse RPC channel to notify it when transactions pass vetting (triggering dissemination to peers).



## External Access

Clients submit transactions and query state through the public gateway.

**JSON-RPC gateway.** Exposes JSON-RPC 2.0 over HTTP and routes requests to the relevant execution-layer service. See [JSON-RPC API](pages/reference/json-rpc-api.md) for the method reference.

**Wallet integration.** Wallets sign transactions client-side and submit them through the JSON-RPC gateway. See [Wallet Integration](pages/tools/wallet-integration.md) for the application-facing flow.



## Transaction Flow

Client submissions reach the scheduler through the gateway; peer-gossiped transactions arrive through the coordinator. The coordinator then drives proposal, validation, and commit through the interfaces above. Follow [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) for the complete sequence and its possible outcomes.



## Related Documentation

- [Consensus](pages/how-it-works/consensus.md): How the coordinator reaches agreement with peers
- [Parallel Execution](pages/how-it-works/execution-model.md): How transactions execute against snapshots and produce deltas
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): The six stages from submission to commit
- [System Overview](pages/how-it-works/architecture.md): The component map

---

## For Blockchain Developers

Source: <https://thruput.network/docs/start/for-blockchain-developers/>

Understand Project Thruput's storage and execution rules through a familiar token transfer.

The contract lifecycle is familiar: write, test, deploy, and call. The main changes are how storage updates combine and how execution and storage are funded. This page introduces those shifts using a Solidity transfer as the starting point.

***



## Token Transfers

A token transfer on Solidity:

```solidity
function transfer(address to, uint256 amount) public {
    require(balances[msg.sender] >= amount, "insufficient");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

The same transfer on Project Thruput:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The code stays familiar. `balances` is a `Map<ContractAddress, Balance>`. Calling `at_mut(address)` selects the balance that will change and returns a mutable handle. Selecting it does not load the balance.

`decrease(amount)` loads the sender’s snapshot balance because the contract needs to fail immediately when funds are insufficient. `lazy_increase(amount)` skips the receiver load because the contract does not need an immediate overflow result. Its bound is checked when the transaction’s completed delta batch is admitted. Both calls produce deltas that can merge with compatible transactions. `Balance` accepts only nonnegative amounts and exposes no absolute `set` operation.

[Build a Token](pages/guides/build-a-token.md) uses this pattern in a complete contract. [Merged Deltas](pages/programming-model/execution.md#merged-deltas) explains how Project Thruput combines changes across a block.

***



## Reentrancy and Balance Checks

`Balance::decrease` checks the transaction’s current balance view. The runtime also checks aggregate bounds when concurrent deltas are reserved. This does not replace authorization or application-specific checks.

Contract calls also have different reentrancy rules from the EVM. See the [EVM reentrancy comparison](pages/ecosystem/evm.md#reentrancy) for that call pattern, and [Authorization](pages/how-it-works/authorization.md) for caller checks and signed permissions.

***



## Resource and Transaction Rules

Project Thruput exposes these rules to contract developers:

- **Gas price estimation.** Gas limits exist for metering, but gas costs zero. The declared gas limit still consumes scheduling capacity.
- **Ordering-sensitive balance updates.** Commutative balance deltas have the same merged outcome in any execution order. Application flows that conflict still need protocol-aware design.
- **Nonces.** Replay protection uses a unique expiry-height and nonce pair, without a sequential account counter.
- **Access lists.** Project Thruput discovers storage access during execution. Compare [Solana account declarations](pages/ecosystem/solana.md#access-lists-vs-type-based-parallelism) with Ethereum’s optional [EIP-2930 access lists](https://eips.ethereum.org/EIPS/eip-2930).
- **Storage slot packing.** Typed fields via `#[thruput_sdk::storage]`. No manual layout, no packing variables into 256-bit slots.
- **TTL management.** No storage expiry. Data persists as long as its native-token deposit is held. Delete the data, get the deposit back.

***



## The Programming Model in Brief

Choose operations that express the change you intend. Use `Balance` for ordinary balance adjustments, `Map` for separate records, and other storage types when the application needs different merge rules. Compatible arithmetic can combine, but ordering-sensitive workflows still need an explicit design.

[Contract Execution](pages/programming-model/execution.md) explains snapshots and deltas. [Storage Types](pages/programming-model/storage-types.md) covers the available APIs, and [NNInt and concurrent updates](pages/programming-model/nnint.md) covers the lower-level integer model.

***



## Storage Choices and Parallelism

The transfer example uses relative balance adjustments so compatible transfers can share a block. Replacing those adjustments with absolute values changes the conflict rules. Review your data model, not just the syntax, when adapting an existing contract.

***



## Next Steps

Continue in layers:

1. [Contract quickstart](pages/get-started/contract.md) builds and deploys your first contract.
2. [Build a Token](pages/guides/build-a-token.md) applies checked and lazy balance operations in a complete ERC-20-style contract.
3. [Contract Execution](pages/programming-model/execution.md) and [Storage Types](pages/programming-model/storage-types.md) give the full contract-author model.
4. [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) explains the engine’s reservation machinery.

For a detailed mapping from Solidity to Project Thruput, see [EVM & Solidity](pages/ecosystem/evm.md).

---

## EVM & Solidity

Source: <https://thruput.network/docs/ecosystem/evm/>

Translate Solidity contract patterns into Project Thruput storage, calls, and authorization.

The contract lifecycle remains write, test, deploy, and call. The main differences are typed storage updates, the call runtime, and resource accounting. This page compares those mechanisms, not network performance.



## The Contract Lifecycle

| Task       | Project Thruput path                                                     |
| ---------- | ------------------------------------------------------------------------ |
| Write      | Rust with SDK storage handles and contract macros                        |
| Compile    | `thruput build` produces an RV32 artifact and contract-spec sidecars     |
| Deploy     | Fund the new contract’s storage and deploy with the CLI or wallet client |
| Initialize | Call an ordinary method, optionally atomically through `deploy --init`   |
| Call       | Use generated Rust or TypeScript bindings                                |
| Read       | Use a typed view through the public client or `thruput view`             |

Project Thruput entrypoints use 8-byte IDs and CXS arguments. Ethereum contract calls commonly use a 4-byte selector and ABI arguments; see [Ethereum transactions](https://ethereum.org/en/developers/docs/transactions/). Use bindings rather than constructing either encoding manually.

Project Thruput deployment addresses derive from the deployer, nonce, and code hash. This resembles `CREATE2` in allowing address prediction, but uses a different preimage. See [Contract artifacts and addresses](pages/how-it-works/contracts.md).



## Mental Model Shifts

| Solidity / EVM pattern               | Project Thruput pattern                                                                                |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| Mapping of token balances            | `Map<ContractAddress, Balance>`                                                                        |
| Read-modify-write balance assignment | Checked or lazy relative balance changes                                                               |
| `require` or `revert`                | `ensure` or a typed contract exception                                                                 |
| `msg.sender`                         | `get_caller()`, the immediate caller                                                                   |
| Constructor                          | An ordinary initializer with a contract-defined guard                                                  |
| Solidity interface and ABI           | Shared Rust interface and generated contract spec                                                      |
| `view` / `pure`                      | Rust receiver choice does not enforce runtime read-only behavior; use the call’s read-only restriction |



## Execution Differences



### Reentrancy

An EVM external call can call back into a contract already on the stack; see [Solidity external calls](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls).

Project Thruput rejects invocation of a contract already on the call stack. For A → B → A, the last call is rejected as reentrant. This runtime check is separate from snapshot isolation. Reads within a transaction can still observe its own earlier changes and successful child calls.

Use [recoverable calls](pages/contracts/cross-contract-calls.md#error-handling) when the parent should inspect a child failure rather than propagate it.



### Ordering and MEV

Compatible arithmetic changes have the same merged value regardless of execution order. Conflicting operations do not all land together, and the proposer still selects transactions and conflict winners. This is not a guarantee that every application is free from ordering-dependent outcomes or MEV.



### Gas Limits and Gas Price Estimation

Ethereum transactions specify gas limits and fee parameters. Project Thruput gas meters execution but costs zero tokens, so no gas price estimation is needed. Gas usage still matters: the declared root limit consumes scheduling capacity, and exceeding it faults execution.

Unlocked native-token balances provide capacity; stored data requires separate deposits. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).



### Nonce Management

Ethereum account transactions use a sequential nonce. Project Thruput replay protection uses an expiry-height and nonce pair, unique for the originating address. It need not increase sequentially. That permits independent transactions from one address without a sequential account counter.



### Integer Overflow/Underflow

`Balance` accepts nonnegative amounts. Its checked methods reject underflow or overflow during execution; lazy methods defer snapshot-bound checks to reservation. The runtime also enforces aggregate bounds across concurrent transactions.



### The `approve()` Race Condition

An absolute allowance replacement can grant new spending authority after the previous allowance has already been spent. The example Project Thruput token instead uses relative allowance adjustments. The caller requests an increase or decrease, not a replacement amount.

This does not remove the need to inspect outcomes or choose an authorization policy. See the [token implementation](pages/guides/build-a-token.md#apply-supply-and-allowance-policy) for its exact allowance methods and exclusive-update option.



## Pattern Adaptations



### Balance Transfer

In a token implementation, use balance deltas:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution. The lazy credit skips a balance load and defers its bound check. Other changes and resource limits still determine whether complete transactions can land together.



### Access Control

Store an owner or role policy and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Define `Error` with `#[contract_exception]`. A forwarding contract becomes the immediate caller; it does not inherit the original user’s identity. See [Authorization](pages/how-it-works/authorization.md).



### Constructor and Initialization

Project Thruput does not invoke `initialize` automatically or make it once-only. Guard initialization in contract storage when required. The CLI’s [atomic initialization](pages/cli/deploy-and-call.md#include-initialization) combines funding, deployment, and the initializer call.



### Events

Define events with `#[derive(Event)]`, mark filterable fields with `#[topic]`, and declare emitted types on the contract interface. See [Events](pages/contracts/events.md) for the complete pattern and [Read events](pages/typescript/events.md) for application queries.

[Build a token](pages/guides/build-a-token.md) walks through the maintained ERC-20 implementation, including allowances, supply policy, events, and tests.



## What Doesn’t Exist

| EVM feature                               | Project Thruput approach                                    |
| ----------------------------------------- | ----------------------------------------------------------- |
| `msg.value`                               | Transfer tokens explicitly through their contract interface |
| `delegatecall` and proxy code replacement | Deploy a new immutable contract at a new address            |
| `selfdestruct`                            | No equivalent contract-removal operation                    |
| Solidity `receive` / `fallback` dispatch  | Use declared methods in the generated SDK dispatcher        |
| Storage-slot packing                      | Use typed storage paths                                     |

Block context and gas inspection do exist: `get_block_timepoint()`, `get_block_height()`, and `stats::gas_remaining()`. Artifact and transaction bounds are network constraints, not EVM limits; see [Contract artifacts](pages/how-it-works/contracts.md).



## Next Steps

- [Contract quickstart](pages/get-started/contract.md): build and deploy a counter
- [Build a token](pages/guides/build-a-token.md): maintained token code and tests
- [Contract Execution](pages/programming-model/execution.md): snapshots and deltas
- [Storage Types](pages/programming-model/storage-types.md): choose a storage API

---

## Solana & Anchor

Source: <https://thruput.network/docs/ecosystem/solana/>

Translate Solana account, storage, and CPI patterns into Project Thruput contracts.

Both ecosystems support Rust contract development. Project Thruput changes how a contract addresses state and how concurrent writes combine. The comparison below follows Solana’s [account model](https://solana.com/docs/core/accounts) and [CPI rules](https://solana.com/docs/core/cpi).



## Accounts vs. Storage

Solana state lives in accounts with an address, owner, lamport balance, and data. Instructions receive declared accounts; Anchor expresses their expected types and constraints.

Project Thruput stores typed fields under contract addresses. For example, a token implementation uses `Map<ContractAddress, Balance>` rather than receiving separate token-account objects for each balance. Contract code still checks caller authority and application rules.



## Access Lists vs. Type-Based Parallelism

Solana transactions declare account access before execution. The runtime uses read/write access to schedule work; transactions that contend for a writable account cannot execute together in that schedule.

Project Thruput discovers storage access during execution. Typed merge rules allow compatible changes to the same location to combine. Different map keys use separate locations, but other shared writes and storage-funding limits can still conflict.



## The Contract Lifecycle



### Writing

| Anchor concept                    | Project Thruput SDK concept                                                  |
| --------------------------------- | ---------------------------------------------------------------------------- |
| `#[program]`                      | `#[contract]` on an interface or implementation                              |
| Account-data structure            | Typed fields under `#[thruput_sdk::storage]`                                 |
| `#[derive(Accounts)]` constraints | Explicit argument and authorization checks; no caller-supplied account array |
| Initialization instruction        | Ordinary initializer, optionally called atomically with deployment           |



### Compiling

Solana programs compile to SBF. Project Thruput contracts compile to RV32 through:

```bash
thruput build
```

The build produces a deployable artifact and contract spec. Keep the generated toolchain and dependencies together.



### Deploying

Project Thruput deployment derives an address from the deployer, nonce, and code hash. This shares a PDA’s predictability, not its derivation or authorization model. See [Contract artifacts and addresses](pages/how-it-works/contracts.md).



### Calling

Use a generated client for another contract:

```rust
let token = ERC20Client::new(&token_address);
token.transfer(&recipient, amount);
```

The receiver sees the calling contract as its immediate caller. [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) covers gas limits and recoverable errors.



## Mental Model Shifts

| Solana / Anchor pattern              | Project Thruput pattern                                          |
| ------------------------------------ | ---------------------------------------------------------------- |
| Per-user state account               | Often a `Map` entry under the contract                           |
| Serialized account data              | Typed storage handles                                            |
| Account-level write conflicts        | Storage-type merge rules, including compatible shared-key deltas |
| Rent-exempt storage balance          | Storage deposit backed by native tokens                          |
| Compute-unit budget                  | Gas limit, with no token fee for gas                             |
| Signer privileges passed through CPI | Immediate caller identity and explicit runtime auth tokens       |



## Account and Call Patterns



### Account Arrays and Validation

Project Thruput has no caller-supplied account array. That removes account-list construction, not authorization. Validate caller identities, contract addresses, amounts, and application conditions before applying changes.



### Rent and Account Lifecycle

Solana accounts hold a refundable minimum lamport balance for their storage. Project Thruput storage also requires funding: it locks native tokens according to the data’s type and size, and releases the deposit when data is deleted. The runtime accounts for it, but the owning address must have enough funds.



### Compute Unit Budgets

Project Thruput gas limits bound computation, including child calls. Gas costs zero tokens, but a root transaction’s declared limit consumes scheduling capacity. Account funding and execution bounds still matter. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).



### PDA Seed Management

A PDA used only for per-user state often maps to a `Map` entry. A PDA used as an authority needs an authorization design as well; replacing its storage with a map does not reproduce its signing role.



### Signer Propagation in CPIs

Solana CPI passes existing signer and writable privileges to the callee. `invoke_signed` additionally supplies seeds when the calling program must authorize a PDA. Ordinary CPI does not always require signer seeds.

Project Thruput’s `get_caller()` returns the immediate calling contract, not the root signer. Use contract policy, allowances, or [typed auth tokens](pages/how-it-works/authorization.md#auth-tokens-and-signedt) when authority must pass through several calls.



## Pattern Adaptations



### PDA State Accounts → Map Fields

```rust
#[thruput_sdk::storage]
pub struct Registry {
    user_states: Map<ContractAddress, Value<UserState>>,
}
```

`UserState` is your serializable application type. Access an entry with `at` or `at_mut`; first writes create storage and require its deposit. See [Storage Types](pages/programming-model/storage-types.md).



### Token Transfer

Inside a token implementation:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

This updates the token’s own balance map. To transfer another contract’s token, call its generated client rather than writing its storage directly.



### Cross-Program Invocation → Cross-Contract Call

```rust
let token = ERC20Client::new(&token_address);
let result = token.try_mint(&recipient, amount);
```

The callee applies its own authorization policy. `try_mint` returns a `Result`; the direct `mint` method propagates failure. See [Handle errors](pages/contracts/errors.md).



### Error Handling

Define errors with `#[contract_exception]` and check conditions with `ensure`:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Unlike signer-account validation, this checks the immediate contract caller. A failure aborts the frame and discards its contract effects.



## What Doesn’t Exist

Project Thruput does not use Solana account arrays, associated token accounts, PDA bump seeds, or account `space`/`realloc` arguments. It has its own contract-address, storage, and authorization models. These are pattern translations, not wire or tooling compatibility.



## Next Steps

- [Contract quickstart](pages/get-started/contract.md): build and deploy a counter
- [Build a token](pages/guides/build-a-token.md): token state and tests
- [Storage Types](pages/programming-model/storage-types.md): map and balance APIs
- [Authorization](pages/how-it-works/authorization.md): caller and auth-token rules

---

## Stellar & Soroban

Source: <https://thruput.network/docs/ecosystem/stellar/>

Translate Stellar operations and Soroban contract patterns into Project Thruput applications.



## Who This Guide Is For

For Stellar developers, distinguish classic operations from Soroban contracts before comparing either with Project Thruput. Project Thruput exposes contract calls and typed storage; payment, trust, and exchange policy belongs in contracts.



## Mental Model Shifts

| Starting point                        | Project Thruput approach                              |
| ------------------------------------- | ----------------------------------------------------- |
| Classic payments and token operations | Call a token contract                                 |
| Account trustlines and asset policy   | Implement or select a contract’s authorization policy |
| Multiple classic operations           | Compose calls in one transaction                      |
| Built-in offers and path payments     | Use an application-defined exchange                   |
| Soroban storage get/set               | Choose typed storage operations and their merge rules |

These are design translations, not compatibility claims. Project Thruput does not automatically provide Stellar’s asset or trustline semantics.



## Pattern Translations



### 1. Simple Payments

Classic Stellar provides a payment operation. A Project Thruput token implementation updates typed balances:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution; the lazy credit records a relative change. Compatible transactions can merge if aggregate bounds and their other changes permit it. See [Build a token](pages/guides/build-a-token.md) for the complete implementation and events.

Thruput tokens use native contract interfaces. The SDK’s `thruput-sep41` client adapter provides familiar token operations over supported ERC20 interfaces. It uses Thruput caller authorization, native events, and Thruput block heights for approval expiry. See [Rust API Docs](pages/tools/rust-api-docs.md) for exact signatures and the [adapter’s API comments](https://github.com/thruputchain/thruput-sdk-rs/blob/main/standard-impls/thruput-sep41/src/lib.rs) for its requirements and differences.

The adapter does not provide Soroban ABI compatibility. Moving assets between Stellar and Thruput through a bridge is a separate integration. Each bridge defines its supported assets and transfer guarantees.



### 2. Multi-Operation Transactions

[Classic Stellar transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions) can bundle operations atomically. Soroban transactions contain a single smart-contract operation, which can invoke other contracts.

A Project Thruput transaction has one root invocation. That invocation can call several contracts. The native DefaultWallet and its SDK helpers also support [atomic typed call batches](pages/typescript/transactions.md#execute-multiple-calls).

If the root aborts, its contract changes and successful child changes are discarded. A parent using recoverable calls can instead handle a child’s failure and continue. See [Invocation Frames](pages/how-it-works/invocation-frames.md).



### 3. Market Making / Resting Orders

Project Thruput has no built-in order book. A contract can store orders by ID in a `Map`, or accept requests through a `RetrocausalQueue`.

Separate order IDs have independent storage locations. Changes to the same order follow its value type’s merge rules. A queue allows concurrent insertion and later ordered processing. Choose according to the venue’s matching and settlement rules.



### 4. DEX Trading / Swaps

Two designs are possible:

- **Synchronous calls:** execute a swap and return its result in one transaction. Reserve-dependent writes to the same pair can conflict.
- **Queued requests:** accept a request first, then process it in a later transaction. The client tracks a request ID through outcome events or stored state.

The maintained [AMM example](pages/guides/build-an-amm.md) uses the queued design. Request acceptance is not proof that the swap completed. A synchronous result refers to execution within a transaction, not immediate network confirmation.



### 5. Account & Trust Management

A Project Thruput contract can store per-account policy in a map, but a stored trust flag has no effect unless the token or application checks it.

Use [caller checks and auth tokens](pages/how-it-works/authorization.md) to enforce the policy. Use [account authorization](pages/typescript/wallet-clients.md) for signatures that can originate transactions. These are separate responsibilities.



### 6. Soroban Smart Contracts

Both environments support Rust contracts, with different storage and authorization APIs:

| Soroban                                     | Project Thruput                                                                           |
| ------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `persistent().get/set`                      | Typed handles such as `Value<T>`, `Map<K, V>`, and `Balance`                              |
| Instance, Persistent, and Temporary storage | One persistent storage model with type-specific operations                                |
| Storage TTL and archival/restoration        | No storage TTL; funded data remains until deleted                                         |
| `require_auth()`                            | Immediate-caller checks or explicit runtime auth tokens, according to the contract policy |
| `#[contractimpl]`                           | `#[contract]` on a Rust interface or implementation                                       |
| Inclusion and resource fees                 | No conventional gas fees; native-token-backed scheduling and storage                      |

Soroban TTL expiry is not the same for every storage type: Temporary data is deleted, while Persistent and Instance entries are archived and can be restored. See [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival).

Project Thruput’s storage types determine which concurrent changes can combine. Use [Contract Execution](pages/programming-model/execution.md) for snapshots and [Storage Types](pages/programming-model/storage-types.md) for API choices.



## Pattern Summary

| Pattern                 | Design decision                                                         |
| ----------------------- | ----------------------------------------------------------------------- |
| Payments                | Select the token contract and its transfer policy                       |
| Resting orders          | Choose keyed storage, a queue, or both                                  |
| Trust and authorization | Store policy and enforce it on every relevant action                    |
| Swaps                   | Choose synchronous execution or accepted requests with later settlement |
| Client recovery         | Track transaction hashes and, for queued work, request outcomes         |



## What Doesn’t Change

Applications still need to validate amounts, choose the intended network, authorize writes, and inspect outcomes. A successful submission is not successful execution on either platform.



## Common Questions



### Q: Do I lose atomicity for multi-op transactions?

No. Calls can execute atomically inside one root transaction. A workflow split across several transactions, such as queue acceptance and later settlement, needs application-level outcome tracking.



### Q: When should I use a queued DEX model?

Use it when concurrent request submission and later processing fit the venue. Use a synchronous call when the caller needs the swap result during the same transaction.



### Q: Will my market making bot need major changes?

The venue determines that. A queued venue requires the bot to connect accepted request IDs with later outcomes. It must not treat a successful processing transaction as proof that every queued request succeeded.



## References

- [Stellar operations and transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions)
- [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival)
- [Contract quickstart](pages/get-started/contract.md)
- [Build a token](pages/guides/build-a-token.md)
- [Build an AMM](pages/guides/build-an-amm.md)

---

## For Backend Developers

Source: <https://thruput.network/docs/start/for-backend-developers/>

Map your Postgres and database experience to Project Thruput's programming model.

Database snapshot isolation is a useful starting point for Project Thruput. Transactions share a committed block snapshot, but their writes follow typed storage merge rules rather than SQL conflict rules.



## Shared Snapshot

Every transaction in a block starts from the previous block’s committed state. Ordinary storage reads include its own changes and successful child calls, but not other transactions’ writes. `RetrocausalQueue` has separate rules for observing concurrent inserts. Each transaction produces typed changes, called **deltas**. Compatible deltas form the next committed state. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas).



## Deltas, Not Assignments

The core shift from a database: instead of `UPDATE accounts SET balance = 50`, you call `increase(5)`, meaning “adjust this value by +5.” This is `UPDATE accounts SET balance = balance + 5`. You express **how the value should change**, not what it should become.

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);          // checked debit
    self.balances.at_mut(receiver).lazy_increase(amount);    // deferred bound check
}
```

[`Balance`](pages/programming-model/storage-types.md#balance) is the SDK type for this pattern. Both calls record deltas that can merge with concurrent transactions. `decrease()` loads the sender’s balance so an insufficient debit fails during execution. `lazy_increase()` skips the receiver load and defers its bound check until the delta batch is reserved. If two transactions debit 20 and 30 from a balance of 100, both can land and the next balance is 50. Applying the changes in either order gives the same result, so the operations **commute**.

[NNInt and concurrent updates](pages/programming-model/nnint.md) explains the representation behind these balance operations, including base matching and early bound checks.

**Relative updates such as `SET col = col + ?` map naturally to mergeable integer operations.** Compatibility still depends on bounds and the transaction’s other changes. Absolute replacements can conflict when they assign different values.

***



## Conflicts and Retries

When deltas conflict, that attempt is excluded from the proposal. Contract code does not retry the operation. The scheduler can requeue transactions after a nomination is rolled back or a different proposal commits, but exclusion does not guarantee automatic requeue or a `retry` status. Clients observe the original transaction and, when retrying is appropriate, resubmit the same signed bytes while valid. Replay protection permits at most one commitment. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission).

The balance constraint works the same way. If two concurrent withdrawals together exceed the available balance, one or more transactions are excluded. This is `CHECK (balance >= 0)` enforced by the storage model rather than application code.

***



## What’s Different From a Database

- **No ad-hoc queries.** Storage is key-value with typed values. You access data by key, not by query. An indexer provides query capabilities off-chain.
- **No JOINs.** If you need data from two Maps, you read both explicitly.
- **Deterministic execution.** Use block context rather than the host clock. Contract code cannot make HTTP calls or use the host’s random-number generator.
- **Storage deposits.** Stored data locks native tokens according to its type and size. Deleting the data returns the deposit.
- **No conventional gas fees.** Gas meters computation (prevents infinite loops) but no tokens are burned. Your unlocked native-token balance provides scheduling capacity under load. The declared gas limit determines how much capacity the transaction uses.

***



## Next Steps

For storage type details (`Balance`, `NNInt`, `Map`, `Vector`, `Value`, `Bytestring`, `CapacityConstraint`, and `RetrocausalQueue`) and their conflict semantics, see [Programming Model: Storage Types](pages/programming-model/storage-types.md). For the contract-level execution model, see [Merged Deltas](pages/programming-model/execution.md#merged-deltas).

Ready to write code? The [contract quickstart](pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## For Distributed Systems Developers

Source: <https://thruput.network/docs/start/for-distributed-systems-developers/>

Understand Project Thruput's use of commutative updates within consensus blocks.

Project Thruput uses commutative operations to combine concurrent changes within a block. The storage model supports parallel execution; consensus selects the result validators commit.



## Your Head Start

Additions such as `+5` and `+3` have the same sum in either order. Project Thruput’s [`Balance`](pages/programming-model/storage-types.md#balance) and [`NNInt`](pages/programming-model/nnint.md) expose relative updates with explicit bounds. `Map<K, V>` gives separate keys independent storage locations.

The similarity to counters and maps in CRDT systems is useful, but the coordination model differs.



## Coordination at Block Boundaries

CRDTs can reconcile independently updated replicas. Project Thruput instead executes transactions against a common committed snapshot, reserves compatible typed changes, and uses [consensus](pages/how-it-works/consensus.md) to select a finalized block.

- **Merge rules operate within a proposal.** Applications do not maintain vector clocks to reconcile ordinary balance or map updates.
- **Bounds still apply.** A balance cannot commit below zero. If concurrent debits exceed the available value, an overdrawing attempt is excluded from the proposal. Requeue and reported status depend on later processing. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission).
- **Consensus selects one result.** Validators verify the proposed state transition. Nodes that have applied the same finalized block agree on that state.
- **Readers can see different heights.** A node may lag while receiving or replaying blocks. Check the returned read height when freshness matters.



## If You Don’t Know Any of This

You can write contracts without implementing a concurrency algorithm. Choose the storage type for the updates your application needs, then use its ordinary Rust methods. The [backend-developer guide](pages/start/for-backend-developers.md) explains the same model through database concepts.



## Next Steps

- [Contract Execution](pages/programming-model/execution.md): snapshots, deltas, and exclusion
- [Storage Types](pages/programming-model/storage-types.md): data-model choices
- [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved): engine reservation details
- [Contract quickstart](pages/get-started/contract.md): build and deploy a counter

---

## Project Thruput roadmap

Source: <https://thruput.network/docs/architecture/roadmap/>

Candidate improvements, open questions, and ways to help shape Project Thruput.

These are candidate improvements to Project Thruput, roughly ordered by what they could unblock. The order is provisional. Scope and priorities can change as people build on Futurenet; there are no committed delivery dates.

Last reviewed: October 21, 2026.



## Proposed next work



### Block and transaction history

Recoverable transaction feeds would let explorers and independent indexers discover chain activity without private infrastructure access. Public block queries are available: `getBlockByHeight` reads committed block metadata, and `getTransactionsByBlock` pages a block’s transactions. The supported feed and its recovery contract still need qualification. Indexer requirements and tests for resuming after an outage would help.



### Contract failure diagnostics

Failures inside wallet or other nested contract calls can be difficult to locate. The goal is to preserve which call failed and provide more useful runtime fault details through the [public API](pages/reference/json-rpc-api.md). Small contracts that reproduce difficult failures are useful contributions.



### State preserving upgrades

Supported upgrade paths and migration tooling would reduce the need to recreate applications after network changes. This work is deferred. Futurenet can still reset, as described in [Get Started](pages/get-started.md). Upgrade fixtures, compatibility tests, and operator feedback would help define the supported paths.



### Sharded state storage

Partitioning state across multiple HogDB shards within each validator is the planned path for scaling state. This is not chain sharding: applications see one key space and never choose a shard. Each account’s state is owned by one shard, and execution routes reads and writes to the owning shard. Initial support is in review in the core engine. Cross-shard snapshot reads, protocol support for shard identity, and a two-phase block commit across shards still need to land. Large-state workloads and benchmarks across shard counts would help.



### Post-quantum signatures

Each address can register multiple keys, and authorization is abstracted over the signature scheme, so users can add or revoke keys without changing addresses. Ed25519 and ML-DSA-65 (FIPS 204) are supported. Validator key migration still needs design, and more schemes may follow as they are standardized. Threat-model, performance, and migration-design reviews would help.



## Exploring



### External calls

Contracts could call services outside the chain within one atomic transaction. While a call is pending, executors run other transactions. The proposer records the response in the block proposal, so other nodes replay it without making the call. Responses must be self-authenticating, and each call’s timeout is bounded by block time. This is not implemented. The contract API and protections against using the chain to flood other services still need design. Use cases such as market-maker quotes, on-demand oracle reads, and compliance checks would help shape it.



## Open to builders



### Additional storage types

Contracts use the [storage types](pages/programming-model/storage-types.md) the SDK provides today. Earlier research prototypes also used ordered sets and bitmaps, and new types will follow developer demand. If an application is hard to express with the current types, describe the workload and where it conflicts.



### Ecosystem tooling

Wallet integrations, oracles, and application conventions are areas where builder demand can shape the work. The [wallet integration guide](pages/tools/wallet-integration.md) is a starting point. Bring an integration or application that exposes a concrete need, and find related projects through the [GitHub community](https://github.com/thruputchain).

---

## CLI

Source: <https://thruput.network/docs/cli/>

Install the Thruput CLI, configure networks, and build, test, deploy, and call contracts.

`thruput` is the command-line tool for working with Project Thruput projects and networks. Use it to create a project, build and test a contract, run a local node, or interact with a deployed contract.



## Projects and networks

The CLI works with two kinds of configuration:

- A **project** contains your Rust contract, tests, and build settings.
- A **profile** selects the network and identity used for an interaction.

This lets you build a contract once and use profiles to target a local node or Futurenet. You can also use network commands without creating a contract project.



## The development loop

| Task                        | Command          |
| --------------------------- | ---------------- |
| Create a contract project   | `thruput new`    |
| Build a contract artifact   | `thruput build`  |
| Run contract artifact tests | `thruput test`   |
| Start a local node          | `thruput node`   |
| Deploy a contract           | `thruput deploy` |
| Call a deployed contract    | `thruput call`   |

These are command names, not a setup script. Start with [installation](pages/cli/install.md), then follow the [CLI quickstart](pages/get-started/cli.md) for a first Futurenet interaction.

The [contract quickstart](pages/get-started/contract.md) adds deployment and calls. Use [Run a local node](pages/cli/local-node.md) when you want a disposable node on your machine.



## Look up an option

Run `thruput <command> --help` for the installed version’s options, or use the [command reference](pages/cli/reference.md). [Profiles and networks](pages/cli/configuration.md) explains profile selection and project overrides.

Use [Skills and local docs](pages/cli/agent-tools.md) to install agent guidance, read bundled references, and serve or export documentation. [Build with an Agent](pages/start/build-with-an-agent.md) combines setup with a first-project prompt.

---

## Install the CLI

Source: <https://thruput.network/docs/cli/install/>

Install the latest Thruput CLI and prepare Cargo access for contract development.

Install the latest `thruput` release. The CLI selects the dependencies and compiler settings for projects it creates; you do not need to choose SDK or node versions.



## Before you start

- Install Rust with [rustup](https://rustup.rs/). Each project pins its own toolchain in `rust-toolchain.toml`: a nightly with the RV32 target and `rust-src`. Run `thruput status` in the project; it reports a missing toolchain or component and prints the `rustup` command that installs it.
- Obtain access to the Project Thruput Cargo registry from your onboarding contact. Repository access alone does not grant package access.

Check that Cargo is available:

```bash
cargo --version
```



## Configure Cargo access

Set the registry address and credential provider in your shell:

```bash
export CARGO_REGISTRIES_THRUPUT_INDEX="sparse+https://crates.thruput.network/api/v1/crates/"
export CARGO_REGISTRIES_THRUPUT_CREDENTIAL_PROVIDER=cargo:token
```

Supply `CARGO_REGISTRIES_THRUPUT_TOKEN` through your credential manager or onboarding environment. Keep the token out of project files and agent prompts. If you already use a Cargo credential manager for this registry, keep its provider instead.

Use the same registry access in terminals where you build contracts. The generated project includes the registry address, but it does not include your credentials.



## Install with Cargo

```bash
cargo install thruput-cli --registry thruput --locked
thruput --version
```

The first command installs the latest CLI with its release’s dependency lockfile. The second should print the installed CLI version.

Cargo installs executables in `~/.cargo/bin`. If `thruput` is not found, add that directory to your shell’s `PATH` and open a new terminal.



## Set up the local runtime

Local nodes and RPC integration tests use `hog-devnode`. The CLI selects a compatible runtime from its bundled catalog and can download it when needed. To inspect available versions and install the selected runtime in advance:

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

`list` shows the runtime catalog and installed versions. `install` downloads and verifies the selected runtime bundle. `which` shows the selected binary’s path.

On Linux, a local node requires the system jemalloc and Snappy libraries. If an error names `libjemalloc.so.2` or `libsnappy.so.1`, install your distribution’s corresponding packages (`libjemalloc2` and `libsnappy1v5` on Ubuntu).

These commands manage the local-node runtime. Rust is managed through `rustup`, and the CLI is installed separately as shown above. You do not need a local node to use Futurenet.

See [runtime selection](pages/cli/local-node.md#runtime-selection) for version and binary overrides.



## Update an existing installation

Run the same `cargo install` command to install the latest release. Keep the `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml` generated for each project rather than replacing them with files from another example.

If an older executable is still selected, check its location:

```bash
command -v thruput
thruput --version
```

---

## Profiles and networks

Source: <https://thruput.network/docs/cli/configuration/>

Select Futurenet, local development, or a custom endpoint and manage global and project configuration.

A profile selects the network, endpoint, and account settings for a command. Global profiles are reusable across projects; a project’s `thruput.toml` can override them.



## Inspect the current settings

```bash
thruput config profiles
thruput config get futurenet --sources
thruput status --profile futurenet
```

`config get` shows persisted configuration and where it came from. `status` adds environment diagnostics, including the effective key and local-runtime selection. Neither command requests funds or deploys a contract.



## Choose a profile

For one command:

```bash
thruput balance --profile futurenet
```

To make Futurenet your global default, including in new projects:

```bash
thruput config use futurenet --global
```

New project templates omit `default_profile`. Existing projects can still have a project default that overrides the global selection. To select Futurenet for one project:

```bash
thruput config use futurenet --project
```

Profile selection checks, in order:

1. `--profile`
2. `THRUPUT_PROFILE`
3. Project `default_profile`
4. Global `default_profile`

If none selects a profile, network commands fail. Offline builds and tests can use a scaffold’s local overlay without a selected default. The name `default` has no special fallback meaning.



## Futurenet

`thruput init` creates `local` and `futurenet`, with `local` as the initial default. Futurenet uses `https://rpc.thruput.network` and `https://faucet.thruput.network`. Initialization preserves existing defaults and custom profile fields. For a first funded account, follow the [CLI quickstart](pages/get-started/cli.md).

The CLI validates the selected network before signing. An explicit `network-hash` pins the network identity. Without a pin, hosted native-account operations use the configured network descriptor and RPC identity. Do not copy a hash from a different deployment; a Futurenet reset can change the identity.

`network = "devnet"` remains a compatibility alias for the hosted network. Existing Devnet profiles and saved wallets keep their names and settings. New installations create only the `futurenet` hosted profile. To add it to an older installation, rerun `thruput init`, then select it with `thruput config use futurenet --global`. Profile names are distinct; the network alias does not copy wallets or contract aliases between profiles. Older CLIs do not recognize `network = "futurenet"` and can fail to update a global config containing it. Upgrade those CLIs or keep their configuration separate.

`config new --network futurenet` stores only the supplied fields. A project overlay inherits omitted endpoints from the same-named global profile.



## Local development

Profiles with `network = "local"` can use the endpoint and runtime manifest recorded by a running `thruput node`. See [Run a local node](pages/cli/local-node.md).

For a one-off endpoint override on an RPC command:

```bash
thruput balance --profile local --rpc-url http://127.0.0.1:9546
```

Local airdrops also need that node’s runtime manifest, which identifies the node’s faucet. Use `--runtime-manifest PATH` when automatic discovery does not apply.



## Global settings and project overrides

| Layer   | Location                        | Purpose                                                   |
| ------- | ------------------------------- | --------------------------------------------------------- |
| Global  | `~/.config/thruput/config.toml` | Shared profiles, key defaults, and wallet bindings        |
| Project | Nearest ancestor `thruput.toml` | Project defaults, profile overrides, and contract aliases |

`XDG_CONFIG_HOME` changes the global configuration root. Same-named profiles merge field by field; project values win. Contract aliases and wallet bindings merge by name.

Inside a project, choose `--global` or `--project` when changing configuration. Outside a project, omitted scope means global.

```bash
thruput config set default-key alice --profile futurenet --project
thruput config unset default-key --profile futurenet --project
```

The second command removes the project override and reveals any inherited value. The editable fields are `network`, `rpc-url`, `network-hash`, `faucet-url`, and `default-key`. Use [wallet commands](pages/cli/wallets.md) to select wallets and deployment commands to create contract aliases.



## Add another endpoint

Replace the example URLs with the RPC and faucet for the same deployment:

```bash
thruput config new staging --network futurenet \
  --rpc-url https://rpc.example.com \
  --faucet-url https://faucet.example.com \
  --global
```

Use `config new` to create a profile in a layer before changing its fields there. `config rm staging --global` removes that layer’s profile, including its saved aliases and wallet bindings. It does not delete onchain state.

---

## Keys and wallets

Source: <https://thruput.network/docs/cli/wallets/>

Create signing keys, save native wallet bindings, select an account, and request test funds.

A **key** signs transactions. A **wallet binding** gives an account address a reusable name within a profile. Keys are global; bindings can be global or project-local.

For first-time setup, the [CLI quickstart](pages/get-started/cli.md) creates and funds a Futurenet account. This page covers account management after that setup.



## Create a key and wallet

```bash
thruput keys generate alice
thruput wallet create --key alice --profile futurenet
```

Confirm wallet creation. The CLI derives a native account and saves its address, owner, and account nonce. It does not deploy a wallet contract or request funds.

An ordinary stored key can also use its native account without a saved binding. Saving a binding is useful when you want a name for selection and inspection. Existing legacy wallet bindings keep their original account identity and transaction format.



### ML-DSA-65 keys

ML-DSA-65 keys require CLI `0.30.0` or later. Check with `thruput --version`.

```bash
thruput keys generate carol --scheme mldsa65
thruput airdrop carol --profile futurenet
```

An ML-DSA-65 key always uses its native account. `balance`, `transfer`, `tx`, and `call` work the same way as with Ed25519 keys. These commands are Ed25519 only:

- `wallet create` does not accept ML-DSA-65 keys.
- `keys import` accepts Ed25519 seeds only.
- `keys export --format strkey` does not apply, because ML-DSA-65 keys have no StrKey form.
- `init --generate-key` creates an Ed25519 key.



## Inspect accounts

```bash
thruput keys ls
thruput wallet ls --profile futurenet
thruput status --profile futurenet
```

Keys live under `${XDG_CONFIG_HOME:-$HOME/.config}/thruput/keys/`. Wallet bindings live in the selected configuration layer. Wallet mutations inside a project update its overlay; outside a project they update global configuration.

Address inputs accept base58 or a checksummed Thruput `Z` StrKey for native wallets and deployed contracts. Stellar C addresses are rejected. Z does not distinguish local, test, and production networks; select the intended profile. Reports and saved public configuration use base58. G public keys identify Ed25519 signers, not Thruput wallet addresses; S seeds remain valid for explicit key import.



## Select an account

```bash
thruput keys use alice
thruput wallet use alice --profile futurenet
thruput balance alice --profile futurenet
```

A profile’s `default-key` can override the global key. Inspect it with `thruput config get futurenet --sources`. Selecting a key does not replace an explicitly selected wallet belonging to another key; the CLI checks ownership rather than silently switching accounts.

For one deployment or call, use `--wallet NAME`. When targets are omitted from `balance`, `airdrop`, or `tx list`, the CLI resolves the effective account from the selected profile and key.



## Fund and transfer

```bash
thruput airdrop alice --profile futurenet
thruput balance alice --profile futurenet
```

The hosted faucet selects the amount. Local-node requests can use `--amount`:

```bash
thruput airdrop alice --profile local --amount 25
```

To transfer native tokens to another saved wallet or an address:

```bash
thruput transfer RECIPIENT 1 --profile futurenet
```

Replace `RECIPIENT` with the destination. Confirm the transaction and inspect its result. A new recipient needs a sufficient first credit to cover its balance storage; funding amounts depend on the network. See [Faucet](pages/tools/faucet.md) and [storage costs](pages/how-it-works/storage-economics.md).



## Remove local records

`thruput wallet rm alice --profile futurenet` removes the saved binding, not the onchain account. `thruput keys rm alice` removes the local signing key and asks for confirmation. Keep a key if you still need it to control an account.

`thruput keys export NAME` prints private key material. Use it only for an intended export, not as a diagnostic or a way to put a signer into browser code.

---

## Create a project

Source: <https://thruput.network/docs/cli/create-project/>

Create a contract project and keep its generated compiler, build, and test configuration together.

Use `thruput new` to create a Rust contract project. If this is your first setup, [install the CLI](pages/cli/install.md) and run `thruput init` first.



## Choose a template

```bash
thruput new my-counter --template counter
cd my-counter
```

The explicit `counter` template includes counter methods, an event, an error, and tests. Without `--template`, the CLI creates a minimal contract:

```bash
thruput new my-contract
```

The minimal project and named templates include the files needed for native tests, RV32 builds, and integration tests. Keep the generated `Cargo.toml`, `rust-toolchain.toml`, and `.cargo/` configuration together. You do not need to select SDK or compiler versions yourself.

Discover named templates and their prerequisites without network access:

```bash
thruput templates list
thruput templates show counter-app
```

`counter-app` adds a local React application, generated bindings, and a temporary browser wallet. It separates contract deployment (`npm run contract:deploy`) from frontend startup (`npm run dev`). Use [Build a counter](pages/tutorials/build-a-counter.md) to build the application step by step instead.

Run `thruput new` without a name for interactive setup, or pass `--path PATH` to select a destination. The destination must be new or empty.



## Find the code

- `src/implementation.rs`: contract logic and storage.
- `tests/test.rs`: native logic tests.
- `tests/test_rv32.rs`: artifact tests.
- `tests/integration.rs`: RPC integration test entry point.
- `thruput.toml`: project profiles and deployment aliases.

See [Project structure](pages/contracts/project-structure.md) for the complete layout and generated artifacts.



## Select a network

New projects omit `default_profile` and follow your global selection. After `thruput config use futurenet --global`, new projects use Futurenet. Inspect the selected profile before deploying:

```bash
thruput config get --sources
```

Use `thruput config use futurenet --project` to set a project override, or `--profile futurenet` for one command. Builds and native/artifact tests run on your machine regardless of the profile. See [Profiles and networks](pages/cli/configuration.md).



## Work in a Cargo workspace

Keep shared `thruput.toml`, `.cargo/`, and `rust-toolchain.toml` files at the workspace root. Select a package when building from that root:

```bash
thruput build -p my-counter
thruput test -p my-counter
```

---

## Build and test

Source: <https://thruput.network/docs/cli/build-and-test/>

Build RV32 artifacts and choose native, artifact, or RPC integration tests.

Run these commands inside a [CLI-generated project](pages/cli/create-project.md) with [Cargo access](pages/cli/install.md#configure-cargo-access) configured.



## Build a deployable artifact

```bash
thruput build
```

The CLI compiles for RV32 and lowers the result into `target/thruput/<package>.rv32a`. It also writes lowering metadata and contract-spec sidecars. Artifact names use the package’s snake-case name. See [Project structure](pages/contracts/project-structure.md#build-artifacts).

Plain `cargo build` targets your host. Use it for Rust tooling and IDE checks, not to produce the deployable artifact.

At a workspace root, select a package:

```bash
thruput build -p my-counter
```

Use `--show-cargo-commands` to inspect the compiler invocation. Arguments after `--` go to Cargo. Keep the scaffold’s compiler and feature configuration instead of recreating the cross-compilation command by hand.



## Choose a test boundary

| Command                      | What it exercises                                                             |
| ---------------------------- | ----------------------------------------------------------------------------- |
| `cargo test`                 | Native contract logic through the SDK test environment                        |
| `thruput test`               | The built RV32 artifact through `tests/test_rv32.rs`                          |
| `thruput test --integration` | Artifact build, disposable local node, deployment, and `tests/integration.rs` |

The first two do not require a running RPC node. Integration mode starts and stops its own node; it does not submit transactions to Futurenet.

```bash
cargo test
thruput test
```

For test code, assertions, and storage-cost setup, use [Test contracts](pages/programming-model/testing.md).



## Focus a test run

```bash
thruput test --match-test counter
thruput test --skip slow
thruput test --show-output
thruput test --no-capture --test-threads 1
```

`--match-test` and `--skip` filter test names. `--show-output` includes output from passing tests; `--no-capture` streams output as tests run.

```bash
thruput test --rerun
thruput test --watch
```

`--rerun` uses the previous failure cache. `--watch` runs immediately, then repeats after source or configuration changes. They can be combined.



## Integration and workspace runs

```bash
thruput test --integration
thruput test --workspace
```

These are separate modes. `--workspace` runs members with a `test_rv32` target in package-name order. It cannot be combined with `-p` or `--integration`. Integration mode does not support `--watch` or `--rerun`.

The CLI can acquire its selected local runtime for integration tests. See [runtime selection](pages/cli/local-node.md#runtime-selection) for explicit overrides, and [Automation](pages/cli/automation.md) for structured test reports.

---

## Run a local node

Source: <https://thruput.network/docs/cli/local-node/>

Start an isolated development chain, select its accounts, and preserve or inspect local state.

Use a local node for disposable development and RPC tests. For a first hosted deployment, follow the [Futurenet contract quickstart](pages/get-started/contract.md).



## Start the node

```bash
thruput node
```

Keep this terminal running. The CLI starts its managed `hog-devnode` and exposes JSON-RPC at `http://127.0.0.1:9545` by default. If the selected runtime is missing, the CLI can download its verified bundle.

The CLI records the active endpoint and runtime manifest so commands using a local profile can find the node.

The node funds the selected project/global key. If local and Futurenet profiles use different keys, run `THRUPUT_PROFILE=local thruput node` so startup uses the key selected by local commands. `--key NAME` explicitly selects a stored key.



## Select a local account

From another terminal in your project:

```bash
thruput status --profile local
thruput balance --profile local
```

`status` shows the effective key. On a fresh chain, the node gives that key’s account 100 native tokens. `thruput balance` then shows slightly less, because the account’s first storage deposit comes out of that allocation. Use `thruput node --initial-account-tokens AMOUNT` to change the amount. The faucet key is private to the node, and the node creates no other accounts. An ML-DSA-65 key gets no genesis allocation. To fund it, or any other key, run `thruput airdrop NAME --profile local`.

If the profile already selects a saved wallet, key selection alone does not replace that wallet. Inspect `thruput status --profile local` and [wallet selection](pages/cli/wallets.md#select-an-account) before submitting.

You can now use the normal [deployment and call commands](pages/cli/deploy-and-call.md) with `--profile local`.



## Preserve state

Without a data directory, stopping the node discards its chain state. Stored signing keys and project configuration remain, but the local deployments and balances do not.

```bash
thruput node --data-dir .thruput/node
```

Restart with the same data directory to reuse the chain. Repeat the same `--network-config` overrides, and omit `--init-network-hash`. A runtime older than `0.1.31-rc.10` created data directories that the current runtime cannot open. Use a new directory for them.

Stop the node before backing up or restoring that directory:

```bash
thruput chain dump --data-dir .thruput/node --output chain-backup.json
thruput chain restore --data-dir .thruput/node --input chain-backup.json
```

Restore asks before replacing populated state. Use `--yes` only when that replacement is intended.



## Change the endpoint or logging

```bash
thruput node --port 9546
thruput node --verbose
```

Choose logging before reproducing a problem: restarting an ephemeral node to enable it loses the old state. `RUST_LOG` provides finer control and overrides the verbose preset.

The public listener binds to loopback by default. `--host` changes that listener for container or VM access; exposing it beyond loopback exposes an unauthenticated development RPC endpoint.



## Runtime selection

The CLI selects a default from its bundled runtime catalog. See [local runtime setup](pages/cli/install.md#set-up-the-local-runtime) to inspect and install managed runtimes.

To inspect the effective configuration:

```bash
thruput status --json
```

An explicit `--hog-devnode-binary`, `THRUPUT_DEVNODE_BINARY`, or adjacent binary can take precedence over managed selection. Use `--hog-devnode-version VERSION` when intentionally selecting an exact catalog entry. `--offline` prevents managed downloads, not RPC or Cargo traffic.

If the runtime is incompatible, select matching binaries. `--hogd-protocol` changes a handshake token only; it does not make different wire formats compatible.

For isolated automated runs, prefer [integration tests](pages/cli/build-and-test.md#integration-and-workspace-runs) rather than managing a long-running node yourself.

---

## Deploy and call

Source: <https://thruput.network/docs/cli/deploy-and-call/>

Deploy an artifact, fund its storage, call methods, and read committed state.

Run these commands in a contract project with a built artifact. Deployment and calls need a funded account; estimating needs no signing key. Select the intended [profile](pages/cli/configuration.md) explicitly. The examples use Futurenet and the scaffolded counter’s methods.



## Estimate deployment funding

```bash
thruput build
thruput deploy --estimate --profile futurenet
thruput deploy --estimate --profile futurenet --json
```

The estimate reads the network’s authoritative execution rules and storage prices without signing or submitting. It checks the artifact, code, and memory limits and assumes a fresh, unfunded contract address. Unlike `--dry-run`, it does not prepare a signed transaction.

| Report field                                | Meaning                                                                                                                             |
| ------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `balanceDepositRaw`, `deploymentCostRaw`    | First balance-item deposit and code collateral, in native-token base units                                                          |
| `minimumFundingRaw`, `minimumFundingTokens` | Their sum, as an integer base-unit string and a whole-token decimal string respectively; one native token has 10,000,000 base units |
| `initializerFundingRaw`                     | `null` when an initializer is requested, because its storage is not estimated; `"0"` when none is requested                         |
| `execution`                                 | Observed committed tip, configuration hash, effective limits, and storage prices                                                    |

Missing authoritative rules or prices produce an error, not a zero-cost estimate. The reading applies at its reported configuration; prices can change before inclusion. Re-estimate after rebuilding or changing networks.

For deployment without initialization, the CLI can read and transfer the minimum directly:

```bash
thruput deploy --profile futurenet --fund minimum
```

The minimum leaves **zero free contract balance** for further storage. It excludes initializer writes, later storage growth, the sender’s replay storage, and the sender’s scheduling capacity. `--fund minimum` cannot be combined with `--init`. Use an explicit total amount when initialization or later calls need storage, as in the [counter guide](pages/tutorials/build-a-counter.md#build-deploy-and-initialize).



## Deploy an artifact

```bash
thruput build
thruput deploy --profile futurenet --fund 10
```

Confirm the deployment. Without a terminal, pass `--yes` to confirm. The CLI waits for its result, prints the deployed address, and saves an alias using the package name. For a project named `my-counter`, later commands can use that alias instead of the address.

Numeric `--fund` transfers exactly that many native tokens from the sender to the new contract. Set it to the estimated minimum plus an allowance for contract storage. `10` above illustrates the syntax; choose your total from the current estimate rather than treating it as a fixed fee or minimum.

At a workspace root, use `-p PACKAGE`. Use `--artifact PATH` to select an artifact directly and `--alias NAME` when you want a specific alias.



## Include initialization

For a new deployment that initializes the counter in the same transaction, use this instead:

```bash
thruput deploy --profile futurenet --fund 10 \
  --init initialize --init-arg 10
```

Repeat `--init-arg` for additional arguments. The initializer sees the deploying wallet as its caller. Funding, deployment, and initialization succeed together or roll back together.

Initialization is an ordinary contract method. The contract must enforce one-time initialization when its design requires it. The starter counter simply adds the supplied amount, so do not call it again after initializing this example.



## Submit a call

For a counter that has been deployed and initialized:

```bash
thruput call my-counter increment 5 --profile futurenet
```

This signs and submits a transaction. Method names and typed arguments use the contract spec. Without metadata, an explicit entrypoint and raw calldata are required; use generated metadata for normal development.

Use `--gas-limit` when the call needs a different execution budget. The sender must have the corresponding scheduling capacity; gas itself has no token fee.



## Read without submitting

```bash
thruput view my-counter get --profile futurenet
```

`view` runs a sandboxed call against committed state. It does not submit a transaction. Use `--from ADDRESS` when a read needs a simulated caller; this does not prove control of that address.

`thruput storage CONTRACT KEY` reads a raw storage item. Prefer a view when you want the contract’s typed behavior.



## Prepare without broadcasting

```bash
thruput deploy --profile futurenet --fund 10 --dry-run
thruput call my-counter increment 5 --profile futurenet --dry-run
```

A dry run prepares and signs a transaction but does not submit it. It still needs the selected key and network access. It is not a simulation of the state change and does not prove that execution will succeed.



## Inspect an uncertain result

Keep the transaction hash and original network if submission or receipt observation fails:

```bash
thruput tx show TX_HASH --profile futurenet
```

A timeout or `unknown` status does not prove that the transaction failed. Repeating a deployment creates a new nonce and predicted address. Inspect the original transaction before deciding to submit a new operation. See [Inspect transactions and events](pages/cli/transactions.md).

---

## Inspect transactions and events

Source: <https://thruput.network/docs/cli/transactions/>

Inspect receipts, address history, contract events, and token transfers from the CLI.

Use the same profile and network that received the transaction. The commands below are read-only.



## Look up one transaction

```bash
thruput tx show TX_HASH --profile futurenet
```

Replace `TX_HASH` with the submitted hash. This performs one status lookup and fetches the receipt when committed; it does not wait for a pending transaction.

Check the receipt’s execution result. A committed failure is different from a transaction that is still `pending` or was reported as `retry` or `dropped`. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).



## List history

```bash
thruput tx list my-counter --profile futurenet --limit 25
```

History is indexed by root invocation target. A wallet-wrapped call can appear under the wallet rather than the inner target contract. Use the receipt and contract events to inspect inner activity; absence from an address-history page does not prove an operation did not occur.



## Read contract events

```bash
thruput events list my-counter --profile futurenet --limit 25
```

For decoded events, supply the trusted spec from the same contract build:

```bash
thruput events list my-counter --profile futurenet \
  --spec target/thruput/my_counter.spec.xdr --event PingEvent
```

Use `--topic0`, `--topic1`, or `--topic2` for raw topic filters. Repeated values at one position mean OR; filters across positions mean AND. Use the signature from the generated spec rather than copying one from another contract.



## Inspect token transfers

```bash
thruput token transfers NATIVE_TOKEN --profile futurenet
```

Use `--account ADDRESS` to restrict the query to an account. Amounts are returned as base-unit values; formatting is separate from the stored amount.



## Continue a page

These list commands return one newest-first page at a time. Pass the returned cursor to the same command with the same target and filters:

```bash
thruput tx list my-counter --profile futurenet --limit 25 --cursor CURSOR
```

Replace `CURSOR` with the exact returned value. An empty page with a non-empty cursor is not the end. The returned cursor `0x` ends that historical walk.

To check for new activity, omit `--cursor` and start at the head again. A saved cursor continues the old walk; it is not a subscription. For forward ingestion and durable checkpoints, use the [event indexing guidance](pages/typescript/events.md#resume-without-missing-events).

The [Explorer](pages/tools/block-explorer.md) provides a browser-based inspection path.

---

## Generate TypeScript bindings

Source: <https://thruput.network/docs/cli/codegen/>

Generate typed application bindings from a built contract's canonical specification.

Generate bindings from the same contract build you deploy. Bindings provide method descriptors, argument types, result decoders, and declared event and error types.

Use Thruput CLI 0.29.0 or newer for applications that import the private `@thruputchain` npm packages. Older generators emit the previous package namespace.



## Generate during a build

```bash
thruput build --bindings ts
```

The build prints the generated binding path alongside the contract artifacts. Use `-p PACKAGE` when selecting a workspace member.



## Write bindings into an application

Build first, then select the binary spec sidecar:

```bash
thruput build
mkdir -p web/src/contracts
thruput codegen ts target/thruput/my_counter.spec.xdr \
  --output web/src/contracts/my-counter.ts
```

Replace `my_counter` with your artifact’s name and the output directory with your application’s location. `codegen ts` accepts `.spec.xdr`, not the readable `.spec.json` or the deployable `.rv32a` file.



## Keep code and deployment aligned

Regenerate bindings when the contract interface changes. Use the address from the matching deployment rather than an address copied from another example.

Do not edit generated files. Put application wrappers next to them so regeneration does not overwrite application logic.

Continue with [Use contract bindings](pages/tools/typescript-bindings.md) for descriptors and typed calls, or [Read events](pages/typescript/events.md) for filters and decoding.

---

## Skills and local docs

Source: <https://thruput.network/docs/cli/agent-tools/>

Install, update, and read the thruput skill, and serve or export local documentation.

Use `thruput skill` for coding-agent instructions and `thruput docs` for the developer documentation. For a first project, follow [Build with an Agent](pages/start/build-with-an-agent.md).



## Install the maintained skill

Installation requires Node.js 22.20 or newer, npm, Git, and access to the private [skill repository](https://github.com/thruputchain/agent-skills). Configure repository authentication through Git, GitHub CLI, or SSH.

```bash
thruput skill install
```

The installer lets you choose your agents, project or global scope, and installation method. Project scope is the default. To select an agent or use a user-wide installation explicitly:

```bash
thruput skill install --agent opencode
thruput skill install --global --agent claude-code
```

Repeat `--agent` to select more than one agent. These commands run `npx skills` against the maintained source. You can also install directly:

```bash
npx skills add thruputchain/agent-skills --skill thruput
```

Installing the skill does not configure Cargo or npm access for a contract or application. Follow the relevant [quickstart](pages/get-started.md) for those dependencies.



## Update an installed skill

Run the update in the same scope as the installation:

```bash
thruput skill update
thruput skill update --global
```

Each command updates only the `thruput` skill, not other installed skills. If `thruput` is absent from that scope, run `skill install` there first. A current installation needs no change. Repeating installation uses the installer again; it does not create a second skill name.

For a direct project-scoped update:

```bash
npx skills update thruput --project
```



## Read installed guidance offline

```bash
thruput skill show
thruput skill list
thruput skill show contracts
thruput skill show contracts --global
thruput skill list --global
```

`show` prints the installed `SKILL.md` unchanged. `list` lists the Markdown references in that installation. Select a topic, such as `contracts`, to read its reference. There is no `--all` option; read the entry and the references needed for your task.

By default, these commands look for `.agents/skills/thruput` in the current directory, then under your home directory. Run them from the directory where you installed the project skill. `--global` selects only the home-directory installation. An invalid project installation reports an error rather than falling back to the global copy.

Install the skill before reading it. Once installed, `show` and `list` need no Node.js, npm, Git, or network access. Missing files produce an installation or read error, not bundled fallback content. Add `--json` for the selected scope, file path, and content or topic list.

Updates change the installed files that `show` and `list` read. This is separate from `thruput docs`, which serves a documentation snapshot bundled with the CLI.



## Automate skill setup

For an intended unattended installation or update:

```bash
thruput skill install --agent opencode --yes --non-interactive --json
thruput skill update --yes --non-interactive --json
```

Installation requires an explicit `--agent` when prompts are unavailable. Both operations require `--yes` to authorize npm execution and skill changes. Add `--global` for user-wide scope. `--non-interactive` and `--json` do not grant consent. `--offline` rejects installation and updates before invoking npm.



## Serve local documentation

```bash
thruput docs
```

This serves the CLI’s bundled site on `127.0.0.1:4321` until you press Ctrl-C. `--foreground` makes that mode explicit. The command prints the browser URL, Markdown index path, and snapshot source. It starts no blockchain node.

To keep the server running after the command returns:

```bash
thruput docs --background --port 0
thruput docs status
thruput docs stop
```

Port `0` chooses an available port. Background startup returns only when the server is ready and reports the browser URL, Markdown index, and log path. Repeating the same start command reuses a matching instance. Stop it before changing its port, snapshot, or CLI executable.

`status` and `stop` manage the current user’s background server, not a foreground process. The server does not start automatically after reboot. Stopping it leaves the extracted Markdown available. Add `--json` to start, status, or stop for structured reports.

Use the printed Markdown index to find individual pages under `pages/`, focused bundles under `sections/`, and the complete `full.md`. Agents on the same machine can read these files without keeping the server running. Bundled documentation is a snapshot and can differ from the hosted site.



## Export Markdown without a server

```bash
thruput docs export --output ./thruput-docs
```

The destination must not exist, and its parent directory must exist. The CLI copies the Markdown tree and snapshot identity, then prints the absolute path to `index.md`. It does not start a server or replace an existing export. Choose a new destination for another export.

Share the whole folder with an agent on another machine. Relative links and local assets remain usable away from the website. A remote agent cannot use your local filesystem path or loopback URL directly.



## Use a trusted site snapshot

```bash
thruput docs --dir /path/to/docs-snapshot --port 0
thruput docs export --dir /path/to/docs-snapshot --output ./exported-docs
```

Pass a directory produced by the documentation snapshot build, including its `snapshot.json`. Keep it unchanged while serving. Export requires `markdown/index.md` in that snapshot. The override does not fetch the hosted site.

Serving bundled docs and exporting them work offline. Linked repositories, package registries, and network services can still require network access.

---

## Use the CLI in scripts

Source: <https://thruput.network/docs/cli/automation/>

Use non-interactive commands and structured output without treating output flags as confirmation.

Use `--non-interactive` to disable questions and terminal UI. It does not authorize state changes. Pass `--yes` to confirm an intended write, such as a deployment, an airdrop, or skill setup. On write commands other than `skill`, `--force` remains an alias.



## Set up explicitly

```bash
thruput init --non-interactive --generate-key
```

`--generate-key` authorizes initial key creation when there are no stored keys or explicit selections. It does not replace an existing key. Use `thruput new` separately to create a project in a script.



## Request structured output

```bash
thruput config get futurenet --json
thruput test --json
```

The envelope identifies the command, its `ok` result, warnings, and command data. Payloads carry a command-specific `schemaVersion`; check it before relying on exact fields.

Check the process exit status as well as the envelope. A reported test failure can carry `ok: false` on stdout. Other command failures can emit an error envelope on stderr. Keep the streams separate instead of assuming every failed command produces a successful-data shape on stdout.

With `test --watch --json`, each completed run is a separate JSON record. A long-running `node` or watch command still runs until stopped.



## Confirm intended writes

For a deployment you intend to submit:

```bash
thruput deploy --profile futurenet --fund 10 --non-interactive --yes --json
```

For preparation without submission, use `--dry-run` instead. Neither `--quiet` nor `--json` substitutes for confirmation.



## Set up agent tools

```bash
thruput skill install --agent opencode --yes --non-interactive --json
thruput docs --background --port 0 --json
```

Unattended skill installation needs both `--yes` and an explicit agent. Updates need `--yes`; add `--global` to either operation for user-wide scope. See [Skills and local docs](pages/cli/agent-tools.md) for prerequisites, targeted updates, and offline reads.

Background docs reports include `running`, `reused`, `server`, and `logPath` in `data`. Read `server.url` and `server.markdownIndex` when a server is present. Use `thruput docs status --json` to inspect it and `thruput docs stop --json` to stop it. A status with `running: false` is a valid result, not a command failure.

---

## Troubleshooting

Source: <https://thruput.network/docs/cli/troubleshooting/>

Diagnose configuration, build, runtime, funding, and transaction-observation problems.

Start with the command’s error and the selected environment:

```bash
thruput --version
thruput status --profile futurenet
thruput config get futurenet --sources
```

For local work, use `--profile local`. `status` can exit nonzero when it finds warnings; inspect the findings rather than assuming the report itself failed.



## Cargo cannot access packages

Complete [Cargo access setup](pages/cli/install.md#configure-cargo-access) in the terminal running the build. A registry token alone is not enough if Cargo has no credential provider configured. Repository access does not imply registry access.



## The wrong profile or account is selected

An explicit `--profile` wins over `THRUPUT_PROFILE`, which wins over project and global defaults. A profile-specific key or selected wallet can also override the global key. Inspect both configuration and `wallet ls --profile NAME` before changing them.

Use [Profiles and networks](pages/cli/configuration.md) and [Keys and wallets](pages/cli/wallets.md) to change the intended layer. Preserve existing keys rather than generating replacements to hide a selection error.



## The local runtime is missing or incompatible

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

Check for an intentional `THRUPUT_DEVNODE_BINARY` override or an adjacent binary. The installed CLI’s catalog chooses a compatible managed runtime. A protocol-token override does not fix a wire-format mismatch. See [runtime selection](pages/cli/local-node.md#runtime-selection).

On Linux, a missing shared-library error identifies the system dependency to install. See [CLI installation](pages/cli/install.md) for runtime-library guidance.



## The node restarted and the deployment disappeared

An ephemeral local node loses chain state on shutdown. Restarting it does not restore the old wallets, balances, or deployments, even when local configuration still has their aliases. Redeploy on the new chain, or use a persistent [data directory](pages/cli/local-node.md#preserve-state).



## Deployment needs funding

Native deployment requires an explicit `--fund` amount. The sender needs funds for the transfer and scheduling capacity; the deployed contract needs funds for its own storage. Inspect the sender with `thruput balance --profile NAME`, then request appropriate test funding or reduce the operation. See [Deploy and call](pages/cli/deploy-and-call.md).



## Submission timed out or status is unknown

Keep the transaction hash and original network. Run `thruput tx show TX_HASH --profile NAME` to inspect it. A timeout is not proof of failure. Do not automatically repeat a deployment or sign a replacement call.



## A view or call cannot resolve a method

Use the correct contract alias and the spec from the matching build. Rebuild after interface changes. At a Cargo workspace root, select the package with `-p`. Explicit entrypoint calls require the matching encoded calldata; changing only the entrypoint does not adapt an incompatible interface.



## The integration target is missing

Current CLI projects include `tests/integration.rs` and its activation wiring. Compare an older project with a fresh scaffold before adding them; do not replace its dependency configuration blindly. See [Test contracts](pages/programming-model/testing.md#what-the-scaffold-gives-you).

---

## Command reference

Source: <https://thruput.network/docs/cli/reference/>

Thruput CLI commands, common options, and links to task instructions.



## First-Run Setup

| Command                                                              | Purpose                                                                       | Usage                                                              |
| -------------------------------------------------------------------- | ----------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `thruput --version`                                                  | Print the installed release                                                   | [Install](pages/cli/install.md)                                    |
| `thruput init`                                                       | Initialize profiles and check setup; offer initial key creation interactively | [CLI quickstart](pages/get-started/cli.md)                         |
| `thruput init --non-interactive --generate-key`                      | Explicitly authorize initial key creation without prompts                     | [Automation](pages/cli/automation.md)                              |
| `thruput status [--profile NAME]`                                    | Inspect project, key, compiler, and runtime readiness                         | [Troubleshooting](pages/cli/troubleshooting.md)                    |
| `thruput new [NAME] [--path PATH] [--template counter\|counter-app]` | Create a minimal contract by default; omit the name for interactive setup     | [Create a project](pages/cli/create-project.md)                    |
| `thruput templates list` / `thruput templates show NAME`             | Discover named templates and their prerequisites offline                      | [Choose a template](pages/cli/create-project.md#choose-a-template) |
| `thruput completion SHELL`                                           | Print shell completions                                                       | `thruput completion --help`                                        |
| `thruput COMMAND --help`                                             | Print the installed command’s options                                         | Available on each command                                          |



## Configuration

| Command                                 | Purpose                                             | Usage                                                                         |
| --------------------------------------- | --------------------------------------------------- | ----------------------------------------------------------------------------- |
| `config profiles`                       | List persisted profiles                             | [Profiles and networks](pages/cli/configuration.md)                           |
| `config get [NAME] [--sources]`         | Inspect merged persisted settings and their origins | [Inspect settings](pages/cli/configuration.md#inspect-the-current-settings)   |
| `config new NAME --network NETWORK`     | Create a profile in one layer                       | [Add an endpoint](pages/cli/configuration.md#add-another-endpoint)            |
| `config set FIELD VALUE --profile NAME` | Set one typed field in an existing profile layer    | [Overrides](pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config unset FIELD --profile NAME`     | Remove a field from one layer                       | [Overrides](pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config use NAME`                       | Set the layer’s default profile                     | [Select a profile](pages/cli/configuration.md#choose-a-profile)               |
| `config rm NAME`                        | Remove a profile from one layer                     | Requires confirmation; `--yes` for an intended automated removal              |
| `--global` / `--project`                | Choose the layer for a configuration mutation       | Required inside a project; mutually exclusive                                 |



## Keys and Wallets

| Command                                            | Purpose                                                            | Usage                                                           |
| -------------------------------------------------- | ------------------------------------------------------------------ | --------------------------------------------------------------- |
| `keys generate [NAME] [--scheme ed25519\|mldsa65]` | Generate a stored key; Ed25519 by default                          | [Keys and wallets](pages/cli/wallets.md)                        |
| `keys import NAME`                                 | Import an Ed25519 secret seed through the supported input flow     | `thruput keys import --help`                                    |
| `keys ls` / `keys use NAME`                        | List or select a global key                                        | [Select an account](pages/cli/wallets.md#select-an-account)     |
| `keys export NAME`                                 | Print private key material                                         | Intended export only; exclude from logs                         |
| `keys rm NAME`                                     | Delete a local key                                                 | Requires confirmation                                           |
| `wallet create [--key NAME] [--name NAME]`         | Derive and save an empty native account binding; Ed25519 keys only | [Create a wallet](pages/cli/wallets.md#create-a-key-and-wallet) |
| `wallet ls` / `wallet use NAME`                    | List or select a profile wallet                                    | [Select an account](pages/cli/wallets.md#select-an-account)     |
| `wallet rm NAME`                                   | Remove a local binding                                             | Does not remove onchain state                                   |
| `balance [TARGET]`                                 | Read the native-token balance                                      | [Funding](pages/cli/wallets.md#fund-and-transfer)               |
| `airdrop [RECIPIENT]`                              | Request test funding                                               | [Faucet](pages/tools/faucet.md)                                 |
| `transfer RECIPIENT AMOUNT`                        | Transfer native tokens from the selected account                   | [Funding and transfers](pages/cli/wallets.md#fund-and-transfer) |



## Build and Test

| Command or option                        | Purpose                                       | Usage                                                                                |
| ---------------------------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------ |
| `build [-p PACKAGE]`                     | Build a deployable RV32 artifact              | [Build and test](pages/cli/build-and-test.md)                                        |
| `build --bindings ts`                    | Also generate TypeScript bindings             | [Code generation](pages/cli/codegen.md)                                              |
| `build --stack-size SIZE`                | Set guest stack size within configured memory | `thruput build --help`                                                               |
| `test [-p PACKAGE]`                      | Build and run the RV32 artifact test target   | [Test modes](pages/cli/build-and-test.md#choose-a-test-boundary)                     |
| `test --integration`                     | Run an isolated local-node integration target | [Integration tests](pages/programming-model/testing.md#integration-test-environment) |
| `test --workspace`                       | Run eligible workspace members                | [Workspace runs](pages/cli/build-and-test.md#integration-and-workspace-runs)         |
| `test --match-test TEXT` / `--skip TEXT` | Filter test names                             | [Focused runs](pages/cli/build-and-test.md#focus-a-test-run)                         |
| `test --rerun` / `--watch`               | Repeat failures or watch files                | Not supported with `--integration`                                                   |
| `test --show-output` / `--no-capture`    | Control test output                           | [Focused runs](pages/cli/build-and-test.md#focus-a-test-run)                         |



## Local Node

| Command or option                                     | Purpose                                   | Usage                                                                          |
| ----------------------------------------------------- | ----------------------------------------- | ------------------------------------------------------------------------------ |
| `node`                                                | Start an ephemeral local node             | [Run a local node](pages/cli/local-node.md)                                    |
| `node --data-dir PATH`                                | Preserve chain state                      | [Persistent state](pages/cli/local-node.md#preserve-state)                     |
| `node --port PORT` / `--host ADDRESS`                 | Configure the public listener             | [Endpoint and logging](pages/cli/local-node.md#change-the-endpoint-or-logging) |
| `node --verbose`                                      | Forward node diagnostics                  | [Troubleshooting](pages/cli/troubleshooting.md)                                |
| `node --network-config NAME=VALUE`                    | Override a supported genesis parameter    | Repeatable; preserve settings when reopening a data directory                  |
| `node --key NAME` / `--initial-account-tokens AMOUNT` | Fund a stored key on a fresh chain        | Default: the selected key and 100 native tokens                                |
| `node --bootstrap-accounts FILE`                      | Fund fixture-owned public keys at genesis | JSON array; cannot be combined with `--key` or `--initial-account-tokens`      |
| `toolchain list` / `install` / `which`                | Inspect or acquire managed runtimes       | [Local runtime setup](pages/cli/install.md#set-up-the-local-runtime)           |
| `toolchain use VERSION` / `clean VERSION`             | Select or remove a managed version        | `thruput toolchain --help`                                                     |
| `chain dump --data-dir PATH --output FILE`            | Back up a stopped local chain             | [Persistent state](pages/cli/local-node.md#preserve-state)                     |
| `chain restore --data-dir PATH --input FILE`          | Restore a stopped local chain             | Requires confirmation before replacing populated state                         |



## Deploy and Interact

| Command or option                       | Purpose                                                                                                                      | Usage                                                                        |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `deploy --fund AMOUNT`                  | Deploy and fund a contract with native tokens                                                                                | [Deploy and call](pages/cli/deploy-and-call.md)                              |
| `deploy --estimate [--json]`            | Read deployment collateral and configuration context without loading a signing key or submitting                             | [Estimate funding](pages/cli/deploy-and-call.md#estimate-deployment-funding) |
| `deploy --fund minimum`                 | Fund a fresh deployment’s balance-item deposit and code collateral; leaves no free balance and cannot include initialization | [Minimum funding](pages/cli/deploy-and-call.md#estimate-deployment-funding)  |
| `deploy --init METHOD --init-arg VALUE` | Initialize atomically with deployment                                                                                        | [Initialization](pages/cli/deploy-and-call.md#include-initialization)        |
| `deploy --artifact PATH --alias NAME`   | Select an artifact and saved alias                                                                                           | [Deployment](pages/cli/deploy-and-call.md#deploy-an-artifact)                |
| `call CONTRACT METHOD [ARGS...]`        | Submit a signed contract invocation                                                                                          | [Calls](pages/cli/deploy-and-call.md#submit-a-call)                          |
| `view CONTRACT METHOD [ARGS...]`        | Run a sandboxed read without submitting                                                                                      | [Views](pages/cli/deploy-and-call.md#read-without-submitting)                |
| `storage CONTRACT KEY`                  | Read a raw committed storage item                                                                                            | [Views and storage](pages/cli/deploy-and-call.md#read-without-submitting)    |
| `--dry-run`                             | Prepare deploy/call transactions without broadcast                                                                           | Still requires signing context and network access                            |
| `--yes` (alias `--force`)               | Confirm an intended write without a prompt; `skill` commands accept only `--yes`                                             | [Automation](pages/cli/automation.md#confirm-intended-writes)                |
| `--profile NAME` / `--rpc-url URL`      | Select configuration or override the endpoint                                                                                | [Profiles](pages/cli/configuration.md)                                       |



## Transactions, Events, and Tokens

| Command                         | Purpose                                         | Usage                                                                     |
| ------------------------------- | ----------------------------------------------- | ------------------------------------------------------------------------- |
| `tx show HASH`                  | One public status and receipt lookup            | [Inspect transactions](pages/cli/transactions.md#look-up-one-transaction) |
| `tx list [TARGET]`              | One page of root-invocation history             | [History](pages/cli/transactions.md#list-history)                         |
| `events list CONTRACT`          | One page of raw or spec-decoded contract events | [Events](pages/cli/transactions.md#read-contract-events)                  |
| `token transfers TOKEN`         | One page of token transfer records              | [Token transfers](pages/cli/transactions.md#inspect-token-transfers)      |
| `--limit N` / `--cursor CURSOR` | Control a historical list page                  | [Pagination](pages/cli/transactions.md#continue-a-page)                   |



## TypeScript Bindings

| Command                   | Input/output                                                     | Usage                                                                        |
| ------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `build --bindings ts`     | Contract build plus generated bindings                           | [Generate bindings](pages/cli/codegen.md)                                    |
| `codegen ts SPEC -o FILE` | Canonical `.spec.xdr` to TypeScript; stdout if output is omitted | [Write into an app](pages/cli/codegen.md#write-bindings-into-an-application) |



## Skills and Local Documentation

| Command                                              | Purpose                                                                                                     | Usage                                                                        |
| ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `thruput skill install [--global] [--agent NAME]`    | Install the maintained skill through `npx skills`; `--agent` is repeatable                                  | [Install the skill](pages/cli/agent-tools.md#install-the-maintained-skill)   |
| `thruput skill update [--global]`                    | Update only the `thruput` skill in the selected scope; requires an existing installation                    | [Update the skill](pages/cli/agent-tools.md#update-an-installed-skill)       |
| `skill install --yes` / `skill update --yes`         | Authorize npm execution and skill changes; unattended installation also needs `--agent`                     | [Automate setup](pages/cli/agent-tools.md#automate-skill-setup)              |
| `thruput skill show [TOPIC] [--global]`              | Read an installed skill file offline; current-directory installation before global unless `--global` is set | [Read guidance](pages/cli/agent-tools.md#read-installed-guidance-offline)    |
| `thruput skill list [--global]`                      | List reference names from the selected installed skill                                                      | [Read guidance](pages/cli/agent-tools.md#read-installed-guidance-offline)    |
| `thruput docs [--foreground] [--port PORT]`          | Serve the bundled site in the foreground; default port `4321`, `0` selects a free port                      | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs --dir PATH`                            | Serve a trusted local snapshot                                                                              | [Snapshot override](pages/cli/agent-tools.md#use-a-trusted-site-snapshot)    |
| `thruput docs --background [--port PORT]`            | Start or reuse a matching background server; conflicts with `--foreground`                                  | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs status`                                | Inspect the current user’s background server and log path                                                   | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs stop`                                  | Stop the managed background server while retaining extracted Markdown                                       | [Serve docs](pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs export --output PATH [--dir SNAPSHOT]` | Export portable Markdown into a new directory without serving                                               | [Export Markdown](pages/cli/agent-tools.md#export-markdown-without-a-server) |



## Shared Flags

| Global flag             | Effect                                                                                                  |
| ----------------------- | ------------------------------------------------------------------------------------------------------- |
| `--non-interactive`     | Disable prompts and terminal UI; does not grant confirmation                                            |
| `--json`                | Emit structured output                                                                                  |
| `--quiet`               | Suppress status messages                                                                                |
| `--show-cargo-commands` | Print Cargo invocations                                                                                 |
| `--offline`             | Disable managed runtime downloads and skill installation/updates; does not disable RPC or Cargo traffic |



### JSON output

| Output concern      | Rule                                                        | Usage                                                                  |
| ------------------- | ----------------------------------------------------------- | ---------------------------------------------------------------------- |
| Success and failure | Check exit status and `ok`; command failures may use stderr | [Use the CLI in scripts](pages/cli/automation.md)                      |
| Payload shape       | Check command-specific `data.schemaVersion`                 | [Structured output](pages/cli/automation.md#request-structured-output) |
| Watch mode          | One JSON record per completed test run                      | [Structured output](pages/cli/automation.md#request-structured-output) |

---

## Smart Contracts

Source: <https://thruput.network/docs/contracts/>

Write, test, and understand Project Thruput contracts with the Rust SDK.

Build contract logic with the Rust SDK. Use this section for storage choices, authorization, events, testing, and the contract programming model.



## Write your first contract

Follow the [contract quickstart](pages/get-started/contract.md) to deploy a counter on Futurenet. Then read [Build a Counter](pages/tutorials/build-a-counter.md) to understand its code and tests, or [Project structure](pages/contracts/project-structure.md) to find the generated files.

Use the [CLI section](pages/cli.md) for build and deployment commands.



## Work on a contract

- [Define methods and interfaces](pages/contracts/methods.md).
- [Choose storage types](pages/programming-model/storage-types.md) for your data.
- [Authorize calls](pages/how-it-works/authorization.md).
- [Define and handle errors](pages/contracts/errors.md).
- [Emit and test events](pages/contracts/events.md).
- [Call another contract](pages/contracts/cross-contract-calls.md).
- [Choose a test mode and write tests](pages/programming-model/testing.md).
- [Debug a contract](pages/contracts/debugging.md).
- [Generate client bindings](pages/contracts/client-bindings.md) for application developers.



## Understand the programming model

Read [Contract Execution](pages/programming-model/execution.md) first for snapshots, merged changes, and the rules that cause bugs. Then read [Storage Types](pages/programming-model/storage-types.md), starting with [Balance](pages/programming-model/storage-types.md#balance) for nonnegative counts and amounts. Continue with [NNInt and concurrent updates](pages/programming-model/nnint.md) to understand the underlying signed deltas, explicit bases, and merge rules. [Exclusive writes](pages/programming-model/storage-types.md#exclusive-writes) and [invocation frames](pages/how-it-works/invocation-frames.md) cover other storage and call constraints.

Read [Contract artifacts and addresses](pages/how-it-works/contracts.md) to understand code hashes, deployment addresses, and immutability.



## Look up an API

Use the [storage API tables](pages/reference/storage-types.md), [SDK macros](pages/reference/sdk-macros.md), [syscalls](pages/reference/syscalls.md), and [generated Rust API docs](pages/tools/rust-api-docs.md).

For larger worked examples, visit [Guides](pages/guides.md).

---

## Project structure

Source: <https://thruput.network/docs/contracts/project-structure/>

Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.

`thruput new` creates a minimal Cargo contract project by default. Use `thruput new my-counter --template counter` for the counter layout below, including its example methods and tests. Keep the generated dependency versions, compiler settings, and CLI configuration together.



## Generated files

```text
my-counter/
  Cargo.toml              # Package, SDK dependencies, and build features
  AGENTS.md               # Instructions for coding agents
  build.rs                # Integration-test setup
  thruput.toml          # Project profiles and contract aliases
  rust-toolchain.toml     # Selected compiler and targets
  .cargo/
    config.toml           # Registry and Cargo configuration
    contract.toml         # Contract-build configuration
  src/
    lib.rs                # Library modules
    implementation.rs     # Contract logic, storage, errors, and events
    main.rs               # Contract entrypoint wrapper
  tests/
    test.rs               # Native logic tests
    test_rv32.rs          # Contract artifact tests
    integration.rs        # Tests against a running node
```

The `.gitignore` excludes build output and project-local runtime state.



## Build artifacts

`thruput build` compiles the entrypoint for RV32, Project Thruput’s 32-bit RISC-V contract target. It lowers the compiler output into an artifact the node can execute.

For `my-counter`, the output under `target/thruput/` includes:

- `my_counter.rv32a`: deployable contract artifact.
- `my_counter.rv32.json`: lowering metadata.
- `my_counter.spec.xdr`: binary contract specification.
- `my_counter.spec.json`: readable contract specification.

The specification describes the contract interface and supports [TypeScript binding generation](pages/tools/typescript-bindings.md).



## Test modes

- `cargo test` runs the native contract tests.
- `thruput test` runs the RV32 artifact tests.
- `thruput test --integration` manages a local node for the integration tests.

See [Testing](pages/programming-model/testing.md) for the execution modes, generated integration environment, and how to add assertions.



## SDK layers

Generated projects start with the SDK’s contract and storage macros. Use typed storage handles for normal state access. Lower-level syscall wrappers are available when you need a custom abstraction.

These layers can be combined within a contract. Use [Storage Types](pages/programming-model/storage-types.md) to choose an API, [SDK Macros](pages/reference/sdk-macros.md) for macro reference, and [Rust API Docs](pages/tools/rust-api-docs.md) for exact signatures.

---

## Methods and interfaces

Source: <https://thruput.network/docs/contracts/methods/>

Define contract state, expose methods, and share typed interfaces with Rust callers.

Start with a [generated project](pages/cli/create-project.md) so its host tests and RV32 entrypoint are configured.



## Define state and behavior

```rust
use thruput_sdk::storage::Balance;
use thruput_sdk::*;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}

#[contract]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.increase(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.get()
    }
}
```

`#[thruput_sdk::storage]` assigns each field a storage path. The field is a handle to persisted data, not an in-memory integer that you must save manually. `#[contract]` generates entrypoints, a `CounterClient`, and interface metadata.

`Balance::get()` gives the never-written counter a zero default while preserving other storage errors. `increase` records a relative change and checks for overflow. Start with [Balance](pages/programming-model/storage-types.md#balance) for nonnegative counts and amounts; use [NNInt](pages/programming-model/nnint.md) when you need signed deltas or an explicit base.



## Expose methods

Public methods on an inherent implementation become entrypoints. Private helper methods stay internal. Use `&mut self` to update through mutable storage handles and `&self` to read through shared handles. A method without a receiver does not need the generated storage struct.

Rust receiver mutability is separate from runtime call restrictions. Use [read-only child calls](pages/contracts/cross-contract-calls.md#gas-limits) when the runtime must reject state changes.

Exported methods return their normal values. Use [contract exceptions](pages/contracts/errors.md) for failures.



## Share an interface

Put a trait in a shared interface crate when callers need the interface without importing its implementation:

```rust
use thruput_sdk::*;

#[contract]
pub trait CounterApi {
    fn increment(&mut self, amount: u64);
    fn get(&self) -> i128;
}
```

This generates `CounterApiClient`. Mark the trait implementation with `#[contract]` too. Declare `throws` and `emits` on the trait definition, not again on its implementation.

For a self-contained contract, the inherent implementation in the first example is enough. The [macro reference](pages/reference/sdk-macros.md#contract) lists parameters and reserved method names.



## Define argument and return types

```rust
#[contract_type]
pub struct CounterSummary {
    pub value: i128,
    pub owner: ContractAddress,
}
```

`#[contract_type]` supplies serialization and spec metadata. Use `Value<T>` when plain data must persist; choose other [storage types](pages/programming-model/storage-types.md) for other update patterns.



## Initialize and generate bindings

Initialization is an ordinary method, not an automatic constructor. Enforce one-time initialization when required and [initialize atomically with deployment](pages/cli/deploy-and-call.md#include-initialization).

Rust callers use generated clients. [Generate client bindings](pages/contracts/client-bindings.md) to share the built contract interface with TypeScript applications. Keep bindings and deployment addresses from the same interface build.

---

## Contract Execution

Source: <https://thruput.network/docs/programming-model/execution/>

The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.

Your contract reads from a frozen snapshot and produces typed storage changes, called deltas. Ordinary storage reads do not see other transactions’ writes. The runtime checks whether each transaction’s deltas can coexist with the other changes landing in the block. Deltas that can coexist form the next committed state. Transactions with conflicting deltas are excluded from that proposal.

Read this page first, then [Storage Types](pages/programming-model/storage-types.md). It explains the behavior your contract relies on without requiring the engine’s lock and reservation implementation.



## Rules That Cause Bugs

- **Reads are not checked at commit.** A decision based on a value that another transaction can change in the same block can be stale. See [Snapshot Isolation](pages/programming-model/execution.md#snapshot-isolation).
- **Decreases must fit the base.** All decreases admitted to one `Balance` or `NNInt` in a block must fit within the base value. For `Balance` and ordinary `NNInt` updates, the base is the start-of-block snapshot; an explicit `NNInt::set_add` uses the base it sets. Same-block credits do not count. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas) and [NNInt](pages/programming-model/nnint.md).
- **Exclusion applies to one proposal.** It does not consume the replay nonce or guarantee automatic requeue. A committed abort, revert, or out-of-gas fault consumes the nonce. See [Exclusion](pages/programming-model/execution.md#exclusion).
- **Absolute writes merge only when equal.** Two `Value`, `Bytestring`, or `NNInt::set` writes to one key land together only when they write the same value. See [Storage Types](pages/programming-model/storage-types.md#choosing-a-type).
- **Some operations allow one writer per block.** One transaction per block can consume from a queue, push or pop a `Vector`, or hold an exclusive write on a key. See [RCQ](pages/programming-model/storage-types.md#rcqt--retrocausalqueue) and [Exclusive Writes](pages/programming-model/storage-types.md#exclusive-writes).
- **The full gas limit is reserved.** Scheduling uses the declared limit, not the gas used. See [Gas](pages/programming-model/execution.md#gas).



## Snapshot Isolation

All transactions in a block read the same committed state from the previous block. Ordinary storage reads do not see another transaction’s writes within the block. Reads include changes made within your transaction, including successful child calls. Other transactions cannot change the snapshot you read.

Reads are not validated when the transaction commits. Only writes can conflict. If two transactions each read `total_supply`, find room under a cap, and mint, both can land and exceed the cap. Enforce a rule that spans transactions with a write the runtime checks: a `Balance` or `NNInt` floor, a [`CapacityConstraint`](pages/programming-model/storage-types.md#capacityconstraint), or an [exclusive write](pages/programming-model/storage-types.md#exclusive-writes).

`RetrocausalQueue` has separate observation rules: a consumer can observe concurrent inserts in the same block. The proposer records these observations for validator replay.



## Merged Deltas

A delta describes how one transaction changes a storage location. It is not necessarily an arithmetic difference. The storage type gives the delta its meaning and defines whether it can coexist with other changes to the same location.

For a `Balance`, the delta is an increase or decrease. When you write:

```rust
self.balance.lazy_increase(5);
```

This says “add 5 to the balance.” It does not say “set the balance to 105.”

Suppose two transactions read a balance of 100:

```text
Tx A: lazy_decrease(20)
Tx B: lazy_decrease(30)
Both land: 100 - 20 - 30 = 50
```

Both changes can land because addition gives the same result in either order and the combined debit fits within the balance. We say the operations **commute**, and the runtime can merge their deltas. If the transactions instead try to debit 80 and 30, the combined debit exceeds the snapshot balance, so whichever transaction reserves second is excluded.

Merge rules depend on the storage type:

- `Balance` merges increases and decreases. All decreases admitted in a block must fit within the snapshot value; credits from other transactions in the same block do not fund a decrease.
- `NNInt` exposes lower-level signed changes and explicit bases.
- Changes to different `Map` keys are independent.
- Two `Value` writes to the same key can coexist only when they store the same value.

In these docs, **compatible deltas** means the storage type allows both changes to land. See [`Balance`](pages/programming-model/storage-types.md#balance) for the ordinary balance API and [NNInt and concurrent updates](pages/programming-model/nnint.md) for the underlying `set_add` rules.



## Block Lifecycle

1. **Read and execute:** your contract reads the block snapshot plus its own changes and successful child calls. It records typed deltas.
2. **Reserve:** after the root call succeeds, the runtime checks whether the complete delta batch can coexist with the proposal’s other changes.
3. **Commit or exclude:** admissible transactions contribute to the finalized block. Conflicting transactions are excluded from that proposal.

Your contract does not control these phases. [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md) covers submission through finalization; [Parallel Execution](pages/how-it-works/execution-model.md) explains the reservation machinery.



## Exclusion

From your contract’s perspective, a conflicting attempt doesn’t land in that proposal. Your code runs, produces deltas, and the system determines whether that completed delta batch is compatible with the proposal’s other changes. Exclusion does not commit the transaction or consume its replay nonce. It does not establish whether the same transaction committed in another proposal. See [How Conflicts Are Resolved](pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the engine-level details.

The scheduler can requeue transactions when a nomination is rolled back or a different proposal commits. When its own proposal commits, it removes the attempted transactions, including excluded ones, and records retryable execution failures as `retry`. See [Exclusion, requeue, and resubmission](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission) for the full lifecycle.

A committed abort, revert, or out-of-gas fault discards the contract changes but records the replay nonce and RCQ observations. Once the receipt confirms that committed failure, fix the cause before signing a new transaction.

Clients keep the signed bytes, submitted hash, and original network, then observe the outcome. Receipt polling does not resubmit. When retrying is appropriate, reuse the same signed transaction while it remains valid. A timeout, expiration, or missing result does not prove that an earlier attempt never committed. See [Resubmission and replacement](pages/typescript/transaction-status.md#resubmission-and-replacement).

When a recent attempt hit a storage conflict, [`getTransactionStatus`](pages/reference/json-rpc-api.md#gettransactionstatus) can include `recentFailure` with `cause.kind` set to `dbConflict` and a `conflict` object naming the contract address, storage key, and conflict code. Use it to find hot keys. It is an advisory diagnostic, not permission to resubmit or sign a replacement.

To handle a conflict inside a child call, use [`with_commit_locking()`](pages/contracts/cross-contract-calls.md#gas-limits). The child takes its commit locks before it returns, so a `try_` call sees the conflict as a failure.



## Gas

Transactions and cross-contract calls specify a gas limit. Gas bounds computation, including work in child calls, but costs zero tokens.

For root transactions, the gas limit is the scheduling quantity. The scheduler accounts for the amount you declare whether execution uses all of it or only part of it. If execution exceeds the limit, the transaction faults. The fault is committed with its contract changes discarded.

Each chain caps the root gas limit at `max_tx_gas`. A transaction above the cap is rejected, not clamped. Wire `14.1.0` servers expose the cap as `stated.maxTxGas` in [`getChainConfig`](pages/reference/json-rpc-api.md#getchainconfig) and report the rejection as `gasLimitTooHigh`.

A child call without `with_gas_limit` can use all of the caller’s remaining gas. Unused child-call gas returns to the caller’s execution budget. That is not a token refund and does not change the root transaction’s scheduling amount.

```rust
let client = TokenClient::new(&token_address);
client.with_gas_limit(100_000).transfer(&to, amount);
```

Gas has no token fee, but lower gas limits use less scheduling capacity. Choose a limit that covers execution and design storage operations to avoid unnecessary conflicts.

Project Thruput needs no gas price estimation because the token price of gas is zero. Gas usage still matters when choosing an execution limit.



## Throughput

Your unlocked native-token balance provides scheduling capacity. A transaction’s gas limit must fit within the capacity the sending account’s tokens provide; the scheduler drops a transaction whose limit exceeds it. Compatible storage changes do not guarantee inclusion in the next block: admission, capacity, propagation, and expiry still matter. See [Balance-Proportional Scheduling](pages/how-it-works/storage-economics.md#balance-proportional-scheduling) for the allocation rules.



## Storage Costs

The address that owns stored data funds its deposit. The runtime accounts for storage changes; your contract does not calculate the deposit itself. Delete data you no longer need with `delete()` or `Map::delete_at` to release its deposit. See [Storage: Refundable Deposits](pages/how-it-works/storage-economics.md#storage-refundable-deposits) for funding and cost rules.

Next, [Storage Types](pages/programming-model/storage-types.md) turns this model into concrete API choices.

---

## Storage Types

Source: <https://thruput.network/docs/programming-model/storage-types/>

SDK storage types, their conflict semantics, and how to choose between them.

Start with `Balance` for nonnegative counts and amounts. It exposes reads, increases, and decreases without requiring you to manage the underlying integer base. The storage type you choose determines whether concurrent writes merge, conflict, or ignore each other.

This page explains behavior and tradeoffs. For exact method signatures, see [Storage Types Reference](pages/reference/storage-types.md) or [`thruput_sdk::storage` Rustdoc](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html).



## Balance

Nonnegative, zero-defaulting storage for counters, balances, allowances, and supply. `Balance` uses `i128` amounts in `0..=i128::MAX`, rejects negative inputs, and exposes no signed adjustment or absolute `set`.

```rust
use thruput_sdk::storage::Balance;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}
```

Read with `self.value.get()`. A never-written value returns zero; other storage failures still abort. With a snapshot value of `100`, these changes can merge:

```rust
// Two transactions run against a snapshot value of 100:
self.value.increase(5);   // Tx A: "add 5"
self.value.decrease(3);   // Tx B: "subtract 3"
// If both transactions are admitted, the result is 102.
```

Both methods check bounds during execution and record relative changes. The runtime also checks aggregate bounds when it reserves concurrent transactions. Two decreases that each fit the snapshot may still exceed it together, and credits from other transactions in the same block do not count toward a decrease. Successful execution alone does not guarantee inclusion. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas).



### Checked and lazy updates

For per-account amounts, combine Balance with a Map:

```rust
use thruput_sdk::{storage::{Balance, Map}, ContractAddress};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

Each direction has a checked and lazy form:

```rust
let sender = get_caller();

// Load the sender and fail during execution if funds are insufficient.
self.balances.at_mut(&sender).decrease(amount);

// Skip the receiver load and defer its bound check.
self.balances.at_mut(&receiver).lazy_increase(amount);
```

All four adjustment methods record deltas that can merge with compatible transactions:

| Method                  | Snapshot base      | Snapshot-bound result                        | Deltas merge? |
| ----------------------- | ------------------ | -------------------------------------------- | ------------- |
| `increase(amount)`      | Loaded if needed   | Overflow detected during contract execution  | Yes           |
| `decrease(amount)`      | Loaded if needed   | Underflow detected during contract execution | Yes           |
| `lazy_increase(amount)` | Not forced to load | Overflow decided during delta reservation    | Yes           |
| `lazy_decrease(amount)` | Not forced to load | Underflow decided during delta reservation   | Yes           |

The `try_` variants report errors that are available during contract execution, so a contract can translate an immediate failure into a domain error. Lazy variants cannot report a snapshot-bound failure that they deliberately did not load. They can still report conversion and transaction-local accumulated-delta errors.



## NNInt

`NNInt` is the lower-level integer API behind Balance. Use it when your state model needs a signed delta or an explicit base. For ordinary nonnegative counts and amounts, keep using Balance.

```rust
use thruput_sdk::storage::NNInt;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct IntegerState {
    value: NNInt,
}
```

The direction is part of the delta:

```rust
// Two transactions run against a nonnegative snapshot value of 100:
self.value.strict_inc(5);    // Tx A: "add 5"
self.value.strict_inc(-3);   // Tx B: "subtract 3"
// If both transactions are admitted, the result is 102.
```

`strict_inc` loads the base for an immediate underflow check; `inc` skips the forced read. Both produce deltas that can merge when their resolved bases match and aggregate bounds permit. Unlike Balance, `NNInt::get` fails on missing storage, and `set` can replace the base, including with a negative value. Negative bases change the commit-time floor.

Continue with [NNInt and concurrent updates](pages/programming-model/nnint.md) for the `set_add` representation, base matching, and negative-base rules. Balance provides a narrower API over that same storage primitive; it does not use a different merge mechanism.



## Map\<K, V>

Key-value store. Different keys use independent storage locations. Same-key behavior follows the value type’s rules. Other shared writes or storage-funding limits can still prevent the complete transactions from landing together.

```rust
use thruput_sdk::{storage::{Balance, Map}, ContractAddress};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

```rust
// Different keys: always independent, never conflict
self.balances.at_mut(&alice).lazy_increase(10);  // Tx A
self.balances.at_mut(&bob).lazy_increase(20);    // Tx B, no interaction

// Same key: follows Balance rules (compatible deltas merge)
self.balances.at_mut(&alice).increase(10);       // Tx A
self.balances.at_mut(&alice).lazy_increase(20);  // Tx B, merges to +30
```

Maps can nest: `Map<K, Map<K2, Balance>>` gives composite keys with independent conflict domains at each level. The ERC-20 allowance pattern uses this for owner and spender pairs.

Maps cannot enumerate keys, so a whole `Map` cannot be deleted. Delete one entry with `delete_at(&key)`, or call `delete()` on a deletable handle. Deleting data returns its [storage deposit](pages/how-it-works/storage-economics.md#storage-refundable-deposits).



## Bytestring

Raw bytes. Concurrent writes of the same value commute. Concurrent writes of different values conflict.

```rust
use thruput_sdk::storage::Bytestring;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Config {
    owner: Bytestring,
}
```

```rust
self.owner.set(&new_owner);    // Tx A
self.owner.set(&other_owner);  // Tx B: conflict, one excluded
```

Use Bytestring for raw configuration or metadata. Writers of different values to the same location conflict; writers of identical values can coexist.



## RCQ\<T> / RetrocausalQueue

Multi-producer, single-consumer queue. Inserts from different transactions merge. Persisted entries are ordered by queue block, then lexicographically within that block. Concurrent observations follow the proposer-recorded order.

```rust
// These two transactions can both land:
self.requests.insert(&entry_a);  // Tx A
self.requests.insert(&entry_b);  // Tx B: no conflict

// Consumes pull from the front of the queue
let entry = self.requests.try_consume();
```

Only one transaction per block can consume from a given queue; a second consumer is excluded. A queue accepts at most 250 inserted entries per block, and each entry is at most 256 bytes. Use `RCQ<T>` when producers are concurrent and one consumer processes items in order. Lower-level raw functions are available when you need byte-level control.



## CapacityConstraint

A commit-time limit shared by changes from multiple transactions. Use it for a rule that spans transactions, such as a supply cap or an aggregate withdrawal limit. A check against a snapshot read cannot enforce that rule, because [reads are not checked at commit](pages/programming-model/execution.md#snapshot-isolation).

```rust
use thruput_sdk::storage::CapacityConstraint;

#[thruput_sdk::storage]
pub struct WithdrawalLimit {
    remaining: CapacityConstraint,
}
```

```rust
// Reset at the start of a period.
self.remaining.set_capacity(period_limit);

// Each withdrawal consumes capacity without loading competing withdrawals.
self.remaining.consume_capacity(amount);
```

Consumption is staged on the handle and written when the handle is flushed or dropped. Call `try_flush()` to catch a flush error instead of aborting in drop. A negative amount releases capacity. The runtime enforces that the committed remaining capacity does not fall below its floor. As with `Balance`, all consumption in a block must fit the capacity the block started with; releases in other transactions do not count.

`set_capacity` must be the first write to that constraint in the transaction, except that repeating the same value is allowed. A reset uses `NNInt::set` rules: it conflicts with consumers in the same block unless it sets the current capacity value.



## Vector\<S>

Ordered collection. Each element is an independent storage slot. Internally backed by a `Map<u32, S>` for elements and a length counter.

```rust
use thruput_sdk::storage::{Vector, Node, Value};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Item {
    value: Value<u64>,
}

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Registry {
    items: Vector<Node<Item>>,
}
```

```rust
// Push a new element
self.items.push_with(|item| {
    item.value.set(&42);
});

// Read by index (bounds-checked)
let val = self.items.at(0).value.get();

// Mutate by index
*self.items.at_mut(0).value.load_mut() = 99;

// Iterate
for item in &self.items {
    let v = item.value.get();
}
```

Different indices are independent and never conflict (same as Map). Same-index writes follow the element type’s rules. Pushes and pops write the length with an exclusive lock, so only one transaction per block can change a vector’s length. That transaction can push or pop several times.

Use Vector for ordered collections where elements are accessed by index. Wrap compound structs in `Node<T>` so storage derivation works through the nesting. For hot concurrent writes, Map with application-managed keys is more parallelism-friendly than Vector with pushes.



## Value\<T>

Typed storage slot. Stores any CXS-serializable value. Conflict semantics are the same as Bytestring: concurrent writes of the same value commute, different values conflict.

```rust
use thruput_sdk::{storage::Value, ContractAddress};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Config {
    owner: Value<ContractAddress>,
    threshold: Value<u64>,
}
```

```rust
let owner = self.owner.get();             // read (aborts if unset)
let result = self.threshold.try_get();    // read without aborting
self.owner.set(&new_owner);               // write
*self.threshold.load_mut() = 10;          // read-modify-write
```

Use `Value<T>` for typed single-slot storage. Use `Bytestring` when you need raw byte access or variable-length data without a fixed schema.



## Choosing a Type

| If your write pattern is…                        | Use                | Why                                                                             |
| ------------------------------------------------ | ------------------ | ------------------------------------------------------------------------------- |
| Nonnegative count, balance, allowance, or supply | Balance            | Nonnegative amounts, zero default, and checked or lazy deltas.                  |
| Signed delta or explicit integer base            | NNInt              | Signed deltas merge and `set` controls the base.                                |
| Cap or limit that spans transactions             | CapacityConstraint | The runtime enforces the limit across the block; a snapshot read cannot.        |
| `INSERT INTO ... (key, value)` with unique keys  | Map                | Different keys are independent.                                                 |
| Ordered list, accessed by index                  | Vector             | Per-element independence. One transaction per vector per block can push or pop. |
| Store a typed value                              | Value\<T>          | Typed Bytestring. Same conflict rules.                                          |
| `col = absolute_value` (raw bytes)               | Bytestring         | Accept that concurrent writes conflict.                                         |
| Append to a log or work queue                    | RCQ\<T>            | Inserts merge. One consumer per queue per block.                                |



## Exclusive Writes

Use exclusive writes when an operation needs sole write access to a storage location for the duration of a block. Compatible deltas normally merge; an exclusive write prevents concurrent modifications to that key.

- `Value<T>::set_exclusive(&v)`: one exclusive write to a typed slot.
- `Map::at_mut_exclusive(&key)`: every write through the returned handle (`Value`, `Balance`, `NNInt`, `Bytestring`, or nested fields) requests the lock.
- `Deletable::delete_exclusive()`: delete, then request the lock.
- Raw keys: `non_negative_int_set_exclusive`, `bytestring_set_exclusive`, `delete_exclusive`, or `set_storage_flags`.

```rust
self.config.set_exclusive(&new_value);          // Value<Config>
self.integer_state.at_mut_exclusive(&owner).set(v);  // Map<_, NNInt>
```

If two transactions write exclusively to the same key, one is excluded. An exclusive write is also excluded if another transaction in the block has already written that key. Once an exclusive write is admitted, every later write to the key in that block is excluded. Whichever transaction reserves first wins. Prefer `Balance` or `NNInt` deltas when the operation can tolerate concurrent updates.



### Lock Requests

An exclusive write requests `ExclusiveLock` after the write succeeds. Later ordinary writes to the key in the same transaction keep the request, including writes from other call frames. The admitted transaction then holds the key’s exclusive lock for the whole block. `clear_flags` withdraws the request.

```rust
self.integer_state.at_mut_exclusive(&owner).set(0);
self.integer_state.at_mut(&owner).inc(1);  // The lock request remains.
```

A reverted frame or failed `try_invoke` discards its flag changes along with its writes. Leaf handles implement `Flaggable` to read, add, or clear flags; see [Flaggable Trait](pages/reference/storage-types.md#flaggable-trait) and [Storage Flags](pages/reference/syscalls.md#storage-flags).

If `Balance` covers your state model, you do not need its lower-level representation. Read [NNInt and concurrent updates](pages/programming-model/nnint.md) when you need signed changes, an explicit base, or the exact `set_add` commutativity rules. For runtime reservation details, continue to [Parallel Execution](pages/how-it-works/execution-model.md).

---

## NNInt and concurrent updates

Source: <https://thruput.network/docs/programming-model/nnint/>

The set_add primitive underneath NNInt and why concurrent transactions merge.

`NNInt` is the lower-level signed-integer storage API underneath [`Balance`](pages/programming-model/storage-types.md#balance). This page explains its `set_add` representation and why concurrent transactions can merge safely.

Start with `Balance` for nonnegative counters, balances, allowances, and supply. Read this page when you need signed changes, an explicit integer base, or the exact representation that makes checked and lazy balance deltas compatible.

For exact SDK method signatures, see [Rust API Docs](pages/tools/rust-api-docs.md) or [Storage Types Reference](pages/reference/storage-types.md#nnint).



## From Balance to NNInt

Balance gives each direction a name: `increase(5)` adds five and `decrease(3)` subtracts three. NNInt exposes the signed delta directly: `strict_inc(5)` and `strict_inc(-3)`. Both APIs record relative changes. Checked operations load the base for early bound checks; lazy operations defer snapshot-bound checks to reservation.

Balance also enforces a nonnegative value and supplies zero for missing storage. NNInt adds control over the base through `set`, and its `get` fails on missing storage. Use that lower-level control only when the state model needs it.



## The set_add Primitive

Every NNInt storage location maintains two pending values during a transaction:

- **set**: `i128`. The absolute base value.
- **add**: `i128`. The accumulated delta.

The low-level operation is `set_add(set_value, add_value)`. It replaces both pending values. The final committed value is `set + add`, subject to overflow, reservation, and floor checks. The storage handle’s `strict_inc`, `inc`, and `set` methods map to this operation.



## The One Rule

Two concurrent `set_add` calls commute **if and only if their resolved set values are equal**.

The bases must match each other; they do not have to equal the snapshot value.

| Tx A              | Tx B                         | Result                                                  |
| ----------------- | ---------------------------- | ------------------------------------------------------- |
| `set_add(S, x)`   | `set_add(S, y)`              | Merge: same base, adds combine to `x + y`               |
| `set_add(100, x)` | `set_add(100, y)`            | Merge: same explicit base, even if snapshot != 100      |
| `set_add(A, x)`   | `set_add(B, y)` where A != B | **Conflict**: different bases, one transaction excluded |

A merge still has to fit in `i128` and respect the floor described in [Negative Set Values](pages/programming-model/nnint.md#negative-set-values). All negative deltas admitted in a block must fit within the base; positive deltas from other transactions do not offset them.



## The None Path

`set_add` also accepts `None` as the set value: `set_add(None, add_value)`. This means “I don’t need to choose the base in this transaction. Let the runtime resolve it from the snapshot.”

The runtime resolves `None` to the start-of-block value, or to `0` if the key is absent or not an NNInt. This skips the snapshot read in the contract and gives the same result as loading the base yourself.

| Tx A               | Tx B                                | Commutes?                                     |
| ------------------ | ----------------------------------- | --------------------------------------------- |
| `set_add(None, x)` | `set_add(None, y)`                  | Yes: both resolve to the start-of-block value |
| `set_add(None, x)` | `set_add(S, y)` where S = snapshot  | Yes: same effective base                      |
| `set_add(None, x)` | `set_add(S, y)` where S != snapshot | **No**: different resolved bases              |



## How the API Maps to set_add

| Method              | Effective call                                       | Loads the base? | Commutes?                                         |
| ------------------- | ---------------------------------------------------- | --------------- | ------------------------------------------------- |
| `strict_inc(delta)` | `set_add(Some(base), accumulated + delta)`           | Yes             | When resolved bases match                         |
| `inc(delta)`        | `set_add(existing_set_or_None, accumulated + delta)` | No              | When resolved bases match                         |
| `set(value)`        | `set_add(Some(value), 0)`                            | No              | Only if all concurrent callers set the same value |

**strict_inc(delta)** loads the base (a pending explicit set, the snapshot value, or `0` for an empty key) and aborts immediately if the transaction’s running total would be negative. Use it when you want an early underflow check.

**inc(delta)** keeps a pending explicit set if this transaction has one; otherwise it uses the `None` path and skips the read. Underflow is caught later, during reservation, which can be harder to debug.

**set(value)** replaces the base and clears the delta. `set(100)` merges with `set(100)` and conflicts with `set(200)`. It conflicts with a concurrent `strict_inc` or `inc` unless the snapshot is 100. Reserve `set` for initialization or admin operations.

`strict_inc` and `inc` merge with each other when their resolved bases match. Choose between them based on read cost and the need for early underflow detection.



## Negative Set Values

Despite the protocol name `NonnegativeInt`, an explicit `set` can be negative. The commit-time invariant is:

```text
value >= min(set, 0)
```

A negative base becomes the floor. An increment can move the value up from it, but nothing can subtract from it:

```rust
non_negative_int_set(key, -5);
non_negative_int_inc(key, 1);  // The value becomes -4.
// set_add(-5, -1) is rejected.
```

`strict_inc` rejects a running total that remains negative, so use `inc` or the raw functions for negative-base state. Use `Balance` for ordinary nonnegative counters, balances, and allowances. A negative NNInt base is a separate state model, not a way to represent a Balance.

Matching bases are required, but do not guarantee inclusion: aggregate bounds and other transaction changes still matter. See [Merged Deltas](pages/programming-model/execution.md#merged-deltas) for the contract-level model.

---

## Authorization

Source: <https://thruput.network/docs/how-it-works/authorization/>

How transaction signatures, address auth data, caller identity, and auth tokens work in Project Thruput.

Project Thruput treats addresses uniformly. An address can hold code, store auth data, receive calls, and originate transactions through either supported admission model.

Authorization has two layers:

1. **Transaction admission**: hogd checks the transaction’s auth claim and signatures before execution.
2. **Runtime authorization**: contracts use caller identity, explicit signature checks, and typed auth tokens while executing.

These layers are related but separate. Transaction admission decides whether the root transaction may enter the block. Runtime authorization decides what authority a contract gives to a caller or token it receives.



## Authorize an application operation

For an owner-controlled method, store the owner in `Value<ContractAddress>` and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), AccessError::NotOwner);
```

Define `AccessError` with [a contract exception](pages/contracts/errors.md#defining-errors). Initialize the owner through a guarded method and [deploy and initialize atomically](pages/cli/deploy-and-call.md#include-initialization) if the first caller becomes the owner.

`get_caller()` identifies the immediate caller. A forwarded call identifies the forwarding contract, not the original user. For authority passed through several frames, use the [typed auth-token model](pages/how-it-works/authorization.md#auth-tokens-and-signedt) below and validate its minter and payload.



## Transaction Admission

A `SignedTransaction` contains an inner transaction, decorated signatures, and, for pubkey accounts, the signing public key:

```text
struct DecoratedSignature {
  unsigned int public_key_id;
  Signature signature;
};

struct SignedTransaction {
  Transaction tx;
  DecoratedSignature signatures<>;
  PublicKey *pubkey_claim_key;
};
```

The source address is the root invocation’s `invoked_address`. Every transaction signature covers this preimage:

```text
cxs(DomainSeparator("Transaction")) || networkHash || txs(transaction)
```

`txs(value)` denotes its standard XDR encoding. The domain separator prevents a transaction signature from being interpreted as a signature over another object. The network hash binds the signature to one Project Thruput network and prevents cross-network replay.

The canonical transaction hash is `sha256(txs(transaction))`. It identifies the inner transaction and excludes signatures. It is distinct from both the signature preimage and the encoded `SignedTransaction` wrapper.



### Signature Schemes

| Scheme               | Public key  | Signature   | Notes                                                    |
| -------------------- | ----------- | ----------- | -------------------------------------------------------- |
| Ed25519              | 32 bytes    | 64 bytes    | Default scheme in the CLI                                |
| ML-DSA-65 (FIPS 204) | 1,952 bytes | 3,309 bytes | Pure ML-DSA with an empty context string, not HashML-DSA |

Both schemes sign the preimage above directly, with no extra pre-hash. ML-DSA-65 signing is randomized by default, so two valid signatures over one transaction can differ. The transaction hash stays the same because it excludes signatures.



## Admission Models

The transaction’s `AuthClaim` selects one of two admission models:

```text
enum AuthClaim switch (AuthClaimType claim_type) {
case kSourceAddressAuthData:
  struct {
    BitMap allowed_keys;
    Weight required_weight;
  } source_address_claim;

case kPubkeySignature:
  PubkeyAccountPreimage pubkey_preimage;
};
```



### Pubkey Accounts

`kPubkeySignature` authorizes an account whose address is derived from `PubkeyAccountPreimage { pubkey_hash, nonce }`. The preimage holds a hash of the public key, not the key itself:

```text
pubkey_hash = sha256(cxs(DomainSeparator("PublicKey")) || cxs(PublicKey))
```

The `PublicKey` encoding includes its scheme, so the same key bytes under Ed25519 and ML-DSA-65 give different addresses. The full key travels in `SignedTransaction.pubkey_claim_key`.

This derivation also changed Ed25519 addresses. A pubkey-account address saved before the Futurenet reset that introduced ML-DSA-65 does not match the same key now. Derive the address again from the key and update saved addresses.

hogd accepts the claim only when:

- the derived address equals the root invocation’s `invoked_address`;
- the source address has no registered `AddressAuthData`;
- the transaction has exactly one signature, with `public_key_id` 0;
- `pubkey_claim_key` is present and its hash equals `pubkey_hash`;
- the signature uses the same scheme as `pubkey_claim_key` (Ed25519 or ML-DSA-65) and verifies against it.

During root execution at an undeployed pubkey-account address, the runtime falls back to the network’s configured DefaultWallet contract. This gives a new pubkey account wallet behavior without first deploying code at its derived address. The fallback applies only to the root invocation.



### Source-Address Accounts

`kSourceAddressAuthData` authorizes the root invocation from auth data stored at its source address. The source address must have `AddressAuthData`; a source-address claim without it is rejected. A source-address claim must not carry `pubkey_claim_key`.

hogd checks:

- `allowed_keys` does not set bits beyond `kMaxSigners = 21`.
- Every signature’s `public_key_id` appears in `allowed_keys`.
- Signature `public_key_id` values are strictly increasing, so duplicates and out-of-order signatures are rejected.
- Each referenced key exists in the source address’s `AddressAuthData`.
- Each signature uses its registered key’s scheme and verifies against that key.
- The sum of matched key weights is at least `max(address.required_weight, claim.required_weight)`.

The threshold is `max(address.required_weight, claim.required_weight)`. This lets the address set a standing minimum while each transaction can require an equal or higher threshold.

Contracts can inspect the root transaction’s auth claim with [`get_auth_claim()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/auth_claim/fn.get_auth_claim.html), but admission has already happened by the time contract code runs. For a pubkey account, the claim exposes `pubkey_hash` and `nonce`, not the public key.



## Address Auth Data

`AddressAuthData` is stored under `StorageKeyType::AuthData` for an address:

```text
struct PublicKeyConfig {
  PublicKey key;
  Weight max_weight;
};

struct AddressAuthData {
  PublicKeyConfigOpt public_keys[21];
  Weight required_weight;
  BlockHeight last_written_height;
};
```

Each key slot is optional. Empty slots do not contribute weight.

An address can mutate only its own auth data. The SDK exposes the current syscalls as:

```rust
use thruput_sdk::{
    add_address_public_key,
    remove_address_public_key,
    set_address_required_weight,
};

add_address_public_key(0, public_key, 1)?;
set_address_required_weight(1)?;
remove_address_public_key(0)?;
```

Registered keys can be Ed25519 or ML-DSA-65. `add_address_public_key` accepts both schemes, and admission verifies each signature with its slot’s scheme.

Use these for source-address accounts, wallet contracts, and contracts that are meant to originate later transactions. Replay protection is transaction-level, through the transaction `Uniquifier`. `AddressAuthData` does not contain nonce policy or gas-sponsorship policy fields.



## Caller Identity

Inside a contract, [`get_caller()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_caller.html) returns the direct caller of the current invocation frame:

```rust
use thruput_sdk::get_caller;

let caller = get_caller();
```

This is Project Thruput’s equivalent of `msg.sender`: immediate caller identity. It is not a signer set and it does not tell you which key signed the root transaction. A root frame has no caller, so the underlying syscall errors there.

Use [`get_current_address()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_current_address.html) when a contract needs its own address.



## Contract Signature Checks

Contracts can verify arbitrary messages with [`verify_signature_ed25519()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/crypto/fn.verify_signature_ed25519.html):

```rust
use thruput_sdk::crypto::verify_signature_ed25519;

let ok = verify_signature_ed25519(&public_key, &signature, message);
```

Contract signature checks support Ed25519 and ML-DSA-65. `verify_signature()` takes a `PublicKey` and a `Signature` and verifies in the key’s scheme. ML-DSA-65 is pure ML-DSA with an empty context. `verify_signature_ed25519()` takes Ed25519 types only.

This is runtime logic, separate from transaction admission. A wallet contract can use it to accept an off-chain signature, apply its own policy, and then mint an auth token in the wallet contract’s name.



## Auth Tokens and `Signed<T>`

The SDK’s [`Signed<T>`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/struct.Signed.html) is a typed runtime auth-token handle. It is not a cryptographic signature and it is not a durable bearer token.

An auth token carries:

- **Minter**: set by the host to the current contract address at mint time.
- **Consumer**: the contract address allowed to consume the token.
- **Payload**: CXS-encoded typed data from the SDK.
- **Expiry height**: the token is valid through this block height.
- **Child nodes**: nested auth tokens that materialize when the parent is consumed.

`Signed<T>` is a handle to this runtime token. The handle travels out-of-band alongside calldata; it does not serialize the payload into the method argument bytes. Contract specifications represent it as a `SignedToken` node containing the payload type.

To make a payload type usable in a token, mark it as a contract type:

```rust
use thruput_sdk::*;

#[contract_type]
pub struct TransferAuth {
    pub to: ContractAddress,
    pub amount: i128,
}
```

Mint with [`mint_auth_token()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/fn.mint_auth_token.html):

```rust
use thruput_sdk::*;

let token: Signed<TransferAuth> = mint_auth_token(
    expiry,
    AuthTokenPreimage {
        consumer: token_contract,
        data: TransferAuth { to, amount },
    },
);
```

Consume with `Signed<T>::consume()`:

```rust
use thruput_sdk::*;

pub fn transfer_from(
    amount: i128,
    to: &ContractAddress,
    auth: Signed<TransferAuth>,
) {
    let (claim, minter) = auth.consume();

    assert!(minter == expected_wallet(), "unauthorized minter");
    assert!(claim.to == *to, "unauthorized recipient");
    assert!(amount <= claim.amount, "exceeds authorized amount");

    // Move funds from `minter` to `to`.
}
```

Consuming proves only two things: the token was minted by the returned `minter`, and the token was destined for the current contract. Any contract can mint a token whose payload decodes as `TransferAuth`. Always check the returned minter against an address your contract trusts before acting on the payload.



## Passing Auth Tokens

Auth tokens never flow implicitly across contract calls. Generated clients collect `Signed<T>` handles from arguments and pass those token ids to `Invoke` beside calldata. A callee receives only the tokens that appeared in its arguments.

Frame ownership works like this:

- When a parent forwards a token to a child call, the child owns that token while it runs.
- If the child returns the token in its return value, the parent receives it back.
- If the child aborts or the parent handles a reverted child frame, forwarded tokens are restored to the parent.
- If the child succeeds without returning a forwarded token, the parent does not automatically regain it.
- Consuming a token removes it. Any child tokens become fresh handles owned by the consuming frame.

This makes method signatures part of the authorization surface: a function that does not take a `Signed<T>` argument cannot consume that token.

Generated clients assign returned token handles to `Signed<T>` fields in the return value. Lower-level callers that receive a `Vec<Signed<Opaque>>` can use `AssumeTokens::try_assume_tokens` to convert an exact number of opaque handles into a typed tuple. A count mismatch returns `CallingError::DecodingSuccess`; `AssumeTokens::assume_tokens` is the throwing convenience form.



## Nested Auth Tokens

A token payload can contain `Signed<U>` fields. When the outer token is consumed, the runtime creates child-token handles for those fields. Child tokens keep the same minter and expiry as the parent, but each child has its own consumer address and payload.

```rust
use thruput_sdk::*;

#[contract_type]
pub struct DexIntent {
    pub pool: ContractAddress,
    pub deadline: BlockHeight,
    pub min_received: i128,
    pub transfer: Signed<TransferAuth>,
}

pub fn execute_swap(intent: Signed<DexIntent>) {
    let (intent, trader) = intent.consume();

    assert!(trader == expected_wallet(), "unauthorized trader");
    assert!(get_block_height() <= intent.deadline, "intent expired");

    // The nested transfer token is now a fresh handle that can be passed to
    // the token contract selected as its consumer.
    token_client.transfer_from(amount_in, &intent.pool, intent.transfer);
}
```

The outer token might be consumed only by the DEX. The nested transfer token might be consumed only by the token contract. Attribution stays with the original minter through the chain.



## Limits

The protocol caps an auth-token payload at 256 bytes and child nodes per token at 4. Network parameters cap tree depth (`max_auth_token_depth`, default 4) and token ids per `Invoke` or `Return` list (`max_auth_tokens`, default 64). `MintAuthToken` rejects malformed token nodes, expired-at-mint tokens, and tokens that would exceed runtime caps. `ConsumeAuthToken` rejects tokens not owned by the current frame, expired tokens, and already-consumed handles.



## Not Landed

Do not rely on these patterns yet:

- Detached admission-time signatures that directly become `Signed<T>` values.
- Nonce or gas-sponsorship policy fields in `AddressAuthData`.
- Durable, storable, or off-chain portable `Signed<T>` handles. A `Signed<T>` is a runtime handle owned by invocation frames inside a transaction.



## See Also

- [Invocation Frames](pages/how-it-works/invocation-frames.md)
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)
- [Syscalls](pages/reference/syscalls.md)
- [SDK Macros](pages/reference/sdk-macros.md)
- [Rust API Docs](pages/tools/rust-api-docs.md)

---

## Handle errors

Source: <https://thruput.network/docs/contracts/errors/>

How errors work in Project Thruput contracts.

Exported Project Thruput contract methods return their declared values and signal failure by throwing an exception. The frame aborts, all state changes in that frame are discarded, and control returns to the caller. Private helpers may use `Result` when they translate failures into a contract or library exception.

You cannot catch a thrown exception within the same frame. Use `Result`-returning helpers for local fallible work and generated `try_*` client methods for another contract. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md).

For exact SDK signatures, see [Rust API Docs](pages/tools/rust-api-docs.md).



## Defining Errors

Use `#[contract_exception]` to define error types. It generates `Debug`, `PartialEq`, serialization and spec traits, and the `Exn` implementation. Add `Clone` yourself if the type needs it.



### `thiserror` and `anyhow`

You can use `thiserror` with `#[contract_exception]` when you want `Display` messages for logs, tests, or off-chain tooling. Put `#[derive(thiserror::Error)]` on the exception type and use `#[error("...")]` on each variant:

```rust
use thruput_sdk::*;

#[derive(thiserror::Error)]
#[contract_exception]
pub enum CounterError {
    #[error("not authorized")]
    NotAuthorized = 1,
}
```

Do not copy the usual `#[derive(Error, Debug)]` pattern from generic Rust examples. `#[contract_exception]` already generates `Debug` and `PartialEq`; deriving them again creates duplicate implementations.

For contract crates, configure `thiserror` without the default `std` feature:

```toml
thiserror = { version = "2", default-features = false }
```

Avoid `anyhow` for contract exception types and public contract method surfaces. `anyhow::Error` is an erased application error type, while contract exceptions need concrete CXS-serializable types that appear in the contract spec. `anyhow` is fine in off-chain tools, build scripts, tests, or CLI code. Inside a contract, private helpers may use `Result` if they immediately convert failures into concrete contract exceptions with `throw`, `ensure`, or `or_throw`.



### Enum errors

Enum errors carry variant-level meaning. Each variant gets an explicit `i32` discriminant. The macro adds `#[repr(i32)]` for you.

```rust
use thruput_sdk::*;

#[contract_exception]
pub enum ERC20Error {
    AlreadyInitialized = 1,
    MustBeContractOwner = 2,
    TooLarge = 3,
    BalanceNotZero = 4,
    NegativeAmount = 5,
    Internal = 100,
}
```



### Struct errors

Struct errors work when you only need a single error type with no variants.

```rust
use thruput_sdk::*;

#[contract_exception]
pub struct Unauthorized;
```

Structs with fields work too:

```rust
#[contract_exception]
pub struct InsufficientBalance {
    pub balance: u64,
}
```



## Throwing Errors



### `throw(exn)`

Aborts the current frame with the given error. Never returns.

```rust
use thruput_sdk::*;

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    if amount < 0 {
        throw(ERC20Error::NegativeAmount);
    }
    // ...
}
```



### `ensure(condition, error)`

Throws `error` if `condition` is false. A convenience wrapper around `throw`.

```rust
use thruput_sdk::*;

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    ensure(
        get_caller() == self._administrator(),
        ERC20Error::MustBeContractOwner,
    );

    self._increase_total_supply(amount);
    self._lazy_increase_balance(receiver, amount);
}
```



### `result.or_throw(exn)`

Extension method on `Result`. Returns the `Ok` value, or throws `exn` on `Err`. Useful for converting fallible operations into contract exceptions.

```rust
use thruput_sdk::*;

fn _decrease_balance(&mut self, owner: &ContractAddress, amount: Amount) {
    self.balances
        .at_mut(owner)
        .try_decrease(amount)
        .or_throw(ERC20Error::TooLarge);
}
```



## Automatic Aborts

The SDK throws `LibraryExn` errors automatically when internal preconditions fail. You do not need to define error variants for these.

| Operation                                 | Throws when                                                                                         |
| ----------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `Balance::decrease(amount)`               | Balance is insufficient (`NonNegativeIntUnderflow`)                                                 |
| `Balance::increase(amount)`               | Balance would overflow (`NonNegativeIntOverflow`)                                                   |
| `NNInt::strict_inc(delta)`                | Result would be negative (`NonNegativeIntUnderflow`)                                                |
| `NNInt::strict_inc(delta)`                | Result would overflow (`NonNegativeIntOverflow`)                                                    |
| `CapacityConstraint::set_capacity(value)` | Another non-idempotent write already occurred this transaction (`CapacityConstraintAlreadyWritten`) |
| `bytestring_get_sized`                    | Stored length does not match expected (`BytestringWrongSize`)                                       |
| `NNInt::get()`                            | Key does not exist (syscall error); `Balance::get()` defaults missing storage to zero               |

```rust
// Aborts automatically if balance would go below zero.
// No error handling code needed.
balance.decrease(amount);
```

Every public SDK function whose name starts with `try_` reports its own failures through `Option` or `Result` instead of aborting. Storage `try_` getters return `Result<T, LibraryExn>`. Use `error.is_storage_missing()` to identify absence, or `.none_if_missing()` to convert only absence into `None` while re-throwing other failures.



## LibraryExn

`LibraryExn` is the SDK’s built-in error enum. It covers all errors generated by SDK internals and runtime operations.

| Variant                                              | Discriminant | Trigger                                                                                                                                                                                                 |
| ---------------------------------------------------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Syscall(SyscallExn)`                                | 0            | A host syscall returned an error (e.g. storage key not found)                                                                                                                                           |
| `Handling(HandlingError)`                            | 1            | Error while handling an incoming contract call (decoding args, encoding result)                                                                                                                         |
| `Calling(CallingError)`                              | 2            | Error while making an outgoing contract call: encoding args, decoding the result, or the runtime refusing the invoke as reentrant (`Reentrance`) or past the cross-invoke depth bound (`DepthExceeded`) |
| `Called(FaultString)`                                | 3            | The called contract reverted                                                                                                                                                                            |
| `AuthToken(AuthTokenError)`                          | 4            | Error encoding or consuming an authorization token                                                                                                                                                      |
| `BytestringWrongSize { expected, found }`            | 5            | A fixed-size bytestring read found a different length                                                                                                                                                   |
| `NonNegativeIntUnderflow`                            | 6            | An integer or balance operation would violate its lower bound                                                                                                                                           |
| `NonNegativeIntOverflow`                             | 7            | An integer or balance operation would overflow                                                                                                                                                          |
| `StorageSerialization`                               | 8            | A typed storage value could not be serialized or deserialized                                                                                                                                           |
| `StorageIndexOutOfBounds { len, access }`            | 9            | A vector index was outside its logical extent                                                                                                                                                           |
| `StorageKeypathOverflow`                             | 10           | A no-allocation storage keypath exceeded its fixed budget                                                                                                                                               |
| `RetrocausalQueueEntryWrongSize { expected, found }` | 11           | A fixed-size queue read found a different entry length                                                                                                                                                  |
| `CapacityConstraintAlreadyWritten`                   | 12           | `set_capacity` followed an incompatible write in the same transaction                                                                                                                                   |
| `UnknownMethod`                                      | 13           | The callee has no entrypoint for the invoked method ID                                                                                                                                                  |

`LibraryExn` is `#[non_exhaustive]`: when matching, always include a wildcard arm.

Generated `try_*` calls can return a `LibraryExn` thrown by the callee. See [Library errors](pages/contracts/errors.md#library-errors) below for an example.



## Cross-Contract Errors

A thrown exception travels as `[selector][payload]`, where the selector is derived from the exception *type*, not from the interface that threw it. Callers match on that selector, so what a caller can catch does not depend on what the callee’s interface declared.

`throws` declares an interface’s error contract: it is published in the contract spec and tells callers what to expect. It does not gate catching.



### Declaring thrown errors

Single error type:

```rust
#[contract(client = CounterClient, throws = CounterError)]
impl Counter {
    // ...
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    // ...
}
```



### Catching errors with `try_*` methods

Every method on the generated client has a `try_` variant returning `Result<T, CallError>` instead of aborting. `CallError` is the same type for every client; a caught exception stays undecoded inside it, and `match_exn!` decodes it against the types you name:

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(val) => {
        // Success
    }
    Err(CallError::Fault(f)) => {
        // The called contract panicked
    }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => {
            // Handle the expected error
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Fault`, `Invalid`, and encode/decode failures with ordinary `match` arms on `CallError`. `match_exn!` handles only the typed part, and its arms are tried in order, so a final `_` arm is required.



### Library errors

`LibraryExn` is matched like any other exception type. There is no special wrapper variant:

```rust
match client.try_do_something() {
    Err(e) => match_exn!(e, {
        LibraryExn::NonNegativeIntUnderflow => {
            // The called contract underflowed an NNInt
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```



### Non-try calls and re-throwing

Non-try client methods (e.g. `client.do_something()` without the `try_` prefix) automatically re-throw any exception from the called contract. The error propagates through the call chain with its original selector intact.



### Undeclared errors

An error type absent from `throws` is caught exactly like a declared one. The selector identifies it either way:

```rust
match client.try_throw_undeclared() {
    Err(e) => match_exn!(e, {
        SecretError => {
            // Never declared by the interface; matched all the same
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```

This is what lets an extension define errors the base interface does not declare. `ERC20PausableError::EnforcedPause` can come back from `ERC20::transfer`, and an `ERC20Client` caller matches it in the same `match_exn!` as `ERC20Error`, no separate decode step, and no coupling of the base interface to the extension.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&to, 1).unwrap_err().try_as(),
    Some(ERC20PausableError::EnforcedPause),
);
```

`None` covers all three ways this can miss: no exception, a different type, or a payload that failed to decode. Use `try_decode` when the last of those must be distinguished from the other two. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one), which also explains how this can occur through semver-compatible evolution.

See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) for the full calling patterns.

---

## Events

Source: <https://thruput.network/docs/contracts/events/>

Define, declare, emit, and test typed events in a Rust contract.

Events expose contract activity to applications. A contract emits topics for filtering and a payload for the data consumers need to read. Use storage for state your contract must read later; contracts cannot read events back.



## Define an event

```rust
use thruput_sdk::*;

#[derive(Event, Clone, Debug)]
pub struct CounterIncremented {
    #[topic]
    pub by: ContractAddress,
    pub amount: u64,
}
```

`#[derive(Event)]` generates the event signature, topic encoding, and a payload type. Topic 0 is the signature. Up to two fields can use `#[topic]`; fields without it go into the CXS-encoded payload.

Here, consumers can filter on `by` and read `amount` from the payload. Strings and byte slices used as topics retain only a hash, so also include them in the payload if consumers need their original values. The total size of topics and payload is limited to 1,024 bytes.



## Declare and emit it

Add the event to a counter method to record the amount and caller:

```rust
use thruput_sdk::storage::Balance;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}

#[contract(emits(CounterIncremented))]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.increase(amount as i128);
        log_event(&CounterIncremented {
            by: get_caller(),
            amount,
        });
    }
}
```

`get_caller()` identifies the immediate caller of this frame. For a forwarded call, that is the forwarding contract.

`emits(...)` records the event in the contract spec. Put it on the inherent implementation or interface trait definition, not on a trait implementation. When adding an event to an existing contract, retain its other event and error declarations.



## Test an emitted event

Export the event alongside the generated client from your contract library. In a native test, call `increment` and inspect the returned `TransactResult`:

```rust
let result = env.transact(|tx| {
    tx.call(&caller).run(|| {
        CounterClient::new(&address).increment(5);
    })
});
result.assert_success();
result.assert_event_count(1);
result.assert_event::<CounterIncremented>(0, |event| {
    assert_eq!(event.topic(0), Some(CounterIncremented::SIGNATURE));
    let by: &ContractAddress = event.topic(1).unwrap().into();
    assert_eq!(by, &caller);
    assert_eq!(event.payload().amount, 5);
});
```

Here, `env` is the test environment, `caller` is the calling address, and `address` is the deployed test contract. See [Testing](pages/programming-model/testing.md#basic-pattern) for registration and deployment setup.

The event count covers all contracts called by the test transaction. Assert both topics and payload so the test checks the event’s content, not only its presence.



## Include the event in the interface

Rebuild after changing an event declaration. The generated spec records its name, signature, topic layout, and payload layout. [Client bindings](pages/contracts/client-bindings.md) use that metadata to expose the event to applications.

For library-emitted events that no interface declares, `#[event_spec(export)]` explicitly includes the type in the linked contract’s spec. See the [event macro reference](pages/reference/sdk-macros.md#deriveevent) for the generated API.

Use [Read events](pages/typescript/events.md) for application queries, receipt decoding, and pagination.

---

## Cross-Contract Calls

Source: <https://thruput.network/docs/contracts/cross-contract-calls/>

Calling other contracts from your contract.

Use a generated Rust client to call another contract through its interface. Direct calls propagate failures; `try_*` calls let your contract inspect them. These are onchain clients, separate from the TypeScript clients used by applications.



## Client Generation

On a trait definition or inherent impl, `#[contract]` generates a client struct, named `{Interface}Client` unless you override it with `client = CustomName`. The client mirrors every public method on the trait or impl block.

For interface design, see [Methods and interfaces](pages/contracts/methods.md). For macro parameters, see [SDK Macros](pages/reference/sdk-macros.md#contract).

Single error type:

```rust
#[contract(client = ERC20Client, throws = ERC20Error)]
pub trait ERC20 {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount);
    fn get_balance_of(&self, addr: &ContractAddress) -> Amount;
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    fn succeed() -> u32;
    fn throw_alpha_not_found();
    fn throw_beta_denied();
}
```

For each method `foo`, the generated client provides:

| Method         | Signature                            | On error                                                                                                 |
| -------------- | ------------------------------------ | -------------------------------------------------------------------------------------------------------- |
| `foo(...)`     | Same return type as the trait method | Re-throws. Your contract aborts too.                                                                     |
| `try_foo(...)` | `Result<T, CallError>`               | Returns the error for inspection. Match it with `match_exn!`, or decode it with `try_as` / `try_decode`. |



## Making Calls

Construct a client with the target contract’s address, then call methods on it.

```rust
let token = ERC20Client::new(&token_addr);
let balance = token.get_balance_of(&account);
token.transfer(&recipient, 100);
```

Client methods take `&self` (not `&mut self`). Clients are lightweight value types holding an address and configuration.



## Gas Limits

Use `with_gas_limit` to cap how much computation the callee can perform. It returns a new client instance (non-mutating).

```rust
let token = ERC20Client::new(&token_addr);
let capped = token.with_gas_limit(500_000);
capped.transfer(&recipient, 100);
```

The default request is `u64::MAX`; the child is still bounded by the caller’s remaining gas. Use an explicit cap when the callee should receive less. See [Contract Execution](pages/programming-model/execution.md#gas) for details.

| Method                      | Signature                               | Description                                                                                               |
| --------------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `new(address)`              | `fn new(&ContractAddress) -> Self`      | Create a client for the given contract address.                                                           |
| `with_gas_limit(gas_limit)` | `fn with_gas_limit(&self, u64) -> Self` | Return a new client with the specified gas limit.                                                         |
| `with_commit_locking()`     | `fn with_commit_locking(&self) -> Self` | Ask the child frame to acquire its commit locks before returning, so a `try_` call can handle a conflict. |
| `with_read_only()`          | `fn with_read_only(&self) -> Self`      | Prevent the child frame from modifying state.                                                             |

`with_commit_locking()` and `with_read_only()` return a configured copy of the client. They can be combined:

```rust
let result = ERC20Client::new(&token_addr)
    .with_commit_locking()
    .with_read_only()
    .try_get_balance_of(&account);
```

Commit locking performs early conflict detection at the child-frame boundary. If lock acquisition fails, the child reverts and a `try_` method can inspect the failure. Read-only calls may read storage but cannot write, deploy a contract, or perform another state-changing operation.



## Error Handling



### Direct calls (re-throw)

Direct calls propagate errors automatically. If the callee throws, your contract throws the same exception to its own caller. No error handling needed or possible.

```rust
let client = MultiClient::new(&addr);

// If this throws AlphaError::NotFound, your contract
// re-throws the same error to whoever called you.
client.throw_alpha_not_found();
```



### try\_ calls (inspect)

Prefixing any method with `try_` returns a `Result` you can match on. The error type is the SDK’s `CallError`, the same type for every client.

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(()) => { /* success */ }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => { /* handle this error */ }
        _ => e.re_throw(),
    }),
}
```



### CallError

`try_*` does not pre-decode the exception into a per-interface enum. A caught exception stays a `RawException`, and `CallError` describes only how the call failed:

```rust
pub enum CallError {
    Invalid,
    Reentrance,
    DepthExceeded,
    InvokeRejected(SysErr),
    Exception(RawException),
    Fault(FaultInfo),
    UnparseableReturn(FaultString),
    UnparseableAbort(FaultString),
    UnparseableAuthHandles(FaultString),
    EncodingArgs(FaultString),
}
```

| Variant                               | When it appears                                                                                                                                                                                                                                       |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Invalid`                             | The call could not be made (e.g. invalid contract address before the call dispatched).                                                                                                                                                                |
| `Reentrance`                          | The target already had a frame open on the invocation stack, so the runtime refused the call as reentrant. See [`Reentrance`](pages/reference/syscalls.md) in the syscall errors.                                                                     |
| `DepthExceeded`                       | Admitting the call would have exceeded the network’s cross-invoke depth bound. The same call succeeds from a shallower frame.                                                                                                                         |
| `InvokeRejected(SysErr)`              | The invoke syscall was refused for another reason, carrying the raw syscall error.                                                                                                                                                                    |
| `Exception(RawException)`             | The callee threw. Any exception type, declared in `throws` or not, including the SDK’s own `LibraryExn`.                                                                                                                                              |
| `Fault(FaultInfo)`                    | The callee panicked, trapped, or exhausted gas. Child faults carry no diagnostic message across the call boundary. `FaultInfo` exists on every target and is zero-sized without `dev`; only a native root-frame panic can retain harness diagnostics. |
| `UnparseableReturn(FaultString)`      | The callee committed but its return buffer could not be decoded as the expected type.                                                                                                                                                                 |
| `UnparseableAbort(FaultString)`       | The callee aborted but the abort payload could not be parsed.                                                                                                                                                                                         |
| `UnparseableAuthHandles(FaultString)` | The callee committed but the returned auth-token handle list was malformed.                                                                                                                                                                           |
| `EncodingArgs(FaultString)`           | The caller’s arguments could not be encoded before dispatch.                                                                                                                                                                                          |

The first four variants mean the callee never ran: the invoke syscall was refused before any child frame opened, so the call was a complete no-op that observed nothing and wrote nothing. `CallError::is_rejected_before_call()` tests for exactly that set, which is the distinction to reach for when a retry or a fallback is only safe if the callee did not execute.



### Matching exceptions with `match_exn!`

An exception carries a selector derived from its type, independent of any interface’s `throws` list. `match_exn!` matches on that, so errors from different interfaces are peers:

```rust
match client.try_transfer(&recipient, 100) {
    Ok(()) => { /* transfer succeeded */ }
    Err(CallError::Fault(f)) => {
        // The callee panicked
    }
    Err(e) => match_exn!(e, {
        ERC20Error::MustBeContractOwner => {
            // Caller is not the owner
        }
        ERC20PausableError::EnforcedPause => {
            // Declared by an extension the ERC20 interface knows nothing
            // about, matched here exactly like a declared error
        }
        LibraryExn::NonNegativeIntUnderflow => {
            // SDK-level failure inside the callee
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Ok`, `Fault`, `Invalid`, and encode/decode failures with an ordinary `match`. `match_exn!` only does typed downcasting, and its arms are tried in order, so it requires a final `_` arm.

Two rules follow from how the macro infers the type from each arm’s pattern:

- Every typed arm must be path-rooted (`Type::Variant`, `Type::Variant { .. }`, or a unit-struct `Type`). A bare identifier would be a binding, leaving nothing to infer the type from; `_` is the untyped escape hatch, and the error value is still in scope there.
- `|` cannot combine patterns of different exception types. Alternates within one type are fine.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&recipient, 100).unwrap_err().try_as(),
    Some(ERC20Error::MustBeContractOwner),
);
```

`None` covers all three ways this can miss: the failure carried no exception, it carried a different type, or the payload failed to decode.



### Telling a corrupt error from an unknown one

`try_as` returns `None` both for a selector belonging to another type and for a matching selector whose payload will not decode, and `match_exn!` sweeps both into `_`. `try_decode` separates them:

```rust
match client.try_call_something().unwrap_err().try_decode::<SomeKnownError>() {
    Some(Ok(err)) => { /* decoded */ }
    Some(Err(_)) => { /* right selector, payload did not decode */ }
    None => { /* no exception, or a different type */ }
}
```

A version change can cause this distinction. An exception’s selector uses the first 8 bytes of `sha256(major_version :: crate :: type)`, not the payload layout. Adding an enum variant leaves the selector unchanged, but an older caller cannot decode that new variant. Use `try_decode` if your contract must distinguish an unknown type from an undecodable payload of a known type.

The reverse direction is not detectable at all: decoding reads a *prefix*, so a callee that **appends a field** to a struct exception is accepted silently by an older caller, which decodes the shorter shape and drops the extra data.



### Raw inspection

`RawException` also exposes `selector()` and `payload()` for inspecting bytes directly, and `re_throw()` to propagate the original abort verbatim.



## Error Forwarding

When contract A calls contract B with a direct (non-try) call and B throws, the error propagates through A to A’s caller with the original selector and payload intact. This means callers further up the chain can still decode the original error.

```rust
fn forward_alpha(target: ContractAddress) {
    // If target throws AlphaError::NotFound, this contract
    // re-throws it unchanged. Our caller sees AlphaError::NotFound.
    MultiClient::new(&target).throw_alpha_not_found();
}
```



## Full Example

A contract that calls an ERC20 token contract:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

pub use thruput_erc20_if as erc20_if;

use erc20_if::Amount;
use erc20_if::ERC20Client;
use thruput_sdk::storage::Value;
use thruput_sdk::*;

#[storage]
pub struct Caller {
    token_contract: Value<ContractAddress>,
}

#[contract(client = CallerClient)]
impl Caller {
    pub fn initialize(&mut self, token_contract: &ContractAddress) {
        self.token_contract.set(token_contract);
    }

    pub fn check_balance(&self, account: &ContractAddress) -> Amount {
        let token = ERC20Client::new(&self.token_contract.get());
        token.get_balance_of(account)
    }
}
```

See [Handle errors](pages/contracts/errors.md) for defining error types with `#[contract_exception]`.

---

## Invocation Frames

Source: <https://thruput.network/docs/how-it-works/invocation-frames/>

How contract calls track state, return results, and merge or discard child effects.

An invocation frame is the execution context for one contract call. A transaction begins with a root frame. A [cross-contract call](pages/contracts/cross-contract-calls.md) creates a child frame and returns control to its parent when it finishes.

The same model applies to RV32 contracts and native system contracts.



## Frame Structure

| Part          | Contents                                                                          |
| ------------- | --------------------------------------------------------------------------------- |
| Call context  | Contract address, entrypoint, calldata, invocation flags, and gas budget          |
| State changes | Storage operations and deployments made by this frame and its successful children |
| Events        | Events emitted by this frame and its successful children                          |
| Child result  | Status and return bytes from the most recent child call                           |
| Resource use  | Gas consumed by this frame and its children                                       |

A transaction’s root invocation has no child-call flags. A child’s gas budget is capped by its parent’s remaining budget. See [Invocation configuration](pages/contracts/cross-contract-calls.md) for SDK controls.



## Call Stack

```text
Root: wallet.execute
  Child: counter.increment
    Nested child: another contract method
```

Each child has its own execution context. Its ordinary reads use the block snapshot plus visible changes from the current transaction. A child call is part of that transaction, not a separate transaction or a separate block.



## Frame Lifecycle



### 1. Creation

The runtime creates a frame with the call context and an empty record of local changes and events.



### 2. Execution

Contract code uses [syscalls](pages/reference/syscalls.md) to read state, record changes, emit events, and call other contracts. Child calls can create further frames.



### 3. Completion

| Result           | Return bytes                                  | Contract effects                      |
| ---------------- | --------------------------------------------- | ------------------------------------- |
| **Return** (`0`) | Returned to the caller                        | Preserved for merging into the parent |
| **Fault** (`1`)  | Empty                                         | Discarded                             |
| **Abort** (`2`)  | Returned to the caller, usually as error data | Discarded                             |

A fault can result from an invalid instruction, invalid memory access, or exhausted gas. An abort is an explicit revert. SDK-generated wrappers use the Return syscall with its revert flag to produce a return or abort. Gas consumed before either failure remains consumed; it is computation metering, not a token fee.



### 4. Merge into Parent (or Finalize for Root)

On a successful child return, its storage changes, deployments, and events become part of the parent frame. They have not committed to the ledger yet. On a child abort or fault, those effects are discarded.

In either case, the parent receives the child’s status and return buffer and accounts for its gas use. A recoverable SDK call lets the parent inspect the failure. A throwing call propagates an unhandled failure. See [Cross-Contract Calls](pages/contracts/cross-contract-calls.md#error-handling).

When the root returns successfully, the transaction’s changes must still pass reservation against the proposed block. A committed root abort or fault records the failure while discarding contract effects; protocol bookkeeping such as replay protection remains. See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#root-frame-completion).



### 5. Pop and Return

The runtime discards the completed frame’s guest memory, registers, and stack. Control returns to the parent, or execution ends for the root. Only state written through the storage APIs can persist beyond execution.



## Example: Nested Contract Calls

Suppose contract A calls B, C, and D using recoverable calls:

| Step                         | Outcome                                          | Changes retained by A |
| ---------------------------- | ------------------------------------------------ | --------------------- |
| A writes `AAA`               | A continues                                      | `AAA`                 |
| B writes `BBB` and returns   | Child effects merge                              | `AAA`, `BBB`          |
| C writes `CCC` and aborts    | Child effects are discarded; A handles the error | `AAA`, `BBB`          |
| D writes `DDD` and faults    | Child effects are discarded; A handles the fault | `AAA`, `BBB`          |
| A writes `FINAL` and returns | Root changes enter reservation                   | `AAA`, `BBB`, `FINAL` |

If the transaction is admitted and committed, the ledger contains `AAA`, `BBB`, and `FINAL`. C’s and D’s writes never commit. If A instead propagates either child failure, A’s contract effects are discarded too.



## Related Documentation

- [Cross-Contract Calls](pages/contracts/cross-contract-calls.md): SDK call and error-handling patterns
- [Authorization](pages/how-it-works/authorization.md#passing-auth-tokens): Auth-token ownership across frames
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): Reservation and final outcomes
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Code and deployment identities

---

## Testing

Source: <https://thruput.network/docs/programming-model/testing/>

How to test Project Thruput contracts: native logic tests, RV32 integration tests, setup, and error matching.



## Test Modes

Start with `cargo test` for native logic tests in process, then run `thruput test` against the RV32 artifact. Add `thruput test --integration` when you need to test the same path a partner or app will use: build artifact, local node, deployment, signing profile, RPC URL, and generated client behavior. [Build and test](pages/cli/build-and-test.md#choose-a-test-boundary) compares the three modes and their command options.

Fresh projects include the integration target and host-only dependencies. The CLI can acquire a compatible catalog-pinned `hog-devnode`; use `thruput toolchain list` to inspect it. `THRUPUT_DEVNODE_BINARY` selects an explicit matching source build.



## What the Scaffold Gives You

Every new project (the default minimal contract, `--template counter`, and `--template counter-app`) includes:

```text
build.rs
tests/
  test.rs
  test_rv32.rs
  integration.rs
```

`tests/test.rs` holds native tests, and `tests/test_rv32.rs` runs under `thruput test`.

`tests/integration.rs` starts with one ignored RPC smoke test. It checks that the CLI provided a base58 contract address, connects to the ephemeral node with `thruput-json-rpc-client`, and calls `getChainTip`. Replace or extend the final placeholder with assertions for your contract.

The starter remains ignored under ordinary `cargo test`, even if you explicitly enable its feature. `thruput test --integration` enables the feature and sets `THRUPUT_INTEGRATION_TEST=1`, which lets the scaffold’s `build.rs` activate the live test. You can rename the module and test functions without changing how activation works.

The generated `thruput-integration-test` feature enables the optional RPC client and Tokio dependencies. Their target-specific Cargo entries keep them out of RV32 guest builds. Preserve the SDK and RPC versions selected together by the scaffold.

The generated `build.rs` contains:

```rust
fn main() {
    println!("cargo:rerun-if-env-changed=THRUPUT_INTEGRATION_TEST");
    println!("cargo:rustc-check-cfg=cfg(thruput_integration_runner)");

    if std::env::var("THRUPUT_INTEGRATION_TEST").as_deref() == Ok("1") {
        println!("cargo:rustc-cfg=thruput_integration_runner");
    }
}
```

> **tip: Projects created with an older scaffold**
>
> Compare with a fresh scaffold, then add `tests/integration.rs`, its feature and host-only dependencies, and the integration activation logic from `build.rs`. If your project already has a build script, merge the activation lines into its existing `main` function. The CLI exits with `integration_test_not_found` when the test target is absent.



## Test Setup

Your `lib.rs` must include `thruput_sdk::declare_mock_contract!()` to generate the `register_mock_contract` function used in tests:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

thruput_sdk::declare_mock_contract!();

mod implementation;
pub use implementation::*;
```



## Basic Pattern

```rust
use thruput_sdk::*;

use my_counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = thruput_sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            client.increment(5);
            assert_eq!(client.get(), 15);
        })
    })
    .assert_success();
}
```

Breaking this down:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()`.
3. **`*test_contract.as_hash()`** copies the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from, and `.run(closure)` executes the closure in a simulated execution context. The returned `TransactResult` records the outcome, return value, and emitted events. `.assert_success()` panics with details if the transaction did not commit.
5. **`deploy_contract`** deploys the contract and returns its address. The nonce makes the address deterministic.
6. **`CounterClient::new`** creates a typed client. Methods return values directly.



## `no_cost` vs `default`

Use [`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost) for most contract logic tests. It disables storage cost enforcement, which keeps tests focused on method behavior, storage mutations, events, and expected exceptions.

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) when the test should exercise the normal storage cost model. This is useful for storage-token behavior, deployment cost checks, or tests that should fail when the caller has not been funded correctly.

Use `TestEnvironment::new(Some(&model))` when the test is specifically about a custom `StorageCostModel`. Use `setup_grant_storage_tokens` to fund accounts in cost-sensitive tests.

For the full generated API, see the [`TestEnvironment` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html) or [Rust API Docs](pages/tools/rust-api-docs.md).

When a native test needs a custom transaction context, start with `env.transaction()`. The builder currently supports replacing the default authorization claim:

```rust
let result = env
    .transaction()
    .with_auth_claim(auth_claim)
    .transact(|tx| tx.call(&caller).run(|| {
        // contract calls
    }));
```

Finish the builder with `transact` for auto-commit, `transact_manual` for explicit commit or abort control, or `build` to obtain a `MockTransactionHandler` directly. Plain `env.transact(...)` remains the shorthand for the default transaction configuration.

Use `thruput test --integration` when the thing under test is not just contract logic: local node startup, RV32 artifact deployment, profile resolution, signing, RPC environment variables, or generated off-chain client behavior.



## Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
// Inside tx.call(&caller).run(...), after client.initialize(5):
assert_eq!(
    client.try_decrement(10).unwrap_err().try_as(),
    Some(LibraryExn::NonNegativeIntUnderflow),
);
```

The `try_decrement` method (generated alongside `decrement` by the `#[contract]` macro) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`, which is the same for every client: a caught exception stays undecoded inside it, and `try_as` decodes it as whichever exception type you name. When more than one type is of interest, `match_exn!` matches several in one place. See [Handle errors](pages/contracts/errors.md) for the full error model.



## Blocks and Conflicts

Each `env.transact` call runs in the current block. Transactions in the same block read the previous block’s committed state and do not see each other’s writes. Call `env.advance_block()` to commit the block and make its effects visible. Use `env.advance_block_at(timepoint)` to pin the next block’s time for deadline and expiry tests.

Use same-block transactions to test merges and exclusion:

```rust
fn transfer(env: &TestEnvironmentHandle, from: ContractAddress, to: ContractAddress, amount: i128) -> TransactResult {
    env.transact(|tx| tx.call(&from).run(move || ERC20Client::new(&token()).transfer(&to, amount)))
}

// Alice holds 100. Both transfers run in the same block.
transfer(&env, alice(), bob(), 60).assert_success();
transfer(&env, alice(), carol(), 60).assert_commit_failed_nondeterministically();
env.advance_block();
```

`assert_commit_failed_nondeterministically()` means the root call succeeded but its deltas could not be reserved with the block’s other changes. On a network, that attempt is excluded from the proposal. This assertion does not test scheduler requeue, RPC status, or client resubmission. See [Exclusion, requeue, and resubmission](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission) for those separate behaviors.

`TransactResult` also provides `assert_return_as::<T>()`, `assert_abort_as::<E>()`, `events()`, and `filter_events::<E>()`. See [`contracts/erc20/tests/same_block.rs`](https://github.com/thruputchain/thruput-examples/blob/main/contracts/erc20/tests/same_block.rs) for more same-block cases.



## Integration Test Environment

`thruput test --integration` runs `tests/integration.rs` against an ephemeral `hog-devnode`. The CLI builds and deploys the selected artifact, then sets:

| Variable                   | Value                                                                   |
| -------------------------- | ----------------------------------------------------------------------- |
| `THRUPUT_INTEGRATION_TEST` | `1`; activates the scaffolded live test                                 |
| `THRUPUT_RPC_URL`          | RPC URL for the ephemeral node                                          |
| `THRUPUT_CONTRACT_ADDRESS` | Deployed contract address                                               |
| `THRUPUT_PROFILE`          | `integration`                                                           |
| `THRUPUT_DEFAULT_KEY`      | `integration`, a temporary key the CLI creates and funds for this run   |
| `THRUPUT_RUNTIME_MANIFEST` | Runtime manifest path, when available                                   |
| `XDG_CONFIG_HOME`          | Temporary config directory that holds the `integration` key and profile |

The full run is:

1. Build the RV32 artifact.
2. Start an isolated local node.
3. Deploy it with a temporary `integration` key that the CLI generates and funds at node genesis.
4. Enable `thruput-integration-test` and run only the `integration` Cargo test target with the environment above.
5. Shut down the node after the test run, including after test failures.

Normal test-harness controls such as `--match-test`, `--skip`, `--fail-fast`, `--show-output`, `--no-capture`, and `--test-threads` apply to integration tests. `--watch`, `--rerun`, and `--workspace` cannot be combined with `--integration` yet.

Integration tests use the same RV32 artifact path as normal builds and deployments.



## Named Addresses

`ContractAddress::named("alice")` produces a deterministic address from a string. Same name always returns the same address. The method hashes the name with SHA-256 at runtime, so it cannot initialize a `static` or `const`. Bind it inside the test or a `LazyLock` instead:

```rust
#[test]
fn transfer_between_known_addresses() {
    let alice = ContractAddress::named("alice");
    let bob   = ContractAddress::named("bob");
    // ...
}
```

The `Named` trait that provides this method is re-exported through `thruput_sdk::*` when the `dev` feature is enabled.

---

## Debug a contract

Source: <https://thruput.network/docs/contracts/debugging/>

Isolate failures in native tests, RV32 artifact tests, and submitted transactions.

Start at the boundary that failed. A compiler error, a contract exception, and an uncertain network submission need different checks.



## Reproduce the logic

Use the smallest input that reproduces the problem:

```bash
RUST_BACKTRACE=1 cargo test test_counter -- --nocapture
```

Native tests provide Rust diagnostics and work with host debugging tools. Use generated `try_*` client methods to assert on expected errors.

Once the logic passes, run `thruput test` to check the RV32 artifact. A passing host test does not replace the artifact test.



## Inspect the build or artifact test

```bash
thruput --show-cargo-commands build
thruput test --match-test counter --show-output
```

Confirm the package, toolchain, and features. In a workspace, use `-p PACKAGE`. See [Build and test](pages/cli/build-and-test.md).



## Classify a deployed failure

| Observation                                     | Next check                                                                                                                                                                                                                                                                                                                                                                                           |
| ----------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Submission rejected                             | Inspect the signing account, profile, network identity, and reported admission error                                                                                                                                                                                                                                                                                                                 |
| Committed exception                             | Decode the typed error; check input and authorization conditions                                                                                                                                                                                                                                                                                                                                     |
| Committed fault                                 | Reproduce in tests; inspect execution limits and panics                                                                                                                                                                                                                                                                                                                                              |
| `pending`, `recentFailure`, or `unknown` status | Observe the original transaction on the same network                                                                                                                                                                                                                                                                                                                                                 |
| `retry` or `dropped` status                     | Read the reported error. A `retry` may succeed if you resubmit the same signed transaction while valid. For insufficient native tokens, fund the sender before resubmitting it. For errors that require changing the transaction, resolve the original outcome before signing a replacement. See [Resubmission and replacement](pages/typescript/transaction-status.md#resubmission-and-replacement) |
| Unexpected view result                          | Check address, interface/spec, read height, and simulated caller                                                                                                                                                                                                                                                                                                                                     |

```bash
thruput tx show TX_HASH --profile futurenet
```

See [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish) for outcomes and [CLI troubleshooting](pages/cli/troubleshooting.md) for configuration checks.



## Reproduce through RPC

Start a local node with `thruput node --verbose` and retain its logs while reproducing the problem. CLI transaction inspection shows public status and receipt data, not a full execution trace.

For repeatable build, deployment, and RPC checks, use `thruput test --integration` and add contract-specific assertions to the generated test.

---

## Generate client bindings

Source: <https://thruput.network/docs/contracts/client-bindings/>

Deliver a contract's typed interface to TypeScript application developers.

Client bindings let an application use your contract’s methods, types, errors, and events. Generate them from the contract spec produced by the same build you deploy:

```bash
thruput build --bindings ts
```

The spec describes the exported interface. Bindings turn that description into TypeScript code for application developers.



## Keep the interface and deployment together

- Regenerate bindings when methods, argument or return types, errors, or events change.
- Give application developers the bindings and the matching deployment address and network.
- Keep generated files separate from application code so regeneration does not overwrite manual changes.

See [Generate TypeScript bindings](pages/cli/codegen.md) for output paths and generation from an existing spec, and [Use contract bindings](pages/tools/typescript-bindings.md) for consuming the generated interface in an application.

---

## Contract artifacts and addresses

Source: <https://thruput.network/docs/how-it-works/contracts/>

Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.

An artifact is compiled contract code. Its code hash identifies that code; a deployment address identifies one instance with its own storage. The same artifact can be deployed at multiple addresses.

This page explains those identities and the rules of deployment. For deployment commands, see [Deploy and call](pages/cli/deploy-and-call.md).

User contracts compile to RV32, Project Thruput’s 32-bit RISC-V contract target. Native system contracts serve separate purposes, described below.



## Contract Types



### RV32 Contracts

`thruput build` compiles the contract’s RV32 entrypoint wrapper for `riscv32im-unknown-none-elf`, lowers that ELF into a deployable `.rv32a` artifact, and finalizes its contract-spec sidecars.

For a crate named `counter`, the default build writes:

```txt
target/thruput/counter.rv32a
target/thruput/counter.rv32.json
target/thruput/counter.spec.xdr
target/thruput/counter.spec.json
```

The `.rv32a` file is the executable contract artifact. `thruput deploy` wraps those bytes in the protocol’s `Contract::kRv32` variant before signing and submitting the deploy transaction.

Deployment must satisfy the network’s limits on attached contract size, RV32 code, guest memory, and new contracts per transaction. Client and gateway submission limits also apply. Use the selected network’s configuration rather than assuming a fixed maximum.



#### Entrypoints

Every callable method is identified by an 8-byte `ContractEntrypointID`. The SDK’s `#[contract]` macro emits one dispatch record per method into the `thruput_rv32_entrypoints` link section.

When hogd invokes an RV32 contract, it enters the guest at `_start` with the method ID in registers. The RV32 runtime dispatches by scanning that section, then calls the generated wrapper for the matching method. That wrapper decodes calldata, calls the Rust method, and returns through the Return syscall.

Entrypoint IDs can be arbitrary 8-byte values at the protocol layer. The SDK derives them as the first 8 bytes of `SHA256("<interface>::<major>::<method>")`. See [SDK Macros](pages/reference/sdk-macros.md) and the [contract spec reference](pages/reference/contract-spec.md) for the developer-facing shape.



#### Artifact Shape

Most developers should let the [Thruput CLI](pages/cli/build-and-test.md) produce RV32 artifacts. Under the hood, the RV32 lowerer:

- Parses the `riscv32im-unknown-none-elf` contract binary.
- Validates the layout expected by the Project Thruput RV32 runtime.
- Packs code, initial memory, metadata, and section digests into the `.rv32a` artifact.
- Self-verifies the artifact before writing it.

The node executes the lowered artifact through the RV32 runtime. Contract state does not live in guest memory. Durable state must be written through Project Thruput storage APIs.



### Native Precompiled Contracts

Native precompiled contracts are implemented directly inside the Project Thruput runtime. They are used for trusted system behavior, such as the native token contract, and can have permissions that user-deployed guest contracts do not have.

Users cannot deploy native contracts. Network configuration assigns system contract addresses; implementations are identified by values from `HogexecPrecompiledNativeContracts`.



## Contract Deployment

Contracts are deployed by the DeployContract [system call](pages/reference/syscalls.md). In normal CLI usage, `thruput deploy` calls `deploy` on the signing account. For a pubkey account, that call runs the native DefaultWallet, which calls DeployContract with the artifact hash and deployment nonce.



### Contract Identification

Contracts are identified by the SHA256 hash of the XDR-encoded `Contract` union. For an RV32 artifact, the deploy hash is:

```txt
SHA256(XDR(Contract::kRv32 {
    rv32_contract: ContractBlob {
        data: <.rv32a artifact bytes>
    }
}))
```

This is not just the SHA256 hash of the raw `.rv32a` bytes. The XDR wrapper and `kRv32` type tag are part of the hash preimage.



### DeployContract Syscall

To deploy a contract, the caller invokes DeployContract with two arguments:

- `nonce`: a 32-byte value chosen by the caller
- `contract_hash`: the SHA256 hash identifying the contract artifact to deploy

The system then:

1. Verifies that the contract identified by `contract_hash` is available for deployment.
2. Computes the deployment address: `ContractAddress = SHA256(XDR(ContractDeploymentHashPreimage))`.
3. Writes the contract’s `DeployedContractHash` to the computed address’s `Metadata` key.
4. Stores the contract code separately in the deduplicated contract code store.



### Deterministic Address Derivation

The address to which a contract is deployed is computed from the deployer address, nonce, and contract hash. Anyone can predict the address before deployment.

A single contract artifact can be deployed at many addresses. Each deployment has separate metadata and separate storage.



### Deployment Preimage

```rust
pub struct ContractDeploymentHashPreimage {
    /// Address of the contract performing the deployment.
    pub deployer_address: ContractAddress,

    /// Arbitrary 32-byte nonce chosen by the deployer.
    pub nonce: SHA256Hash,

    /// SHA256 hash of the contract artifact.
    pub contract_hash: SHA256Hash,
}
```

Under XDR encoding, this structure serializes as the concatenation of its fields:

```txt
XDR(ContractDeploymentHashPreimage) = deployer_address || nonce || contract_hash
```



### Example

A wallet contract at address `0x1234...` deploys `counter.rv32a`:

```txt
deployer_address = 0x1234...
nonce            = 0x5678...
contract_hash    = SHA256(XDR(Contract::kRv32 {
                       rv32_contract: ContractBlob { data: bytes(counter.rv32a) }
                   }))
                 = 0xabcd...

ContractAddress  = SHA256(0x1234... || 0x5678... || 0xabcd...)
                 = 0x9999...
```

The deployed counter contract’s address is now `0x9999...`.

This scheme is analogous to Ethereum’s `CREATE2` opcode because the address can be calculated before deployment.



## Deployment Eligibility

To be deployed via DeployContract, a contract identified by `contract_hash` must be available in the context of the current transaction.

A contract is available if either of the following holds:

- The contract code already exists in the on-chain contract code store.
- The contract is included in the `contracts_to_deploy` field of the current transaction.

```rust
pub struct Transaction {
    pub invocation: Invocation,
    pub uniquifier: Uniquifier,

    /// New contract code to make available for deployment.
    pub contracts_to_deploy: VecM<Contract>,

    /// Authorization claim specifying required signatures.
    pub auth_claim: AuthClaim,
}
```

`contracts_to_deploy` makes contract code available, but it does not deploy the code to an address by itself. Deployment to a specific address happens when a contract invokes DeployContract.

Example flow:

1. The transaction includes `contracts_to_deploy: [Contract::kRv32 { rv32_contract: ContractBlob { data: <artifact bytes> } }]`.
2. The contract code becomes available under its `contract_hash`.
3. During execution, a contract calls `DeployContract(nonce, contract_hash)`.
4. The system computes the deployed address and writes its metadata.



## Address Metadata

When a contract is deployed, the system writes its `DeployedContractHash` to the storage key `(contract_address, StorageKeyType::Metadata)`.

```rust
pub struct DeployedContractHash {
    /// SHA256 hash of the contract code.
    pub hash: SHA256Hash,

    /// Size of the contract in bytes.
    pub contract_size: u32,

    /// Type of contract: kNative, kMockTest, or kRv32.
    pub contract_type: ContractType,
}
```

This metadata allows the executor and off-chain tools to:

- Verify what code is running at an address.
- Determine the contract type without loading bytecode.
- Calculate storage costs from the contract size.

The metadata is set during deployment and persists for the lifetime of the contract address.



## Deployment Concurrency

Multiple transactions may deploy the same contract to the same address in the same block. Project Thruput does not consider concurrent deployments of the same contract to the same address to be in conflict. Collision resistance of SHA256 implies that different contracts cannot be deployed to the same address.

If a contract requires one-time initialization, implement that guard in contract storage.



## Redeployment and Immutability

Once a contract is deployed to an address, that address’s `DeployedContractHash` cannot be changed. Deployed contracts are immutable.



## Related Documentation

- [Thruput CLI](pages/cli.md): RV32 builds, local nodes, deployment, and codegen
- [Invocation Frames](pages/how-it-works/invocation-frames.md): execution context and call stack management
- [Syscalls](pages/reference/syscalls.md): system calls available to contracts
- [SDK Macros](pages/reference/sdk-macros.md): SDK entrypoint IDs and generated clients
- [Contract Spec](pages/reference/contract-spec.md): generated method, type, event, and error metadata
- [System Overview](pages/how-it-works/architecture.md): the component map

---

## Rust API Docs

Source: <https://thruput.network/docs/tools/rust-api-docs/>

Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.

Use Rustdoc for exact signatures, trait bounds, and source links. Use this site for contract tasks and the programming model.



## Match your project

The hosted links below select one SDK release. If your project’s dependency differs, select its version at [crates.thruput.network](https://crates.thruput.network) or build its resolved SDK documentation locally:

```bash
cargo doc -p thruput-sdk --no-deps --open
```

Run this from the generated contract project after [Cargo access setup](pages/cli/install.md#configure-cargo-access). Hosted Rustdoc may require your onboarding credentials.



## Common Links

| Need                                         | Rustdoc                                                                                                                                                                                                                                                    |
| -------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| SDK overview and re-exports                  | [`thruput_sdk`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/index.html)                                                                                                                                                                         |
| Contract types                               | [`ContractAddress`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.ContractAddress.html), [`SHA256Hash`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.SHA256Hash.html)                                         |
| Native tests                                 | [`TestEnvironment`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/struct.TestEnvironment.html)                                                                                                                                                    |
| Storage types and traits                     | [`thruput_sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html)                                                                                                                                                        |
| Nonnegative balances and counters            | [`Balance`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/balance/struct.Balance.html)                                                                                                                                                    |
| Lower-level signed deltas and explicit bases | [`NNInt`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/nnint/struct.NNInt.html)                                                                                                                                                          |
| Shared capacity                              | [`CapacityConstraint`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/capacity_constraint/struct.CapacityConstraint.html)                                                                                                                  |
| Keyed and indexed storage                    | [`Map`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/map/struct.Map.html), [`Vector`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/vector/struct.Vector.html)                                                          |
| Typed and raw values                         | [`Value`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/value/struct.Value.html), [`Bytestring`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/bytestring/struct.Bytestring.html)                                        |
| Queues and nested state                      | [`RCQ`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/rcq/struct.RCQ.html), [`Node`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/node/struct.Node.html)                                                                |
| Contract and storage macros                  | [`#[contract]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract.html), [`#[storage]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.storage.html)                                                                       |
| Error macro                                  | [`#[contract_exception]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract_exception.html)                                                                                                                                             |
| Events                                       | [`Event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/derive.Event.html), [`log_event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/event/fn.log_event.html)                                                                         |
| Error helpers                                | [`throw`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.throw.html), [`ensure`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.ensure.html), [`OrThrow`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/trait.OrThrow.html) |
| Deployment                                   | [`deploy_contract`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/deploy/fn.deploy_contract.html)                                                                                                                                                 |
| Mock registration                            | [`declare_mock_contract!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.declare_mock_contract.html)                                                                                                                                        |
| Compile-time hashes                          | [`sha256_static!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.sha256_static.html), [`hash_ident!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.hash_ident.html)                                                         |



## How to Use These Docs

- Start with [Testing](pages/programming-model/testing.md) to choose native, artifact, or RPC tests.
- Use [storage API tables](pages/reference/storage-types.md) for common operations and [storage guidance](pages/programming-model/storage-types.md) to choose a type.
- Use [SDK Macros](pages/reference/sdk-macros.md) for parameters and generated items.
- Follow Rustdoc source links when you need the implementation behind an API.

---

## Storage Types

Source: <https://thruput.network/docs/reference/storage-types/>

API reference for Project Thruput storage types.

| Area                                  | Links                                                                                                                                              |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| Type choice and conflict semantics    | [Storage guidance](pages/programming-model/storage-types.md)                                                                                       |
| Generated type, guard, and trait APIs | [`thruput_sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html), [Rust API Docs](pages/tools/rust-api-docs.md) |
| Encoding                              | CXS; serialization traits retain the names `ReadXDR` and `WriteXDR`                                                                                |



## Balance

| Property        | Value                                                                                                                        |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Representation  | `i128`, backed by NNInt                                                                                                      |
| Range           | `0..=i128::MAX`; `Balance::MAX` is `i128::MAX`                                                                               |
| Missing value   | Zero                                                                                                                         |
| Negative amount | Rejected with `NonNegativeIntUnderflow`                                                                                      |
| Operations      | No absolute `set` or signed adjustment                                                                                       |
| Traits          | `Deletable`                                                                                                                  |
| Usage           | [Balance guidance](pages/programming-model/storage-types.md#balance), [Counter tutorial](pages/tutorials/build-a-counter.md) |

| Method              | Signature                                                                 | Description                                                                                                   |
| ------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> i128`                                                   | Read the balance. A never-written location returns zero.                                                      |
| `try_get`           | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read without aborting. A never-written location returns `Ok(0)`.                                              |
| `increase`          | `fn increase(&mut self, amount: i128)`                                    | Load and increase the balance. Aborts immediately on overflow.                                                |
| `try_increase`      | `fn try_increase(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked increase that leaves storage unmodified on `Err`.                                                     |
| `decrease`          | `fn decrease(&mut self, amount: i128)`                                    | Load and decrease the balance. Aborts immediately if funds are insufficient.                                  |
| `try_decrease`      | `fn try_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked decrease that leaves storage unmodified on `Err`.                                                     |
| `lazy_increase`     | `fn lazy_increase(&mut self, amount: i128)`                               | Record an increase without loading the committed balance. Aggregate overflow is checked during reservation.   |
| `try_lazy_increase` | `fn try_lazy_increase(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta overflow.                                                       |
| `lazy_decrease`     | `fn lazy_decrease(&mut self, amount: i128)`                               | Record a decrease without loading the committed balance. Aggregate sufficiency is checked during reservation. |
| `try_lazy_decrease` | `fn try_lazy_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta underflow.                                                      |



## NNInt

| Property         | Value                                                                                                                                                           |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Data model       | Signed changes, explicit `set`, and a commit-time floor                                                                                                         |
| Decrement        | Negative `inc` or `strict_inc` argument                                                                                                                         |
| Exclusive writes | Handle from `Map::at_mut_exclusive`, `delete_exclusive`, or `non_negative_int_set_exclusive` in `thruput_sdk::sys_exn::nnint`; no handle `set_exclusive` method |
| Traits           | `Deletable`                                                                                                                                                     |
| Usage            | [Merged deltas](pages/programming-model/execution.md#merged-deltas), [NNInt and concurrent updates](pages/programming-model/nnint.md)                           |

| Method           | Signature                                                                 | Description                                                                                                                     |
| ---------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `get`            | `fn get(&self) -> i128`                                                   | Read current value. Aborts if the location has never been set.                                                                  |
| `try_get`        | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read current value without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.                      |
| `set`            | `fn set(&mut self, set_value: i128)`                                      | Set the value. Uses the keypath’s locking mode.                                                                                 |
| `inc`            | `fn inc(&mut self, increment: i128)`                                      | Add `increment` without forcing a snapshot read. Underflow is caught by later runtime checks, not immediately.                  |
| `strict_inc`     | `fn strict_inc(&mut self, increment: i128)`                               | Add `increment`, loading the current base for early underflow detection. Aborts immediately if the result would be negative.    |
| `try_strict_inc` | `fn try_strict_inc(&mut self, increment: i128) -> Result<(), LibraryExn>` | Checked increment that reports overflow, underflow, or storage failure instead of aborting. Leaves storage unmodified on `Err`. |



## CapacityConstraint

| Property | Value                                                         |
| -------- | ------------------------------------------------------------- |
| Purpose  | Commit-time capacity for a contract-defined linear constraint |
| Flush    | Staged changes are written on flush or drop                   |
| Traits   | `Deletable`                                                   |

| Method                       | Signature                                                                    | Description                                                                                                                |
| ---------------------------- | ---------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `get_remaining_capacity`     | `fn get_remaining_capacity(&self) -> i128`                                   | Return the committed capacity plus changes staged in this transaction and handle. A never-written location starts at zero. |
| `try_get_remaining_capacity` | `fn try_get_remaining_capacity(&self) -> Result<i128, LibraryExn>`           | Read remaining capacity without aborting.                                                                                  |
| `consume_capacity`           | `fn consume_capacity(&mut self, amount: i128)`                               | Stage consumption for commit-time enforcement. A negative amount releases capacity.                                        |
| `try_consume_capacity`       | `fn try_consume_capacity(&mut self, amount: i128) -> Result<(), LibraryExn>` | Stage consumption and report arithmetic overflow instead of aborting.                                                      |
| `set_capacity`               | `fn set_capacity(&mut self, capacity: i128)`                                 | Set the capacity. Must be the first write in the transaction, except for an idempotent repeat.                             |
| `try_set_capacity`           | `fn try_set_capacity(&mut self, capacity: i128) -> Result<(), LibraryExn>`   | Set capacity and report invalid write ordering instead of aborting.                                                        |
| `flush`                      | `fn flush(&mut self)`                                                        | Merge staged changes into pending storage immediately.                                                                     |
| `try_flush`                  | `fn try_flush(&mut self) -> Result<(), LibraryExn>`                          | Flush staged changes and report failure. On error, changes remain staged and drop retries the flush.                       |



## Map\<K, V>

| Property        | Value                                                             |
| --------------- | ----------------------------------------------------------------- |
| Bounds          | `K: WriteXDR`, `V: StorageType`                                   |
| Enumeration     | Not supported; no `keys()` or iterator                            |
| Deletion        | Does not implement `Deletable`                                    |
| Disjoint access | Compares derived keypaths, not `PartialEq`; duplicate slots panic |

| Method                      | Signature                                                                                                      | Description                                                                                                                                   |
| --------------------------- | -------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `at`                        | `fn at(&self, entry_key: &K) -> SlotRef<'_, Self, V>`                                                          | Read-only borrow of the value at `entry_key`. Returns a `SlotRef` that derefs to `V`.                                                         |
| `at_mut`                    | `fn at_mut(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                                  | Mutable borrow of the value at `entry_key`. Returns a `SlotMut` that derefs to `V`.                                                           |
| `at_mut_exclusive`          | `fn at_mut_exclusive(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                        | Mutable borrow with an exclusive lock. One writer per key per block. Later writes to the entry in the same transaction keep the lock request. |
| `at_disjoint_mut`           | `fn at_disjoint_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>`                  | Mutably borrow N elements at once. Panics if any keys are equal.                                                                              |
| `at_disjoint_unchecked_mut` | `unsafe fn at_disjoint_unchecked_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>` | Mutably borrow N elements without duplicate checking. Caller must ensure all keys are disjoint.                                               |
| `keypath`                   | `fn keypath(&self) -> &Keypath`                                                                                | Reference to the map’s root keypath.                                                                                                          |



### DisjointMut\<Owner, S, N>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `at_disjoint_mut`                                              |
| Borrow   | Exclusive borrow of the parent map                             |
| Traits   | `Deref<Target = [S; N]>`, `DerefMut`; supports direct indexing |



## Vector\<S>

| Property       | Value                                                                                                    |
| -------------- | -------------------------------------------------------------------------------------------------------- |
| Representation | `Map<u32, S>` and a separate length; `S: StorageType`                                                    |
| Sparse slots   | Deleting element storage does not shrink `len`; an in-bounds slot can be missing                         |
| Iterators      | `Iterator`, `ExactSizeIterator`, `DoubleEndedIterator`; `IntoIterator` for shared and mutable references |
| Deletion       | `Deletable` when `S: Deletable`; deletes elements, then length                                           |

| Method            | Signature                                                      | Description                                                                                                                  |
| ----------------- | -------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `len`             | `fn len(&self) -> u32`                                         | Current logical length. Returns 0 if never set.                                                                              |
| `is_empty`        | `fn is_empty(&self) -> bool`                                   | True if `len() == 0`.                                                                                                        |
| `at`              | `fn at(&self, index: u32) -> SlotRef<'_, Self, S>`             | Read-only borrow at `index`. Bounds-checked.                                                                                 |
| `at_mut`          | `fn at_mut(&mut self, index: u32) -> SlotMut<'_, Self, S>`     | Mutable borrow at `index`. Bounds-checked.                                                                                   |
| `push_empty_slot` | `fn push_empty_slot(&mut self) -> SlotMut<'_, Self, S>`        | Increment `len` and return a mutable handle to the new slot. Marked `#[must_use]`.                                           |
| `push_with`       | `fn push_with<R>(&mut self, f: impl FnOnce(&mut S) -> R) -> R` | Initialize a new slot through the closure `f`, then increment `len`. If `f` traps, neither the data nor `len` are committed. |
| `pop`             | `fn pop(&mut self)`                                            | Delete the last element and decrement `len`. Aborts if empty. Requires `S: Deletable`.                                       |
| `iter`            | `fn iter(&self) -> VectorIter<'_, S>`                          | Read-only iterator. Yields `SlotRef` handles. Shared borrow prevents structural modifications.                               |
| `iter_mut`        | `fn iter_mut(&mut self) -> VectorIterMut<'_, S>`               | Mutable iterator. Yields `SlotMut` handles. Exclusive borrow on the vector.                                                  |
| `keypath`         | `fn keypath(&self) -> &Keypath`                                | Reference to the vector’s root keypath.                                                                                      |



## Value\<T>

| Property | Value                                            |
| -------- | ------------------------------------------------ |
| Data     | One serialized typed value                       |
| Bounds   | `T: WriteXDR` for writes, `T: ReadXDR` for reads |
| Traits   | `Deletable`                                      |

| Method              | Signature                                                              | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> T`                                                   | Deserialize and return the stored value. Aborts if the key does not exist.                                    |
| `try_get`           | `fn try_get(&self) -> Result<T, LibraryExn>`                           | Deserialize without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.           |
| `set`               | `fn set(&mut self, value: &T)`                                         | Serialize and store the value. Uses the keypath’s locking mode.                                               |
| `try_set`           | `fn try_set(&mut self, value: &T) -> Result<(), LibraryExn>`           | Serialize and store without aborting. Leaves storage unmodified on `Err`.                                     |
| `set_exclusive`     | `fn set_exclusive(&mut self, value: &T)`                               | Serialize and store the value with an exclusive lock, regardless of keypath flag.                             |
| `try_set_exclusive` | `fn try_set_exclusive(&mut self, value: &T) -> Result<(), LibraryExn>` | Exclusive store that reports failure instead of aborting.                                                     |
| `load_mut`          | `fn load_mut(&mut self) -> ValueMut<'_, T>`                            | Load the value and return a mutable guard. Flushes back to storage on drop. Requires `T: WriteXDR + ReadXDR`. |
| `key`               | `fn key(&self) -> &StorageKey`                                         | Reference to the value’s resolved storage key.                                                                |



### ValueMut\<T>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `load_mut`                                                     |
| Traits   | `Deref<Target = T>`, `DerefMut`                                |
| Drop     | Writes back after mutable access; a clean guard does not write |

| Method      | Signature                                           | Description                                                                                            |
| ----------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `flush`     | `fn flush(&mut self)`                               | Write a dirty value immediately. A clean guard is a no-op.                                             |
| `try_flush` | `fn try_flush(&mut self) -> Result<(), LibraryExn>` | Flush and report serialization or storage failure. On error, the guard remains dirty and drop retries. |



## Bytestring

| Property         | Value                                                                                                                                                          |
| ---------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Data             | Raw bytes                                                                                                                                                      |
| Exclusive writes | Handle from `Map::at_mut_exclusive`, `delete_exclusive`, or `bytestring_set_exclusive` in `thruput_sdk::sys_exn::bytestring`; no handle `set_exclusive` method |
| Traits           | `Deletable`                                                                                                                                                    |

| Method      | Signature                                            | Description                                                                                  |
| ----------- | ---------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `len`       | `fn len(&self) -> usize`                             | Length in bytes.                                                                             |
| `is_empty`  | `fn is_empty(&self) -> bool`                         | True if length is zero.                                                                      |
| `exists`    | `fn exists(&self) -> bool`                           | True if a bytestring exists. Returns false for a missing key.                                |
| `get`       | `fn get(&self) -> Box<[u8]>`                         | Read stored bytes as a heap-allocated slice.                                                 |
| `try_get`   | `fn try_get(&self) -> Result<Box<[u8]>, LibraryExn>` | Read without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`. |
| `get_sized` | `fn get_sized<const N: usize>(&self) -> [u8; N]`     | Read into a fixed-size array. Aborts if length does not match `N`.                           |
| `set`       | `fn set(&mut self, buf: &[u8])`                      | Write bytes. Exclusive when the handle came from `Map::at_mut_exclusive`.                    |



## RCQ\<T>

| Property    | Value                                                                                               |
| ----------- | --------------------------------------------------------------------------------------------------- |
| Data        | CXS-encoded `T`; multi-producer queue                                                               |
| Concurrency | Inserts merge, up to 250 entries per queue per block; one consuming transaction per queue per block |
| Traits      | `StorageType`, `Deletable`                                                                          |
| Modules     | Typed wrapper in `thruput_sdk::storage`; raw-key functions in `thruput_sdk::sys_exn::rcq`           |

| Method              | Signature                                                                        | Description                                                                                        |
| ------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `insert`            | `fn insert(&mut self, entry: &T)` where `T: WriteXDR`                            | CXS-encode and insert the entry.                                                                   |
| `insert_raw`        | `fn insert_raw(&mut self, queue_entry: &[u8])`                                   | Insert raw bytes; bypasses CXS encoding.                                                           |
| `consume`           | `fn consume(&mut self) -> T` where `T: ReadXDROwned`                             | Consume the next entry and decode it. Aborts if the queue is empty or the entry cannot be decoded. |
| `try_consume`       | `fn try_consume(&mut self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`     | Consume and decode without aborting. A decode failure leaves the entry in the queue.               |
| `consume_raw`       | `fn consume_raw(&mut self) -> Box<[u8]>`                                         | Consume the next entry as raw bytes. Aborts if the queue is empty.                                 |
| `try_consume_raw`   | `fn try_consume_raw(&mut self) -> Result<Box<[u8]>, LibraryExn>`                 | Consume raw bytes without aborting.                                                                |
| `consume_sized`     | `fn consume_sized<const N: usize>(&mut self) -> [u8; N]`                         | Consume into a fixed-size array. Aborts on size mismatch.                                          |
| `try_consume_sized` | `fn try_consume_sized<const N: usize>(&mut self) -> Result<[u8; N], LibraryExn>` | Consume without aborting. A wrong-size entry is left in the queue.                                 |
| `peek`              | `fn peek(&self) -> T` where `T: ReadXDROwned`                                    | Read the next entry without consuming. Aborts if empty.                                            |
| `try_peek`          | `fn try_peek(&self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`            | Read and decode without aborting or consuming.                                                     |
| `peek_raw`          | `fn peek_raw(&self) -> Box<[u8]>`                                                | Raw-bytes peek. Aborts if empty.                                                                   |
| `try_peek_raw`      | `fn try_peek_raw(&self) -> Result<Box<[u8]>, LibraryExn>`                        | Raw-bytes peek without aborting.                                                                   |
| `peek_sized`        | `fn peek_sized<const N: usize>(&self) -> [u8; N]`                                | Fixed-size peek. Aborts on size mismatch.                                                          |
| `try_peek_sized`    | `fn try_peek_sized<const N: usize>(&self) -> Result<[u8; N], LibraryExn>`        | Fixed-size peek without aborting.                                                                  |
| `key`               | `fn key(&self) -> &StorageKey`                                                   | Reference to the queue’s resolved storage key.                                                     |



### Lower-level free functions (`thruput_sdk::sys_exn::rcq`)

| Function                              | Signature                                                                                                 | Description                                                         |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `retrocausal_queue_insert`            | `fn retrocausal_queue_insert(key: &StorageKey, queue_entry: &[u8])`                                       | Insert raw bytes.                                                   |
| `retrocausal_queue_consume_sized`     | `fn retrocausal_queue_consume_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                         | Consume a fixed-size entry. Aborts on size mismatch or empty queue. |
| `retrocausal_queue_try_consume_sized` | `fn retrocausal_queue_try_consume_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>` | Consume a fixed-size entry without aborting.                        |
| `retrocausal_queue_peek_sized`        | `fn retrocausal_queue_peek_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                            | Peek a fixed-size entry.                                            |
| `retrocausal_queue_try_peek_sized`    | `fn retrocausal_queue_try_peek_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>`    | Peek a fixed-size entry without aborting.                           |
| `retrocausal_queue_consume`           | `fn retrocausal_queue_consume(key: &StorageKey) -> Box<[u8]>`                                             | Consume a raw entry.                                                |
| `retrocausal_queue_try_consume`       | `fn retrocausal_queue_try_consume(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                     | Consume a raw entry without aborting.                               |
| `retrocausal_queue_peek`              | `fn retrocausal_queue_peek(key: &StorageKey) -> Box<[u8]>`                                                | Peek a raw entry.                                                   |
| `retrocausal_queue_try_peek`          | `fn retrocausal_queue_try_peek(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                        | Peek a raw entry without aborting.                                  |



## Slot Types

| Type                    | Implements                       | Description                                              |
| ----------------------- | -------------------------------- | -------------------------------------------------------- |
| `SlotRef<'a, Owner, S>` | `Deref<Target = S>`              | Read-only handle. Holds a shared borrow on the parent.   |
| `SlotMut<'a, Owner, S>` | `Deref<Target = S>` + `DerefMut` | Mutable handle. Holds an exclusive borrow on the parent. |

| Access                | Lifetime                  | Syntax                                    |
| --------------------- | ------------------------- | ----------------------------------------- |
| Map or vector element | Tied to parent collection | `*slot` or direct field access; no unwrap |



## Node\<T>

| Property           | Value                                                       |
| ------------------ | ----------------------------------------------------------- |
| Data               | Compound storage field group; does not keep its own keypath |
| Bound              | `T: From<Keypath>`                                          |
| Access             | `Deref<Target = T>`, `DerefMut`                             |
| Collection support | Implements `StorageType` for use in maps and vectors        |
| Deletion           | `Deletable` when `T: Deletable`; delegates to inner fields  |



## Deletable Trait

| Implementor                                                     | Behavior                                               |
| --------------------------------------------------------------- | ------------------------------------------------------ |
| `Balance`, `NNInt`, `CapacityConstraint`, `Value`, `Bytestring` | Delete one key                                         |
| `Node`, `Vector`                                                | Delete recursively when elements implement `Deletable` |
| `Map`                                                           | Not implemented; entries cannot be enumerated          |

| Method             | Signature                        | Description                                                |
| ------------------ | -------------------------------- | ---------------------------------------------------------- |
| `delete`           | `fn delete(&mut self)`           | Delete using the keypath’s own locking semantics.          |
| `delete_exclusive` | `fn delete_exclusive(&mut self)` | Delete with an exclusive lock, regardless of keypath flag. |



## Flaggable Trait

| Property     | Value                                                |
| ------------ | ---------------------------------------------------- |
| Implementors | `Value`, `NNInt`, `Balance`, `Bytestring`            |
| Scope        | Current transaction’s requested flags for a leaf key |
| Type         | `StorageFlags` aliases `StorageDeltaFlags`           |
| Flag         | `ExclusiveLock`                                      |

| Method        | Signature                                      | Description                                                                                      |
| ------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| `flags`       | `fn flags(&self) -> StorageFlags`              | The key’s flags as seen by the current call frame. `None` if the key has no pending write.       |
| `set_flags`   | `fn set_flags(&mut self, flags: StorageFlags)` | Add `flags` (bitwise OR). Throws unless a write to the key is pending in the current call frame. |
| `clear_flags` | `fn clear_flags(&mut self)`                    | Remove every flag. Does nothing if the key has no pending write.                                 |



### Raw-key functions

| Function              | Signature                                                          | Description                                                    |
| --------------------- | ------------------------------------------------------------------ | -------------------------------------------------------------- |
| `storage_flags`       | `fn storage_flags(key: &StorageKey) -> StorageDeltaFlags`          | Read the key’s flags.                                          |
| `set_storage_flags`   | `fn set_storage_flags(key: &StorageKey, flags: StorageDeltaFlags)` | Add flags. Throws if no write is pending or a flag is unknown. |
| `clear_storage_flags` | `fn clear_storage_flags(key: &StorageKey)`                         | Remove every flag.                                             |

| Module                           | Behavior                                                                |
| -------------------------------- | ----------------------------------------------------------------------- |
| `thruput_sdk::sys_exn::flags`    | Throwing versions, re-exported at crate root                            |
| `thruput_sdk::sys_result::flags` | Non-throwing versions returning `Result`                                |
| Usage                            | [Lock requests](pages/programming-model/storage-types.md#lock-requests) |

---

## SDK Macros

Source: <https://thruput.network/docs/reference/sdk-macros/>

Macro targets, parameters, generated APIs, and constraints for the Rust SDK.

| Task                          | Guide                                                           |
| ----------------------------- | --------------------------------------------------------------- |
| Define state and methods      | [Methods and interfaces](pages/contracts/methods.md)            |
| Choose storage                | [Storage types](pages/programming-model/storage-types.md)       |
| Declare and handle failures   | [Handle errors](pages/contracts/errors.md)                      |
| Call another contract         | [Cross-Contract Calls](pages/contracts/cross-contract-calls.md) |
| Define, emit, and test events | [Events](pages/contracts/events.md)                             |
| Register a test contract      | [Testing](pages/programming-model/testing.md)                   |
| Find complete generated APIs  | [Rust API Docs](pages/tools/rust-api-docs.md)                   |



## `#[contract]`



### Applies to

| Target                  | Generates                                               |
| ----------------------- | ------------------------------------------------------- |
| Trait definition        | Client struct and interface metadata                    |
| Trait implementation    | Export functions and mock registration                  |
| Inherent implementation | Export functions, client struct, and interface metadata |
| Free function           | Export function, no client                              |



### Parameters

| Parameter                                    | Default                 | Meaning                                                                                |
| -------------------------------------------- | ----------------------- | -------------------------------------------------------------------------------------- |
| `throws = Error` or `throws(ErrorA, ErrorB)` | None                    | Error types recorded in the spec; does not restrict which exceptions callers can catch |
| `emits(EventA, EventB)`                      | None                    | Event types recorded in the spec                                                       |
| `client = ClientName`                        | `{Interface}Client`     | Generated client name                                                                  |
| `interface = "Name"`                         | Trait or self-type name | Interface identity used for entrypoints                                                |
| `version = "0.1.0"`                          | `CARGO_PKG_VERSION`     | Version used for entrypoint identity                                                   |
| `exports = "name"`                           | Generated               | Internal exports module name                                                           |



### `throws` rules

| Constraint | Rule                                                                                       |
| ---------- | ------------------------------------------------------------------------------------------ |
| Placement  | Trait definition or inherent implementation; rejected on trait implementations             |
| Duplicates | The same type cannot be listed twice; different paths with the same final name are allowed |
| Runtime    | A known exception can be caught whether or not it is declared in `throws`                  |



### `emits` rules

| Constraint       | Rule                                                                                                    |
| ---------------- | ------------------------------------------------------------------------------------------------------- |
| Placement        | Trait definition or inherent implementation; rejected on trait implementations                          |
| Type             | Must implement `Event`                                                                                  |
| Spec             | Records name, signature, topics, and payload layout                                                     |
| Undeclared event | May be emitted; use `#[event_spec(export)]` to include a library event without an interface declaration |



### Generated client

| Method                                           | Behavior                                                                                |
| ------------------------------------------------ | --------------------------------------------------------------------------------------- |
| `ClientName::new(&ContractAddress)`              | Construct a client                                                                      |
| `with_gas_limit(&self, u64) -> Self`             | Return a configured copy with a child gas cap                                           |
| `with_commit_locking(&self) -> Self`             | Request commit locks before the child returns                                           |
| `with_read_only(&self) -> Self`                  | Reject child state changes                                                              |
| `method(&self, ...) -> T`                        | Return the value or propagate failure                                                   |
| `try_method(&self, ...) -> Result<T, CallError>` | Return the value or an inspectable failure                                              |
| Reserved names                                   | `new`, `with_gas_limit`, `with_commit_locking`, `with_read_only`, and the `try_` prefix |



### Inspecting errors

| API                 | Purpose                                                                                               |
| ------------------- | ----------------------------------------------------------------------------------------------------- |
| `match_exn!`        | Match typed exceptions; requires a final `_` arm                                                      |
| `try_as::<E>()`     | Decode one known exception type; returns `None` for a different type or failed decoding               |
| `try_decode::<E>()` | Distinguish unknown type from malformed payload                                                       |
| Usage               | [Error matching examples](pages/contracts/cross-contract-calls.md#matching-exceptions-with-match_exn) |



### Method behavior

| Method                      | Behavior                                                                                 |
| --------------------------- | ---------------------------------------------------------------------------------------- |
| Public inherent method      | Exported                                                                                 |
| Private inherent method     | Internal helper                                                                          |
| Trait implementation method | Exported                                                                                 |
| Storage receiver            | Uses generated storage handles; see [Methods and interfaces](pages/contracts/methods.md) |



## `#[contract_exception]`

| Property            | Value                                                               |
| ------------------- | ------------------------------------------------------------------- |
| Targets             | Structs and enums; no generics                                      |
| Generated derives   | `Debug`, `PartialEq`, `ReadXDR`, `WriteXDR`, `ContractTypeSpec`     |
| Generated traits    | `Exn` and `ContractTypeName`                                        |
| Enum representation | Adds `#[repr(i32)]`; variants require explicit discriminants        |
| `version = "0.1.0"` | Override `CARGO_PKG_VERSION` for identity                           |
| `name = "Name"`     | Override the Rust type name for identity                            |
| `Clone`             | Add the derive explicitly if needed                                 |
| Examples            | [Enum and struct errors](pages/contracts/errors.md#defining-errors) |



### Selector computation

| Component       | Rule                                                                                                                                                                                        |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Selector        | First 8 bytes of `sha256(MAJOR_VERSION :: CRATE_NAME :: TYPE_NAME)`                                                                                                                         |
| `MAJOR_VERSION` | Leftmost nonzero version component: `1.2.3` → `1`, `0.9.2` → `0.9`, `0.0.2` → `0.0.2`                                                                                                       |
| `CRATE_NAME`    | `CARGO_PKG_NAME`                                                                                                                                                                            |
| `TYPE_NAME`     | Type name or explicit `name`                                                                                                                                                                |
| Compatibility   | Stable selector does not guarantee an older caller can decode every new payload; see [decoding errors](pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one) |



## `#[exn]`

| Property                   | Value                                                                             |
| -------------------------- | --------------------------------------------------------------------------------- |
| Purpose                    | Low-level `Exn` implementation with computed selector                             |
| Derives and representation | Supplied by the author; prefer `#[contract_exception]` for normal contract errors |
| `version`                  | Optional selector-version override                                                |



## `#[storage]` / `#[derive(Storage)]`

| Property    | Value                                                                     |
| ----------- | ------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                      |
| Output      | `From<Keypath>` implementation assigning each field a subpath             |
| Fields      | Storage handles; wrap plain data in `Value<T>`                            |
| Collections | Use `Node<T>` to place a compound storage struct inside `Map` or `Vector` |
| Usage       | [Storage types](pages/programming-model/storage-types.md)                 |



## `#[derive(Deletable)]`

| Property    | Value                                                                               |
| ----------- | ----------------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                                |
| Requirement | Every field must implement `Deletable`; `Map` does not                              |
| Output      | Calls each field’s `delete_internal()`; exposes `delete()` and `delete_exclusive()` |



## `#[derive(Event)]`

| Property                     | Value                                                                                                           |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Target                       | Named-field struct                                                                                              |
| `#[topic]`                   | Mark an indexed field; at most two fields, in addition to the signature at topic 0                              |
| Direct topics                | `ContractAddress`, `SHA256Hash`, `[u8; 32]`, `U256`, `I256`, `u32`, `u64`, `u128`, `i32`, `i64`, `i128`, `bool` |
| Integer topics               | Fixed 32-byte big-endian encoding with zero or sign extension                                                   |
| String and byte-slice topics | Hashed; filterable but not recoverable from the topic                                                           |
| Payload                      | Non-topic fields, serialized by the generated `WriteXDR` implementation                                         |
| `#[event_spec(export)]`      | Include the event in the linked contract spec without `emits(...)`                                              |
| `SIGNATURE`                  | Full 32-byte hash of version, defining crate, and type identity                                                 |
| `Event` implementation       | Topic access and payload decoding                                                                               |
| `{Name}Payload`              | Companion payload type with `ReadXDR`                                                                           |
| Usage                        | [Event definitions, emission, and tests](pages/contracts/events.md)                                             |



## Utility Macros

| Macro                                      | Output / usage                                                                                                      |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| `static_key!("slot")`                      | Compile-time SHA-256 `StorageKey`                                                                                   |
| `sha256_static!("text")`                   | Compile-time `SHA256Hash`                                                                                           |
| `sha256_ident!(Name)`                      | `SHA256Hash` of an identifier                                                                                       |
| `hash_ident! { static NAME: SHA256Hash; }` | Named hash static; also supports `ContractAddress` and visibility                                                   |
| `sha256_array_ident!(Name)`                | Identifier hash as `[u8; 32]`                                                                                       |
| `hash_to_array!("text")`                   | String or byte-string hash as `[u8; 32]`                                                                            |
| `declare_mock_contract!()`                 | Crate-root mock registration when `dev` is enabled; see [test setup](pages/programming-model/testing.md#test-setup) |



## `#[contract_type]`

| Property                | Value                                                                                                            |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Targets                 | Named, tuple, or unit structs and enums                                                                          |
| Output                  | Serialization derives and `ContractTypeSpec`                                                                     |
| `name = "Name"`         | Override spec type name                                                                                          |
| `export`                | Include an otherwise unreachable type in the spec                                                                |
| Enum variants           | Explicit discriminants required                                                                                  |
| Generic type parameters | Not supported                                                                                                    |
| Spec inclusion          | Types reachable through method signatures, errors, events, or other reachable types; otherwise requires `export` |
| Spec kind               | Struct, enum without payloads, or union with payloads                                                            |
| Examples                | [Argument and return types](pages/contracts/methods.md#define-argument-and-return-types)                         |



## `#[derive(ContractTypeSpec)]`

| Property                        | Value                                                              |
| ------------------------------- | ------------------------------------------------------------------ |
| Targets                         | Structs and enums                                                  |
| Output                          | `ContractTypeSpec` only; serialization must be supplied separately |
| `#[contract_type_spec(export)]` | Include an otherwise unreachable type in the spec                  |

---

## Syscalls

Source: <https://thruput.network/docs/reference/syscalls/>

Host function numbers, parameters, and errors for Project Thruput contracts.

These are the host functions available to Project Thruput guest contracts. Most developers use the SDK rather than calling syscalls directly. See [Programming Model: Storage Types](pages/programming-model/storage-types.md) for the high-level API.

The tables below describe the protocol’s logical typed interface. The generated low-level bindings map it to each guest target’s ABI. User contracts use RV32. Variable-length buffers are passed as spans.

The return value is a `SyscallErrorCode`. Any syscall can return `Fault` (1) if a pointer argument is out of guest memory bounds, or `NoSyscall` (2) if the syscall number is not supported. Per-syscall error codes are listed with each entry below, and the full enum is at the bottom of this page.



## Hashing



### SHA256

|            |   |
| ---------- | - |
| **Number** | 0 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |
| out       | `hash`   | `SHA256Hash`  |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the SHA-256 hash of the input buffer.



### SHA256Update

|            |    |
| ---------- | -- |
| **Number** | 26 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `index`  | `u32`         |
| in        | `buffer` | `[u8]` (span) |
| in        | `reset`  | `bool`        |

Errors:

- `InvalidSyscallInput` if the indexed hash buffer does not exist and `reset` is false, the buffer becomes too large, or there are too many active hash buffers.

Updates the SHA-256 hash computation at the specified index with the supplied bytes. If `reset` is true, the hash state is cleared before the update.



### SHA256Finalize

|            |    |
| ---------- | -- |
| **Number** | 27 |

| Direction | Name     | Type         |
| --------- | -------- | ------------ |
| in        | `index`  | `u32`        |
| out       | `output` | `SHA256Hash` |

Errors:

- `InvalidSyscallInput` if the queried hash buffer does not exist (for example, calling finalize twice on the same buffer without an intervening reset).

Finalizes the SHA-256 hash computation at the specified index, returns the digest, and removes the buffer.



### SHA256Copy

|            |    |
| ---------- | -- |
| **Number** | 33 |

| Direction | Name        | Type  |
| --------- | ----------- | ----- |
| in        | `src_index` | `u32` |
| in        | `dst_index` | `u32` |

Errors:

- `InvalidSyscallInput` if the hash computation at `src_index` does not exist, or if `dst_index` does not already hold a hash computation and there are too many active hash buffers.

Copies the in-progress SHA-256 hash computation at `src_index` to `dst_index`, replacing any hash computation already at `dst_index`. Both computations can then be extended and finalized independently. Copying an index onto itself succeeds and changes nothing.



## Calldata



### GetCalldataLen

|            |   |
| ---------- | - |
| **Number** | 2 |

| Direction | Name               | Type                  |
| --------- | ------------------ | --------------------- |
| out       | `len`              | `RuntimeMemoryLength` |
| out       | `auth_token_count` | `u32`                 |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the length of the calldata supplied to the invocation associated with the current call frame, plus the number of auth tokens supplied to that invocation.



### GetCalldata

|            |   |
| ---------- | - |
| **Number** | 3 |

| Direction | Name               | Type                  |
| --------- | ------------------ | --------------------- |
| out       | `buffer`           | `[u8]` (span)         |
| out       | `written_len`      | `RuntimeMemoryLength` |
| out       | `auth_token_count` | `u32`                 |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the calldata and the number N of auth tokens supplied to the invocation associated with the current call frame. Auth-token ids are local to each frame; the supplied tokens are ids `0..N-1`.



## Logging



### ConsoleLog

|            |   |
| ---------- | - |
| **Number** | 4 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Logs the input buffer to the console. No-op on release builds and on-chain; calling it from a production contract is harmless but pointless.



### LogEvent

|            |    |
| ---------- | -- |
| **Number** | 24 |

| Direction | Name     | Type                         |
| --------- | -------- | ---------------------------- |
| in        | `topic0` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic1` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic2` | `Option<Topic>` (`[u8; 32]`) |
| in        | `data`   | `[u8]` (span)                |

Errors:

- `InvalidSyscallInput` if the serialized event (32 bytes per topic plus the data) is longer than the maximum event length (1,024 bytes), the transaction has already emitted 1,000 events, or topics are not supplied as a continuous prefix (for example `topic0` and `topic2` without `topic1`).

Emits an event with up to three 32-byte topics and a data payload. The serialized event is `topic0 || topic1 || topic2 || data`, with a separate `num_topics` field that lets downstream indexers filter on the leading topic chunks. Events are accumulated into a per-block merkle-patricia trie.



## Invocation



### Invoke

|            |   |
| ---------- | - |
| **Number** | 5 |

| Direction | Name                        | Type                                                                                       |
| --------- | --------------------------- | ------------------------------------------------------------------------------------------ |
| in        | `address`                   | `ContractAddress`                                                                          |
| in        | `calldata`                  | `[u8]` (span)                                                                              |
| in        | `owned_auth_token_ids_list` | `[u8]` (span, interpreted as `[u32]`)                                                      |
| in        | `inputs`                    | `CopyableInvokeInputs` (`entrypoint_id`, `gas_limit`, `flags`, `reserved`)                 |
| out       | `outputs`                   | `CopyableInvokeOutputs` (`return_buffer_len`, `returned_auth_token_count`, `frame_status`) |

Errors:

- `InvalidSyscallInput` if the call is rejected before a child frame runs: the target is missing, the flags are invalid, the calldata is longer than `max_calldata_len`, more auth-token ids are supplied than `max_auth_tokens`, or an auth-token id is malformed, duplicated, or not owned by the current frame.
- `Reentrance` if the invoked address is already on the call stack.
- `InvokeDepthExceeded` if the transaction already holds the maximum number of invocation frames open. Like `Reentrance`, the call is rejected before any child frame runs and the syscall is a no-op. This is a resource limit rather than a malformed call: the same invocation succeeds from a shallower frame.

Invokes the specified entrypoint of the contract at `address` with the supplied calldata and auth tokens, creating a new call frame. The new frame is capped at `min(gas_limit, remaining gas in current frame)`; unused child-frame gas returns to the caller’s execution budget. This is not a token refund. The SDK defaults `gas_limit` to `u64::MAX` so the child inherits everything the parent has left.

`entrypoint_id` is the big-endian interpretation of the 8-byte `ContractEntrypointID` (`ContractEntrypointID::into_u64` in the Rust bindings). `frame_status` is `Return`, `Abort`, or `Fault`; it reports the outcome after a child frame actually runs. A nonzero syscall error means the call was rejected before the child ran and the output struct is untouched.



### GetMsgSender

|            |   |
| ---------- | - |
| **Number** | 1 |

| Direction | Name     | Type              |
| --------- | -------- | ----------------- |
| out       | `sender` | `ContractAddress` |

Errors:

- `IsRootTransaction` if there is no caller (the syscall was made from a root transaction frame).

Returns the contract address of the contract that invoked the current call frame.



### GetCurrentAddress

|            |    |
| ---------- | -- |
| **Number** | 19 |

| Direction | Name      | Type              |
| --------- | --------- | ----------------- |
| out       | `address` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the contract address of the current call frame.



## Return



### Return

|            |   |
| ---------- | - |
| **Number** | 6 |

| Direction | Name                      | Type                                  |
| --------- | ------------------------- | ------------------------------------- |
| in        | `buffer`                  | `[u8]` (span)                         |
| in        | `revert_frame`            | `bool`                                |
| in        | `returned_auth_token_ids` | `[u8]` (span, interpreted as `[u32]`) |

Errors:

- `Fault` (the current frame faults, like `Exit`) if the buffer is longer than `max_return_buffer_len`, a frame marked for revert returns auth tokens, or the auth-token id list is longer than `max_auth_tokens`, malformed, duplicated, or names tokens the current frame does not own.

Does not return to the caller (terminates execution of the current guest invocation).

Returns data and a set of auth-token ids from the current call frame and optionally marks the frame for revert. The return buffer is made available to the caller via `GetReturnedBuffer`.



### GetReturnedBuffer

|            |   |
| ---------- | - |
| **Number** | 7 |

| Direction | Name                        | Type                  |
| --------- | --------------------------- | --------------------- |
| out       | `buffer`                    | `[u8]` (span)         |
| out       | `written_len`               | `RuntimeMemoryLength` |
| out       | `returned_auth_token_start` | `u32`                 |
| out       | `returned_auth_token_count` | `u32`                 |

Errors:

- `NoReturnBufferAvailable` if no return buffer is available: the most recent subcall faulted (for example by trapping or calling `Exit`), or no subcall has been made in this frame.

Returns the return buffer and the returned auth tokens from the most recent subcall that ended with `Return`. The tokens join the current frame as ids `returned_auth_token_start` to `returned_auth_token_start + returned_auth_token_count - 1`.



### Exit

|            |   |
| ---------- | - |
| **Number** | 8 |

No inputs. No outputs. Does not return.

Errors: none beyond the universal `Fault` / `NoSyscall`.

Terminates the current call frame immediately. The frame reverts and the caller sees a deterministic error with no return buffer available.



## Storage



### BytestringGetLen

|            |    |
| ---------- | -- |
| **Number** | 13 |

| Direction | Name     | Type                     |
| --------- | -------- | ------------------------ |
| in        | `key`    | `StorageKeyContractData` |
| out       | `length` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist in the current transaction view.
- `InvalidSyscallInput` if the key exists but holds a different storage type (e.g. NNInt rather than bytestring).

Returns the length of the bytestring stored at `key`.



### BytestringGet

|            |    |
| ---------- | -- |
| **Number** | 14 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| out       | `bytestring`  | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted.
- `InvalidSyscallInput` if the key exists but holds a different storage type.

Retrieves the bytestring stored at `key`.



### BytestringSet

|            |    |
| ---------- | -- |
| **Number** | 15 |

| Direction | Name         | Type                     |
| --------- | ------------ | ------------------------ |
| in        | `key`        | `StorageKeyContractData` |
| in        | `bytestring` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the bytestring is too long.

Writes the bytestring value at `key`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged.



### NonnegativeIntGet

|            |    |
| ---------- | -- |
| **Number** | 16 |

| Direction | Name                       | Type                     |
| --------- | -------------------------- | ------------------------ |
| in        | `key`                      | `StorageKeyContractData` |
| in        | `force_load_from_snapshot` | `bool`                   |
| out       | `current_set`              | `i128`                   |
| out       | `current_set_opt`          | `bool`                   |
| out       | `current_add`              | `i128`                   |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted (only returned when `force_load_from_snapshot` is true).
- `InvalidSyscallInput` if the key exists but holds a different storage type (only returned when `force_load_from_snapshot` is true).

Retrieves the NNInt value at `key`.

If `force_load_from_snapshot` is true, `current_set` will never be null: the syscall reads the snapshot value. A snapshot that is not an NNInt, or a prior write on this key that is not an NNInt, returns `InvalidSyscallInput`. A snapshot that does not exist, or was deleted by a prior write, returns `StorageKeyNotExist`.

If `force_load_from_snapshot` is false, the prior snapshot state is ignored unless the prior write on `key` is itself an NNInt write (in which case the parameters of that write are returned). If the prior write is not an NNInt or was a deletion, the syscall returns `(None, 0)` without error.



### NonnegativeIntSetAdd

|            |    |
| ---------- | -- |
| **Number** | 17 |

| Direction | Name        | Type                     |
| --------- | ----------- | ------------------------ |
| in        | `key`       | `StorageKeyContractData` |
| in        | `set_value` | `Option<i128>`           |
| in        | `add_value` | `i128`                   |

Errors:

- `InvalidSyscallInput` if the operation would always violate the NNInt floor (for example `set_add(1, -2)` or `set_add(-1, -1)`).

Sets or modifies the NNInt at `key`. `set_value` (if `Some`) supplies the base, and `add_value` is added as a delta. The resolved value must satisfy `value >= min(set, 0)`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged. See [Programming Model: NNInt](pages/programming-model/nnint.md) for commutativity rules.



### DeleteObject

|            |    |
| ---------- | -- |
| **Number** | 18 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Deletes the object at `key`. Leaves the key’s [storage flags](pages/reference/syscalls.md#storage-flags) unchanged.



## Storage Flags

A transaction keeps one `StorageDeltaFlagSet` per storage key, separate from its writes. Every change the transaction commits on a key carries that key’s flags. `ExclusiveLock` (`0x1`) is the only flag: it gives the key’s change an exclusive lock for the whole block, so no concurrent transaction in the block can modify the key.

Writes never change a key’s flags. A lock requested after one write stays on the key through later writes in the same transaction, including writes from other call frames, until `ClearStorageFlags` withdraws it. Flag changes follow call frames like writes do: a successful frame passes them to its caller, and a reverted frame or failed `try_invoke` discards them.

Each flag syscall costs the same storage access gas as a write and does not read the ledger.



### SetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 36 |

| Direction | Name    | Type                                    |
| --------- | ------- | --------------------------------------- |
| in        | `key`   | `StorageKeyContractData`                |
| in        | `flags` | `StorageDeltaFlagSet` (`u32`, by value) |

Errors:

- `InvalidSyscallInput` if `flags` contains an unknown flag, or no write to `key` is pending in the current call frame’s view of the transaction.

Adds `flags` (bitwise OR) to the flags the transaction requests for `key`. A pending write is one made earlier in this frame, or inherited from a caller or a successful callee. A pending deletion counts. A value that exists only in the block snapshot does not.



### GetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 37 |

| Direction | Name    | Type                     |
| --------- | ------- | ------------------------ |
| in        | `key`   | `StorageKeyContractData` |
| out       | `flags` | `StorageDeltaFlagSet`    |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the flags the transaction requests for `key`, as visible in the current call frame. A key with no pending write returns `None` (`0`). Allowed in read-only frames.



### ClearStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 38 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Removes every flag the transaction requests for `key`, as visible in the current call frame. Does nothing if no write to `key` is pending.



## Retrocausal Queue



### RetrocausalQueueInsert

|            |    |
| ---------- | -- |
| **Number** | 20 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `queue_entry` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type that cannot be converted to a retrocausal queue, if the entry is too large, or if too many entries are inserted in the current transaction.

Inserts an entry into the retrocausal queue at `key`.



### RetrocausalQueueConsume

|            |    |
| ---------- | -- |
| **Number** | 21 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `peek`        | `bool`                   |
| out       | `queue_entry` | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `NoRetrocausalQueueEntry` if the queue is empty.
- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Consumes (or with `peek = true`, only inspects) the next entry from the retrocausal queue at `key`.



### RetrocausalQueuePeekLen

|            |    |
| ---------- | -- |
| **Number** | 30 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |
| out       | `len` | `RuntimeMemoryLength`    |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `NoRetrocausalQueueEntry` if the queue is empty.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Returns the length (in bytes) of the next entry in the retrocausal queue at `key`.



## Auth



### VerifySignature

|            |    |
| ---------- | -- |
| **Number** | 12 |

| Direction | Name         | Type                        |
| --------- | ------------ | --------------------------- |
| in        | `scheme`     | `i32` (CryptographicScheme) |
| in        | `signature`  | `[u8]` (span)               |
| in        | `public_key` | `[u8]` (span)               |
| in        | `message`    | `[u8]` (span)               |

No outputs: the result is the `SyscallErrorCode` itself (`None` on success).

Errors:

- `InvalidSyscallInput` if verification fails or the inputs are malformed (wrong key/signature size for the chosen scheme, unsupported scheme, etc.).

Verifies a cryptographic signature against a public key and message.



### GetAuthClaim

|            |    |
| ---------- | -- |
| **Number** | 25 |

| Direction | Name         | Type        |
| --------- | ------------ | ----------- |
| out       | `auth_claim` | `AuthClaim` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the authentication claim associated with the current transaction. Takes no input.



### ChangePublicKeyRegistration

|            |    |
| ---------- | -- |
| **Number** | 23 |

| Direction | Name         | Type                                |
| --------- | ------------ | ----------------------------------- |
| in        | `key_index`  | `u32`                               |
| in        | `key_scheme` | `Option<i32>` (CryptographicScheme) |
| in        | `key_bytes`  | `[u8]` (span)                       |
| in        | `key_weight` | `Option<u32>`                       |

Errors:

- `InvalidSyscallInput` if the registration is invalid or `key_index` is out of bounds.

Changes the public key registration for the current contract address at `key_index`. If `key_scheme` is `None`, the key is removed. Otherwise the key is set with the supplied scheme, bytes, and weight.



### WriteAddressRequiredWeight

|            |    |
| ---------- | -- |
| **Number** | 28 |

| Direction | Name              | Type                       |
| --------- | ----------------- | -------------------------- |
| in        | `required_weight` | `Weight` (`u32`, by value) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Writes the required-weight threshold for the current contract address. This is the minimum total weight of signing keys needed to authorize a transaction from this address.



### MintAuthToken

|            |    |
| ---------- | -- |
| **Number** | 31 |

| Direction | Name                    | Type          |
| --------- | ----------------------- | ------------- |
| in        | `expiry_height`         | `BlockHeight` |
| in        | `serialized_auth_token` | `[u8]` (span) |
| out       | `token_id`              | `u32`         |

Errors:

- `InvalidSyscallInput` if the serialized token fails to parse as a valid `AuthToken`, `expiry_height` is in the past, or minting would exceed the per-transaction auth-token cap.

Mints an authentication token for the current contract address.



### ConsumeAuthToken

|            |    |
| ---------- | -- |
| **Number** | 32 |

| Direction | Name                       | Type                  |
| --------- | -------------------------- | --------------------- |
| in        | `token_id`                 | `u32`                 |
| out       | `auth_payload`             | `[u8]` (span)         |
| out       | `token_minter`             | `ContractAddress`     |
| out       | `auth_payload_written_len` | `RuntimeMemoryLength` |
| out       | `unwrapped_token_id_start` | `u32`                 |
| out       | `unwrapped_token_id_count` | `u32`                 |

Errors:

- `InvalidSyscallInput` if the token is not owned by the current contract address, or the token has expired.

Consumes an authentication token owned by the current contract address. Returns the token’s auth payload, its minter, and the id range of any nested tokens unwrapped as a side effect.



## Address



### GetDeployAddress

|            |   |
| ---------- | - |
| **Number** | 9 |

| Direction | Name             | Type              |
| --------- | ---------------- | ----------------- |
| in        | `caller_address` | `ContractAddress` |
| in        | `nonce`          | `SHA256Hash`      |
| in        | `contract_hash`  | `SHA256Hash`      |
| out       | `to_be_deployed` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Computes the address that would be deployed for a contract with the given deployer address, nonce, and contract hash. Pure computation; does not deploy anything.



### DeployContract

|            |    |
| ---------- | -- |
| **Number** | 10 |

| Direction | Name               | Type              |
| --------- | ------------------ | ----------------- |
| in        | `nonce`            | `SHA256Hash`      |
| in        | `contract_hash`    | `SHA256Hash`      |
| out       | `deployed_address` | `ContractAddress` |

Errors:

- `InvalidSyscallInput` if the requested contract is not available for deployment, or the contract is a special precompiled (native) contract that cannot be deployed. A contract must either already exist on chain or be supplied in the transaction’s `contracts_to_deploy` field.
- `ContractAlreadyDeployed` if a contract with the same nonce and contract hash has already been deployed at the computed address in a previous block or earlier in this transaction. A contract can be deployed multiple times concurrently in the same block; if a contract must initialize only once, gate the initialization on a semaphore.

Deploys a contract with the specified nonce and contract hash at the computed address.



## Block



### GetBlockHeight

|            |    |
| ---------- | -- |
| **Number** | 29 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| out       | `result` | `BlockHeight` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the current block height.



### GetBlockTimepoint

|            |    |
| ---------- | -- |
| **Number** | 35 |

| Direction | Name              | Type        |
| --------- | ----------------- | ----------- |
| out       | `block_timepoint` | `TimePoint` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the timepoint of the block currently executing. The value is fixed by the coordinator before execution begins and is carried in the block’s `ProposalHeader`, so it is part of the block identity and is identical for every invocation in the block.

Like a block height, this is consensus data rather than a trusted clock: it is chosen by the proposer within whatever bounds the network’s validators enforce. Contracts should treat it as coarse-grained wall-clock time, suitable for expiries, vesting schedules, and deadlines, and must not rely on it for fine-grained ordering or as a source of randomness.



## Network



### GetNetworkHash

|            |    |
| ---------- | -- |
| **Number** | 34 |

| Direction | Name           | Type          |
| --------- | -------------- | ------------- |
| out       | `network_hash` | `NetworkHash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the network name, the identifier that separates this network’s blocks from those of every other network. It is fixed for the life of the network, so it is constant across every block and every invocation.

Transaction signatures already commit to this value (the signature preimage is `cxs(DomainSeparator("Transaction")) || network_hash || xdr(tx)`). Exposing it to contracts lets a contract bind its own off-chain signed messages to this network the same way, so a message signed for one network cannot be replayed against a contract at the same address on another.



## Transaction



### GetSourceTransactionHash

|            |    |
| ---------- | -- |
| **Number** | 11 |

| Direction | Name             | Type         |
| --------- | ---------------- | ------------ |
| out       | `source_tx_hash` | `SHA256Hash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the transaction that initiated the current execution.



### GetTransactionStatistics

|            |    |
| ---------- | -- |
| **Number** | 22 |

| Direction | Name        | Type                   |
| --------- | ----------- | ---------------------- |
| in        | `statistic` | `TransactionStatistic` |
| out       | `result`    | `u64`                  |

Errors:

- `InvalidSyscallInput` if the requested statistic does not exist or is not available in this configuration.

Returns a transaction statistic. Statistics may be disabled in release builds or production execution, and may be nondeterministic in test configurations. Nondeterministic stats are disabled in production settings.



## Error Codes

The full `SyscallErrorCode` enum, from `protocol/syscall_error.x`:

| Code | Name                               | Description                                                                                                                                                                                                                              |
| ---- | ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 0    | `None`                             | Success.                                                                                                                                                                                                                                 |
| 1    | `Fault`                            | A pointer argument is out of guest memory bounds. Any syscall can return this.                                                                                                                                                           |
| 2    | `NoSyscall`                        | The supplied syscall number is not supported. Any syscall can return this.                                                                                                                                                               |
| 3    | `IsRootTransaction`                | Cannot call `GetMsgSender` from a root invocation.                                                                                                                                                                                       |
| 4    | `Reentrance`                       | Reentrance guard violation: the invoked address is already on the call stack.                                                                                                                                                            |
| 5    | `ContractAlreadyDeployed`          | Attempt to deploy a contract twice (same nonce, contract hash, and deployer).                                                                                                                                                            |
| 6    | `NoReturnBufferAvailable`          | No return buffer from a child call frame. Either the most recent subcall faulted or no subcall has been made in this frame.                                                                                                              |
| 7    | `InvalidSyscallInput`              | Invalid input to a syscall (type mismatch, value out of range, data too long, unknown storage flag, etc.).                                                                                                                               |
| 8    | `StorageKeyNotExist`               | The storage key does not exist in the current view.                                                                                                                                                                                      |
| 9    | `NoRetrocausalQueueEntry`          | The retrocausal queue is empty.                                                                                                                                                                                                          |
| 10   | `RetrocausalQueueReadLimitReached` | The transaction reached its concurrent RCQ read limit. The contract may use this as a stop condition.                                                                                                                                    |
| 11   | `InvokeDepthExceeded`              | The transaction already holds the maximum number of invocation frames open, so another would exceed the network’s cross-invoke depth bound. A resource limit, not a malformed call: the same invocation succeeds from a shallower frame. |

---

## TypeScript

Source: <https://thruput.network/docs/typescript/>

Connect applications and services to Project Thruput with the TypeScript client and typed contract bindings.

Build browser applications, Node.js services, and scripts with `@thruputchain/client`. You can read an existing contract without a wallet, signing key, Rust installation, or deployment.



## The application model

A **public client** connects to an RPC endpoint and reads network data. A **contract binding** describes methods, arguments, results, errors, and events. Together they provide typed contract reads.

Writes also need an **account** and authorization. A browser app connects to the user’s wallet provider. A script or service can manage a signer directly. A wallet client wraps application calls into a transaction, signs it, submits it, and observes its result.

```text
Read:   contract binding + public client → typed result
Write:  contract binding + wallet client → signed transaction → receipt
```



## How the packages fit

| Package or entry point           | Role                                                                                    |
| -------------------------------- | --------------------------------------------------------------------------------------- |
| `@thruputchain/client`           | RPC clients, accounts, wallet helpers, amounts, and contract runtime                    |
| `@thruputchain/client/contracts` | Standard contract bindings supplied with the client, including ERC-20 and DefaultWallet |
| `@thruputchain/protocol`         | Wire types, serialization, and protocol constants such as `NATIVE_TOKEN_ADDRESS`        |
| `@thruputchain/contract-spec`    | Contract schema tooling; most applications use the generated binding instead            |
| `@thruputchain/react`            | React integration over the client and wallet model; see [React](pages/react.md)         |

Generated bindings are application files, not a replacement for the client package. They import its contract runtime.



## Start with an existing contract

The [TypeScript quickstart](pages/get-started/typescript.md) reads Futurenet’s native-token contract using its supplied binding and address. [Read contract data](pages/typescript/reads.md) uses the same checkpoint, so you can learn the application APIs without first writing a contract.

For a custom contract, obtain its generated bindings, deployment address, and network from its author. [Use contract bindings](pages/tools/typescript-bindings.md) explains how those pieces fit.

[Read events](pages/typescript/events.md) completes the read-only path with filters, decoding, and historical pagination. It also needs no wallet or signer.



## Add writes

Read [Accounts and wallet clients](pages/typescript/wallet-clients.md) to understand account identity, authorization, and call wrapping. Then choose one integration path for your application:

- [Connect a wallet](pages/tools/wallet-integration.md) when the user’s browser wallet manages approval and signing.
- [Use a signer in scripts](pages/typescript/accounts.md) when your Node.js process manages the account key.

These are alternatives, not consecutive setup steps. Both lead to [Send transactions](pages/typescript/transactions.md) and [Track transaction results](pages/typescript/transaction-status.md). [Deploy a contract](pages/typescript/deployment.md) builds on that transaction flow when your application needs to create a deployment.

Complete applications live in [Guides](pages/guides.md). This section covers individual tasks; [Client API reference](pages/tools/typescript-sdk.md) and [Wallet provider reference](pages/tools/wallet-provider.md) provide lookup tables.

---

## Package setup

Source: <https://thruput.network/docs/typescript/setup/>

Configure access to Project Thruput's JavaScript packages for TypeScript and React applications.

The private `@thruputchain` TypeScript client and React library are distributed through GitHub Packages. Configure registry access once, then install the packages your application imports.



## Before you start

- Install Node.js 22.12 or newer and npm.
- Obtain access to Project Thruput’s GitHub packages.
- Install the [GitHub CLI](https://cli.github.com/) and sign in with `gh auth login`.



## Give npm package access

Authorize package reads, then make the token available to npm in this terminal:

```bash
gh auth refresh -h github.com -s read:packages
export NODE_AUTH_TOKEN="$(gh auth token)"
```

Create a `.npmrc` file in the application directory:

```ini
@thruputchain:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Keep `${NODE_AUTH_TOKEN}` as a literal reference in this file. Do not replace it with the token. If your environment already supplies a package-read token, use that instead of the GitHub CLI commands.

These pages use `@thruputchain/client` 0.24.0 with `@thruputchain/protocol` 0.19.0. Install those versions and keep the generated lockfile. A package-access error needs an account or token with the required permissions; repository access alone may not be enough.



## Install the TypeScript client

In a new application directory:

```bash
npm init -y
npm pkg set type=module
npm install --save-exact @thruputchain/client@0.24.0 @thruputchain/protocol@0.19.0
npm install --save-dev typescript tsx @types/node
mkdir -p src
```

In an existing application, keep its package configuration and add the dependencies you need. `tsx` runs the Node.js examples; browser apps can use their existing bundler.

The client re-exports common types and constructors. Install the protocol package directly when you import protocol-only constants such as `NATIVE_TOKEN_ADDRESS`. Use the protocol version that the client requires; a different version installs a second copy. Schema tooling can import `@thruputchain/contract-spec`; ordinary generated bindings use the client runtime.



## Type-check an application

For the Node.js examples, create `tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "skipLibCheck": true,
    "noEmit": true
  },
  "include": ["src/**/*.ts"]
}
```

```bash
npx tsc
```

The examples use ESM imports and `.js` paths for local TypeScript modules. Browser projects should keep the module settings required by their bundler.

---

## Connect to a network

Source: <https://thruput.network/docs/typescript/connect/>

Create a public client, select Futurenet or a local endpoint, and check network identity.

A public client performs RPC reads without signing. Create one per application network and share it across contract bindings and wallet clients.



## Connect to Futurenet

Create `src/client.ts`:

```ts
import { createThruputClient, futurenet } from "@thruputchain/client";

export const client = await createThruputClient({ cluster: futurenet() });
```

Client creation is asynchronous. It checks that the endpoint uses RPC wire format 14 and reads its network identity before returning. Other examples import this client from `./client.js`.

To check the connection, create `src/network.ts`:

```ts
import { toBase58 } from "@thruputchain/client";
import { client } from "./client.js";

const [tip, version] = await Promise.all([
  client.getChainTip(),
  client.getVersionInfo(),
]);
console.log("Network:", toBase58(client.network.networkHash));
console.log("Block:", tip.blockHeight.toString());
console.log("Wire format:", version.wireFormat);
```

```bash
npx tsx src/network.ts
```

No wallet permission or account funding is required.



## Select another endpoint

`futurenet({ rpcUrl })` overrides the Futurenet endpoint. The deprecated `devnet()` helper remains available for existing applications and retains its `"devnet"` cluster name. For a local node, replace the cluster with `localnet()`:

```ts
import { createThruputClient, localnet } from "@thruputchain/client";

const client = await createThruputClient({ cluster: localnet() });
```

Start the node with [the CLI](pages/cli/local-node.md) first. The SDK does not read CLI runtime manifests. `localnet()` expects the all-zero network hash unless you provide a custom `networkHash`.

Use `defineCluster()` for a reusable custom descriptor. `mainnet()` requires an explicit endpoint. Cluster capabilities, such as `airdrop`, declare expected services. Client creation throws `RpcCompatibilityError` when the endpoint does not advertise the matching method.



## Pin a network identity

Futurenet is unpinned by default. To require a specific deployment, provide the trusted hash from your environment:

```ts
import { createThruputClient, futurenet, hashFromBase58, networkHash } from "@thruputchain/client";

const expected = process.env.THRUPUT_NETWORK_HASH;
if (!expected) throw new Error("Set THRUPUT_NETWORK_HASH to the expected base58 network hash");
const client = await createThruputClient({
  cluster: futurenet({ networkHash: networkHash(hashFromBase58(expected)) }),
});
```

An identity mismatch throws `RpcCompatibilityError`. Use the base58 `networkHash` from [`getNetworkInfo`](pages/reference/json-rpc-api.md#getnetworkinfo). A Futurenet reset can change the network hash. Update the trusted configuration deliberately rather than accepting a wallet-supplied hash as your application’s network.



## Configure transport behavior

Use [HTTP transport](pages/typescript/transport.md) for timeouts, batching, and custom transports. A transport-only client reads the endpoint’s network but does not pin it. A wallet bound to it requires an explicit signing network hash that matches that network.

---

## Configure HTTP transport

Source: <https://thruput.network/docs/typescript/transport/>

Set RPC timeouts, batch independent reads, and classify transport failures.

The client uses HTTP JSON-RPC by default. Supply `HttpTransport` when you need explicit timeout, header, or batching settings.



## Set a request timeout

```ts
import { createThruputClient, futurenet, HttpTransport } from "@thruputchain/client";

const cluster = futurenet();
const client = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, { timeoutMs: 10_000 }),
});
```

The cluster still controls identity checks; the transport controls requests to the endpoint. A timeout ends observation of that request, not an already-submitted transaction.



## HTTP batching

Batch independent RPC reads into fewer HTTP requests:

```ts
const batched = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, {
    batch: { maxSize: 100, waitMs: 0 },
    timeoutMs: 10_000,
  }),
});
const [tip, version] = await Promise.all([
  batched.getChainTip(),
  batched.getVersionInfo(),
]);
```

Batching is off by default. `batch: true` uses the defaults shown. Concurrent requests are grouped within the scheduling window and split at `maxSize`.

- Responses match by request ID, not array position.
- Per-call RPC errors remain separate. HTTP or malformed-batch failures reject affected requests.
- Cancellation removes one caller; canceling every caller can cancel the shared request.
- HTTP batching does not provide a shared state snapshot or an atomic transaction. Use [shared-snapshot reads](pages/typescript/reads.md#read-related-values-from-one-snapshot) when related contract values must come from one state; awaiting separate reads does not make their snapshots match.

Server [array and byte limits](pages/reference/json-rpc-api.md#json-rpc-arrays) still apply.



## Handle transport errors

| Error                                       | Boundary                                                                                              |
| ------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `HttpRequestError`                          | Network request failed                                                                                |
| `HttpResponseError`                         | Non-success HTTP status                                                                               |
| `NativeRpcError`                            | RPC error response; a `JsonRpcError` with `code`, `data`, method context, and a typed `decoded` cause |
| `RpcCompatibilityError`                     | Unsupported wire format, network mismatch, or unadvertised method                                     |
| `RpcRequestValidationError`                 | Invalid local request, rejected before dispatch                                                       |
| `RpcDecodingError`                          | Malformed result; retains the raw value                                                               |
| `ContractViewError` / `ContractDecodeError` | Contract outcome or decoding, not transport                                                           |

`NativeRpcError.decoded` is `known` with a `data.kind` from the [error codes](pages/reference/json-rpc-api.md#error-codes), or `unclassified`. Neither grants retry permission. Use `classifyReadError(error, { signal })` when implementing a bounded read-retry policy. See [read cancellation](pages/typescript/reads.md#cancel-stale-reads). Do not apply automatic read retries to transaction submission.



## Use a custom transport

Implement the exported `Transport` interface when integrating another request layer. A client created with only a transport has no validated cluster identity. For wallet use, provide a trusted signing network hash and verify the endpoint separately, or supply a cluster descriptor as above.

---

## Addresses and amounts

Source: <https://thruput.network/docs/typescript/values/>

Parse and display exact amounts, addresses, and hashes in a TypeScript application.

Contract integers are JavaScript `bigint` values. Addresses and hashes are typed byte arrays. Convert at the application’s input and display boundaries.



## Parse and display amounts

```ts
import { parseUnits, formatUnits } from "@thruputchain/client";

const amount = parseUnits("12.05", 2); // 1205n
console.log(formatUnits(amount, 2));  // "12.05"
const oneToken = parseUnits("1", 7);  // 10000000n
```

Both helpers support 0–255 decimals and signed amounts. Parsing rejects whitespace, exponents, and excess precision rather than rounding. `ParseUnitsError.code` is `malformed` or `precision`; invalid decimal counts throw `RangeError`.

The native token has seven decimal places. Other tokens choose their own decimals. Check positivity and the contract’s integer bounds separately. Avoid converting amounts to `number`, which can lose precision.



## Convert addresses and hashes

Addresses and transaction and network hashes are unprefixed, case-sensitive base58 in RPC responses, the CLI, and wallet providers. Use base58 for any identifier that users see or paste, that you store, or that you compare with those values:

```ts
import { addressFromBase58, hashFromBase58, toBase58 } from "@thruputchain/client";

export function parseIdentifiers(addressText: string, transactionText: string) {
  const address = addressFromBase58(addressText);
  const transactionHash = hashFromBase58(transactionText);
  return { address, transactionHash, displayAddress: toBase58(address) };
}
```

Both parsers require 32 decoded bytes.

`parseAddress(text)` also accepts a Thruput `Z` StrKey address. `addressToStrkey(address)` formats address bytes with the Z prefix. Stellar C addresses are rejected. Z does not distinguish local, test, and production networks; select the intended cluster. Ed25519 public keys and seeds retain their G and S StrKey formats. A G public key is not a Thruput wallet address.

Use `toHex0x` and `fromHex0x` for signed transaction bytes, calldata, raw event topics, and storage keys. These opaque byte fields stay `0x`-prefixed hex.

Use `gasAmount(500_000n)` for a typed gas budget. A gas amount is a computation limit, not a native-token amount.



## Store values in application data

JavaScript’s default JSON serializer does not accept `bigint`. For application-owned storage, use decimal strings for integers and base58 for addresses and hashes. Store event and history cursors as the opaque strings the client returns. The client handles RPC serialization itself.

---

## Use contract bindings

Source: <https://thruput.network/docs/tools/typescript-bindings/>

Select a generated interface, bind a deployment address, and work with typed arguments and results.

Bindings describe a contract’s API. The client runtime uses them to encode arguments and decode results, exceptions, and events. A binding does not select a network or deployment address.



## Obtain the binding

The client supplies standard bindings such as `ERC20` through `@thruputchain/client/contracts`. For a custom contract, obtain its generated `.ts` file, address, and network from the contract author.

Generate a binding yourself only when you have its build or canonical spec. See [CLI code generation](pages/cli/codegen.md) and [the contract-side handoff](pages/contracts/client-bindings.md).

Regenerate when methods, argument or return types, declared exceptions, or events change. Keep the generated file and deployment from the same interface build. Put application wrappers in separate files.



## Select an Interface Version

```ts
import { ERC20 } from "@thruputchain/client/contracts";

const tokenInterface = ERC20.v0_1;
```

Methods and their types live under an interface’s compatibility major. A generated counter might export `Counter.v0_1`; use the actual exports in its generated file rather than reconstructing names.

```ts
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;
const args: CounterVersions.v0_1.IncrementArgs = { amount: 1n };
```

The value alias does not create a TypeScript type namespace. Keep the full path for explicit type annotations.



## Bind a deployment

```ts
import { getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const nativeToken = getContract({ binding: ERC20.v0_1, address: NATIVE_TOKEN_ADDRESS, client });
const supply = await nativeToken.totalSupply.view({ args: undefined });
```

`getContract` binds the descriptor to an address and client. It does not deploy or authorize anything. Use [Read contract data](pages/typescript/reads.md) for view behavior and caller context.



## Method Descriptors

| API                                                                                            | Purpose                                                                                                         |
| ---------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `method.invocation(contract, gasLimit, args)`                                                  | Build calldata and the target invocation                                                                        |
| `method.call({ address, gasLimit, args })`                                                     | Retain result and exception decoders with the invocation                                                        |
| `method.view({ client, address, args, caller?, assumedAuth?, minStateBlockHeight?, signal? })` | Read a typed value with `stateBlockHeight`, gas use, and events; optional freshness floor                       |
| `method.viewOutcome(...)`                                                                      | Return a typed return/abort/fault/unsupported outcome                                                           |
| `method.viewRequest({ address, args, caller?, assumedAuth? })`                                 | Prepare an independent read with its decoder for `client.readViews`; no I/O, and freshness belongs to the group |
| `method.decodeArgs(bytes)`                                                                     | Decode complete calldata                                                                                        |
| `method.decodeReturn(bytes)` / `decodeException(bytes)`                                        | Decode known method output                                                                                      |
| `method.decodeReceipt(receipt)` / `decodeReceiptOutcome(receipt)`                              | Decode a receipt for that root method                                                                           |

Direct descriptor calls can omit absent arguments. Bound argumentless views use `{ args: undefined }`. Public argument names use camelCase; ABI names remain in metadata. Contract integers use `bigint`.

Existing generated bindings gain `viewRequest()` through the client runtime; this feature needs no new codegen metadata. See [shared-snapshot reads](pages/typescript/reads.md#read-related-values-from-one-snapshot) for grouped calls and [minimum heights](pages/typescript/reads.md#read-after-confirmation) for single reads.



## Execute and Decode

Build calls with `.call(...)` when the application needs typed return values, then pass them to a wallet’s `executeCallsAndWait`. Returned values follow call order. See [Send transactions](pages/typescript/transactions.md).

Receipt decoders require the known root method. For wallet-wrapped calls, use the wallet execution helpers or `decodeExecution(receipt, calls)` instead of treating the receipt as the child’s receipt. See [Track transaction results](pages/typescript/transaction-status.md#decode-the-correct-method).



## Exceptions

Each interface exposes declared and unknown exception types. A declared exception has `kind: "declared"`, selector, name, decoded value, and a symbolic variant for enum errors. An unknown selector has `kind: "unknown"`, selector, and its raw data.

Return and declared-exception decoders reject trailing bytes. Unknown exceptions retain the bytes they cannot interpret. A successful transaction whose result cannot be decoded is still a successful execution.



## Events

Events use their defining crate, version, module, and type path. A descriptor builds topic filters, decodes event rows, and selects events from receipts. See [Read events](pages/typescript/events.md) for examples and pagination.



## Type Mapping

Bindings describe structs, enum variants, unions, tuples, and optional values. Use the generated types rather than rebuilding their shapes or encoding calldata manually.

| Contract type              | TypeScript type                        |
| -------------------------- | -------------------------------------- |
| Void                       | `void`                                 |
| Bool                       | `boolean`                              |
| Integer                    | `bigint`                               |
| String                     | `string`                               |
| Address                    | `ContractAddress`                      |
| Bytes / vector of u8       | `Uint8Array`                           |
| Other vectors              | `T[]`                                  |
| Fixed bytes                | `FixedBytes<N>`                        |
| Fixed arrays of length 0–3 | Exact readonly tuple                   |
| Longer fixed arrays        | `FixedArray<T, N>`                     |
| Tuple                      | Readonly tuple                         |
| Option                     | `T \| null`                            |
| Named struct               | Interface in its spec-ID namespace     |
| Enum                       | Bigint value union and const object    |
| Union                      | Discriminated `{ case, value? }` union |
| SignedToken                | `SignedToken<T>` placeholder           |

`fixedBytes` validates and brands mutable bytes; `fixedArray` returns a frozen copy. `signedToken<T>()` supplies a zero-byte placeholder, not authorization. See [Addresses and amounts](pages/typescript/values.md) for input conversion.



## Standard Bindings

The client includes versioned DefaultWallet and ERC-20 interfaces, plus related metadata, permit, and signed-operation interfaces. Use the [generated client API](https://client-ts.thruput.network/) for the complete export list.

---

## Read contract data

Source: <https://thruput.network/docs/typescript/reads/>

Read typed contract values, require a minimum height, and group related reads at one committed snapshot.

A view simulates a contract call against committed state without submitting a transaction. It needs a public client and a binding, not a signer.



## Read the existing native-token contract

Use the `src/client.ts` from [Connect to a network](pages/typescript/connect.md). Create `src/read.ts`:

```ts
import { formatUnits, getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const nativeToken = getContract({ binding: ERC20.v0_1, address: NATIVE_TOKEN_ADDRESS, client });
const result = await nativeToken.totalSupply.view({ args: undefined });
console.log("Native-token supply:", formatUnits(result.value, 7));
console.log("Read at block:", result.stateBlockHeight.toString());
```

```bash
npx tsx src/read.ts
```

The client supplies the standard ERC-20 binding, and the protocol package supplies the deployed native-token address as `NATIVE_TOKEN_ADDRESS`. No Rust contract or generated application file is needed for this example.



## Pass arguments and caller context

For a base58 address held by your application:

```ts
import { addressFromBase58 } from "@thruputchain/client";

export async function readBalance(ownerText: string, signal?: AbortSignal) {
  const owner = addressFromBase58(ownerText);
  return nativeToken.getBalanceOf.view({ args: { addr: owner }, signal });
}
```

A view result includes the typed `value`, snapshot `stateBlockHeight`, `gasUsed`, and simulated `events`. Independent reads can use different snapshots or lag a recent transaction receipt.

Pass `caller` when the method needs a simulated caller. Pass `assumedAuth`, such as `account.authClaim`, when the method checks authorization. Both change simulation context only. Simulation does not verify signatures, prove control of an address, or authorize a transaction.



## Read after confirmation

Pass a successful receipt’s `blockHeight` as `minStateBlockHeight` when the read must include that committed transaction:

```ts
export async function readBalanceAtLeast(ownerText: string, minStateBlockHeight: bigint, signal?: AbortSignal) {
  return nativeToken.getBalanceOf.view({
    args: { addr: addressFromBase58(ownerText) },
    minStateBlockHeight,
    signal,
  });
}
```

`minStateBlockHeight` is an optional nonnegative `bigint` freshness floor, not an exact historical height. The same option works with generated `.view()`, `.viewOutcome()`, bound views, and raw `client.simulateInvocation()`. Omit it for an unconstrained read.

A backend whose selected snapshot is behind returns error `-32012` (`NativeRpcErrorCode.StateHeightUnavailable`). Its `data.kind` is `stateHeightUnavailable`, with `requestedStateBlockHeight` and `observedStateBlockHeight`. The request does not wait for a block or force a refresh, and the client does not poll or retry it. Keep the confirmed receipt and decide when to retry the read; this error is not a reason to repeat the write.



## Read related values from one snapshot

Prepare calls with `viewRequest()` and send them together through `readViews()`:

```ts
export async function readTokenSnapshot(ownerText: string, minStateBlockHeight?: bigint, signal?: AbortSignal) {
  const owner = addressFromBase58(ownerText);
  const snapshot = await client.readViews({
    calls: [
      ERC20.v0_1.totalSupply.viewRequest({ address: NATIVE_TOKEN_ADDRESS }),
      ERC20.v0_1.getBalanceOf.viewRequest({
        address: NATIVE_TOKEN_ADDRESS,
        args: { addr: owner },
      }),
    ],
    minStateBlockHeight,
  }, { signal });

  const [supply, balance] = snapshot.results;
  if (supply.kind === "return" && balance.kind === "return") {
    console.log("Shared snapshot:", snapshot.stateBlockHeight.toString());
    console.log("Supply and balance:", supply.value, balance.value);
  } else {
    console.error("Read outcomes:", supply.kind, balance.kind);
  }
  return snapshot;
}
```

`viewRequest()` performs no I/O. `readViews()` returns results in input order, retaining each call’s inferred return and exception types, events, and gas use. Each result is `return`, `abort`, `fault`, or `unsupported`. Transport, freshness, and decoding failures reject the group.

All calls use one committed snapshot, and simulated writes stay within their own call. Put `minStateBlockHeight` on the group, not on individual prepared calls. Two separate reads with the same minimum height can still use different snapshots.

Shared reads require an endpoint that advertises batch simulation limits. Inspect `(await client.getServerLimits()).simulationBatch` for its invocation, gas, calldata, response-size, and timeout limits. The client never splits a group or falls back to separate views. [HTTP batching](pages/typescript/transport.md#http-batching) alone does not provide this guarantee. Raw requests use [`simulateInvocations`](pages/reference/json-rpc-api.md#simulateinvocations) through `client.simulateInvocations({ invocations, minStateBlockHeight }, { signal })`.



## Handle contract outcomes

`view()` throws `ContractViewError` for an abort, fault, or unsupported result. Use `viewOutcome()` when those outcomes belong in your application’s normal control flow:

```ts
const outcome = await nativeToken.totalSupply.viewOutcome({ args: undefined });
if (outcome.kind === "return") {
  console.log(outcome.value);
} else {
  console.error("Contract view failed:", outcome.kind);
}
```

Malformed contract bytes throw `ContractDecodeError`. Transport and RPC failures remain separate from contract outcomes.



## Cancel stale reads

```ts
import { classifyReadError } from "@thruputchain/client";

export async function refreshSupply(signal: AbortSignal) {
  try {
    return await nativeToken.totalSupply.view({ args: undefined, signal });
  } catch (error) {
    if (classifyReadError(error, { signal }) === "cancelled") return;
    throw error;
  }
}
```

Create an `AbortController` for the operation and call `abort()` when its result is no longer needed. RPC actions, including `readViews`, take `{ signal }` as request options; bound views take it inside their options object. Canceling a group ends the client’s wait but does not guarantee that backend execution has stopped.

`classifyReadError` returns `transient`, `permanent`, `cancelled`, or `unknown`. It does not retry or replace the error. Applications choose retry limits; an unclassified `TypeError` is not proof of a network failure.

---

## Read events

Source: <https://thruput.network/docs/typescript/events/>

Filter and decode contract events, walk historical pages, and save progress without missing rows.

Use a generated event descriptor to build filters and decode payloads. This page uses the supplied ERC-20 `TransferEvent`; a custom contract uses the event exported by its generated bindings.



## Query events

With the client from [Connect to a network](pages/typescript/connect.md), create `src/events.ts`:

```ts
import { thruput_erc20_if } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const { TransferEvent } = thruput_erc20_if.v0_1.events;
const page = await client.getContractEvents({
  event: TransferEvent,
  addresses: [NATIVE_TOKEN_ADDRESS],
  start: { order: "descending", anchor: { kind: "atEnd" } },
  limit: 20,
});
for (const event of page.events) {
  console.log(event.blockHeight, event.sequenceNumber, event.fields.amount);
}
```

This fetches one typed page. An empty page is a valid result. Each row retains the emitting contract `address`, `transactionHash`, `blockHeight`, `sequenceNumber`, topics, and decoded fields.

For the next page, repeat `event` and `addresses`, pass `cursor: page.nextCursor`, and omit `start`. `nextCursor: null` ends the walk. An empty page can still have a cursor.



## Filter topics

Add `topics: { to: owner }` to restrict transfers to a typed address. A named topic accepts one value or `{ oneOf: [...] }`. Filters require one to five contract addresses; each topic alternative list accepts 1–16 values.

Addresses, fixed 32-byte values, supported integer scalars, `U256`, `I256`, and bool have direct encodings. Strings and byte slices are hashed. Use the generated filter’s input types; do not reconstruct topic bytes or assume a hashed value can be read back.



## Walk historical pages

For raw event pages, use the descriptor’s filter and decoder:

```ts
import type { EventWalkQuery } from "@thruputchain/client";

const query: EventWalkQuery = {
  filters: [TransferEvent.filter({ addresses: [NATIVE_TOKEN_ADDRESS] })],
  start: { order: "ascending", anchor: { kind: "atBeginning" } },
  limit: 20,
};
for await (const page of client.iterateEventPages(query)) {
  for (const row of page.events) {
    const decoded = TransferEvent.decode(row.event);
    console.log(row.blockHeight, decoded);
  }
}
```

The iterator requests pages on demand and stops at `nextCursor: null`. It fixes the first page’s `latestIndexedBlockHeight` as the walk’s upper bound. It throws `HistoryWalkError` for regressed coverage, lost retention, duplicate or out-of-order rows, and repeated cursors. `decode` returns `null` for a different signature and throws for malformed matching data.

Pass `{ signal }` as the iterator’s second argument to cancel an in-flight read. Breaking the loop stops future requests. There is no automatic retry, polling, subscription, or persistence.



## Resume without missing events

A walk does not follow later blocks. Keep the network, target, and filters fixed. Upsert rows by `(transactionHash, sequenceNumber)` within that network and query.

`for await` discards the iterator’s return value. Call `next()` directly to receive its `HistoryCompletion` after the last page. For an ascending walk, `completedThroughBlockHeight` is the walk’s upper bound. In this example, `store` is application code, not an SDK API:

```ts
const saved = await store.loadCheckpoint(); // bigint | undefined
const pages = client.iterateEventPages({
  ...query,
  start: {
    order: "ascending",
    anchor: saved === undefined
      ? { kind: "atBeginning" }
      : { kind: "atHeight", blockHeight: saved },
  },
});
for (;;) {
  const step = await pages.next();
  if (step.done) {
    const done = step.value.completedThroughBlockHeight;
    if (done !== undefined) await store.saveCheckpoint(done);
    break;
  }
  await store.savePage(step.value.events);
}
```

The next walk starts inclusively at the saved height, so deduplicate that boundary block. A walk that stops early saves no checkpoint; the next run replays from the previous one. A lost-retention `HistoryWalkError` means required blocks are no longer served. `oldestIndexedBlockHeight` and `latestIndexedBlockHeight` are serving bounds, not processed checkpoints.

For a latest-first UI, start a new descending walk from `atEnd` rather than continuing an old cursor. Descending completion is not an ingestion checkpoint.

Raw [`getEvents`](pages/reference/json-rpc-api.md#getevents) continuation sends the cursor with the same filters and no `start`. Treat cursors as opaque strings. Retention bounds and a cursor alone do not prove complete or recoverable history.



## Decode receipt events

Use `TransferEvent.allFromReceipt(receipt, { address: NATIVE_TOKEN_ADDRESS })` to decode matching events in a receipt. `singleFromReceipt` requires exactly one matching event. Both select the emitter as well as the event type; a transaction can call several contracts that emit the same event.

---

## Accounts and wallet clients

Source: <https://thruput.network/docs/typescript/wallet-clients/>

Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.

A public client connects to the network. An account describes the identity and authorization used for a transaction. A wallet client combines that account with the operations needed to prepare, sign, and submit transactions.

Account authorization and wallet call behavior are separate. Authorization determines which signatures can originate a transaction. An invocation adapter determines how a wallet contract wraps calls to other contracts.



## Choose an account model

|                 | Pubkey account                                                                 | Source-address account                                               |
| --------------- | ------------------------------------------------------------------------------ | -------------------------------------------------------------------- |
| Constructor     | `createPubkeyAccount`                                                          | `createSourceAddressAccount`                                         |
| Address         | Derived from a hash of an Ed25519 or ML-DSA-65 public key and an account nonce | Existing address supplied by the application                         |
| Authorization   | One Ed25519 or ML-DSA-65 signer whose key matches the account preimage         | Signer entries and a claim checked against stored authorization data |
| Wallet behavior | DefaultWallet adapter selected automatically                                   | Application-call wrapping requires an appropriate adapter            |
| Typical use     | A script account without a separate wallet deployment                          | An existing account contract with configured signer policy           |

Both constructors create local JavaScript objects. They do not fund an address, deploy code, or change authorization data on chain.



## Create a pubkey account

Given an existing `Signer` named `signer`:

```ts
import { createPubkeyAccount } from "@thruputchain/client";

const account = createPubkeyAccount({ signer, nonce: 0n });
```

The same public key and account nonce produce the same address. The key hash includes the scheme, so one seed gives different addresses under Ed25519 and ML-DSA-65. The nonce defaults to zero and is separate from each transaction’s replay-protection nonce.

An undeployed pubkey account uses the network’s DefaultWallet behavior for its root invocation. No separate wallet deployment is needed. See [Use a signer in scripts](pages/typescript/accounts.md) for key loading and funding.



## Describe a source-address account

For an existing account whose stored policy authorizes your signer at key slot zero with sufficient weight:

```ts
import { createSourceAddressAccount } from "@thruputchain/client";
import { bitMap, weight } from "@thruputchain/protocol";

const account = createSourceAddressAccount({
  address: walletAddress,
  signers: [{ signer, publicKeyId: 0n }],
  allowedKeys: bitMap(0x01n),
  requiredWeight: weight(1n),
});
```

Here, `walletAddress` is the existing account address, not an application contract you want to call. `publicKeyId` identifies a stored signer slot; `allowedKeys` selects slots for the authorization claim. The signatures must satisfy both the stored policy and the claim’s required weight.

The constructor does not register signers or set their weights. Those must already be configured on chain. See [Authorization](pages/how-it-works/authorization.md#source-address-accounts) for the protocol rules.



## Bind an account to a client

With a pubkey `account` and the cluster-aware public client from [Connect to a network](pages/typescript/connect.md):

```ts
import { createWalletClient } from "@thruputchain/client";
import { client } from "./client.js";

const wallet = createWalletClient({ client, account });
```

The wallet is a separate object. It retains public-client operations and adds signing and account operations. Pubkey accounts also receive DefaultWallet execution helpers such as `executeAndWait` and `executeCallsAndWait`. Multiple accounts can share the original public client.

For a source-address account, `createWalletClient` provides transaction preparation and signing, but does not infer how its account contract wraps application calls. Supply an `invocationAdapter` that matches that contract to obtain the execution helpers. Do not select an adapter from the authorization model alone. Custom implementations use `defineWalletInvocationAdapter`; see [Client API reference](pages/tools/typescript-sdk.md#choose-an-account-model).

A cluster-aware client supplies its validated signing network hash. A transport-only client requires an explicit `networkHash` when creating the wallet client, and it must match the endpoint’s network.



## Bind a browser wallet provider

In a browser app, the wallet provider manages signing. Use an authorized account returned by its session:

```ts
import { createProviderWalletClient } from "@thruputchain/client/wallet";

const wallet = createProviderWalletClient({
  client,
  provider,
  account: selectedAccount,
  networkHash: expectedNetworkHash,
});
```

`selectedAccount` is the provider’s wire `WalletAccount`, containing its address, public key, and derivation nonce. It is not the signer-backed account object returned by the constructors above. The provider integration supports pubkey accounts and DefaultWallet behavior; it does not expose a raw signer.

`expectedNetworkHash` is the application’s trusted network identity in provider format: unprefixed base58. It must match the client’s network. The factory does not request connection permission. Follow [Connect a wallet](pages/tools/wallet-integration.md) for discovery, account selection, and session cleanup.

---

## Connect a wallet

Source: <https://thruput.network/docs/tools/wallet-integration/>

Discover browser wallets, connect an account on the intended network, and manage its session.

A browser wallet provider owns account access and transaction approval. Your application receives authorized account information and requests signatures without handling the user’s private key.

For installation and test funds, follow [Wallet Extension](pages/tools/wallet-extension.md).



## Choose the Integration

This page covers the provider-backed path described in [Accounts and wallet clients](pages/typescript/wallet-clients.md). For a Node.js process that manages its own key, use [Use a signer in scripts](pages/typescript/accounts.md). Wallet implementers should use [Wallet provider reference](pages/tools/wallet-provider.md).



## Discover and Connect

Start discovery when the wallet picker mounts and let the user select a provider:

```ts
import { discoverWalletProviders, type WalletProvider } from "@thruputchain/client/provider";

export function mountWalletPicker(showChoice: (provider: WalletProvider) => void) {
  return discoverWalletProviders(showChoice);
}
```

Call the returned cleanup function when the picker unmounts. Discovery supports either load order and reports each provider ID once. Provider IDs and names are display metadata, not proof of identity; render names as text.

Connect from the user’s chosen-wallet action. This helper accepts a public client, the application’s trusted network hash, and an account picker:

```ts
import type { CoreThruputClient } from "@thruputchain/client";
import { parseWalletSession, type WalletAccount, type WalletProvider } from "@thruputchain/client/provider";
import { createProviderWalletClient } from "@thruputchain/client/wallet";

export async function connectWallet(
  client: CoreThruputClient,
  provider: WalletProvider,
  expectedNetworkHash: string,
  chooseAccount: (accounts: readonly WalletAccount[]) => WalletAccount,
) {
  const session = parseWalletSession(await provider.request({ method: "connect" }));
  if (session.networkHash !== expectedNetworkHash) {
    throw new Error("Select the application's network in your wallet");
  }
  if (session.accounts.length === 0) throw new Error("No authorized account");
  const account = chooseAccount(session.accounts);
  if (!session.accounts.includes(account)) throw new Error("Choose an authorized account");

  const wallet = createProviderWalletClient({
    client, provider, account, networkHash: expectedNetworkHash,
  });
  return { wallet, account };
}
```

For a [cluster-aware client](pages/typescript/connect.md), convert its validated network identity with `toBase58(client.network.networkHash)`. Provider network hashes are 32 bytes in unprefixed base58. Do not adopt the wallet’s network as the application’s expected network.

`connect` prompts for access; `getSession` reads existing access without prompting. A disconnected session has no accounts but still reports the wallet’s current network. The adapter does not switch networks.



## Handle Changes and Cleanup

Every provider `change` invalidates the current adapter. A failed session read or mismatched session also invalidates it. Stop offering actions through that binding, update the account/network UI, and construct a new adapter for a newly authorized session.

```ts
import type { WalletProvider } from "@thruputchain/client/provider";
import type { ProviderWalletClient } from "@thruputchain/client/wallet";

export function watchWallet(
  provider: WalletProvider,
  wallet: ProviderWalletClient,
  resetAccountUI: () => void,
) {
  const stopChanges = provider.on("change", () => {
    wallet.dispose();
    resetAccountUI();
  });
  return () => {
    stopChanges();
    wallet.dispose();
  };
}
```

Application callbacks should handle their own UI errors. Call cleanup when the binding is no longer needed. `dispose()` invalidates the adapter but does not revoke wallet permission. The user’s Disconnect action calls `provider.request({ method: "disconnect" })`.



## Prepare, Sign, Save, Submit, Observe

For routine writes, use [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet). The provider helpers require `onSigned` to save the approved transaction before broadcast.

For explicit control, the sequence is:

1. `wallet.prepareExecution(request)` builds the unsigned transaction.
2. `wallet.signTransaction(transaction)` requests approval and verifies the returned bytes, signature, and hash. It does not broadcast.
3. Your application saves the signed result, account, and original network.
4. `wallet.submitTransaction(signed)` broadcasts the latest verified approval once.
5. The public client observes the hash and checks execution. Decode the result’s base58 `hash` with `hashFromBase58` and pass it to `client.waitForTransactionReceipt`.

The adapter allows one in-flight operation. A session change invalidates pending work; do not automatically re-sign it. Signature verification requires Web Crypto, available in browsers on HTTPS or localhost.



## Recover an Ambiguous Submission

Once submission begins, an error may arrive after broadcast. Use the saved hash and original network to [track the transaction](pages/typescript/transaction-status.md), including after disconnect or reload. Do not create a replacement merely because observation timed out.

Use `parseWalletProviderError` for provider errors across browser contexts rather than relying on `instanceof`. The [error table](pages/tools/wallet-provider.md#errors) distinguishes rejection, authorization, network, and transport errors.

For a complete counter interface with wallet-approved updates, follow [Counter, part 4: Connect a wallet](pages/tutorials/connect-a-wallet-to-your-app.md).

---

## Use a signer in scripts

Source: <https://thruput.network/docs/typescript/accounts/>

Bind a Node.js signer to a native account, request Futurenet funds, and use local bootstrap accounts.

Use a signer when your Node.js script or service manages an account’s key. This page sets up a pubkey account. See [Accounts and wallet clients](pages/typescript/wallet-clients.md) for account models and client construction, or [Connect a wallet](pages/tools/wallet-integration.md) for a browser application.



## Bind a signer

Supply a 32-byte Ed25519 private-key seed through your process environment as `THRUPUT_PRIVATE_KEY`, using `0x`-prefixed hex. For a disposable Futurenet test account, generate one once in your terminal:

```bash
export THRUPUT_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep that environment for the funding and send commands. Generating another seed selects another account. For a persistent account, load the existing seed from your secret configuration.

Create `src/wallet.ts`:

```ts
import {
  Ed25519Signer, createPubkeyAccount, createWalletClient, fromHex0x,
} from "@thruputchain/client";
import { client } from "./client.js";

const secret = process.env.THRUPUT_PRIVATE_KEY;
if (!secret) throw new Error("Set THRUPUT_PRIVATE_KEY for this script account");

export const account = createPubkeyAccount({
  signer: Ed25519Signer.fromSeed(fromHex0x(secret)),
});
export const wallet = createWalletClient({ client, account });
```

Keep the key in the process’s secret configuration, not browser code or committed files.

For an ML-DSA-65 account, use the same kind of 32-byte seed with `MlDsa65Signer`:

```ts
import { MlDsa65Signer, createPubkeyAccount, fromHex0x } from "@thruputchain/client";

export const account = createPubkeyAccount({
  signer: MlDsa65Signer.fromSeed(fromHex0x(secret)),
});
```

One seed gives a different account under each scheme. ML-DSA-65 keys have no StrKey form, and an ML-DSA-65 signed transaction is about 5 KB larger than an Ed25519 one.



## Request Futurenet funds

Create `src/fund.ts`:

```ts
import { toBase58 } from "@thruputchain/client";
import { account, wallet } from "./wallet.js";

const result = await wallet.requestAirdrop();
console.log("Account:", toBase58(account.address));
console.log("Funding transaction:", toBase58(result.transactionHash));
```

```bash
npx tsx src/fund.ts
```

The client must use a cluster that declares airdrop support. The hosted faucet selects the allocation. `requestAirdrop` calls the faucet once, then observes any returned transaction hash. It throws if the funding transaction does not execute successfully. `requestAirdropAttempt` performs one faucet call and leaves observation to the application.



## Use a local development account

For a node started by [the CLI](pages/cli/local-node.md), create a disposable signer and fund it from the local faucet. In the terminal that runs the script:

```bash
export THRUPUT_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

```ts
import { createThruputClient, createPubkeyAccount, createWalletClient, Ed25519Signer, fromHex0x, localnet } from "@thruputchain/client";

const seed = process.env.THRUPUT_SIGNING_PRIVATE_KEY;
if (!seed) throw new Error("Set THRUPUT_SIGNING_PRIVATE_KEY");
const client = await createThruputClient({ cluster: localnet() });
const signer = Ed25519Signer.fromSeed(fromHex0x(seed));
const account = createPubkeyAccount({ signer });
const wallet = createWalletClient({ client, account });
await wallet.requestAirdrop();
```

`localnet()` selects the local endpoint and checks its network identity. Keep the signer seed in this terminal environment for later calls. Use an existing seed from secret configuration when the account must persist. The SDK does not load CLI account files or runtime manifests.

---

## Send transactions

Source: <https://thruput.network/docs/typescript/transactions/>

Build typed calls, execute them through a wallet, and distinguish submission from successful execution.

A binding builds an application call. A wallet wraps that call into an authorized transaction. Use the wallet’s execution helper instead of submitting a contract method directly as the transaction root.



## Send from a script

Set up and fund the account from [Use a signer in scripts](pages/typescript/accounts.md). For this small-transfer example, choose a recipient that already has native tokens. Create `src/send.ts`:

```ts
import { addressFromBase58, gasAmount, parseUnits, toBase58 } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { wallet } from "./wallet.js";

const recipient = process.env.THRUPUT_RECIPIENT;
if (!recipient) throw new Error("Set THRUPUT_RECIPIENT to a funded base58 address");

const transfer = ERC20.v0_1.transfer.call({
  address: NATIVE_TOKEN_ADDRESS,
  gasLimit: gasAmount(500_000n),
  args: {
    receiver: addressFromBase58(recipient),
    amount: parseUnits("0.0001", 7),
  },
});
const { transactionHash, receipt, values } = await wallet.executeCallsAndWait({
  calls: [transfer],
  gasLimit: gasAmount(1_000_000n),
});
console.log("Committed:", toBase58(transactionHash), receipt.blockHeight.toString());
console.log("Return value:", values[0]); // transfer returns void
```

```bash
npx tsx src/send.ts
```

The helper waits for successful committed execution and decodes child returns in call order. A returned receipt and a decoded result are separate guarantees; see [Track transaction results](pages/typescript/transaction-status.md) for failures at either boundary.



## Send through a browser wallet

Use the adapter returned by [Connect a wallet](pages/tools/wallet-integration.md). The same typed call works, but the provider helper also requires an `onSigned` callback:

```ts
import type { ContractAddress } from "@thruputchain/client";
import { gasAmount, parseUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import type { ProviderWalletClient, ProviderExecutionOptions } from "@thruputchain/client/wallet";

export function sendNativeToken(
  wallet: ProviderWalletClient,
  receiver: ContractAddress,
  onSigned: ProviderExecutionOptions["onSigned"],
) {
  const transfer = ERC20.v0_1.transfer.call({
    address: NATIVE_TOKEN_ADDRESS,
    gasLimit: gasAmount(500_000n),
    args: { receiver, amount: parseUnits("0.0001", 7) },
  });
  return wallet.executeCallsAndWait({
    calls: [transfer],
    gasLimit: gasAmount(1_000_000n),
  }, { onSigned });
}
```

Call this from the user’s send action. Your `onSigned` implementation must finish saving the signed bytes, hash, account, and network before it resolves. A failed save prevents submission. The SDK does not provide that storage layer.



## Choose an execution helper

| Need                                                                 | Helper                                     |
| -------------------------------------------------------------------- | ------------------------------------------ |
| Submit and require successful execution                              | `executeAndWait({ invocation, gasLimit })` |
| Also decode typed child returns                                      | `executeCallsAndWait({ calls, gasLimit })` |
| Get a submitted hash and observe separately in a signer-based script | `execute({ invocation, gasLimit })`        |
| Inspect the transaction before signing                               | `prepareExecution(...)`                    |

Provider-backed helpers require the additional lifecycle options shown above. Their explicit prepare/sign/submit path is covered in [Wallet integration](pages/tools/wallet-integration.md#prepare-sign-save-submit-observe).



## Execute multiple calls

Pass an ordered list to `executeCallsAndWait` to execute calls atomically. If a call fails, the transaction does not commit earlier calls’ state changes. The returned `values` follow the same order.

For a provider wallet, await `getCapabilities()` and inspect the returned `atomicBatch` before offering a multi-call action. `null` means unsupported; `maxCalls` gives the advertised limit. The adapter checks support during preparation as well. One atomic wallet transaction is different from [HTTP request batching](pages/typescript/transport.md#http-batching).

The SDK requests capabilities only when the provider advertises `getCapabilities`. No advertisement or a `4200` response means unsupported batching. Permission errors, transport failures, malformed responses, and account/network mismatches must remain errors. Refresh capability state after a session change; see [batch capability requirements](pages/tools/wallet-provider.md#optional-atomic-batch-capabilities).

Keep a batch within the wallet’s advertised limit, up to 16 calls. For explicit preparation, `prepareBatchExecution({ invocations, gasLimit })` builds one unsigned transaction; use the same [sign, save, submit, and observe flow](pages/tools/wallet-integration.md#prepare-sign-save-submit-observe) as a single call.

If batching is unsupported, offer a single-call action only when it meets the user’s intended operation. Do not split an operation that requires atomicity. After a batch is rejected or its submission is uncertain, never fall back to individual transactions. Retain its signed evidence and [inspect the original hash](pages/typescript/transaction-status.md).

A batch that enqueues requests commits their acceptance, not their later execution. Track the resulting request IDs and outcomes as described in [Build an AMM](pages/guides/build-an-amm.md#understand-acceptance-and-execution).



## Set gas and funding

Each child call has a budget; the root needs enough gas for the wallet wrapper and its child calls. The numbers above are example transfer budgets, not universal defaults. `walletGasLimit(invocations, overhead)` sums invocation budgets and an overhead that you have measured for your workload. For typed calls, pass each call’s `invocation` field.

There are no conventional gas fees, but the declared root limit uses scheduling capacity backed by the sender’s unlocked native tokens. Storage deposits are separate. A new recipient’s first credit must cover its balance storage, so a small first transfer can fail. See [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md).

---

## Track transaction results

Source: <https://thruput.network/docs/typescript/transaction-status/>

Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.

Submission, commitment, execution, and decoding are separate steps. Keep the transaction hash and network so the application can continue observing the same operation after a timeout or wallet disconnect.



## Inspect a submitted transaction

Use the public client from [Connect to a network](pages/typescript/connect.md). Create `src/status.ts`:

```ts
import { hashFromBase58 } from "@thruputchain/client";
import { client } from "./client.js";

const text = process.env.THRUPUT_TX_HASH;
if (!text) throw new Error("Set THRUPUT_TX_HASH to the base58 transaction hash");
const transactionHash = hashFromBase58(text);
const status = await client.getTransactionStatus({ transactionHash });
if (!("status" in status)) throw new Error("Unsupported status from a newer server");

if (status.status === "committed") {
  const receipt = await client.getTransactionReceipt({ transactionHash });
  if (!receipt) throw new Error("The committed receipt is not available from this endpoint");
  const { execution } = receipt;
  console.log("Execution succeeded:", "result" in execution && execution.result === "return");
  console.log("Block:", receipt.blockHeight.toString());
} else {
  console.log("Status:", status.status);
}
```

This performs one status check. `client.waitForTransactionReceipt(hash)` polls for a receipt, but does not itself require successful execution. Check `receipt.execution.result` or use `waitForExecution(client, hash)` to require success.



## Interpret status

| Status               | Application meaning                                                                                                                                                                                                                                                                                                                                                                                                        |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pending`            | The scheduler has the transaction; keep waiting                                                                                                                                                                                                                                                                                                                                                                            |
| `committed`          | Fetch the receipt and check execution; `blockHeight` is always present                                                                                                                                                                                                                                                                                                                                                     |
| `recentFailure`      | Advisory failure of an attempt; the transaction can still commit                                                                                                                                                                                                                                                                                                                                                           |
| `retry`              | Scheduler processing failed; resubmitting the same signed transaction may succeed                                                                                                                                                                                                                                                                                                                                          |
| `dropped`            | Scheduler processing failed; inspect `error`. For insufficient native tokens (`SchedulerErrorInsufficientNativeTokens`), fund the sender before resubmitting the same signed transaction while valid. For errors that require changing the transaction, resolve the original outcome before signing a replacement. See [Resubmission and replacement](pages/typescript/transaction-status.md#resubmission-and-replacement) |
| `unknown` or `other` | No conclusive successful or failed execution result                                                                                                                                                                                                                                                                                                                                                                        |

`pending`, `retry`, and `dropped` can include an advisory `recentFailure` diagnostic. It can describe an earlier attempt. A value from a newer server arrives as `UnsupportedRpcValue`. See [`getTransactionStatus`](pages/reference/json-rpc-api.md#gettransactionstatus) for the wire fields.

A timeout or canceled observation does not cancel onchain execution. Query the original hash on the original network rather than automatically signing a replacement.



## Handle scheduler processing errors

`waitForTransactionReceipt()` keeps polling through `retry`, `dropped`, and `recentFailure` statuses, and it never resubmits. It reports each observed status through `onStatus`. When observation stops, it throws `TransactionReceiptObservationError`, or its subclass `TransactionReceiptTimeoutError`:

```ts
import { TransactionReceiptObservationError } from "@thruputchain/client";

try {
  const receipt = await client.waitForTransactionReceipt(transactionHash, {
    onStatus(status) {
      if ("error" in status) console.warn(status.status, status.error.source, status.error.code);
    },
  });
  console.log("Committed at block:", receipt.blockHeight.toString());
} catch (error) {
  if (error instanceof TransactionReceiptObservationError) {
    console.error({ lastStatus: error.lastStatus, knownCommitment: error.knownCommitment });
  }
  throw error;
}
```

`error` on a `retry` or `dropped` status is a `SchedulerTransactionError`: `source` is `auth`, `scheduler`, `executor`, or `other`, and `code` is a signed 32-bit number. Interpret the code using that source’s protocol error enum. To stop waiting early, pass a `signal` and abort it. Neither a timeout nor cancellation proves the transaction did not execute.



## Resubmission and replacement

Keep the original signed bytes, transaction hash, and signing network so recovery does not create a different transaction. Query the original hash on that network and preserve any known commitment. A missing receipt from one endpoint does not erase a known commitment.

An excluded proposal attempt does not consume the replay nonce. Scheduler requeue depends on the proposal outcome; it is not guaranteed. See [Exclusion, requeue, and resubmission](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission).

When the reported scheduler error permits another attempt and the transaction remains valid, resubmit the same signed bytes with bounded backoff. Receipt polling alone will not do this. `recentFailure` is advisory and does not authorize resubmission or replacement.

Stop resubmitting once the transaction expires. Expiration prevents future inclusion, but an earlier attempt may already have committed. A timeout, `unknown`, or expiration alone is not proof of nonexecution. Resolve the original outcome before deciding whether to sign a replacement. For a receipt-confirmed abort or fault, fix the cause before signing a new transaction; its replay nonce has already been consumed.



## Handle execution-helper errors

| Error                             | What happened                                                                                    | What to retain                                                                                                      |
| --------------------------------- | ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| `TransactionExecutionError`       | Committed execution failed                                                                       | `receipt`                                                                                                           |
| `TransactionObservationError`     | Submission or observation stopped; `phase` is `beforeSubmission`, `submission`, or `observation` | `transactionHash`, `submission` (signed bytes and network), `cause`, and any `submissionCause` or `knownCommitment` |
| `ExecutionDecodeError`            | Execution succeeded, but child return decoding failed                                            | Successful `receipt` and decoding cause                                                                             |
| `ExecutionReturnUnavailableError` | Execution succeeded, but the wallet did not provide child returns                                | Successful `receipt`                                                                                                |

For example, classify errors from a wallet execution helper:

```ts
import { TransactionExecutionError, TransactionObservationError, toBase58 } from "@thruputchain/client";

export function describeExecutionError(error: unknown): string {
  if (error instanceof TransactionObservationError) {
    return `Check transaction ${toBase58(error.transactionHash)} on its original network`;
  }
  if (error instanceof TransactionExecutionError) {
    const { execution } = error.receipt;
    return `Committed execution failed: ${"result" in execution ? execution.result : "unsupported result"}`;
  }
  return error instanceof Error ? error.message : "Transaction operation failed";
}
```

A decoding failure is not a reason to repeat a successful write. Keep the submitted call descriptors if you need to decode the receipt again later.



## Decode the correct method

`decodeReceipt` and `decodeReceiptOutcome` apply to a known **root method**. A wallet-root receipt is not a receipt for the application method it called. Use `executeCallsAndWait` or `decodeExecution(receipt, calls)` for ordered DefaultWallet child returns.

Do not decode a root abort with a child method’s exception schema merely because the transaction contained one child call. The wallet itself may have failed before the child executed.



## Restore application state

After a reload, use the saved hash and network to resume public observation. Decode a saved base58 hash with `hashFromBase58`. This does not require the wallet to remain connected. A provider’s `onSigned` callback provides the pre-submission record; see [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet).

For protocol-level outcomes, see [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md).

---

## Deploy a contract

Source: <https://thruput.network/docs/typescript/deployment/>

Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.

Use this task when an application or service deploys a supplied contract artifact. You do not need to write Rust, but you do need the `.rv32a` artifact and the bindings from its build. For ordinary developer deployment, use [the CLI](pages/cli/deploy-and-call.md).



## Prepare the deployment identity

For the generated counter, place its artifact and binding in your project. This Node.js example uses the funded account from [Use a signer in scripts](pages/typescript/accounts.md):

```ts
import { readFile } from "node:fs/promises";
import { gasAmount, parseUnits, prepareContractDeployment, toBase58 } from "@thruputchain/client";
import { Counter } from "./contracts/my-counter.js";
import { account, wallet } from "./wallet.js";

const artifact = await readFile("artifacts/my_counter.rv32a");
const deployment = prepareContractDeployment({
  deployer: account.address,
  contract: artifact,
});
console.log("Predicted address:", toBase58(deployment.address));
```

Preparation hashes the artifact and predicts its address without signing or submitting. Retain the deployment nonce if you need to reproduce that identity. It differs from the transaction nonce used for replay protection.



## Fund, deploy, and initialize

```ts
const result = await wallet.deployContractAndWait(deployment, {
  gasLimit: gasAmount(10_000_000n),
  amount: parseUnits("10", 7),
  initializer: Counter.v0_1.initialize.invocation(
    deployment.address,
    gasAmount(500_000n),
    { initialValue: 10n },
  ),
});
console.log("Deployed:", toBase58(result.address));
```

`amount` is explicit native-token funding in base units for the target contract. The example allocation and gas budgets are not universal costs. `0n` skips the funding transfer. The sender still needs scheduling capacity for the root transaction.

Funding, deployment, and the optional initializer form one atomic operation. The initializer targets the predicted address and sees the wallet as its caller. If it fails, the operation rolls back. The helper waits for success and verifies the returned deployment address.



## Deploy through a provider wallet

The provider adapter supports the same deployment plan and options, with an additional `{ onSigned }` lifecycle argument. Decode the authorized provider account’s base58 address with `addressFromBase58` and use it as `deployer`. See [Send transactions](pages/typescript/transactions.md#send-through-a-browser-wallet) for persistence before submission.

Inspect the original transaction hash if observation fails rather than generating a new deployment attempt. See [Track transaction results](pages/typescript/transaction-status.md).

---

## Client API reference

Source: <https://thruput.network/docs/tools/typescript-sdk/>

TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.

| Reference                                                      | Purpose                                |
| -------------------------------------------------------------- | -------------------------------------- |
| [Generated client API](https://client-ts.thruput.network/)     | Complete types, overloads, and exports |
| [Generated protocol API](https://protocol-ts.thruput.network/) | Protocol types and codecs              |
| [JSON-RPC API](pages/reference/json-rpc-api.md)                | Wire methods and responses             |
| [TypeScript overview](pages/typescript.md)                     | Application model and task guides      |



## Install

| Package                       | Use                                     | Instructions                                      |
| ----------------------------- | --------------------------------------- | ------------------------------------------------- |
| `@thruputchain/client`        | Application client and contract runtime | [Package setup](pages/typescript/setup.md)        |
| `@thruputchain/protocol`      | Protocol-only constants and wire types  | [Package setup](pages/typescript/setup.md)        |
| `@thruputchain/contract-spec` | Schema tooling                          | [Contract spec](pages/reference/contract-spec.md) |



## Connect to a Cluster

| API                                            | Behavior                                                                                                                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createThruputClient({ cluster, transport? })` | Async client creation; checks wire format 14, advertised methods, and network identity                                                                                          |
| `futurenet(options?)`                          | Futurenet; unpinned unless given `networkHash`; declares airdrop support                                                                                                        |
| `FUTURENET_RPC_URL`                            | Default Futurenet endpoint: `https://rpc.thruput.network`                                                                                                                       |
| `devnet(options?)` / `DEVNET_RPC_URL`          | Deprecated compatibility APIs; use `futurenet` / `FUTURENET_RPC_URL`; `devnet()` retains its legacy cluster name                                                                |
| `localnet(options?)`                           | Local endpoint and default local identity; override with the matching runtime identity                                                                                          |
| `mainnet(options)`                             | Requires an explicit endpoint                                                                                                                                                   |
| `defineCluster(descriptor)`                    | Custom name, endpoint, hash pin, and expected capabilities                                                                                                                      |
| `getChainTip()` / `getVersionInfo()`           | Tip `blockHeight` and `blockHash`; `wireFormat`, `implementation`, and optional release identity                                                                                |
| `client.network`                               | Validated network identity of a cluster client                                                                                                                                  |
| `client.discovery`                             | Connection-time snapshot of version, network, and optional server limits                                                                                                        |
| `RpcCompatibilityError`                        | Unsupported wire format, network mismatch, or unadvertised method                                                                                                               |
| `getChainConfig()`                             | Stated limits plus optional `execution` with `observedTip`, `configHash`, runtime-resolved limits, and exact `bigint` storage prices; absent execution context is not zero cost |
| Usage                                          | [Connect to a network](pages/typescript/connect.md)                                                                                                                             |



## Exact Amounts and Common Types

| API                                                | Result / rule                                                                              |
| -------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `parseUnits(text, decimals)`                       | Exact signed `bigint`; rejects malformed input and excess precision                        |
| `formatUnits(value, decimals)`                     | Decimal string                                                                             |
| `addressFromBase58(text)` / `hashFromBase58(text)` | Typed address or hash from base58                                                          |
| `toBase58(bytes)`                                  | Base58 encoding for addresses and hashes that users see, store, or compare with RPC values |
| `parseAddress(text)`                               | Typed Thruput address from base58 or a `Z` StrKey; rejects Stellar C addresses             |
| `addressToStrkey(bytes)`                           | Thruput Z address; does not identify a specific Thruput network                            |
| `fromHex0x(text)` / `toHex0x(bytes)`               | `0x` hex for signed transaction bytes and calldata                                         |
| `addressFromHex(text)` / `hashFromHex(text)`       | Explicit hex conversion; use base58 for RPC and provider identifiers                       |
| `gasAmount(bigint)`                                | Typed computation budget                                                                   |
| `ParseUnitsError`                                  | `code: "malformed" \| "precision"`; invalid decimals throw `RangeError`                    |
| Usage                                              | [Addresses and amounts](pages/typescript/values.md)                                        |



## Choose an Account Model

| API                                                                             | Inputs / behavior                                                                                                                                                     |
| ------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createPubkeyAccount({ signer, nonce? })`                                       | Ed25519 or ML-DSA-65 signer; address nonce defaults to `0n`                                                                                                           |
| `createSourceAddressAccount({ address, signers, allowedKeys, requiredWeight })` | Existing stored-auth account; does not write auth data                                                                                                                |
| `createWalletClient({ client, account, invocationAdapter?, onSigned? })`        | Separate signer-bound client; pubkey accounts default to DefaultWallet                                                                                                |
| `networkHash` wallet option                                                     | Required for a client without validated network identity; must match the endpoint’s network                                                                           |
| `createProviderWalletClient(...)`                                               | External wallet adapter; see [provider API](pages/tools/wallet-provider.md#sdk-adapter-behavior)                                                                      |
| Usage                                                                           | [Accounts and wallet clients](pages/typescript/wallet-clients.md), [script setup](pages/typescript/accounts.md), [browser wallets](pages/tools/wallet-integration.md) |



## Fund and Execute a Call

| API                                                                    | Result / behavior                                                                                                                                                                                      |
| ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `requestAirdrop(options)` (client) / `wallet.requestAirdrop(options?)` | One faucet call, then read-only observation; returns `AirdropSucceeded` with `transactionHash`, `blockHeight`, and `execution`; throws unless execution succeeds; account-defaulted on a signer wallet |
| `requestAirdropAttempt({ recipient, clientNonce })`                    | One faucet call; returns a `pending` or `succeeded` attempt without observation                                                                                                                        |
| `prepareExecution(request)`                                            | Unsigned wallet-root transaction                                                                                                                                                                       |
| `execute(request)`                                                     | Submitted hash; signer-based wallet                                                                                                                                                                    |
| `executeAndWait(request, options?)`                                    | Successful committed `receipt` and `transactionHash`                                                                                                                                                   |
| `executeCallsAndWait({ calls, gasLimit }, options?)`                   | Successful receipt plus ordered typed child values                                                                                                                                                     |
| `walletGasLimit(invocations, overhead)`                                | Sum invocation budgets, checking u64 bounds; pass `call.invocation` for typed calls; does not estimate usage                                                                                           |
| Usage                                                                  | [Send transactions](pages/typescript/transactions.md)                                                                                                                                                  |



## Typed Calls and Observation Recovery

| API / error                                                             | Meaning                                                                                                        |
| ----------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| `getTransactionStatus({ transactionHash })`                             | One status lookup; `committed` always includes `blockHeight`                                                   |
| `getTransactionReceipt({ transactionHash })`                            | One committed-receipt lookup with `blockHeight`, `execution`, `events`, and `gasUsed`; `null` when unavailable |
| `waitForTransactionReceipt(hash, options?)`                             | Poll until a receipt, including failed execution; reports each status through `onStatus`; never resubmits      |
| `waitForCommitment(hash, options?)`                                     | Poll until commitment is known, without requiring a receipt                                                    |
| `waitForExecution(client, hash, options?)`                              | Wait and require successful execution                                                                          |
| `TransactionReceiptObservationError` / `TransactionReceiptTimeoutError` | Observation stopped; retains `transactionHash`, `knownCommitment`, and `lastStatus`                            |
| `SchedulerTransactionError`                                             | `source`: `auth`, `scheduler`, `executor`, or `other`; `code`: signed 32-bit number                            |
| `UnsupportedRpcValue`                                                   | A status, result, or source from a newer server; retains `raw`                                                 |
| `TransactionExecutionError`                                             | Failed committed `receipt`                                                                                     |
| `TransactionObservationError`                                           | Known `transactionHash`, signed `submission`, `phase`, and causes                                              |
| `ExecutionDecodeError`                                                  | Successful receipt whose child return data failed decoding                                                     |
| `ExecutionReturnUnavailableError`                                       | Successful receipt without child returns                                                                       |
| Usage                                                                   | [Track transaction results](pages/typescript/transaction-status.md)                                            |



## Use a Local Account

| API                                                | Result / requirement                                                                               |
| -------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `localnet(options?)`                               | Local endpoint and pinned local network identity                                                   |
| `Ed25519Signer.fromSeed(seed)`                     | Ed25519 signer from a 32-byte seed in the application environment                                  |
| `MlDsa65Signer.fromSeed(seed, { deterministic? })` | ML-DSA-65 signer from a 32-byte FIPS 204 seed; signing is randomized unless `deterministic` is set |
| `createPubkeyAccount({ signer })`                  | Native pubkey account derived from the signer                                                      |
| `wallet.requestAirdrop()`                          | Fund the account through the local faucet                                                          |
| Usage                                              | [Local development accounts](pages/typescript/accounts.md#use-a-local-development-account)         |



## Deploy Through a Wallet

| API                                                                   | Result / requirement                                                                   |
| --------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `prepareContractDeployment({ deployer, contract, deploymentNonce? })` | Contract hash, nonce, and predicted address; no submission                             |
| `rv32Contract(artifact)`                                              | Protocol wrapper for nonempty artifact bytes                                           |
| `DeploymentOptions`                                                   | Required `gasLimit` and native-token `amount` in base units; optional `initializer`    |
| `prepareDeployment(deployment, options)`                              | Unsigned deployment transaction                                                        |
| `deployContract(deployment, options)`                                 | Submitted hash and predicted address; signer wallet                                    |
| `deployContractAndWait(deployment, options, controls?)`               | Successful deployment with verified address; provider form requires lifecycle controls |
| Usage                                                                 | [Deploy a contract](pages/typescript/deployment.md)                                    |



## Typed Views

| API                                                                                                                            | Result / behavior                                                                                            |
| ------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| `getContract({ binding, address, client })`                                                                                    | Bound method collection                                                                                      |
| `method.view({ client, address, args?, caller?, assumedAuth?, minStateBlockHeight?, signal? })`                                | Typed `value`, `stateBlockHeight`, `gasUsed`, and `events`                                                   |
| `method.viewOutcome(options)`                                                                                                  | `return`, `abort`, `fault`, or `unsupported`; same options as `view`                                         |
| `method.viewRequest({ address, args?, caller?, assumedAuth? })`                                                                | Prepare a typed read without I/O; arguments follow the method’s generated types                              |
| `client.readViews({ calls, minStateBlockHeight? }, options?)`                                                                  | Tuple-typed outcomes in input order at one shared `stateBlockHeight`; no splitting or separate-read fallback |
| `client.simulateInvocation(request, options?)` / `client.simulateInvocations({ invocations, minStateBlockHeight? }, options?)` | Raw single/grouped simulations; `minStateBlockHeight` goes on the single request or whole group              |
| `minStateBlockHeight`                                                                                                          | Optional nonnegative `bigint` freshness floor; no waiting, forced refresh, or automatic client retry         |
| `assumedAuth`                                                                                                                  | Protocol `AuthClaim`, such as `account.authClaim`; simulation does not verify signatures                     |
| `(await client.getServerLimits()).simulationBatch`                                                                             | Optional advertised batch limits; required for grouped reads                                                 |
| `NativeRpcErrorCode.StateHeightUnavailable` (`-32012`)                                                                         | RPC freshness error with `requestedStateBlockHeight` and `observedStateBlockHeight`; not a contract outcome  |
| `ContractViewError`                                                                                                            | Contract abort, fault, or unsupported result                                                                 |
| `ContractDecodeError`                                                                                                          | Malformed contract data                                                                                      |
| Usage                                                                                                                          | [Read contract data](pages/typescript/reads.md), [bindings](pages/tools/typescript-bindings.md)              |



## Cancellation and Read Errors

| API                                    | Rule                                                                       |
| -------------------------------------- | -------------------------------------------------------------------------- |
| `signal`                               | Request options for actions; inside view options for generated/bound views |
| `classifyReadError(error, { signal })` | `transient`, `permanent`, `cancelled`, or `unknown`; no automatic retry    |
| Cancellation                           | Cancels observation, not onchain execution                                 |
| Usage                                  | [Read cancellation](pages/typescript/reads.md#cancel-stale-reads)          |



## HTTP Batching

| Option                                              | Default / meaning                                         |
| --------------------------------------------------- | --------------------------------------------------------- |
| `HttpTransport(url, { timeoutMs, headers, batch })` | Configure the HTTP request layer                          |
| `batch`                                             | Off by default; `true` selects default batching settings  |
| `maxSize`                                           | 100 entries; allowed range 1–1,000                        |
| `waitMs`                                            | 0ms scheduling window                                     |
| Usage                                               | [Configure HTTP transport](pages/typescript/transport.md) |



## Event Pages

| API                                                                                   | Result / behavior                                                                             |
| ------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `getContractEvents({ event, addresses, topics?, start \| cursor, limit? }, options?)` | One typed page with event identity, `nextCursor`, and indexer bounds                          |
| `start`                                                                               | `{ order, anchor }`; anchor kind `atBeginning`, `atEnd`, or `atHeight` with `blockHeight`     |
| `nextCursor`                                                                          | Opaque string for the next page; `null` ends the walk                                         |
| `iterateEventPages({ filters, start, limit? }, options?)`                             | Raw pages on demand from an explicit `start`; returns `HistoryCompletion` after the last page |
| `iterateTransactionsByRootAddress({ address, start, limit? }, options?)`              | Transactions sent by a root address, as a checked walk                                        |
| `HistoryWalkError`                                                                    | Regressed coverage, lost retention, duplicate or out-of-order rows, or a repeated cursor      |
| `Event.filter({ addresses, topics? })` / `Event.decode(raw)`                          | Generated topic filter and payload decoder                                                    |
| `Event.allFromReceipt(receipt, { address })` / `singleFromReceipt(...)`               | Matching receipt events, filtered by emitter                                                  |
| Usage                                                                                 | [Read events](pages/typescript/events.md)                                                     |



## Receipt Decoding

| API                                             | Requirement                                                                                   |
| ----------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `decodeExecution(receipt, calls, adapter?)`     | Successful wallet receipt and retained ordered call descriptors                               |
| `method.decodeReceipt` / `decodeReceiptOutcome` | Descriptor must identify the root method                                                      |
| Usage                                           | [Decode the correct method](pages/typescript/transaction-status.md#decode-the-correct-method) |



## Low-Level Signing

| API                                                                                 | Role                                                                              |
| ----------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| `prepareTransaction`                                                                | Build a root transaction and its authorization claim                              |
| `signTransaction(transaction, signers, networkHash)`                                | Sign the network-bound preimage                                                   |
| `client.sendTransaction({ signedTransaction: serializeSignedTransaction(signed) })` | Submit signed bytes once; returns `transactionHash` and `admission`               |
| `sendTransaction(client, signed)` from `@thruputchain/client/actions`               | Serialize, submit once, and require `accepted` admission; returns the hash        |
| Transaction hash                                                                    | SHA-256 of unsigned transaction XDR, separate from the signing preimage           |
| Usage                                                                               | Prefer [wallet execution](pages/typescript/transactions.md) for application calls |



## Public Entry Points

| Import                             | Use for                                                             |
| ---------------------------------- | ------------------------------------------------------------------- |
| `@thruputchain/client`             | Clients, clusters, accounts, actions, amounts, common primitives    |
| `@thruputchain/client/contracts`   | Standard contract and event descriptors                             |
| `@thruputchain/client/contract`    | Descriptor runtime, codecs, fixed-length helpers                    |
| `@thruputchain/client/transport`   | HTTP/mock transports and errors                                     |
| `@thruputchain/client/actions`     | Standalone actions                                                  |
| `@thruputchain/client/wallet`      | Execution and provider adapters                                     |
| `@thruputchain/client/provider`    | Provider wire types, validation, discovery                          |
| `@thruputchain/client/transaction` | Construction, signing, serialization                                |
| `@thruputchain/client/signers`     | Signer interface, `Ed25519Signer`, `MlDsa65Signer`, `verifyMlDsa65` |
| `@thruputchain/client/signed-op`   | Network-bound offchain signed operations                            |



## Maintained Examples

| Source                                                                               | Purpose                                                                       |
| ------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| [Client examples](https://github.com/thruputchain/thruput-sdk-ts/tree/main/examples) | Runnable SDK examples; use dependencies matching the selected source revision |
| [Guides](pages/guides.md)                                                            | Complete contract and application walkthroughs                                |

---

## Wallet provider reference

Source: <https://thruput.network/docs/tools/wallet-provider/>

Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.

| Audience                       | Entry point                                                                                                  |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| Application developers         | [Connect a wallet](pages/tools/wallet-integration.md), [Send transactions](pages/typescript/transactions.md) |
| Wallet and bridge implementers | Provider contract `2.0.0`; requirements below apply at the wallet boundary                                   |
| Complete signatures            | [Generated client API](https://client-ts.thruput.network/)                                                   |
| Imports                        | Wire types and validators: `/provider`; application adapter: `/wallet`                                       |



## Interface and Methods

| Type / member                      | Shape                                                                            |
| ---------------------------------- | -------------------------------------------------------------------------------- |
| `WalletAccount`                    | `{ address: string; publicKey: string; nonce: string }`                          |
| `WalletSession`                    | `{ networkHash: string; accounts: readonly WalletAccount[] }`                    |
| `WalletProvider.info`              | `{ id: string; name: string; version: "2.0.0" }`                                 |
| `WalletProvider.supportedMethods?` | Optional readonly method-name list                                               |
| `request(request)`                 | `Promise<unknown>`; validate each result                                         |
| `on("change", listener)`           | Subscribe to a full session snapshot; returns an idempotent unsubscribe function |

| Request method               | Parameters                                    | Result / requirement                                                                                 |
| ---------------------------- | --------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `connect`                    | None                                          | Prompt for origin-scoped access; successful session has at least one account                         |
| `getSession`                 | None                                          | Non-interactive session snapshot; never grants access                                                |
| `disconnect`                 | None                                          | `null`; idempotently revokes origin permission and pending approvals                                 |
| `getCapabilities` (optional) | `{ account, networkHash }`                    | `WalletCapabilities`; requires an authorized account on that network; never prompts or grants access |
| `signTransaction`            | `{ account, networkHash, transaction }`       | `{ signedTransaction, hash }`; approval and signing only                                             |
| `submitTransaction`          | `{ account, networkHash, signedTransaction }` | `{ hash }`; broadcast acknowledgement, not an execution receipt                                      |

| Rule           | Requirement                                                                                             |
| -------------- | ------------------------------------------------------------------------------------------------------- |
| Request shape  | Exactly the method’s defined fields, including nested `params`                                          |
| Selection      | Explicit account and network; no implicit network switch                                                |
| Batch contract | [Optional Atomic Batch Capabilities](pages/tools/wallet-provider.md#optional-atomic-batch-capabilities) |



## Canonical Data and Limits

| Value                                               | Required format / bound                                                                                        |
| --------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Address, public key, network hash, transaction hash | 32 bytes as unprefixed, case-sensitive base58                                                                  |
| Account nonce                                       | Canonical decimal u64, at most `18446744073709551615`; address derivation, not transaction replay nonce        |
| Session accounts                                    | At most 32 unique addresses                                                                                    |
| Provider ID                                         | 1–64 ASCII letters, digits, dots, underscores, or hyphens                                                      |
| Provider name                                       | 1–80 characters; no controls or surrounding whitespace; render as text                                         |
| Provider version                                    | Exactly `"2.0.0"`; version 1 providers are rejected                                                            |
| Provider `supportedMethods`                         | Optional array of at most 32 strings; unknown names are opaque, including names with punctuation or namespaces |
| Error message                                       | At most 1,024 characters                                                                                       |
| Unsigned transaction                                | Canonical classic XDR, at most 1,048,460 decoded bytes                                                         |
| Signed transaction                                  | Canonical classic XDR, at most 1,048,576 decoded bytes                                                         |
| Transaction hex                                     | Lowercase, even-length, `0x`-prefixed; at most 2,096,922 unsigned or 2,097,154 signed characters               |
| Account derivation                                  | Protocol pubkey account matching its public key and nonce; Ed25519 key must be non-small-order and prime-order |

| Validation boundary | Requirement                                                                                                                                  |
| ------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| Canonical values    | Reject malformed values rather than normalizing                                                                                              |
| XDR                 | Consume all input; re-encoding must reproduce the supplied bytes                                                                             |
| Before approval     | Enforce unsigned size limit; 116 bytes are reserved for the Ed25519 envelope: a 76-byte decorated signature and a 40-byte `pubkey_claim_key` |
| Bridges             | Bound raw messages before parsing and bound pending requests; allow for JSON envelope size                                                   |
| Data parsers        | Return snapshots                                                                                                                             |
| Provider parser     | Preserves the live object’s identity and method receivers; does not establish trust                                                          |
| Version 1 state     | Reset stored sessions; do not convert hex values to base58                                                                                   |



## Permissions and Session Events

| Event / state                                              | Requirement                                                                      |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Unauthorized or disconnected origin                        | Empty accounts, current network hash retained                                    |
| Accounts, permission, account metadata, or network changes | Emit `change` with a full session snapshot                                       |
| Subscription                                               | Does not emit an initial snapshot; call `getSession`                             |
| Connect/disconnect ordering                                | Page-facing changes arrive before the request resolves, including across bridges |
| Pending operation                                          | Recheck authorization before signing or broadcasting                             |
| Session change                                             | Clear approvals; old approval cannot survive a changed session                   |



## Optional Atomic Batch Capabilities

| Item                           | Requirement                                                                                                                                                       |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Advertisement                  | Providers implementing `getCapabilities` must include that exact name in top-level `supportedMethods`, separate from `info` and `WalletSession`                   |
| Unknown advertised method      | Ignore the name; it does not invalidate the provider                                                                                                              |
| Unadvertised capability method | Clients must not probe it; the SDK reports unsupported batching without making that request                                                                       |
| Response shape                 | Exactly `{ account, networkHash, atomicBatch: { maxCalls: number } \| null }`                                                                                     |
| Scope                          | Response account and network must match the request’s canonical account and network; provider verifies current origin/account authorization and network           |
| Side effects                   | Capability queries must not prompt, grant access, sign, or broadcast                                                                                              |
| Unsupported batching           | `atomicBatch: null`, no advertisement, or an advertised capability request returning `4200`                                                                       |
| Other failures                 | Permission and transport errors propagate; malformed responses or mismatched scope are errors, not unsupported capability                                         |
| Call limit                     | `maxCalls` is an integer from 1 to 16; a batch must contain at least one call and stay within the advertised limit                                                |
| Atomicity                      | Ordered, all-or-nothing calls inside one `DefaultWallet.execute` transaction, not multiple independent transactions; an inner abort or fault rolls back the batch |
| Queued work                    | A successful batch that enqueues work does not establish the outcome of later processing                                                                          |
| Session changes                | Discard capability state when the account/network session changes; check support again before batch preparation                                                   |
| Approval                       | Use the existing `signTransaction` and `submitTransaction` requests; one approval covers only that exact batch transaction                                        |
| Persistence and recovery       | Save signed bytes, hash, account, and network before submission; inspect the original hash after uncertainty                                                      |
| Fallback                       | Never split a rejected or uncertain batch into individual transactions                                                                                            |
| Application usage              | [Execute multiple calls](pages/typescript/transactions.md#execute-multiple-calls)                                                                                 |



## Signing and Transaction Identity

| Item          | Requirement                                                                                                                                               |
| ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Root identity | Transaction root address and pubkey claim (public-key hash and derivation nonce) match the selected account                                               |
| Claim key     | `pubkey_claim_key` is present and equals the account’s Ed25519 public key                                                                                 |
| Signed bytes  | Preserve unsigned transaction byte-for-byte                                                                                                               |
| Signature     | Exactly one Ed25519 signature with public-key ID zero; provider accounts are Ed25519 only, so ML-DSA-65 pubkey accounts cannot connect through a provider |
| Preimage      | `cxs(DomainSeparator("Transaction")) \|\| networkHash \|\| txs(transaction)`                                                                              |
| Verification  | Strict Ed25519 with ZIP-215 disabled; public key and signature point R are non-small-order and prime-order                                                |
| Signing       | Sign the preimage directly, without an extra pre-hash                                                                                                     |
| Result hash   | Base58 SHA-256 of unsigned transaction XDR; excludes signatures and network                                                                               |
| Web Crypto    | Required by SDK signature verification; HTTPS or localhost in browsers                                                                                    |



## Approval and Submission

| Boundary                    | Requirement                                                                                                      |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Trusted caller              | Derive origin in trusted wallet/bridge code, not page-supplied parameters                                        |
| Retained approval           | Bind exact signed bytes to origin, account, and network                                                          |
| Submission                  | Reject bytes outside the retained approval; return the approved canonical hash                                   |
| Approval lifecycle          | Clear on disconnect/session change; bound retained approvals; fail closed after eviction, restart, or lost state |
| Application persistence     | Save signed result, hash, account, and original network before broadcast                                         |
| Uncertain submission        | Observe the saved hash on the original network; do not automatically sign a replacement                          |
| Identical-byte resubmission | Requires an explicit recovery policy and still-valid provider approval                                           |
| Usage                       | [Transaction observation](pages/typescript/transaction-status.md)                                                |



## Errors

| Code     | Meaning                                                         |
| -------- | --------------------------------------------------------------- |
| `4001`   | User rejected the request                                       |
| `4100`   | Unauthorized origin/account, stale session, or missing approval |
| `4200`   | Unsupported method                                              |
| `4900`   | Provider disconnected or transport unavailable                  |
| `4901`   | Requested network does not match                                |
| `-32602` | Invalid parameters, encoding, or limits                         |
| `-32603` | Internal error or invalid provider result                       |
| `-32002` | Another operation is pending                                    |

| Rule                    | Requirement                                                                         |
| ----------------------- | ----------------------------------------------------------------------------------- |
| Across contexts         | Preserve numeric code and message; use `parseWalletProviderError`, not `instanceof` |
| Unknown method          | Return `4200`                                                                       |
| Malformed known request | Return `-32602`                                                                     |



## Multiple-Provider Discovery

| API / rule                                           | Behavior                                                                                  |
| ---------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `registerWalletProvider(provider, target = window)`  | Validate, announce immediately, and respond to provider requests                          |
| `discoverWalletProviders(listener, target = window)` | Subscribe before requesting announcements; validate and deduplicate IDs                   |
| Request event                                        | `groundhog:requestProvider` (`REQUEST_PROVIDER_EVENT`)                                    |
| Announcement event                                   | `groundhog:announceProvider` (`ANNOUNCE_PROVIDER_EVENT`); `detail` is the provider itself |
| Discovery limits                                     | At most 32 IDs; first valid announcement for an ID wins                                   |
| Cleanup                                              | Idempotent; removes listeners, but does not disconnect sessions                           |
| Registration removal                                 | Does not retract an already discovered provider                                           |
| Outside browsers                                     | Imports are safe; supply an `EventTarget` to discovery helpers                            |
| Trust                                                | Shape validation is not wallet identity or origin authorization                           |



## Validation Helpers

| Helper                                                                  | Validates / returns                                                                                                       |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `parseWalletAccount`, `parseWalletSession`, `parseWalletProviderInfo`   | Canonical data and frozen snapshots; separately require nonempty accounts after connect                                   |
| `parseWalletProvider`                                                   | Metadata and callable methods on the live object                                                                          |
| `parseWalletIdentifier`, `parseWalletNetworkHash`                       | 32-byte base58 address, public key, or hash; network hash uses the same format                                            |
| `parseWalletCapabilities`                                               | Exact scoped response shape and DefaultWallet call-count bounds; authorization and expected-scope comparison are separate |
| `parseProviderRequest`                                                  | Exact request union and bounded XDR                                                                                       |
| `parseTransactionHex`, `parseSignedTransactionHex`                      | Canonical decoded objects, without signature verification                                                                 |
| `parseSignTransactionResult`, `parseSubmitTransactionResult`            | Result shape; not signature, approval, or broadcast verification                                                          |
| `assertWalletTransaction(tx, account)`                                  | Root address and pubkey claim (public-key hash and nonce); mismatch is `4100`                                             |
| `verifySignTransactionResult(value, transaction, account, networkHash)` | Exact bytes, account claim, `pubkey_claim_key`, strict signature, and hash; invalid result is `-32603`                    |
| `parseWalletProviderError`                                              | Recognized code and bounded message                                                                                       |

| Constant                         | Value       |
| -------------------------------- | ----------- |
| `MAX_TRANSACTION_BYTES`          | `1_048_576` |
| `MAX_UNSIGNED_TRANSACTION_BYTES` | `1_048_460` |
| `MAX_WALLET_ACCOUNTS`            | `32`        |
| `MAX_DISCOVERED_PROVIDERS`       | `32`        |
| `MAX_DEFAULT_WALLET_CALLS`       | `16`        |



## SDK Adapter Behavior

| API                                                                                   | Result / behavior                                                                                                                             |
| ------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `createProviderWalletClient({ client, provider, account, networkHash })`              | Synchronous separate binding for an authorized wire account; does not connect or mutate client                                                |
| `getCapabilities()`                                                                   | Fresh account/network capabilities when advertised; absence or `4200` means unsupported batching                                              |
| `prepareExecution(request)`                                                           | Unsigned DefaultWallet transaction with nonce, expiry, and size handling                                                                      |
| `prepareBatchExecution(request)`                                                      | Unsigned DefaultWallet transaction containing ordered `invocations`; snapshots inputs before async work and validates fresh capability limits |
| `signTransaction(transaction)`                                                        | Verified approval; never broadcasts                                                                                                           |
| `submitTransaction(signed)`                                                           | Consumes latest approval once, including on failure; verifies response hash                                                                   |
| `executeAndWait(request, controls)`                                                   | Prepare, sign, save through `onSigned`, submit, and observe successful execution                                                              |
| `executeCallsAndWait(request, controls)`                                              | Atomic typed calls and ordered decoded results                                                                                                |
| `prepareDeployment(plan, options)` / `deployContractAndWait(plan, options, controls)` | Explicit funding and optional atomic initialization                                                                                           |
| `dispose()`                                                                           | Idempotently unsubscribe and permanently invalidate; does not revoke permission                                                               |

| Lifecycle rule     | Behavior                                                                                                              |
| ------------------ | --------------------------------------------------------------------------------------------------------------------- |
| Inputs             | Snapshot configuration and inputs before async work; validate account derivation and client network identity          |
| Session            | Check before preparation/signing/submission; every change or failed/mismatched session read invalidates the adapter   |
| Concurrency        | One in-flight operation; overlapping work fails with `-32002`                                                         |
| New approval       | Clears the previous approval after local transaction validation; refusal does not restore it                          |
| Execution controls | Required `onSigned` persistence callback; optional `wait` settings and cancellation signal                            |
| Cleanup            | No automatic reconnect/retry, UI deadline, or provider-request cancellation; late results cannot reactivate or submit |
| Usage              | [Connect a wallet](pages/tools/wallet-integration.md), [Send transactions](pages/typescript/transactions.md)          |



## Design References

| Reference                                                                                                                                                                       | Relationship                                                                                                                                                  |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [EIP-1193](https://eips.ethereum.org/EIPS/eip-1193), [EIP-6963](https://eips.ethereum.org/EIPS/eip-6963), [Wallet Standard](https://github.com/wallet-standard/wallet-standard) | Design influences, not compatibility claims                                                                                                                   |
| Scope                                                                                                                                                                           | No arbitrary-message signing, implicit network addition, WalletConnect, hardware-wallet protocol, or source-address account support in this provider contract |

---

## React

Source: <https://thruput.network/docs/react/>

Use Project Thruput's React provider and hooks for wallets and contract data.

Build wallet controls and contract-data interfaces with `@thruputchain/react`. The library supplies state and hooks; you supply the components, styling, and application workflow.



## How the layers fit

- The **TypeScript client** connects to a network and executes typed contract operations.
- **WalletProvider** shares that client and manages wallet discovery, connection, and account selection.
- **TanStack Query** manages read state, caching, and mutations through your application’s `QueryClient`.
- **Contract bindings** describe each contract’s methods, results, errors, and events.

The library manages one configured application network and one selected wallet connection. Public reads work without wallet permission. A connected wallet supplies the signing client for writes.



## Start with a read

The [React quickstart](pages/get-started/react.md) displays Futurenet’s native-token supply using the supplied ERC-20 binding and contract address. You do not need Rust, the CLI, or your own deployment.

For an existing app, follow [Setup](pages/react/setup.md) and [Providers and clients](pages/react/providers.md). Then use [Read contract data](pages/react/reads.md) or [Read balances](pages/react/balances.md). [Cache and refresh data](pages/react/queries.md) explains the query behavior shared by those hooks.



## Add wallet actions

[Connect a wallet](pages/react/wallets.md) covers discovery, account selection, and connection states. [Send transactions](pages/react/transactions.md) and [Track transaction results](pages/react/transaction-status.md) cover the approval-to-receipt flow.

Use the [TypeScript account model](pages/typescript/wallet-clients.md) for shared signing concepts and the [React API reference](pages/react/reference.md) for exact hook inputs and results. Complete application walkthroughs belong in [Guides](pages/guides.md).

---

## Setup

Source: <https://thruput.network/docs/react/setup/>

Install the React integration and connect its wallet and query providers to Futurenet.

Use the current Node.js LTS release. For a new app, create a React TypeScript project:

```bash
npm create vite@latest my-thruput-ui -- --template react-ts
cd my-thruput-ui
npm install
```

Complete the shared [registry access setup](pages/typescript/setup.md#give-npm-package-access), then install the integration and its client together:

```bash
npm install @thruputchain/react @thruputchain/client @thruputchain/protocol @tanstack/react-query
```

The package manager resolves the React library’s compatible client dependency. Keep the lockfile. In an existing application, satisfy the library’s peer dependencies rather than forcing an incompatible client version. The integration uses React 19 and TanStack Query 5.



## Connect the application

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, futurenet } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Futurenet…</p>);

async function start() {
  const client = await createThruputClient({ cluster: futurenet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

void start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Futurenet"}</p>,
  );
});
```

The public client and query cache are created once, before rendering the app. `WalletProvider` does not request wallet permission automatically.



## Check the setup

Start the development server:

```bash
npm run dev
```

In another terminal, check the production build:

```bash
npm run build
```

---

## Providers and clients

Source: <https://thruput.network/docs/react/providers/>

Understand the React contexts, public and signing clients, and their lifetimes.

The [setup page](pages/react/setup.md) mounts two contexts. They have different responsibilities:

| Provider              | Responsibility                                                                                  |
| --------------------- | ----------------------------------------------------------------------------------------------- |
| `WalletProvider`      | Public client, wallet discovery, authorized session, selected account, signing-client lifecycle |
| `QueryClientProvider` | Read cache, query state, refresh policies, and mutations                                        |

`WalletProvider`, `useClient`, `useWallet`, and `useWalletClient` work without TanStack Query context. Balance, contract-view, receipt, and execution hooks require both providers.

The React `WalletProvider` is a context component. A discovered wallet provider is the external wallet object that handles permission and signing requests. See [Accounts and wallet clients](pages/typescript/wallet-clients.md) for that shared model.



## Use the public client

`useClient()` returns the initialized client supplied to `WalletProvider`. It remains available while disconnected and stays on the application’s network when the wallet changes networks.

Use it with SDK actions or [custom queries](pages/react/events.md). Contract reads do not require a connected wallet.

Choose a cluster or pin its identity through the TypeScript [network configuration](pages/typescript/connect.md), then supply that cluster-validated client to `WalletProvider`.

Configure HTTP timeouts and batching through the [client transport](pages/typescript/transport.md). Configure caching and refresh behavior through [TanStack Query](pages/react/queries.md).



## Use the signing client

`useWalletClient()` returns the current provider-backed signing client, or `null` when unavailable. `useWallet()` exposes the connection state and selection actions.

Enable writes only when `wallet.status === "connected"`. An account address can still be present in a wrong-network session, so an address alone is not evidence that signing is available.

The provider owns the signing client’s lifecycle. Session changes invalidate the old binding immediately and create a fresh binding after event dispatch when the session is valid. Use the current hook result for new operations.



## Keep identities stable

Create the public client and `QueryClient` once for the application’s lifetime. Replacing the public client starts a disconnected wallet lifecycle, even when the new client points to the same network. Reads through different client instances have separate cache identities.

Unmounting `WalletProvider` disposes its signing binding without revoking remote permission. The user’s [Disconnect action](pages/react/wallets.md) requests permission revocation. Calling the current signing client’s `dispose()` also clears the local React connection.



## Use a client-rendered boundary

In a server-rendered framework, initialize the client and mount these providers in the application’s client-rendered boundary. Server rendering starts disconnected; browser discovery runs after mounting.

Project Thruput query keys contain in-memory client identities. Use them within one query-cache lifetime, not as persisted keys or server-to-browser hydration identifiers. See [Cache and refresh data](pages/react/queries.md) for cache scope and reusable query factories.

---

## Read contract data

Source: <https://thruput.network/docs/react/reads/>

Display a typed contract view with loading, error, data, and refresh states.

`useContractView` reads a generated method descriptor and infers its arguments and result. Mount the [application providers](pages/react/setup.md) first.



## Display native-token supply

Use this as `src/App.tsx`. The binding and deployed address are supplied by the SDK packages:

```tsx
import { formatUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    address: NATIVE_TOKEN_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>Native-token supply</h1>
      {supply.isLoading ? <p>Reading the contract…</p> : null}
      {supply.error ? <p role="alert">{supply.error.message}</p> : null}
      {supply.data ? (
        <>
          <p>{formatUnits(supply.data.value, 7)} native tokens</p>
          <p>Read at block {supply.data.stateBlockHeight.toString()}</p>
        </>
      ) : null}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

No wallet, signer, or new deployment is needed. The result retains `value`, `stateBlockHeight`, `gasUsed`, and simulated `events`.



## Pass method arguments

For a method with arguments, pass its generated argument object:

```tsx
import type { ContractAddress } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export function RawBalance({ owner }: { owner: ContractAddress }) {
  const balance = useContractView({
    method: ERC20.v0_1.getBalanceOf,
    address: NATIVE_TOKEN_ADDRESS,
    args: { addr: owner },
  });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Reading balance…</p>;
  return <p>{balance.data.value.toString()} base units</p>;
}
```

Pass `caller` when a view needs simulated caller context. It does not authorize a transaction. Custom contracts use their own [generated bindings](pages/tools/typescript-bindings.md).



## Control when a read runs

`enabled: false` disables automatic reads and retains cached data. `staleTime` controls freshness. Arguments must still be valid: the hook encodes them while constructing the query, even when disabled. Mount a read component only after required inputs are ready.

Keep generated descriptors stable. Cache identity includes the client, method decoder, contract address, encoded arguments, and caller. Equivalent argument values share a query; changing an input selects a different query.



## Handle refresh and cancellation

Use `isLoading` for the first active fetch and `isFetching` for any active fetch, including refresh. A disabled query can be pending without loading. Display read errors separately from cached data when a refresh fails.

Query cancellation aborts contract-view requests and ignores late results from custom transports. Independent views can use different snapshots. After a write, check that a view’s `stateBlockHeight` has reached the receipt’s `blockHeight` before treating its data as post-transaction state.

---

## Read balances

Source: <https://thruput.network/docs/react/balances/>

Read native-token and contract-token balances for a connected account or an explicit address.

Use `useBalance` for the native token and `useTokenBalance` for a standard ERC-20 contract. Both return query state, a `queryKey`, and data containing `rawBalance` and `stateBlockHeight`.



## Follow the connected account

```tsx
import { formatUnits } from "@thruputchain/client";
import { useBalance } from "@thruputchain/react";

export function NativeBalance() {
  const balance = useBalance();
  if (balance.isLoading) return <p>Loading balance…</p>;
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Connect a wallet on this network to see its balance.</p>;
  return <p>{formatUnits(balance.data.rawBalance, 7)} native tokens</p>;
}
```

With no address, the hook follows the selected account only while the wallet is connected to the application’s network. Account changes select a different query rather than displaying the previous account’s balance.



## Read an explicit address

Pass an address to read without wallet permission:

```tsx
import { formatUnits } from "@thruputchain/client";
import { useTokenBalance, type BalanceAddress } from "@thruputchain/react";

export function TokenBalance({ token, owner, decimals }: {
  token: BalanceAddress;
  owner: BalanceAddress;
  decimals: number;
}) {
  const balance = useTokenBalance({ token, address: owner });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Loading token balance…</p>;
  return (
    <p>{formatUnits(balance.data.rawBalance, decimals)} at block {balance.data.stateBlockHeight.toString()}</p>
  );
}
```

Addresses accept base58 strings or SDK-branded bytes. Equivalent inputs share a key. The hook does not fetch token metadata or choose decimals; supply those from the application or a metadata read. The native token has seven decimals.



## Handle missing inputs

| Input                          | Behavior                                                               |
| ------------------------------ | ---------------------------------------------------------------------- |
| Omitted or undefined `address` | Resolve the connected account on the app’s network                     |
| Explicit address               | Read even while disconnected or while the wallet is on another network |
| `address: null`                | Disable account resolution and fetching                                |
| Missing or null `token`        | Disable token fetching                                                 |

Missing-input queries are idle with `isLoading: false`. Invalid addresses surface through query error state.



## Set refresh behavior

Pass options through `query`, for example `{ staleTime: 10_000, refetchInterval: 15_000 }`. The balance hooks also support retry, garbage-collection, focus/reconnect, and `select` options. Defaults come from your QueryClient and TanStack Query.

Abandoned balance results are discarded, but their underlying RPC may still finish. Use [Cache and refresh data](pages/react/queries.md) for polling, reusable query options, and invalidation after writes.

---

## Cache and refresh data

Source: <https://thruput.network/docs/react/queries/>

Share query results, reuse query factories, and refresh the original data after a transaction.

Project Thruput query hooks use your application’s TanStack Query cache. Keep the public client and QueryClient stable so components reading the same inputs can share data and in-flight requests.



## Understand cache scope

Keys include network and public-client instance identity. Balance keys also include owner and token where applicable. Contract-view keys include the method decoder, target, encoded arguments, and caller.

Different client instances do not share cached reads, even on the same network. Use the `queryKey` returned by a hook or factory rather than constructing a library-owned key yourself.

`staleTime` controls when data becomes stale. Polling and post-transaction invalidation are explicit application choices. Independent queries do not guarantee a common read height.



## Reuse query options

Factories work outside components when given an initialized client and explicit inputs:

```ts
import type { ConnectedThruputClient } from "@thruputchain/client";
import { tokenBalanceQueryOptions, type BalanceAddress } from "@thruputchain/react";
import type { QueryClient } from "@tanstack/react-query";

export function prefetchBalance(
  queries: QueryClient,
  client: ConnectedThruputClient,
  owner: BalanceAddress,
  token: BalanceAddress,
) {
  return queries.prefetchQuery(tokenBalanceQueryOptions({
    client,
    address: owner,
    token,
    query: { staleTime: 10_000 },
  }));
}
```

The same client and inputs produce the key used by `useTokenBalance`. Factories also exist for native balances, contract views, and receipts.

Balance factories do not resolve the connected wallet. Missing inputs produce a skipped query for hook use; call imperative `fetchQuery` or `prefetchQuery` only when inputs are present. `enabled` controls observers, not imperative fetching. `select` transforms observer data, not the cache’s raw data.



## Read a dynamic list

Use one balance component per token, or compose factory options with `useQueries`:

```tsx
import { toBase58 } from "@thruputchain/client";
import { useQueries } from "@tanstack/react-query";
import { tokenBalanceQueryOptions, useClient, useWallet, type BalanceAddress } from "@thruputchain/react";

export function TokenBalances({ tokens }: { tokens: BalanceAddress[] }) {
  const client = useClient();
  const wallet = useWallet();
  const tokenKeys = tokens.map(token => typeof token === "string" ? token : toBase58(token));
  const balances = useQueries({
    queries: tokenKeys.map(token => tokenBalanceQueryOptions({
      client,
      address: wallet.status === "connected" ? wallet.address : null,
      token,
      query: { staleTime: 10_000 },
    })),
  });

  return (
    <ul>
      {balances.map((balance, index) => (
        <li key={tokenKeys[index]}>
          {balance.isLoading ? "Loading…" : balance.error ? balance.error.message : balance.data?.rawBalance.toString() ?? "No balance loaded"}
        </li>
      ))}
    </ul>
  );
}
```

Pass a list of unique tokens. Base58 is case-sensitive, so do not change the case of address strings. These are independent queries, not one atomic read or a concurrency-limited batch. Use a grouped application query and check heights when several values must describe the same snapshot.



## Refresh after a write

After observing a committed transaction, invalidate the key for the account and token that operation affected:

```ts
import type { QueryClient } from "@tanstack/react-query";
import type { BalanceQueryKey } from "@thruputchain/react";

export function refreshBalance(queries: QueryClient, originalKey: BalanceQueryKey) {
  return queries.invalidateQueries({ queryKey: originalKey, exact: true });
}
```

Capture the original key when starting the operation. An account change while waiting should not redirect the refresh to the newly selected account. Invalidating a query requests another read; check its height when the application needs post-transaction state.

For custom queries, append an application namespace and every read input to `getClientQueryKey(client)`. Canonicalize addresses and hashes with `toBase58`, other byte arrays with `toHex0x`, and bigints as decimal strings. [Read events](pages/react/events.md) shows a custom query with fixed inputs.



## Keep persistence separate

Query keys contain in-memory identities and are not portable across server/browser processes or persisted cache sessions. Store application records, such as pending transaction hashes and their networks, separately from the query cache. See [Track transaction results](pages/react/transaction-status.md).

---

## Read events

Source: <https://thruput.network/docs/react/events/>

Use the public client and TanStack Query to display typed contract events in React.

Compose the TypeScript client’s event actions with TanStack Query. Generated bindings provide filtering and decoding; React components provide loading, empty, error, and refresh states.



## Display recent native-token transfers

```tsx
import { toBase58 } from "@thruputchain/client";
import { thruput_erc20_if } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { getClientQueryKey, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";

const { TransferEvent } = thruput_erc20_if.v0_1.events;

export function RecentTransfers() {
  const client = useClient();
  const transfers = useQuery({
    queryKey: [...getClientQueryKey(client), "app", "recent-native-token-transfers"],
    queryFn: ({ signal }) => client.getContractEvents({
      event: TransferEvent,
      addresses: [NATIVE_TOKEN_ADDRESS],
      start: { order: "descending", anchor: { kind: "atEnd" } },
      limit: 20,
    }, { signal }),
    staleTime: 10_000,
  });

  return (
    <section aria-label="Recent native-token transfers">
      {transfers.isLoading ? <p>Loading transfers…</p> : null}
      {transfers.error ? <p role="alert">{transfers.error.message}</p> : null}
      {transfers.data?.events.length === 0 ? <p>No transfers in this page.</p> : null}
      <ul>
        {transfers.data?.events.map(event => (
          <li key={`${toBase58(event.transactionHash)}:${event.sequenceNumber}`}>
            {event.fields.amount.toString()} base units at block {event.blockHeight.toString()}
          </li>
        ))}
      </ul>
      <button disabled={transfers.isFetching} onClick={() => void transfers.refetch()}>
        Refresh transfers
      </button>
    </section>
  );
}
```

The query has fixed contract, event, start, and page-size inputs. If you make them configurable, include each input in the key. Include the cursor string when caching separate historical pages.



## Choose a history workflow

Refreshing the example starts at the head again. A saved `nextCursor` continues an older historical walk; it is not a subscription. Use the TypeScript [event pagination guidance](pages/typescript/events.md) for iteration and durable checkpoints.

For live refresh, choose an explicit polling policy. Query caching does not create a background indexer or save progress across reloads.



## Decode transaction events

A receipt returned by an execution or receipt hook contains events. Use a generated descriptor’s `allFromReceipt` or `singleFromReceipt` with the emitting contract address.

A committed receipt can report failed execution. Check the result before treating its events as successful application activity. See [Track transaction results](pages/react/transaction-status.md).

---

## Connect a wallet

Source: <https://thruput.network/docs/react/wallets/>

Build wallet and account selectors with explicit connection, network, and error states.

`useWallet` exposes discovered wallets, the selected account, and connection actions. `WalletProvider` manages discovery and session listeners; your components render the controls.

To install and fund a wallet for testing, follow [Wallet Extension](pages/tools/wallet-extension.md).



## Select and connect a wallet

```tsx
import { useWallet } from "@thruputchain/react";

export function WalletControls() {
  const wallet = useWallet();
  const busy = wallet.status === "connecting" || wallet.status === "disconnecting";
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";

  return (
    <section aria-label="Wallet connection">
      <select
        aria-label="Wallet"
        value={wallet.provider?.info.id ?? ""}
        disabled={busy || wallet.providers.length === 0}
        onChange={event => wallet.selectProvider(event.target.value)}
      >
        <option value="" disabled>Choose a wallet</option>
        {wallet.providers.map(provider => (
          <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>
        ))}
      </select>
      {wallet.providers.length === 0 ? <p>No wallet provider detected.</p> : null}
      {authorized ? (
        <button disabled={busy} onClick={() => void wallet.disconnect()}>Disconnect</button>
      ) : (
        <button disabled={busy || !wallet.provider} onClick={() => void wallet.connect()}>
          {wallet.status === "connecting" ? "Connecting…" : "Connect wallet"}
        </button>
      )}
      {wallet.status === "wrongNetwork" ? <p>Switch your wallet to the application's network.</p> : null}
      {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
    </section>
  );
}
```

Discovery selects the first provider without prompting. The user grants access through `connect()`. Provider names and IDs are display metadata, not proof of identity. The library supplies no branded buttons or wallet installation links.



## Select an authorized account

```tsx
import { useWallet } from "@thruputchain/react";

export function AccountSelector() {
  const wallet = useWallet();
  if (!wallet.session?.accounts.length) return null;

  return (
    <select
      aria-label="Account"
      value={wallet.address ?? ""}
      onChange={event => wallet.selectAccount(event.target.value)}
    >
      {wallet.session.accounts.map(account => (
        <option key={account.address} value={account.address}>{account.address}</option>
      ))}
    </select>
  );
}
```

Selection does not prompt. An unauthorized address or unknown provider sets `error` while preserving the current binding. Selecting another provider clears the local binding without revoking the previous provider’s permission.



## Interpret connection state

| State           | UI behavior                                                 |
| --------------- | ----------------------------------------------------------- |
| `disconnected`  | Offer connection when a provider is available               |
| `connecting`    | Show progress and prevent duplicate connection requests     |
| `connected`     | Enable supported signing actions                            |
| `disconnecting` | Local authorization is already cleared; wait for revocation |
| `wrongNetwork`  | Ask the user to switch networks; keep signing disabled      |

`connect()` and `disconnect()` resolve after handling the request. Read failures from `wallet.error`; those actions do not throw provider request failures. Signing and submission operations do reject on failure.



## Handle changes and cleanup

Session changes invalidate old signing bindings immediately. The provider binds a fresh client after event dispatch when possible, retaining the selected account if still authorized. Do not retain an old signing client for future operations.

Disconnect clears local authorization immediately. If remote revocation fails, the UI remains disconnected and exposes an error. Unmounting disposes the local binding without requesting revocation. Connection is explicit; there is no automatic reconnect or persisted connection.

Use the shared [wallet-provider error codes](pages/tools/wallet-provider.md#errors) for application-specific messages. Do not infer transaction failure from a disconnected wallet; [receipt observation](pages/react/transaction-status.md) uses the public client.

---

## Send transactions

Source: <https://thruput.network/docs/react/transactions/>

Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.

`useExecute` runs a wallet-backed transaction from a user action. It prepares, signs, awaits your persistence callback, submits once, and waits for successful execution. Both [providers](pages/react/providers.md) are required.



## Execute a typed call

This component sends a small native-token transfer to an already funded recipient. The application supplies `savePending`, which must durably save the approved transaction before resolving:

```tsx
import { gasAmount, parseUnits, toBase58, TransactionObservationError, type ContractAddress } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useExecute, useWallet, type ExecuteVariables } from "@thruputchain/react";

type SavePending = ExecuteVariables["options"]["onSigned"];

export function SendNativeTokens({ receiver, savePending }: {
  receiver: ContractAddress;
  savePending: SavePending;
}) {
  const wallet = useWallet();
  const execution = useExecute();
  const unresolved = execution.error instanceof TransactionObservationError;

  function send() {
    execution.mutate({
      request: {
        invocation: ERC20.v0_1.transfer.invocation(NATIVE_TOKEN_ADDRESS, gasAmount(500_000n), {
          receiver,
          amount: parseUnits("0.0001", 7),
        }),
        gasLimit: gasAmount(1_000_000n),
      },
      options: { onSigned: savePending, wait: { timeoutMs: 60_000 } },
    });
  }

  return (
    <section aria-label="Send native tokens">
      <button disabled={wallet.status !== "connected" || execution.isPending || unresolved} onClick={send}>
        {execution.isPending ? "Waiting for approval or confirmation…" : "Send native tokens"}
      </button>
      {execution.error ? <p role="alert">{execution.error.message}</p> : null}
      {unresolved ? <p>Check the saved transaction before starting another transfer.</p> : null}
      {execution.data ? <p>Committed: {toBase58(execution.data.transactionHash)}</p> : null}
    </section>
  );
}
```

`mutate` exposes failures through mutation state. Use `mutateAsync` when an event handler needs to await the result, and handle its rejected promise. Trigger writes from user actions, not render effects.

The example budgets apply to this transfer, not every contract. See [gas and funding](pages/typescript/transactions.md#set-gas-and-funding) for root and child limits and first-address storage funding.



## Save before submission

`onSigned` receives the `0x` hex signed transaction, its base58 `hash`, the account, and the original base58 network hash. Await the application’s durable write. A rejected callback prevents broadcast.

The query cache is not the pending-transaction store. Keep the saved record available after a reload, account change, or disconnect. Use it to [observe the original transaction](pages/react/transaction-status.md) rather than automatically signing a replacement.



## Handle mutation state

| State       | Meaning                                                                               |
| ----------- | ------------------------------------------------------------------------------------- |
| `isPending` | Preparation, approval, persistence, submission, or receipt observation is in progress |
| `data`      | Successful committed execution with `transactionHash` and `receipt`                   |
| `error`     | Inspect the error boundary; an observation failure is not proof of failed execution   |

Mutation retries are disabled, including when the QueryClient’s defaults enable retries. A wallet change invalidates the captured signing binding; observation after broadcast can continue on the original network.

`reset()` clears mutation UI state. It does not cancel a transaction or resolve an unknown outcome. See the shared [execution error model](pages/typescript/transaction-status.md#handle-execution-helper-errors).



## Decode returns and refresh reads

For typed child returns, use the current `useWalletClient()` binding’s `executeCallsAndWait` with the required persistence options. Keep its promise and UI state in the application’s write handler; `useExecute` returns the root execution result.

After commitment, explicitly [invalidate affected queries](pages/react/queries.md#refresh-after-a-write). Capture their original account/token keys before starting the operation so a later account selection does not change the refresh target.

---

## Track transaction results

Source: <https://thruput.network/docs/react/transaction-status/>

Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.

`useWaitForTransactionReceipt` observes a hash through the public client. It works while the wallet is disconnected. Use a client on the transaction’s original network.



## Display a receipt

```tsx
import { useWaitForTransactionReceipt } from "@thruputchain/react";

export function TransactionStatus({ hash }: { hash: string | null }) {
  const receipt = useWaitForTransactionReceipt({
    hash: hash || null,
    wait: { timeoutMs: 60_000, pollingIntervalMs: 500 },
  });

  if (!hash) return <p>No transaction selected.</p>;
  if (receipt.error) {
    return (
      <section>
        <p role="alert">Observation stopped: {receipt.error.message}</p>
        <button disabled={receipt.isFetching} onClick={() => void receipt.refetch()}>
          Check again
        </button>
      </section>
    );
  }
  if (!receipt.data) return <p>Waiting for a committed receipt…</p>;

  const { execution } = receipt.data;
  const succeeded = "result" in execution && execution.result === "return";
  return (
    <p>
      {succeeded ? "Execution succeeded" : "Execution failed"}
      {" at block "}{receipt.data.blockHeight.toString()}
    </p>
  );
}
```

A failed committed execution is **receipt data**, not a query error. A query timeout means observation stopped, not that the transaction failed.



## Resume observation

Restore the saved base58 hash and its network from the application’s pending record. Missing hashes disable the query. Refetch explicitly to resume after a timeout; do not submit a new operation merely to obtain a result.

The SDK owns polling. The receipt query disables retries and automatic focus/reconnect refetching. Committed receipts have infinite stale time. Observers of the same hash share the query, so configure their timeout and polling settings consistently.

Canceling the query cancels observation, never the transaction.



## Interpret contract results

The receipt is for the transaction’s root method. A wallet-wrapped application call must be decoded through the wallet’s child results, not by treating the root as the application method. Use the [TypeScript receipt model](pages/typescript/transaction-status.md#decode-the-correct-method).

Generated event descriptors can select receipt events by emitter and type. The application decides whether commitment completes its workflow; a queued request may require later events before the requested action is complete.

---

## React API reference

Source: <https://thruput.network/docs/react/reference/>

Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.

| Entry point                                                   | Purpose                                                                                               |
| ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `@thruputchain/react`                                         | All public React exports below                                                                        |
| [Setup](pages/react/setup.md)                                 | Installation and context wiring                                                                       |
| [TypeScript client reference](pages/tools/typescript-sdk.md)  | Shared SDK concepts and operations; use the client supported by the React package’s peer dependencies |
| [React source](https://github.com/thruputchain/thruput-react) | Public declarations and implementation                                                                |



## WalletProvider

| Prop               | Type / behavior                                                                   |
| ------------------ | --------------------------------------------------------------------------------- |
| `client`           | Initialized `ConnectedThruputClient` with validated cluster identity; keep stable |
| `children`         | `ReactNode`                                                                       |
| `discoveryTarget?` | `EventTarget`; browser default is `window` after mounting                         |

| Context behavior   | Rule                                                                        |
| ------------------ | --------------------------------------------------------------------------- |
| Scope              | One application network and selected wallet connection                      |
| Discovery          | Automatic after mounting; first provider selected without prompting         |
| Connection         | Explicit; no automatic reconnect or persisted connection                    |
| Client replacement | Dispose binding and start disconnected, including same-network replacements |
| Server rendering   | Disconnected initial state; browser discovery after mount                   |
| Usage              | [Providers and clients](pages/react/providers.md)                           |



## Wallet hooks

| Hook                | Result                                                           |
| ------------------- | ---------------------------------------------------------------- |
| `useClient()`       | The configured public client, including while disconnected       |
| `useWallet()`       | `WalletConnection`: reactive state and stable connection actions |
| `useWalletClient()` | Current provider-backed signing client or `null`                 |
| Context requirement | `WalletProvider`; no QueryClient required for these three hooks  |



### WalletConnection

| Field / action               | Meaning                                                                    |
| ---------------------------- | -------------------------------------------------------------------------- |
| `providers` / `provider`     | Discovered providers and selected provider                                 |
| `session`                    | Validated network and authorized accounts, or `null`                       |
| `account` / `address`        | Selected wire account and canonical base58 address, or `null`              |
| `networkHash`                | Expected application network in unprefixed base58                          |
| `status`                     | `disconnected`, `connecting`, `connected`, `disconnecting`, `wrongNetwork` |
| `error`                      | Latest connection/selection error, or `null`                               |
| `connect()` / `disconnect()` | `Promise<void>`; request failures appear in `error`                        |
| `selectProvider(id)`         | Select a discovered provider without prompting                             |
| `selectAccount(address)`     | Select an authorized account and recreate the binding                      |
| Usage                        | [Connect a wallet](pages/react/wallets.md)                                 |



## Contract reads

| API                               | Inputs / result                                                                                                 |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `useContractView(input)`          | Generated `method`, contract `address`, typed `args`, optional `caller`, `enabled`, `staleTime`                 |
| `contractViewQueryOptions(input)` | Same inputs plus explicit initialized `client`; reusable TanStack options                                       |
| Result                            | Query state and `queryKey`; data is `ContractView<R>` with `value`, `stateBlockHeight`, `gasUsed`, and `events` |
| Defaults                          | `enabled: true`, `staleTime: 0`; other query behavior follows the QueryClient                                   |
| Key                               | Client/network, decoder identity, contract address, entrypoint, encoded arguments, caller                       |
| Cancellation                      | Abort the view request and discard late results                                                                 |
| Validation                        | Arguments are encoded while constructing the query, even when disabled                                          |
| Usage                             | [Read contract data](pages/react/reads.md)                                                                      |



## Balances

| API                                             | Inputs / result                                                                    |
| ----------------------------------------------- | ---------------------------------------------------------------------------------- |
| `useBalance({ address?, query? }?)`             | Native-token balance                                                               |
| `useTokenBalance({ token?, address?, query? })` | Standard ERC-20 balance                                                            |
| `BalanceAddress`                                | Base58 string or SDK-branded address bytes                                         |
| `BalanceData`                                   | `{ rawBalance: bigint; stateBlockHeight: bigint }`                                 |
| Hook result                                     | TanStack Query state plus `queryKey`; `query.select` can change observer data type |
| Omitted `address`                               | Connected account on the application’s network                                     |
| Explicit address                                | Read without wallet permission                                                     |
| Null address / missing token                    | Skip fetching                                                                      |
| Invalid address                                 | Query error state                                                                  |
| Cancellation                                    | Discard abandoned results; underlying balance RPC may finish                       |
| Usage                                           | [Read balances](pages/react/balances.md)                                           |



### Balance query options

| Option                                                         | Behavior                                                     |
| -------------------------------------------------------------- | ------------------------------------------------------------ |
| `enabled`                                                      | Control automatic observer fetching                          |
| `staleTime`, `gcTime`                                          | Freshness and cache retention                                |
| `refetchInterval`, `refetchIntervalInBackground`               | Explicit polling                                             |
| `refetchOnMount`, `refetchOnReconnect`, `refetchOnWindowFocus` | Refresh triggers                                             |
| `retry`, `retryDelay`                                          | Read retry policy                                            |
| `select`                                                       | Transform observer data; cache remains raw `BalanceData`     |
| Key / fetch function                                           | Owned by the library; not configurable through these options |



## Transaction execution

| API / field                | Behavior                                                                          |
| -------------------------- | --------------------------------------------------------------------------------- |
| `useExecute()`             | TanStack mutation through the current wallet                                      |
| `ExecuteVariables.request` | SDK `PrepareExecutionRequest`: inner invocation, root budget, transaction options |
| `ExecuteVariables.options` | Required `onSigned`; optional `wait` observation controls                         |
| `mutate(variables)`        | Start from an event handler; expose mutation state                                |
| `mutateAsync(variables)`   | Await execution; rejects on failure                                               |
| Successful data            | `{ transactionHash, receipt }` after successful committed execution               |
| Retry                      | Always disabled by the hook                                                       |
| Invalidation               | Application-owned; no automatic balance refresh                                   |
| Typed child results        | Use the signing client’s `executeCallsAndWait`                                    |
| Usage                      | [Send transactions](pages/react/transactions.md)                                  |



## Receipt observation

| API / option                                      | Behavior                                                                        |
| ------------------------------------------------- | ------------------------------------------------------------------------------- |
| `useWaitForTransactionReceipt({ hash?, wait? }?)` | Public observation; wallet connection not required                              |
| `hash`                                            | Base58 string; `null` or `undefined` skips fetching                             |
| `wait.timeoutMs` / `pollingIntervalMs`            | SDK observation settings; configure consistently for the same hash              |
| Data                                              | `TransactionReceipt`, including failed committed execution                      |
| Query error                                       | Observation failure, not proof of failed execution                              |
| `queryKey`                                        | Client/network-scoped canonical hash                                            |
| Defaults                                          | Infinite stale time; no query retry, focus/reconnect refetch, or retry on mount |
| Cancellation                                      | Cancels observation, never the transaction                                      |
| Usage                                             | [Track transaction results](pages/react/transaction-status.md)                  |



## Query factories and keys

| Export                           | Inputs / purpose                                                                         |
| -------------------------------- | ---------------------------------------------------------------------------------------- |
| `balanceQueryOptions`            | Explicit client, address, optional balance-query settings                                |
| `tokenBalanceQueryOptions`       | Explicit client, address, token, optional balance-query settings                         |
| `contractViewQueryOptions`       | Explicit client and typed view inputs                                                    |
| `transactionReceiptQueryOptions` | Explicit client, hash, and wait settings                                                 |
| `getClientQueryKey(client)`      | Stable-value network/client prefix for custom query keys                                 |
| Factory context                  | No hook or provider required; use the same client instance to share cache entries        |
| Missing balance inputs           | Skipped query; do not use imperative fetch with missing inputs                           |
| Cache lifetime                   | In-memory client identity; not portable for persisted caches or server/browser hydration |
| Usage                            | [Cache and refresh data](pages/react/queries.md)                                         |

---

## Tutorials

Source: <https://thruput.network/docs/tutorials/>

Build a counter app from an empty directory through contract, TypeScript, React, and wallet connection tutorials.



## Build a counter app

One contract and one application across four parts:

1. [Contract](pages/tutorials/build-a-counter.md): write, test, and deploy the counter.
2. [TypeScript](pages/tutorials/work-with-thruput-from-typescript.md): create the client and a server-side development signer.
3. [React](pages/tutorials/build-a-counter-with-react.md): build a working counter interface with development signing and receipt tracking.
4. [Connect a wallet](pages/tutorials/connect-a-wallet-to-your-app.md): switch to wallet-approved updates and return to development signing on explicit disconnect.

Follow the four parts in order, using your own contract and deployment throughout. The [examples repository](https://github.com/thruputchain/thruput-examples) supplies a full-featured counter app for reference.

---

## Build a counter, part 1: Contract

Source: <https://thruput.network/docs/tutorials/build-a-counter/>

Create, test, and deploy the contract for a counter application, starting from an empty directory.

Build a small counter application from scratch. Across four parts, you will create a contract, add a TypeScript development signer, build a React interface, and let users switch to their own wallet.

You can also explore the [full counter example on GitHub](https://github.com/thruputchain/thruput-examples/tree/main/apps/counter).



## Create the contract

Complete [CLI installation and Cargo access](pages/cli/install.md). For deployment, use a funded Futurenet account from the [CLI quickstart](pages/get-started/cli.md).

```bash
thruput new counter --template counter
cd counter
```

Keep the generated manifest and toolchain settings. Open `src/implementation.rs`. The scaffold includes the Balance-based counter used by this guide; focus on its storage and these methods.



## Store a relative count

```rust
use thruput_sdk::storage::Balance;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}
```

`value` is a persistent storage handle. `Balance` stores nonnegative amounts and reads zero before the first update. Increment and decrement record relative changes:

```rust
pub fn initialize(&mut self, initial_value: u64) {
    self.value.increase(initial_value as i128);
}

pub fn increment(&mut self, amount: u64) {
    self.value.increase(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.decrease(amount as i128);
}
```

Both methods take a nonnegative amount. `increase` checks for overflow, and `decrease` fails during execution if this invocation would take the count below zero. Both record deltas that can merge across compatible concurrent transactions within bounds. See [Balance](pages/programming-model/storage-types.md#balance) for checked and lazy updates.

`Balance::get` returns zero for missing storage and preserves other storage errors:

```rust
pub fn get(&self) -> u64 {
    self.value.get() as u64
}
```

`initialize` adds its initial amount. It is an ordinary method, so call it once during this deployment flow. This teaching counter allows any caller to update it. Leave the extra scaffold event and error methods in place; the app does not need them.

Balance uses the same mergeable integer storage as NNInt. Once you understand the Balance API, read [NNInt and concurrent updates](pages/programming-model/nnint.md) for signed deltas, explicit bases, and the underlying merge rules.



## Run both test modes

```bash
cargo test
thruput test
```

The native tests exercise contract logic and underflow handling. The artifact test runs the compiled RV32 contract. Neither needs a running RPC node.

**Checkpoint:** the counter tests pass, including a decrement that is expected to fail.



## Build, deploy, and initialize

```bash
thruput build
thruput deploy --estimate --profile futurenet
```

Add **10 native test tokens** to the reported minimum funding in whole-token units as an example allowance for initializer storage and later writes. This is a budget, not an exact estimate of those writes or a universal requirement. Replace `TOTAL_FUNDING` with the decimal sum. The minimum alone covers only the first balance-item deposit and deployment collateral, leaving no free contract balance. See [Estimate deployment funding](pages/cli/deploy-and-call.md#estimate-deployment-funding).

```bash
thruput deploy --profile futurenet --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
thruput view counter get --profile futurenet
```

Confirm the deployment when prompted, or pass `--yes` when running without a terminal. Funding, deployment, and initialization happen in one transaction. The sender still needs its own storage and scheduling capacity. Your new counter should read `10`.

Save the printed deployment address. Part 2 uses this address and the contract spec produced by the build.



## Check a change

```bash
thruput call counter increment 1 --profile futurenet
thruput view counter get --profile futurenet
```

On your otherwise unchanged counter, the value is now `11`. Keep the same address and project for [part 2](pages/tutorials/work-with-thruput-from-typescript.md).

For isolated local work, follow [Run a local node](pages/cli/local-node.md) and use its profile, endpoint, and network identity consistently.



## Work with an agent

```text
Follow Build a counter, part 1:
https://thruput.network/docs/tutorials/build-a-counter/
Start with thruput new counter --template counter, without cloning an examples repo.
Run the native and RV32 checks, build, and read the deployment estimate.
Add the documented storage allowance to the minimum and deploy with that
explicit total using my configured Futurenet account. Initialize atomically to 10.
Report the actual address, transaction hash,
and read value. Keep the generated dependency configuration and report
failed checks rather than inventing results.
```

---

## Build a counter, part 2: TypeScript

Source: <https://thruput.network/docs/tutorials/work-with-thruput-from-typescript/>

Create a typed client and a small server-side development signer for the counter, without cloning a repository.

Build the TypeScript layer for the contract from [part 1](pages/tutorials/build-a-counter.md). It will read the counter and prepare signed updates with a funded development key. The key stays in Node.js. Part 3 adds a React interface that can start counting immediately.



## Create the app directory

Inside the `counter` project from part 1:

```bash
mkdir app
cd app
npm init -y
npm pkg set type=module
```

Configure [npm registry access](pages/typescript/setup.md#give-npm-package-access), then install the TypeScript dependencies:

```bash
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src/contracts
```

Keep the generated lockfile. Add these entries to `.gitignore`:

**.gitignore**

```text
node_modules/
dist/
.env
```



## Generate the TypeScript binding

Use Thruput CLI 0.29.0 or newer. Its TypeScript generator imports the `@thruputchain` packages used by this app. Generate the binding from the contract spec built in part 1. Run this from `app`:

```bash
thruput codegen ts ../target/thruput/counter.spec.xdr \
  --output src/contracts/counter.ts
```

The binding provides typed methods and decodes the contract’s results. Regenerate it when the contract interface changes.



## Configure the client

Get the network hash for the deployment with [`getNetworkInfo`](pages/reference/json-rpc-api.md#getnetworkinfo):

```bash
curl -s https://rpc.thruput.network \
  -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"getNetworkInfo","params":{}}'
```

Futurenet resets can change this hash, so fetch it again after a reset.

Create `.env`. Set `NETWORK_HASH` to the `networkHash` value from the response and `COUNTER_ADDRESS` to the deployment address from part 1:

**.env**

```dotenv
RPC_URL=https://rpc.thruput.network
NETWORK_HASH=<network-hash>
COUNTER_ADDRESS=<your-deployed-counter-address>
```

These public values identify one deployment. A different network needs its own endpoint, hash, and contract address.

**chain.ts**

```ts
import {
  addressFromBase58, createThruputClient, createPubkeyAccount, createWalletClient,
  defineCluster, fromHex0x, hashFromBase58, networkHash, Ed25519Signer,
} from "@thruputchain/client";
import { Counter } from "./src/contracts/counter.js";

function required(name: string) {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} in .env or the process environment`);
  return value;
}

export const rpcUrl = required("RPC_URL");
export const contract = addressFromBase58(required("COUNTER_ADDRESS"));
export const client = await createThruputClient({
  cluster: defineCluster({
    rpcUrl,
    networkHash: networkHash(hashFromBase58(required("NETWORK_HASH"))),
    capabilities: ["airdrop"],
  }),
});
export { Counter };

export function developmentWallet() {
  const signer = Ed25519Signer.fromSeed(fromHex0x(required("COUNTER_SIGNING_PRIVATE_KEY")));
  return createWalletClient({ client, account: createPubkeyAccount({ signer }) });
}
```



## Read and fund

**read.ts**

```ts
import { client, contract, Counter } from "./chain.js";

const result = await Counter.v0_1.get.view({ client, address: contract });
console.log("Counter:", result.value.toString());
console.log("Read at block:", result.stateBlockHeight.toString());
```

```bash
node --env-file=.env --import tsx read.ts
```

For a disposable development signer, generate a seed once in this terminal:

```bash
export COUNTER_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep this terminal environment for funding and the server. A persistent account should load its existing seed from secret configuration. Never put this key in a browser file or a `VITE_` variable.

**fund.ts**

```ts
import { toBase58 } from "@thruputchain/client";
import { developmentWallet } from "./chain.js";

const wallet = developmentWallet();
const funding = await wallet.requestAirdrop();
console.log("Development signer:", toBase58(wallet.account.address));
console.log("Funding transaction:", toBase58(funding.transactionHash));
```

```bash
node --env-file=.env --import tsx fund.ts
```



## Add the development server

The server exposes public configuration, proxies the app’s RPC requests, and prepares only a `+1` or `-1` call to the configured counter. Preparation signs but does not broadcast. The browser can therefore retain the hash before submission.

**server.ts**

```ts
import { createServer, type ServerResponse } from "node:http";
import { gasAmount, serializeSignedTransaction, toBase58, toHex0x } from "@thruputchain/client";
import { client, contract, Counter, developmentWallet, rpcUrl } from "./chain.js";

const wallet = process.env.COUNTER_SIGNING_PRIVATE_KEY ? developmentWallet() : null;
const allowed = new Set([
  "getVersionInfo", "getNetworkInfo", "getServerLimits", "getChainTip", "simulateInvocation",
  "getBalance", "getTransactionStatus", "getTransactionReceipt",
  "sendTransaction",
]);
function json(response: ServerResponse, status: number, value: unknown) {
  response.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  response.end(JSON.stringify(value));
}

createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/api/config") {
      return json(response, 200, {
        counterAddress: toBase58(contract), networkId: toBase58(client.network.networkHash),
        signerAddress: wallet ? toBase58(wallet.account.address) : null,
      });
    }
    if (request.method !== "POST") return json(response, 404, { error: "Not found" });
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 65_536) return json(response, 413, { error: "Request too large" });
      chunks.push(Buffer.from(chunk));
    }
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (request.url === "/api/prepare") {
      if (!wallet) return json(response, 503, { error: "Development signer unavailable" });
      if (body?.direction !== "increment" && body?.direction !== "decrement") {
        return json(response, 400, { error: "Choose increment or decrement" });
      }
      const direction: "increment" | "decrement" = body.direction;
      const transaction = await wallet.prepareExecution({
        invocation: Counter.v0_1[direction].invocation(contract, gasAmount(500_000n), { amount: 1n }),
        gasLimit: gasAmount(1_000_000n),
      });
      const signed = await wallet.signTransaction(transaction);
      return json(response, 200, { transaction: toHex0x(serializeSignedTransaction(signed)) });
    }
    if (request.url === "/thruput-rpc" && allowed.has(body?.method)) {
      const upstream = await fetch(rpcUrl, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body), signal: AbortSignal.timeout(10_000),
      });
      return json(response, upstream.status, await upstream.json());
    }
    json(response, 404, { error: "Not found" });
  } catch (error) {
    json(response, 500, { error: error instanceof Error ? error.message : "Request failed" });
  }
}).listen(3001, "127.0.0.1", () => console.log("Counter API: http://127.0.0.1:3001"));
```

Run it in the terminal holding the development key:

```bash
node --env-file=.env --import tsx server.ts
```

**Checkpoint:** the typed read works, the development account is funded, and the API is running. The server keeps its private key; `/api/config` exposes only public identity as base58. The signed transaction from `/api/prepare` stays `0x` hex. Part 3 turns these pieces into a usable React counter.

This server is for local development.



## Work with an agent

```text
Follow Build a counter, part 2:
https://thruput.network/docs/tutorials/work-with-thruput-from-typescript/
Generate the binding from my part-1 contract spec and create the listed
files using my deployment address. Verify the read, funding, and
public configuration endpoint. Keep the development key server-side.
Do not claim success for failed checks or submit replacement transactions
merely because observation failed.
```

---

## Build a counter, part 3: React

Source: <https://thruput.network/docs/tutorials/build-a-counter-with-react/>

Build a small React counter that can read and update the contract immediately through the development signer.

Add a React interface to the project from [part 2](pages/tutorials/work-with-thruput-from-typescript.md). It will work through the funded development signer as soon as you open it. There is no wallet connection requirement yet.

Keep the API server running on port 3001. All files below are inside the `app` directory you created in part 2.



## Install React

From `app`, install the React packages and browser tooling:

```bash
npm install @thruputchain/react @tanstack/react-query react react-dom
npm install --save-dev vite @types/react @types/react-dom
```



## Add the browser entry point

```bash
npm pkg set scripts.dev="vite" scripts.build="tsc --noEmit && vite build"
```

**tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022", "module": "ESNext", "moduleResolution": "Bundler",
    "jsx": "react-jsx", "strict": true, "noUncheckedIndexedAccess": true,
    "skipLibCheck": true, "noEmit": true, "types": ["vite/client", "node"]
  },
  "include": ["*.ts", "src"]
}
```

**vite.config.ts**

```ts
import { defineConfig } from "vite";

export default defineConfig({
  server: {
    host: "127.0.0.1",
    proxy: {
      "/api": "http://127.0.0.1:3001",
      "/thruput-rpc": "http://127.0.0.1:3001",
    },
  },
});
```

**index.html**

```html
<!doctype html>
<html lang="en">
  <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Counter</title></head>
  <body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body>
</html>
```



## Connect the public client

**src/main.tsx**

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, defineCluster, hashFromBase58, networkHash } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { App } from "./App";
import type { Config } from "./updates";
import "./style.css";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting…</p>);

async function start() {
  const response = await fetch("/api/config");
  if (!response.ok) throw new Error("Could not load counter configuration");
  const config: Config = await response.json();
  const client = await createThruputClient({
    cluster: defineCluster({
      rpcUrl: new URL("/thruput-rpc", location.origin).href,
      networkHash: networkHash(hashFromBase58(config.networkId)),
      capabilities: [],
    }),
  });
  const queries = new QueryClient();
  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}><App config={config} /></WalletProvider>
    </QueryClientProvider>,
  );
}
void start().catch((error: unknown) => root.render(
  <p role="alert">{error instanceof Error ? error.message : "Could not start the app"}</p>,
));
```

The React provider shares the public client and discovers wallet providers without asking for permission. The next part uses that wallet context. The development signer remains on the API server.

Add a small stylesheet to keep the example readable on narrow screens:

**src/style.css**

```css
body { margin: 0; font-family: system-ui, sans-serif; }
main { max-width: 48rem; margin: auto; padding: 1.5rem; }
section { margin-block: 1.5rem; }
p { overflow-wrap: anywhere; }
button, select { max-width: 100%; margin: .25rem; padding: .5rem .75rem; font: inherit; }
output { font-size: 3rem; font-variant-numeric: tabular-nums; }
```



## Separate preparation from submission

Create a small shared update module. It retains the hash before submitting and can observe a saved operation after a reload:

**src/updates.ts**

```ts
import { useRef, useState } from "react";
import {
  deserializeSignedTransaction, fromHex0x, hashSignedTransaction, serializeSignedTransaction, toBase58,
  type ConnectedThruputClient,
} from "@thruputchain/client";
import { parseSignTransactionResult } from "@thruputchain/client/provider";
import { useClient, useWaitForTransactionReceipt } from "@thruputchain/react";

export type Config = { networkId: string; counterAddress: string; signerAddress: string | null };
export type Direction = "increment" | "decrement";
export type Pending = { hash: string; signedTransaction: string; account: string; networkId: string };
export type Prepared = { record: Pending; submit(): Promise<unknown> };

export async function archiveExpiredUpdate(client: ConnectedThruputClient, record: Pending, key: string, storage: Pick<Storage, "setItem" | "removeItem">) {
  if (toBase58(client.network.networkHash) !== record.networkId) throw new Error("Select the original network before recovery");
  const signed = deserializeSignedTransaction(fromHex0x(record.signedTransaction));
  const hash = hashSignedTransaction(signed);
  if (toBase58(hash) !== record.hash) throw new Error("Saved transaction hash does not match its bytes");
  const tip = await client.getChainTip();
  if (tip.blockHeight < signed.tx.uniquifier.block_expiry_height) throw new Error("The transaction has not expired; keep observing it");
  if (await client.getTransactionReceipt({ transactionHash: hash })) throw new Error("A receipt is available; check the transaction and finish it");
  // Expiry prevents future inclusion, but a missing receipt does not prove it never committed.
  storage.setItem(`${key}:archived:${record.hash}`, JSON.stringify({ ...record, outcome: "unresolved", archivedAtHeight: tip.blockHeight.toString() }));
  storage.removeItem(key);
}

export async function prepareDevelopment(client: ConnectedThruputClient, config: Config, direction: Direction): Promise<Prepared> {
  if (!config.signerAddress) throw new Error("Development signer unavailable");
  const response = await fetch("/api/prepare", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ direction }),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Preparation failed");
  const signed = deserializeSignedTransaction(fromHex0x(body.transaction));
  return {
    record: { hash: toBase58(hashSignedTransaction(signed)), signedTransaction: body.transaction, account: config.signerAddress, networkId: config.networkId },
    submit: () => client.sendTransaction({ signedTransaction: serializeSignedTransaction(signed) }),
  };
}

export function useUpdate(config: Config) {
  const client = useClient();
  const key = `counter:${config.networkId}:${config.counterAddress}`;
  const [state, setState] = useState<{ record: Pending | null; error: string | null }>(() => {
    try {
      const text = localStorage.getItem(key);
      if (!text) return { record: null, error: null };
      const value = JSON.parse(text);
      const signed = parseSignTransactionResult({ hash: value.hash, signedTransaction: value.signedTransaction });
      if (value.networkId !== config.networkId || typeof value.account !== "string") throw new Error("Invalid saved transaction");
      return { record: { ...signed, account: value.account, networkId: value.networkId }, error: null };
    } catch { return { record: null, error: "Cannot read the saved transaction. Check browser storage before sending." }; }
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const lock = useRef(false);
  const receipt = useWaitForTransactionReceipt({ hash: busy ? null : state.record?.hash ?? null });

  async function send(prepare: () => Promise<Prepared>) {
    if (lock.current || state.record || state.error) return;
    lock.current = true; setBusy(true); setError(null); setNotice(null);
    try {
      const update = await prepare();
      localStorage.setItem(key, JSON.stringify(update.record));
      setState({ record: update.record, error: null });
      await update.submit();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Update failed");
    } finally { lock.current = false; setBusy(false); }
  }
  function finish() {
    if (!receipt.data) return;
    try { localStorage.removeItem(key); setState({ record: null, error: null }); setError(null); }
    catch { setError("Could not clear the saved record"); }
  }
  async function archiveExpired() {
    if (lock.current || !state.record) return;
    const record = state.record;
    if (!window.confirm("Archive this expired update? Its past outcome may still be unknown. This does not resend or cancel it. Inspect its original hash before repeating the operation.")) return;
    lock.current = true; setBusy(true); setError(null);
    try {
      await archiveExpiredUpdate(client, record, key, localStorage);
      setState({ record: null, error: null });
      setNotice(`Archived ${record.hash} in browser storage. Its outcome is unresolved; inspect this hash before repeating the operation.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Recovery failed");
    } finally { lock.current = false; setBusy(false); }
  }
  return { pending: state.record, error: state.error ?? error, notice, busy, blocked: busy || Boolean(state.record || state.error), receipt, send, finish, archiveExpired };
}
```

The preparer returns a signed record and a submission function. This keeps the UI independent of how the signature was obtained. The record stores the hash, account, and network as base58, the same format the wallet provider and `useWaitForTransactionReceipt` use. Only the signed transaction stays `0x` hex. A failed storage write stops before submission. A later submission error retains the hash for observation.



## Build the small components

**src/Counter.tsx**

```tsx
import { addressFromBase58 } from "@thruputchain/client";
import { contractViewQueryOptions, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";
import { Counter } from "./contracts/counter";
import type { Direction, useUpdate } from "./updates";

export function CounterPanel({ address, disabled, send }: {
  address: string; disabled: boolean; send(direction: Direction): void;
}) {
  const client = useClient();
  const counter = useQuery({
    ...contractViewQueryOptions({ client, method: Counter.v0_1.get, address: addressFromBase58(address) }),
    refetchInterval: 2_000,
  });
  return <section>
    {counter.isLoading ? <p>Reading counter…</p> : null}
    {counter.error ? <p role="alert">{counter.error.message}</p> : null}
    <p><output aria-label="Counter value">{counter.data?.value.toString() ?? "Not loaded"}</output></p>
    <button type="button" disabled={disabled || !counter.data || counter.data.value === 0n} onClick={() => send("decrement")}>Decrement</button>
    <button type="button" disabled={disabled || !counter.data} onClick={() => send("increment")}>Increment</button>
  </section>;
}

export function UpdateStatus({ update }: { update: ReturnType<typeof useUpdate> }) {
  const execution = update.receipt.data?.execution;
  const succeeded = execution !== undefined && "result" in execution && execution.result === "return";
  return <section aria-label="Transaction">
    {update.busy ? <p>Preparing or submitting…</p> : null}
    {update.error ? <p role="alert">{update.error}</p> : null}
    {update.notice ? <p role="status">{update.notice}</p> : null}
    {update.pending ? <>
      <p>Original signer: {update.pending.account}</p>
      <p>Transaction: {update.pending.hash}</p>
      {update.receipt.data ? <>
        <p role="status">{succeeded ? "Update committed" : "Execution failed"}</p>
        <button type="button" onClick={update.finish}>Finish</button>
      </> : <>
        <p>Waiting for a result. A timeout does not cancel the transaction.</p>
        {update.receipt.error ? <p role="alert">{update.receipt.error.message}</p> : null}
        <button type="button" disabled={update.busy || update.receipt.isFetching} onClick={() => void update.receipt.refetch()}>Check transaction</button>
        <button type="button" disabled={update.busy} onClick={() => void update.archiveExpired()}>Archive expired update</button>
      </>}
    </> : null}
  </section>;
}
```

**src/App.tsx**

```tsx
import { useClient } from "@thruputchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { prepareDevelopment, useUpdate, type Config } from "./updates";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const update = useUpdate(config);
  return <main>
    <h1>Counter</h1>
    <p>Using development signer: {config.signerAddress ?? "Not configured"}</p>
    <CounterPanel address={config.counterAddress} disabled={update.blocked || !config.signerAddress}
      send={direction => void update.send(() => prepareDevelopment(client, config, direction))} />
    <UpdateStatus update={update} />
  </main>;
}
```



## Run and verify

In a second terminal inside `app`, leaving the API server running:

```bash
npm run dev
```

Open Vite’s URL. Click **Increment**, wait for **Update committed**, and confirm the refreshed counter value. Click **Finish** before another update. Try **Decrement** too.

The public read refreshes independently of signing. An error or timeout does not cause another transaction to be submitted. A saved hash remains available after reload; this minimal example keeps one unresolved update per counter and network in one browser tab.

If submission was stopped after signing, a receipt may never arrive. **Archive expired update** checks the original network, signed bytes, expiry height, and receipt before releasing the active slot. It preserves the complete record under `counter:NETWORK:CONTRACT:archived:HASH` in browser storage. It does not resend the transaction or prove it never committed: an unavailable or lagging indexer can still hide a past receipt. Inspect the original hash before repeating the operation. Recovery errors, including a failed archive write, keep the active record.

```bash
npm run build
```

**Checkpoint:** a working React counter using a server-held development signer. No wallet connection or keyboard/concurrency machinery is needed. Part 4 adds a different signing path to these same components.



## Work with an agent

```text
Follow Build a counter, part 3:
https://thruput.network/docs/tutorials/build-a-counter-with-react/
Create the listed files in my existing app directory. Do not clone an
examples repo. Verify reads, increment/decrement, transaction feedback,
and the build. Keep the development key on the server and retain an
unresolved transaction's hash instead of submitting a replacement.
```

---

## Build a counter, part 4: Connect a wallet

Source: <https://thruput.network/docs/tutorials/connect-a-wallet-to-your-app/>

Let the user switch from the development signer to a connected wallet in the same counter application.

Keep the app from [part 3](pages/tutorials/build-a-counter-with-react.md). It already works through the development signer. Add wallet controls so a successful connection switches new updates to the user’s wallet; explicit disconnect returns to the development signer.

The display, contract, public client, and transaction-status component stay the same. Only preparation and submission differ.



## Prepare the wallet

Install the [Wallet Extension](pages/tools/wallet-extension.md) and select the app’s network. Request native test tokens for that wallet’s account; it is independent of the server’s development signer.

`WalletProvider` is already mounted from part 3. It discovers providers without requesting permission.



## Add wallet controls

**src/WalletControls.tsx**

```tsx
import { useWallet } from "@thruputchain/react";

export function WalletControls({ busy, walletMode, disconnect }: {
  busy: boolean; walletMode: boolean; disconnect(): void;
}) {
  const wallet = useWallet();
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  return <section aria-label="Wallet connection">
    <label>Wallet <select name="wallet" value={wallet.provider?.info.id ?? ""}
      disabled={busy || connecting || wallet.providers.length === 0}
      onChange={event => wallet.selectProvider(event.target.value)}>
      <option value="" disabled>No wallet detected</option>
      {wallet.providers.map(provider => <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>)}
    </select></label>
    <button type="button" disabled={busy || connecting || !wallet.provider || wallet.status === "connected"}
      onClick={() => void wallet.connect()}>Connect wallet</button>
    {walletMode ? <button type="button" disabled={busy || connecting} onClick={disconnect}>Disconnect wallet</button> : null}
    {wallet.session && wallet.session.accounts.length > 1 ? <label>Account
      <select name="account" value={wallet.address ?? ""} disabled={busy || connecting}
        onChange={event => wallet.selectAccount(event.target.value)}>
        {wallet.session.accounts.map(account => <option key={account.address} value={account.address}>{account.address}</option>)}
      </select>
    </label> : null}
    {wallet.status === "wrongNetwork" ? <p role="alert">Select the app's network in your wallet.</p> : null}
    {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
  </section>;
}
```



## Add the wallet preparer

**src/wallet-update.ts**

```ts
import { addressFromBase58, gasAmount } from "@thruputchain/client";
import type { ProviderWalletClient } from "@thruputchain/client/wallet";
import { Counter } from "./contracts/counter";
import type { Config, Direction, Prepared } from "./updates";

export async function prepareWallet(wallet: ProviderWalletClient, account: string, config: Config, direction: Direction): Promise<Prepared> {
  const transaction = await wallet.prepareExecution({
    invocation: Counter.v0_1[direction].invocation(addressFromBase58(config.counterAddress), gasAmount(500_000n), { amount: 1n }),
    gasLimit: gasAmount(1_000_000n),
  });
  const signed = await wallet.signTransaction(transaction);
  return {
    record: { ...signed, account, networkId: config.networkId },
    submit: () => wallet.submitTransaction(signed),
  };
}
```

The same `useUpdate` hook saves the signed record before invoking `submit`. The wallet returns the transaction hash in base58, the same format as the development record. A wallet rejection prevents submission. The application never receives the wallet’s private key.



## Switch signing paths

Replace `src/App.tsx`:

**src/App.tsx**

```tsx
import { useEffect, useState } from "react";
import { useClient, useWallet, useWalletClient } from "@thruputchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { WalletControls } from "./WalletControls";
import { prepareDevelopment, useUpdate, type Config, type Direction } from "./updates";
import { prepareWallet } from "./wallet-update";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const wallet = useWallet();
  const signingClient = useWalletClient();
  const update = useUpdate(config);
  const [selected, setSelected] = useState<"development" | "wallet">("development");
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";
  useEffect(() => { if (authorized) setSelected("wallet"); }, [authorized]);
  const walletMode = authorized || selected === "wallet";
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  const canSend = walletMode ? wallet.status === "connected" && signingClient !== null : config.signerAddress !== null;

  function disconnect() {
    void wallet.disconnect();
    setSelected("development");
  }
  function send(direction: Direction) {
    if (!canSend || connecting || update.blocked) return;
    if (walletMode) {
      if (!signingClient || !wallet.address) return;
      const originalClient = signingClient;
      const originalAccount = wallet.address;
      void update.send(() => prepareWallet(originalClient, originalAccount, config, direction));
    } else {
      void update.send(() => prepareDevelopment(client, config, direction));
    }
  }
  return <main>
    <h1>Counter</h1>
    <p>{walletMode ? "Using connected wallet" : "Using development signer"}: {walletMode ? wallet.address ?? "Unavailable" : config.signerAddress ?? "Unavailable"}</p>
    <WalletControls busy={update.busy} walletMode={walletMode} disconnect={disconnect} />
    <CounterPanel address={config.counterAddress} disabled={!canSend || connecting || update.blocked} send={send} />
    <UpdateStatus update={update} />
  </main>;
}
```

A successful connection selects wallet signing immediately. A later session loss or wrong network keeps wallet mode selected and pauses writes. It does not silently send through the development key. Explicit disconnect opts back into development signing.

Each update captures its original signing client and account. A receipt is observed through the public client, so disconnecting does not cancel an already-submitted transaction.



## Verify both paths

1. Open the app disconnected. Increment with the development signer and inspect its hash and result.
2. Connect your wallet on the correct network. Confirm the displayed account changes.
3. Increment again and approve the request in the wallet. Wait for the receipt and refreshed value.
4. Reject another approval. The page should show the error without sending through the development signer.
5. Disconnect explicitly. The development-signer label and immediate-update path return.

After a committed result, **Finish** clears its saved record. For an unresolved result, **Check transaction** observes the original hash without submitting again. Reload with a saved hash to verify recovery.

A session change can stop submission after the signed record was saved. Once the signed transaction expires, use **Archive expired update** from part 3 to preserve its evidence and release the active slot. This never switches signers, resubmits, or treats a missing receipt as proof of failure.

```bash
npm run build
```

**Checkpoint:** a small, complete app built without a repository clone. Its default signer is convenient for development, and connected users can approve their own transactions.

You can also explore the [full counter example on GitHub](https://github.com/thruputchain/thruput-examples/tree/main/apps/counter).



## Work with an agent

```text
Follow Build a counter, part 4:
https://thruput.network/docs/tutorials/connect-a-wallet-to-your-app/
Extend my part-3 app using the listed files. Keep development signing
as the default, switch on wallet connection, and return only on explicit
disconnect. Let me approve wallet requests. Verify both paths, rejection,
wrong-network handling, receipt recovery, and the build. Do not clone
the examples repo or add keyboard/concurrency features to this tutorial.
```

---

## Guides

Source: <https://thruput.network/docs/guides/>

Build a token, build an AMM, or consume the firehose with runnable examples and verified checkpoints.

Work through a focused project using the [examples repository](https://github.com/thruputchain/thruput-examples):

- [Build a token](pages/guides/build-a-token.md): balances, allowances, supply policy, events, and native/RV32 checks.
- [Build an AMM](pages/guides/build-an-amm.md): pool creation, liquidity, queued swaps, and correlated outcomes, exercised through the contract test environments.
- [Consume the Firehose](pages/guides/consume-the-firehose.md): connect to whole-block delivery, acknowledge durable progress, and resume after a disconnect.

For the full contract-to-application journey, follow the [counter tutorials](pages/tutorials.md).

---

## Build a token

Source: <https://thruput.network/docs/guides/build-a-token/>

Build and test an ERC-20 contract with balances, allowances, administrator-controlled supply, and standard events.

Build the `erc20` contract in the [examples repository](https://github.com/thruputchain/thruput-examples/tree/main/contracts/erc20). You will trace a transfer, exercise minting and allowances, and test both native and RV32 execution.

This is a contract guide. The [counter series](pages/tutorials/build-a-counter.md) covers the full contract-to-application journey; [TypeScript](pages/typescript.md) covers application interactions.



## Prepare the project

Complete [CLI and Cargo setup](pages/cli/install.md), then clone the examples repository if you do not already have it:

```bash
git clone https://github.com/thruputchain/thruput-examples.git
cd thruput-examples
```

Use the workspace’s manifests, toolchain, and lockfile together. The token implements the shared interface crates rather than copying their definitions.



## Model the token state

Open `contracts/erc20/src/implementation.rs`:

```rust
pub struct TokenContract {
    config: Value<Config>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Allowance>>,
    total_supply: Balance,
}
```

The storage attribute derives paths for these handles:

| Field          | Job                                             |
| -------------- | ----------------------------------------------- |
| `config`       | Administrator and optional token metadata       |
| `balances`     | Each account’s nonnegative token amount         |
| `allowances`   | An owner/spender pair’s remaining authorization |
| `total_supply` | Outstanding tokens                              |

Different map keys are independent. Balance changes use deltas instead of replacing a shared absolute value. See [Storage Types](pages/programming-model/storage-types.md) for the merge rules.



## Follow a transfer

The implementation takes the payer from the direct caller. The internal `_move` helper does the debit, the credit, and the event:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    check_amount(amount);
    let owner = get_caller();

    self._move(&owner, receiver, amount);
}

// Move `amount` from `owner` to `receiver` and emit [`TransferEvent`].
fn _move(&mut self, owner: &ContractAddress, receiver: &ContractAddress, amount: Amount) {
    self._decrease_balance(owner, amount);
    self._lazy_increase_balance(receiver, amount);

    TransferEvent::new(owner, receiver, amount).log();
}
```

`check_amount` rejects a negative amount with `NegativeAmount`. The checked debit throws `TooLarge` if the balance does not cover the amount. The contract has no separate insufficient-balance error. The credit records a relative increase. The event records the movement for applications; it is not the source of the contract’s balance state.

`transfer_from` first spends the caller’s allowance, then performs the same debit and credit. An allowance belongs to a specific owner/spender pair, not to every caller.



## Apply supply and allowance policy

Read the `mint`, `burn`, `clawback`, and `adjust_allowance` implementations:

- Minting and clawback require the configured administrator. Holders burn their own tokens with `burn`, or tokens they hold an allowance for with `burn_from`.
- Initialization records that administrator and rejects a later initialization.
- Allowances change by a signed `difference`. A positive value adds authority; a negative value removes it.
- `delete_allowance` deletes an allowance. `delete_balance` requires a zero balance before it deletes its row.
- Only the two delete paths are exclusive. Each requests sole write access to its entry for the block. Other balance and allowance writes are not exclusive.

The metadata feature adds name, symbol, and decimals. The permit feature adds signed-operation authorization. Keep the basic transfer policy clear before extending either surface.



## Exercise the contract

```bash
cargo test -p erc20 --locked
```

This reports `erc20_test_rv32` as ignored. It needs the built artifact; `thruput test` runs it in the next section.

`tests/test_native.rs` deploys the contract in the SDK environment and runs the shared scenarios under `tests/common`. Inspect those scenarios for administrator checks, minting, transfers, allowance spending, cleanup, and expected exceptions.

`tests/same_block.rs` tests behavior that a serial-only token test would miss:

| Scenario                                                  | Expected result                                                       |
| --------------------------------------------------------- | --------------------------------------------------------------------- |
| Compatible credits to one balance                         | Deltas merge                                                          |
| Debits covered by the balance                             | Both can commit                                                       |
| Combined debits exceed the balance                        | Reservation excludes an overdrawing transaction                       |
| Read during the same block                                | Reads the block snapshot                                              |
| Approval and a separate spending transaction in one block | The new approval is not already spendable from the snapshot           |
| Allowance spend and the owner’s own debit in one block    | Both commit while the balance covers them; one more debit is excluded |

Run a specific case while inspecting the corresponding code:

```bash
cargo test -p erc20 --test same_block same_block_credits_merge --locked
```

**Checkpoint:** the native tests pass, including expected failure paths. A test that deliberately catches a contract exception can still be a passing test.



## Build and test the guest artifact

```bash
thruput build -p erc20
thruput test -p erc20
```

The build writes `target/thruput/erc20.rv32a` and spec sidecars. The artifact test exercises the compiled guest implementation. Keep it as well as the native tests.

You now have a deployable token artifact. Use [Deploy and call](pages/cli/deploy-and-call.md) for network deployment and [Use contract bindings](pages/tools/typescript-bindings.md) for typed application calls. The repository’s standard-token and factory examples add a fixed launch configuration for the separate launchpad application.



## Work with an agent

```text
Follow Build a token:
https://thruput.network/docs/guides/build-a-token/
Use contracts/erc20 in thruput-examples with its workspace lockfile.
Trace administrator checks, transfers, allowances, and events in source.
Run the native, same-block, and RV32 tests. Report actual results and
artifact paths. Do not replace the standard interface with invented APIs.
```

---

## Build an AMM

Source: <https://thruput.network/docs/guides/build-an-amm/>

Build and exercise a queued constant-product AMM, including liquidity, swaps, request outcomes, and RV32 tests.

Build the AMM contract suite in [thruput-examples](https://github.com/thruputchain/thruput-examples). This guide creates pools, adds and removes liquidity, and executes swaps through its native and RV32 test environments. You will also verify that a failed queued request does not become a false success.

Read [Build a token](pages/guides/build-a-token.md) first. Complete [CLI and Cargo setup](pages/cli/install.md). Commands run from the examples repository root with its checked-in manifests and lockfile.



## Assemble the components

| Source                   | Responsibility                                      |
| ------------------------ | --------------------------------------------------- |
| `interfaces/swap-if`     | Shared methods, request types, errors, and clients  |
| `engines/swap-pair`      | Constant-product math and reserve operations        |
| `contracts/swap-handler` | Apply a request, move tokens, and update pair state |
| `contracts/swap-driver`  | Queue and process requests                          |
| `contracts/swap-factory` | Create and connect a pool’s contracts               |
| `contracts/swap-router`  | User-facing liquidity and swap requests             |
| `helpers/batch-driver`   | Shared queue capacity and processing logic          |

The pair is an internal engine used by the handler, not another public contract entry point. The suite adapts [Uniswap V2 pair operations](https://github.com/Uniswap/v2-core/blob/master/contracts/UniswapV2Pair.sol) to Project Thruput’s execution model.



## Create a pool

Run the factory’s deployment scenario:

```bash
cargo test -p swap-factory --test factory create_pair_brings_up_pool --locked
```

Open `contracts/swap-factory/src/factory.rs` and `tests/factory.rs`. Creation derives and funds three addresses, deploys the LP token, handler, and driver, initializes their relationships, and records the pair. The tests verify the resulting pool and funding rules.

The factory takes funding from the caller through an allowance. It does not let arbitrary pool creators spend the factory’s own native tokens. Pool addresses are deterministic for the token pair and configured code hashes.

**Checkpoint:** a pool is created in the test environment with its contracts connected correctly. The test also checks that a second `create_pair` fails, so a passing run prints a `PairExists` exception.



## Add liquidity

```bash
cargo test -p swap-router --test add_liquidity --locked -- --nocapture
```

In `contracts/swap-router/tests/add_liquidity.rs`, the fixture establishes token balances, authorizes the handler, submits a liquidity request, and processes it. The test helper named `etx` is example test code, not an SDK API:

```rust
etx.user_allow_for_pair(user, amounts_desired)?;
etx.advance_block();
etx.user_add_liquidity(ALICE, amounts_desired)?;
etx.process_outstanding_requests(1)?;
```

The tests also separate the purchaser from the recipient: Alice can supply tokens while Bob receives LP tokens. Assertions check both the mint event and the actual LP balance.



## Execute a swap

```bash
cargo test -p swap-router --test swap carol_swap_exact_tokens_for_tokens --locked -- --nocapture
```

Open `contracts/swap-router/tests/swap.rs`. The exact-input scenario:

1. Establishes pool reserves.
2. Calculates expected output independently of the router.
3. Grants the handler an allowance for the input amount.
4. Submits a request with a minimum output.
5. Processes the queue.
6. Checks both token balances, the consumed allowance, and unchanged LP ownership.

The corresponding exact-output test checks that the requested output is received without exceeding the input cap.

**Checkpoint:** the swap tests pass with real state and event assertions, not just a successful method return.



## Understand acceptance and execution

Every swap changes reserves. Concurrent transactions using the same snapshot cannot all replace those reserves with different values. The implementation separates accepting requests from executing reserve-dependent work:

```text
users → router → driver queue
                    ↓
             process_requests
                    ↓
                 handler → pair engine
```

Queue inserts can merge. Processing consumes requests serially inside one transaction, so each operation sees earlier updates in that transaction. The handler accepts work from its driver, and the driver accepts requests from the configured router.

An accepted request is not a completed swap. Submission returns a request ID and emits `RequestAccepted`. A later operation event or `RequestFailed` identifies its outcome.



## Verify failures and request IDs

```bash
cargo test -p swap-router --test request_id --locked
cargo test -p swap-router --test swap swap_limits_respected --locked
cargo test -p swap-driver --test authorization --locked
```

These checks verify that request IDs reach terminal events, a request that misses its slippage limit fails (the exact-input case also checks that balances and the allowance are unchanged), and unauthorized calls cannot bypass the router/driver/handler chain.

Each request is handled with a gas cap and commit locking. A handled failure can roll back that request without taking down other requests in the processing transaction.



## Bound the queue and processing work

Queue capacity bounds pending storage. Consumption is checked during reservation across concurrent requests. An excluded attempt does not land in that proposal. It does not guarantee automatic requeue or a `retry` status. Keep the signed bytes, hash, and original network. When retrying is appropriate, resubmit the same signed transaction while valid. See [Exclusion, requeue, and resubmission](pages/how-it-works/transaction-lifecycle.md#exclusion-requeue-and-resubmission).

Processing is permissionless and bounded by gas. The driver requires enough budget for the waiting work up to its configured minimum batch. It does not consume a request and then discard it merely because no processing budget remains.

```bash
cargo test -p swap-driver --test admission --locked
cargo test -p swap-driver --test min_batch --locked
cargo test -p swap-driver --test same_block --locked
```

These cases check queue limits, the minimum processing budget, and interactions with withdrawals and allowance changes. The source’s `process_requests_gas` helper supplies the budget calculation; do not copy a gas number from an unrelated operation.



## Remove liquidity

```bash
cargo test -p swap-router --test remove_liquidity --locked
```

The tests verify redemption and the distinction between the LP-token owner and the recipient of the withdrawn tokens. Run the complete native suite before changing the design:

```bash
cargo test -p swap-factory -p swap-router -p swap-driver -p swap-pair --locked
```

The suite reports four `sim_*` tests as ignored. They need simulator fixtures and are not part of this guide.



## Verify compiled contracts

Build the guest contracts used by the suite:

```bash
thruput build -p erc20
thruput build -p swap-factory
thruput build -p swap-handler
thruput build -p swap-driver
thruput build -p swap-router
cargo test -p swap-driver -p swap-router -p swap-factory --features guest_test --locked
```

`guest_test` runs the scenarios against the compiled RV32 implementations in the SDK test environment. It does not start a browser application or submit to Futurenet.

**Checkpoint:** you have built the AMM and verified pool creation, liquidity, swaps, and failure behavior through native and guest execution. The repository also contains an application under `apps/swap`; this guide focuses on the contract suite.



## Work with an agent

```text
Follow Build an AMM:
https://thruput.network/docs/guides/build-an-amm/
Use the existing swap contract suite in thruput-examples. Run pool,
liquidity, swap, slippage, request-ID, authorization, and queue tests.
Build the guest artifacts and rerun with guest_test. Explain how the
assertions establish each outcome. Do not equate request acceptance or
a successful processing transaction with completion of a specific swap.
```

---

## Consume the Firehose

Source: <https://thruput.network/docs/guides/consume-the-firehose/>

Connect to the hosted Futurenet firehose from a browser or Node, acknowledge blocks, and resume from durable progress.

The hosted Futurenet firehose is `wss://firehose.thruput.network`. It carries public chain data without authentication. It is experimental and has no SLA.

Use it for whole-block push delivery and bounded replay. Each block contains exact stored `EventIndexerPulledBlock` XDR bytes, transported as hex. Saving these bytes does not verify their commitments. Decode and verify with compatible protocol bindings if your application requires that assurance.



## Connect from a browser

Open a browser console and run:

```js
const ws = new WebSocket('wss://firehose.thruput.network');
ws.addEventListener('open', () => {
  ws.send(JSON.stringify({
    jsonrpc: '2.0', id: 1, method: 'firehose_subscribe',
    params: [{ from: 'tip' }],
  }));
});
ws.addEventListener('message', ({ data }) => console.log(JSON.parse(data)));
```

Browsers can connect directly; WebSocket connections do not use a CORS preflight. A page’s own Content Security Policy must permit the endpoint.

This first snippet only inspects messages. Close it with `ws.close()` before running a consumer. There is one subscription per connection, at most 8 concurrent connections per client IP, and 12 active subscribers globally.



## Process and acknowledge

A subscribe response returns the transport subscription ID. Notifications use `firehose_block` and carry `params.subscription` for routing. A block payload looks like this (hex abbreviated):

```json
{
  "type": "block",
  "subscriberId": 1,
  "block": {
    "schemaVersion": 2,
    "height": 42,
    "consensusHash": "<base58>",
    "byteLength": 27600,
    "record": "0x...",
    "ingestedAtUnixMicros": 1789720800000000
  }
}
```

`schemaVersion` is `2`. `consensusHash` is unprefixed base58. `byteLength` counts raw XDR bytes, not hex characters. `ingestedAtUnixMicros` is absent on archive reads.

The server waits for an application ACK before sending the next block. After durable processing, send:

```js
ws.send(JSON.stringify({
  jsonrpc: '2.0', id: 2, method: 'firehose_ack', params: [1, 42],
}));
```

Use the notification’s `subscriberId`, not the transport subscription ID. The ACK result is `null`. Use `firehose_unsubscribe` with `[subscriptionId]` to remove a subscription.

For a browser application, store output and an inclusive replay height together in an IndexedDB transaction before ACKing. After the ACK response succeeds, advance that checkpoint to the following height. If the ACK response is lost, keep the earlier replay height and process it idempotently. A received message or console log is not durable progress.



## Run the Node consumer

Use [consume-firehose.ts](https://github.com/thruputchain/thruput-examples/blob/main/examples/typescript/consume-firehose.ts) from the examples repository. Use Node 22.18 or newer. Clone the repository if you do not already have it, then install its dependencies and run from the repository root:

```bash
git clone https://github.com/thruputchain/thruput-examples.git
cd thruput-examples
npm install
npm run example:consume-firehose
# Optional configuration:
FIREHOSE_URL=wss://firehose.thruput.network OUTPUT_DIR=./my-output \
  npm run example:consume-firehose
```

Run one consumer per output directory on a filesystem supporting file and directory sync and atomic rename. A new directory subscribes at tip, meaning the next publication after registration. It does not request genesis or replay the current tip.

For each block the example validates the height and byte length, saves the inclusive replay height in `cursor.json`, writes and syncs `HEIGHT.xdr`, then ACKs. After a successful ACK response it saves the following height. Replaying a height overwrites the same output file. This is an idempotent byte sink, not a decoded indexer or a commitment verifier. Replace the file write with your application’s durable transaction as needed.

The checkpoint includes the endpoint so an accidental URL change cannot silently reuse another service’s cursor. Keep the output and checkpoint together. After a crash, a leftover `.tmp` file is not committed progress; the consumer resumes from `cursor.json`.



## Reconnect and resume

The Node example reconnects after transport loss with a 2-second delay. Stop it with Ctrl-C and restart with the same output directory to resume. It sends the saved inclusive replay height:

```json
{"jsonrpc":"2.0","id":1,"method":"firehose_subscribe","params":[{"from":"height","height":43}]}
```

Persist progress from the last acknowledged cursor, allowing conservative replay if ACK delivery or saving the checkpoint was uncertain. Do not resume from the last height merely received. A lost ACK response can cause a processed block to repeat across connections, so application effects must be idempotent.

A terminal notification has this payload:

```json
{"type":"closed","reason":"catchup_timeout","nextHeight":43}
```

Stop consuming that subscription. This is an application message, not a WebSocket close frame. It can be lost on a broken connection; your durable checkpoint remains the recovery source. The example stops on terminal notifications, JSON-RPC errors, and processing failures so you can inspect the cause.



## Handle an expired cursor

At attach, a height below `max(0, tip - 42428)` is rejected with JSON-RPC error `-32009`, message `below_window`. No records are delivered for that rejected request.

The serve window is 42,428 blocks, about 24 hours at about 2 seconds per block. Store retention is about 7 days, but clients can only request within the serve window. History starts when the archive started; neither genesis replay nor any depth beyond the window is promised. Even within the window, unavailable historical records terminate with `archive_error`.

On `below_window`, restore application state from another source or explicitly accept the missing interval and start a new tip subscription. For the example, using a new output directory makes that reset explicit and preserves the old checkpoint. Do not automatically replace an expired cursor with tip.



## Keep up with delivery

On the hosted Futurenet the live send plus ACK deadline is 60 seconds. A full live queue or expired live deadline demotes the subscriber to archive catch-up. An outstanding operation gets one additional 60-second catch-up deadline before `catchup_timeout`. Growing lag over the 120-second progress window terminates with `catchup_falling_behind`.

Blocks can be up to about 16 MB (about 32 MB of hex). A client must sustain roughly the chain’s record rate to keep up during a large-block burst; one that cannot falls behind and is closed with `catchup_falling_behind`, and can resume from its saved cursor.

Keep processing bounded and inspect [API errors, limits, and close reasons](pages/reference/firehose.md) before retrying. `firehose_stats` reports active subscribers and process counters; sent counts measure transport enqueue, not completed application work.

Operators can also run `hog-firehose-store` and `hog-firehose-serve` themselves.

---

## Faucet

Source: <https://thruput.network/docs/tools/faucet/>

Request native test tokens for a Futurenet wallet and check the funding result.

Use the [hosted faucet](https://thruput-faucet.up.railway.app) to fund a Futurenet wallet or contract address with native test tokens. These tokens have no monetary value.



## Request funds in the browser

1. Copy your public address from the [Wallet Extension](pages/tools/wallet-extension.md) or your [CLI wallet](pages/cli/wallets.md#create-a-key-and-wallet).
2. Open the [faucet](https://thruput-faucet.up.railway.app).
3. Paste your wallet address into **Wallet address**.
4. Click **Request airdrop**. The faucet sets the amount.
5. Wait for the **Sent … native tokens** notice, then check the receiving wallet’s balance. The notice also shows a shortened transaction hash.

If the page cannot connect, it shows **Faucet unavailable** and disables the request. Click **Retry** to connect again.

The faucet needs only a public address. Amounts, cooldowns, and quotas depend on the deployment; follow the values and errors shown by the service.



## CLI

With a Futurenet wallet already configured:

```bash
thruput airdrop --profile futurenet
thruput balance --profile futurenet
```

The faucet selects the amount, so omit `--amount` for remote requests. For initial key and wallet setup, follow the [CLI quickstart](pages/get-started/cli.md).

The CLI retains a nonce for a pending remote airdrop. If the outcome is unclear, rerun the same command to resume that request. A timeout does not prove that funding failed.



## TypeScript

Use the client or wallet’s `requestAirdrop` action. [Script accounts](pages/typescript/accounts.md) covers funding and retaining a request nonce for recovery. The client must use a cluster with airdrop support.

For Localnet, use your local node’s airdrop through the [CLI](pages/cli/local-node.md) or SDK rather than the hosted Futurenet faucet.



## If funding does not appear

- Check that the recipient address and wallet network match the request.
- Follow the displayed cooldown before requesting again.
- If you have a transaction hash, inspect it in the [Explorer](pages/tools/block-explorer.md). A committed transaction must also have a successful execution result.
- If the browser lost its connection, check the balance before starting a new request.

---

## Explorer

Source: <https://thruput.network/docs/tools/block-explorer/>

Use the Futurenet explorer to look up transactions, inspect receipts and events, and check address activity.

Use the [Futurenet explorer](https://explorer.thruput.network/) to look up transactions, inspect receipts and events, and check address balances and recent activity. Sign in if prompted.



## Look Up a Transaction or Address

1. Open the [Futurenet explorer](https://explorer.thruput.network/).
2. Paste the transaction hash or address into the search field.
3. Select **Search**.

The home page also lists recent native-token transfers. Select a transaction to inspect it, or follow an address link to view that address.



### Transactions

The transaction page shows:

- Transaction status and, once committed, block height and execution result.
- Receipt events, including decoded token transfers, mints, and burns where supported.
- Raw receipt data for debugging.

Events without a supported decoder appear as raw topics and data.



### Addresses and Tokens

The address page shows the native-token balance. For non-token addresses, it also shows recent transactions and sent or received native-token transfers. Recognized token contracts show token metadata and token transfer history. Other contracts can show their emitted events.

Address transaction history combines transactions whose root invocation targets the address with native-token transfer activity. It does not cover every nested invocation or every token transfer involving the address.



### Share a Result

Copy the page URL to share a transaction or address:

```text
https://explorer.thruput.network/tx/<transaction-hash>
https://explorer.thruput.network/address/<address>
```



## Inspect State Without an Explorer

Use the CLI for terminal workflows, local nodes, or when the explorer is unavailable:

```bash
thruput balance <wallet-or-address> --profile futurenet
thruput tx show <transaction-hash> --profile futurenet
thruput view <contract-or-alias> <method> --profile futurenet
thruput storage <contract-or-alias> 0x<32-byte-key> --profile futurenet
```

These commands use Futurenet. For a local node, use `--profile local` instead. The hosted explorer does not show your local node’s transactions.

Use the [JSON-RPC API](pages/reference/json-rpc-api.md) directly for receipts, status, address-rooted history, and event pagination.



## If a result is missing

Check the full hash or address and the network that produced it. Indexer-backed history can lag, so use `thruput tx show` for the original transaction before submitting another one. A pending or missing result does not prove failure.

---

## Wallet Extension

Source: <https://thruput.network/docs/tools/wallet-extension/>

Download and install the Thruput fork of Freighter in Chrome for Futurenet testing.

Use [Thruput Freighter](https://github.com/thruputchain/freighter), a fork of Stellar’s Freighter wallet with added Thruput support. Developer builds are available for Futurenet testing.



## Download and extract

1. Sign in to GitHub.
2. Open the [successful Run Tests builds](https://github.com/thruputchain/freighter/actions/workflows/runTests.yml?query=is%3Asuccess).
3. Open the newest run with a **thruput-freighter-dev-…** download in its **Artifacts** section.
4. Download the artifact ZIP and extract it.

Artifacts expire after 14 days. If no download is available, follow the source-build instructions in the [Freighter repository](https://github.com/thruputchain/freighter).

Keep the extracted folder in a stable location. Chrome loads the extension from the folder that directly contains `manifest.json`.



## Load it in Chrome

1. Open `chrome://extensions` in the address bar.
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select the extracted folder that directly contains `manifest.json`, not the ZIP or its parent folder.
5. Open the puzzle-piece menu beside Chrome’s address bar. Find **Thruput Freighter Dev** and click its pin button to keep it in the toolbar.

![Chrome's Extensions page with Developer mode enabled and the Load unpacked button](assets/images/wallet/wallet-install.png)

Open the extension from the toolbar and follow its setup prompts. Use a test wallet for development. To request native test tokens, copy your public address and use the [Futurenet faucet](pages/tools/faucet.md).



## Update the extension

Download and extract a newer build into the same folder. Click **Reload** on the extension’s card in `chrome://extensions`, then refresh any connected app tabs.



## If something does not work

| Symptom                          | Check                                                                                                 |
| -------------------------------- | ----------------------------------------------------------------------------------------------------- |
| No artifact download             | Sign in to GitHub and choose a successful run with an unexpired **thruput-freighter-dev-…** artifact. |
| Chrome cannot find the manifest  | Select the extracted folder that directly contains `manifest.json`.                                   |
| The app does not detect a wallet | Enable the extension, allow it on the site, and refresh the app tab.                                  |

For application integration, see the [TypeScript integration](pages/tools/wallet-integration.md) or [React wallet hooks](pages/react/wallets.md).

---

## JSON-RPC API

Source: <https://thruput.network/docs/reference/json-rpc-api/>

Project Thruput native JSON-RPC methods, wire types, and error codes for wire format 14.

| API property  | Value                                                                                                                                                                                            |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Wire format   | `14.x`. Tools `0.33.0` serves `14.0.0`; `14.1.0` adds `stated.maxTxGas` and the `gasLimitTooHigh` transaction detail                                                                             |
| Compatibility | Breaking wire changes increase the major version of `getVersionInfo.wireFormat`. Clients accept one major version and do not fall back                                                           |
| Schema        | [Generated OpenRPC specification](https://github.com/thruputchain/thruput-tools/blob/main/crates/json-rpc/open-rpc-spec/snapshots/thruput-spec.json) for exact method signatures and field types |
| Transport     | JSON-RPC 2.0 over HTTP. For the node topology, see [Networking](pages/how-it-works/networking.md)                                                                                                |



## Request Format

```json
{
  "jsonrpc": "2.0",
  "method": "getTransactionStatus",
  "params": { "transactionHash": "<base58 transaction hash>" },
  "id": 1
}
```

| Request rule         | Contract                                                                                                                                    |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| Parameter shape      | One named-parameter object. Positional arrays, wrapped objects, and unknown fields return `-32602`                                          |
| No-parameter methods | Accept `{}`, `[]`, `null`, or omitted `params`; clients send `{}`                                                                           |
| Method names         | Unprefixed core names. Optional groups use `faucet_` and `dev_` prefixes                                                                    |
| Discovery            | `getVersionInfo.supportedMethods` lists the methods that this endpoint registered. An unlisted method returns `Method not found` (`-32601`) |
| Field names          | camelCase in requests, responses, and error data                                                                                            |



## Value Encoding

| Value                                                                                                                                                     | JSON encoding                                                                                                                                                                        |
| --------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Addresses, transaction hashes, block and network hashes, config hashes, public keys, public-key hashes, validator IDs                                     | Unprefixed, case-sensitive base58 (Bitcoin/Solana alphabet). Must decode to exactly 32 bytes. `0x` hex is rejected                                                                   |
| Signed transactions, calldata, entrypoints, return and abort data, storage keys and bytes, event topics and data, cursors, client nonces, upgrade entries | `0x`-prefixed lowercase hex with an even number of digits                                                                                                                            |
| 64-bit and wider integers: heights, nanosecond timestamps, gas, counts, balances, amounts                                                                 | Canonical decimal string, including `"0"`                                                                                                                                            |
| Smaller bounded integers: protocol versions, page limits, event sequence numbers, key IDs, weights                                                        | JSON number                                                                                                                                                                          |
| Encoding choice                                                                                                                                           | By field meaning, not byte length. A raw event topic stays hex even when its decoded value is an address or hash                                                                     |
| Decimal string rejects                                                                                                                                    | Numeric JSON, leading zeros, `+`, negative zero, whitespace, fractions, exponents, overflow                                                                                          |
| Binary payloads                                                                                                                                           | Transactions use classic XDR; contract arguments and return values use CXS. See [XDR Protocol](pages/reference/xdr-protocol.md)                                                      |
| Tagged unions                                                                                                                                             | Discriminator field such as `status`, `result`, `kind`, or `attemptStatus`. Accept unknown tag values (for example `other` or `unknown`) without treating them as success or absence |



## JSON-RPC Arrays

| Property        | Contract                                                                                                                               |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Maximum entries | 1,000 per array on the gateway and local node                                                                                          |
| Correlation     | Match responses by request ID; response order is not execution order                                                                   |
| Errors          | Per-entry RPC errors remain independent; transport failures can affect the shared exchange                                             |
| Guarantees      | No shared snapshot, ordering, or atomicity between independent requests                                                                |
| Other limits    | Request and response byte limits and concurrency settings are separate                                                                 |
| Client defaults | Opt-in HTTP batching uses 100 entries and a 0ms scheduling window; see [client transport](pages/typescript/transport.md#http-batching) |



## Discovery Methods



### `getVersionInfo`

**Parameters:** None.

| Response field                                                            | Contract                                                                              |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| `wireFormat`                                                              | Wire-format SemVer, for example `"14.1.0"`. The only field that selects client codecs |
| `supportedMethods`                                                        | Sorted names of the methods registered on this endpoint                               |
| `implementation`                                                          | Diagnostic implementation version                                                     |
| `commitHash`, `platformVersion`, `releaseVersion`, `bundleManifestDigest` | Optional diagnostics; omitted when unavailable                                        |



### `getNetworkInfo`

**Parameters:** None.

```json
{ "networkHash": "<base58, 32 bytes>" }
```

`networkHash` is the signing network identity. It is part of every transaction signature preimage. Compare it with the expected network before signing. See [Authorization](pages/how-it-works/authorization.md).



### `getServerLimits`

**Parameters:** None. Answered without contacting a backend.

| Response field               | Contract                                                                                                                          |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| `maxSimulationGas`           | Maximum simulation `gasLimit`, and the default when `gasLimit` is omitted; decimal string                                         |
| `maxSimulationCalldataBytes` | Maximum simulation calldata size in bytes; decimal string                                                                         |
| `maxEventsPerPage`           | Maximum `getEvents` `limit`; JSON number                                                                                          |
| `maxTransactionsPerPage`     | Maximum transaction-page `limit`; JSON number                                                                                     |
| `maxCursorBytes`             | Maximum decoded cursor size in bytes; decimal string                                                                              |
| `simulationBatch`            | Optional: `maxInvocations`, `maxCalldataBytes`, `maxBackendResponseBytes` (JSON numbers), `maxGas`, `timeoutMs` (decimal strings) |

These are operator settings, not consensus parameters. Values can differ between endpoints on the same chain.



### `getChainTip`

**Parameters:** None.

```json
{ "blockHeight": "42", "blockHash": "<base58 block hash>" }
```



### `getChainConfig`

**Parameters:** None.

| Response field              | Contract                                                                                                                                                                                                                                                    |
| --------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `stated`                    | Explicit configuration values. A missing field is unspecified, not zero                                                                                                                                                                                     |
| `stated.max*`               | `maxSha256Buffers`, `maxCrossInvokeDepth`, `maxNewContractsPerTx`, `maxBytestringLen`, `maxContractSizeBytes`, `maxSavepointDepth`, `maxAuthTokenDepth`, `maxRv32CodeBytes`, `maxRv32MemoryBytes`: JSON numbers. `maxTxGas` (wire `14.1.0`): decimal string |
| `execution`                 | Optional authoritative reading. A missing `execution` means the backend cannot supply it; do not infer zero prices                                                                                                                                          |
| `execution.observedTip`     | `blockHeight` and `blockHash` that the rules were read with                                                                                                                                                                                                 |
| `execution.configHash`      | Base58 configuration and storage-model commitment                                                                                                                                                                                                           |
| `execution.effectiveLimits` | Runtime-resolved limits, same fields as `stated`                                                                                                                                                                                                            |
| `execution.storageCosts`    | `baseDataItemCost`, `bytestringCostPerByte`, `baseContractDeploymentCost`, `contractDeploymentCostPerByte`, `authPerKeyCost`, `rcqCostPerEntry`, `replayCacheCostPerEntry`, `balanceCost`: native-token base units as decimal strings                       |

Later transactions can execute under newer rules. Usage: [Estimate deployment funding](pages/cli/deploy-and-call.md#estimate-deployment-funding).



## Transaction Methods



### `sendTransaction`

| Parameter           | Type | Description                             |
| ------------------- | ---- | --------------------------------------- |
| `signedTransaction` | hex  | `0x` hex of the `SignedTransaction` XDR |

```json
{ "transactionHash": "<base58 transaction hash>", "admission": "accepted" }
```

| Case                 | Contract                                                                                                                                                                                                                     |
| -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Success              | Scheduler admission only, not commitment or execution                                                                                                                                                                        |
| `transactionHash`    | `sha256` of the inner `Transaction` XDR; excludes signatures                                                                                                                                                                 |
| `-32000`             | Invalid encoding, envelope, size, or executor bound. `data.detail.reason` can be `tooManyContracts`, `contractTooLarge`, `duplicateContract`, `rv32MemoryTooLarge`, `rv32CodeTooLarge`, or `gasLimitTooHigh` (wire `14.1.0`) |
| `-32001`             | `data.reason` is `expired` (`blockExpiryHeight` at or below the tip) or `authenticationRejected`                                                                                                                             |
| `data.admission`     | `notAttempted`, `rejected`, or `unknown` for this attempt                                                                                                                                                                    |
| `-32051` or `-32050` | Admission can be unknown. Query `getTransactionStatus` with the hash before you prepare a replacement                                                                                                                        |
| `-32053`             | Retryable refusal; optional `data.retryAfterMs`                                                                                                                                                                              |



### `getTransactionStatus`

| Parameter         | Type   | Description      |
| ----------------- | ------ | ---------------- |
| `transactionHash` | base58 | Transaction hash |

| `status`        | Fields and meaning                                                                                                                                                                                                                                                                                                                                                                                                                          |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pending`       | In the scheduler, not committed. Optional `recentFailure`                                                                                                                                                                                                                                                                                                                                                                                   |
| `committed`     | `blockHeight` of the block that included it, including `"0"`                                                                                                                                                                                                                                                                                                                                                                                |
| `retry`         | Retained scheduler processing failure; `error`; optional `recentFailure`. Another submission of the same signed transaction may succeed while valid. This status does not promise automatic requeue                                                                                                                                                                                                                                         |
| `dropped`       | Retained scheduler failure; `error`; optional `recentFailure`. For insufficient native tokens (`SchedulerErrorInsufficientNativeTokens`), fund the sender before resubmitting the same signed transaction while valid. For errors that require changing the transaction, resolve the original outcome before signing a replacement. See [Resubmission and replacement](pages/typescript/transaction-status.md#resubmission-and-replacement) |
| `recentFailure` | Scheduler miss with a recent indexed failure: `attemptBlockHeight`, `cause`                                                                                                                                                                                                                                                                                                                                                                 |
| `unknown`       | Both the scheduler and committed history reported a miss                                                                                                                                                                                                                                                                                                                                                                                    |
| `other`         | Status from a newer server version                                                                                                                                                                                                                                                                                                                                                                                                          |

| Field           | Contract                                                                                                            |
| --------------- | ------------------------------------------------------------------------------------------------------------------- |
| `error.source`  | `auth`, `scheduler`, `executor`, or `other`                                                                         |
| `error.code`    | Signed 32-bit JSON number from `AuthErrorCode`, `SchedulerErrorCode`, or `ExecResult`                               |
| `recentFailure` | Advisory `{ attemptBlockHeight, cause }`. It can describe a different attempt. It does not authorize resubmission   |
| `cause.kind`    | `dbConflict` with `conflict { address, key, code }`, `contractRejected` with `contractIndex` and `code`, or `other` |

Indexed commitment takes priority. No negative status proves nonexecution, and a failed backend lookup returns an error, not `unknown`. Exclusion from one proposal does not guarantee a `retry` status. Usage: [Handle scheduler processing errors](pages/typescript/transaction-status.md#handle-scheduler-processing-errors) and [Resubmission and replacement](pages/typescript/transaction-status.md#resubmission-and-replacement).



### `getTransactionReceipt`

| Parameter         | Type   | Description      |
| ----------------- | ------ | ---------------- |
| `transactionHash` | base58 | Transaction hash |

**Returns:** `TransactionReceipt`, or `null` if no receipt is available.

```json
{
  "transactionHash": "<base58 transaction hash>",
  "blockHeight": "12345",
  "execution": { "result": "return", "returnData": "0x42" },
  "events": [],
  "gasUsed": "1500"
}
```

| `execution.result`      | Meaning                                                       |
| ----------------------- | ------------------------------------------------------------- |
| `return`                | Root call returned; `returnData` is required, possibly `"0x"` |
| `abort`                 | Root call aborted; `abortData` is required, possibly `"0x"`   |
| `fault`                 | Deterministic execution fault                                 |
| `nonDeterministicError` | Proposal-time storage conflict or race                        |
| `failedGasSponsorship`  | Gas sponsorship failed                                        |
| `other`                 | Result from a newer server version                            |

A receipt proves commitment. Only `execution.result: "return"` proves successful execution. `gasUsed` is metered work, not a fee: gas has no token cost and no refund.



## State Methods



### `getBalance`

| Parameter | Type   | Description                 |
| --------- | ------ | --------------------------- |
| `address` | base58 | Account or contract address |

```json
{ "address": "<base58 address>", "stateBlockHeight": "4567", "rawBalance": "1000000000" }
```

`rawBalance` is free native-token base units as a decimal string. Storage collateral is separate.



### `getStorage`

| Parameter | Type   | Description            |
| --------- | ------ | ---------------------- |
| `address` | base58 | Contract address       |
| `key`     | hex    | Serialized storage key |

```json
{ "stateBlockHeight": "4567", "item": { "kind": "nonnegativeInt", "value": "1000000000" } }
```

| `item.kind`                                        | Fields                                            |
| -------------------------------------------------- | ------------------------------------------------- |
| `nonnegativeInt`                                   | `value`: decimal string                           |
| `bytestring`                                       | `bytes`: hex                                      |
| `deployedContract`                                 | `hash` (base58), `size`, `contractType`           |
| `authData`, `retrocausalQueue`, `replayCacheEntry` | None                                              |
| `unknown`                                          | `typeId` for a storage kind newer than the client |

`item` is `null` when the key has no value. `stateBlockHeight` names the snapshot for both cases.



### `getRegisteredAuth`

| Parameter | Type   | Description     |
| --------- | ------ | --------------- |
| `address` | base58 | Account address |

| Response field                | Contract                                                                                                                        |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `address`, `stateBlockHeight` | Echoed address and snapshot height                                                                                              |
| `configuration`               | `null`, or `{ signers, requiredWeight }`                                                                                        |
| `signers[]`                   | `keyId`, `maxWeight`, and `publicKey`: `{ "scheme": "ed25519", "key": "<base58>" }` or `{ "scheme": "unknown", "schemeId": n }` |

`null` does not prove that the account is absent. It does not recover the key of a pubkey-derived account.



## Simulation Methods



### `simulateInvocation`

| Parameter             | Type           | Description                                                                   |
| --------------------- | -------------- | ----------------------------------------------------------------------------- |
| `address`             | base58         | Contract address                                                              |
| `entrypoint`          | hex            | 8-byte entrypoint ID                                                          |
| `calldata`            | hex            | Call input                                                                    |
| `caller`              | base58         | Optional parent contract                                                      |
| `assumedAuth`         | object         | Optional assumed claim; see below                                             |
| `gasLimit`            | decimal string | Optional, positive, at most `maxSimulationGas`; omission selects that maximum |
| `minStateBlockHeight` | decimal string | Optional freshness floor; not a historical selector                           |

| `assumedAuth.kind` | Fields                                                                           |
| ------------------ | -------------------------------------------------------------------------------- |
| `sourceAddress`    | `allowedKeys`, `requiredWeight`: JSON numbers                                    |
| `pubkeySignature`  | `pubkeyHash` (base58), `accountNonce` (decimal string; account derivation nonce) |

No signature is verified. Contract checks still run, and writes never commit. Omission supplies a zero-key, zero-weight source-address claim.

| Response field or case               | Contract                                                                                                 |
| ------------------------------------ | -------------------------------------------------------------------------------------------------------- |
| `stateBlockHeight`                   | Committed state height H. Execution uses context H+1                                                     |
| `output`                             | `{ "result": "return", "returnData" }`, `{ "result": "abort", "abortData" }`, or `{ "result": "fault" }` |
| `events`                             | Events emitted during the simulation                                                                     |
| `gasUsed`                            | Decimal string. Equals the selected limit on an out-of-gas fault                                         |
| Snapshot below `minStateBlockHeight` | `-32012` with `requestedStateBlockHeight` and `observedStateBlockHeight`; no wait or refresh             |



### `simulateInvocations`

| Parameter             | Contract                                                                                                               |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `invocations`         | Nonempty array. Each entry takes `address`, `entrypoint`, `calldata`, and optional `caller`, `assumedAuth`, `gasLimit` |
| `minStateBlockHeight` | Optional floor for the whole group. A per-entry floor is rejected                                                      |

| Response field or case       | Contract                                                                           |
| ---------------------------- | ---------------------------------------------------------------------------------- |
| `stateBlockHeight`           | One snapshot height for all invocations                                            |
| `results`                    | One `{ output, events, gasUsed }` per invocation, in input order                   |
| Isolation                    | Invocations do not see each other’s simulated writes                               |
| Abort or fault               | Per-invocation outcome, not a group failure                                        |
| Limits                       | `getServerLimits.simulationBatch` plus per-call limits; violations return `-32602` |
| Snapshot failure or deadline | The group fails; no partial results. Backend work can outlive the deadline         |

Usage: [Read related values from one snapshot](pages/typescript/reads.md#read-related-values-from-one-snapshot).



## History Methods



### `getEvents`

| Parameter             | Type         | Description                                                                                                                                  |
| --------------------- | ------------ | -------------------------------------------------------------------------------------------------------------------------------------------- |
| `filters`             | array        | 1 to 5 filters. OR across filters                                                                                                            |
| `filters[].addresses` | base58 array | 1 to 5 contract addresses                                                                                                                    |
| `filters[].topics`    | object       | Optional `topic0`, `topic1`, `topic2`: up to 16 32-byte hex values each. AND across positions, OR within one. Omitted or empty is a wildcard |
| `start`               | object       | First page only; see [Pagination](pages/reference/json-rpc-api.md#pagination)                                                                |
| `cursor`              | hex          | Later pages only                                                                                                                             |
| `limit`               | number       | Optional page size                                                                                                                           |

**Returns:** `EventPage`.

| Field                                                  | Contract                                                        |
| ------------------------------------------------------ | --------------------------------------------------------------- |
| `events[]`                                             | `{ transactionHash, blockHeight, sequenceNumber, event }`       |
| `event`                                                | `address` (base58), `topics` (up to 3 hex values), `data` (hex) |
| `nextCursor`                                           | Hex, or `null` when the walk is complete                        |
| `oldestIndexedBlockHeight`, `latestIndexedBlockHeight` | Serving bounds as decimal strings; not checkpoints              |

Event identity is `transactionHash` plus `sequenceNumber`. Usage: [Read events](pages/typescript/events.md#query-events).



### `getTransactionsByRootAddress`

| Parameter                  | Type   | Description                                                  |
| -------------------------- | ------ | ------------------------------------------------------------ |
| `address`                  | base58 | Root invocation target                                       |
| `start`, `cursor`, `limit` |        | See [Pagination](pages/reference/json-rpc-api.md#pagination) |

**Returns:** `TransactionRefPage` with `transactions[]` of `{ transactionHash, blockHeight }`, plus `nextCursor` and the serving bounds. Internal calls and incoming transfers do not match. Hydrate a reference with `getTransactionReceipt`.



### `getBlockByHeight`

| Parameter     | Type           | Description              |
| ------------- | -------------- | ------------------------ |
| `blockHeight` | decimal string | Nonnegative block height |

**Returns:** `BlockInfo`, or `null` outside indexed coverage (including genesis).

```json
{
  "blockHash": "<base58>",
  "protocol": 1,
  "networkHash": "<base58>",
  "configHash": "<base58>",
  "proposer": "<base58 validator ID>",
  "blockTimepoint": "1791200000000000001",
  "blockHeight": "42",
  "txsHash": "<base58>",
  "storageHash": "<base58>",
  "eventsHash": "<base58>",
  "prevBlockHash": "<base58>",
  "proposalTxsHash": "<base58>",
  "upgrades": ["0x..."]
}
```

An unavailable or corrupt index returns an error, not `null`. The index can lag behind `getChainTip`.



### `getTransactionsByBlock`

| Parameter         | Type           | Description                                                                |
| ----------------- | -------------- | -------------------------------------------------------------------------- |
| `blockHeight`     | decimal string | Committed block height                                                     |
| `start`           | object         | First page only: `{ "order": "ascending" }` or `{ "order": "descending" }` |
| `cursor`, `limit` |                | See [Pagination](pages/reference/json-rpc-api.md#pagination)               |

**Returns:** `TransactionRefPage`. References are ordered by unsigned transaction-hash bytes, not execution order. An empty page does not prove that the block exists; use `getBlockByHeight`.



## Pagination

| Rule                      | Contract                                                                                                                                                                                                    |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| First page                | Send `start` and no `cursor`                                                                                                                                                                                |
| `start` for range history | `{ "order": "ascending", "anchor": { "kind": "atBeginning" } }`, `{ "order": "descending", "anchor": { "kind": "atEnd" } }`, or either order with `{ "kind": "atHeight", "blockHeight": "42" }` (inclusive) |
| Later pages               | Send the returned `cursor` verbatim with the same query fields and no `start`. The cursor owns direction and its snapshot bound                                                                             |
| `start` and `cursor`      | Exactly one is required                                                                                                                                                                                     |
| `limit`                   | Omission selects the smaller of 50 and the page cap. `0` or values above the cap return `-32602`. The cap is at most 200                                                                                    |
| Completion                | `nextCursor: null`. An empty page with a non-null cursor is not the end                                                                                                                                     |
| Invalid cursor            | Empty or oversized cursors return `-32602`. Rejected tokens return `-32602` with `data.kind: "invalidCursor"` and `reason` `malformed`, `unsupportedVersion`, or `queryMismatch`                            |
| Retention                 | `-32013` with `reason: "outsideRetention"` and optional indexed bounds                                                                                                                                      |
| Subscriptions             | A walk does not follow new blocks. Start a new walk to check for new activity                                                                                                                               |

For an application pattern, see [Resume without missing events](pages/typescript/events.md#resume-without-missing-events).



## Optional Methods

These methods appear in `supportedMethods` only when the endpoint configures them.



### `faucet_requestAirdrop`

| Parameter     | Type   | Description                        |
| ------------- | ------ | ---------------------------------- |
| `recipient`   | base58 | Recipient address                  |
| `clientNonce` | hex    | Caller-selected 1-to-32-byte nonce |

| `attemptStatus` | Fields                                                                                                        |
| --------------- | ------------------------------------------------------------------------------------------------------------- |
| `pending`       | `recipient`, `rawAmount`, `retryAfterSeconds`, optional `transactionHash`                                     |
| `succeeded`     | `recipient`, `rawAmount`, `transactionHash`, `blockHeight`, `execution: { "result": "return", "returnData" }` |

Each call advances one attempt bound to `recipient` and `clientNonce`. Do not repeat it automatically. Poll a returned `transactionHash` with `getTransactionStatus` and `getTransactionReceipt`. `pending` does not prove admission. `-32030` means the faucet stopped the attempt; it does not prove nonexecution.



### `dev_fundAccount`

Local node only.

| Parameter     | Type           | Description                   |
| ------------- | -------------- | ----------------------------- |
| `recipient`   | base58         | Recipient address             |
| `rawAmount`   | decimal string | Positive amount in base units |
| `clientNonce` | hex            | 1-to-32-byte nonce            |
| `faucet`      | base58         | Expected local faucet address |

**Returns:** `{ recipient, rawAmount, transactionHash, signedTransaction }`. Check the receipt before you treat the transfer as successful. `-32031` means signed evidence exists without a resolved outcome. Retry with the same request.



### `dev_getPendingTransactionCount`

Local node only. **Parameters:** None. **Returns:** `{ "count": "0" }`, the local scheduler’s pending count as a decimal string.



## Method Availability

| Methods                                                                                                            | Registered when the endpoint has     |
| ------------------------------------------------------------------------------------------------------------------ | ------------------------------------ |
| `getVersionInfo`, `getNetworkInfo`, `getServerLimits`                                                              | Always                               |
| `sendTransaction`                                                                                                  | Scheduler                            |
| `getTransactionStatus`                                                                                             | Scheduler and indexer                |
| `getTransactionReceipt`, `getEvents`, `getTransactionsByRootAddress`, `getBlockByHeight`, `getTransactionsByBlock` | Indexer                              |
| `getChainTip`, `getChainConfig`, `getBalance`, `getStorage`, `getRegisteredAuth`                                   | State database                       |
| `simulateInvocation`, `simulateInvocations`                                                                        | Simulation backend                   |
| `faucet_requestAirdrop`                                                                                            | Hosted faucet, or local node funding |
| `dev_fundAccount`                                                                                                  | Local node funding                   |
| `dev_getPendingTransactionCount`                                                                                   | Local node only                      |

A configured backend that is down returns a backend error. It does not remove the method.



## Error Codes

Standard JSON-RPC 2.0 errors also apply, including `-32601` for unregistered methods. Error `data` carries a `kind` discriminator in camelCase.

| Code     | `data.kind`                      | Meaning                                                                                |
| -------- | -------------------------------- | -------------------------------------------------------------------------------------- |
| `-32602` | `invalidParams`, `invalidCursor` | Invalid named request or continuation token; optional `reason` and JSON-pointer `path` |
| `-32000` | `transactionInvalid`             | Invalid transaction framing, envelope, or executor bound                               |
| `-32001` | `transactionRejected`            | Expiry or scheduler authentication refusal for this attempt                            |
| `-32012` | `stateHeightUnavailable`         | Simulation snapshot below the requested floor                                          |
| `-32013` | `historyUnavailable`             | Required history cannot be served                                                      |
| `-32030` | `fundingAttemptStopped`          | Funding service stopped this attempt                                                   |
| `-32031` | `localFundingUnresolved`         | Local funding has signed evidence without a resolved outcome                           |
| `-32050` | `backendUnavailable`             | Required backend is unavailable                                                        |
| `-32051` | `backendTimeout`                 | Deadline exceeded; writes may have been dispatched                                     |
| `-32053` | `overloaded`                     | Temporary refusal; retry with backoff                                                  |
| `-32054` | `backendDataInvalid`             | Backend data cannot satisfy the method contract                                        |



## Client Libraries

| Language   | Package                                    | Wire selection                                                                                                      |
| ---------- | ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| TypeScript | `@thruputchain/client` `0.24`              | Calls `getVersionInfo` once at connect and requires major `14`. See [TypeScript SDK](pages/tools/typescript-sdk.md) |
| Rust       | `thruput-json-rpc-client` (`NativeClient`) | `thruput-client`’s `check_endpoint` requires major `14` and the methods you name                                    |



## Related Documentation

- [Networking](pages/how-it-works/networking.md)
- [Authorization](pages/how-it-works/authorization.md)
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md)
- [Storage Types](pages/reference/storage-types.md)

---

## Contract Spec

Source: <https://thruput.network/docs/reference/contract-spec/>

Canonical contract metadata, structured identities, methods, types, events, and exceptions.

For usage, see [TypeScript Bindings](pages/tools/typescript-bindings.md) and [Build a Counter](pages/tutorials/build-a-counter.md).



## Where the Spec Lives

| Artifact            | Purpose                                                                                                                  |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| `<crate>.spec.xdr`  | Canonical contract API, consumed by standalone TypeScript codegen                                                        |
| `<crate>.spec.json` | Human-readable rendering for inspection; not the codegen input                                                           |
| `<crate>.rv32a`     | Deployable RV32 artifact                                                                                                 |
| Generation          | SDK macros emit fragments; build canonicalizes, sorts, validates, and writes sidecars under `target/thruput/` by default |



## Top-Level Structure

| JSON key     | Contents                                                          |
| ------------ | ----------------------------------------------------------------- |
| `format`     | `gh_contract_spec_v1`, the inspection-rendering tag               |
| `interfaces` | Exported interfaces, methods, and declared exceptions             |
| `type_defs`  | Reachable named type layouts                                      |
| `events`     | Declared event identities, signatures, topics, and payload fields |



## Structured Identity

| Identity field        | Meaning                                                                                                             |
| --------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `crate`               | Declaring crate in the JSON rendering (`crate_name` in the canonical type)                                          |
| `major`               | Compatibility major, such as `1`, `0.1`, or `0.0.2`                                                                 |
| `module_path`         | Module within that crate                                                                                            |
| `declared`            | Declaration name                                                                                                    |
| Used by               | Named type references, type definitions, and event names                                                            |
| TypeScript projection | Crate, compatibility-major namespace, module path, then declaration; interface methods use interface name and major |

The compatibility major is the leftmost non-zero SemVer component. Use canonical IDs and generated descriptors; short declaration names are not globally unique.



## Interfaces

| Field                | Meaning                                                                                                                                                                                                                               |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `name`               | Interface name from the trait, inherent self type, or explicit override                                                                                                                                                               |
| `version`            | Full interface version                                                                                                                                                                                                                |
| `throws`             | Declared exception selectors and types                                                                                                                                                                                                |
| `methods`            | Exported methods in canonical order                                                                                                                                                                                                   |
| Method `name`        | ABI name                                                                                                                                                                                                                              |
| Method `args`        | Ordered fields with `name` and `type`                                                                                                                                                                                                 |
| Method `return_type` | Contract type of the result                                                                                                                                                                                                           |
| Entrypoint ID        | Derived from interface name, compatibility major, and method name: `SHA256("<name>::<major>::<method>")[0..8]`. Not a JSON field                                                                                                      |
| Method `effect`      | Optional author-declared effect: `pure`, `readOnly`, or `stateChanging`, set with `#[contract(effect = "...")]`. Omitted when the method has no declaration. It is not a runtime guarantee. Do not assume read-only when it is absent |



## Type Encoding

| `kind`                                                     | Other JSON fields    | Meaning                                     |
| ---------------------------------------------------------- | -------------------- | ------------------------------------------- |
| `void`, `bool`, `u8`                                       | None                 | Unit, boolean, or byte                      |
| `u32`, `i32`, `u64`, `i64`, `u128`, `i128`, `u256`, `i256` | None                 | Corresponding integer                       |
| `string`, `bytes`, `address`                               | None                 | String, variable bytes, or contract address |
| `option`                                                   | `inner`              | Optional value                              |
| `vec`                                                      | `element`, `max_len` | Variable-length sequence                    |
| `array`                                                    | `element`, `len`     | Fixed-length sequence                       |
| `tuple`                                                    | `items`              | Ordered element types                       |
| `named`                                                    | `name`               | Structured identity of a named type         |
| `signed_token`                                             | `preimage`           | Payload type, or null when erased           |

Contract arguments, results, and exception payloads use CXS. The spec sidecar uses its canonical XDR encoding. JSON is the inspection projection, not either binary encoding.



## Type Definitions

| Kind                | Fields beyond structured `name`                      |
| ------------------- | ---------------------------------------------------- |
| `struct`            | `fields`, each with name/type                        |
| `enum`              | `variants`, each with name/value                     |
| `union`             | `cases`, each with name, discriminant, and case_type |
| Union case `void`   | No payload                                           |
| Union case `tuple`  | `items`                                              |
| Union case `struct` | `fields`                                             |



## Events

| Field       | Meaning                                                                                        |
| ----------- | ---------------------------------------------------------------------------------------------- |
| `name`      | Structured event identity                                                                      |
| `signature` | 32-byte event signature rendered as hex; topic 0 for derived events                            |
| `topics`    | User topic fields and their types                                                              |
| `fields`    | CXS payload fields and their types                                                             |
| Limits      | At most three topics including signature; 1,024 bytes for topics plus payload                  |
| Discovery   | Events must be declared by the interface or explicitly exported through supported SDK metadata |

Use the generated signature rather than copying a literal from another contract. See [Events](pages/contracts/events.md) for emission and [Read events](pages/typescript/events.md) for filtering and restart.



## Errors

| Field or case        | Meaning                                                                                  |
| -------------------- | ---------------------------------------------------------------------------------------- |
| Exception `selector` | Hex rendering of its 64-bit selector                                                     |
| Exception `type`     | Payload type, potentially a structured named reference                                   |
| Known selector       | Generated decoder interprets the declared payload and rejects trailing bytes             |
| Unknown selector     | Client preserves selector and raw abort bytes                                            |
| Runtime fault        | May have no contract exception payload; do not infer a child ABI from root failure bytes |



## Related Documentation

- [SDK Macros](pages/reference/sdk-macros.md)
- [TypeScript Bindings](pages/tools/typescript-bindings.md)
- [XDR Protocol](pages/reference/xdr-protocol.md)

---

## XDR Protocol

Source: <https://thruput.network/docs/reference/xdr-protocol/>

Encoding boundaries and source definitions for the Project Thruput protocol.



## Encodings

| Surface                                                                      | Encoding                                                                                    | Reference                                                                                                    |
| ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `Transaction`, `SignedTransaction`, contract spec sidecars                   | Classic XDR                                                                                 | Protocol definitions below                                                                                   |
| Contract arguments, return values, exceptions, typed storage, event payloads | CXS, the compact encoding used by the SDK                                                   | [Contract Spec](pages/reference/contract-spec.md), [TypeScript Bindings](pages/tools/typescript-bindings.md) |
| Transaction signing preimage                                                 | CXS domain separator, raw network hash, then classic XDR transaction                        | [Authorization](pages/how-it-works/authorization.md)                                                         |
| Public JSON-RPC requests and responses                                       | JSON, with base58 identifiers, `0x` hex byte fields, and decimal strings for large integers | [JSON-RPC API](pages/reference/json-rpc-api.md)                                                              |

The Rust traits retain the names `ReadXDR` and `WriteXDR` for both encodings. Use generated SDK clients and TypeScript bindings for contract payloads; a classic XDR encoder produces different bytes.



## Source Definitions

| Source baseline            | Value                  |
| -------------------------- | ---------------------- |
| Rust protocol package      | `thruput-xdr` `0.61.0` |
| Embedded protocol revision | `hogp/6705996afff00a0` |

| Definition                                                                                                                        | Types                                                                |
| --------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| [transaction.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/transaction.x)     | `Invocation`, `Transaction`, `SignedTransaction`, invocation outputs |
| [types.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/types.x)                 | Addresses, hashes, signatures, protocol scalar types                 |
| [storage_item.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/storage_item.x)   | Storage items and deltas                                             |
| [header.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/header.x)               | Proposal header                                                      |
| [consensus.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/consensus.x)         | Consensus values                                                     |
| [contract_spec.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/contract_spec.x) | Contract types, methods, events, and interface metadata              |

---

## Firehose API

Source: <https://thruput.network/docs/reference/firehose/>

Hosted Futurenet WebSocket subscriptions for committed block records, acknowledgements, and resumable replay.

| Surface                   | Contract                                                                                 |
| ------------------------- | ---------------------------------------------------------------------------------------- |
| Hosted Futurenet endpoint | `wss://firehose.thruput.network`                                                         |
| Transport                 | JSON-RPC 2.0 over WebSocket with TLS. Browsers connect directly without a CORS preflight |
| Access                    | No authentication. Public chain data. Experimental, no SLA                               |
| Usage                     | [Consume the Firehose](pages/guides/consume-the-firehose.md)                             |
| Scope                     | Separate from the JSON-RPC gateway                                                       |



## Methods

| Request convention | Value                                         |
| ------------------ | --------------------------------------------- |
| Protocol           | JSON-RPC 2.0 on the same WebSocket connection |
| Parameters         | Positional arrays                             |

| Method                 | `params`                                               | Result                                                                                                                                          |
| ---------------------- | ------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `firehose_subscribe`   | `[{"from":"height","height":N}]` or `[{"from":"tip"}]` | Transport subscription ID, used for unsubscribe and notification routing                                                                        |
| `firehose_unsubscribe` | `[subscriptionId]`                                     | Removes the transport subscription                                                                                                              |
| `firehose_ack`         | `[subscriberId,height]`                                | `null`. Must acknowledge this connection’s outstanding block; wrong heights, duplicate ACKs, and unknown or foreign subscriber IDs are rejected |
| `firehose_stats`       | `[]`                                                   | Process totals and active subscriber details below                                                                                              |

| Cursor                         | Behavior                                                                                                                                                        |
| ------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `{"from":"height","height":N}` | Inclusive replay from `N`, then follow publications. `0 <= N < 9223372036854775807`. Future heights wait; missing historical records close with `archive_error` |
| `{"from":"tip"}`               | Publications after registration only. Does not replay the current tip                                                                                           |
| JavaScript numbers             | Heights and subscriber IDs are JSON integers. Reject values outside the safe integer range in a client using `JSON.parse`                                       |



## Notifications

| Envelope field        | Value                                                        |
| --------------------- | ------------------------------------------------------------ |
| `jsonrpc`             | `"2.0"`                                                      |
| `method`              | `"firehose_block"` for both block and terminal notifications |
| `params.subscription` | Transport subscription ID, distinct from `subscriberId`      |
| `params.result`       | One of the following tagged payloads                         |

| Block payload field          | Type             | Meaning                                                                                                                      |
| ---------------------------- | ---------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `type`                       | string           | `"block"`                                                                                                                    |
| `subscriberId`               | integer          | Numeric application ID for ACKs on this connection                                                                           |
| `block.schemaVersion`        | integer          | Record format version. Currently `2`                                                                                         |
| `block.height`               | integer          | Committed height                                                                                                             |
| `block.consensusHash`        | base58 string    | Consensus hash contained in the record, not an independent trust anchor                                                      |
| `block.byteLength`           | integer          | Original XDR byte count, before hex or JSON framing                                                                          |
| `block.record`               | hex string       | Exact complete stored XDR record, including consensus value, event logs, and transaction bodies. Canonical `0x`-prefixed hex |
| `block.ingestedAtUnixMicros` | optional integer | Publication timestamp after durable append. Absent on archive reads; outside the commitment                                  |

| Terminal payload field | Type    | Meaning                                                                                            |
| ---------------------- | ------- | -------------------------------------------------------------------------------------------------- |
| `type`                 | string  | `"closed"`. Stop consuming this subscription                                                       |
| `reason`               | string  | Termination reason below                                                                           |
| `nextHeight`           | integer | Inclusive first unacknowledged height. May already have been processed locally if its ACK was lost |

| Close behavior | Contract                                                                                                                        |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Scope          | Application notification, not a WebSocket close frame; other subscriptions can continue                                         |
| Delivery       | Bounded 250 ms enqueue opportunity. A broken or blocked connection can lose this notification; retain a local durable cursor    |
| Ordering       | One outstanding block per subscription. ACK before the next block; heights are ordered without duplicates within a subscription |
| Reconnection   | No exactly-once guarantee across connections. Replay uncertain work idempotently                                                |



## Request errors

| Code / layer     | Message or reason                                                 | Meaning                                                                                                                 |
| ---------------- | ----------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| HTTP 429 (nginx) | Connection limit                                                  | More than 8 concurrent connections from a client IP                                                                     |
| `-32006`         | `Too many subscriptions on the connection`                        | One subscription already exists on this connection. Data: `"Exceeded max limit of 1"`. Existing subscription stays open |
| `-32009`         | `subscriber limit reached`                                        | Global subscriber cap reached                                                                                           |
| `-32009`         | `invalid height`                                                  | Height outside the accepted range                                                                                       |
| `-32009`         | `below_window`                                                    | Requested height below `max(0, tip - 42428)` at attach. No subscription accepted or records sent                        |
| `-32009`         | `subscriber IDs exhausted`                                        | Server cannot allocate another application subscriber ID                                                                |
| `-32009`         | `unknown subscriber`                                              | ACK names no active application subscriber                                                                              |
| `-32009`         | `acknowledgement must match this connection's outstanding height` | Wrong height, duplicate ACK, or ACK from another connection                                                             |



## Cursors and resume

| Rule              | Contract                                                                                                                                                                             |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Serve window      | New height requests must be within 42,428 blocks below tip (about 24 hours at about 2 seconds per block). Boundary and future heights are accepted                                   |
| Available history | Starts when the archive started. No catch-up from genesis or guaranteed historical depth. Store retention is about 7 days, but requests remain limited by the serve window           |
| Moving window     | Accepted subscriptions retain their cursors as the window advances, subject to delivery deadlines                                                                                    |
| Durable progress  | Persist application output and the inclusive replay height together before ACK. After a successful ACK response, persist the next height as the last acknowledged cursor’s successor |
| Uncertain ACK     | Keep the prior replay height if ACK delivery or checkpoint persistence is uncertain. Reapply idempotently; never resume from the last received height alone                          |
| Resume            | Subscribe with `{"from":"height","height":savedReplayHeight}`. A terminal `nextHeight` is the server’s first unacknowledged height, not proof of durable client processing           |
| Expired cursor    | `below_window` requires an explicit recovery decision: restore application state from another source or deliberately start a new tip subscription and accept the gap                 |



## Close Reasons

| Reason                   | Meaning                                                                                  |
| ------------------------ | ---------------------------------------------------------------------------------------- |
| `catchup_timeout`        | Archive-mode send/ACK deadline expired, including the extra deadline after live demotion |
| `catchup_falling_behind` | Archive lag increased across a progress window                                           |
| `archive_timeout`        | Archive read deadline expired                                                            |
| `archive_error`          | Archive record could not be read, including missing history                              |
| `archive_corrupt`        | Record decoding or commitment verification failed                                        |
| `archive_gap`            | Decoded height differs from the requested height                                         |
| `record_too_large`       | Raw record exceeds the configured delivery limit                                         |
| `encoding_error`         | Notification could not be encoded                                                        |
| `height_exhausted`       | Height cannot advance safely                                                             |
| `client_closed`          | Client subscription or transport closed; also recorded in diagnostics                    |



## Delivery Limits

| Hosted admission limit           | Value         |
| -------------------------------- | ------------- |
| Connections per client IP        | 8             |
| Subscriptions per connection     | 1             |
| Global active subscribers        | 12            |
| Largest deliverable block record | 20 MiB        |
| Serve request window             | 42,428 blocks |

| Service flag               | Release default | Hosted Futurenet | Effect                                                                |
| -------------------------- | --------------: | ---------------: | --------------------------------------------------------------------- |
| `--max-subscribers`        |            `64` |             `12` | Global subscription cap; also connection cap                          |
| `--subscriber-queue`       |             `8` |              `8` | Maximum queued live blocks per subscriber                             |
| `--subscriber-queue-bytes` |       `2097152` |        `2097152` | Maximum raw bytes in a live queue                                     |
| `--max-record-bytes`       |       `4194304` |       `20971520` | Maximum deliverable raw record; ingestion can accept larger records   |
| `--live-timeout-ms`        |          `5000` |          `60000` | Live send plus ACK deadline before demotion                           |
| `--catchup-timeout-ms`     |         `10000` |          `60000` | Archive read deadline and, separately, archive send plus ACK deadline |
| `--catchup-progress-ms`    |         `30000` |         `120000` | Window for checking whether archive lag grows                         |



## Statistics

| Result field                                              | Meaning                                                         |
| --------------------------------------------------------- | --------------------------------------------------------------- |
| `currentSubscribers`                                      | Active subscription count                                       |
| `tip`                                                     | Durable archive height, or `-1` before an origin is known       |
| `totals`                                                  | Process-lifetime counters, retained after subscribers leave     |
| `subscribers`                                             | Active subscriber array, bounded by the configured cap          |
| `subscribers[].id`                                        | Application subscriber ID                                       |
| `subscribers[].nextHeight`                                | Inclusive next unacknowledged height                            |
| `subscribers[].lagBlocks`                                 | Lag relative to the durable archive, not the node’s current tip |
| `subscribers[].mode`                                      | `"live"` or `"catchup"`                                         |
| `subscribers[].queuedBlocks`, `subscribers[].queuedBytes` | Live queue occupancy; bytes count raw records                   |
| `subscribers[].counters`                                  | Counters for this active subscriber                             |

| Counter field (in `totals` and `counters`) | Meaning                                                                                      |
| ------------------------------------------ | -------------------------------------------------------------------------------------------- |
| `demotions`                                | Transitions from live delivery to archive catch-up                                           |
| `blocksSent`, `bytesSent`                  | Successful transport enqueues, not confirmed application processing; bytes count raw records |
| `catchupSeconds`                           | Time in catch-up, including disk, send, and ACK waits                                        |
| `disconnects`                              | Counts keyed by termination reason                                                           |

---

## Project Thruput

Source: <https://thruput.network/>

Project Thruput explores abundant compute through unordered transactions within each block, shared state, and runtime-enforced constraints.



Blockchain technology\
built for abundance
-------------------

Unordered transactions. Parallel execution.\
Shared balances without overspending.\
No conventional gas fees.

## Use a coding agent

```text
Help me deploy and use my first Project Thruput counter contract on Futurenet.

1. Install the latest Thruput CLI and run thruput init. Use
   thruput --help to see all available commands. Follow the installation
   instructions at https://thruput.network/docs/cli/install/.
2. Install the thruput skill user-wide for this coding agent with
   thruput skill install --global, then read the installed skill.
3. Export the documentation into a new folder with thruput docs export.
   Read its index and the relevant setup and contract instructions.
4. Outside a project, run thruput config use futurenet to select the global
   default. Create a wallet with thruput wallet create, then request test funds
   with thruput airdrop. Verify the balance before deployment.
5. Run thruput new counter --template counter, enter the project directory,
   and check thruput config get still selects futurenet. New projects inherit
   the global default. Build the contract and run its tests.
6. Deploy and initialize the counter to 10. Call increment with 5,
   then verify that its read-only view returns 15.

Finish with the project location, contract address, transaction hashes,
verified counter value, and the CLI commands I can use next.
```

01 / A different starting point



Payments need rules.\
Do they need an order?
----------------------

Project Thruput is a moonshot inspired by [Stellar’s mission](https://stellar.org/foundation). It looks a decade ahead, exploring the compute and throughput a globally accessible financial system could need.

Project Thruput removes transaction order within each block to unlock parallel execution, even across shared balances. Typed storage lets compatible changes combine, while the runtime enforces application constraints and prevents overspending.

Example: Three payments read the same starting balance of 100. Payments of 30 and 40 can land together, leaving 30. Admitting a payment of 50 as well would overspend, so it is excluded. The diagram shows one possible selection.

Blocks still form an ordered history. Within each block, admitted changes combine into the next committed state.

[Explore the execution model](pages/how-it-works/execution-model.md)

Starting balance**100**

Payment &#x41;**−30**Admitted

Payment &#x42;**−40**Admitted

Payment &#x43;**−50**Excluded

Committed balance**30**

One valid outcome: 100 − 30 − 40 = 30

02 / Why Project Thruput



## More compute. More throughput.

The bet is that removing transaction order within blocks can unlock far more computation for smart contracts. Developers could build the logic their applications need, instead of keeping contracts small to compete for scarce compute within each block. Work pushed offchain by compute limits could move onchain.

Higher throughput follows from the same design, even across shared state. The aim is a new baseline: if an application makes sense onchain, compute and throughput should not hold it back.



01

### Rules across shared state

A transaction can check its own changes. A capacity constraint can also enforce a shared withdrawal budget across concurrent transactions. The SDK provides storage types for both merge rules and constraints on their combined changes.

[Choose your storage](pages/programming-model/storage-types.md)



02

### No conventional gas fees

Gas meters computation without a token fee or burn. We’re exploring whether a trader on Wall Street and a farmer in Kenya can pay the same transaction fee: zero.

[Understand gas limits](pages/programming-model/execution.md#gas)



03

### Balance-based capacity

Project Thruput tries to get as much work done as capacity allows, instead of rationing it. Under load, unlocked native-token balances determine each account's share of scheduling capacity over time. A root transaction's declared gas limit determines how much capacity it uses.

[Explore scheduling](pages/how-it-works/storage-economics.md#balance-proportional-scheduling)



04

### Refundable storage deposits

Stored data locks native tokens as a deposit. Delete the data to reclaim that deposit.

[Understand storage deposits](pages/how-it-works/storage-economics.md#storage-refundable-deposits)

03 / Architecture



## One validator. Many machines.

A Project Thruput validator is itself a distributed system. A high performance RPC system connects scheduling, authentication, and smart-contract execution across machines.

Authentication and smart-contract execution use this model today. Extending it to state is part of the longer-term plan.

Need more execution capacity? Add executor machines. The goal is to make throughput a hardware-sizing question: start with the work your application needs, then size the compute to match.

[Explore the architecture](pages/how-it-works/architecture.md)

One validator

CoordinatorConsensus with other validators

SchedulerDistribute transaction batches

AuthenticationCheck signatures and claims

Internal RPC

Machine 01

**Contract executor** Run contracts in parallel

Machine 02

**Contract executor** Run contracts in parallel

Machine 03

**Contract executor** Run contracts in parallel

Machine 04

**Contract executor** Run contracts in parallel

Machine 05

**Contract executor** Run contracts in parallel

StateShared snapshots and compatible changes



### More machines. More work.

Measured ERC-20 payments / second

**7.02M** payments / sec · 8 executor hosts

1. 1.18M

   1
2. 2.32M

   2
3. 3.47M

   3
4. 4.44M

   4
5. 5.35M

   5
6. 6.20M

   6
7. 6.84M

   7
8. 7.02M

   8

Executor hosts (64 cores each)



Real RV32 ERC-20 transfers between 100 hot accounts. This benchmark measures execution, signature checks, and block open-to-commit work in Thruput’s core execution engine. It excludes overhead from consensus, the mempool, and client JSON-RPC submission. [Benchmark results and methodology](https://github.com/thruputchain/whitney).

04 / From contract to application



## Write Rust. Build something you can use.

Create, test, deploy, and inspect contracts with a complete CLI. Generate TypeScript bindings to call them from your application. Give your coding agent the `thruput` skill and local docs to work from the same tools and instructions.

[Build a counter, step by step](pages/tutorials/build-a-counter.md)



### Agent

Agent prompt

```text
Using the thruput skill and local docs,
run thruput new counter --template counter.
Add increment(amount) and decrement(amount) methods
using strict_inc with positive and negative deltas.
Build it and run the native and RV32 tests.
```



### Rust

**src/implementation.rs**

```rust
pub fn increment(&mut self, amount: u64) {
    self.value.strict_inc(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.strict_inc(-(amount as i128));
}
```



### TypeScript

**increment.ts**

```ts
const call = Counter.increment.call({
  contract: counterAddress,
  args: { amount: 5n },
  gasLimit: gasAmount(500_000n),
});

await wallet.executeCallsAndWait({
  calls: [call],
  gasLimit: gasAmount(1_000_000n),
});
```

1. 01

   ### [Create](pages/cli/create-project.md)

   Start a project with the CLI.

2. 02

   ### [Write](pages/contracts.md)

   Define contract logic in Rust.

3. 03

   ### [Test](pages/cli/build-and-test.md)

   Check native and RV32 execution.

4. 04

   ### [Deploy](pages/cli/deploy-and-call.md)

   Fund and initialize on Futurenet.

5. 05

   ### [Connect](pages/typescript.md)

   Call with typed bindings.

[![Stellar](assets/brand/stellar.svg) ![Stellar](assets/brand/stellar-dark.svg) ](https://stellar.org)[Project Thruput](pages/index.md)

A blockchain for abundant compute

Technology preview · alpha-pre.1

---

## Whitepapers

Source: <https://thruput.network/whitepapers/>

Read the whitepapers on Project Thruput’s system design and trust-minimized bridging between FBA blockchains.

Project Thruput / Research

## Whitepapers

The ideas behind Project Thruput, from the system design to research on connecting blockchains.



01 / System design



## Project Thruput

The main whitepaper introduces the case for abundant blockchain compute. It explores unordered transactions within blocks, concurrent updates to shared state, and the system architecture and capacity model behind Project Thruput.

Start here for the project’s motivation and design.

[Read PDF ](assets/whitepapers/thruput.pdf)[Download PDF](assets/whitepapers/thruput.pdf)



02 / Consensus research



## Trust-minimized bridging between FBA blockchains

This research paper explores how Federated Byzantine Agreement (FBA) can extend across blockchains. It presents a way for one chain to agree on another’s state, enabling asset transfers without giving an external third party custody of the escrowed assets.

For readers interested in consensus protocols, trust assumptions, and cross-chain interoperability.

[Read PDF ](assets/whitepapers/fba-bridging.pdf)[Download PDF](assets/whitepapers/fba-bridging.pdf)

[Understand Project Thruput](pages/architecture.md)

[![Stellar](assets/brand/stellar.svg) ![Stellar](assets/brand/stellar-dark.svg) ](https://stellar.org)[Project Thruput](pages/index.md)

A blockchain for abundant compute

Technology preview · alpha-pre.1
