# Stellar Thruput documentation

Documentation source: `0ef4e3a19aa21cfa1487f7d3e59b19f902eaf72f`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Read a focused section or an individual page before loading the full documentation.

- [Complete documentation](full.md)

## Get Started

[Section bundle](sections/get-started.md)

- [Get Started](pages/get-started.md): Choose a starting point for Stellar Thruput contracts, applications, or coding agents.
- [CLI quickstart](pages/get-started/cli.md): Create a Devnet wallet, request native test tokens, and inspect your first transaction from the terminal.
- [Contract quickstart](pages/get-started/contract.md): Create, test, and deploy a Rust counter contract to Stellar Thruput Devnet.
- [TypeScript quickstart](pages/get-started/typescript.md): Connect to Devnet and read the native-token contract with a typed TypeScript client.
- [React quickstart](pages/get-started/react.md): Display live Devnet contract data in React with a typed query and a refresh action.
- [Build with an Agent](pages/start/build-with-an-agent.md): Give your coding agent one prompt to install the Thruput CLI, fund a wallet, and deploy and call a counter contract on Stellar Thruput Devnet.

## Understand Stellar Thruput

[Section bundle](sections/architecture.md)

- [Introduction](pages/architecture.md): Learn what Stellar Thruput is and how compatible updates let contracts share state.
- [System Overview](pages/how-it-works/architecture.md): How Stellar Thruput's public gateway, execution services, storage, and consensus coordinator fit together.
- [Parallel Execution](pages/how-it-works/execution-model.md): How the engine executes transactions against snapshots and reserves compatible state changes.
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to committed state.
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): How the native token provides scheduling capacity and refundable storage deposits without conventional gas fees.
- [Consensus](pages/how-it-works/consensus.md): How SCP coordinates proposals, validation, and finalized blocks.
- [Networking](pages/how-it-works/networking.md): Node topology, component registration, and how transactions reach the mempool.
- [For Blockchain Developers](pages/start/for-blockchain-developers.md): Understand Stellar Thruput's storage and execution rules through a familiar token transfer.
- [EVM & Solidity](pages/ecosystem/evm.md): Translate Solidity contract patterns into Stellar Thruput storage, calls, and authorization.
- [Solana & Anchor](pages/ecosystem/solana.md): Translate Solana account, storage, and CPI patterns into Stellar Thruput contracts.
- [Stellar & Soroban](pages/ecosystem/stellar.md): Translate Stellar operations and Soroban contract patterns into Stellar Thruput applications.
- [For Backend Developers](pages/start/for-backend-developers.md): Map your Postgres and database experience to Stellar Thruput's programming model.
- [For Distributed Systems Developers](pages/start/for-distributed-systems-developers.md): Understand Stellar Thruput's use of commutative updates within consensus blocks.

## CLI

[Section bundle](sections/cli.md)

- [CLI](pages/cli.md): Install the Thruput CLI, configure networks, and build, test, deploy, and call contracts.
- [Install the CLI](pages/cli/install.md): Install the latest Thruput CLI and prepare Cargo access for contract development.
- [Profiles and networks](pages/cli/configuration.md): Select Devnet, local development, or a custom endpoint and manage global and project configuration.
- [Keys and wallets](pages/cli/wallets.md): Create signing keys, save native wallet bindings, select an account, and request test funds.
- [Create a project](pages/cli/create-project.md): Create a contract project and keep its generated compiler, build, and test configuration together.
- [Build and test](pages/cli/build-and-test.md): Build RV32 artifacts and choose native, artifact, or RPC integration tests.
- [Run a local node](pages/cli/local-node.md): Start an isolated development chain, select its accounts, and preserve or inspect local state.
- [Deploy and call](pages/cli/deploy-and-call.md): Deploy an artifact, fund its storage, call methods, and read committed state.
- [Inspect transactions and events](pages/cli/transactions.md): Inspect receipts, address history, contract events, and token transfers from the CLI.
- [Generate TypeScript bindings](pages/cli/codegen.md): Generate typed application bindings from a built contract's canonical specification.
- [Skills and local docs](pages/cli/agent-tools.md): Install, update, and read the thruput skill, and serve or export local documentation.
- [Use the CLI in scripts](pages/cli/automation.md): Use non-interactive commands and structured output without treating output flags as confirmation.
- [Troubleshooting](pages/cli/troubleshooting.md): Diagnose configuration, build, runtime, funding, and transaction-observation problems.
- [Command reference](pages/cli/reference.md): Thruput CLI commands, common options, and links to task instructions.

## Smart Contracts

[Section bundle](sections/contracts.md)

- [Smart Contracts](pages/contracts.md): Write, test, and understand Stellar Thruput contracts with the Rust SDK.
- [Project structure](pages/contracts/project-structure.md): Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.
- [Methods and interfaces](pages/contracts/methods.md): Define contract state, expose methods, and share typed interfaces with Rust callers.
- [Contract Execution](pages/programming-model/execution.md): The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.
- [Storage Types](pages/programming-model/storage-types.md): SDK storage types, their conflict semantics, and how to choose between them.
- [NNInt and concurrent updates](pages/programming-model/nnint.md): The set_add primitive underneath NNInt and why concurrent transactions merge.
- [Authorization](pages/how-it-works/authorization.md): How transaction signatures, address auth data, caller identity, and auth tokens work in Stellar Thruput.
- [Handle errors](pages/contracts/errors.md): How errors work in Stellar Thruput contracts.
- [Events](pages/contracts/events.md): Define, declare, emit, and test typed events in a Rust contract.
- [Cross-Contract Calls](pages/contracts/cross-contract-calls.md): Calling other contracts from your contract.
- [Invocation Frames](pages/how-it-works/invocation-frames.md): How contract calls track state, return results, and merge or discard child effects.
- [Testing](pages/programming-model/testing.md): How to test Stellar Thruput contracts: native logic tests, RV32 integration tests, setup, and error matching.
- [Debug a contract](pages/contracts/debugging.md): Isolate failures in native tests, RV32 artifact tests, and submitted transactions.
- [Generate client bindings](pages/contracts/client-bindings.md): Deliver a contract's typed interface to TypeScript application developers.
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.
- [Rust API Docs](pages/tools/rust-api-docs.md): Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.
- [Storage Types](pages/reference/storage-types.md): API reference for Stellar Thruput storage types.
- [SDK Macros](pages/reference/sdk-macros.md): Macro targets, parameters, generated APIs, and constraints for the Rust SDK.
- [Syscalls](pages/reference/syscalls.md): Host function numbers, parameters, and errors for Stellar Thruput contracts.

## TypeScript

[Section bundle](sections/typescript.md)

- [TypeScript](pages/typescript.md): Connect applications and services to Stellar Thruput with the TypeScript client and typed contract bindings.
- [Package setup](pages/typescript/setup.md): Configure access to Stellar Thruput's JavaScript packages for TypeScript and React applications.
- [Connect to a network](pages/typescript/connect.md): Create a public client, select Devnet or a local endpoint, and check network identity.
- [Configure HTTP transport](pages/typescript/transport.md): Set RPC timeouts, batch independent reads, and classify transport failures.
- [Addresses and amounts](pages/typescript/values.md): Parse and display exact amounts, addresses, and hashes in a TypeScript application.
- [Use contract bindings](pages/tools/typescript-bindings.md): Select a generated interface, bind a deployment address, and work with typed arguments and results.
- [Read contract data](pages/typescript/reads.md): Read typed contract values, require a minimum height, and group related reads at one committed snapshot.
- [Read events](pages/typescript/events.md): Filter and decode contract events, walk historical pages, and save progress without missing rows.
- [Accounts and wallet clients](pages/typescript/wallet-clients.md): Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.
- [Connect a wallet](pages/tools/wallet-integration.md): Discover browser wallets, connect an account on the intended network, and manage its session.
- [Use a signer in scripts](pages/typescript/accounts.md): Bind a Node.js signer to a native account, request Devnet funds, and use local bootstrap accounts.
- [Send transactions](pages/typescript/transactions.md): Build typed calls, execute them through a wallet, and distinguish submission from successful execution.
- [Track transaction results](pages/typescript/transaction-status.md): Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.
- [Deploy a contract](pages/typescript/deployment.md): Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.
- [Client API reference](pages/tools/typescript-sdk.md): TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.
- [Wallet provider reference](pages/tools/wallet-provider.md): Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.

## React

[Section bundle](sections/react.md)

- [React](pages/react.md): Use Stellar Thruput's React provider and hooks for wallets and contract data.
- [Setup](pages/react/setup.md): Install the React integration and connect its wallet and query providers to Devnet.
- [Providers and clients](pages/react/providers.md): Understand the React contexts, public and signing clients, and their lifetimes.
- [Read contract data](pages/react/reads.md): Display a typed contract view with loading, error, data, and refresh states.
- [Read balances](pages/react/balances.md): Read native-token and contract-token balances for a connected account or an explicit address.
- [Cache and refresh data](pages/react/queries.md): Share query results, reuse query factories, and refresh the original data after a transaction.
- [Read events](pages/react/events.md): Use the public client and TanStack Query to display typed contract events in React.
- [Connect a wallet](pages/react/wallets.md): Build wallet and account selectors with explicit connection, network, and error states.
- [Send transactions](pages/react/transactions.md): Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.
- [Track transaction results](pages/react/transaction-status.md): Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.
- [React API reference](pages/react/reference.md): Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.

## Guides

[Section bundle](sections/guides.md)

- [Guides](pages/guides.md): Build a counter app, a token contract, or an AMM with runnable examples and verified checkpoints.
- [Build a counter, part 1: Contract](pages/tutorials/build-a-counter.md): Create, test, and deploy the contract for a counter application, starting from an empty directory.
- [Build a counter, part 2: TypeScript](pages/tutorials/work-with-thruput-from-typescript.md): Create a typed client and a small server-side development signer for the counter, without cloning a repository.
- [Build a counter, part 3: React](pages/tutorials/build-a-counter-with-react.md): Build a small React counter that can read and update the contract immediately through the development signer.
- [Build a counter, part 4: Connect a wallet](pages/tutorials/connect-a-wallet-to-your-app.md): Let the user switch from the development signer to a connected wallet in the same counter application.
- [Build a token](pages/tutorials/build-a-token.md): Build and test an ERC-20 contract with balances, allowances, administrator-controlled supply, and standard events.
- [Build an AMM](pages/tutorials/build-an-amm.md): Build and exercise a queued constant-product AMM, including liquidity, swaps, request outcomes, and RV32 tests.

## Tools

[Section bundle](sections/tools.md)

- [Faucet](pages/tools/faucet.md): Request native test tokens for a Devnet wallet and check the funding result.
- [Explorer](pages/tools/block-explorer.md): Use the Devnet explorer to look up transactions, inspect receipts and events, and check address activity.
- [Wallet Extension](pages/tools/wallet-extension.md): Install the wallet for Stellar Thruput in Chrome, create a test wallet, and connect it to a Devnet app.

## Reference

[Section bundle](sections/reference.md)

- [JSON-RPC API](pages/reference/json-rpc-api.md): Stellar Thruput JSON-RPC methods, wire types, and error codes.
- [Contract Spec](pages/reference/contract-spec.md): Canonical contract metadata, structured identities, methods, types, events, and exceptions.
- [XDR Protocol](pages/reference/xdr-protocol.md): Encoding boundaries and source definitions for the Stellar Thruput protocol.

## Overview

[Section bundle](sections/overview.md)

- [Stellar Thruput](pages/index.md): Stellar Thruput explores abundant compute through unordered transactions within each block, shared state, and runtime-enforced constraints.
