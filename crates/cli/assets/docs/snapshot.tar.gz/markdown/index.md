# Groundhog documentation

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

Read a focused section or an individual page before loading the full documentation.

- [Complete documentation](full.md)

## Get Started

[Section bundle](sections/get-started.md)

- [CLI quickstart](pages/get-started/cli.md): Create a Devnet wallet, request test HOG, and inspect your first transaction from the terminal.
- [Contract quickstart](pages/get-started/contract.md): Create, test, and deploy a Rust counter contract to Groundhog Devnet.
- [Get Started](pages/get-started.md): Choose a starting point for Groundhog contracts, applications, or coding agents.
- [React quickstart](pages/get-started/react.md): Display live Devnet contract data in React with a typed query and a refresh action.
- [TypeScript quickstart](pages/get-started/typescript.md): Connect to Devnet and read the native HOG contract with a typed TypeScript client.
- [Build with an Agent](pages/start/build-with-an-agent.md): Give your coding agent the Groundhog skill and docs, then build a counter application on Devnet with one prompt.

## Understand Groundhog

[Section bundle](sections/architecture.md)

- [Introduction](pages/architecture.md): Learn what Groundhog is and how compatible updates let contracts share state.
- [EVM & Solidity](pages/ecosystem/evm.md): Groundhog concepts for Solidity and EVM developers.
- [Solana & Anchor](pages/ecosystem/solana.md): Groundhog concepts for Solana and Anchor developers.
- [Stellar & Soroban](pages/ecosystem/stellar.md): Groundhog patterns for developers building in the Stellar ecosystem.
- [System Overview](pages/how-it-works/architecture.md): How Groundhog's public gateway, execution services, storage, and consensus coordinator fit together.
- [Consensus](pages/how-it-works/consensus.md): SCP-based consensus, block production, and irrevocable finality.
- [Parallel Execution](pages/how-it-works/execution-model.md): How the engine executes transactions against snapshots and reserves compatible state changes.
- [Networking](pages/how-it-works/networking.md): Node topology, component registration, and how transactions reach the mempool.
- [Compute, Capacity & Storage](pages/how-it-works/storage-economics.md): How HOG provides scheduling capacity and refundable storage deposits, while gas meters execution without a token fee.
- [Transaction Lifecycle](pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to committed state.
- [For Backend Developers](pages/start/for-backend-developers.md): Map your Postgres and database experience to Groundhog's programming model.
- [For Blockchain Developers](pages/start/for-blockchain-developers.md): Map your Ethereum, Solana, or Move experience to Groundhog's programming model.
- [For Distributed Systems Developers](pages/start/for-distributed-systems-developers.md): Map your distributed systems experience to Groundhog's programming model.

## CLI

[Section bundle](sections/cli.md)

- [Use the CLI in scripts](pages/cli/automation.md): Use non-interactive commands and structured output without treating output flags as confirmation.
- [Build and test](pages/cli/build-and-test.md): Build RV32 artifacts and choose native, artifact, or RPC integration tests.
- [Generate TypeScript bindings](pages/cli/codegen.md): Generate typed application bindings from a built contract's canonical specification.
- [Profiles and networks](pages/cli/configuration.md): Select Devnet, local development, or a custom endpoint and manage global and project configuration.
- [Create a project](pages/cli/create-project.md): Create a contract project and keep its generated compiler, build, and test configuration together.
- [Deploy and call](pages/cli/deploy-and-call.md): Deploy an artifact, fund its storage, call methods, and read committed state.
- [CLI](pages/cli.md): Install the Groundhog CLI, configure networks, and build, test, deploy, and call contracts.
- [Install the CLI](pages/cli/install.md): Install the latest Groundhog CLI and prepare Cargo access for contract development.
- [Run a local node](pages/cli/local-node.md): Start an isolated development chain, select its accounts, and preserve or inspect local state.
- [Command reference](pages/cli/reference.md): Groundhog CLI commands, common options, and links to task instructions.
- [Inspect transactions and events](pages/cli/transactions.md): Inspect receipts, address history, contract events, and token transfers from the CLI.
- [Troubleshooting](pages/cli/troubleshooting.md): Diagnose configuration, build, runtime, funding, and transaction-observation problems.
- [Keys and wallets](pages/cli/wallets.md): Create signing keys, save native wallet bindings, select an account, and request test funds.

## Smart Contracts

[Section bundle](sections/contracts.md)

- [Generate client bindings](pages/contracts/client-bindings.md): Deliver a contract's typed interface to TypeScript application developers.
- [Cross-Contract Calls](pages/contracts/cross-contract-calls.md): Calling other contracts from your contract.
- [Debug a contract](pages/contracts/debugging.md): Isolate failures in native tests, RV32 artifact tests, and submitted transactions.
- [Handle errors](pages/contracts/errors.md): How errors work in Groundhog contracts.
- [Events](pages/contracts/events.md): Define, declare, emit, and test typed events in a Rust contract.
- [Smart Contracts](pages/contracts.md): Write, test, and understand Groundhog contracts with the Rust SDK.
- [Methods and interfaces](pages/contracts/methods.md): Define contract state, expose methods, and share typed interfaces with Rust callers.
- [Project structure](pages/contracts/project-structure.md): Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.
- [Authorization](pages/how-it-works/authorization.md): How transaction signatures, address auth data, caller identity, and auth tokens work in Groundhog.
- [Contract artifacts and addresses](pages/how-it-works/contracts.md): Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.
- [Invocation Frames](pages/how-it-works/invocation-frames.md): Execution context, call stack management, and frame lifecycle.
- [Contract Execution](pages/programming-model/execution.md): The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.
- [NNInt and concurrent updates](pages/programming-model/nnint.md): The set_add primitive underneath NNInt and why concurrent transactions merge.
- [Storage Types](pages/programming-model/storage-types.md): SDK storage types, their conflict semantics, and how to choose between them.
- [Testing](pages/programming-model/testing.md): How to test Groundhog contracts: native logic tests, RV32 integration tests, setup, and error matching.
- [SDK Macros](pages/reference/sdk-macros.md): Macro targets, parameters, generated APIs, and constraints for the Rust SDK.
- [Storage Types](pages/reference/storage-types.md): API reference for Groundhog storage types.
- [Syscalls](pages/reference/syscalls.md): Authoritative reference for the host functions exposed to Groundhog contracts, generated from the protocol's syscalls.yaml.
- [Rust API Docs](pages/tools/rust-api-docs.md): Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.

## TypeScript

[Section bundle](sections/typescript.md)

- [Use contract bindings](pages/tools/typescript-bindings.md): Select a generated interface, bind a deployment address, and work with typed arguments and results.
- [Client API reference](pages/tools/typescript-sdk.md): TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.
- [Connect a wallet](pages/tools/wallet-integration.md): Discover browser wallets, connect an account on the intended network, and manage its session.
- [Wallet provider reference](pages/tools/wallet-provider.md): Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.
- [Use a signer in scripts](pages/typescript/accounts.md): Bind a Node.js signer to a native account, request Devnet funds, and use local bootstrap accounts.
- [Connect to a network](pages/typescript/connect.md): Create a public client, select Devnet or a local endpoint, and check network identity.
- [Deploy a contract](pages/typescript/deployment.md): Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.
- [Read events](pages/typescript/events.md): Filter and decode contract events, walk historical pages, and save progress without missing rows.
- [TypeScript](pages/typescript.md): Connect applications and services to Groundhog with the TypeScript client and typed contract bindings.
- [Read contract data](pages/typescript/reads.md): Read an existing contract with typed views, handle read failures, and cancel stale requests.
- [Package setup](pages/typescript/setup.md): Configure access to Groundhog's JavaScript packages for TypeScript and React applications.
- [Track transaction results](pages/typescript/transaction-status.md): Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.
- [Send transactions](pages/typescript/transactions.md): Build typed calls, execute them through a wallet, and distinguish submission from successful execution.
- [Configure HTTP transport](pages/typescript/transport.md): Set RPC timeouts, batch independent reads, and classify transport failures.
- [Addresses and amounts](pages/typescript/values.md): Parse and display exact amounts, addresses, and hashes in a TypeScript application.
- [Accounts and wallet clients](pages/typescript/wallet-clients.md): Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.

## React

[Section bundle](sections/react.md)

- [Read balances](pages/react/balances.md): Read native HOG and token balances for a connected account or an explicit address.
- [Read events](pages/react/events.md): Use the public client and TanStack Query to display typed contract events in React.
- [React](pages/react.md): Use Groundhog's React provider and hooks for wallets and contract data.
- [Providers and clients](pages/react/providers.md): Understand the React contexts, public and signing clients, and their lifetimes.
- [Cache and refresh data](pages/react/queries.md): Share query results, reuse query factories, and refresh the original data after a transaction.
- [Read contract data](pages/react/reads.md): Display a typed contract view with loading, error, data, and refresh states.
- [React API reference](pages/react/reference.md): Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.
- [Setup](pages/react/setup.md): Install the React integration and connect its wallet and query providers to Devnet.
- [Track transaction results](pages/react/transaction-status.md): Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.
- [Send transactions](pages/react/transactions.md): Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.
- [Connect a wallet](pages/react/wallets.md): Build wallet and account selectors with explicit connection, network, and error states.

## Guides

[Section bundle](sections/guides.md)

- [Guides](pages/guides.md): Learn Groundhog through contract tutorials, application walkthroughs, and worked designs.
- [Add Events to a Contract](pages/tutorials/add-events-to-a-contract.md): Tutorial: define an event, emit it from a Groundhog contract, test it, and find it in the contract spec and on chain.
- [Build a Counter](pages/tutorials/build-a-counter.md): Tutorial: build a counter contract on Groundhog, step by step.
- [Build a Token](pages/tutorials/build-a-token.md): Build an ERC-20-compatible token with the Groundhog SDK and standard interface crate.
- [Connect a Wallet to Your App](pages/tutorials/connect-a-wallet-to-your-app.md): Build a small TypeScript dapp that connects an installed wallet and sends a localnet HOG transfer with receipt recovery.
- [Design a Swap](pages/tutorials/design-a-swap.md): How a constant-product AMM is built on Groundhog, and why the execution model shapes it.
- [Develop Locally with the CLI](pages/tutorials/develop-locally.md): Build, deploy, call, and inspect a Groundhog contract against a local hog-devnode.
- [Develop on Devnet with the CLI](pages/tutorials/develop-on-devnet.md): Create a persistent key-owned wallet, deploy a counter to Devnet, and exercise the Groundhog CLI end to end.
- [Work with Groundhog from TypeScript](pages/tutorials/work-with-groundhog-from-typescript.md): Build a contract, generate TypeScript bindings, connect to a local node, and use typed contract APIs.

## Tools

[Section bundle](sections/tools.md)

- [Block Explorer](pages/tools/block-explorer.md): Use the devnet explorer to look up transactions, inspect receipts and events, and check address activity.
- [Faucet](pages/tools/faucet.md): Request test HOG for a Devnet wallet and check the funding result.

## Reference

[Section bundle](sections/reference.md)

- [Contract Spec](pages/reference/contract-spec.md): Canonical contract metadata, structured identities, methods, types, events, and exceptions.
- [JSON-RPC API](pages/reference/json-rpc-api.md): Groundhog JSON-RPC methods, wire types, and error codes.
- [XDR Protocol](pages/reference/xdr-protocol.md): Encoding boundaries and protocol definitions selected by Groundhog 0.1.27.

## Overview

[Section bundle](sections/overview.md)

- [Groundhog](pages/index.md): Build Groundhog contracts and applications with the Rust SDK, CLI, and TypeScript client.
