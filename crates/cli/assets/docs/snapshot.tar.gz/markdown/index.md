# Project Thruput documentation

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

Read a focused section or an individual page before loading the full documentation.

- [Complete documentation](full.md)

## Get Started

[Section bundle](sections/get-started.md)

- [Get Started](pages/get-started.md): Choose a starting point for Project Thruput contracts, applications, or coding agents.
- [CLI quickstart](pages/get-started/cli.md): Create a Futurenet wallet, request native test tokens, and inspect your first transaction from the terminal.
- [Contract quickstart](pages/get-started/contract.md): Create, test, and deploy a Rust counter contract to Project Thruput Futurenet.
- [TypeScript quickstart](pages/get-started/typescript.md): Connect to Futurenet and read the native-token contract with a typed TypeScript client.
- [React quickstart](pages/get-started/react.md): Display live Futurenet contract data in React with a typed query and a refresh action.
- [Build with an Agent](pages/get-started/build-with-an-agent.md): Give your coding agent one prompt to install the Thruput CLI, fund a wallet, and deploy and call a counter contract on Project Thruput Futurenet.

## Understand Project Thruput

[Section bundle](sections/architecture.md)

- [Introduction](pages/architecture.md): Learn what Project Thruput is and how compatible updates let contracts share state.
- [System Overview](pages/architecture/system-overview.md): How Project Thruput's public gateway, execution services, storage, and consensus coordinator fit together.
- [Parallel Execution](pages/architecture/execution-model.md): How the engine executes transactions against snapshots and reserves compatible state changes.
- [Transaction Lifecycle](pages/architecture/transaction-lifecycle.md): How a transaction moves from submission to committed state.
- [Compute, Capacity & Storage](pages/architecture/storage-economics.md): How the native token provides scheduling capacity and refundable storage deposits without conventional gas fees.
- [Consensus](pages/architecture/consensus.md): How SCP coordinates proposals, validation, and finalized blocks.
- [Networking](pages/architecture/networking.md): Node topology, component registration, and how transactions reach the mempool.
- [For Blockchain Developers](pages/architecture/coming-from/blockchain.md): Understand Project Thruput's storage and execution rules through a familiar token transfer.
- [EVM & Solidity](pages/architecture/coming-from/evm.md): Translate Solidity contract patterns into Project Thruput storage, calls, and authorization.
- [Solana & Anchor](pages/architecture/coming-from/solana.md): Translate Solana account, storage, and CPI patterns into Project Thruput contracts.
- [Stellar & Soroban](pages/architecture/coming-from/stellar.md): Map Stellar and Soroban operations to Thruput storage, authorization, and development workflow.
- [For Backend Developers](pages/architecture/coming-from/backend.md): Map your Postgres and database experience to Project Thruput's programming model.
- [For Distributed Systems Developers](pages/architecture/coming-from/distributed-systems.md): Understand Project Thruput's use of commutative updates within consensus blocks.
- [Project Thruput roadmap](pages/architecture/roadmap.md): Things we'd like to see built in Thruput.

## CLI

[Section bundle](sections/cli.md)

- [CLI](pages/cli.md): Install the Thruput CLI, configure networks, and build, test, deploy, and call contracts.
- [Install the CLI](pages/cli/install.md): Install the latest Thruput CLI and the local runtime for contract development.
- [Profiles and networks](pages/cli/configuration.md): Select Futurenet, local development, or a custom endpoint and manage global and project configuration.
- [Keys and wallets](pages/cli/wallets.md): Create signing keys, save native wallet bindings, select an account, and request test funds.
- [Create a project](pages/cli/create-project.md): Create a contract project and keep its generated compiler, build, and test configuration together.
- [Build and test](pages/cli/build-and-test.md): Build RV32 artifacts and choose native, artifact, or RPC integration tests.
- [Run a local node](pages/cli/local-node.md): Start an isolated development chain, select its accounts, and preserve or inspect local state.
- [Deploy and call](pages/cli/deploy-and-call.md): Deploy an artifact, fund its storage, call methods, and read committed state.
- [Inspect transactions and events](pages/cli/transactions.md): Inspect receipts, address history, contract events, and token transfers from the CLI.
- [Generate TypeScript bindings](pages/cli/codegen.md): Generate typed application bindings from a built contract's canonical specification.
- [Skills and local docs](pages/cli/agent-tools.md): Install, update, and read the thruput skill, and serve or export local documentation.
- [Use the CLI in scripts](pages/cli/automation.md): Use non-interactive commands and structured output without treating output flags as confirmation.
- [Troubleshooting](pages/cli/troubleshooting.md): Diagnose configuration, build, runtime, funding, and transaction-observation problems.
- [Command reference](pages/cli/reference.md): Thruput CLI commands, common options, and links to task instructions.

## Smart Contracts

[Section bundle](sections/contracts.md)

- [Smart Contracts](pages/contracts.md): Write, test, and understand Project Thruput contracts with the Rust SDK.
- [Project structure](pages/contracts/project-structure.md): Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.
- [Methods and interfaces](pages/contracts/methods.md): Define contract state, expose methods, and share typed interfaces with Rust callers.
- [Contract Execution](pages/contracts/execution.md): The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.
- [Storage Types](pages/contracts/storage-types.md): SDK storage types, their conflict semantics, and how to choose between them.
- [NNInt and concurrent updates](pages/contracts/nnint.md): The set_add primitive underneath NNInt and why concurrent transactions merge.
- [Authorization](pages/contracts/authorization.md): How transaction signatures, address auth data, caller identity, and auth tokens work in Project Thruput.
- [Handle errors](pages/contracts/errors.md): How errors work in Project Thruput contracts.
- [Events](pages/contracts/events.md): Define, declare, emit, and test typed events in a Rust contract.
- [Cross-Contract Calls](pages/contracts/cross-contract-calls.md): Calling other contracts from your contract.
- [Invocation Frames](pages/contracts/invocation-frames.md): How contract calls track state, return results, and merge or discard child effects.
- [Testing](pages/contracts/testing.md): How to test Project Thruput contracts: native logic tests, RV32 integration tests, setup, and error matching.
- [Debug a contract](pages/contracts/debugging.md): Isolate failures in native tests, RV32 artifact tests, and submitted transactions.
- [Generate client bindings](pages/contracts/client-bindings.md): Deliver a contract's typed interface to TypeScript application developers.
- [Contract artifacts and addresses](pages/contracts/artifacts-and-addresses.md): Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.
- [Rust API Docs](pages/contracts/reference/rust-api-docs.md): Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.
- [Storage Types](pages/contracts/reference/storage-types.md): API reference for Project Thruput storage types.
- [SDK Macros](pages/contracts/reference/sdk-macros.md): Macro targets, parameters, generated APIs, and constraints for the Rust SDK.
- [Syscalls](pages/contracts/reference/syscalls.md): Host function numbers, parameters, and errors for Project Thruput contracts.

## TypeScript

[Section bundle](sections/typescript.md)

- [TypeScript](pages/typescript.md): Connect applications and services to Project Thruput with the TypeScript client and typed contract bindings.
- [Package setup](pages/typescript/setup.md): Install Project Thruput's public npm packages for TypeScript and React applications.
- [Connect to a network](pages/typescript/connect.md): Create a public client, select Futurenet or a local endpoint, and check network identity.
- [Configure HTTP transport](pages/typescript/transport.md): Set RPC timeouts, batch independent reads, and classify transport failures.
- [Addresses and amounts](pages/typescript/values.md): Parse and display exact amounts, addresses, and hashes in a TypeScript application.
- [Use contract bindings](pages/typescript/bindings.md): Select a generated interface, bind a deployment address, and work with typed arguments and results.
- [Read contract data](pages/typescript/reads.md): Read typed contract values, require a minimum height, and group related reads at one committed snapshot.
- [Read events](pages/typescript/events.md): Filter and decode contract events, walk historical pages, and save progress without missing rows.
- [Accounts and wallet clients](pages/typescript/wallet-clients.md): Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.
- [Connect a wallet](pages/typescript/wallet-integration.md): Discover browser wallets, connect an account on the intended network, and manage its session.
- [Use a signer in scripts](pages/typescript/accounts.md): Bind a Node.js signer to a native account, request Futurenet funds, and use local bootstrap accounts.
- [Send transactions](pages/typescript/transactions.md): Build typed calls, execute them through a wallet, and distinguish submission from successful execution.
- [Track transaction results](pages/typescript/transaction-status.md): Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.
- [Deploy a contract](pages/typescript/deployment.md): Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.
- [Client API reference](pages/typescript/reference/sdk.md): TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.
- [Error reference](pages/typescript/reference/errors.md): ThruputError codes, typed context, and transaction facts in the TypeScript client.
- [Wallet provider reference](pages/typescript/reference/wallet-provider.md): Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.

## React

[Section bundle](sections/react.md)

- [React](pages/react.md): Use Project Thruput's React provider and hooks for wallets and contract data.
- [Setup](pages/react/setup.md): Install the React integration and connect its wallet and query providers to Futurenet.
- [Providers and clients](pages/react/providers.md): Understand the React contexts, public and signing clients, and their lifetimes.
- [Read contract data](pages/react/reads.md): Display a typed contract view with loading, error, data, and refresh states.
- [Read balances](pages/react/balances.md): Read native-token and contract-token balances for a connected account or an explicit address.
- [Cache and refresh data](pages/react/queries.md): Share query results, reuse query factories, and refresh the original data after a transaction.
- [Read events](pages/react/events.md): Use the public client and TanStack Query to display typed contract events in React.
- [Connect a wallet](pages/react/wallets.md): Build wallet and account selectors with explicit connection, network, and error states.
- [Send transactions](pages/react/transactions.md): Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.
- [Track transaction results](pages/react/transaction-status.md): Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.
- [React API reference](pages/react/reference.md): Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.

## Tutorials

[Section bundle](sections/tutorials.md)

- [Tutorials](pages/tutorials.md): Build a counter app from an empty directory through contract, TypeScript, React, and wallet connection tutorials.
- [Build a counter, part 1: Contract](pages/tutorials/build-a-counter.md): Create, test, and deploy the contract for a counter application, starting from an empty directory.
- [Build a counter, part 2: TypeScript](pages/tutorials/work-with-thruput-from-typescript.md): Create a typed client and a small server-side development signer for the counter, without cloning a repository.
- [Build a counter, part 3: React](pages/tutorials/build-a-counter-with-react.md): Build a small React counter that can read and update the contract immediately through the development signer.
- [Build a counter, part 4: Connect a wallet](pages/tutorials/connect-a-wallet-to-your-app.md): Let the user switch from the development signer to a connected wallet in the same counter application.

## Guides

[Section bundle](sections/guides.md)

- [Guides](pages/guides.md): Build a token, build an AMM, or consume the firehose with runnable examples and verified checkpoints.
- [Build a token](pages/guides/build-a-token.md): Build and test an ERC-20 contract with balances, allowances, administrator-controlled supply, and standard events.
- [Build an AMM](pages/guides/build-an-amm.md): Build and exercise a queued constant-product AMM, including liquidity, swaps, request outcomes, and RV32 tests.
- [Consume the Firehose](pages/guides/consume-the-firehose.md): Connect to the hosted Futurenet firehose from a browser or Node, acknowledge blocks, and resume from durable progress.

## Tools

[Section bundle](sections/tools.md)

- [Faucet](pages/tools/faucet.md): Request native test tokens for a Futurenet wallet and check the funding result.
- [Explorer](pages/tools/block-explorer.md): Use the Futurenet explorer to look up transactions, inspect receipts and events, and check address activity.
- [Wallet Extension](pages/tools/wallet-extension.md): Download and install the Thruput fork of Freighter in Chrome for Futurenet testing.

## Reference

[Section bundle](sections/reference.md)

- [JSON-RPC API](pages/reference/json-rpc-api.md): Project Thruput native JSON-RPC methods, wire types, and error codes for wire format 14.
- [Contract Spec](pages/reference/contract-spec.md): Canonical contract metadata, structured identities, methods, types, events, and exceptions.
- [XDR Protocol](pages/reference/xdr-protocol.md): Encoding boundaries and source definitions for the Project Thruput protocol.
- [Firehose API](pages/reference/firehose.md): Hosted Futurenet WebSocket subscriptions for committed block records, acknowledgements, and resumable replay.

## Overview

[Section bundle](sections/overview.md)

- [Stellar Project Thruput](pages/index.md): Unordered transactions. Parallel execution. Shared balances without overspending. No conventional gas fees
- [Whitepapers](pages/whitepapers.md): Read the whitepapers on Project Thruput’s system design and trust-minimized bridging between FBA blockchains.
