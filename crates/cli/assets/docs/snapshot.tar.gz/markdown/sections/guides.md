# Guides

Documentation source: `c395bff83c52fc8618aa373273398cdd2c9d6535`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Guides

Source: <https://thruput.network/guides/>

Build a counter app, a token contract, or an AMM with runnable examples and verified checkpoints.

Build a project with a visible result or passing check. The counter series starts from an empty directory. The [examples repository](https://github.com/groundhogchain/groundhog-examples) supplies the token and AMM contracts and a full-featured counter app for reference.



## Build a counter app

One contract and one application across four parts:

1. [Contract](../pages/tutorials/build-a-counter.md): write, test, and deploy the counter.
2. [TypeScript](../pages/tutorials/work-with-thruput-from-typescript.md): create the client and a server-side development signer.
3. [React](../pages/tutorials/build-a-counter-with-react.md): build a working counter interface with development signing and receipt tracking.
4. [Connect a wallet](../pages/tutorials/connect-a-wallet-to-your-app.md): switch to wallet-approved updates and return to development signing on explicit disconnect.

Follow the four parts in order, using your own contract and deployment throughout.



## Build another contract

- [Build a token](../pages/tutorials/build-a-token.md): balances, allowances, supply policy, events, and native/RV32 checks.
- [Build an AMM](../pages/tutorials/build-an-amm.md): pool creation, liquidity, queued swaps, and correlated outcomes, exercised through the contract test environments.

Use the CLI, Smart Contracts, TypeScript, and React sections for individual tasks and API details. Network setup, event APIs, and wallet connection have their canonical instructions there.

---

## Build a counter, part 1: Contract

Source: <https://thruput.network/tutorials/build-a-counter/>

Create, test, and deploy the contract for a counter application, starting from an empty directory.

Build a small counter application from scratch. Across four parts, you will create a contract, add a TypeScript development signer, build a React interface, and let users switch to their own wallet.

You can also explore the [full counter example on GitHub](https://github.com/groundhogchain/groundhog-examples/tree/main/apps/counter).



## Create the contract

Complete [CLI installation and Cargo access](../pages/cli/install.md). For deployment, use a funded Devnet account from the [CLI quickstart](../pages/get-started/cli.md).

```bash
thruput new counter --template counter
cd counter
```

Keep the generated manifest and toolchain settings. Open `src/implementation.rs`. The scaffold includes the counter used by this guide; focus on its storage and these methods.



## Store a relative count

```rust
#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}
```

`value` is a persistent storage handle. Increment and decrement record signed deltas:

```rust
pub fn increment(&mut self, amount: u64) {
    self.value.strict_inc(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.strict_inc(-(amount as i128));
}
```

`strict_inc` checks the invocation for underflow and records the relative change. Compatible deltas can merge across concurrent transactions. See [NNInt and concurrent updates](../pages/programming-model/nnint.md) for the merge rules.

The read defaults only missing storage to zero:

```rust
pub fn get(&self) -> u64 {
    self.value.try_get().none_if_missing().unwrap_or(0) as u64
}
```

The scaffold’s `initialize` method adds its initial amount. It is an ordinary method, so call it once during this deployment flow. This teaching counter allows any caller to update it. Leave the extra scaffold event and error methods in place; the app does not need them.



## Run both test modes

```bash
cargo test
thruput test
```

The native tests exercise contract logic and underflow handling. The artifact test runs the compiled RV32 contract. Neither needs a running RPC node.

**Checkpoint:** the counter tests pass, including a decrement that is expected to fail.



## Build, deploy, and initialize

```bash
thruput build
thruput deploy --estimate --profile devnet
```

Add **10 native test tokens** to the reported minimum funding in whole-token units as an example allowance for initializer storage and later writes. This is a budget, not an exact estimate of those writes or a universal requirement. Replace `TOTAL_FUNDING` with the decimal sum. The minimum alone covers only the first balance-item deposit and deployment collateral, leaving no free contract balance. See [Estimate deployment funding](../pages/cli/deploy-and-call.md#estimate-deployment-funding).

```bash
thruput deploy --profile devnet --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
thruput view counter get --profile devnet
```

Funding, deployment, and initialization happen in one transaction. The sender still needs its own storage and scheduling capacity. Your new counter should read `10`.

Save the printed deployment address. Part 2 uses this address and the contract spec produced by the build.



## Check a change

```bash
thruput call counter increment 1 --profile devnet
thruput view counter get --profile devnet
```

On your otherwise unchanged counter, the value is now `11`. Keep the same address and project for [part 2](../pages/tutorials/work-with-thruput-from-typescript.md).

For isolated local work, follow [Run a local node](../pages/cli/local-node.md) and use its profile, endpoint, and network identity consistently.



## Work with an agent

```text
Follow Build a counter, part 1:
https://thruput.network/docs/tutorials/build-a-counter/
Start with thruput new counter --template counter, without cloning an examples repo.
Run the native and RV32 checks, build, and read the deployment estimate.
Add the documented storage allowance to the minimum and deploy with that
explicit total using my configured Devnet account. Initialize atomically to 10.
Report the actual address, transaction hash,
and read value. Keep the generated dependency configuration and report
failed checks rather than inventing results.
```

---

## Build a counter, part 2: TypeScript

Source: <https://thruput.network/tutorials/work-with-thruput-from-typescript/>

Create a typed client and a small server-side development signer for the counter, without cloning a repository.

Build the TypeScript layer for the contract from [part 1](../pages/tutorials/build-a-counter.md). It will read the counter and prepare signed updates with a funded development key. The key stays in Node.js. Part 3 adds a React interface that can start counting immediately.



## Create the app directory

Inside the `counter` project from part 1:

```bash
mkdir app
cd app
npm init -y
npm pkg set type=module
```

Configure [npm registry access](../pages/typescript/setup.md#give-npm-package-access), then install the TypeScript dependencies:

```bash
npm install @groundhogchain/client @groundhogchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src/contracts
```

Keep the generated lockfile. Add these entries to `.gitignore`:

**.gitignore**

```text
node_modules/
dist/
.env
```



## Generate the TypeScript binding

Generate the binding from the contract spec built in part 1. Run this from `app`:

```bash
thruput codegen ts ../target/thruput/counter.spec.xdr \
  --output src/contracts/counter.ts
```

The binding provides typed methods and decodes the contract’s results. Regenerate it when the contract interface changes.



## Configure the client

Create `.env`. Set `COUNTER_ADDRESS` to the deployment address from part 1 and use the endpoint and network hash for that deployment:

**.env**

```dotenv
RPC_URL=https://rpc.thruput.network
NETWORK_HASH=0xabb9cdbc56285d0e71c9845273ca06211fedf7ee2f58c43cfac6060f9402aa0f
COUNTER_ADDRESS=<your-deployed-counter-address>
```

These public values identify one deployment. A different network needs its own endpoint, hash, and contract address.

**chain.ts**

```ts
import {
  addressFromHex, createGroundhogClient, createPubkeyAccount, createWalletClient,
  defineCluster, fromHex0x, hashFromHex, networkHash, PrivateKeySigner,
} from "@groundhogchain/client";
import { Counter } from "./src/contracts/counter.js";

function required(name: string) {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} in .env or the process environment`);
  return value;
}

export const rpcUrl = required("RPC_URL");
export const contract = addressFromHex(required("COUNTER_ADDRESS"));
export const client = await createGroundhogClient({
  cluster: defineCluster({
    rpcUrl,
    networkHash: networkHash(hashFromHex(required("NETWORK_HASH"))),
    capabilities: ["airdrop"],
  }),
});
export { Counter };

export function developmentWallet() {
  const signer = new PrivateKeySigner(fromHex0x(required("COUNTER_SIGNING_PRIVATE_KEY")));
  return createWalletClient({ client, account: createPubkeyAccount({ signer }) });
}
```



## Read and fund

**read.ts**

```ts
import { client, contract, Counter } from "./chain.js";

const result = await Counter.v0_1.get.view({ client, contract });
console.log("Counter:", result.value.toString());
console.log("Read at block:", result.height.toString());
```

```bash
node --env-file=.env --import tsx read.ts
```

For a disposable development signer, generate a seed once in this terminal:

```bash
export COUNTER_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep this terminal environment for funding and the server. A persistent account should load its existing seed from secret configuration. Never put this key in a browser file or a `VITE_` variable.

**fund.ts**

```ts
import { toHex0x } from "@groundhogchain/client";
import { developmentWallet } from "./chain.js";

const wallet = developmentWallet();
const funding = await wallet.requestAirdrop();
if (funding.status.result !== "ok") throw new Error("Funding did not execute successfully");
console.log("Development signer:", toHex0x(wallet.account.address));
console.log("Funding transaction:", toHex0x(funding.txHash));
```

```bash
node --env-file=.env --import tsx fund.ts
```



## Add the development server

The server exposes public configuration, proxies the app’s RPC requests, and prepares only a `+1` or `-1` call to the configured counter. Preparation signs but does not broadcast. The browser can therefore retain the hash before submission.

**server.ts**

```ts
import { createServer, type ServerResponse } from "node:http";
import { gasAmount, serializeSignedTransaction, toHex0x } from "@groundhogchain/client";
import { client, contract, Counter, developmentWallet, rpcUrl } from "./chain.js";

const wallet = process.env.COUNTER_SIGNING_PRIVATE_KEY ? developmentWallet() : null;
const allowed = new Set([
  "groundhog_networkInfo", "groundhog_chainTip", "groundhog_view",
  "groundhog_getBalance", "groundhog_getTransactionStatus",
  "groundhog_getTransactionReceipt", "groundhog_sendRawTransaction",
]);
function json(response: ServerResponse, status: number, value: unknown) {
  response.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  response.end(JSON.stringify(value));
}

createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/api/config") {
      return json(response, 200, {
        counterAddress: toHex0x(contract), networkId: toHex0x(client.network.networkHash),
        signerAddress: wallet ? toHex0x(wallet.account.address) : null,
      });
    }
    if (request.method !== "POST") return json(response, 404, { error: "Not found" });
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 65_536) return json(response, 413, { error: "Request too large" });
      chunks.push(Buffer.from(chunk));
    }
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (request.url === "/api/prepare") {
      if (!wallet) return json(response, 503, { error: "Development signer unavailable" });
      if (body?.direction !== "increment" && body?.direction !== "decrement") {
        return json(response, 400, { error: "Choose increment or decrement" });
      }
      const direction: "increment" | "decrement" = body.direction;
      const transaction = await wallet.prepareExecution({
        invocation: Counter.v0_1[direction].invocation(contract, gasAmount(500_000n), { amount: 1n }),
        gasLimit: gasAmount(1_000_000n),
      });
      const signed = await wallet.signTransaction(transaction);
      return json(response, 200, { transaction: toHex0x(serializeSignedTransaction(signed)) });
    }
    if (request.url === "/thruput-rpc" && allowed.has(body?.method)) {
      const upstream = await fetch(rpcUrl, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body), signal: AbortSignal.timeout(10_000),
      });
      return json(response, upstream.status, await upstream.json());
    }
    json(response, 404, { error: "Not found" });
  } catch (error) {
    json(response, 500, { error: error instanceof Error ? error.message : "Request failed" });
  }
}).listen(3001, "127.0.0.1", () => console.log("Counter API: http://127.0.0.1:3001"));
```

Run it in the terminal holding the development key:

```bash
node --env-file=.env --import tsx server.ts
```

**Checkpoint:** the typed read works, the development account is funded, and the API is running. The server keeps its private key; `/api/config` exposes only public identity. Part 3 turns these pieces into a usable React counter.

This server is for local development.



## Work with an agent

```text
Follow Build a counter, part 2:
https://thruput.network/docs/tutorials/work-with-thruput-from-typescript/
Generate the binding from my part-1 contract spec and create the listed
files using my deployment address. Verify the read, funding, and
public configuration endpoint. Keep the development key server-side.
Do not claim success for failed checks or submit replacement transactions
merely because observation failed.
```

---

## Build a counter, part 3: React

Source: <https://thruput.network/tutorials/build-a-counter-with-react/>

Build a small React counter that can read and update the contract immediately through the development signer.

Add a React interface to the project from [part 2](../pages/tutorials/work-with-thruput-from-typescript.md). It will work through the funded development signer as soon as you open it. There is no wallet connection requirement yet.

Keep the API server running on port 3001. All files below are inside the `app` directory you created in part 2.



## Install React

From `app`, install the React packages and browser tooling:

```bash
npm install @groundhogchain/react @tanstack/react-query react react-dom
npm install --save-dev vite @types/react @types/react-dom
```



## Add the browser entry point

```bash
npm pkg set scripts.dev="vite" scripts.build="tsc --noEmit && vite build"
```

**tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022", "module": "ESNext", "moduleResolution": "Bundler",
    "jsx": "react-jsx", "strict": true, "noUncheckedIndexedAccess": true,
    "skipLibCheck": true, "noEmit": true, "types": ["vite/client", "node"]
  },
  "include": ["*.ts", "src"]
}
```

**vite.config.ts**

```ts
import { defineConfig } from "vite";

export default defineConfig({
  server: {
    host: "127.0.0.1",
    proxy: {
      "/api": "http://127.0.0.1:3001",
      "/thruput-rpc": "http://127.0.0.1:3001",
    },
  },
});
```

**index.html**

```html
<!doctype html>
<html lang="en">
  <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Counter</title></head>
  <body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body>
</html>
```



## Connect the public client

**src/main.tsx**

```tsx
import { createRoot } from "react-dom/client";
import { createGroundhogClient, defineCluster, hashFromHex, networkHash } from "@groundhogchain/client";
import { WalletProvider } from "@groundhogchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { App } from "./App";
import type { Config } from "./updates";
import "./style.css";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting…</p>);

async function start() {
  const response = await fetch("/api/config");
  if (!response.ok) throw new Error("Could not load counter configuration");
  const config: Config = await response.json();
  const client = await createGroundhogClient({
    cluster: defineCluster({
      rpcUrl: new URL("/thruput-rpc", location.origin).href,
      networkHash: networkHash(hashFromHex(config.networkId)),
      capabilities: [],
    }),
  });
  const queries = new QueryClient();
  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}><App config={config} /></WalletProvider>
    </QueryClientProvider>,
  );
}
void start().catch((error: unknown) => root.render(
  <p role="alert">{error instanceof Error ? error.message : "Could not start the app"}</p>,
));
```

The React provider shares the public client and discovers wallet providers without asking for permission. The next part uses that wallet context. The development signer remains on the API server.

Add a small stylesheet to keep the example readable on narrow screens:

**src/style.css**

```css
body { margin: 0; font-family: system-ui, sans-serif; }
main { max-width: 48rem; margin: auto; padding: 1.5rem; }
section { margin-block: 1.5rem; }
p { overflow-wrap: anywhere; }
button, select { max-width: 100%; margin: .25rem; padding: .5rem .75rem; font: inherit; }
output { font-size: 3rem; font-variant-numeric: tabular-nums; }
```



## Separate preparation from submission

Create a small shared update module. It retains the hash before submitting and can observe a saved operation after a reload:

**src/updates.ts**

```ts
import { useRef, useState } from "react";
import { deserializeSignedTransaction, fromHex0x, hashSignedTransaction, toHex0x, type ConnectedGroundhogClient } from "@groundhogchain/client";
import { parseSignTransactionResult } from "@groundhogchain/client/provider";
import { useClient, useWaitForTransactionReceipt } from "@groundhogchain/react";

export type Config = { networkId: string; counterAddress: string; signerAddress: string | null };
export type Direction = "increment" | "decrement";
export type Pending = { hash: string; signedTransaction: string; account: string; networkId: string };
export type Prepared = { record: Pending; submit(): Promise<unknown> };

export async function archiveExpiredUpdate(client: ConnectedGroundhogClient, record: Pending, key: string, storage: Pick<Storage, "setItem" | "removeItem">) {
  if (toHex0x(client.network.networkHash) !== record.networkId) throw new Error("Select the original network before recovery");
  const signed = deserializeSignedTransaction(fromHex0x(record.signedTransaction));
  const hash = hashSignedTransaction(signed);
  if (toHex0x(hash) !== record.hash) throw new Error("Saved transaction hash does not match its bytes");
  const tip = await client.getChainTip();
  if (tip.height < signed.tx.uniquifier.block_expiry_height) throw new Error("The transaction has not expired; keep observing it");
  if (await client.getTransactionReceipt(hash)) throw new Error("A receipt is available; check the transaction and finish it");
  // Expiry prevents future inclusion, but a missing receipt does not prove it never committed.
  storage.setItem(`${key}:archived:${record.hash}`, JSON.stringify({ ...record, outcome: "unresolved", archivedAtHeight: tip.height.toString() }));
  storage.removeItem(key);
}

export async function prepareDevelopment(client: ConnectedGroundhogClient, config: Config, direction: Direction): Promise<Prepared> {
  if (!config.signerAddress) throw new Error("Development signer unavailable");
  const response = await fetch("/api/prepare", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ direction }),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Preparation failed");
  const signed = deserializeSignedTransaction(fromHex0x(body.transaction));
  return {
    record: { hash: toHex0x(hashSignedTransaction(signed)), signedTransaction: body.transaction, account: config.signerAddress, networkId: config.networkId },
    submit: () => client.sendTransaction(signed),
  };
}

export function useUpdate(config: Config) {
  const client = useClient();
  const key = `counter:${config.networkId}:${config.counterAddress}`;
  const [state, setState] = useState<{ record: Pending | null; error: string | null }>(() => {
    try {
      const text = localStorage.getItem(key);
      if (!text) return { record: null, error: null };
      const value = JSON.parse(text);
      const signed = parseSignTransactionResult({ hash: value.hash, signedTransaction: value.signedTransaction });
      if (value.networkId !== config.networkId || typeof value.account !== "string") throw new Error("Invalid saved transaction");
      return { record: { ...signed, account: value.account, networkId: value.networkId }, error: null };
    } catch { return { record: null, error: "Cannot read the saved transaction. Check browser storage before sending." }; }
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const lock = useRef(false);
  const receipt = useWaitForTransactionReceipt({ hash: busy ? null : state.record?.hash ?? null });

  async function send(prepare: () => Promise<Prepared>) {
    if (lock.current || state.record || state.error) return;
    lock.current = true; setBusy(true); setError(null); setNotice(null);
    try {
      const update = await prepare();
      localStorage.setItem(key, JSON.stringify(update.record));
      setState({ record: update.record, error: null });
      await update.submit();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Update failed");
    } finally { lock.current = false; setBusy(false); }
  }
  function finish() {
    if (!receipt.data) return;
    try { localStorage.removeItem(key); setState({ record: null, error: null }); setError(null); }
    catch { setError("Could not clear the saved record"); }
  }
  async function archiveExpired() {
    if (lock.current || !state.record) return;
    const record = state.record;
    if (!window.confirm("Archive this expired update? Its past outcome may still be unknown. This does not resend or cancel it. Inspect its original hash before repeating the operation.")) return;
    lock.current = true; setBusy(true); setError(null);
    try {
      await archiveExpiredUpdate(client, record, key, localStorage);
      setState({ record: null, error: null });
      setNotice(`Archived ${record.hash} in browser storage. Its outcome is unresolved; inspect this hash before repeating the operation.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Recovery failed");
    } finally { lock.current = false; setBusy(false); }
  }
  return { pending: state.record, error: state.error ?? error, notice, busy, blocked: busy || Boolean(state.record || state.error), receipt, send, finish, archiveExpired };
}
```

The preparer returns a signed record and a submission function. This keeps the UI independent of how the signature was obtained. A failed storage write stops before submission. A later submission error retains the hash for observation.



## Build the small components

**src/Counter.tsx**

```tsx
import { addressFromHex, ExecResult } from "@groundhogchain/client";
import { contractViewQueryOptions, useClient } from "@groundhogchain/react";
import { useQuery } from "@tanstack/react-query";
import { Counter } from "./contracts/counter";
import type { Direction, useUpdate } from "./updates";

export function CounterPanel({ address, disabled, send }: {
  address: string; disabled: boolean; send(direction: Direction): void;
}) {
  const client = useClient();
  const counter = useQuery({
    ...contractViewQueryOptions({ client, method: Counter.v0_1.get, contract: addressFromHex(address) }),
    refetchInterval: 2_000,
  });
  return <section>
    {counter.isLoading ? <p>Reading counter…</p> : null}
    {counter.error ? <p role="alert">{counter.error.message}</p> : null}
    <p><output aria-label="Counter value">{counter.data?.value.toString() ?? "Not loaded"}</output></p>
    <button type="button" disabled={disabled || !counter.data || counter.data.value === 0n} onClick={() => send("decrement")}>Decrement</button>
    <button type="button" disabled={disabled || !counter.data} onClick={() => send("increment")}>Increment</button>
  </section>;
}

export function UpdateStatus({ update }: { update: ReturnType<typeof useUpdate> }) {
  return <section aria-label="Transaction">
    {update.busy ? <p>Preparing or submitting…</p> : null}
    {update.error ? <p role="alert">{update.error}</p> : null}
    {update.notice ? <p role="status">{update.notice}</p> : null}
    {update.pending ? <>
      <p>Original signer: {update.pending.account}</p>
      <p>Transaction: {update.pending.hash}</p>
      {update.receipt.data ? <>
        <p role="status">{update.receipt.data.execResult === ExecResult.ExecResultOK ? "Update committed" : "Execution failed"}</p>
        <button type="button" onClick={update.finish}>Finish</button>
      </> : <>
        <p>Waiting for a result. A timeout does not cancel the transaction.</p>
        {update.receipt.error ? <p role="alert">{update.receipt.error.message}</p> : null}
        <button type="button" disabled={update.busy || update.receipt.isFetching} onClick={() => void update.receipt.refetch()}>Check transaction</button>
        <button type="button" disabled={update.busy} onClick={() => void update.archiveExpired()}>Archive expired update</button>
      </>}
    </> : null}
  </section>;
}
```

**src/App.tsx**

```tsx
import { useClient } from "@groundhogchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { prepareDevelopment, useUpdate, type Config } from "./updates";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const update = useUpdate(config);
  return <main>
    <h1>Counter</h1>
    <p>Using development signer: {config.signerAddress ?? "Not configured"}</p>
    <CounterPanel address={config.counterAddress} disabled={update.blocked || !config.signerAddress}
      send={direction => void update.send(() => prepareDevelopment(client, config, direction))} />
    <UpdateStatus update={update} />
  </main>;
}
```



## Run and verify

In a second terminal inside `app`, leaving the API server running:

```bash
npm run dev
```

Open Vite’s URL. Click **Increment**, wait for **Update committed**, and confirm the refreshed counter value. Click **Finish** before another update. Try **Decrement** too.

The public read refreshes independently of signing. An error or timeout does not cause another transaction to be submitted. A saved hash remains available after reload; this minimal example keeps one unresolved update per counter and network in one browser tab.

If submission was stopped after signing, a receipt may never arrive. **Archive expired update** checks the original network, signed bytes, expiry height, and receipt before releasing the active slot. It preserves the complete record under `counter:NETWORK:CONTRACT:archived:HASH` in browser storage. It does not resend the transaction or prove it never committed: an unavailable or lagging indexer can still hide a past receipt. Inspect the original hash before repeating the operation. Recovery errors, including a failed archive write, keep the active record.

```bash
npm run build
```

**Checkpoint:** a working React counter using a server-held development signer. No wallet connection or keyboard/concurrency machinery is needed. Part 4 adds a different signing path to these same components.



## Work with an agent

```text
Follow Build a counter, part 3:
https://thruput.network/docs/tutorials/build-a-counter-with-react/
Create the listed files in my existing app directory. Do not clone an
examples repo. Verify reads, increment/decrement, transaction feedback,
and the build. Keep the development key on the server and retain an
unresolved transaction's hash instead of submitting a replacement.
```

---

## Build a counter, part 4: Connect a wallet

Source: <https://thruput.network/tutorials/connect-a-wallet-to-your-app/>

Let the user switch from the development signer to a connected wallet in the same counter application.

Keep the app from [part 3](../pages/tutorials/build-a-counter-with-react.md). It already works through the development signer. Add wallet controls so a successful connection switches new updates to the user’s wallet; explicit disconnect returns to the development signer.

The display, contract, public client, and transaction-status component stay the same. Only preparation and submission differ.



## Prepare the wallet

Install the [Wallet Extension](../pages/tools/wallet-extension.md) and select the app’s network. Request native test tokens for that wallet’s account; it is independent of the server’s development signer.

`WalletProvider` is already mounted from part 3. It discovers providers without requesting permission.



## Add wallet controls

**src/WalletControls.tsx**

```tsx
import { useWallet } from "@groundhogchain/react";

export function WalletControls({ busy, walletMode, disconnect }: {
  busy: boolean; walletMode: boolean; disconnect(): void;
}) {
  const wallet = useWallet();
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  return <section aria-label="Wallet connection">
    <label>Wallet <select name="wallet" value={wallet.provider?.info.id ?? ""}
      disabled={busy || connecting || wallet.providers.length === 0}
      onChange={event => wallet.selectProvider(event.target.value)}>
      <option value="" disabled>No wallet detected</option>
      {wallet.providers.map(provider => <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>)}
    </select></label>
    <button type="button" disabled={busy || connecting || !wallet.provider || wallet.status === "connected"}
      onClick={() => void wallet.connect()}>Connect wallet</button>
    {walletMode ? <button type="button" disabled={busy || connecting} onClick={disconnect}>Disconnect wallet</button> : null}
    {wallet.session && wallet.session.accounts.length > 1 ? <label>Account
      <select name="account" value={wallet.address ?? ""} disabled={busy || connecting}
        onChange={event => wallet.selectAccount(event.target.value)}>
        {wallet.session.accounts.map(account => <option key={account.address} value={account.address}>{account.address}</option>)}
      </select>
    </label> : null}
    {wallet.status === "wrongNetwork" ? <p role="alert">Select the app's network in your wallet.</p> : null}
    {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
  </section>;
}
```



## Add the wallet preparer

**src/wallet-update.ts**

```ts
import { addressFromHex, gasAmount } from "@groundhogchain/client";
import type { ProviderWalletClient } from "@groundhogchain/client/wallet";
import { Counter } from "./contracts/counter";
import type { Config, Direction, Prepared } from "./updates";

export async function prepareWallet(wallet: ProviderWalletClient, account: string, config: Config, direction: Direction): Promise<Prepared> {
  const transaction = await wallet.prepareExecution({
    invocation: Counter.v0_1[direction].invocation(addressFromHex(config.counterAddress), gasAmount(500_000n), { amount: 1n }),
    gasLimit: gasAmount(1_000_000n),
  });
  const signed = await wallet.signTransaction(transaction);
  return {
    record: { ...signed, account, networkId: config.networkId },
    submit: () => wallet.submitTransaction(signed),
  };
}
```

The same `useUpdate` hook saves the signed record before invoking `submit`. A wallet rejection prevents submission. The application never receives the wallet’s private key.



## Switch signing paths

Replace `src/App.tsx`:

**src/App.tsx**

```tsx
import { useEffect, useState } from "react";
import { useClient, useWallet, useWalletClient } from "@groundhogchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { WalletControls } from "./WalletControls";
import { prepareDevelopment, useUpdate, type Config, type Direction } from "./updates";
import { prepareWallet } from "./wallet-update";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const wallet = useWallet();
  const signingClient = useWalletClient();
  const update = useUpdate(config);
  const [selected, setSelected] = useState<"development" | "wallet">("development");
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";
  useEffect(() => { if (authorized) setSelected("wallet"); }, [authorized]);
  const walletMode = authorized || selected === "wallet";
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  const canSend = walletMode ? wallet.status === "connected" && signingClient !== null : config.signerAddress !== null;

  function disconnect() {
    void wallet.disconnect();
    setSelected("development");
  }
  function send(direction: Direction) {
    if (!canSend || connecting || update.blocked) return;
    if (walletMode) {
      if (!signingClient || !wallet.address) return;
      const originalClient = signingClient;
      const originalAccount = wallet.address;
      void update.send(() => prepareWallet(originalClient, originalAccount, config, direction));
    } else {
      void update.send(() => prepareDevelopment(client, config, direction));
    }
  }
  return <main>
    <h1>Counter</h1>
    <p>{walletMode ? "Using connected wallet" : "Using development signer"}: {walletMode ? wallet.address ?? "Unavailable" : config.signerAddress ?? "Unavailable"}</p>
    <WalletControls busy={update.busy} walletMode={walletMode} disconnect={disconnect} />
    <CounterPanel address={config.counterAddress} disabled={!canSend || connecting || update.blocked} send={send} />
    <UpdateStatus update={update} />
  </main>;
}
```

A successful connection selects wallet signing immediately. A later session loss or wrong network keeps wallet mode selected and pauses writes. It does not silently send through the development key. Explicit disconnect opts back into development signing.

Each update captures its original signing client and account. A receipt is observed through the public client, so disconnecting does not cancel an already-submitted transaction.



## Verify both paths

1. Open the app disconnected. Increment with the development signer and inspect its hash and result.
2. Connect your wallet on the correct network. Confirm the displayed account changes.
3. Increment again and approve the request in the wallet. Wait for the receipt and refreshed value.
4. Reject another approval. The page should show the error without sending through the development signer.
5. Disconnect explicitly. The development-signer label and immediate-update path return.

After a committed result, **Finish** clears its saved record. For an unresolved result, **Check transaction** observes the original hash without submitting again. Reload with a saved hash to verify recovery.

A session change can stop submission after the signed record was saved. Once the signed transaction expires, use **Archive expired update** from part 3 to preserve its evidence and release the active slot. This never switches signers, resubmits, or treats a missing receipt as proof of failure.

```bash
npm run build
```

**Checkpoint:** a small, complete app built without a repository clone. Its default signer is convenient for development, and connected users can approve their own transactions.

You can also explore the [full counter example on GitHub](https://github.com/groundhogchain/groundhog-examples/tree/main/apps/counter).



## Work with an agent

```text
Follow Build a counter, part 4:
https://thruput.network/docs/tutorials/connect-a-wallet-to-your-app/
Extend my part-3 app using the listed files. Keep development signing
as the default, switch on wallet connection, and return only on explicit
disconnect. Let me approve wallet requests. Verify both paths, rejection,
wrong-network handling, receipt recovery, and the build. Do not clone
the examples repo or add keyboard/concurrency features to this tutorial.
```

---

## Build a token

Source: <https://thruput.network/tutorials/build-a-token/>

Build and test an ERC-20 contract with balances, allowances, administrator-controlled supply, and standard events.

Build the `erc20` contract in the [examples repository](https://github.com/groundhogchain/groundhog-examples/tree/main/contracts/erc20). You will trace a transfer, exercise minting and allowances, and test both native and RV32 execution.

This is a contract guide. The [counter series](../pages/tutorials/build-a-counter.md) covers the full contract-to-application journey; [TypeScript](../pages/typescript.md) covers application interactions.



## Prepare the project

Complete [CLI and Cargo setup](../pages/cli/install.md), then clone the examples repository if you do not already have it:

```bash
git clone https://github.com/groundhogchain/groundhog-examples.git
cd groundhog-examples
```

Use the workspace’s manifests, toolchain, and lockfile together. The token implements the shared interface crates rather than copying their definitions.



## Model the token state

Open `contracts/erc20/src/implementation.rs`:

```rust
pub struct TokenContract {
    config: Value<Config>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Allowance>>,
    total_supply: Balance,
}
```

The storage attribute derives paths for these handles:

| Field          | Job                                             |
| -------------- | ----------------------------------------------- |
| `config`       | Administrator and optional token metadata       |
| `balances`     | Each account’s nonnegative token amount         |
| `allowances`   | An owner/spender pair’s remaining authorization |
| `total_supply` | Outstanding tokens                              |

Different map keys are independent. Balance changes use deltas instead of replacing a shared absolute value. See [Storage Types](../pages/programming-model/storage-types.md) for the merge rules.



## Follow a transfer

The implementation takes the payer from the direct caller:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let owner = get_caller();
    self._decrease_balance(&owner, amount);
    self._lazy_increase_balance(receiver, amount);
    TransferEvent::new(&owner, receiver, amount_to_diff(amount)).log();
}
```

The checked debit reports insufficient balance during execution. The credit records a relative increase. The event records the movement for applications; it is not the source of the contract’s balance state.

`transfer_from` first spends the caller’s allowance, then performs the same debit and credit. An allowance belongs to a specific owner/spender pair, not to every caller.



## Apply supply and allowance policy

Read the `mint`, `burn`, and `adjust_allowance` implementations:

- Minting and burning require the configured administrator.
- Initialization records that administrator and rejects a later initialization.
- Allowances change by a signed `difference`. A positive value adds authority; a negative value removes it.
- An exclusive allowance update requests sole write access to that entry for the block. It does not make a prior offchain read current.
- `clear_allowance` deletes an allowance; `clear_balance` requires an empty balance before deleting its row.

The metadata feature adds name, symbol, and decimals. The permit feature adds signed-operation authorization. Keep the basic transfer policy clear before extending either surface.



## Exercise the contract

```bash
cargo test -p erc20 --locked
```

`tests/test_native.rs` deploys the contract in the SDK environment and runs the shared scenarios under `tests/common`. Inspect those scenarios for administrator checks, minting, transfers, allowance spending, cleanup, and expected exceptions.

`tests/same_block.rs` tests behavior that a serial-only token test would miss:

| Scenario                                                  | Expected result                                             |
| --------------------------------------------------------- | ----------------------------------------------------------- |
| Compatible credits to one balance                         | Deltas merge                                                |
| Debits covered by the balance                             | Both can commit                                             |
| Combined debits exceed the balance                        | Reservation excludes an overdrawing transaction             |
| Read during the same block                                | Reads the block snapshot                                    |
| Approval and a separate spending transaction in one block | The new approval is not already spendable from the snapshot |

Run a specific case while inspecting the corresponding code:

```bash
cargo test -p erc20 --test same_block same_block_credits_merge --locked
```

**Checkpoint:** the native tests pass, including expected failure paths. A test that deliberately catches a contract exception can still be a passing test.



## Build and test the guest artifact

```bash
thruput build -p erc20
thruput test -p erc20
```

The build writes `target/thruput/erc20.rv32a` and spec sidecars. The artifact test exercises the compiled guest implementation. Keep it as well as the native tests.

You now have a deployable token artifact. Use [Deploy and call](../pages/cli/deploy-and-call.md) for network deployment and [Use contract bindings](../pages/tools/typescript-bindings.md) for typed application calls. The repository’s standard-token and factory examples add a fixed launch configuration for the separate launchpad application.



## Work with an agent

```text
Follow Build a token:
https://thruput.network/docs/tutorials/build-a-token/
Use contracts/erc20 in groundhog-examples with its workspace lockfile.
Trace administrator checks, transfers, allowances, and events in source.
Run the native, same-block, and RV32 tests. Report actual results and
artifact paths. Do not replace the standard interface with invented APIs.
```

---

## Build an AMM

Source: <https://thruput.network/tutorials/build-an-amm/>

Build and exercise a queued constant-product AMM, including liquidity, swaps, request outcomes, and RV32 tests.

Build the AMM contract suite in [groundhog-examples](https://github.com/groundhogchain/groundhog-examples). This guide creates pools, adds and removes liquidity, and executes swaps through its native and RV32 test environments. You will also verify that a failed queued request does not become a false success.

Read [Build a token](../pages/tutorials/build-a-token.md) first. Complete [CLI and Cargo setup](../pages/cli/install.md). Commands run from the examples repository root with its checked-in manifests and lockfile.



## Assemble the components

| Source                   | Responsibility                                      |
| ------------------------ | --------------------------------------------------- |
| `interfaces/swap-if`     | Shared methods, request types, errors, and clients  |
| `engines/swap-pair`      | Constant-product math and reserve operations        |
| `contracts/swap-handler` | Apply a request, move tokens, and update pair state |
| `contracts/swap-driver`  | Queue and process requests                          |
| `contracts/swap-factory` | Create and connect a pool’s contracts               |
| `contracts/swap-router`  | User-facing liquidity and swap requests             |
| `helpers/batch-driver`   | Shared queue capacity and processing logic          |

The pair is an internal engine used by the handler, not another public contract entry point. The suite adapts [Uniswap V2 pair operations](https://github.com/Uniswap/v2-core/blob/master/contracts/UniswapV2Pair.sol) to Stellar Thruput’s execution model.



## Create a pool

Run the factory’s deployment scenario:

```bash
cargo test -p swap-factory --test factory create_pair_brings_up_pool --locked
```

Open `contracts/swap-factory/src/factory.rs` and `tests/factory.rs`. Creation derives and funds three addresses, deploys the LP token, handler, and driver, initializes their relationships, and records the pair. The tests verify the resulting pool and funding rules.

The factory takes funding from the caller through an allowance. It does not let arbitrary pool creators spend the factory’s own native tokens. Pool addresses are deterministic for the token pair and configured code hashes.

**Checkpoint:** a pool is created in the test environment with its contracts connected correctly.



## Add liquidity

```bash
cargo test -p swap-router --test add_liquidity --locked -- --nocapture
```

In `contracts/swap-router/tests/add_liquidity.rs`, the fixture establishes token balances, authorizes the handler, submits a liquidity request, and processes it. The test helper named `etx` is example test code, not an SDK API:

```rust
etx.user_allow_for_pair(user, amounts_desired)?;
etx.advance_block();
etx.user_add_liquidity(ALICE, amounts_desired)?;
etx.process_outstanding_requests(1)?;
```

The tests also separate the purchaser from the recipient: Alice can supply tokens while Bob receives LP tokens. Assertions check both the mint event and the actual LP balance.



## Execute a swap

```bash
cargo test -p swap-router --test swap carol_swap_exact_tokens_for_tokens --locked -- --nocapture
```

Open `contracts/swap-router/tests/swap.rs`. The exact-input scenario:

1. Establishes pool reserves.
2. Calculates expected output independently of the router.
3. Grants the handler an allowance for the input amount.
4. Submits a request with a minimum output.
5. Processes the queue.
6. Checks both token balances, the consumed allowance, and unchanged LP ownership.

The corresponding exact-output test checks that the requested output is received without exceeding the input cap.

**Checkpoint:** the swap tests pass with real state and event assertions, not just a successful method return.



## Understand acceptance and execution



Every swap changes reserves. Concurrent transactions using the same snapshot cannot all replace those reserves with different values. The implementation separates accepting requests from executing reserve-dependent work:

```text
users → router → driver queue
                    ↓
             process_requests
                    ↓
                 handler → pair engine
```

Queue inserts can merge. Processing consumes requests serially inside one transaction, so each operation sees earlier updates in that transaction. The handler accepts work from its driver, and the driver accepts requests from the configured router.

An accepted request is not a completed swap. Submission returns a request ID and emits `RequestAccepted`. A later operation event or `RequestFailed` identifies its outcome.



## Verify failures and request IDs



```bash
cargo test -p swap-router --test request_id --locked
cargo test -p swap-router --test swap swap_limits_respected --locked
cargo test -p swap-driver --test authorization --locked
```

These checks verify that request IDs reach terminal events, slippage failures leave the user’s funds unchanged, and unauthorized calls cannot bypass the router/driver/handler chain.

Each request is handled with a gas cap and commit locking. A handled failure can roll back that request without taking down other requests in the processing transaction.



## Bound the queue and processing work



Queue capacity bounds pending storage. Consumption is checked during reservation across concurrent requests. An excluded submission returns to the mempool; it is not guaranteed a place in the next block.

Processing is permissionless and bounded by gas. The driver requires enough budget for the waiting work up to its configured minimum batch. It does not consume a request and then discard it merely because no processing budget remains.

```bash
cargo test -p swap-driver --test admission --locked
cargo test -p swap-driver --test min_batch --locked
cargo test -p swap-driver --test same_block --locked
```

These cases check queue limits, the minimum processing budget, and interactions with withdrawals and allowance changes. The source’s `process_requests_gas` helper supplies the budget calculation; do not copy a gas number from an unrelated operation.



## Remove liquidity

```bash
cargo test -p swap-router --test remove_liquidity --locked
```

The tests verify redemption and the distinction between the LP-token owner and the recipient of the withdrawn tokens. Run the complete native suite before changing the design:

```bash
cargo test -p swap-factory -p swap-router -p swap-driver -p swap-pair --locked
```



## Verify compiled contracts

Build the guest contracts used by the suite:

```bash
thruput build -p erc20
thruput build -p swap-factory
thruput build -p swap-handler
thruput build -p swap-driver
thruput build -p swap-router
cargo test -p swap-driver -p swap-router -p swap-factory --features guest_test --locked
```

`guest_test` runs the scenarios against the compiled RV32 implementations in the SDK test environment. It does not start a browser application or submit to Devnet.

**Checkpoint:** you have built the AMM and verified pool creation, liquidity, swaps, and failure behavior through native and guest execution. The repository also contains an application under `apps/swap`; this guide focuses on the contract suite.



## Work with an agent

```text
Follow Build an AMM:
https://thruput.network/docs/tutorials/build-an-amm/
Use the existing swap contract suite in groundhog-examples. Run pool,
liquidity, swap, slippage, request-ID, authorization, and queue tests.
Build the guest artifacts and rerun with guest_test. Explain how the
assertions establish each outcome. Do not equate request acceptance or
a successful processing transaction with completion of a specific swap.
```
