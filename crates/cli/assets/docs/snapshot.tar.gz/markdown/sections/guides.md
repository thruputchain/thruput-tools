# Guides

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Guides

Source: <https://docs.groundhog.dev/guides/>

Learn Groundhog through contract tutorials, application walkthroughs, and worked designs.

Build a project or work through a design. Choose a guide by the result you want, and use the product sections for individual commands and API details.



## Start with a counter

Start with the [contract quickstart](../pages/get-started/contract.md) for a working Devnet deployment, then continue with the detailed guides:

1. [Build a Counter](../pages/tutorials/build-a-counter.md) explains a small Rust contract, storage, errors, and tests.
2. [Develop Locally](../pages/tutorials/develop-locally.md) walks through deploying and calling the counter on a local node.
3. [Work with Groundhog from TypeScript](../pages/tutorials/work-with-groundhog-from-typescript.md) connects a typed client to a contract.
4. [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md) follows an event from its Rust definition through application queries.

For a hosted deployment, follow [Develop on Devnet](../pages/tutorials/develop-on-devnet.md).



## Explore another project

- **[Connect a Wallet to Your App](../pages/tutorials/connect-a-wallet-to-your-app.md)** builds a vanilla TypeScript interface for connecting a wallet, sending a transfer, and checking its receipt.
- **[Build a Token](../pages/tutorials/build-a-token.md)** is a contract tutorial covering storage, an interface implementation, and tests.
- **[Design a Swap](../pages/tutorials/design-a-swap.md)** is a design walkthrough covering request acceptance, execution, and batching. Read it for the design decisions rather than a complete application setup.



## Find example code

The [Groundhog examples repository](https://github.com/groundhogchain/groundhog-examples) contains contract and application examples. Use each example’s README for its setup, supported dependencies, and checks.

For your first setup, start with [Get Started](../pages/get-started.md).

---

## Add Events to a Contract

Source: <https://docs.groundhog.dev/tutorials/add-events-to-a-contract/>

Tutorial: define an event, emit it from a Groundhog contract, test it, and find it in the contract spec and on chain.

We’re extending the counter from [Build a Counter](../pages/tutorials/build-a-counter.md) with a `CounterIncremented` event: define the event type, declare it as part of the contract’s interface, emit it, assert on it in a test, find it in the contract spec, and query it over JSON-RPC.

**Prerequisites:** A working counter contract from [Build a Counter](../pages/tutorials/build-a-counter.md). For the application steps, complete [TypeScript package setup](../pages/typescript/setup.md) and read [Use contract bindings](../pages/tools/typescript-bindings.md) first.

For contract-only guidance, see [Events](../pages/contracts/events.md).



## How Events Work on Groundhog

An event is up to three 32-byte **topics** plus a CXS-serialized **payload** (at most 1 KB in total). Topics are indexed: off-chain consumers filter on them via [`groundhog_getEvents`](../pages/reference/json-rpc-api.md#groundhog_getevents). The payload is not indexed; it carries the data you want to read back.

Topic 0 is always the event’s **signature**, a hash that identifies the event type, so up to two topics are available for your own fields. There is no `indexed` keyword as in Solidity: you mark struct fields with `#[topic]`.



## Step 1: Define the Event

Add the event type to `src/implementation.rs`:

```rust
#[derive(Event, Clone, Debug)]
pub struct CounterIncremented<'a> {
    #[topic]
    pub by: &'a ContractAddress,
    pub amount: u64,
}
```

- **`#[derive(Event)]`** generates the signature, topic/payload encoding, and typed decoding view. See [SDK Macros](../pages/reference/sdk-macros.md#deriveevent) or [`#[derive(Event)]` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/derive.Event.html).
- **`#[topic]`** makes `by` an indexed topic (topic 1), so consumers can filter events by address. Fields without the attribute, here `amount`, go into the payload.
- **The lifetime** lets the topic borrow the address. Addresses, fixed 32-byte values, supported integer scalars, `U256`, `I256`, and bool have direct topic encodings. Strings and byte slices are hashed; keep their original value in the payload if consumers need it. See [topic encodings](../pages/typescript/events.md#filter-topics).



## Step 2: Declare and Emit It

Declare the event on the `#[contract]` attribute and emit it from `increment`:

```rust
#[contract(
    throws = CounterError,
    emits(PingEvent, CounterIncremented)
)]
impl Counter {
    pub fn initialize(&mut self, initial_value: u64) {
        self.value.strict_inc(initial_value as i128);
    }

    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
        let caller = get_caller();
        log_event(&CounterIncremented { by: &caller, amount });
    }

    // decrement and get are unchanged
}
```

The generated counter already declares and emits `PingEvent`. Keep it in the `emits(...)` list unless you also remove the scaffold’s `ping` method. Export the new event from `src/lib.rs` so integration tests can import it:

```rust
pub use implementation::CounterIncremented;
```

- **`emits(CounterIncremented)`** declares the event as part of the contract’s interface, which records it in the [contract spec](../pages/reference/contract-spec.md#events) so codegen and indexers can decode it. Like `throws`, `emits` belongs on the interface: the trait definition or inherent impl, never a trait impl.
- **[`log_event`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/event/fn.log_event.html)** emits topics and payload through `LogEvent`. Events become part of the block’s event trie; contracts cannot read them back.
- **`get_caller()`** returns the address of the immediate caller, which becomes the event’s indexed topic.



## Step 3: Test It

Every event emitted during a test transaction is captured on the `TransactResult` that `env.transact` returns. Add to `tests/test.rs`:

```rust
use sdk::*;

use counter::{CounterClient, CounterIncremented, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

#[test]
fn test_increment_emits_event() {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();

    let result = env.transact(|tx| {
        tx.call(&ContractAddress::named("test")).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);
            client.initialize(10);
            client.increment(5);
        })
    });
    result.assert_success();

    // initialize emits nothing; increment emits exactly one event
    result.assert_event_count(1);
    result.assert_event::<CounterIncremented>(0, |event| {
        assert_eq!(event.topic(0), Some(CounterIncremented::SIGNATURE));
        let by: &ContractAddress = event.topic(1).unwrap().into();
        assert_eq!(by, &ContractAddress::named("test"));
        assert_eq!(event.payload().amount, 5);
    });
}
```

Walking through the assertions:

1. **`assert_event_count(1)`** counts every event the transaction emitted, across all contracts it touched.
2. **`assert_event::<CounterIncremented>(0, ...)`** decodes the event at index 0 as a `CounterIncremented` and hands you a typed view.
3. **`event.topic(0)`** is the signature; `CounterIncremented::SIGNATURE` is the constant the derive generated.
4. **`event.topic(1)`** is the `by` field. A 32-byte topic converts back to `&ContractAddress` with `.into()`. The caller is the address the transaction originated from: `ContractAddress::named("test")`.
5. **`event.payload()`** is the decoded `CounterIncrementedPayload`; payload fields are read back directly.

Run it:

```bash
cargo test
```



## Step 4: Find It in the Spec

Build the contract:

```bash
groundhog build
```

The build writes `counter.spec.json` for inspection and canonical `counter.spec.xdr` for codegen. Inspect the event’s structured spec identity, signature, topic `by`, and payload field `amount`. Use that generated signature for topic 0 instead of copying a hash from another crate/version. See [Contract Spec](../pages/reference/contract-spec.md).

Anything that consumes the spec now understands the event. Generate [TypeScript bindings](../pages/tools/typescript-bindings.md) from the RV32 spec sidecar:

```bash
mkdir -p web/src/contracts
groundhog codegen ts target/groundhog/counter.spec.xdr \
  --output web/src/contracts/counter.ts
```

The generated `CounterIncremented` descriptor builds a typed filter, decodes matching events, and extracts events from transaction receipts:

```ts
import { counter } from "./contracts/counter.js";
const { CounterIncremented } = counter.v0_1.implementation;

const filter = CounterIncremented.filter({
  contractAddresses: [contract],
  topics: { by: caller },
});

const decoded = CounterIncremented.decode(event);
if (decoded) {
  console.log(decoded.topics.by, decoded.fields.amount);
}

const matches = CounterIncremented.allFromReceipt(receipt, {
  contractAddress: contract,
});
const match = CounterIncremented.singleFromReceipt(receipt, {
  contractAddress: contract,
});
```

`decode()` returns `null` when the signature differs and throws for malformed data with the matching signature. `allFromReceipt()` returns every matching event from the selected emitter. `singleFromReceipt()` requires exactly one match. Each receipt match retains its emitting `contractAddress`.



## Step 5: Query It On Chain

After deploying (see [Develop Locally with the CLI](../pages/tutorials/develop-locally.md#6-dry-run-and-deploy) for the deploy flow) and calling `increment`, the event is queryable through the gateway. Filter on the contract address and the signature from the spec as `topic0`, with a `0x` prefix:

```json
{
  "jsonrpc": "2.0",
  "method": "groundhog_getEvents",
  "params": [
    {
      "filters": [
        {
          "contractAddresses": ["0x<64-character-contract-address>"],
          "topics": {
            "topic0": [
              "0x<signature-from-your-generated-descriptor>"
            ],
            "topic1": [],
            "topic2": []
          }
        }
      ],
      "order": "descending",
      "anchor": { "kind": "atEnd" },
      "cursor": "0x",
      "limit": 50
    }
  ],
  "id": 1
}
```

Each returned event carries its topics (topic 1 is the caller’s address, directly comparable) and the CXS payload (`amount`). To filter on a *specific* caller, put that address in `topic1`. See [`groundhog_getEvents`](../pages/reference/json-rpc-api.md#groundhog_getevents) for pagination and filter semantics.

Replace the address and signature placeholders above before sending the request. With the TypeScript client, use the generated filter instead:

```ts
const page = await client.getContractEvents({
  event: CounterIncremented,
  contractAddresses: [contract],
  topics: { by: caller },
  order: "ascending",
  limit: 20,
}, { signal });
for (const event of page.events) {
  console.log(event.txHash, event.blockHeight, event.sequenceNumber, event.fields.amount);
}
```

This fetches exactly one typed page. See [Read events](../pages/typescript/events.md) for generated filters, typed decoding, and multi-page iteration. The next section adds application-owned persistence to that query.



## Resume Without Missing Events

A cursor continues one bounded historical walk. It does not follow blocks added later. Raw JSON-RPC uses `"0x"` to start and returns `"0x"` at exhaustion; the TypeScript client uses an empty `Uint8Array`. An empty page alone is not exhaustion. Raw continuation requests still require `order` and `anchor`, even though the cursor contains continuation state. Keep the network, target, and filters fixed.

Store rows and progress in one database transaction. For events, use a unique key of `(txHash, sequenceNumber)` within the network/query’s store. Transaction-reference pages can use `txHash`; their query matches root invocation targets, not every address touched by a transaction.

Use an ascending query with application-owned storage. Use one store per network and query; changing filters needs a separate store or an explicit rebuild.

| Application method               | Responsibility                                                                                                         |
| -------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `store.loadProgress()`           | Return the saved `{ height, cursor }`, or `undefined` for a new scan. Heights are bigint and cursors are `Uint8Array`. |
| `store.savePage(rows, progress)` | Upsert rows by their stable identity and save progress in the **same database transaction**.                           |

```ts
const query = {
  filters: [CounterIncremented.filter({ contractAddresses: [contract] })],
  order: "ascending" as const,
  limit: 20,
};
const saved = await store.loadProgress();
let height = saved?.height ?? 0n;

for await (const page of client.iterateEventPages({
  ...query,
  anchor: { height },
  cursor: saved?.cursor ?? new Uint8Array(),
}, { signal })) {
  if (page.oldestBlock > height) {
    throw new Error("History gap: required blocks are no longer retained");
  }
  const last = page.events.at(-1);
  if (last) height = last.blockHeight;
  await store.savePage(page.events, { height, cursor: page.cursor.slice() });
}
```

The store methods are application code, not SDK APIs. A non-empty saved cursor resumes the old walk. An empty one starts a fresh scan at the saved height. Serialize heights and cursor bytes exactly, and test interruption and replay against your database implementation.

For example, block 100 contains events A and B on different pages:

1. Save A and its continuation cursor together. The last stored row height is 100.
2. If the process stops, resume that exact saved walk when its cursor is valid.
3. If starting a fresh scan, start inclusively at height 100, not 101. Upsert A again and store B. This prevents losing the unfinished part of the block.
4. After exhaustion, a later call starts a new walk at the last stored height. It rereads that block, deduplicates it, and can discover newer blocks.

`latestBlock` is the indexer’s head at response time, not proof that you processed every matching row through that height. Never set the application checkpoint to it. An empty completed walk may leave the last-row checkpoint unchanged.

Check `oldestBlock` before accepting data as complete. If retention has removed needed history, report a gap and choose an explicit rebuild/archive policy. Current indexers do not reliably reject malformed cursors: corrupt bytes can look like an exhausted walk. Preserve cursors exactly; do not decode them in the client or silently restart on arbitrary errors. These checks do not prove that corrupted or pruned history is recoverable.



## Next Steps

- [Contract Spec](../pages/reference/contract-spec.md) for the full spec format the event landed in
- [SDK Macros](../pages/reference/sdk-macros.md#deriveevent) for `#[derive(Event)]` details, including `#[event_spec(export)]` for library-emitted events
- [TypeScript Bindings](../pages/tools/typescript-bindings.md) to generate a typed client that knows about your event
- [Build a Token](../pages/tutorials/build-a-token.md) for a contract emitting standard ERC-20 events

---

## Build a Counter

Source: <https://docs.groundhog.dev/tutorials/build-a-counter/>

Tutorial: build a counter contract on Groundhog, step by step.

We’re building the counter contract generated by `groundhog new`. It has initialize, increment, decrement, and get operations, plus a small event example and an explicit error example. The counter demonstrates the core idea: use `strict_inc` to record a change instead of replacing the counter with a newly calculated value. Concurrent changes can then combine.

**Prerequisites:** [Install the CLI](../pages/cli/install.md) and configure Cargo access. For a short deployment walkthrough before studying the code, follow the [contract quickstart](../pages/get-started/contract.md).

CLI `0.19.0` generates a project pinned to SDK `0.41.1`. Keep the generated files and compiler toolchain; the explanation below is not a replacement scaffold.



## What You’ll Build

A contract with four core counter methods and two scaffold examples:

| Method       | Signature                         | What it does                                                         |
| ------------ | --------------------------------- | -------------------------------------------------------------------- |
| `initialize` | `(&mut self, initial_value: u64)` | Add the initial amount. Call it once after deployment by convention. |
| `increment`  | `(&mut self, amount: u64)`        | Add to the counter                                                   |
| `decrement`  | `(&mut self, amount: u64)`        | Subtract from the counter (aborts if result would be negative)       |
| `get`        | `(&self) -> u64`                  | Read current value                                                   |
| `ping`       | `(&self, tag: u64)`               | Emit a simple event                                                  |
| `error`      | `(&self) -> u64`                  | Throw the declared contract error                                    |



## Step 1: Project Setup

Create a new contract crate:

```bash
groundhog new counter
cd counter
```

Keep the generated `Cargo.toml` and `rust-toolchain.toml`. The manifest declares:

- the library contract and RV32 entrypoint binary;
- separate host and RV32 SDK dependencies, with the versions selected by the CLI;
- the `entrypoints`, `dev`, and `groundhog-integration-test` features used by the tooling;
- a self-dependency that enables `dev` for native tests.

Do not copy a dependency block from another release into this project. Inspect the manifest generated on your machine when you need its exact versions or feature settings.

Your `src/lib.rs`:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;

pub use implementation::Counter;
pub use implementation::CounterClient;
```

The crate is `no_std` whenever the `dev` feature is disabled. The generated self-dependency enables `dev` for native tests; it is not a default feature. The host SDK dependency enables `std`, while the RV32 SDK dependency remains suitable for guest builds.



## Step 2: Define the Error Type

Contracts need a contract exception type only when they declare domain exceptions through `throws`. The generated counter includes one as an example. `#[contract_exception]` derives serialization for CXS encoding, and each variant maps to an integer discriminant.

```rust
use sdk::storage::NNInt;
use sdk::*;

#[contract_exception]
pub enum CounterError {
    NotAuthorized = 1,
}
```

This counter doesn’t use authorization, so `NotAuthorized` is a placeholder exercised by the scaffold’s `error` method. A contract without domain exceptions can omit `throws` and the exception type. Storage failures, such as a counter going below zero, remain SDK library exceptions.

The scaffold also includes a tiny event type:

```rust
#[derive(Event, Clone, Debug)]
pub struct PingEvent {
    #[topic]
    pub tag: u64,
}
```

`#[topic]` marks the field as an indexed event topic. The full event flow is covered in [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md).



## Step 3: Define Storage

```rust
#[derive(Debug)]
#[sdk::storage]
pub struct Counter {
    value: NNInt,
}
```

The `#[sdk::storage]` macro derives a storage path for each field. The field’s storage type handles reads and writes. [`NNInt`](../pages/programming-model/storage-types.md#nnint) is Groundhog’s integer storage type for signed changes. Those [deltas can merge](../pages/programming-model/execution.md#merged-deltas) across concurrent transactions.

One field is all this contract needs. More complex contracts use `Map<K, V>` for key-value storage (see [Build a Token](../pages/tutorials/build-a-token.md)).



## Step 4: Implement the Contract

```rust
#[contract(throws = CounterError, emits(PingEvent))]
impl Counter {
    pub fn initialize(&mut self, initial_value: u64) {
        self.value.strict_inc(initial_value as i128);
    }

    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn decrement(&mut self, amount: u64) {
        self.value.strict_inc(-(amount as i128));
    }

    pub fn get(&self) -> u64 {
        self.value.try_get().none_if_missing().unwrap_or(0) as u64
    }

    pub fn ping(&self, tag: u64) {
        log_event(&PingEvent { tag });
    }

    pub fn error(&self) -> u64 {
        throw(CounterError::NotAuthorized);
    }
}
```

Line by line:

- **`#[contract(throws = CounterError, emits(PingEvent))]`** generates contract entrypoints, a `CounterClient` struct for cross-contract calls and testing, and spec metadata for the declared error and event. The client name defaults to `{StructName}Client`. You can override it with `client = CustomName` if needed.

- **`strict_inc(delta)`** records a signed change. `increment(5)` records `+5`, while `decrement(5)` records `-5`. Concurrent calls can combine those changes instead of competing to replace the counter with different final values. `strict_inc` takes `i128`, so the scaffold casts the `u64` amount and negates it for decrements.

- **`strict_inc` aborts on underflow.** If the counter is at 3 and you call `decrement(5)`, the result would be -2. `NNInt` rejects the change and the transaction aborts automatically. You don’t need to check for this.

- **`try_get().none_if_missing().unwrap_or(0)`** reads the current value. `try_get()` returns `Result<i128, LibraryExn>`, so a bare `unwrap_or(0)` would report zero for every read error, not just a never-incremented counter. `none_if_missing()` converts only absence into `None` and re-throws anything else, so a wrong-type slot or an overflowed accumulation surfaces instead of looking like a legitimate zero.

- **`as u64` narrows the stored value.** `NNInt` stores `i128`, so a value above `u64::MAX` would truncate in this scaffold. A production counter should return `i128` or perform a checked conversion with a domain error.

- **`initialize` is not automatic or guarded.** Deployment and initialization are separate calls. Calling `initialize(10)` twice adds 20 because the scaffold does not store an initialized flag.

- **`&self` vs `&mut self`**: `get` takes `&self` (read-only), so it reads from the snapshot without recording a storage change. `initialize`, `increment`, and `decrement` take `&mut self` to update state. `ping` and `error` also take `&self`.

- **`ping` and `error`**: these are scaffold examples for events and explicit exceptions. They are not part of the counter logic, but they give you working code to modify.



## Step 5: Test It

The scaffold creates `tests/test.rs`:

```rust
use sdk::*;

use counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            assert_eq!(client.get(), 10);

            client.increment(5);
            assert_eq!(client.get(), 15);

            client.decrement(3);
            assert_eq!(client.get(), 12);
        })
    })
    .assert_success();
}
```

Breaking down the test setup:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled. Good for logic tests.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()` in your `lib.rs` and available when the `dev` feature is enabled.
3. **`test_contract.as_hash().clone()`** gets the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from; `.assert_success()` panics with details if the transaction did not commit. The returned `TransactResult` also records emitted events. See [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md).
5. **`deploy_contract`** deploys the contract and returns its address. The nonce (`SHA256Hash`) makes the address deterministic across test runs.
6. **`CounterClient::new`** creates a typed client. Methods return values directly (no `Result` unwrapping needed).

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) instead when the test should exercise the normal storage cost model. Use `TestEnvironment::new(Some(&model))` for custom cost-model tests. For the generated SDK reference, see [Rust API Docs](../pages/tools/rust-api-docs.md).



### Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
#[test]
fn test_counter_underflow() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter_underflow");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(5);

            // Decrementing by 10 should abort: strict_inc rejects a negative result
            assert_eq!(
                client.try_decrement(10).unwrap_err().try_as(),
                Some(LibraryExn::NonNegativeIntUnderflow),
            );
        })
    })
    .assert_success();
}
```

The `try_decrement` method (generated by the `#[contract]` macro alongside `decrement`) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`; `try_as` decodes the caught exception as whichever exception type you name, here the SDK’s own `LibraryExn`, which is matched exactly like a contract’s error type.



### Native Logic vs RV32 Integration

Run the fast native tests first:

```bash
cargo test
```

Then build the deployable RV32 artifact:

```bash
groundhog build
```

The scaffold includes `tests/integration.rs`. Run it against an ephemeral local node:

```bash
groundhog test --integration
```

That command deploys RV32 with the runtime’s lowest-index `local_user`, normally `dev-1`, and sets `GROUNDHOG_INTEGRATION_TEST=1` to activate the scaffolded test. It also provides `GROUNDHOG_RPC_URL`, `GROUNDHOG_CONTRACT_ADDRESS`, `GROUNDHOG_PROFILE`, `GROUNDHOG_DEFAULT_KEY`, and `GROUNDHOG_RUNTIME_MANIFEST` to the integration test process. Plain `groundhog test` runs the generated executor-backed RV32 test.



## Why This Matters

This counter is small, but the pattern scales. If 1,000 admitted transactions increment the same counter by 1, their changes can combine to `+1000`. Block capacity and scheduling still determine how many transactions are admitted, and decrements still cannot take an ordinary counter below zero.



## Next Steps

- [Build a Token](../pages/tutorials/build-a-token.md) for a full ERC-20 implementation using the same patterns
- [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md) to extend this counter with an emitted event
- [Storage Types](../pages/programming-model/storage-types.md) for `Balance`, `NNInt`, `CapacityConstraint`, `Map`, `Vector`, `Value`, `Bytestring`, and `RCQ`
- [NNInt and concurrent updates](../pages/programming-model/nnint.md) for the underlying merge rules
- [SDK Macros](../pages/reference/sdk-macros.md) for details on `#[contract]`, `#[contract_exception]`, `#[storage]`

---

## Build a Token

Source: <https://docs.groundhog.dev/tutorials/build-a-token/>

Build an ERC-20-compatible token with the Groundhog SDK and standard interface crate.

This tutorial builds an ERC-20-compatible token with transfers, allowances, minting, burning, and standard events. Balances, allowances, and total supply use `Balance`, the SDK’s nonnegative, zero-defaulting interface over Groundhog’s mergeable integer storage. Its [deltas can merge](../pages/programming-model/execution.md#merged-deltas) across concurrent transfers.

**Prerequisites:** Complete [Build a Counter](../pages/tutorials/build-a-counter.md) first.

> **note: Version checked**
>
> This tutorial uses CLI `0.19.0`, SDK `0.41.1`, and `groundhog-erc20-if` `0.1.41`.



## 1. Create the Project

Start from the minimal CLI template:

```bash
groundhog new erc20 --template stub
cd erc20
```

The generated RV32 wrapper and Groundhog profiles can remain unchanged. This tutorial replaces the library implementation and native test. The generated RV32 test only deploys the artifact, so it keeps passing; remove it if you would rather not carry it:

```bash
rm tests/test_rv32.rs
```

Now make two edits to the generated `Cargo.toml`. Extend the `dev` feature so it forwards to the interface crate:

```toml
[features]
dev = ["sdk/dev", "groundhog-erc20-if/dev"]
```

and add the interface crate. The generated manifest declares `sdk` twice, once per target, because it needs `std` on the host and forbids it on the guest. `groundhog-erc20-if` needs no such split, so add it as a plain dependency rather than editing either `[target.'cfg(...)']` block:

```toml
[dependencies]
groundhog-erc20-if = { version = "=0.1.41", registry = "groundhog" }
```

Leave the rest of the generated manifest alone. In particular keep the `groundhog-integration-test` feature and the `[target.'cfg(not(target_arch = "riscv32"))'.dependencies]` block: `tests/integration.rs` is gated on them, and removing them makes `groundhog test --integration` fail with cargo’s “package does not have the feature”.

The interface crate is the source of truth for:

- `ERC20` and `ERC20Client`
- `Amount = u128` and `Difference = i128`
- `ERC20Error`
- `TransferEvent`, `AllowanceChangeEvent`, `MintEvent`, `BurnEvent`, and their `.log()` methods

Its interface declares `ERC20Error` and those four events, so implementations and generated clients share the same wire contract. Version 0.1.41 uses signed allowance deltas with optional exclusive locking and explicit cleanup.



## 2. Wire the Library

Replace `src/lib.rs`:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

sdk::declare_mock_contract!();

mod implementation;

pub use groundhog_erc20_if::{ERC20, ERC20Client};
pub use implementation::TokenContract;
```

`declare_mock_contract!()` generates `register_mock_contract` for native tests. The standard interface remains in its own crate rather than being copied into this project.



## 3. Define Storage

Replace `src/implementation.rs` with these imports and storage types:

```rust
use groundhog_erc20_if::*;
use sdk::storage::{Balance, Deletable, Map, Value};
use sdk::*;

type Allowance = Balance;

#[contract_type]
#[cfg_attr(feature = "dev", derive(Debug))]
pub struct Config {
    pub administrator: ContractAddress,
}

#[sdk::storage]
#[cfg_attr(feature = "dev", derive(Debug))]
pub struct TokenContract {
    config: Value<Config>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Allowance>>,
    total_supply: Balance,
}
```

The fields have distinct jobs:

| Field          | Purpose                                           |
| -------------- | ------------------------------------------------- |
| `config`       | Stores the administrator that can mint and burn.  |
| `balances`     | Maps each account to a zero-defaulting `Balance`. |
| `allowances`   | Maps owner and spender pairs to `Balance` values. |
| `total_supply` | Tracks all outstanding tokens in a `Balance`.     |

[`Value<Config>` and `Map`](../pages/programming-model/storage-types.md) provide typed storage and key-derived paths. `Balance` accepts nonnegative `u128` amounts and exposes increase and decrease operations instead of signed arithmetic or an absolute `set`.



## 4. Add Storage Helpers

Continue in `src/implementation.rs`:

```rust
impl TokenContract {
    fn init(&mut self, administrator: &ContractAddress) {
        if self.config.try_get().none_if_missing().is_some() {
            throw(ERC20Error::AlreadyInitialized);
        }

        self.config.set(&Config {
            administrator: *administrator,
        });
    }

    fn administrator(&self) -> ContractAddress {
        self.config.get().administrator
    }

    fn balance_of(&self, owner: &ContractAddress) -> Amount {
        self.balances.at(owner).get()
    }

    fn lazy_increase_balance(
        &mut self,
        owner: &ContractAddress,
        amount: Amount,
    ) {
        self.balances
            .at_mut(owner)
            .try_lazy_increase(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn decrease_balance(&mut self, owner: &ContractAddress, amount: Amount) {
        self.balances
            .at_mut(owner)
            .try_decrease(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn allowance_of(
        &self,
        owner: &ContractAddress,
        spender: &ContractAddress,
    ) -> Amount {
        self.allowances.at(owner).at(spender).get()
    }

    fn adjust_allowance_by(
        &mut self,
        owner: &ContractAddress,
        spender: &ContractAddress,
        diff: Difference,
        exclusive: bool,
    ) {
        let mut owner_allowances = self.allowances.at_mut(owner);
        let mut allowance = if exclusive {
            owner_allowances.at_mut_exclusive(spender)
        } else {
            owner_allowances.at_mut(spender)
        };
        let result = if diff >= 0 {
            allowance.try_increase(diff as u128)
        } else {
            allowance.try_decrease(diff.unsigned_abs())
        };
        result.unwrap_or_else(|_| throw(ERC20Error::TooLarge));

        AllowanceChangeEvent::new(owner, spender, diff).log();
    }

    fn increase_total_supply(&mut self, amount: Amount) {
        self.total_supply
            .try_increase(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn decrease_total_supply(&mut self, amount: Amount) {
        self.total_supply
            .try_decrease(amount)
            .unwrap_or_else(|_| throw(ERC20Error::TooLarge));
    }

    fn supply(&self) -> Amount {
        self.total_supply.get()
    }
}
```

The helpers preserve the interface’s error and storage behavior:

1. A missing `Balance` reads as zero, so balance, allowance, and supply getters do not need missing-storage handling.
2. The standard interface requires overdrafts and overflows to surface as `ERC20Error::TooLarge`. The `try_` methods let the helpers translate SDK library failures into that domain error.
3. Both checked and lazy operations record mergeable deltas. Checked `decrease` loads the sender so insufficient funds fail during contract execution. `lazy_increase` skips the receiver load and leaves its bound check to delta reservation after the contract returns.

> **note: Checked and lazy failures happen at different points**
>
> Suppose a sender’s snapshot balance is 10. `try_decrease(11)` returns `Err` while the contract is running, so `decrease_balance` can translate it into `ERC20Error::TooLarge`.
>
> Now suppose a receiver’s snapshot balance is `Balance::MAX`, with no offsetting debit in the proposed block. `try_lazy_increase(1)` returns `Ok(())` inside the contract because it does not load that snapshot balance. After the contract returns, the completed delta batch cannot satisfy the balance bound, so the transaction is excluded and returned to the mempool.
>
> The distinction is when the snapshot-bound result becomes known. Both checked and lazy calls still produce deltas that can merge with compatible transactions. A lazy call can still reject an amount that cannot be represented or accumulated within the transaction.



## 5. Implement the Interface

Add the implementation below the helpers:

```rust
#[contract(version = "0.1.5")]
impl ERC20 for TokenContract {
    fn initialize(&mut self, administrator: &ContractAddress) {
        self.init(administrator);
    }

    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let owner = get_caller();

        self.decrease_balance(&owner, amount);
        self.lazy_increase_balance(receiver, amount);
        TransferEvent::new(&owner, receiver, amount_to_diff(amount)).log();
    }

    fn transfer_from(
        &mut self,
        owner: &ContractAddress,
        receiver: &ContractAddress,
        amount: Amount,
    ) {
        let spender = get_caller();
        let diff = amount_to_diff(amount);

        if owner != &spender {
            self.adjust_allowance_by(owner, &spender, -diff, false);
        }
        self.decrease_balance(owner, amount);
        self.lazy_increase_balance(receiver, amount);
        TransferEvent::new(owner, receiver, amount_to_diff(amount)).log();
    }

    fn adjust_allowance(
        &mut self,
        spender: &ContractAddress,
        difference: Difference,
        exclusive: bool,
    ) {
        let owner = get_caller();
        self.adjust_allowance_by(&owner, spender, difference, exclusive);
    }

    fn clear_allowance(&mut self, spender: &ContractAddress) {
        let owner = get_caller();
        let remaining = amount_to_diff(self.allowance_of(&owner, spender));
        self.allowances.at_mut(&owner).at_mut(spender).delete_exclusive();
        AllowanceChangeEvent::new(&owner, spender, -remaining).log();
    }

    fn clear_balance(&mut self) {
        let owner = get_caller();
        ensure(self.balance_of(&owner) == 0, ERC20Error::BalanceNotZero);
        self.balances.at_mut(&owner).delete_exclusive();
    }

    fn allowance(
        &self,
        owner: &ContractAddress,
        spender: &ContractAddress,
    ) -> Amount {
        self.allowance_of(owner, spender)
    }

    fn get_balance_of(&self, owner: &ContractAddress) -> Amount {
        self.balance_of(owner)
    }

    fn get_balance(&self) -> Amount {
        self.balance_of(&get_caller())
    }

    fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
        ensure(
            get_caller() == self.administrator(),
            ERC20Error::MustBeContractOwner,
        );

        // Establish the checked supply bound first. Once it holds, the lazy
        // receiver increase cannot overflow an individual balance.
        self.increase_total_supply(amount);
        self.lazy_increase_balance(receiver, amount);
        MintEvent::new(receiver, amount_to_diff(amount)).log();
    }

    fn burn(&mut self, owner: &ContractAddress, amount: Amount) {
        ensure(
            get_caller() == self.administrator(),
            ERC20Error::MustBeContractOwner,
        );

        self.decrease_balance(owner, amount);
        self.decrease_total_supply(amount);
        BurnEvent::new(owner, amount_to_diff(amount)).log();
    }

    fn total_supply(&self) -> Amount {
        self.supply()
    }
}
```

Deployment does not call `initialize` automatically. Call it once afterward. The stored config enforces one-time initialization.

Mint and burn are restricted to the administrator. `transfer_from` spends allowance when caller and owner differ. `clear_allowance` revokes and deletes one pair; `clear_balance` deletes only an empty balance. This minimal token keeps released storage funding at the contract; a production token should define any caller-refund policy explicitly.

Allowance adjustments with `exclusive=false` can merge within bounds. With `exclusive=true`, competing writes to that pair conflict. An off-chain read followed by a signed delta is still not an exact-target update; the read may be old before the transaction starts.



## 6. Test the Contract

Replace `tests/test.rs`:

```rust
use erc20::{register_mock_contract, ERC20Client};
use sdk::*;

static NONCE: SHA256Hash = sdk::sha256_static!("ERC20_TUTORIAL_NONCE");

#[test]
fn transfer_updates_balances_and_supply() {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = test_contract.as_hash().clone();

    let alice = ContractAddress::named("alice");
    let bob = ContractAddress::named("bob");

    env.transact(|tx| {
        tx.call(&alice).run(move || {
            let address = deploy_contract(&NONCE, &contract_hash);
            let token = ERC20Client::new(&address);
            let owner = get_current_address();

            token.initialize(&owner);
            token.mint(&owner, 1_000);
            token.transfer(&bob, 100);

            assert_eq!(token.get_balance_of(&owner), 900);
            assert_eq!(token.get_balance_of(&bob), 100);
            assert_eq!(token.total_supply(), 1_000);

            token.adjust_allowance(&bob, 25, false);
            token.adjust_allowance(&bob, -5, true);
            assert_eq!(token.allowance(&owner, &bob), 20);
            token.clear_allowance(&bob);
            assert_eq!(token.allowance(&owner, &bob), 0);
            token.burn(&owner, 900);
            token.clear_balance();
            assert_eq!(token.get_balance_of(&owner), 0);
            assert_eq!(token.total_supply(), 100);
        })
    })
    .assert_success();
}
```

Run the native test and build the deployable artifact:

```bash
cargo test
groundhog build
```

The RV32 build produces `erc20.rv32a`, lowering metadata, and contract-spec sidecars under `target/groundhog/`.

In the native test’s root transaction, `get_current_address()` is Alice’s root address. `get_caller()` is meaningful inside the nested token invocation.



## Concurrency Semantics

`Balance` records increases and decreases as changes rather than replacing the stored value with a newly calculated result. The transfer path checks the sender with `decrease` and credits the receiver with `lazy_increase`. Allowance adjustments use checked operations in both directions so the interface can report failures immediately.

This is the [merged-delta model](../pages/programming-model/execution.md#merged-deltas): the runtime combines changes from concurrent transfers when they can all be applied safely. Changes to different balances or allowances do not conflict. Credits to the same balance can combine, and debits from the same balance or allowance can combine as long as their total does not exceed the available value. If the total is too large, the runtime excludes one or more transactions and returns them to the mempool.



## Next Steps

- [Design a Swap](../pages/tutorials/design-a-swap.md) for an application built from cross-contract token calls
- [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md) for event testing and queries
- [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) for the snapshot, execution, and exclusion model behind this contract
- [Storage Types](../pages/programming-model/storage-types.md) for checked and lazy `Balance` operations and other state choices
- [NNInt and concurrent updates](../pages/programming-model/nnint.md) for the lower-level `set_add` representation behind `Balance`
- [How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the engine’s concurrent reservation machinery
- [Handle errors](../pages/contracts/errors.md) for domain and library exception behavior

---

## Connect a Wallet to Your App

Source: <https://docs.groundhog.dev/tutorials/connect-a-wallet-to-your-app/>

Build a small TypeScript dapp that connects an installed wallet and sends a localnet HOG transfer with receipt recovery.

Build a browser dapp that discovers installed wallets, connects an account, and asks the user to approve a **0.1 HOG** transfer. The wallet holds the keys. Your app builds the call, saves the signed transaction before submission, and checks the receipt.



## Before You Start

- Use Node.js `22.12.0` or newer and a browser with an installed Groundhog provider, such as Thruput Wallet.
- Start an isolated local ledger with `groundhog node`. See [Develop Locally](../pages/tutorials/develop-locally.md#4-start-the-local-node) for CLI and runtime setup. Keep that process running.
- In Thruput Wallet, select **Localnet** (`http://127.0.0.1:9545`), unlock a test account, and choose **Request test HOG**. Wait for success. Have a second localnet test account’s address ready and fund it too, so the transfer does not need to create an unfunded receiver’s balance storage.

Use this app in one tab on that ledger. Restarting a node started without `--data-dir` discards its state. Localnet’s fixed network hash does not distinguish separate ledger runs, so a saved hash from an earlier run cannot recover a transaction on the new one.



## 1. Create the App

Create a vanilla TypeScript project:

```bash
npm create vite@latest wallet-demo -- --template vanilla-ts
cd wallet-demo
npm install
```

Configure registry access using [Package setup](../pages/typescript/setup.md), then install the SDK packages:

```bash
npm install @groundhogchain/client @groundhogchain/protocol
```

Replace `index.html` with:

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Localnet wallet demo</title>
  </head>
  <body>
    <h1>Send 0.1 HOG on Localnet</h1>
    <fieldset id="controls">
      <legend>Wallet actions</legend>
      <div id="wallets">Waiting for an installed wallet.</div>
      <pre id="session">Disconnected</pre>
      <label>Recipient address <input id="recipient" placeholder="0x…" /></label>
      <button id="send" disabled>Send 0.1 HOG</button>
      <button id="check" disabled>Check saved transaction</button>
      <button id="disconnect" disabled>Disconnect</button>
    </fieldset>
    <pre id="status" role="status"></pre>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
```



## 2. Discover and Connect

Replace `src/main.ts` with the following code, then append the next two blocks to the same file. The app uses the first account authorized in the wallet’s connection prompt and displays it before enabling Send.

```ts
import { addressFromHex, createGroundhogClient, localnet, toHex0x } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { discoverWalletProviders, parseWalletSession, type WalletProvider,
  type WalletSession } from "@groundhogchain/client/provider";
import { createProviderWalletClient, type ProviderWalletClient } from "@groundhogchain/client/wallet";
import { ExecResult, HOG_ADDRESS, fromHex, gasAmount, sha256Hash } from "@groundhogchain/protocol";

const controls = document.querySelector<HTMLFieldSetElement>("#controls")!;
const choices = document.querySelector<HTMLDivElement>("#wallets")!;
const details = document.querySelector<HTMLPreElement>("#session")!;
const status = document.querySelector<HTMLPreElement>("#status")!;
const recipient = document.querySelector<HTMLInputElement>("#recipient")!;
const send = document.querySelector<HTMLButtonElement>("#send")!;
const check = document.querySelector<HTMLButtonElement>("#check")!;
const disconnect = document.querySelector<HTMLButtonElement>("#disconnect")!;
const message = (text: string) => { status.textContent = text; };

async function start() {
  const client = await createGroundhogClient({ cluster: localnet() });
  const networkHash = toHex0x(client.network.networkHash).slice(2);
  let provider: WalletProvider | undefined;
  let session: WalletSession | undefined;
  let active: ProviderWalletClient | undefined;
  let stopChanges: (() => void) | undefined;
  let busy = false;
  let closed = false;

  function update(value: unknown) {
    active?.dispose(); // Every change invalidates pending wallet work.
    session = undefined;
    try { if (value !== undefined) session = parseWalletSession(value); }
    catch { message("Invalid wallet session. Reconnect."); }
    const account = session?.accounts[0];
    const matches = session?.networkHash === networkHash;
    details.textContent = session
      ? `Account: ${account?.address ?? "Disconnected"}\nNetwork: ${session.networkHash}`
      : "Disconnected";
    send.disabled = check.disabled = !account || !matches;
    disconnect.disabled = !provider;
    if (session && !matches) message("Select Localnet in the wallet, then reconnect.");
  }

  async function run(action: () => Promise<void>) {
    if (busy || closed) return;
    busy = controls.disabled = true;
    try { await action(); }
    catch (error) { message(error instanceof Error ? error.message : "Wallet request failed."); }
    finally { busy = controls.disabled = false; }
  }

  const stopDiscovery = discoverWalletProviders((choice) => {
    if (!choices.querySelector("button")) choices.textContent = "";
    const button = document.createElement("button");
    button.textContent = `Connect ${choice.info.name}`;
    button.onclick = () => { void run(async () => {
      stopChanges?.();
      provider = choice;
      update(undefined);
      // Subscribe before connect, including changes emitted during its prompt.
      stopChanges = choice.on("change", update);
      const connected = await choice.request({ method: "connect" });
      if (closed) return;
      update(connected);
      if (!session?.accounts[0]) throw new Error("No authorized account. Reconnect.");
      if (session.networkHash === networkHash) message("Connected. Check the account and recipient before sending.");
    }); };
    choices.append(button);
  });
```

`localnet()` pins the RPC network identity. The app compares the wallet session with that verified identity; it does not adopt a network selected by the wallet. Provider names are rendered as text.



## 3. Prepare, Sign, Save, and Submit

Append this code inside `start()`. `ERC20` is a generated binding shipped with the SDK. HOG has seven decimals, so `1_000_000n` base units is 0.1 HOG. `prepareExecution()` wraps this transfer through DefaultWallet; `signTransaction()` requests approval without broadcasting.

```ts
  function selection() {
    const account = session?.accounts[0];
    if (!provider || !account || session?.networkHash !== networkHash) {
      throw new Error("Connect a Localnet account first.");
    }
    return { provider, account, key: `wallet-demo:${networkHash}:${account.address}` };
  }

  async function observe(key: string, hash: string) {
    message(`Checking Localnet transaction ${hash}`);
    try {
      const receipt = await client.waitForTransactionReceipt(
        sha256Hash(fromHex(hash.slice(2))), { timeoutMs: 30_000 },
      );
      const result = receipt.execResult === ExecResult.ExecResultOK
        ? "Transfer succeeded" : `Execution failed: ${ExecResult[receipt.execResult]}`;
      message(`${result}\nLocalnet transaction: ${hash}`);
      try { localStorage.removeItem(key); }
      catch { message(`${result}\n${hash}\nCould not clear the saved record. Check again later.`); }
    } catch {
      message(`Outcome unresolved. Keep this Localnet hash: ${hash}\nUse Check saved transaction. Do not send a replacement.`);
    }
  }

  send.onclick = () => { void run(async () => {
    const { provider, account, key } = selection();
    if (localStorage.getItem(key)) throw new Error("Check the saved transaction before sending again.");
    const receiver = addressFromHex(recipient.value.trim());
    const wallet = createProviderWalletClient({ client, provider, account, networkHash });
    active = wallet;
    let submitting = false;
    let hash = "";
    try {
      const transaction = await wallet.prepareExecution({
        invocation: ERC20.v0_1.transfer.invocation(HOG_ADDRESS, gasAmount(500_000n), {
          receiver, amount: 1_000_000n,
        }),
        gasLimit: gasAmount(10_000_000n),
      });
      message("Review the 0.1 HOG transfer in your wallet.");
      const signed = await wallet.signTransaction(transaction);
      hash = signed.hash;
      localStorage.setItem(key, JSON.stringify({ ...signed, account, networkHash }));
      // If storage fails, submission never starts.
      submitting = true;
      await wallet.submitTransaction(signed);
      await observe(key, hash);
    } catch (error) {
      if (submitting) message(`Broadcast may have occurred. Localnet hash: ${hash}\nUse Check saved transaction.`);
      else throw new Error("No broadcast requested. Check the wallet, recipient, and browser storage.", { cause: error });
    } finally {
      wallet.dispose();
      active = undefined;
    }
  }); };
```

The recovery key includes the original network and account. The record includes the signed bytes and hash. Recovery here only reads receipts. A submission acknowledgment is not execution success. Any error after submission starts leaves the record in place.



## 4. Check Status and Clean Up

Append this final block. It closes `start()` and starts the app:

```ts
  check.onclick = () => { void run(async () => {
    const { key } = selection();
    const saved = localStorage.getItem(key);
    if (!saved) { message("No saved transaction for this Localnet account."); return; }
    const pending: unknown = JSON.parse(saved);
    if (!pending || typeof pending !== "object" || !("hash" in pending) ||
        typeof pending.hash !== "string" || !/^0x[0-9a-f]{64}$/.test(pending.hash)) {
      throw new Error("Invalid saved transaction hash.");
    }
    await observe(key, pending.hash);
  }); };
  disconnect.onclick = () => { void run(async () => {
    active?.dispose();
    await provider?.request({ method: "disconnect" });
    update({ networkHash, accounts: [] });
    message("Disconnected. Saved transaction hashes are kept.");
  }); };
  function cleanup() {
    closed = true;
    active?.dispose();
    stopChanges?.();
    stopDiscovery();
  }
  window.addEventListener("pagehide", cleanup, { once: true });
  window.addEventListener("pageshow", (event) => { if (event.persisted) location.reload(); });
  import.meta.hot?.dispose(cleanup);
}
void start().catch(() => message("Cannot connect to Localnet. Start the node, then reload."));
```

The app creates a fresh adapter for each Send action and disposes it afterward. Account or network changes invalidate pending approval work. Cleanup removes listeners without revoking access; the user’s Disconnect action requests revocation. None of these actions automatically re-signs or retries a transfer.



## 5. Try It

Run `npm run dev` and open the localhost URL printed by Vite. Choose your wallet, approve access, and check the displayed account and network. Paste your funded test recipient’s address, click **Send 0.1 HOG**, and review the amount and recipient in the wallet before approving.

Expect a transaction hash followed by **Transfer succeeded** or **Execution failed**. If the outcome is unresolved, use **Check saved transaction**. After a reload, reconnect the same account on the same running ledger to check its saved hash. Switching accounts leaves the original record intact. Status checks only query RPC; they never sign or submit.

If no wallet appears, enable the extension for this browser profile and reload. If you reject approval, start another Send only when you intend a new transfer. A missing receipt or timeout does not prove that a submitted transaction failed.

This small app keeps one unresolved hash per account and network and blocks another send until it gets a receipt. It does not coordinate multiple tabs or provide a manual resolution screen for transactions that never receive a receipt. Keep the hash and investigate on the original ledger using the [recovery guide](../pages/tools/wallet-integration.md#recover-an-ambiguous-submission).



## Next Steps

- [Wallet Integration](../pages/tools/wallet-integration.md) covers provider errors, lifecycle rules, and recovery policies for a larger app.
- [Work with Groundhog from TypeScript](../pages/tutorials/work-with-groundhog-from-typescript.md) shows how to generate your own contract binding. Replace the ERC-20 invocation with your contract’s typed call and keep the same wallet flow.

---

## Design a Swap

Source: <https://docs.groundhog.dev/tutorials/design-a-swap/>

How a constant-product AMM is built on Groundhog, and why the execution model shapes it.

This page follows the contracts behind a swap application. The implementation adapts Uniswap V2’s [pair operations](https://github.com/Uniswap/v2-core/blob/master/contracts/UniswapV2Pair.sol) and [supporting math libraries](https://github.com/Uniswap/v2-periphery/tree/master/contracts/libraries/) to Groundhog’s snapshot execution model. Requests enter a queue concurrently, then a separate transaction processes them against the pair’s reserves.

**Prerequisites:** [Build a Token](../pages/tutorials/build-a-token.md). You should be able to write a contract, deploy it, and call another contract through a generated client.

> **note: Sources**
>
> For your reference while following along, the example swap application currently lives in the `groundhog-examples` repository.



## The problem

For each token-pair that the application manages, it tracks its own reserves of each of the two tokens. Every pair operation reads these balances, computes against them, and writes them back:

```rust
let (reserve0, reserve1) = self.reserves.get();
let amount_out = compute_output(amount_in, reserve0, reserve1);
self.reserves.set(&(reserve0 + amount_in, reserve1 - amount_out));
```

On Groundhog, every transaction in a block reads the same committed snapshot. If two transactions compute different reserve values for the same pair, their writes cannot merge. One transaction can land while the other is excluded and returned to the mempool. Identical writes can coexist, so the reserve field alone does not enforce one operation per pair per block.

A direct port therefore needs to account for both conflicting writes and operations that compute identical reserves. Processing requests sequentially inside one transaction makes each operation use the preceding operation’s updated reserves. See [Parallel Execution](../pages/how-it-works/execution-model.md) for the storage merge rules.

> **caution: The serial part stays serial**
>
> Nothing here makes the pair’s operations concurrent. They cannot be: each one genuinely depends on the result of the last. What changes is *when* the serial work happens, and how many operations can be performed in one block.



## Split acceptance from execution

Although a pair operation itself has to be performed serially with respect to other operations on the same pair, accepting a request does not.

So our implementation splits them: instead of performing an operation immediately, user requests (many per block) are accepted into a queue. The queue is processed later, in a transaction of its own.

```plaintext
  many transactions, one block              one transaction, later
  ┌──────────┐
  │ Alice    │──┐
  ├──────────┤  │   ┌───────────┐          ┌────────────────────┐
  │ Bob      │──┼──▶│   queue   │─────────▶│ drain: op, op, op  │
  ├──────────┤  │   └───────────┘          └────────────────────┘
  │ Carol    │──┘   inserts commute      serial execution, as required
  └──────────┘
```

The queue is a Groundhog primitive called `RCQ` (“retro-causal queue”). Inserts **commute**: two transactions inserting in the same block do not conflict. Many requests can be accepted together.

Draining is the other half of the RCQ rule: only one transaction per block may consume from a given queue. That is exactly the serialization the pair needs, and now it costs one transaction per block instead of one per user.

With this arrangement, a single transaction can process multiple operations against updated reserves, bounded by its execution budget.

> **tip: The general lesson**
>
> When two transactions conflict, the fix is usually to change *what you write*, not to add locking. A write that commutes (a queue insert, a balance delta) doesn’t require a transaction to be deferred.



## Batch the serial work

We call processing the request-queue *cranking*, and anyone may do it. `Queue::crank` in the `batch-driver` helper crate takes requests off the queue one at a time and hands each to a closure that knows how to perform it. The swap application provides that closure:

```rust
self.queue.crank(|request, gas_limit| {
    cfg.handler()
        .with_commit_locking()
        .with_gas_limit(gas_limit)
        .try_handle_request(request)
})
```

Some details to explain:

**`with_gas_limit`.** Each request carries its own budget, and the processing loop performed in `crank` checks that the frame can still afford one before taking it off the queue. (A request is never consumed and then dropped for want of gas to handle it.)

**`with_commit_locking`.** A request that fails should not take the batch down with it. “Commit-locking” settles the sub-call’s effects as soon as it returns (instead of waiting until the end of the transaction to check invariants), so a failed request can be rolled back alone and the processing continues to the next one. The closure above catches errors using the `try_*` variant of a cross-contract call, and the loop continues with more requests.



### The gas limit is the batch size

Although a root transaction (the one signed by a sender) declares a gas limit, executing it on Groundhog does not *consume* any tokens; rather, tokens are temporarily reserved while the transaction occupies a portion of the chain’s scheduling capacity. (See [Execution](../pages/programming-model/execution.md).)

A crank runs until the queue is empty or the frame’s remaining gas is no longer sufficient to run another request, so **the caller chooses the batch size by choosing a gas limit**. A caller can request a small batch, subject to the minimum described below. Someone clearing a backlog asks for a large one. (The `batch-driver` helper provides `gas_for_batch` for converting a request count into the necessary gas limit.)



## Nobody has to be on duty

Cranking needs no privilege, so the policy can be simple: after submitting a request, send a crank as its own transaction with a short expiry, and stop.

Nothing needs to be polled, timed, or estimated, because every way a crank can turn out is harmless:

| Outcome                             | What happens                                                                        |
| ----------------------------------- | ----------------------------------------------------------------------------------- |
| Another crank won the block         | Yours is excluded and returns to the mempool. It may be included before its expiry. |
| The queue was empty at the snapshot | Yours commits having done nothing, writing no delta and conflicting with nobody.    |
| Otherwise                           | It drains the queue, up to the batch its gas limit allows.                          |

The short expiry keeps the first case from becoming a nuisance: a crank that loses several blocks running should give up rather than land much later as a pointless no-op.

If an operator chooses to provide a queue-keeper mechanism, its operation will compose with this without any reconfiguration. When the keeper’s crank runs, everyone else’s cranks defer harmlessly behind it. If it stops, theirs immediately take up the slack.

> **tip: The general lesson**
>
> An excluded crank leaves no committed effects. It can be considered again until its expiry, without coordinating with other crank callers.



### Minimum batch size

Because batch sizes determine application throughput, we want to ensure that each block’s one opportunity to drain the queue is not wasted on too small a batch. So the application’s policy requires that a crank be able to process what is currently waiting in the queue, up to a configured `min_crank_batch`; otherwise it is refused before the queue is touched.



## A queue costs storage, so it needs a ceiling

Storage on Groundhog is a refundable deposit paid from the contract’s own balance. See [Storage Economics](../pages/how-it-works/storage-economics.md). A queue anyone can add to is therefore an unbounded claim on whoever funds the contract.

We represent a ceiling with a `CapacityConstraint`, an SDK type that holds the room *remaining* rather than the number of entries used:

```rust
self.slots.consume_capacity(1);   // take this request's room
```

The constraint mechanism allows transactions to consume capacity (corresponding to slots in the finite-sized queue) without conflict, but prevents exhaustion in any particular block. The ceiling is built into the `Queue` datatype in the `batch-driver` helper crate.



### Early is not the same as failed

Note that a transaction that submits a request and thus consumes a unit of queue capacity (as in the line of code above) does not explicitly check whether any capacity is available. If it did (if the capacity constraint were checked at call time), a request arriving at a full queue would have to fail deterministically. The transaction would be committed with the block, have no effect due to the failure, and not be retried. The user would have to submit a new transaction.

Instead, capacity consumption is checked against all concurrent transactions in aggregate when they are being committed as a block; if a resource would be exhausted, some transaction(s) will be excluded from the block and returned to the mempool. Thus the request can land later, once a crank frees capacity. (A caller who cannot wait indefinitely bounds the wait with the transaction’s expiry height.)



## Getting the answer back

As a request is not served in the transaction that submits it, the submitter cannot be given a result. It is provided an identifier instead.

`UniqueIds` (in the `unique-ids` helper crate) mints that identifier from the submitting transaction’s hash and a stored counter. Both halves are needed: the counter separates requests made in one transaction, and the transaction hash separates requests made in different ones, including concurrent transactions in the same block that observe the same counter because neither can see the other’s delta.

The identifier is returned to the caller and stamped on the queued request, so it reappears on whatever event that request eventually produces:

```plaintext
  submit ──▶ RequestAccepted { request_id }
                    ⋮
  crank  ──▶ SwapEvent { request_id, ... }       // success
         or  RequestFailed { request_id, ... }
```

`RequestAccepted`, `RequestFailed` and `RequestsProcessed` are defined in `batch-driver` and emitted by the queue itself, so every application built on this pattern reports on its queue in the same way.



## Components

| Crate          | Role                                                                                  |
| -------------- | ------------------------------------------------------------------------------------- |
| `swap-if`      | Interfaces only: every trait, client, error, and shared value type                    |
| `swap-pair`    | The fundamental operations. Not a contract; the handler runs it in its own invocation |
| `swap-handler` | Performs one request: prices it against live reserves, moves the assets               |
| `swap-driver`  | Holds the queue, batches requests, forwards each to the handler                       |
| `swap-router`  | Builds requests from user operations and enqueues them with the appropriate driver    |
| `swap-factory` | Creates pairs and keeps a registry                                                    |
| `batch-driver` | The reusable part: `Queue`, its crank policy, and the three events                    |
| `unique-ids`   | `UniqueIds`                                                                           |



## Each link takes work only from its predecessor

A request names the account whose tokens it will spend. Nothing downstream from the directly called contract can check that claim, because it is the only one that can see (via [`get_caller`](../pages/how-it-works/invocation-frames.md)) who is submitting the request.

```plaintext
  user ──▶ SwapRouter ──▶ SwapDriver ──▶ SwapHandler ──▶ pair operations
           sees the        accepts        accepts
           caller          only from      only from
                           the router     its driver
```

So the router is the only contract that can attribute a request to an account, and each link afterwards accepts work only from its predecessor. `SwapDriver` checks that its caller is the router before enqueuing; `SwapHandler` checks that its caller is its driver before handling. Without those checks, anyone could enqueue a request naming a victim as the payer and themselves as the recipient, and be paid out of the victim’s standing allowance.

In contrast, `process_requests` takes no privilege at all: cranking is permissionless, because a crank can only perform requests that were already accepted, and the more participants willing to do it the better.



## Next steps

- [Parallel Execution](../pages/how-it-works/execution-model.md) for snapshots, conflicts, and exclusion
- [Execution](../pages/programming-model/execution.md) for gas, scheduling capacity, and merged deltas
- [Storage Types](../pages/programming-model/storage-types.md) for `RCQ`, `NNInt`, and what commutes
- [Storage Economics](../pages/how-it-works/storage-economics.md) for deposits and who pays for them

---

## Develop Locally with the CLI

Source: <https://docs.groundhog.dev/tutorials/develop-locally/>

Build, deploy, call, and inspect a Groundhog contract against a local hog-devnode.

This tutorial walks through the complete local CLI loop. You will build and test a counter, start an ephemeral Groundhog node, create and fund a wallet for your signing key, deploy, submit calls, and inspect committed state.

Local development is the fastest way to exercise deployment and RPC behavior. The node provides its own local faucet and RPC endpoint.



## Prerequisites

This detailed walkthrough targets [CLI 0.19.0](https://github.com/groundhogchain/groundhog-rpc/releases/tag/v0.19.0) and its managed node. You also need `jq` and [Cargo access](../pages/cli/install.md#configure-cargo-access). For latest-release onboarding, use the [contract quickstart](../pages/get-started/contract.md). Keep the generated SDK dependencies and compiler toolchain.



### Verify the Selected Runtime

Inspect the CLI and selected runtime:

```bash
command -v groundhog
groundhog --version
groundhog status --json | jq '.data.environment.devnode'
```

Read the returned path, version, and source. CLI 0.19.0’s catalog selects node 0.1.29-rc.4. An explicit `GROUNDHOG_DEVNODE_BINARY` can override managed selection, so a successful status command alone does not establish the intended runtime.

If an inherited override is unintended, remove it for this terminal and inspect the managed selection:

```bash
unset GROUNDHOG_DEVNODE_BINARY
groundhog toolchain list
groundhog toolchain which
groundhog status --json | jq '.data.environment.devnode'
```

Use the same CLI and environment in the terminal that starts the node. Preserve intentional source-build overrides. A protocol mismatch requires matching binaries and bindings, not merely overriding the protocol token.



## 1. Initialize the CLI

Run the guided environment check if this is your first Groundhog project:

```bash
groundhog init
```

Accept signing-key generation to create the stored key named `default`. Decline starter-project creation because the next step creates it explicitly. Init also creates global `local` and `devnet` profiles.



## 2. Create a Counter Project

From the directory where you keep development projects:

```bash
groundhog new my-counter
cd my-counter
```

The generated `groundhog.toml` sets `default_profile = "local"`, so commands run from this project use the local profile automatically. Only `config set` requires an explicit `--profile local`; the other commands below use the project default. If you previously set `GROUNDHOG_PROFILE`, unset it first because it overrides that default.

The generated project defines the private registry in `.cargo/config.toml`. Complete [Cargo access setup](../pages/cli/install.md#configure-cargo-access) before the first build. The SDK downloads its test executor from public storage without FFI credentials.

Check the stored key and select it explicitly for this project’s local profile:

```bash
groundhog keys ls
groundhog config set default-key default --profile local --project
```

You should see `default` in the key list. If you skipped key generation during init, run `groundhog keys generate default` first. If you already use a differently named key, substitute its name in the key-selection command above and in `--key default` in step 5. The wallet created in step 5 will still be named `default`.



## 3. Build and Test Locally

Run the fast native tests, then the executor-backed RV32 test:

```bash
cargo test
groundhog build
groundhog test
```

These commands do not require a running JSON-RPC node:

| Command           | What it checks                                                 |
| ----------------- | -------------------------------------------------------------- |
| `cargo test`      | Native contract logic through the SDK test environment         |
| `groundhog build` | Deployable RV32 artifact, lowering metadata, and contract spec |
| `groundhog test`  | The generated executor-backed `tests/test_rv32.rs` target      |

Inspect the generated artifacts:

```bash
ls -lh target/groundhog/
```

For `my-counter`, expect:

```text
my_counter.rv32a
my_counter.rv32.json
my_counter.spec.xdr
my_counter.spec.json
```



## 4. Start the Local Node

Open a second terminal, keep it running, and start the node:

```bash
groundhog node
```

The command starts one supervised `hog-devnode`, exposes JSON-RPC at `http://127.0.0.1:9545`, and records its runtime manifest. The managed runtime’s artifact layout needs no extra flags. Use `--contract-artifacts-dir <DIR>` only for intentional nonstandard artifact directories.

The node is ephemeral. Deployments and calls share state while this process runs, but stopping it discards chain state and clears the active-runtime record.



## 5. Create and Fund Your Local Wallet

Return to the project terminal and check the active node:

```bash
groundhog status
```

The profile should show `default` as the key and `http://127.0.0.1:9545` as the RPC URL. If no endpoint appears, confirm that `groundhog node` is still running and both terminals use the same user configuration.

Create a wallet owned by your stored key, then select it for this project:

```bash
groundhog wallet create --key default --name default
groundhog wallet use default
groundhog wallet ls
```

Confirm wallet creation when prompted. The key signs transactions; the wallet has the on-chain address and holds HOG. `wallet ls` should show `default` as selected. Its address differs from the address printed by `keys ls`.

Wallet creation prefunds the creation transaction. Request 100 local HOG to cover deployment and the subsequent calls:

```bash
groundhog airdrop default --amount 100
groundhog balance default
```

Confirm the airdrop when prompted. The CLI uses the node’s local faucet automatically. Keep this node running for the remaining steps.



## 6. Dry-Run and Deploy

Prepare a signed deployment without broadcasting it:

```bash
groundhog deploy --dry-run
```

Then deploy the RV32 artifact and confirm when prompted:

```bash
groundhog deploy
```

The CLI prints the contract address and saves `my-counter` as an alias under `[profile.local.contracts]` in `groundhog.toml`.



## 7. Initialize and Call the Counter

Deployment and initialization are separate operations. Initialize the counter once, confirming the call when prompted:

```bash
groundhog call my-counter initialize 10
groundhog view my-counter get
```

The first view should return `10`.

Submit another state change:

```bash
groundhog call my-counter increment 5
groundhog view my-counter get
```

The counter should now return `15`.

Use JSON mode when testing scripts or automation:

```bash
groundhog --json view my-counter get \
  | jq -e '.ok == true and .data.schemaVersion == 1 and .data.returnValue == 15'
```



## 8. Confirm Dry Runs Do Not Commit

Prepare a call without broadcasting it:

```bash
groundhog call my-counter increment 100 --dry-run
groundhog view my-counter get
```

The value should remain `15`.



## Integration Test Mode

`groundhog test --integration` starts its own disposable local node, deploys the RV32 artifact, and runs the scaffolded `tests/integration.rs`. Invoke it like this:

```bash
groundhog test --integration
```

The generated starter stays ignored under ordinary `cargo test`. Add your contract-specific RPC assertions to `tests/integration.rs`. See [Testing](../pages/programming-model/testing.md#what-the-scaffold-gives-you) for how the CLI activates the test and which environment variables it provides.

The starter uses `groundhog-json-rpc-client` to connect directly to the node. Use `GROUNDHOG_RPC_URL` and `GROUNDHOG_CONTRACT_ADDRESS` for your own RPC assertions.

Use this integration mode for automated RPC tests. For interactive development across several commands, use the long-running `groundhog node` flow above.



## Troubleshooting



### `hog-devnode` is not found

Use the `groundhog` and `hog-devnode` binaries from the same Groundhog client bundle, preserve the extracted directory layout, and add its `bin` directory to `PATH`. For a custom location, set `GROUNDHOG_DEVNODE_BINARY` to that bundle’s `hog-devnode` executable.



### The wrong key or wallet is selected

From the project directory, repeat the explicit selections:

```bash
groundhog config set default-key default --profile local --project
groundhog wallet use default
```

If the wallet has not been created yet, complete step 5 first. Use your actual key name if it differs from `default`.



### The node was restarted

Stopping the ephemeral node discards its wallets, funds, and deployed contracts. Your stored key and project configuration remain. Repeat wallet creation, funding, deployment, and initialization against the new node before continuing.



### Protocol mismatch

First repeat the [runtime selection check](../pages/tutorials/develop-locally.md#verify-the-selected-runtime), including inherited environment overrides. Use a `hog-devnode` build compatible with the CLI. Do not use `--hogd-protocol` to make a mismatched installation appear compatible. That developer diagnostic changes only the handshake token, not the wire format; use it only when token-only compatibility has been independently established.



## Next Steps

- [Develop on Devnet with the CLI](../pages/tutorials/develop-on-devnet.md) to create a persistent key-owned wallet and deploy to the hosted network
- [Build a Counter](../pages/tutorials/build-a-counter.md) for a line-by-line walkthrough of the generated contract
- [Command reference](../pages/cli/reference.md) for commands and flags

---

## Develop on Devnet with the CLI

Source: <https://docs.groundhog.dev/tutorials/develop-on-devnet/>

Create a persistent key-owned wallet, deploy a counter to Devnet, and exercise the Groundhog CLI end to end.

This tutorial moves the local development loop onto Devnet. You will use the signing key and profiles created during setup, create a contract wallet, build and test a counter locally, deploy it to the hosted network, submit calls, and inspect committed state.

Complete [Develop Locally with the CLI](../pages/tutorials/develop-locally.md) first if you have not yet built, deployed, and called a contract against `hog-devnode`.

> **note: Hosted version must be discovered**
>
> Use the discovery steps below to match the client bundle to the serving release. A local build or test does not verify the hosted Devnet flow.



## Before You Start

You need:

- Rust and Cargo through [rustup](https://rustup.rs/)
- `curl` and `jq`
- Access to the private Groundhog Cargo registry
- Network access to Groundhog Devnet

> **caution: Persistent development key**
>
> This tutorial writes a signing key to your normal Groundhog configuration. Use a dedicated Devnet key, protect the file like any other development credential, and do not use a key that controls anything valuable.

> **note: Fresh setup**
>
> The commands below assume a fresh Groundhog configuration with no stored keys. If you are reusing an installation, follow [Profiles and networks](../pages/cli/configuration.md) and [Keys and wallets](../pages/cli/wallets.md) to align selections before adapting this tutorial.

> **caution: Devnet resets**
>
> Devnet may be reset. A reset changes its network hash and removes existing wallets, balances, and deployments. After a reset, repeat the identity configuration below, create the wallet again, request an airdrop, and redeploy the contract.



## 1. Initialize the CLI

Start with the CLI installed in the local tutorial, then check it against the hosted deployment below:

```bash
groundhog --version
```

Run the guided setup on first use:

```bash
groundhog init
```

On a fresh setup with no stored keys, accept key generation. Init creates and selects the key named `default`, and creates global `local` and `devnet` profiles. Decline starter-project creation because step 6 creates it explicitly.



## 2. Configure Devnet Identity

Inspect the Devnet profile created by init:

```bash
groundhog config get devnet --sources
```

Init supplies the network, RPC URL, faucet URL, and HOG contract alias. Read the deployment version and packaging release from that RPC:

```bash
DEVNET_RPC_URL=$(groundhog --json config get devnet | jq -er '.data.rpcUrl')
DEVNET_VERSION_JSON=$(curl -fsS -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"groundhog_version","params":[]}' \
  "$DEVNET_RPC_URL")
echo "$DEVNET_VERSION_JSON" \
  | jq -e '.result | {wireFormat, implementation, releaseVersion}'
DEVNET_RELEASE_VERSION=$(echo "$DEVNET_VERSION_JSON" \
  | jq -r '.result.releaseVersion // "unavailable"')
printf 'Reported packaging release: %s\n' "$DEVNET_RELEASE_VERSION"
```

When present, `releaseVersion` identifies a validated [packaging release](https://github.com/groundhogchain/packaging/releases). It and `bundleManifestDigest` are diagnostics and may be absent. Use `wireFormat` for RPC compatibility, and confirm the deployed contract/interface family before using generated bindings. If deployment identity is unavailable, confirm it with the operator rather than guessing a bundle. The local 0.19.0 test recipe does not prove that Devnet has upgraded. Select any required older client/runtime explicitly and keep its generated bindings coordinated.

Hosted transaction signatures also require the live network hash. Read it from the node, validate its format, remove the RPC’s `0x` prefix, and save it in the Devnet profile:

```bash
DEVNET_NETWORK_HASH=$(curl -fsS -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"groundhog_networkInfo","params":[]}' \
  "$DEVNET_RPC_URL" \
  | jq -er '.result.networkHash | select(test("^0x[0-9a-f]{64}$")) | ltrimstr("0x")')
groundhog config set network-hash "$DEVNET_NETWORK_HASH" \
  --profile devnet \
  --global
```

The signing network hash is not the faucet descriptor’s `genesisHash`. Do not substitute one for the other.

Wallet creation, airdrop, deploy, and call validate the selected RPC’s live network identity. A mismatch fails before the CLI signs a transaction. See [Authorization](../pages/how-it-works/authorization.md) for why signatures include the network hash.



## 3. Check the Devnet Signing Key

Confirm that the key created by init is selected:

```bash
groundhog keys ls
```

`default` should be marked as selected. If you skipped key generation, create it with `groundhog keys generate default`. The first generated key becomes the global default automatically.

The private key is stored under the Groundhog configuration directory, normally `~/.config/groundhog/keys/`.



## 4. Inspect the Devnet Profile

Init created the global `devnet` profile with its network, RPC, faucet, and HOG contract settings. Inspect it rather than recreating it:

```bash
groundhog config get devnet --sources
```

The report should show the Devnet RPC and faucet URLs from global config. The globally selected `default` key applies because the fresh Devnet profile does not override it. Later, inside a project, the project’s `devnet` profile merges over this global profile.



## 5. Create a Devnet Wallet

Run wallet creation from a directory outside a Groundhog project so it updates the global Devnet profile:

```bash
groundhog wallet create --profile devnet
groundhog wallet ls --profile devnet
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Wallet creation performs a prefund-first flow through the hosted faucet. The faucet funds the future address, deploys the wallet contract, and initializes it for your public key. It never receives your private key.

That prefund pays for wallet creation only. The airdrop funds the effective wallet before its first application deployment.

With no `--key` or `--name`, the CLI uses the selected key and saves the wallet under the same name. Deploy and call resolve the saved wallet through `default`.

If wallet creation reports a pending attempt, rerun the exact same command:

```bash
groundhog wallet create --profile devnet
```

Keep the CLI cache intact until the attempt completes. Its retry record preserves the request’s idempotency data.



## 6. Create and Test a Counter

From the directory where you keep development projects:

```bash
groundhog new my-counter
cd my-counter
```

Build and run the local test paths before submitting anything to Devnet:

```bash
cargo test
groundhog build --profile devnet
groundhog test --profile devnet
```

These commands build and test locally. They do not submit transactions to Devnet.

Inspect the artifacts:

```bash
ls -lh target/groundhog/
```

Expect:

```text
my_counter.rv32a
my_counter.rv32.json
my_counter.spec.xdr
my_counter.spec.json
```

The project and global `devnet` profiles merge. The project supplies contract aliases while the global wallet binding remains available.



## 7. Dry-Run and Deploy

Prepare a current signed deployment without broadcasting it:

```bash
groundhog deploy --profile devnet --dry-run
```

Then submit the deployment:

```bash
groundhog deploy --profile devnet
```

On success, the CLI prints the contract address and saves `my-counter` under `[profile.devnet.contracts]` in the project’s `groundhog.toml`.



## 8. Initialize, Mutate, and Read State

Deployment does not initialize the counter automatically. Call `initialize` once:

```bash
groundhog call my-counter initialize 10 --profile devnet
groundhog view my-counter get --profile devnet
```

The first view should return `10`.

Submit another state change:

```bash
groundhog call my-counter increment 5 --profile devnet
groundhog view my-counter get --profile devnet
```

The counter should now return `15`.

Check structured output with pipeline failure propagation enabled:

```bash
set -o pipefail
groundhog --json view my-counter get --profile devnet \
  | jq -e '.ok == true and .data.schemaVersion == 1 and .data.returnValue == 15'
groundhog --json balance --profile devnet \
  | jq -e '.ok == true and .command == "balance" and .data.schemaVersion == 1'
```



## 9. Confirm Dry Runs Do Not Commit

Prepare an increment without broadcasting it:

```bash
groundhog call my-counter increment 100 --profile devnet --dry-run
groundhog view my-counter get --profile devnet
```

The value should remain `15`.

Submit a final real mutation:

```bash
groundhog call my-counter decrement 3 --profile devnet
groundhog view my-counter get --profile devnet
```

The final value should be `12`.



## 10. Request More HOG If Needed

Check the effective wallet’s balance before requesting more:

```bash
groundhog balance --profile devnet
```

If a later deployment needs more HOG:

```bash
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Do not pass `--amount` for a hosted Devnet airdrop. The faucet sets the amount and enforces deployment-specific quotas.

Remote airdrops are idempotent. If an airdrop reports a pending attempt, rerun the exact same command and keep the CLI cache intact until it completes.



## Troubleshooting



### RPC and faucet mismatch

The CLI rejects a descriptor, RPC identity, or configured network hash mismatch. Inspect the RPC and faucet identities directly:

```bash
DEVNET_RPC_URL=$(groundhog --json config get devnet | jq -er '.data.rpcUrl')
DEVNET_FAUCET_URL=$(groundhog --json config get devnet | jq -er '.data.faucetUrl')
curl -fsS "$DEVNET_FAUCET_URL/v1/network" \
  | jq '{rpcUrl: .endpoints.rpcUrl, networkHash, genesisHash}'
curl -fsS -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"groundhog_networkInfo","params":[]}' \
  "$DEVNET_RPC_URL" | jq '.result'
```

The RPC and faucet `networkHash` values must agree. `genesisHash` identifies different data and is expected to differ.



### Missing RPC or faucet URL

Run `groundhog config get devnet --sources`. If either value is missing, rerun interactive `groundhog init`, which fills missing built-in profile defaults without replacing existing values.



### No wallet for the selected key

Run `groundhog wallet ls --profile devnet`. On a fresh setup, the saved wallet and selected key are both named `default`. Rerun `groundhog wallet create --profile devnet` if needed.



### Insufficient funds

Check `groundhog balance --profile devnet`, then request one airdrop if needed. Avoid unnecessary requests because quotas apply to shared infrastructure.



## Persistent State and Cleanup

Devnet is shared and persists between ordinary requests, but operators may reset it. Deleting local files does not remove your wallet or deployed contracts from the current chain. A Devnet reset does.

Removing a wallet binding only removes local configuration. Removing the signing key permanently removes your ability to control that wallet unless you backed up the key first. Because this tutorial saved the binding globally, run these commands from outside a Groundhog project:

```bash
groundhog wallet rm default --profile devnet
groundhog keys rm default
```

Both commands remove local data only. `keys rm` asks for confirmation. In non-interactive automation, use `groundhog keys rm default --force` only when permanent key removal is intended.

Do not run those commands as routine tutorial cleanup. Keep the key if you intend to reuse the wallet or deployed contract.



## Next Steps

- [Build a Counter](../pages/tutorials/build-a-counter.md) for the generated contract’s implementation details
- [Command reference](../pages/cli/reference.md) for commands and flags
- [Faucet](../pages/tools/faucet.md) for wallet funding behavior and retries
- [TypeScript SDK](../pages/tools/typescript-sdk.md) for the cluster-aware Devnet client flow

---

## Work with Groundhog from TypeScript

Source: <https://docs.groundhog.dev/tutorials/work-with-groundhog-from-typescript/>

Build a contract, generate TypeScript bindings, connect to a local node, and use typed contract APIs.

This tutorial connects the Groundhog CLI, a Rust contract, generated TypeScript bindings, and `@groundhogchain/client` in one local workflow.

Use the latest [CLI](../pages/cli/install.md) and [TypeScript packages](../pages/typescript/setup.md), and keep their generated project and dependency lockfiles.



## How the Pieces Fit

The CLI and TypeScript packages have different jobs:

```text
Rust contract and #[contract] metadata
                  |
                  | groundhog build
                  v
    .rv32a artifact + .spec.xdr API
                  |
                  | groundhog build --bindings ts
                  | or groundhog codegen ts
                  v
       generated TypeScript binding
                  |
                  | imports @groundhogchain/client/contract
                  v
 typed views, invocations, events, and receipt decoding
```

The generated binding contains the contract-specific API: method names, arguments, returns, declared exceptions, events, and entrypoint IDs. The client package provides the shared runtime, JSON-RPC transport, transaction helpers, and standard contract bindings.

| Job                                       | Owner                                          |
| ----------------------------------------- | ---------------------------------------------- |
| Build and deploy a Rust contract          | Groundhog CLI                                  |
| Produce the canonical contract API        | `.spec.xdr` generated during the build         |
| Generate contract-specific TypeScript     | Groundhog CLI codegen                          |
| Connect to JSON-RPC and run chain actions | `@groundhogchain/client`                       |
| Encode calls and decode contract values   | Generated binding plus client contract runtime |
| Authorize an application write            | Wallet contract and signer                     |

This split is similar to an EVM ABI plus an application client, but Groundhog bindings contain typed method and event descriptors instead of dynamically calling methods by name.



## Before You Start

Complete [Develop Locally with the CLI](../pages/tutorials/develop-locally.md) first. You need:

- The Groundhog CLI and its managed local runtime
- Node.js `22.12.0` or newer
- Access to the Groundhog Cargo and GitHub Packages registries

Keep `groundhog node` running in a separate terminal throughout this tutorial.



## 1. Create and Build the Contract

Create the generated counter project and select the local development account:

```bash
groundhog new my-counter
cd my-counter

groundhog config set default-key dev-1 \
  --profile local \
  --project
```

Run the native tests, then build the RV32 artifact and TypeScript binding together:

```bash
cargo test
groundhog build --bindings ts --profile local
```

The build writes these application-facing artifacts:

```text
target/groundhog/my_counter.rv32a
target/groundhog/my_counter.spec.xdr
target/groundhog/my_counter.spec.json
target/groundhog/my_counter.ts
```

The `.rv32a` file is deployable code. The `.spec.xdr` file is the canonical contract API consumed by codegen. The `.ts` file is the generated application binding.

Re-run codegen whenever you change an exported method, argument, return type, declared exception, event, or reachable contract type.



## 2. Deploy and Initialize

With the local node running, deploy the contract:

```bash
groundhog deploy --profile local --fund 10
```

The CLI prints the deployed address and saves `my-counter` as a project alias. Keep the printed `0x...` address for the TypeScript application.

Deployment and initialization are separate calls. Initialize the counter once:

```bash
groundhog call my-counter initialize 10 --profile local
groundhog view my-counter get --profile local
```

The view should return `10`.



## 3. Create the TypeScript Application

Create an application directory inside the contract project and copy the generated binding into it:

```bash
mkdir -p web/src/contracts
cp target/groundhog/my_counter.ts web/src/contracts/my-counter.ts
cd web

npm init -y
npm pkg set type=module
npm pkg set scripts.view="tsx src/view.ts"
npm pkg set scripts.write="tsx src/write.ts"
```

Configure GitHub Packages as described in [Package setup](../pages/typescript/setup.md), then install the application dependencies:

```bash
npm install @groundhogchain/client @groundhogchain/protocol

npm install --save-dev typescript tsx @types/node
```

Generated bindings import the client contract runtime and the protocol packages directly. Keep these versions coordinated with the CLI that generated the file.



## 4. Run a Typed View

Create `web/src/view.ts`:

```ts
import {
  HttpTransport,
  addressFromHex,
  createGroundhogClient,
} from "@groundhogchain/client";
import { loadLocalDevAccount } from "@groundhogchain/client/local-dev";
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;

const rpcUrl = process.env.GROUNDHOG_RPC_URL ?? "http://127.0.0.1:9545";
const contractHex = process.env.GROUNDHOG_CONTRACT_ADDRESS;

if (!contractHex) {
  throw new Error("Set GROUNDHOG_CONTRACT_ADDRESS to the deployed counter");
}

const client = await createGroundhogClient({
  transport: new HttpTransport(rpcUrl),
});
const contract = addressFromHex(contractHex);
const { address: caller } = await loadLocalDevAccount();

const result = await Counter.get.view({
  client,
  contract,
  caller,
});

console.log({
  value: result.value.toString(),
  height: result.height.toString(),
  events: result.events.length,
});
```

Run it with the address printed by `groundhog deploy`:

```bash
GROUNDHOG_CONTRACT_ADDRESS="0x..." npm run view
```

The generated `Counter.get` descriptor knows from the Rust contract spec that `get()` returns `u64`. Its `view()` method decodes the returned bytes into a TypeScript `bigint`. The binding handles CXS decoding.

Change the contract through the CLI, then run the application again:

```bash
groundhog call my-counter increment 5 --profile local
GROUNDHOG_CONTRACT_ADDRESS="0x..." npm run view
```

The TypeScript view should now print `15`.



## 5. Build a Typed Invocation

Views simulate a contract call against committed state and do not submit a transaction. A state-changing application starts by building a typed invocation:

```ts
import { gasAmount } from "@groundhogchain/client";

const increment = Counter.increment.invocation(
  contract,
  gasAmount(500_000n),
  { amount: 5n },
);
```

The descriptor validates the argument object and encodes its calldata from the contract spec. `increment` is an application invocation, not yet an authorized transaction.



## 6. Execute Through the Default Wallet

A generated application invocation is not a signed transaction. A wallet client supplies the account’s authorization claim, creates the wallet-root invocation, binds the signature to the connected network, and submits the transaction. Call `waitForTransactionReceipt()` separately to observe execution.

The simplest account type is a pubkey account. Its address is derived from one Ed25519 public key and an address nonce. An undeployed pubkey-account address resolves to Groundhog’s native-compatible DefaultWallet, so creating the account does not require deploying or initializing a wallet contract:

```text
Ed25519 key + address nonce
            |
            v
   pubkey-account address
            |
            | kPubkeySignature auth claim
            v
DefaultWallet.execute         root invocation
            |
            v
Counter.increment             application invocation
```

Create a separate `web/src/write.ts`. This complete program connects to the same local node, binds a fresh pubkey account, funds it, executes the invocation, decodes the wallet and child returns, and reads the committed value:

```ts
import { randomBytes } from "node:crypto";
import {
  PrivateKeySigner,
  addressFromHex,
  createGroundhogClient,
  createPubkeyAccount,
  createWalletClient,
  localnet,
  toHex0x,
} from "@groundhogchain/client";
import { gasAmount } from "@groundhogchain/client";
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;

const contractHex = process.env.GROUNDHOG_CONTRACT_ADDRESS;
if (!contractHex) {
  throw new Error("Set GROUNDHOG_CONTRACT_ADDRESS to the deployed counter");
}

const client = await createGroundhogClient({
  cluster: localnet({ rpcUrl: process.env.GROUNDHOG_RPC_URL }),
});
const account = createPubkeyAccount({
  signer: new PrivateKeySigner(randomBytes(32)),
});
const wallet = createWalletClient({ client, account });
const contract = addressFromHex(contractHex);
const increment = Counter.increment.call({
  contract,
  gasLimit: gasAmount(500_000n),
  args: { amount: 5n },
});

const airdrop = await wallet.requestAirdrop();
if (airdrop.status.result !== "ok") {
  throw new Error(`Airdrop failed with ${airdrop.status.result}`);
}

const { txHash, receipt, values } = await wallet.executeCallsAndWait({
  calls: [increment],
  gasLimit: gasAmount(10_000_000n),
});
// increment returns void. The helper checked execution and decoded its result.
console.log(receipt.gasUsed, values[0]);

const committed = await Counter.get.view({
  client: wallet,
  contract,
  caller: account.address,
});

console.log({
  transaction: toHex0x(txHash),
  value: committed.value.toString(),
});
```

Run the write program with the same contract address:

```bash
GROUNDHOG_CONTRACT_ADDRESS="0x..." npm run write
```

`createPubkeyAccount()` constructs the protocol’s `kPubkeySignature` claim and derives the matching address. `createWalletClient()` selects the DefaultWallet adapter automatically for this account type. Because `localnet()` validates the endpoint’s network identity, the wallet can also use the returned network hash when signing.

Gas costs zero tokens, but declared root gas reserves scheduling capacity against the sender’s free HOG. Storage deposits are separate and belong to the address storing the data. The example checks airdrop execution before submitting. Calibrate gas for other workloads; `gasUsed` is not a token fee.

If observation fails, keep `TransactionObservationError.txHash` and query it on the original network. A timeout or cancellation does not prove the operation failed. Never automatically re-sign or replace the transaction. See [Track transaction results](../pages/typescript/transaction-status.md).

Do not submit `Counter.increment` directly as the transaction root. `wallet.execute()` wraps it in `DefaultWallet.execute` and then signs and submits the root transaction.

> **note: Local bootstrap accounts**
>
> `loadLocalDevAccount()` returns a manifest-verified native pubkey account. Bind its signer with `createPubkeyAccount({ signer: local.signer, nonce: 0n })` and use the manifest’s network hash. See [Local bootstrap accounts](../pages/typescript/accounts.md#use-a-local-bootstrap-account).

For additional implementation references, see the maintained client examples:

- [Transfer native HOG through a pubkey account and DefaultWallet](https://github.com/groundhogchain/client-ts/blob/main/examples/transfer-hog.ts).
- [Deploy and call a counter](https://github.com/groundhogchain/client-ts/blob/main/examples/deploy-counter.ts)

To use an installed browser wallet, follow [Connect a Wallet to Your App](../pages/tutorials/connect-a-wallet-to-your-app.md). This tutorial uses local signers.



## 7. Decode Receipts and Events

Generated descriptors can decode a receipt when the descriptor represents the transaction’s root method. In `write.ts`, the root is `DefaultWallet.execute`:

```ts
import { DefaultWallet } from "@groundhogchain/client/contracts";

const outcome = DefaultWallet.v0_1.execute.decodeReceiptOutcome(receipt);

if (outcome.kind === "return") {
  const [incrementReturn] = outcome.value;
  if (!incrementReturn) {
    throw new Error("Expected one child return");
  }
  const value = Counter.increment.decodeReturn(incrementReturn);
}
```

`decodeReceipt()` is the throwing convenience API. `decodeReceiptOutcome()` returns a typed `return`, `abort`, or `failure` result.

The generated DefaultWallet binding decodes its root return into one raw buffer per child. The earlier `executeCallsAndWait` call supplied descriptors and decoded these automatically. When recovering from a receipt alone, retain the original call descriptors or explicitly select the known child method; the receipt does not identify arbitrary child ABIs.

For a void mutation such as `increment` or ERC-20 `transfer`, successful decoding produces `undefined`. Applications commonly combine the root execution result with typed events and a follow-up view of committed state.

After a wallet-backed `Counter.ping` call, its generated event descriptor can find the nested event by emitting contract address:

```ts
import { my_counter } from "./contracts/my-counter.js";
const { PingEvent } = my_counter.v0_1.implementation;

const ping = PingEvent.singleFromReceipt(receipt, {
  contractAddress: contract,
});

console.log(ping.topics.tag);
```

See [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md) for the complete event flow.



## 8. Work with ERC-20 Tokens

The client ships generated bindings for the standard Groundhog ERC-20 and metadata interfaces. You do not need to run codegen for those interfaces:

```ts
import {
  ERC20 as ERC20Versions,
  ERC20Metadata as ERC20MetadataVersions,
  groundhog_erc20_if,
} from "@groundhogchain/client/contracts";

const ERC20 = ERC20Versions.v0_1;
const ERC20Metadata = ERC20MetadataVersions.v0_1;
const { TransferEvent } = groundhog_erc20_if.v0_1.events;
```

A useful token demonstration follows the contract’s authorization and balance preconditions:

| Call                          | Caller                             | Purpose                                        |
| ----------------------------- | ---------------------------------- | ---------------------------------------------- |
| `initialize`                  | Deployer or intended administrator | Set the administrator once                     |
| `mint`                        | Administrator                      | Create a balance for the sending account       |
| `getBalanceOf`, `totalSupply` | Read-only view                     | Confirm balances and supply                    |
| `transfer`                    | Token holder                       | Send part of the caller’s balance              |
| `adjustAllowance`             | Token holder                       | Change a spender’s allowance by a signed delta |
| `transferFrom`                | Spender                            | Transfer from the owner using allowance        |
| `burn`                        | Administrator                      | Destroy tokens from an account                 |

If the contract includes `ERC20Metadata`, use its initializer to set the administrator, name, symbol, and decimals together. Do not call both initializers on a one-time-initialized token.

Read a balance without submitting a transaction:

```ts
const balance = await ERC20.getBalanceOf.view({
  client,
  contract: token,
  caller,
  args: { addr: holder },
});

console.log(balance.value);
```

Build and execute a transfer through the holder’s wallet:

```ts
const transfer = ERC20.transfer.invocation(token, gasAmount(500_000n), {
  receiver,
  amount: 100n,
});

const txHash = await wallet.execute({
  invocation: transfer,
  gasLimit: gasAmount(10_000_000n),
});
const receipt = await wallet.waitForTransactionReceipt(txHash);
const transferReturn = DefaultWallet.v0_1.execute.decodeReceipt(receipt).value[0];
if (!transferReturn) {
  throw new Error("Expected one child return");
}
ERC20.transfer.decodeReturn(transferReturn);
```

`mint`, `transfer`, `adjustAllowance`, `transferFrom`, and `burn` return `void`. Their useful application results are the committed execution outcome, emitted event, and updated state:

```ts
const event = TransferEvent.singleFromReceipt(receipt, {
  contractAddress: token,
});

console.log(event.topics.from, event.topics.to, event.fields.amount);
```

The standard interface uses `adjustAllowance` arguments `{ spender, difference, exclusive }`. `difference` is signed, and `AllowanceChangeEvent` records that delta. An exclusive change conflicts with concurrent changes to the entry, but cannot make an earlier off-chain read current. Read-then-adjust is not a guarantee of an exact target. `clearAllowance({ spender })` revokes and deletes an allowance; `clearBalance()` deletes the caller’s empty balance entry.

Convert human amounts with `parseUnits(text, decimals)` and format with `formatUnits(value, decimals)`, both from the client root. Obtain token decimals from its metadata rather than applying HOG’s seven decimals to every token.



## CLI, Binding, or Client?

Use this rule of thumb:

| You need to…                                              | Use…                                                      |
| --------------------------------------------------------- | --------------------------------------------------------- |
| Build a contract or manage CLI profiles                   | Groundhog CLI                                             |
| Generate types for your contract                          | `groundhog build --bindings ts` or `groundhog codegen ts` |
| Connect to RPC, create an account, execute, sign, or poll | `@groundhogchain/client`                                  |
| Encode or decode one contract’s methods and events        | Its generated binding                                     |
| Call the standard token interface                         | `@groundhogchain/client/contracts`                        |



## Next Steps

- [TypeScript](../pages/typescript.md) for client tasks and API reference
- [TypeScript Bindings](../pages/tools/typescript-bindings.md) for generated method, exception, and event APIs
- [Build a Token](../pages/tutorials/build-a-token.md) for the Rust implementation behind the standard token interface
- [Add Events to a Contract](../pages/tutorials/add-events-to-a-contract.md) for typed event generation and queries
- [Wallet Integration](../pages/tools/wallet-integration.md) for connecting an external wallet
- [Design a Swap](../pages/tutorials/design-a-swap.md) for a larger application built from token and cross-contract calls
