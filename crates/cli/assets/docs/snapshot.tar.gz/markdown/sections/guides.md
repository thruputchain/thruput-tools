# Guides

Documentation source: `fd91c2019cd8f984aeda15c0303042679e1c8825`. Hosted docs may be newer than this snapshot.

## Guides

Source: <https://thruput.network/docs/guides/>

Build a token, build an AMM, or consume the firehose with runnable examples and verified checkpoints.

Work through a focused project using the [examples repository](https://github.com/thruputchain/thruput-examples):

- [Build a token](../pages/guides/build-a-token.md): balances, allowances, supply policy, events, and native/RV32 checks.
- [Build an AMM](../pages/guides/build-an-amm.md): pool creation, liquidity, queued swaps, and correlated outcomes, exercised through the contract test environments.
- [Consume the Firehose](../pages/guides/consume-the-firehose.md): connect to whole-block delivery, acknowledge durable progress, and resume after a disconnect.

For the full contract-to-application journey, follow the [counter tutorials](../pages/tutorials.md).

---

## Build a token

Source: <https://thruput.network/docs/guides/build-a-token/>

Build and test an ERC-20 contract with balances, allowances, administrator-controlled supply, and standard events.

Build the `erc20` contract in the [examples repository](https://github.com/thruputchain/thruput-examples/tree/main/contracts/erc20). You will trace a transfer, exercise minting and allowances, and test both native and RV32 execution.

This is a contract guide. The [counter series](../pages/tutorials/build-a-counter.md) covers the full contract-to-application journey; [TypeScript](../pages/typescript.md) covers application interactions.



## Prepare the project

Complete [CLI and Cargo setup](../pages/cli/install.md), then clone the examples repository if you do not already have it:

```bash
git clone https://github.com/thruputchain/thruput-examples.git
cd thruput-examples
```

Use the workspace’s manifests, toolchain, and lockfile together. The token implements the shared interface crates rather than copying their definitions.



## Model the token state

Open `contracts/erc20/src/implementation.rs`:

```rust
pub struct TokenContract {
    config: Value<Config>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Allowance>>,
    total_supply: Balance,
}
```

The storage attribute derives paths for these handles:

| Field          | Job                                             |
| -------------- | ----------------------------------------------- |
| `config`       | Administrator and optional token metadata       |
| `balances`     | Each account’s nonnegative token amount         |
| `allowances`   | An owner/spender pair’s remaining authorization |
| `total_supply` | Outstanding tokens                              |

Different map keys are independent. Balance changes use deltas instead of replacing a shared absolute value. See [Storage Types](../pages/programming-model/storage-types.md) for the merge rules.



## Follow a transfer

The implementation takes the payer from the direct caller. The internal `_move` helper does the debit, the credit, and the event:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    check_amount(amount);
    let owner = get_caller();

    self._move(&owner, receiver, amount);
}

// Move `amount` from `owner` to `receiver` and emit [`TransferEvent`].
fn _move(&mut self, owner: &ContractAddress, receiver: &ContractAddress, amount: Amount) {
    self._decrease_balance(owner, amount);
    self._lazy_increase_balance(receiver, amount);

    TransferEvent::new(owner, receiver, amount).log();
}
```

`check_amount` rejects a negative amount with `NegativeAmount`. The checked debit throws `TooLarge` if the balance does not cover the amount. The contract has no separate insufficient-balance error. The credit records a relative increase. The event records the movement for applications; it is not the source of the contract’s balance state.

`transfer_from` first spends the caller’s allowance, then performs the same debit and credit. An allowance belongs to a specific owner/spender pair, not to every caller.



## Apply supply and allowance policy

Read the `mint`, `burn`, `clawback`, and `adjust_allowance` implementations:

- Minting and clawback require the configured administrator. Holders burn their own tokens with `burn`, or tokens they hold an allowance for with `burn_from`.
- Initialization records that administrator and rejects a later initialization.
- Allowances change by a signed `difference`. A positive value adds authority; a negative value removes it.
- `delete_allowance` deletes an allowance. `delete_balance` requires a zero balance before it deletes its row.
- Only the two delete paths are exclusive. Each requests sole write access to its entry for the block. Other balance and allowance writes are not exclusive.

The metadata feature adds name, symbol, and decimals. The permit feature adds signed-operation authorization. Keep the basic transfer policy clear before extending either surface.



## Exercise the contract

```bash
cargo test -p erc20 --locked
```

This reports `erc20_test_rv32` as ignored. It needs the built artifact; `thruput test` runs it in the next section.

`tests/test_native.rs` deploys the contract in the SDK environment and runs the shared scenarios under `tests/common`. Inspect those scenarios for administrator checks, minting, transfers, allowance spending, cleanup, and expected exceptions.

`tests/same_block.rs` tests behavior that a serial-only token test would miss:

| Scenario                                                  | Expected result                                                       |
| --------------------------------------------------------- | --------------------------------------------------------------------- |
| Compatible credits to one balance                         | Deltas merge                                                          |
| Debits covered by the balance                             | Both can commit                                                       |
| Combined debits exceed the balance                        | Reservation excludes an overdrawing transaction                       |
| Read during the same block                                | Reads the block snapshot                                              |
| Approval and a separate spending transaction in one block | The new approval is not already spendable from the snapshot           |
| Allowance spend and the owner’s own debit in one block    | Both commit while the balance covers them; one more debit is excluded |

Run a specific case while inspecting the corresponding code:

```bash
cargo test -p erc20 --test same_block same_block_credits_merge --locked
```

**Checkpoint:** the native tests pass, including expected failure paths. A test that deliberately catches a contract exception can still be a passing test.



## Build and test the guest artifact

```bash
thruput build -p erc20
thruput test -p erc20
```

The build writes `target/thruput/erc20.rv32a` and spec sidecars. The artifact test exercises the compiled guest implementation. Keep it as well as the native tests.

You now have a deployable token artifact. Use [Deploy and call](../pages/cli/deploy-and-call.md) for network deployment and [Use contract bindings](../pages/tools/typescript-bindings.md) for typed application calls. The repository’s standard-token and factory examples add a fixed launch configuration for the separate launchpad application.



## Work with an agent

```text
Follow Build a token:
https://thruput.network/docs/guides/build-a-token/
Use contracts/erc20 in thruput-examples with its workspace lockfile.
Trace administrator checks, transfers, allowances, and events in source.
Run the native, same-block, and RV32 tests. Report actual results and
artifact paths. Do not replace the standard interface with invented APIs.
```

---

## Build an AMM

Source: <https://thruput.network/docs/guides/build-an-amm/>

Build and exercise a queued constant-product AMM, including liquidity, swaps, request outcomes, and RV32 tests.

Build the AMM contract suite in [thruput-examples](https://github.com/thruputchain/thruput-examples). This guide creates pools, adds and removes liquidity, and executes swaps through its native and RV32 test environments. You will also verify that a failed queued request does not become a false success.

Read [Build a token](../pages/guides/build-a-token.md) first. Complete [CLI and Cargo setup](../pages/cli/install.md). Commands run from the examples repository root with its checked-in manifests and lockfile.



## Assemble the components

| Source                   | Responsibility                                      |
| ------------------------ | --------------------------------------------------- |
| `interfaces/swap-if`     | Shared methods, request types, errors, and clients  |
| `engines/swap-pair`      | Constant-product math and reserve operations        |
| `contracts/swap-handler` | Apply a request, move tokens, and update pair state |
| `contracts/swap-driver`  | Queue and process requests                          |
| `contracts/swap-factory` | Create and connect a pool’s contracts               |
| `contracts/swap-router`  | User-facing liquidity and swap requests             |
| `helpers/batch-driver`   | Shared queue capacity and processing logic          |

The pair is an internal engine used by the handler, not another public contract entry point. The suite adapts [Uniswap V2 pair operations](https://github.com/Uniswap/v2-core/blob/master/contracts/UniswapV2Pair.sol) to Project Thruput’s execution model.



## Create a pool

Run the factory’s deployment scenario:

```bash
cargo test -p swap-factory --test factory create_pair_brings_up_pool --locked
```

Open `contracts/swap-factory/src/factory.rs` and `tests/factory.rs`. Creation derives and funds three addresses, deploys the LP token, handler, and driver, initializes their relationships, and records the pair. The tests verify the resulting pool and funding rules.

The factory takes funding from the caller through an allowance. It does not let arbitrary pool creators spend the factory’s own native tokens. Pool addresses are deterministic for the token pair and configured code hashes.

**Checkpoint:** a pool is created in the test environment with its contracts connected correctly. The test also checks that a second `create_pair` fails, so a passing run prints a `PairExists` exception.



## Add liquidity

```bash
cargo test -p swap-router --test add_liquidity --locked -- --nocapture
```

In `contracts/swap-router/tests/add_liquidity.rs`, the fixture establishes token balances, authorizes the handler, submits a liquidity request, and processes it. The test helper named `etx` is example test code, not an SDK API:

```rust
etx.user_allow_for_pair(user, amounts_desired)?;
etx.advance_block();
etx.user_add_liquidity(ALICE, amounts_desired)?;
etx.process_outstanding_requests(1)?;
```

The tests also separate the purchaser from the recipient: Alice can supply tokens while Bob receives LP tokens. Assertions check both the mint event and the actual LP balance.



## Execute a swap

```bash
cargo test -p swap-router --test swap carol_swap_exact_tokens_for_tokens --locked -- --nocapture
```

Open `contracts/swap-router/tests/swap.rs`. The exact-input scenario:

1. Establishes pool reserves.
2. Calculates expected output independently of the router.
3. Grants the handler an allowance for the input amount.
4. Submits a request with a minimum output.
5. Processes the queue.
6. Checks both token balances, the consumed allowance, and unchanged LP ownership.

The corresponding exact-output test checks that the requested output is received without exceeding the input cap.

**Checkpoint:** the swap tests pass with real state and event assertions, not just a successful method return.



## Understand acceptance and execution



Every swap changes reserves. Concurrent transactions using the same snapshot cannot all replace those reserves with different values. The implementation separates accepting requests from executing reserve-dependent work:

```text
users → router → driver queue
                    ↓
             process_requests
                    ↓
                 handler → pair engine
```

Queue inserts can merge. Processing consumes requests serially inside one transaction, so each operation sees earlier updates in that transaction. The handler accepts work from its driver, and the driver accepts requests from the configured router.

An accepted request is not a completed swap. Submission returns a request ID and emits `RequestAccepted`. A later operation event or `RequestFailed` identifies its outcome.



## Verify failures and request IDs



```bash
cargo test -p swap-router --test request_id --locked
cargo test -p swap-router --test swap swap_limits_respected --locked
cargo test -p swap-driver --test authorization --locked
```

These checks verify that request IDs reach terminal events, a request that misses its slippage limit fails (the exact-input case also checks that balances and the allowance are unchanged), and unauthorized calls cannot bypass the router/driver/handler chain.

Each request is handled with a gas cap and commit locking. A handled failure can roll back that request without taking down other requests in the processing transaction.



## Bound the queue and processing work



Queue capacity bounds pending storage. Consumption is checked during reservation across concurrent requests. An excluded submission is reported as `retry`. Resubmit the same signed transaction; it is not guaranteed a place in the next block.

Processing is permissionless and bounded by gas. The driver requires enough budget for the waiting work up to its configured minimum batch. It does not consume a request and then discard it merely because no processing budget remains.

```bash
cargo test -p swap-driver --test admission --locked
cargo test -p swap-driver --test min_batch --locked
cargo test -p swap-driver --test same_block --locked
```

These cases check queue limits, the minimum processing budget, and interactions with withdrawals and allowance changes. The source’s `process_requests_gas` helper supplies the budget calculation; do not copy a gas number from an unrelated operation.



## Remove liquidity

```bash
cargo test -p swap-router --test remove_liquidity --locked
```

The tests verify redemption and the distinction between the LP-token owner and the recipient of the withdrawn tokens. Run the complete native suite before changing the design:

```bash
cargo test -p swap-factory -p swap-router -p swap-driver -p swap-pair --locked
```

The suite reports four `sim_*` tests as ignored. They need simulator fixtures and are not part of this guide.



## Verify compiled contracts

Build the guest contracts used by the suite:

```bash
thruput build -p erc20
thruput build -p swap-factory
thruput build -p swap-handler
thruput build -p swap-driver
thruput build -p swap-router
cargo test -p swap-driver -p swap-router -p swap-factory --features guest_test --locked
```

`guest_test` runs the scenarios against the compiled RV32 implementations in the SDK test environment. It does not start a browser application or submit to Futurenet.

**Checkpoint:** you have built the AMM and verified pool creation, liquidity, swaps, and failure behavior through native and guest execution. The repository also contains an application under `apps/swap`; this guide focuses on the contract suite.



## Work with an agent

```text
Follow Build an AMM:
https://thruput.network/docs/guides/build-an-amm/
Use the existing swap contract suite in thruput-examples. Run pool,
liquidity, swap, slippage, request-ID, authorization, and queue tests.
Build the guest artifacts and rerun with guest_test. Explain how the
assertions establish each outcome. Do not equate request acceptance or
a successful processing transaction with completion of a specific swap.
```

---

## Consume the Firehose

Source: <https://thruput.network/docs/guides/consume-the-firehose/>

Connect to the hosted Futurenet firehose from a browser or Node, acknowledge blocks, and resume from durable progress.

The hosted Futurenet firehose is `wss://firehose.thruput.network`. It carries public chain data without authentication. It is experimental and has no SLA.

Use it for whole-block push delivery and bounded replay. Each block contains exact stored `EventIndexerPulledBlock` XDR bytes, transported as hex. Saving these bytes does not verify their commitments. Decode and verify with compatible protocol bindings if your application requires that assurance.



## Connect from a browser

Open a browser console and run:

```js
const ws = new WebSocket('wss://firehose.thruput.network');
ws.addEventListener('open', () => {
  ws.send(JSON.stringify({
    jsonrpc: '2.0', id: 1, method: 'firehose_subscribe',
    params: [{ from: 'tip' }],
  }));
});
ws.addEventListener('message', ({ data }) => console.log(JSON.parse(data)));
```

Browsers can connect directly; WebSocket connections do not use a CORS preflight. A page’s own Content Security Policy must permit the endpoint.

This first snippet only inspects messages. Close it with `ws.close()` before running a consumer. There is one subscription per connection, at most 8 concurrent connections per client IP, and 12 active subscribers globally.



## Process and acknowledge

A subscribe response returns the transport subscription ID. Notifications use `firehose_block` and carry `params.subscription` for routing. A block payload looks like this (hex abbreviated):

```json
{
  "type": "block",
  "subscriberId": 1,
  "block": {
    "schemaVersion": 2,
    "height": 42,
    "consensusHash": "<base58>",
    "byteLength": 27600,
    "record": "0x...",
    "ingestedAtUnixMicros": 1789720800000000
  }
}
```

`schemaVersion` is `2`. `consensusHash` is unprefixed base58. `byteLength` counts raw XDR bytes, not hex characters. `ingestedAtUnixMicros` is absent on archive reads.

The server waits for an application ACK before sending the next block. After durable processing, send:

```js
ws.send(JSON.stringify({
  jsonrpc: '2.0', id: 2, method: 'firehose_ack', params: [1, 42],
}));
```

Use the notification’s `subscriberId`, not the transport subscription ID. The ACK result is `null`. Use `firehose_unsubscribe` with `[subscriptionId]` to remove a subscription.

For a browser application, store output and an inclusive replay height together in an IndexedDB transaction before ACKing. After the ACK response succeeds, advance that checkpoint to the following height. If the ACK response is lost, keep the earlier replay height and process it idempotently. A received message or console log is not durable progress.



## Run the Node consumer

Use [consume-firehose.ts](https://github.com/thruputchain/thruput-examples/blob/main/examples/typescript/consume-firehose.ts) from the examples repository. Use Node 22.18 or newer. Clone the repository if you do not already have it, then install its dependencies and run from the repository root:

```bash
git clone https://github.com/thruputchain/thruput-examples.git
cd thruput-examples
npm install
npm run example:consume-firehose
# Optional configuration:
FIREHOSE_URL=wss://firehose.thruput.network OUTPUT_DIR=./my-output \
  npm run example:consume-firehose
```

Run one consumer per output directory on a filesystem supporting file and directory sync and atomic rename. A new directory subscribes at tip, meaning the next publication after registration. It does not request genesis or replay the current tip.

For each block the example validates the height and byte length, saves the inclusive replay height in `cursor.json`, writes and syncs `HEIGHT.xdr`, then ACKs. After a successful ACK response it saves the following height. Replaying a height overwrites the same output file. This is an idempotent byte sink, not a decoded indexer or a commitment verifier. Replace the file write with your application’s durable transaction as needed.

The checkpoint includes the endpoint so an accidental URL change cannot silently reuse another service’s cursor. Keep the output and checkpoint together. After a crash, a leftover `.tmp` file is not committed progress; the consumer resumes from `cursor.json`.



## Reconnect and resume

The Node example reconnects after transport loss with a 2-second delay. Stop it with Ctrl-C and restart with the same output directory to resume. It sends the saved inclusive replay height:

```json
{"jsonrpc":"2.0","id":1,"method":"firehose_subscribe","params":[{"from":"height","height":43}]}
```

Persist progress from the last acknowledged cursor, allowing conservative replay if ACK delivery or saving the checkpoint was uncertain. Do not resume from the last height merely received. A lost ACK response can cause a processed block to repeat across connections, so application effects must be idempotent.

A terminal notification has this payload:

```json
{"type":"closed","reason":"catchup_timeout","nextHeight":43}
```

Stop consuming that subscription. This is an application message, not a WebSocket close frame. It can be lost on a broken connection; your durable checkpoint remains the recovery source. The example stops on terminal notifications, JSON-RPC errors, and processing failures so you can inspect the cause.



## Handle an expired cursor

At attach, a height below `max(0, tip - 42428)` is rejected with JSON-RPC error `-32009`, message `below_window`. No records are delivered for that rejected request.

The serve window is 42,428 blocks, about 24 hours at about 2 seconds per block. Store retention is about 7 days, but clients can only request within the serve window. History starts when the archive started; neither genesis replay nor any depth beyond the window is promised. Even within the window, unavailable historical records terminate with `archive_error`.

On `below_window`, restore application state from another source or explicitly accept the missing interval and start a new tip subscription. For the example, using a new output directory makes that reset explicit and preserves the old checkpoint. Do not automatically replace an expired cursor with tip.



## Keep up with delivery

On the hosted Futurenet the live send plus ACK deadline is 60 seconds. A full live queue or expired live deadline demotes the subscriber to archive catch-up. An outstanding operation gets one additional 60-second catch-up deadline before `catchup_timeout`. Growing lag over the 120-second progress window terminates with `catchup_falling_behind`.

Blocks can be up to about 16 MB (about 32 MB of hex). A client must sustain roughly the chain’s record rate to keep up during a large-block burst; one that cannot falls behind and is closed with `catchup_falling_behind`, and can resume from its saved cursor.

Keep processing bounded and inspect [API errors, limits, and close reasons](../pages/reference/firehose.md) before retrying. `firehose_stats` reports active subscribers and process counters; sent counts measure transport enqueue, not completed application work.

Operators can also run `hog-firehose-store` and `hog-firehose-serve` themselves.
