# Tutorials

Documentation source: `3cc5d07f366f6182e06af875daffd57a90a66e06`. Hosted docs may be newer than this snapshot.

## Tutorials

Source: <https://thruput.network/docs/tutorials/>

Build a counter app from an empty directory through contract, TypeScript, React, and wallet connection tutorials.



## Build a counter app

One contract and one application across four parts:

1. [Contract](../pages/tutorials/build-a-counter.md): write, test, and deploy the counter.
2. [TypeScript](../pages/tutorials/work-with-thruput-from-typescript.md): create the client and a server-side development signer.
3. [React](../pages/tutorials/build-a-counter-with-react.md): build a working counter interface with development signing and receipt tracking.
4. [Connect a wallet](../pages/tutorials/connect-a-wallet-to-your-app.md): switch to wallet-approved updates and return to development signing on explicit disconnect.

Follow the four parts in order, using your own contract and deployment throughout. The [examples repository](https://github.com/thruputchain/thruput-examples) supplies a full-featured counter app for reference.

---

## Build a counter, part 1: Contract

Source: <https://thruput.network/docs/tutorials/build-a-counter/>

Create, test, and deploy the contract for a counter application, starting from an empty directory.

Build a small counter application from scratch. Across four parts, you will create a contract, add a TypeScript development signer, build a React interface, and let users switch to their own wallet.

You can also explore the [full counter example on GitHub](https://github.com/thruputchain/thruput-examples/tree/main/apps/counter).



## Create the contract

Complete [CLI installation and Cargo access](../pages/cli/install.md). For deployment, use a funded Futurenet account from the [CLI quickstart](../pages/get-started/cli.md).

```bash
thruput new counter --template counter
cd counter
```

Keep the generated manifest and toolchain settings. Open `src/implementation.rs`. The scaffold includes the Balance-based counter used by this guide; focus on its storage and these methods.



## Store a relative count

```rust
use thruput_sdk::storage::Balance;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}
```

`value` is a persistent storage handle. `Balance` stores nonnegative amounts and reads zero before the first update. Increment and decrement record relative changes:

```rust
pub fn initialize(&mut self, initial_value: u64) {
    self.value.increase(initial_value as i128);
}

pub fn increment(&mut self, amount: u64) {
    self.value.increase(amount as i128);
}

pub fn decrement(&mut self, amount: u64) {
    self.value.decrease(amount as i128);
}
```

Both methods take a nonnegative amount. `increase` checks for overflow, and `decrease` fails during execution if this invocation would take the count below zero. Both record deltas that can merge across compatible concurrent transactions within bounds. See [Balance](../pages/programming-model/storage-types.md#balance) for checked and lazy updates.

`Balance::get` returns zero for missing storage and preserves other storage errors:

```rust
pub fn get(&self) -> u64 {
    self.value.get() as u64
}
```

`initialize` adds its initial amount. It is an ordinary method, so call it once during this deployment flow. This teaching counter allows any caller to update it. Leave the extra scaffold event and error methods in place; the app does not need them.

Balance uses the same mergeable integer storage as NNInt. Once you understand the Balance API, read [NNInt and concurrent updates](../pages/programming-model/nnint.md) for signed deltas, explicit bases, and the underlying merge rules.



## Run both test modes

```bash
cargo test
thruput test
```

The native tests exercise contract logic and underflow handling. The artifact test runs the compiled RV32 contract. Neither needs a running RPC node.

**Checkpoint:** the counter tests pass, including a decrement that is expected to fail.



## Build, deploy, and initialize

```bash
thruput build
thruput deploy --estimate --profile futurenet
```

Add **10 native test tokens** to the reported minimum funding in whole-token units as an example allowance for initializer storage and later writes. This is a budget, not an exact estimate of those writes or a universal requirement. Replace `TOTAL_FUNDING` with the decimal sum. The minimum alone covers only the first balance-item deposit and deployment collateral, leaving no free contract balance. See [Estimate deployment funding](../pages/cli/deploy-and-call.md#estimate-deployment-funding).

```bash
thruput deploy --profile futurenet --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
thruput view counter get --profile futurenet
```

Confirm the deployment when prompted, or pass `--yes` when running without a terminal. Funding, deployment, and initialization happen in one transaction. The sender still needs its own storage and scheduling capacity. Your new counter should read `10`.

Save the printed deployment address. Part 2 uses this address and the contract spec produced by the build.



## Check a change

```bash
thruput call counter increment 1 --profile futurenet
thruput view counter get --profile futurenet
```

On your otherwise unchanged counter, the value is now `11`. Keep the same address and project for [part 2](../pages/tutorials/work-with-thruput-from-typescript.md).

For isolated local work, follow [Run a local node](../pages/cli/local-node.md) and use its profile, endpoint, and network identity consistently.



## Work with an agent

```text
Follow Build a counter, part 1:
https://thruput.network/docs/tutorials/build-a-counter/
Start with thruput new counter --template counter, without cloning an examples repo.
Run the native and RV32 checks, build, and read the deployment estimate.
Add the documented storage allowance to the minimum and deploy with that
explicit total using my configured Futurenet account. Initialize atomically to 10.
Report the actual address, transaction hash,
and read value. Keep the generated dependency configuration and report
failed checks rather than inventing results.
```

---

## Build a counter, part 2: TypeScript

Source: <https://thruput.network/docs/tutorials/work-with-thruput-from-typescript/>

Create a typed client and a small server-side development signer for the counter, without cloning a repository.

Build the TypeScript layer for the contract from [part 1](../pages/tutorials/build-a-counter.md). It will read the counter and prepare signed updates with a funded development key. The key stays in Node.js. Part 3 adds a React interface that can start counting immediately.



## Create the app directory

Inside the `counter` project from part 1:

```bash
mkdir app
cd app
npm init -y
npm pkg set type=module
```

Configure [npm registry access](../pages/typescript/setup.md#give-npm-package-access), then install the TypeScript dependencies:

```bash
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src/contracts
```

Keep the generated lockfile. Add these entries to `.gitignore`:

**.gitignore**

```text
node_modules/
dist/
.env
```



## Generate the TypeScript binding

Use Thruput CLI 0.29.0 or newer. Its TypeScript generator imports the `@thruputchain` packages used by this app. Generate the binding from the contract spec built in part 1. Run this from `app`:

```bash
thruput codegen ts ../target/thruput/counter.spec.xdr \
  --output src/contracts/counter.ts
```

The binding provides typed methods and decodes the contract’s results. Regenerate it when the contract interface changes.



## Configure the client

Get the network hash for the deployment with [`getNetworkInfo`](../pages/reference/json-rpc-api.md#getnetworkinfo):

```bash
curl -s https://rpc.thruput.network \
  -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"getNetworkInfo","params":{}}'
```

Futurenet resets can change this hash, so fetch it again after a reset.

Create `.env`. Set `NETWORK_HASH` to the `networkHash` value from the response and `COUNTER_ADDRESS` to the deployment address from part 1:

**.env**

```dotenv
RPC_URL=https://rpc.thruput.network
NETWORK_HASH=<network-hash>
COUNTER_ADDRESS=<your-deployed-counter-address>
```

These public values identify one deployment. A different network needs its own endpoint, hash, and contract address.

**chain.ts**

```ts
import {
  addressFromBase58, createThruputClient, createPubkeyAccount, createWalletClient,
  defineCluster, fromHex0x, hashFromBase58, networkHash, PrivateKeySigner,
} from "@thruputchain/client";
import { Counter } from "./src/contracts/counter.js";

function required(name: string) {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} in .env or the process environment`);
  return value;
}

export const rpcUrl = required("RPC_URL");
export const contract = addressFromBase58(required("COUNTER_ADDRESS"));
export const client = await createThruputClient({
  cluster: defineCluster({
    rpcUrl,
    networkHash: networkHash(hashFromBase58(required("NETWORK_HASH"))),
    capabilities: ["airdrop"],
  }),
});
export { Counter };

export function developmentWallet() {
  const signer = new PrivateKeySigner(fromHex0x(required("COUNTER_SIGNING_PRIVATE_KEY")));
  return createWalletClient({ client, account: createPubkeyAccount({ signer }) });
}
```



## Read and fund

**read.ts**

```ts
import { client, contract, Counter } from "./chain.js";

const result = await Counter.v0_1.get.view({ client, address: contract });
console.log("Counter:", result.value.toString());
console.log("Read at block:", result.stateBlockHeight.toString());
```

```bash
node --env-file=.env --import tsx read.ts
```

For a disposable development signer, generate a seed once in this terminal:

```bash
export COUNTER_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep this terminal environment for funding and the server. A persistent account should load its existing seed from secret configuration. Never put this key in a browser file or a `VITE_` variable.

**fund.ts**

```ts
import { toBase58 } from "@thruputchain/client";
import { developmentWallet } from "./chain.js";

const wallet = developmentWallet();
const funding = await wallet.requestAirdrop();
console.log("Development signer:", toBase58(wallet.account.address));
console.log("Funding transaction:", toBase58(funding.transactionHash));
```

```bash
node --env-file=.env --import tsx fund.ts
```



## Add the development server

The server exposes public configuration, proxies the app’s RPC requests, and prepares only a `+1` or `-1` call to the configured counter. Preparation signs but does not broadcast. The browser can therefore retain the hash before submission.

**server.ts**

```ts
import { createServer, type ServerResponse } from "node:http";
import { gasAmount, serializeSignedTransaction, toBase58, toHex0x } from "@thruputchain/client";
import { client, contract, Counter, developmentWallet, rpcUrl } from "./chain.js";

const wallet = process.env.COUNTER_SIGNING_PRIVATE_KEY ? developmentWallet() : null;
const allowed = new Set([
  "getVersionInfo", "getNetworkInfo", "getServerLimits", "getChainTip", "simulateInvocation",
  "getBalance", "getTransactionStatus", "getTransactionReceipt",
  "sendTransaction",
]);
function json(response: ServerResponse, status: number, value: unknown) {
  response.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  response.end(JSON.stringify(value));
}

createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/api/config") {
      return json(response, 200, {
        counterAddress: toBase58(contract), networkId: toBase58(client.network.networkHash),
        signerAddress: wallet ? toBase58(wallet.account.address) : null,
      });
    }
    if (request.method !== "POST") return json(response, 404, { error: "Not found" });
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 65_536) return json(response, 413, { error: "Request too large" });
      chunks.push(Buffer.from(chunk));
    }
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (request.url === "/api/prepare") {
      if (!wallet) return json(response, 503, { error: "Development signer unavailable" });
      if (body?.direction !== "increment" && body?.direction !== "decrement") {
        return json(response, 400, { error: "Choose increment or decrement" });
      }
      const direction: "increment" | "decrement" = body.direction;
      const transaction = await wallet.prepareExecution({
        invocation: Counter.v0_1[direction].invocation(contract, gasAmount(500_000n), { amount: 1n }),
        gasLimit: gasAmount(1_000_000n),
      });
      const signed = await wallet.signTransaction(transaction);
      return json(response, 200, { transaction: toHex0x(serializeSignedTransaction(signed)) });
    }
    if (request.url === "/thruput-rpc" && allowed.has(body?.method)) {
      const upstream = await fetch(rpcUrl, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body), signal: AbortSignal.timeout(10_000),
      });
      return json(response, upstream.status, await upstream.json());
    }
    json(response, 404, { error: "Not found" });
  } catch (error) {
    json(response, 500, { error: error instanceof Error ? error.message : "Request failed" });
  }
}).listen(3001, "127.0.0.1", () => console.log("Counter API: http://127.0.0.1:3001"));
```

Run it in the terminal holding the development key:

```bash
node --env-file=.env --import tsx server.ts
```

**Checkpoint:** the typed read works, the development account is funded, and the API is running. The server keeps its private key; `/api/config` exposes only public identity as base58. The signed transaction from `/api/prepare` stays `0x` hex. Part 3 turns these pieces into a usable React counter.

This server is for local development.



## Work with an agent

```text
Follow Build a counter, part 2:
https://thruput.network/docs/tutorials/work-with-thruput-from-typescript/
Generate the binding from my part-1 contract spec and create the listed
files using my deployment address. Verify the read, funding, and
public configuration endpoint. Keep the development key server-side.
Do not claim success for failed checks or submit replacement transactions
merely because observation failed.
```

---

## Build a counter, part 3: React

Source: <https://thruput.network/docs/tutorials/build-a-counter-with-react/>

Build a small React counter that can read and update the contract immediately through the development signer.

Add a React interface to the project from [part 2](../pages/tutorials/work-with-thruput-from-typescript.md). It will work through the funded development signer as soon as you open it. There is no wallet connection requirement yet.

Keep the API server running on port 3001. All files below are inside the `app` directory you created in part 2.



## Install React

From `app`, install the React packages and browser tooling:

```bash
npm install @thruputchain/react @tanstack/react-query react react-dom
npm install --save-dev vite @types/react @types/react-dom
```



## Add the browser entry point

```bash
npm pkg set scripts.dev="vite" scripts.build="tsc --noEmit && vite build"
```

**tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022", "module": "ESNext", "moduleResolution": "Bundler",
    "jsx": "react-jsx", "strict": true, "noUncheckedIndexedAccess": true,
    "skipLibCheck": true, "noEmit": true, "types": ["vite/client", "node"]
  },
  "include": ["*.ts", "src"]
}
```

**vite.config.ts**

```ts
import { defineConfig } from "vite";

export default defineConfig({
  server: {
    host: "127.0.0.1",
    proxy: {
      "/api": "http://127.0.0.1:3001",
      "/thruput-rpc": "http://127.0.0.1:3001",
    },
  },
});
```

**index.html**

```html
<!doctype html>
<html lang="en">
  <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Counter</title></head>
  <body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body>
</html>
```



## Connect the public client

**src/main.tsx**

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, defineCluster, hashFromBase58, networkHash } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { App } from "./App";
import type { Config } from "./updates";
import "./style.css";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting…</p>);

async function start() {
  const response = await fetch("/api/config");
  if (!response.ok) throw new Error("Could not load counter configuration");
  const config: Config = await response.json();
  const client = await createThruputClient({
    cluster: defineCluster({
      rpcUrl: new URL("/thruput-rpc", location.origin).href,
      networkHash: networkHash(hashFromBase58(config.networkId)),
      capabilities: [],
    }),
  });
  const queries = new QueryClient();
  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}><App config={config} /></WalletProvider>
    </QueryClientProvider>,
  );
}
void start().catch((error: unknown) => root.render(
  <p role="alert">{error instanceof Error ? error.message : "Could not start the app"}</p>,
));
```

The React provider shares the public client and discovers wallet providers without asking for permission. The next part uses that wallet context. The development signer remains on the API server.

Add a small stylesheet to keep the example readable on narrow screens:

**src/style.css**

```css
body { margin: 0; font-family: system-ui, sans-serif; }
main { max-width: 48rem; margin: auto; padding: 1.5rem; }
section { margin-block: 1.5rem; }
p { overflow-wrap: anywhere; }
button, select { max-width: 100%; margin: .25rem; padding: .5rem .75rem; font: inherit; }
output { font-size: 3rem; font-variant-numeric: tabular-nums; }
```



## Separate preparation from submission

Create a small shared update module. It retains the hash before submitting and can observe a saved operation after a reload:

**src/updates.ts**

```ts
import { useRef, useState } from "react";
import {
  deserializeSignedTransaction, fromHex0x, hashSignedTransaction, serializeSignedTransaction, toBase58,
  type ConnectedThruputClient,
} from "@thruputchain/client";
import { parseSignTransactionResult } from "@thruputchain/client/provider";
import { useClient, useWaitForTransactionReceipt } from "@thruputchain/react";

export type Config = { networkId: string; counterAddress: string; signerAddress: string | null };
export type Direction = "increment" | "decrement";
export type Pending = { hash: string; signedTransaction: string; account: string; networkId: string };
export type Prepared = { record: Pending; submit(): Promise<unknown> };

export async function archiveExpiredUpdate(client: ConnectedThruputClient, record: Pending, key: string, storage: Pick<Storage, "setItem" | "removeItem">) {
  if (toBase58(client.network.networkHash) !== record.networkId) throw new Error("Select the original network before recovery");
  const signed = deserializeSignedTransaction(fromHex0x(record.signedTransaction));
  const hash = hashSignedTransaction(signed);
  if (toBase58(hash) !== record.hash) throw new Error("Saved transaction hash does not match its bytes");
  const tip = await client.getChainTip();
  if (tip.blockHeight < signed.tx.uniquifier.block_expiry_height) throw new Error("The transaction has not expired; keep observing it");
  if (await client.getTransactionReceipt({ transactionHash: hash })) throw new Error("A receipt is available; check the transaction and finish it");
  // Expiry prevents future inclusion, but a missing receipt does not prove it never committed.
  storage.setItem(`${key}:archived:${record.hash}`, JSON.stringify({ ...record, outcome: "unresolved", archivedAtHeight: tip.blockHeight.toString() }));
  storage.removeItem(key);
}

export async function prepareDevelopment(client: ConnectedThruputClient, config: Config, direction: Direction): Promise<Prepared> {
  if (!config.signerAddress) throw new Error("Development signer unavailable");
  const response = await fetch("/api/prepare", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ direction }),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Preparation failed");
  const signed = deserializeSignedTransaction(fromHex0x(body.transaction));
  return {
    record: { hash: toBase58(hashSignedTransaction(signed)), signedTransaction: body.transaction, account: config.signerAddress, networkId: config.networkId },
    submit: () => client.sendTransaction({ signedTransaction: serializeSignedTransaction(signed) }),
  };
}

export function useUpdate(config: Config) {
  const client = useClient();
  const key = `counter:${config.networkId}:${config.counterAddress}`;
  const [state, setState] = useState<{ record: Pending | null; error: string | null }>(() => {
    try {
      const text = localStorage.getItem(key);
      if (!text) return { record: null, error: null };
      const value = JSON.parse(text);
      const signed = parseSignTransactionResult({ hash: value.hash, signedTransaction: value.signedTransaction });
      if (value.networkId !== config.networkId || typeof value.account !== "string") throw new Error("Invalid saved transaction");
      return { record: { ...signed, account: value.account, networkId: value.networkId }, error: null };
    } catch { return { record: null, error: "Cannot read the saved transaction. Check browser storage before sending." }; }
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const lock = useRef(false);
  const receipt = useWaitForTransactionReceipt({ hash: busy ? null : state.record?.hash ?? null });

  async function send(prepare: () => Promise<Prepared>) {
    if (lock.current || state.record || state.error) return;
    lock.current = true; setBusy(true); setError(null); setNotice(null);
    try {
      const update = await prepare();
      localStorage.setItem(key, JSON.stringify(update.record));
      setState({ record: update.record, error: null });
      await update.submit();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Update failed");
    } finally { lock.current = false; setBusy(false); }
  }
  function finish() {
    if (!receipt.data) return;
    try { localStorage.removeItem(key); setState({ record: null, error: null }); setError(null); }
    catch { setError("Could not clear the saved record"); }
  }
  async function archiveExpired() {
    if (lock.current || !state.record) return;
    const record = state.record;
    if (!window.confirm("Archive this expired update? Its past outcome may still be unknown. This does not resend or cancel it. Inspect its original hash before repeating the operation.")) return;
    lock.current = true; setBusy(true); setError(null);
    try {
      await archiveExpiredUpdate(client, record, key, localStorage);
      setState({ record: null, error: null });
      setNotice(`Archived ${record.hash} in browser storage. Its outcome is unresolved; inspect this hash before repeating the operation.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Recovery failed");
    } finally { lock.current = false; setBusy(false); }
  }
  return { pending: state.record, error: state.error ?? error, notice, busy, blocked: busy || Boolean(state.record || state.error), receipt, send, finish, archiveExpired };
}
```

The preparer returns a signed record and a submission function. This keeps the UI independent of how the signature was obtained. The record stores the hash, account, and network as base58, the same format the wallet provider and `useWaitForTransactionReceipt` use. Only the signed transaction stays `0x` hex. A failed storage write stops before submission. A later submission error retains the hash for observation.



## Build the small components

**src/Counter.tsx**

```tsx
import { addressFromBase58 } from "@thruputchain/client";
import { contractViewQueryOptions, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";
import { Counter } from "./contracts/counter";
import type { Direction, useUpdate } from "./updates";

export function CounterPanel({ address, disabled, send }: {
  address: string; disabled: boolean; send(direction: Direction): void;
}) {
  const client = useClient();
  const counter = useQuery({
    ...contractViewQueryOptions({ client, method: Counter.v0_1.get, address: addressFromBase58(address) }),
    refetchInterval: 2_000,
  });
  return <section>
    {counter.isLoading ? <p>Reading counter…</p> : null}
    {counter.error ? <p role="alert">{counter.error.message}</p> : null}
    <p><output aria-label="Counter value">{counter.data?.value.toString() ?? "Not loaded"}</output></p>
    <button type="button" disabled={disabled || !counter.data || counter.data.value === 0n} onClick={() => send("decrement")}>Decrement</button>
    <button type="button" disabled={disabled || !counter.data} onClick={() => send("increment")}>Increment</button>
  </section>;
}

export function UpdateStatus({ update }: { update: ReturnType<typeof useUpdate> }) {
  const execution = update.receipt.data?.execution;
  const succeeded = execution !== undefined && "result" in execution && execution.result === "return";
  return <section aria-label="Transaction">
    {update.busy ? <p>Preparing or submitting…</p> : null}
    {update.error ? <p role="alert">{update.error}</p> : null}
    {update.notice ? <p role="status">{update.notice}</p> : null}
    {update.pending ? <>
      <p>Original signer: {update.pending.account}</p>
      <p>Transaction: {update.pending.hash}</p>
      {update.receipt.data ? <>
        <p role="status">{succeeded ? "Update committed" : "Execution failed"}</p>
        <button type="button" onClick={update.finish}>Finish</button>
      </> : <>
        <p>Waiting for a result. A timeout does not cancel the transaction.</p>
        {update.receipt.error ? <p role="alert">{update.receipt.error.message}</p> : null}
        <button type="button" disabled={update.busy || update.receipt.isFetching} onClick={() => void update.receipt.refetch()}>Check transaction</button>
        <button type="button" disabled={update.busy} onClick={() => void update.archiveExpired()}>Archive expired update</button>
      </>}
    </> : null}
  </section>;
}
```

**src/App.tsx**

```tsx
import { useClient } from "@thruputchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { prepareDevelopment, useUpdate, type Config } from "./updates";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const update = useUpdate(config);
  return <main>
    <h1>Counter</h1>
    <p>Using development signer: {config.signerAddress ?? "Not configured"}</p>
    <CounterPanel address={config.counterAddress} disabled={update.blocked || !config.signerAddress}
      send={direction => void update.send(() => prepareDevelopment(client, config, direction))} />
    <UpdateStatus update={update} />
  </main>;
}
```



## Run and verify

In a second terminal inside `app`, leaving the API server running:

```bash
npm run dev
```

Open Vite’s URL. Click **Increment**, wait for **Update committed**, and confirm the refreshed counter value. Click **Finish** before another update. Try **Decrement** too.

The public read refreshes independently of signing. An error or timeout does not cause another transaction to be submitted. A saved hash remains available after reload; this minimal example keeps one unresolved update per counter and network in one browser tab.

If submission was stopped after signing, a receipt may never arrive. **Archive expired update** checks the original network, signed bytes, expiry height, and receipt before releasing the active slot. It preserves the complete record under `counter:NETWORK:CONTRACT:archived:HASH` in browser storage. It does not resend the transaction or prove it never committed: an unavailable or lagging indexer can still hide a past receipt. Inspect the original hash before repeating the operation. Recovery errors, including a failed archive write, keep the active record.

```bash
npm run build
```

**Checkpoint:** a working React counter using a server-held development signer. No wallet connection or keyboard/concurrency machinery is needed. Part 4 adds a different signing path to these same components.



## Work with an agent

```text
Follow Build a counter, part 3:
https://thruput.network/docs/tutorials/build-a-counter-with-react/
Create the listed files in my existing app directory. Do not clone an
examples repo. Verify reads, increment/decrement, transaction feedback,
and the build. Keep the development key on the server and retain an
unresolved transaction's hash instead of submitting a replacement.
```

---

## Build a counter, part 4: Connect a wallet

Source: <https://thruput.network/docs/tutorials/connect-a-wallet-to-your-app/>

Let the user switch from the development signer to a connected wallet in the same counter application.

Keep the app from [part 3](../pages/tutorials/build-a-counter-with-react.md). It already works through the development signer. Add wallet controls so a successful connection switches new updates to the user’s wallet; explicit disconnect returns to the development signer.

The display, contract, public client, and transaction-status component stay the same. Only preparation and submission differ.



## Prepare the wallet

Install the [Wallet Extension](../pages/tools/wallet-extension.md) and select the app’s network. Request native test tokens for that wallet’s account; it is independent of the server’s development signer.

`WalletProvider` is already mounted from part 3. It discovers providers without requesting permission.



## Add wallet controls

**src/WalletControls.tsx**

```tsx
import { useWallet } from "@thruputchain/react";

export function WalletControls({ busy, walletMode, disconnect }: {
  busy: boolean; walletMode: boolean; disconnect(): void;
}) {
  const wallet = useWallet();
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  return <section aria-label="Wallet connection">
    <label>Wallet <select name="wallet" value={wallet.provider?.info.id ?? ""}
      disabled={busy || connecting || wallet.providers.length === 0}
      onChange={event => wallet.selectProvider(event.target.value)}>
      <option value="" disabled>No wallet detected</option>
      {wallet.providers.map(provider => <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>)}
    </select></label>
    <button type="button" disabled={busy || connecting || !wallet.provider || wallet.status === "connected"}
      onClick={() => void wallet.connect()}>Connect wallet</button>
    {walletMode ? <button type="button" disabled={busy || connecting} onClick={disconnect}>Disconnect wallet</button> : null}
    {wallet.session && wallet.session.accounts.length > 1 ? <label>Account
      <select name="account" value={wallet.address ?? ""} disabled={busy || connecting}
        onChange={event => wallet.selectAccount(event.target.value)}>
        {wallet.session.accounts.map(account => <option key={account.address} value={account.address}>{account.address}</option>)}
      </select>
    </label> : null}
    {wallet.status === "wrongNetwork" ? <p role="alert">Select the app's network in your wallet.</p> : null}
    {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
  </section>;
}
```



## Add the wallet preparer

**src/wallet-update.ts**

```ts
import { addressFromBase58, gasAmount } from "@thruputchain/client";
import type { ProviderWalletClient } from "@thruputchain/client/wallet";
import { Counter } from "./contracts/counter";
import type { Config, Direction, Prepared } from "./updates";

export async function prepareWallet(wallet: ProviderWalletClient, account: string, config: Config, direction: Direction): Promise<Prepared> {
  const transaction = await wallet.prepareExecution({
    invocation: Counter.v0_1[direction].invocation(addressFromBase58(config.counterAddress), gasAmount(500_000n), { amount: 1n }),
    gasLimit: gasAmount(1_000_000n),
  });
  const signed = await wallet.signTransaction(transaction);
  return {
    record: { ...signed, account, networkId: config.networkId },
    submit: () => wallet.submitTransaction(signed),
  };
}
```

The same `useUpdate` hook saves the signed record before invoking `submit`. The wallet returns the transaction hash in base58, the same format as the development record. A wallet rejection prevents submission. The application never receives the wallet’s private key.



## Switch signing paths

Replace `src/App.tsx`:

**src/App.tsx**

```tsx
import { useEffect, useState } from "react";
import { useClient, useWallet, useWalletClient } from "@thruputchain/react";
import { CounterPanel, UpdateStatus } from "./Counter";
import { WalletControls } from "./WalletControls";
import { prepareDevelopment, useUpdate, type Config, type Direction } from "./updates";
import { prepareWallet } from "./wallet-update";

export function App({ config }: { config: Config }) {
  const client = useClient();
  const wallet = useWallet();
  const signingClient = useWalletClient();
  const update = useUpdate(config);
  const [selected, setSelected] = useState<"development" | "wallet">("development");
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";
  useEffect(() => { if (authorized) setSelected("wallet"); }, [authorized]);
  const walletMode = authorized || selected === "wallet";
  const connecting = wallet.status === "connecting" || wallet.status === "disconnecting";
  const canSend = walletMode ? wallet.status === "connected" && signingClient !== null : config.signerAddress !== null;

  function disconnect() {
    void wallet.disconnect();
    setSelected("development");
  }
  function send(direction: Direction) {
    if (!canSend || connecting || update.blocked) return;
    if (walletMode) {
      if (!signingClient || !wallet.address) return;
      const originalClient = signingClient;
      const originalAccount = wallet.address;
      void update.send(() => prepareWallet(originalClient, originalAccount, config, direction));
    } else {
      void update.send(() => prepareDevelopment(client, config, direction));
    }
  }
  return <main>
    <h1>Counter</h1>
    <p>{walletMode ? "Using connected wallet" : "Using development signer"}: {walletMode ? wallet.address ?? "Unavailable" : config.signerAddress ?? "Unavailable"}</p>
    <WalletControls busy={update.busy} walletMode={walletMode} disconnect={disconnect} />
    <CounterPanel address={config.counterAddress} disabled={!canSend || connecting || update.blocked} send={send} />
    <UpdateStatus update={update} />
  </main>;
}
```

A successful connection selects wallet signing immediately. A later session loss or wrong network keeps wallet mode selected and pauses writes. It does not silently send through the development key. Explicit disconnect opts back into development signing.

Each update captures its original signing client and account. A receipt is observed through the public client, so disconnecting does not cancel an already-submitted transaction.



## Verify both paths

1. Open the app disconnected. Increment with the development signer and inspect its hash and result.
2. Connect your wallet on the correct network. Confirm the displayed account changes.
3. Increment again and approve the request in the wallet. Wait for the receipt and refreshed value.
4. Reject another approval. The page should show the error without sending through the development signer.
5. Disconnect explicitly. The development-signer label and immediate-update path return.

After a committed result, **Finish** clears its saved record. For an unresolved result, **Check transaction** observes the original hash without submitting again. Reload with a saved hash to verify recovery.

A session change can stop submission after the signed record was saved. Once the signed transaction expires, use **Archive expired update** from part 3 to preserve its evidence and release the active slot. This never switches signers, resubmits, or treats a missing receipt as proof of failure.

```bash
npm run build
```

**Checkpoint:** a small, complete app built without a repository clone. Its default signer is convenient for development, and connected users can approve their own transactions.

You can also explore the [full counter example on GitHub](https://github.com/thruputchain/thruput-examples/tree/main/apps/counter).



## Work with an agent

```text
Follow Build a counter, part 4:
https://thruput.network/docs/tutorials/connect-a-wallet-to-your-app/
Extend my part-3 app using the listed files. Keep development signing
as the default, switch on wallet connection, and return only on explicit
disconnect. Let me approve wallet requests. Verify both paths, rejection,
wrong-network handling, receipt recovery, and the build. Do not clone
the examples repo or add keyboard/concurrency features to this tutorial.
```
