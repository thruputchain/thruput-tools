# TypeScript

Documentation source: `44bc1f66f613eb3dcda6693605fcd1b6d4a41d48`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## TypeScript

Source: <https://thruput.network/typescript/>

Connect applications and services to Stellar Thruput with the TypeScript client and typed contract bindings.

Build browser applications, Node.js services, and scripts with `@thruputchain/client`. You can read an existing contract without a wallet, signing key, Rust installation, or deployment.



## The application model

A **public client** connects to an RPC endpoint and reads network data. A **contract binding** describes methods, arguments, results, errors, and events. Together they provide typed contract reads.

Writes also need an **account** and authorization. A browser app connects to the user’s wallet provider. A script or service can manage a signer directly. A wallet client wraps application calls into a transaction, signs it, submits it, and observes its result.

```text
Read:   contract binding + public client → typed result
Write:  contract binding + wallet client → signed transaction → receipt
```



## How the packages fit

| Package or entry point           | Role                                                                                    |
| -------------------------------- | --------------------------------------------------------------------------------------- |
| `@thruputchain/client`           | RPC clients, accounts, wallet helpers, amounts, and contract runtime                    |
| `@thruputchain/client/contracts` | Standard contract bindings supplied with the client, including ERC-20 and DefaultWallet |
| `@thruputchain/protocol`         | Wire types, serialization, and protocol constants such as `HOG_ADDRESS`                 |
| `@thruputchain/contract-spec`    | Contract schema tooling; most applications use the generated binding instead            |
| `@thruputchain/react`            | React integration over the client and wallet model; see [React](../pages/react.md)      |

Generated bindings are application files, not a replacement for the client package. They import its contract runtime.



## Start with an existing contract

The [TypeScript quickstart](../pages/get-started/typescript.md) reads Futurenet’s native-token contract using its supplied binding and address. [Read contract data](../pages/typescript/reads.md) uses the same checkpoint, so you can learn the application APIs without first writing a contract.

For a custom contract, obtain its generated bindings, deployment address, and network from its author. [Use contract bindings](../pages/tools/typescript-bindings.md) explains how those pieces fit.

[Read events](../pages/typescript/events.md) completes the read-only path with filters, decoding, and historical pagination. It also needs no wallet or signer.



## Add writes

Read [Accounts and wallet clients](../pages/typescript/wallet-clients.md) to understand account identity, authorization, and call wrapping. Then choose one integration path for your application:

- [Connect a wallet](../pages/tools/wallet-integration.md) when the user’s browser wallet manages approval and signing.
- [Use a signer in scripts](../pages/typescript/accounts.md) when your Node.js process manages the account key.

These are alternatives, not consecutive setup steps. Both lead to [Send transactions](../pages/typescript/transactions.md) and [Track transaction results](../pages/typescript/transaction-status.md). [Deploy a contract](../pages/typescript/deployment.md) builds on that transaction flow when your application needs to create a deployment.

Complete applications live in [Guides](../pages/guides.md). This section covers individual tasks; [Client API reference](../pages/tools/typescript-sdk.md) and [Wallet provider reference](../pages/tools/wallet-provider.md) provide lookup tables.

---

## Package setup

Source: <https://thruput.network/typescript/setup/>

Configure access to Stellar Thruput's JavaScript packages for TypeScript and React applications.

The private `@thruputchain` TypeScript client and React library are distributed through GitHub Packages. Configure registry access once, then install the packages your application imports.



## Before you start

- Install Node.js 22.12 or newer and npm.
- Obtain access to Stellar Thruput’s GitHub packages.
- Install the [GitHub CLI](https://cli.github.com/) and sign in with `gh auth login`.



## Give npm package access

Authorize package reads, then make the token available to npm in this terminal:

```bash
gh auth refresh -h github.com -s read:packages
export NODE_AUTH_TOKEN="$(gh auth token)"
```

Create a `.npmrc` file in the application directory:

```ini
@thruputchain:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Keep `${NODE_AUTH_TOKEN}` as a literal reference in this file. Do not replace it with the token. If your environment already supplies a package-read token, use that instead of the GitHub CLI commands.

Use the latest packages when starting a new project and keep the generated lockfile. A package-access error needs an account or token with the required permissions; repository access alone may not be enough.



## Install the TypeScript client

In a new application directory:

```bash
npm init -y
npm pkg set type=module
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
mkdir -p src
```

In an existing application, keep its package configuration and add the dependencies you need. `tsx` runs the Node.js examples; browser apps can use their existing bundler.

The client re-exports common types and constructors. Install the protocol package directly when you import protocol-only constants such as `HOG_ADDRESS`. Schema tooling can import `@thruputchain/contract-spec`; ordinary generated bindings use the client runtime.



## Type-check an application

For the Node.js examples, create `tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "skipLibCheck": true,
    "noEmit": true
  },
  "include": ["src/**/*.ts"]
}
```

```bash
npx tsc
```

The examples use ESM imports and `.js` paths for local TypeScript modules. Browser projects should keep the module settings required by their bundler.

---

## Connect to a network

Source: <https://thruput.network/typescript/connect/>

Create a public client, select Futurenet or a local endpoint, and check network identity.

A public client performs RPC reads without signing. Create one per application network and share it across contract bindings and wallet clients.



## Connect to Futurenet

Create `src/client.ts`:

```ts
import { createThruputClient, devnet } from "@thruputchain/client";

export const client = await createThruputClient({ cluster: devnet() });
```

Client creation is asynchronous. It fetches the network identity before returning. Other examples import this client from `./client.js`.

To check the connection, create `src/network.ts`:

```ts
import { toHex0x } from "@thruputchain/client";
import { client } from "./client.js";

const [tip, version] = await Promise.all([
  client.getChainTip(),
  client.getVersion(),
]);
console.log("Network:", toHex0x(client.network.networkHash));
console.log("Block:", tip.height.toString());
console.log("Wire format:", version.wireFormat);
```

```bash
npx tsx src/network.ts
```

No wallet permission or account funding is required.



## Select another endpoint

The SDK helper is still named `devnet()` for compatibility. `devnet({ rpcUrl })` overrides the Futurenet endpoint. For a local node, replace the cluster with `localnet()`:

```ts
import { createThruputClient, localnet } from "@thruputchain/client";

const client = await createThruputClient({ cluster: localnet() });
```

Start the node with [the CLI](../pages/cli/local-node.md) first. Local account manifests and RPC endpoints must refer to the same node.

Use `defineCluster()` for a reusable custom descriptor. `mainnet()` requires an explicit endpoint. Cluster capabilities, such as `airdrop`, declare expected services; they are not server capability discovery.



## Pin a network identity

Futurenet is unpinned by default. To require a specific deployment, provide the trusted hash from your environment:

```ts
import { createThruputClient, devnet, hashFromHex, networkHash } from "@thruputchain/client";

const expected = process.env.THRUPUT_NETWORK_HASH;
if (!expected) throw new Error("Set THRUPUT_NETWORK_HASH to the expected 0x-prefixed hash");
const client = await createThruputClient({
  cluster: devnet({ networkHash: networkHash(hashFromHex(expected)) }),
});
```

An identity mismatch throws `NetworkMismatchError`. A Futurenet reset can change the network hash. Update the trusted configuration deliberately rather than accepting a wallet-supplied hash as your application’s network.



## Configure transport behavior

Use [HTTP transport](../pages/typescript/transport.md) for timeouts, batching, and custom transports. A transport-only client skips cluster identity validation; a wallet bound to it requires an explicit signing network hash.

---

## Configure HTTP transport

Source: <https://thruput.network/typescript/transport/>

Set RPC timeouts, batch independent reads, and classify transport failures.

The client uses HTTP JSON-RPC by default. Supply `HttpTransport` when you need explicit timeout, header, or batching settings.



## Set a request timeout

```ts
import { createThruputClient, devnet, HttpTransport } from "@thruputchain/client";

const cluster = devnet();
const client = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, { timeoutMs: 10_000 }),
});
```

The cluster still controls identity checks; the transport controls requests to the endpoint. A timeout ends observation of that request, not an already-submitted transaction.



## HTTP batching

Batch independent RPC reads into fewer HTTP requests:

```ts
const batched = await createThruputClient({
  cluster,
  transport: new HttpTransport(cluster.rpcUrl!, {
    batch: { maxSize: 100, waitMs: 0 },
    timeoutMs: 10_000,
  }),
});
const [tip, version] = await Promise.all([
  batched.getChainTip(),
  batched.getVersion(),
]);
```

Batching is off by default. `batch: true` uses the defaults shown. Concurrent requests are grouped within the scheduling window and split at `maxSize`.

- Responses match by request ID, not array position.
- Per-call RPC errors remain separate. HTTP or malformed-batch failures reject affected requests.
- Cancellation removes one caller; canceling every caller can cancel the shared request.
- HTTP batching does not provide a shared state snapshot or an atomic transaction. Use [shared-snapshot reads](../pages/typescript/reads.md#read-related-values-from-one-snapshot) when related contract values must come from one state; awaiting separate reads does not make their snapshots match.

Server [array and byte limits](../pages/reference/json-rpc-api.md#json-rpc-arrays) still apply.



## Handle transport errors

| Error                                       | Boundary                                                        |
| ------------------------------------------- | --------------------------------------------------------------- |
| `HttpRequestError`                          | Network request failed                                          |
| `HttpResponseError`                         | Non-success HTTP status                                         |
| `JsonRpcError`                              | RPC error response; includes `code`, `data`, and method context |
| `ContractViewError` / `ContractDecodeError` | Contract outcome or decoding, not transport                     |

Use `classifyReadError(error, { signal })` when implementing a bounded read-retry policy. See [read cancellation](../pages/typescript/reads.md#cancel-stale-reads). Do not apply automatic read retries to transaction submission.



## Use a custom transport

Implement the exported `Transport` interface when integrating another request layer. A client created with only a transport has no validated cluster identity. For wallet use, provide a trusted signing network hash and verify the endpoint separately, or supply a cluster descriptor as above.

---

## Addresses and amounts

Source: <https://thruput.network/typescript/values/>

Parse and display exact amounts, addresses, and hashes in a TypeScript application.

Contract integers are JavaScript `bigint` values. Addresses and hashes are typed byte arrays. Convert at the application’s input and display boundaries.



## Parse and display amounts

```ts
import { parseUnits, formatUnits } from "@thruputchain/client";

const amount = parseUnits("12.05", 2); // 1205n
console.log(formatUnits(amount, 2));  // "12.05"
const oneHog = parseUnits("1", 7);    // 10000000n
```

Both helpers support 0–255 decimals and signed amounts. Parsing rejects whitespace, exponents, and excess precision rather than rounding. `ParseUnitsError.code` is `malformed` or `precision`; invalid decimal counts throw `RangeError`.

The native token has seven decimal places. Other tokens choose their own decimals. Check positivity and the contract’s integer bounds separately. Avoid converting amounts to `number`, which can lose precision.



## Convert addresses and hashes

```ts
import { addressFromHex, hashFromHex, toHex0x } from "@thruputchain/client";

export function parseInputs(addressText: string, transactionText: string) {
  const address = addressFromHex(addressText);
  const txHash = hashFromHex(transactionText);
  return { address, txHash, displayAddress: toHex0x(address) };
}
```

These inputs use `0x`-prefixed hex. Provider session network hashes use a different wire format: 64 lowercase hex characters without `0x`. Convert explicitly when crossing the [wallet provider](../pages/tools/wallet-provider.md#canonical-data-and-limits) boundary.

Use `gasAmount(500_000n)` for a typed gas budget. A gas amount is a computation limit, not a native-token amount.



## Store values in application data

JavaScript’s default JSON serializer does not accept `bigint`. For application-owned storage, use decimal strings for integers and a defined byte encoding for addresses, hashes, and cursors. The client handles RPC serialization itself.

---

## Use contract bindings

Source: <https://thruput.network/tools/typescript-bindings/>

Select a generated interface, bind a deployment address, and work with typed arguments and results.

Bindings describe a contract’s API. The client runtime uses them to encode arguments and decode results, exceptions, and events. A binding does not select a network or deployment address.



## Obtain the binding

The client supplies standard bindings such as `ERC20` through `@thruputchain/client/contracts`. For a custom contract, obtain its generated `.ts` file, address, and network from the contract author.

Generate a binding yourself only when you have its build or canonical spec. See [CLI code generation](../pages/cli/codegen.md) and [the contract-side handoff](../pages/contracts/client-bindings.md).



Regenerate when methods, argument or return types, declared exceptions, or events change. Keep the generated file and deployment from the same interface build. Put application wrappers in separate files.



## Select an Interface Version

```ts
import { ERC20 } from "@thruputchain/client/contracts";

const tokenInterface = ERC20.v0_1;
```

Methods and their types live under an interface’s compatibility major. A generated counter might export `Counter.v0_1`; use the actual exports in its generated file rather than reconstructing names.

```ts
import { Counter as CounterVersions } from "./contracts/my-counter.js";

const Counter = CounterVersions.v0_1;
const args: CounterVersions.v0_1.IncrementArgs = { amount: 1n };
```

The value alias does not create a TypeScript type namespace. Keep the full path for explicit type annotations.



## Bind a deployment

```ts
import { getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
const supply = await hog.totalSupply.view({ args: undefined });
```

`getContract` binds the descriptor to an address and client. It does not deploy or authorize anything. Use [Read contract data](../pages/typescript/reads.md) for view behavior and caller context.



## Method Descriptors

| API                                                               | Purpose                                                                                                         |
| ----------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `method.invocation(contract, gasLimit, args)`                     | Build calldata and the target invocation                                                                        |
| `method.call({ contract, gasLimit, args })`                       | Retain result and exception decoders with the invocation                                                        |
| `method.view({ client, contract, args, minHeight?, signal? })`    | Read a typed value with height, gas use, and events; optional freshness floor                                   |
| `method.viewOutcome(...)`                                         | Return a typed return/abort/fault outcome                                                                       |
| `method.viewRequest({ contract, args, caller? })`                 | Prepare an independent read with its decoder for `client.readViews`; no I/O, and freshness belongs to the group |
| `method.decodeArgs(bytes)`                                        | Decode complete calldata                                                                                        |
| `method.decodeReturn(bytes)` / `decodeException(bytes)`           | Decode known method output                                                                                      |
| `method.decodeReceipt(receipt)` / `decodeReceiptOutcome(receipt)` | Decode a receipt for that root method                                                                           |

Direct descriptor calls can omit absent arguments. Bound argumentless views use `{ args: undefined }`. Public argument names use camelCase; ABI names remain in metadata. Contract integers use `bigint`.

Existing generated bindings gain `viewRequest()` through the client runtime; this feature needs no new codegen metadata. See [shared-snapshot reads](../pages/typescript/reads.md#read-related-values-from-one-snapshot) for grouped calls and [minimum heights](../pages/typescript/reads.md#read-after-confirmation) for single reads.



## Execute and Decode

Build calls with `.call(...)` when the application needs typed return values, then pass them to a wallet’s `executeCallsAndWait`. Returned values follow call order. See [Send transactions](../pages/typescript/transactions.md).

Receipt decoders require the known root method. For wallet-wrapped calls, use the wallet execution helpers or `decodeExecution(receipt, calls)` instead of treating the receipt as the child’s receipt. See [Track transaction results](../pages/typescript/transaction-status.md#decode-the-correct-method).



## Exceptions

Each interface exposes declared and unknown exception types. A declared exception has `kind: "declared"`, selector, name, decoded value, and a symbolic variant for enum errors. An unknown selector has `kind: "unknown"`, selector, and its raw data.

Return and declared-exception decoders reject trailing bytes. Unknown exceptions retain the bytes they cannot interpret. A successful transaction whose result cannot be decoded is still a successful execution.



## Events



Events use their defining crate, version, module, and type path. A descriptor builds topic filters, decodes event rows, and selects events from receipts. See [Read events](../pages/typescript/events.md) for examples and pagination.



## Type Mapping

Bindings describe structs, enum variants, unions, tuples, and optional values. Use the generated types rather than rebuilding their shapes or encoding calldata manually.

| Contract type              | TypeScript type                        |
| -------------------------- | -------------------------------------- |
| Void                       | `void`                                 |
| Bool                       | `boolean`                              |
| Integer                    | `bigint`                               |
| String                     | `string`                               |
| Address                    | `ContractAddress`                      |
| Bytes / vector of u8       | `Uint8Array`                           |
| Other vectors              | `T[]`                                  |
| Fixed bytes                | `FixedBytes<N>`                        |
| Fixed arrays of length 0–3 | Exact readonly tuple                   |
| Longer fixed arrays        | `FixedArray<T, N>`                     |
| Tuple                      | Readonly tuple                         |
| Option                     | `T \| null`                            |
| Named struct               | Interface in its spec-ID namespace     |
| Enum                       | Bigint value union and const object    |
| Union                      | Discriminated `{ case, value? }` union |
| SignedToken                | `SignedToken<T>` placeholder           |

`fixedBytes` validates and brands mutable bytes; `fixedArray` returns a frozen copy. `signedToken<T>()` supplies a zero-byte placeholder, not authorization. See [Addresses and amounts](../pages/typescript/values.md) for input conversion.



## Standard Bindings

The client includes versioned DefaultWallet and ERC-20 interfaces, plus related metadata, permit, and signed-operation interfaces. Use the [generated client API](https://client-ts.thruput.network/) for the complete export list.

---

## Read contract data

Source: <https://thruput.network/typescript/reads/>

Read typed contract values, require a minimum height, and group related reads at one committed snapshot.

A view simulates a contract call against committed state without submitting a transaction. It needs a public client and a binding, not a signer.





## Read the existing native-token contract

Use the `src/client.ts` from [Connect to a network](../pages/typescript/connect.md). Create `src/read.ts`:

```ts
import { formatUnits, getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
const result = await hog.totalSupply.view({ args: undefined });
console.log("Native-token supply:", formatUnits(result.value, 7));
console.log("Read at block:", result.height.toString());
```

```bash
npx tsx src/read.ts
```

The client supplies the standard ERC-20 binding, and the protocol package supplies the deployed native-token address as `HOG_ADDRESS`. No Rust contract or generated application file is needed for this example.



## Pass arguments and caller context

For an address held by your application:

```ts
import { addressFromHex } from "@thruputchain/client";

export async function readBalance(ownerText: string, signal?: AbortSignal) {
  const owner = addressFromHex(ownerText);
  return hog.getBalanceOf.view({ args: { addr: owner }, signal });
}
```

A view result includes the typed `value`, snapshot `height`, `gasUsed`, and simulated `events`. Independent reads can use different snapshots or lag a recent transaction receipt.

Pass `caller` when the method needs a simulated caller. This changes call context; it does not prove control of that address or authorize a transaction.



## Read after confirmation

Pass a successful receipt’s `height` as `minHeight` when the read must include that committed transaction:

```ts
export async function readBalanceAtLeast(ownerText: string, minHeight: bigint, signal?: AbortSignal) {
  return hog.getBalanceOf.view({
    args: { addr: addressFromHex(ownerText) },
    minHeight,
    signal,
  });
}
```

`minHeight` is an optional nonnegative `bigint` freshness floor, not an exact historical height. The same option works with generated `.view()`, `.viewOutcome()`, bound views, and raw `client.view()`. Omit it for an unconstrained read.

A backend whose selected snapshot is behind returns `ViewHeightUnavailable` (`-32011`) with requested and observed heights. The request does not wait for a block or force a refresh, and the client does not poll or retry it. Keep the confirmed receipt and decide when to retry the read; this error is not a reason to repeat the write.



## Read related values from one snapshot

Prepare calls with `viewRequest()` and send them together through `readViews()`:

```ts
export async function readTokenSnapshot(ownerText: string, minHeight?: bigint, signal?: AbortSignal) {
  const owner = addressFromHex(ownerText);
  const snapshot = await client.readViews({
    calls: [
      ERC20.v0_1.totalSupply.viewRequest({ contract: HOG_ADDRESS }),
      ERC20.v0_1.getBalanceOf.viewRequest({
        contract: HOG_ADDRESS,
        args: { addr: owner },
      }),
    ],
    minHeight,
  }, { signal });

  const [supply, balance] = snapshot.results;
  if (supply.kind === "return" && balance.kind === "return") {
    console.log("Shared snapshot:", snapshot.height.toString());
    console.log("Supply and balance:", supply.value, balance.value);
  } else {
    console.error("Read outcomes:", supply.kind, balance.kind);
  }
  return snapshot;
}
```

`viewRequest()` performs no I/O. `readViews()` returns results in input order, retaining each call’s inferred return and exception types, events, and gas use. Each result is `return`, `abort`, or `fault`. Transport, freshness, and decoding failures reject the group.

All calls use one committed snapshot, and simulated writes stay within their own call. Put `minHeight` on the group, not on individual prepared calls. Two separate reads with the same minimum height can still use different snapshots.

Shared reads require a batch-capable RPC endpoint and runtime. Inspect `(await client.getServerLimits()).viewBatch` for advertised call, gas, calldata, response-size, and timeout limits. The client never splits a group or falls back to separate views. [HTTP batching](../pages/typescript/transport.md#http-batching) alone does not provide this guarantee. Raw requests use `client.viewBatch({ calls, minHeight }, { signal })`.



## Handle contract outcomes

`view()` throws `ContractViewError` for an abort or fault. Use `viewOutcome()` when those outcomes belong in your application’s normal control flow:

```ts
const outcome = await hog.totalSupply.viewOutcome({ args: undefined });
if (outcome.kind === "return") {
  console.log(outcome.value);
} else {
  console.error("Contract view failed:", outcome.kind);
}
```

Malformed contract bytes throw `ContractDecodeError`. Transport and RPC failures remain separate from contract outcomes.



## Cancel stale reads

```ts
import { classifyReadError } from "@thruputchain/client";

export async function refreshSupply(signal: AbortSignal) {
  try {
    return await hog.totalSupply.view({ args: undefined, signal });
  } catch (error) {
    if (classifyReadError(error, { signal }) === "cancelled") return;
    throw error;
  }
}
```

Create an `AbortController` for the operation and call `abort()` when its result is no longer needed. RPC actions, including `readViews`, take `{ signal }` as request options; bound views take it inside their options object. Canceling a group ends the client’s wait but does not guarantee that backend execution has stopped.

`classifyReadError` returns `transient`, `permanent`, `cancelled`, or `unknown`. It does not retry or replace the error. Applications choose retry limits; an unclassified `TypeError` is not proof of a network failure.

---

## Read events

Source: <https://thruput.network/typescript/events/>

Filter and decode contract events, walk historical pages, and save progress without missing rows.

Use a generated event descriptor to build filters and decode payloads. This page uses the supplied ERC-20 `TransferEvent`; a custom contract uses the event exported by its generated bindings.



## Query events

With the client from [Connect to a network](../pages/typescript/connect.md), create `src/events.ts`:

```ts
import { groundhog_erc20_if } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { client } from "./client.js";

const { TransferEvent } = groundhog_erc20_if.v0_1.events;
const page = await client.getContractEvents({
  event: TransferEvent,
  contractAddresses: [HOG_ADDRESS],
  order: "descending",
  limit: 20,
});
for (const event of page.events) {
  console.log(event.blockHeight, event.sequenceNumber, event.fields.amount);
}
```

This fetches one typed page. An empty page is a valid result. Each row retains the emitting contract address, transaction hash, position, topics, and decoded fields.



## Filter topics

Add `topics: { to: owner }` to restrict transfers to a typed address. A named topic accepts one value or `{ oneOf: [...] }`. Filters require one to five contract addresses; each topic alternative list accepts 1–16 values.

Addresses, fixed 32-byte values, supported integer scalars, `U256`, `I256`, and bool have direct encodings. Strings and byte slices are hashed. Use the generated filter’s input types; do not reconstruct topic bytes or assume a hashed value can be read back.



## Walk historical pages

For raw event pages, use the descriptor’s filter and decoder:

```ts
const query = {
  filters: [TransferEvent.filter({ contractAddresses: [HOG_ADDRESS] })],
  order: "ascending" as const,
  anchor: "beginning" as const,
  limit: 20,
};
for await (const page of client.iterateEventPages(query)) {
  for (const row of page.events) {
    const decoded = TransferEvent.decode(row.event);
    console.log(row.blockHeight, decoded);
  }
}
```

The iterator requests pages on demand. It follows empty pages with non-empty continuation cursors and stops on an empty `Uint8Array`. Repeated cursors and RPC errors throw. `decode` returns `null` for a different signature and throws for malformed matching data.

Pass `{ signal }` as the iterator’s second argument to cancel an in-flight read. Breaking the loop stops future requests. There is no automatic retry, polling, subscription, or persistence.



## Resume without missing events

A cursor continues one historical walk; it does not follow later blocks. Keep the network, target, and filters fixed. Store rows and progress in the same database transaction, deduplicating by `(txHash, sequenceNumber)` within that network and query.

After exhausting an ascending walk, start a new walk inclusively at the last stored row’s block height. Replay and deduplicate that block so a partially processed block does not lose rows. `latestBlock` is the indexer’s head, not proof that your application processed every row through that height. Check `oldestBlock` for a retention gap.

For a latest-first UI, refresh from the head rather than continuing an old cursor.

For durable ascending ingestion, provide an application-owned store. `loadProgress()` returns `{ height: bigint, cursor: Uint8Array }` or `undefined`; `savePage()` upserts rows by stable identity and saves progress in the same database transaction:

```ts
const saved = await store.loadProgress();
let height = saved?.height ?? 0n;

for await (const page of client.iterateEventPages({
  ...query,
  anchor: { height },
  cursor: saved?.cursor ?? new Uint8Array(),
})) {
  if (page.oldestBlock > height) {
    throw new Error("History gap: required blocks are no longer retained");
  }
  const last = page.events.at(-1);
  if (last) height = last.blockHeight;
  await store.savePage(page.events, { height, cursor: page.cursor.slice() });
}
```

The store methods are application code, not SDK APIs. A non-empty saved cursor resumes the previous walk; an empty cursor starts a new scan at the saved height. Serialize heights and cursor bytes exactly. If a block spans pages, restart inclusively at that block and deduplicate instead of skipping to the next height.

Raw JSON-RPC represents an empty cursor as `"0x"` and still requires `order` and `anchor` on continuation requests. Preserve cursor bytes rather than decoding or editing them. Corrupted cursors can resemble exhaustion on some indexers; retention bounds and a cursor alone do not prove complete or recoverable history.



## Decode receipt events

Use `TransferEvent.allFromReceipt(receipt, { contractAddress: HOG_ADDRESS })` to decode matching events in a receipt. `singleFromReceipt` requires exactly one matching event. Both select the emitter as well as the event type; a transaction can call several contracts that emit the same event.

---

## Accounts and wallet clients

Source: <https://thruput.network/typescript/wallet-clients/>

Choose an account authorization model and bind it to a signer-backed or provider-backed wallet client.

A public client connects to the network. An account describes the identity and authorization used for a transaction. A wallet client combines that account with the operations needed to prepare, sign, and submit transactions.

Account authorization and wallet call behavior are separate. Authorization determines which signatures can originate a transaction. An invocation adapter determines how a wallet contract wraps calls to other contracts.



## Choose an account model

|                 | Pubkey account                                        | Source-address account                                               |
| --------------- | ----------------------------------------------------- | -------------------------------------------------------------------- |
| Constructor     | `createPubkeyAccount`                                 | `createSourceAddressAccount`                                         |
| Address         | Derived from an Ed25519 public key and account nonce  | Existing address supplied by the application                         |
| Authorization   | One Ed25519 signer matching the account preimage      | Signer entries and a claim checked against stored authorization data |
| Wallet behavior | DefaultWallet adapter selected automatically          | Application-call wrapping requires an appropriate adapter            |
| Typical use     | A script account without a separate wallet deployment | An existing account contract with configured signer policy           |

Both constructors create local JavaScript objects. They do not fund an address, deploy code, or change authorization data on chain.



## Create a pubkey account

Given an existing `Signer` named `signer`:

```ts
import { createPubkeyAccount } from "@thruputchain/client";

const account = createPubkeyAccount({ signer, nonce: 0n });
```

The same public key and account nonce produce the same address. The nonce defaults to zero and is separate from each transaction’s replay-protection nonce.

An undeployed pubkey account uses the network’s DefaultWallet behavior for its root invocation. No separate wallet deployment is needed. See [Use a signer in scripts](../pages/typescript/accounts.md) for key loading and funding.



## Describe a source-address account

For an existing account whose stored policy authorizes your signer at key slot zero with sufficient weight:

```ts
import { createSourceAddressAccount } from "@thruputchain/client";
import { bitMap, weight } from "@thruputchain/protocol";

const account = createSourceAddressAccount({
  address: walletAddress,
  signers: [{ signer, publicKeyId: 0n }],
  allowedKeys: bitMap(0x01n),
  requiredWeight: weight(1n),
});
```

Here, `walletAddress` is the existing account address, not an application contract you want to call. `publicKeyId` identifies a stored signer slot; `allowedKeys` selects slots for the authorization claim. The signatures must satisfy both the stored policy and the claim’s required weight.

The constructor does not register signers or set their weights. Those must already be configured on chain. See [Authorization](../pages/how-it-works/authorization.md#source-address-accounts) for the protocol rules.



## Bind an account to a client

With a pubkey `account` and the cluster-aware public client from [Connect to a network](../pages/typescript/connect.md):

```ts
import { createWalletClient } from "@thruputchain/client";
import { client } from "./client.js";

const wallet = createWalletClient({ client, account });
```

The wallet is a separate object. It retains public-client operations and adds signing and account operations. Pubkey accounts also receive DefaultWallet execution helpers such as `executeAndWait` and `executeCallsAndWait`. Multiple accounts can share the original public client.

For a source-address account, `createWalletClient` provides transaction preparation and signing, but does not infer how its account contract wraps application calls. Supply an `invocationAdapter` that matches that contract to obtain the execution helpers. Do not select an adapter from the authorization model alone. Custom implementations use `defineWalletInvocationAdapter`; see [Client API reference](../pages/tools/typescript-sdk.md#choose-an-account-model).

A cluster-aware client supplies its validated signing network hash. A transport-only client requires an explicit `networkHash` when creating the wallet client.



## Bind a browser wallet provider

In a browser app, the wallet provider manages signing. Use an authorized account returned by its session:

```ts
import { createProviderWalletClient } from "@thruputchain/client/wallet";

const wallet = createProviderWalletClient({
  client,
  provider,
  account: selectedAccount,
  networkHash: expectedNetworkHash,
});
```

`selectedAccount` is the provider’s wire `WalletAccount`, containing its address, public key, and derivation nonce. It is not the signer-backed account object returned by the constructors above. The provider integration supports pubkey accounts and DefaultWallet behavior; it does not expose a raw signer.

`expectedNetworkHash` is the application’s trusted network identity in provider format, without `0x`. The factory does not request connection permission. Follow [Connect a wallet](../pages/tools/wallet-integration.md) for discovery, account selection, and session cleanup.

---

## Connect a wallet

Source: <https://thruput.network/tools/wallet-integration/>

Discover browser wallets, connect an account on the intended network, and manage its session.

A browser wallet provider owns account access and transaction approval. Your application receives authorized account information and requests signatures without handling the user’s private key.

For installation and test funds, follow [Wallet Extension](../pages/tools/wallet-extension.md).



## Choose the Integration

This page covers the provider-backed path described in [Accounts and wallet clients](../pages/typescript/wallet-clients.md). For a Node.js process that manages its own key, use [Use a signer in scripts](../pages/typescript/accounts.md). Wallet implementers should use [Wallet provider reference](../pages/tools/wallet-provider.md).



## Discover and Connect

Start discovery when the wallet picker mounts and let the user select a provider:

```ts
import { discoverWalletProviders, type WalletProvider } from "@thruputchain/client/provider";

export function mountWalletPicker(showChoice: (provider: WalletProvider) => void) {
  return discoverWalletProviders(showChoice);
}
```

Call the returned cleanup function when the picker unmounts. Discovery supports either load order and reports each provider ID once. Provider IDs and names are display metadata, not proof of identity; render names as text.

Connect from the user’s chosen-wallet action. This helper accepts a public client, the application’s trusted network hash, and an account picker:

```ts
import type { CoreThruputClient } from "@thruputchain/client";
import { parseWalletSession, type WalletAccount, type WalletProvider } from "@thruputchain/client/provider";
import { createProviderWalletClient } from "@thruputchain/client/wallet";

export async function connectWallet(
  client: CoreThruputClient,
  provider: WalletProvider,
  expectedNetworkHash: string,
  chooseAccount: (accounts: readonly WalletAccount[]) => WalletAccount,
) {
  const session = parseWalletSession(await provider.request({ method: "connect" }));
  if (session.networkHash !== expectedNetworkHash) {
    throw new Error("Select the application's network in your wallet");
  }
  if (session.accounts.length === 0) throw new Error("No authorized account");
  const account = chooseAccount(session.accounts);
  if (!session.accounts.includes(account)) throw new Error("Choose an authorized account");

  const wallet = createProviderWalletClient({
    client, provider, account, networkHash: expectedNetworkHash,
  });
  return { wallet, account };
}
```

For a [cluster-aware client](../pages/typescript/connect.md), convert its validated network identity with `toHex0x(client.network.networkHash).slice(2)`. Provider network hashes are 64 lowercase hex characters without `0x`. Do not adopt the wallet’s network as the application’s expected network.

`connect` prompts for access; `getSession` reads existing access without prompting. A disconnected session has no accounts but still reports the wallet’s current network. The adapter does not switch networks.



## Handle Changes and Cleanup

Every provider `change` invalidates the current adapter. A failed session read or mismatched session also invalidates it. Stop offering actions through that binding, update the account/network UI, and construct a new adapter for a newly authorized session.

```ts
import type { WalletProvider } from "@thruputchain/client/provider";
import type { ProviderWalletClient } from "@thruputchain/client/wallet";

export function watchWallet(
  provider: WalletProvider,
  wallet: ProviderWalletClient,
  resetAccountUI: () => void,
) {
  const stopChanges = provider.on("change", () => {
    wallet.dispose();
    resetAccountUI();
  });
  return () => {
    stopChanges();
    wallet.dispose();
  };
}
```

Application callbacks should handle their own UI errors. Call cleanup when the binding is no longer needed. `dispose()` invalidates the adapter but does not revoke wallet permission. The user’s Disconnect action calls `provider.request({ method: "disconnect" })`.



## Prepare, Sign, Save, Submit, Observe

For routine writes, use [Send transactions](../pages/typescript/transactions.md#send-through-a-browser-wallet). The provider helpers require `onSigned` to save the approved transaction before broadcast.

For explicit control, the sequence is:

1. `wallet.prepareExecution(request)` builds the unsigned transaction.
2. `wallet.signTransaction(transaction)` requests approval and verifies the returned bytes, signature, and hash. It does not broadcast.
3. Your application saves the signed result, account, and original network.
4. `wallet.submitTransaction(signed)` broadcasts the latest verified approval once.
5. The public client observes the hash and checks execution.

The adapter allows one in-flight operation. A session change invalidates pending work; do not automatically re-sign it. Signature verification requires Web Crypto, available in browsers on HTTPS or localhost.



## Recover an Ambiguous Submission

Once submission begins, an error may arrive after broadcast. Use the saved hash and original network to [track the transaction](../pages/typescript/transaction-status.md), including after disconnect or reload. Do not create a replacement merely because observation timed out.

Use `parseWalletProviderError` for provider errors across browser contexts rather than relying on `instanceof`. The [error table](../pages/tools/wallet-provider.md#errors) distinguishes rejection, authorization, network, and transport errors.

For a complete counter interface with wallet-approved updates, follow [Counter, part 4: Connect a wallet](../pages/tutorials/connect-a-wallet-to-your-app.md).

---

## Use a signer in scripts

Source: <https://thruput.network/typescript/accounts/>

Bind a Node.js signer to a native account, request Futurenet funds, and use local bootstrap accounts.

Use a signer when your Node.js script or service manages an account’s key. This page sets up a pubkey account. See [Accounts and wallet clients](../pages/typescript/wallet-clients.md) for account models and client construction, or [Connect a wallet](../pages/tools/wallet-integration.md) for a browser application.



## Bind a signer

Supply a 32-byte Ed25519 private-key seed through your process environment as `THRUPUT_PRIVATE_KEY`, using `0x`-prefixed hex. For a disposable Futurenet test account, generate one once in your terminal:

```bash
export THRUPUT_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

Keep that environment for the funding and send commands. Generating another seed selects another account. For a persistent account, load the existing seed from your secret configuration.

Create `src/wallet.ts`:

```ts
import {
  PrivateKeySigner, createPubkeyAccount, createWalletClient, fromHex0x,
} from "@thruputchain/client";
import { client } from "./client.js";

const secret = process.env.THRUPUT_PRIVATE_KEY;
if (!secret) throw new Error("Set THRUPUT_PRIVATE_KEY for this script account");

export const account = createPubkeyAccount({
  signer: new PrivateKeySigner(fromHex0x(secret)),
});
export const wallet = createWalletClient({ client, account });
```

Keep the key in the process’s secret configuration, not browser code or committed files.





## Request Futurenet funds

Create `src/fund.ts`:

```ts
import { toHex0x } from "@thruputchain/client";
import { account, wallet } from "./wallet.js";

const result = await wallet.requestAirdrop();
if (result.status.result !== "ok") {
  throw new Error(`Airdrop execution failed: ${result.status.result}`);
}
console.log("Account:", toHex0x(account.address));
console.log("Funding transaction:", toHex0x(result.txHash));
```

```bash
npx tsx src/fund.ts
```

The client must use a cluster that declares airdrop support. The hosted faucet selects the allocation. `requestAirdrop` polls one attempt with a stable nonce; retain an explicit `clientNonce` if your application must recover the request across process restarts. `requestAirdropAttempt` exposes application-controlled polling.



## Use a local development account

For a node started by [the CLI](../pages/cli/local-node.md), create a disposable signer and fund it from the local faucet. In the terminal that runs the script:

```bash
export THRUPUT_SIGNING_PRIVATE_KEY="$(node -e 'process.stdout.write("0x" + require("node:crypto").randomBytes(32).toString("hex"))')"
```

```ts
import { createThruputClient, createPubkeyAccount, createWalletClient, fromHex0x, localnet, PrivateKeySigner } from "@thruputchain/client";

const seed = process.env.THRUPUT_SIGNING_PRIVATE_KEY;
if (!seed) throw new Error("Set THRUPUT_SIGNING_PRIVATE_KEY");
const client = await createThruputClient({ cluster: localnet() });
const signer = new PrivateKeySigner(fromHex0x(seed));
const account = createPubkeyAccount({ signer });
const wallet = createWalletClient({ client, account });
await wallet.requestAirdrop();
```

`localnet()` selects the local endpoint and checks its network identity. Keep the signer seed in this terminal environment for later calls. Use an existing seed from secret configuration when the account must persist. The SDK does not load CLI account files or runtime manifests.

---

## Send transactions

Source: <https://thruput.network/typescript/transactions/>

Build typed calls, execute them through a wallet, and distinguish submission from successful execution.

A binding builds an application call. A wallet wraps that call into an authorized transaction. Use the wallet’s execution helper instead of submitting a contract method directly as the transaction root.



## Send from a script

Set up and fund the account from [Use a signer in scripts](../pages/typescript/accounts.md). For this small-transfer example, choose a recipient that already has native tokens. Create `src/send.ts`:

```ts
import { addressFromHex, gasAmount, parseUnits, toHex0x } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { wallet } from "./wallet.js";

const recipient = process.env.THRUPUT_RECIPIENT;
if (!recipient) throw new Error("Set THRUPUT_RECIPIENT to a funded address");

const transfer = ERC20.v0_1.transfer.call({
  contract: HOG_ADDRESS,
  gasLimit: gasAmount(500_000n),
  args: {
    receiver: addressFromHex(recipient),
    amount: parseUnits("0.0001", 7),
  },
});
const { txHash, receipt, values } = await wallet.executeCallsAndWait({
  calls: [transfer],
  gasLimit: gasAmount(1_000_000n),
});
console.log("Committed:", toHex0x(txHash), receipt.height.toString());
console.log("Return value:", values[0]); // transfer returns void
```

```bash
npx tsx src/send.ts
```

The helper waits for successful committed execution and decodes child returns in call order. A returned receipt and a decoded result are separate guarantees; see [Track transaction results](../pages/typescript/transaction-status.md) for failures at either boundary.



## Send through a browser wallet

Use the adapter returned by [Connect a wallet](../pages/tools/wallet-integration.md). The same typed call works, but the provider helper also requires an `onSigned` callback:

```ts
import type { ContractAddress } from "@thruputchain/client";
import { gasAmount, parseUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import type { ProviderWalletClient, ProviderExecutionOptions } from "@thruputchain/client/wallet";

export function sendHog(
  wallet: ProviderWalletClient,
  receiver: ContractAddress,
  onSigned: ProviderExecutionOptions["onSigned"],
) {
  const transfer = ERC20.v0_1.transfer.call({
    contract: HOG_ADDRESS,
    gasLimit: gasAmount(500_000n),
    args: { receiver, amount: parseUnits("0.0001", 7) },
  });
  return wallet.executeCallsAndWait({
    calls: [transfer],
    gasLimit: gasAmount(1_000_000n),
  }, { onSigned });
}
```

Call this from the user’s send action. Your `onSigned` implementation must finish saving the signed bytes, hash, account, and network before it resolves. A failed save prevents submission. The SDK does not provide that storage layer.



## Choose an execution helper

| Need                                                                 | Helper                                     |
| -------------------------------------------------------------------- | ------------------------------------------ |
| Submit and require successful execution                              | `executeAndWait({ invocation, gasLimit })` |
| Also decode typed child returns                                      | `executeCallsAndWait({ calls, gasLimit })` |
| Get a submitted hash and observe separately in a signer-based script | `execute({ invocation, gasLimit })`        |
| Inspect the transaction before signing                               | `prepareExecution(...)`                    |

Provider-backed helpers require the additional lifecycle options shown above. Their explicit prepare/sign/submit path is covered in [Wallet integration](../pages/tools/wallet-integration.md#prepare-sign-save-submit-observe).



## Execute multiple calls

Pass an ordered list to `executeCallsAndWait` to execute calls atomically. If a call fails, the transaction does not commit earlier calls’ state changes. The returned `values` follow the same order.

For a provider wallet, await `getCapabilities()` and inspect the returned `atomicBatch` before offering a multi-call action. `null` means unsupported; `maxCalls` gives the advertised limit. The adapter checks support during preparation as well. One atomic wallet transaction is different from [HTTP request batching](../pages/typescript/transport.md#http-batching).

The SDK requests capabilities only when the provider advertises `getCapabilities`. No advertisement or a `4200` response means unsupported batching. Permission errors, transport failures, malformed responses, and account/network mismatches must remain errors. Refresh capability state after a session change; see [batch capability requirements](../pages/tools/wallet-provider.md#optional-atomic-batch-capabilities).

Keep a batch within the wallet’s advertised limit, up to 16 calls. For explicit preparation, `prepareBatchExecution({ invocations, gasLimit })` builds one unsigned transaction; use the same [sign, save, submit, and observe flow](../pages/tools/wallet-integration.md#prepare-sign-save-submit-observe) as a single call.

If batching is unsupported, offer a single-call action only when it meets the user’s intended operation. Do not split an operation that requires atomicity. After a batch is rejected or its submission is uncertain, never fall back to individual transactions. Retain its signed evidence and [inspect the original hash](../pages/typescript/transaction-status.md).

A batch that enqueues requests commits their acceptance, not their later execution. Track the resulting request IDs and outcomes as described in [Build an AMM](../pages/guides/build-an-amm.md#understand-acceptance-and-execution).



## Set gas and funding

Each child call has a budget; the root needs enough gas for the wallet wrapper and its child calls. The numbers above are example transfer budgets, not universal defaults. `walletGasLimit(invocations, overhead)` sums invocation budgets and an overhead that you have measured for your workload. For typed calls, pass each call’s `invocation` field.

There are no conventional gas fees, but the declared root limit uses scheduling capacity backed by the sender’s unlocked native tokens. Storage deposits are separate. A new recipient’s first credit must cover its balance storage, so a small first transfer can fail. See [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md).

---

## Track transaction results

Source: <https://thruput.network/typescript/transaction-status/>

Observe a submitted hash, distinguish commitment from execution success, and handle transaction errors.

Submission, commitment, execution, and decoding are separate steps. Keep the transaction hash and network so the application can continue observing the same operation after a timeout or wallet disconnect.



## Inspect a submitted transaction

Use the public client from [Connect to a network](../pages/typescript/connect.md). Create `src/status.ts`:

```ts
import { ExecResult, hashFromHex } from "@thruputchain/client";
import { client } from "./client.js";

const text = process.env.THRUPUT_TX_HASH;
if (!text) throw new Error("Set THRUPUT_TX_HASH to the submitted transaction hash");
const hash = hashFromHex(text);
const status = await client.getTransactionStatus(hash);

if (status.status === "committed") {
  const receipt = await client.getTransactionReceipt(hash);
  if (!receipt) throw new Error("The committed receipt is not available from this endpoint");
  console.log("Execution succeeded:", receipt.execResult === ExecResult.ExecResultOK);
  console.log("Block:", receipt.height.toString());
} else {
  console.log("Status:", status.status);
}
```

This performs one status check. `waitForTransactionReceipt(hash)` polls for a receipt, but does not itself require successful execution. Check `execResult` or use `waitForExecution(client, hash)` to require success.



## Interpret status

| Status               | Application meaning                                                                             |
| -------------------- | ----------------------------------------------------------------------------------------------- |
| `pending`            | The gateway knows the transaction; keep waiting                                                 |
| `committed`          | Fetch the receipt and check execution; status `height` can be absent until indexing supplies it |
| `invalid`            | Show the reported reason                                                                        |
| `recentFailure`      | Advisory failure of an attempt; the transaction can still commit                                |
| `retry`              | Scheduler processing failed; resubmitting the same signed transaction may succeed               |
| `dropped`            | Scheduler processing failed permanently; modify the transaction before resubmitting             |
| `unknown` or `other` | No conclusive successful or failed execution result                                             |

A timeout or canceled observation does not cancel onchain execution. Query the original hash on the original network rather than automatically signing a replacement.



## Handle scheduler processing errors

`waitForTransactionReceipt()` throws `TransactionProcessingError` on `retry` or `dropped`. It stops polling and never resubmits. Keep the hash, status, and scheduler diagnostics:

```ts
import { TransactionProcessingError } from "@thruputchain/client";

try {
  const receipt = await client.waitForTransactionReceipt(hash);
  console.log("Execution succeeded:", receipt.execResult === ExecResult.ExecResultOK);
} catch (error) {
  if (error instanceof TransactionProcessingError) {
    console.error({ txHash: error.txHash, status: error.status, error: error.error });
  }
  throw error;
}
```

`error.error` is a `SchedulerTransactionError`: `source` is `auth`, `scheduler`, `executor`, or `other`, and `code` is a signed 32-bit number. Interpret the code using that source’s protocol error enum. The client maps unrecognized sources to `other` and preserves the code.



## Handle execution-helper errors

| Error                             | What happened                                                     | What to retain                               |
| --------------------------------- | ----------------------------------------------------------------- | -------------------------------------------- |
| `TransactionExecutionError`       | Committed execution failed                                        | `receipt`                                    |
| `TransactionObservationError`     | Observation failed after submission was attempted                 | `txHash`, `cause`, and any `submissionCause` |
| `ExecutionDecodeError`            | Execution succeeded, but child return decoding failed             | Successful `receipt` and decoding cause      |
| `ExecutionReturnUnavailableError` | Execution succeeded, but the wallet did not provide child returns | Successful `receipt`                         |

For example, classify errors from a wallet execution helper:

```ts
import { TransactionExecutionError, TransactionObservationError, toHex0x } from "@thruputchain/client";

export function describeExecutionError(error: unknown): string {
  if (error instanceof TransactionObservationError) {
    return `Check transaction ${toHex0x(error.txHash)} on its original network`;
  }
  if (error instanceof TransactionExecutionError) {
    return `Committed execution failed: ${error.receipt.execResult}`;
  }
  return error instanceof Error ? error.message : "Transaction operation failed";
}
```

A decoding failure is not a reason to repeat a successful write. Keep the submitted call descriptors if you need to decode the receipt again later.



## Decode the correct method

`decodeReceipt` and `decodeReceiptOutcome` apply to a known **root method**. A wallet-root receipt is not a receipt for the application method it called. Use `executeCallsAndWait` or `decodeExecution(receipt, calls)` for ordered DefaultWallet child returns.

Do not decode a root abort with a child method’s exception schema merely because the transaction contained one child call. The wallet itself may have failed before the child executed.



## Restore application state

After a reload, use the saved hash and network to resume public observation. This does not require the wallet to remain connected. A provider’s `onSigned` callback provides the pre-submission record; see [Send transactions](../pages/typescript/transactions.md#send-through-a-browser-wallet).

For protocol-level outcomes, see [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md).

---

## Deploy a contract

Source: <https://thruput.network/typescript/deployment/>

Deploy a supplied RV32 artifact from TypeScript with explicit funding and optional atomic initialization.

Use this task when an application or service deploys a supplied contract artifact. You do not need to write Rust, but you do need the `.rv32a` artifact and the bindings from its build. For ordinary developer deployment, use [the CLI](../pages/cli/deploy-and-call.md).



## Prepare the deployment identity

For the generated counter, place its artifact and binding in your project. This Node.js example uses the funded account from [Use a signer in scripts](../pages/typescript/accounts.md):

```ts
import { readFile } from "node:fs/promises";
import { gasAmount, parseUnits, prepareContractDeployment, toHex0x } from "@thruputchain/client";
import { Counter } from "./contracts/my-counter.js";
import { account, wallet } from "./wallet.js";

const artifact = await readFile("artifacts/my_counter.rv32a");
const deployment = prepareContractDeployment({
  deployer: account.address,
  contract: artifact,
});
console.log("Predicted address:", toHex0x(deployment.address));
```

Preparation hashes the artifact and predicts its address without signing or submitting. Retain the deployment nonce if you need to reproduce that identity. It differs from the transaction nonce used for replay protection.



## Fund, deploy, and initialize

```ts
const result = await wallet.deployContractAndWait(deployment, {
  gasLimit: gasAmount(10_000_000n),
  amount: parseUnits("10", 7),
  initializer: Counter.v0_1.initialize.invocation(
    deployment.address,
    gasAmount(500_000n),
    { initialValue: 10n },
  ),
});
console.log("Deployed:", toHex0x(result.address));
```

`amount` is explicit native-token funding in base units for the target contract. The example allocation and gas budgets are not universal costs. `0n` skips the funding transfer. The sender still needs scheduling capacity for the root transaction.

Funding, deployment, and the optional initializer form one atomic operation. The initializer targets the predicted address and sees the wallet as its caller. If it fails, the operation rolls back. The helper waits for success and verifies the returned deployment address.



## Deploy through a provider wallet

The provider adapter supports the same deployment plan and options, with an additional `{ onSigned }` lifecycle argument. Use the authorized provider account’s address as `deployer`. See [Send transactions](../pages/typescript/transactions.md#send-through-a-browser-wallet) for persistence before submission.

Inspect the original transaction hash if observation fails rather than generating a new deployment attempt. See [Track transaction results](../pages/typescript/transaction-status.md).

---

## Client API reference

Source: <https://thruput.network/tools/typescript-sdk/>

TypeScript client entry points, common operations, and links to focused usage guides and generated API documentation.

| Reference                                                      | Purpose                                |
| -------------------------------------------------------------- | -------------------------------------- |
| [Generated client API](https://client-ts.thruput.network/)     | Complete types, overloads, and exports |
| [Generated protocol API](https://protocol-ts.thruput.network/) | Protocol types and codecs              |
| [JSON-RPC API](../pages/reference/json-rpc-api.md)             | Wire methods and responses             |
| [TypeScript overview](../pages/typescript.md)                  | Application model and task guides      |



## Install

| Package                       | Use                                     | Instructions                                         |
| ----------------------------- | --------------------------------------- | ---------------------------------------------------- |
| `@thruputchain/client`        | Application client and contract runtime | [Package setup](../pages/typescript/setup.md)        |
| `@thruputchain/protocol`      | Protocol-only constants and wire types  | [Package setup](../pages/typescript/setup.md)        |
| `@thruputchain/contract-spec` | Schema tooling                          | [Contract spec](../pages/reference/contract-spec.md) |



## Connect to a Cluster

| API                                            | Behavior                                                                                                                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `createThruputClient({ cluster, transport? })` | Async client creation with network identity validation                                                                                                                          |
| `devnet(options?)`                             | Hosted development network; unpinned unless given `networkHash`; declares airdrop support                                                                                       |
| `localnet(options?)`                           | Local endpoint and default local identity; override with the matching runtime identity                                                                                          |
| `mainnet(options)`                             | Requires an explicit endpoint                                                                                                                                                   |
| `defineCluster(descriptor)`                    | Custom name, endpoint, hash pin, and expected capabilities                                                                                                                      |
| `getChainTip()` / `getVersion()`               | Current tip and release/wire identity                                                                                                                                           |
| `getChainConfig()`                             | Stated limits plus optional `execution` with `observedTip`, `configHash`, runtime-resolved limits, and exact `bigint` storage prices; absent execution context is not zero cost |
| Usage                                          | [Connect to a network](../pages/typescript/connect.md)                                                                                                                          |



## Exact Amounts and Common Types

| API                                          | Result / rule                                                           |
| -------------------------------------------- | ----------------------------------------------------------------------- |
| `parseUnits(text, decimals)`                 | Exact signed `bigint`; rejects malformed input and excess precision     |
| `formatUnits(value, decimals)`               | Decimal string                                                          |
| `addressFromHex(text)` / `hashFromHex(text)` | Typed address or hash from `0x` hex                                     |
| `toHex0x(bytes)`                             | `0x`-prefixed display encoding                                          |
| `gasAmount(bigint)`                          | Typed computation budget                                                |
| `ParseUnitsError`                            | `code: "malformed" \| "precision"`; invalid decimals throw `RangeError` |
| Usage                                        | [Addresses and amounts](../pages/typescript/values.md)                  |



## Choose an Account Model



| API                                                                             | Inputs / behavior                                                                                                                                                              |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `createPubkeyAccount({ signer, nonce? })`                                       | Ed25519 signer; address nonce defaults to `0n`                                                                                                                                 |
| `createSourceAddressAccount({ address, signers, allowedKeys, requiredWeight })` | Existing stored-auth account; does not write auth data                                                                                                                         |
| `createWalletClient({ client, account, invocationAdapter? })`                   | Separate signer-bound client; pubkey accounts default to DefaultWallet                                                                                                         |
| `networkHash` wallet option                                                     | Required for a client without validated network identity                                                                                                                       |
| `createProviderWalletClient(...)`                                               | External wallet adapter; see [provider API](../pages/tools/wallet-provider.md#sdk-adapter-behavior)                                                                            |
| Usage                                                                           | [Accounts and wallet clients](../pages/typescript/wallet-clients.md), [script setup](../pages/typescript/accounts.md), [browser wallets](../pages/tools/wallet-integration.md) |



## Fund and Execute a Call

| API                                                  | Result / behavior                                                                                            |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `requestAirdrop(options?)`                           | Poll one funding attempt; account-defaulted on an airdrop-capable signer wallet                              |
| `requestAirdropAttempt(request)`                     | Single application-controlled funding attempt                                                                |
| `prepareExecution(request)`                          | Unsigned wallet-root transaction                                                                             |
| `execute(request)`                                   | Submitted hash; signer-based wallet                                                                          |
| `executeAndWait(request, options?)`                  | Successful committed receipt and hash                                                                        |
| `executeCallsAndWait({ calls, gasLimit }, options?)` | Successful receipt plus ordered typed child values                                                           |
| `walletGasLimit(invocations, overhead)`              | Sum invocation budgets, checking u64 bounds; pass `call.invocation` for typed calls; does not estimate usage |
| Usage                                                | [Send transactions](../pages/typescript/transactions.md)                                                     |



## Typed Calls and Observation Recovery

| API / error                                 | Meaning                                                                                                             |
| ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `getTransactionStatus(hash)`                | One status lookup; committed `height` is optional                                                                   |
| `getTransactionReceipt(hash)`               | One committed-receipt lookup; `null` when unavailable                                                               |
| `waitForTransactionReceipt(hash, options?)` | Wait for a receipt, including failed execution; throws on `retry` or `dropped`, never resubmits                     |
| `waitForExecution(client, hash, options?)`  | Wait and require successful execution                                                                               |
| `TransactionProcessingError`                | Scheduler `retry` or `dropped` outcome; retains `txHash`, `status`, and `error`                                     |
| `SchedulerTransactionError`                 | `source`: `auth`, `scheduler`, `executor`, or `other`; `code`: signed 32-bit number; unknown sources map to `other` |
| `TransactionExecutionError`                 | Failed committed `receipt`                                                                                          |
| `TransactionObservationError`               | Known `txHash` plus observation and optional submission causes                                                      |
| `ExecutionDecodeError`                      | Successful receipt whose child return data failed decoding                                                          |
| `ExecutionReturnUnavailableError`           | Successful receipt without child returns                                                                            |
| Usage                                       | [Track transaction results](../pages/typescript/transaction-status.md)                                              |



## Use a Local Account



| API                               | Result / requirement                                                                          |
| --------------------------------- | --------------------------------------------------------------------------------------------- |
| `localnet(options?)`              | Local endpoint and pinned local network identity                                              |
| `PrivateKeySigner(seed)`          | Explicit signer seed from the application environment                                         |
| `createPubkeyAccount({ signer })` | Native pubkey account derived from the signer                                                 |
| `wallet.requestAirdrop()`         | Fund the account through the local faucet                                                     |
| Usage                             | [Local development accounts](../pages/typescript/accounts.md#use-a-local-development-account) |



## Deploy Through a Wallet

| API                                                                   | Result / requirement                                                                   |
| --------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `prepareContractDeployment({ deployer, contract, deploymentNonce? })` | Contract hash, nonce, and predicted address; no submission                             |
| `rv32Contract(artifact)`                                              | Protocol wrapper for nonempty artifact bytes                                           |
| `DeploymentOptions`                                                   | Required `gasLimit` and native-token `amount` in base units; optional `initializer`    |
| `prepareDeployment(deployment, options)`                              | Unsigned deployment transaction                                                        |
| `deployContract(deployment, options)`                                 | Submitted hash and predicted address; signer wallet                                    |
| `deployContractAndWait(deployment, options, controls?)`               | Successful deployment with verified address; provider form requires lifecycle controls |
| Usage                                                                 | [Deploy a contract](../pages/typescript/deployment.md)                                 |



## Typed Views

| API                                                                                    | Result / behavior                                                                                     |
| -------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `getContract({ binding, address, client })`                                            | Bound method collection                                                                               |
| `method.view(options)`                                                                 | Typed value, height, gas use, and events; supports `minHeight` and `signal`                           |
| `method.viewOutcome(options)`                                                          | `return`, `abort`, or `fault`; also supports `minHeight`                                              |
| `method.viewRequest({ contract, args?, caller? })`                                     | Prepare a typed read without I/O; arguments follow the method’s generated types                       |
| `client.readViews({ calls, minHeight? }, options?)`                                    | Tuple-typed outcomes in input order at one shared `height`; no splitting or separate-read fallback    |
| `client.view(request, options?)` / `client.viewBatch({ calls, minHeight? }, options?)` | Raw single/grouped simulations; `minHeight` goes on the single request or whole group                 |
| `minHeight`                                                                            | Optional nonnegative `bigint` freshness floor; no waiting, forced refresh, or automatic client retry  |
| `(await client.getServerLimits()).viewBatch`                                           | Optional advertised batch limits                                                                      |
| `ViewHeightUnavailable` (`-32011`)                                                     | RPC freshness error with requested and observed heights; not a contract outcome                       |
| `ContractViewError`                                                                    | Contract abort or fault                                                                               |
| `ContractDecodeError`                                                                  | Malformed contract data                                                                               |
| Usage                                                                                  | [Read contract data](../pages/typescript/reads.md), [bindings](../pages/tools/typescript-bindings.md) |



## Cancellation and Read Errors

| API                                    | Rule                                                                       |
| -------------------------------------- | -------------------------------------------------------------------------- |
| `signal`                               | Request options for actions; inside view options for generated/bound views |
| `classifyReadError(error, { signal })` | `transient`, `permanent`, `cancelled`, or `unknown`; no automatic retry    |
| Cancellation                           | Cancels observation, not onchain execution                                 |
| Usage                                  | [Read cancellation](../pages/typescript/reads.md#cancel-stale-reads)       |



## HTTP Batching

| Option                                              | Default / meaning                                            |
| --------------------------------------------------- | ------------------------------------------------------------ |
| `HttpTransport(url, { timeoutMs, headers, batch })` | Configure the HTTP request layer                             |
| `batch`                                             | Off by default; `true` selects default batching settings     |
| `maxSize`                                           | 100 entries; allowed range 1–1,000                           |
| `waitMs`                                            | 0ms scheduling window                                        |
| Usage                                               | [Configure HTTP transport](../pages/typescript/transport.md) |



## Event Pages

| API                                                                            | Result / behavior                                     |
| ------------------------------------------------------------------------------ | ----------------------------------------------------- |
| `getContractEvents({ event, contractAddresses, topics?, ...query }, options?)` | One typed page with event identity and indexer bounds |
| `iterateEventPages(query, options?)`                                           | Raw pages on demand; empty cursor ends the walk       |
| `Event.filter(input)` / `Event.decode(raw)`                                    | Generated topic filter and payload decoder            |
| `Event.allFromReceipt(...)` / `singleFromReceipt(...)`                         | Matching receipt events, filtered by emitter          |
| Usage                                                                          | [Read events](../pages/typescript/events.md)          |



## Receipt Decoding

| API                                             | Requirement                                                                                      |
| ----------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| `decodeExecution(receipt, calls, adapter?)`     | Successful wallet receipt and retained ordered call descriptors                                  |
| `method.decodeReceipt` / `decodeReceiptOutcome` | Descriptor must identify the root method                                                         |
| Usage                                           | [Decode the correct method](../pages/typescript/transaction-status.md#decode-the-correct-method) |



## Low-Level Signing

| API                                                  | Role                                                                                 |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------ |
| `prepareTransaction`                                 | Build a root transaction and its authorization claim                                 |
| `signTransaction(transaction, signers, networkHash)` | Sign the network-bound preimage                                                      |
| `sendTransaction(signed)`                            | Submit signed bytes                                                                  |
| Transaction hash                                     | SHA-256 of unsigned transaction XDR, separate from the signing preimage              |
| Usage                                                | Prefer [wallet execution](../pages/typescript/transactions.md) for application calls |



## Public Entry Points

| Import                             | Use for                                                          |
| ---------------------------------- | ---------------------------------------------------------------- |
| `@thruputchain/client`             | Clients, clusters, accounts, actions, amounts, common primitives |
| `@thruputchain/client/contracts`   | Standard contract and event descriptors                          |
| `@thruputchain/client/contract`    | Descriptor runtime, codecs, fixed-length helpers                 |
| `@thruputchain/client/transport`   | HTTP/mock transports and errors                                  |
| `@thruputchain/client/actions`     | Standalone actions                                               |
| `@thruputchain/client/wallet`      | Execution and provider adapters                                  |
| `@thruputchain/client/provider`    | Provider wire types, validation, discovery                       |
| `@thruputchain/client/transaction` | Construction, signing, serialization                             |
| `@thruputchain/client/signers`     | Signer interface and private-key signer                          |
| `@thruputchain/client/signed-op`   | Network-bound offchain signed operations                         |



## Maintained Examples

| Source                                                                               | Purpose                                                                       |
| ------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| [Client examples](https://github.com/thruputchain/thruput-sdk-ts/tree/main/examples) | Runnable SDK examples; use dependencies matching the selected source revision |
| [Guides](../pages/guides.md)                                                         | Complete contract and application walkthroughs                                |

---

## Wallet provider reference

Source: <https://thruput.network/tools/wallet-provider/>

Wallet provider wire methods, data formats, validation rules, and SDK adapter APIs.

| Audience                       | Entry point                                                                                                        |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| Application developers         | [Connect a wallet](../pages/tools/wallet-integration.md), [Send transactions](../pages/typescript/transactions.md) |
| Wallet and bridge implementers | Provider contract `1.0.0`; requirements below apply at the wallet boundary                                         |
| Complete signatures            | [Generated client API](https://client-ts.thruput.network/)                                                         |
| Imports                        | Wire types and validators: `/provider`; application adapter: `/wallet`                                             |



## Interface and Methods

| Type / member                      | Shape                                                                            |
| ---------------------------------- | -------------------------------------------------------------------------------- |
| `WalletAccount`                    | `{ address: string; publicKey: string; nonce: string }`                          |
| `WalletSession`                    | `{ networkHash: string; accounts: readonly WalletAccount[] }`                    |
| `WalletProvider.info`              | `{ id: string; name: string; version: "1.0.0" }`                                 |
| `WalletProvider.supportedMethods?` | Optional readonly method-name list                                               |
| `request(request)`                 | `Promise<unknown>`; validate each result                                         |
| `on("change", listener)`           | Subscribe to a full session snapshot; returns an idempotent unsubscribe function |

| Request method               | Parameters                                    | Result / requirement                                                                                 |
| ---------------------------- | --------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `connect`                    | None                                          | Prompt for origin-scoped access; successful session has at least one account                         |
| `getSession`                 | None                                          | Non-interactive session snapshot; never grants access                                                |
| `disconnect`                 | None                                          | `null`; idempotently revokes origin permission and pending approvals                                 |
| `getCapabilities` (optional) | `{ account, networkHash }`                    | `WalletCapabilities`; requires an authorized account on that network; never prompts or grants access |
| `signTransaction`            | `{ account, networkHash, transaction }`       | `{ signedTransaction, hash }`; approval and signing only                                             |
| `submitTransaction`          | `{ account, networkHash, signedTransaction }` | `{ hash }`; broadcast acknowledgement, not an execution receipt                                      |

| Rule           | Requirement                                                                                                |
| -------------- | ---------------------------------------------------------------------------------------------------------- |
| Request shape  | Exactly the method’s defined fields, including nested `params`                                             |
| Selection      | Explicit account and network; no implicit network switch                                                   |
| Batch contract | [Optional Atomic Batch Capabilities](../pages/tools/wallet-provider.md#optional-atomic-batch-capabilities) |



## Canonical Data and Limits

| Value                       | Required format / bound                                                                                        |
| --------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Address, public key, hash   | 32-byte lowercase `0x`-prefixed hex                                                                            |
| Network hash                | 64 lowercase hex characters without `0x`                                                                       |
| Account nonce               | Canonical decimal u64, at most `18446744073709551615`; address derivation, not transaction replay nonce        |
| Session accounts            | At most 32 unique addresses                                                                                    |
| Provider ID                 | 1–64 ASCII letters, digits, dots, underscores, or hyphens                                                      |
| Provider name               | 1–80 characters; no controls or surrounding whitespace; render as text                                         |
| Provider version            | Exactly `"1.0.0"`                                                                                              |
| Provider `supportedMethods` | Optional array of at most 32 strings; unknown names are opaque, including names with punctuation or namespaces |
| Error message               | At most 1,024 characters                                                                                       |
| Unsigned transaction        | Canonical classic XDR, at most 1,048,500 decoded bytes                                                         |
| Signed transaction          | Canonical classic XDR, at most 1,048,576 decoded bytes                                                         |
| Transaction hex             | Lowercase, even-length, `0x`-prefixed; at most 2,097,002 unsigned or 2,097,154 signed characters               |
| Account derivation          | Protocol pubkey account matching its public key and nonce; Ed25519 key must be non-small-order and prime-order |

| Validation boundary | Requirement                                                                                |
| ------------------- | ------------------------------------------------------------------------------------------ |
| Canonical values    | Reject malformed values rather than normalizing                                            |
| XDR                 | Consume all input; re-encoding must reproduce the supplied bytes                           |
| Before approval     | Enforce unsigned size limit; 76 bytes are reserved for one decorated signature             |
| Bridges             | Bound raw messages before parsing and bound pending requests; allow for JSON envelope size |
| Data parsers        | Return snapshots                                                                           |
| Provider parser     | Preserves the live object’s identity and method receivers; does not establish trust        |



## Permissions and Session Events

| Event / state                                              | Requirement                                                                      |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Unauthorized or disconnected origin                        | Empty accounts, current network hash retained                                    |
| Accounts, permission, account metadata, or network changes | Emit `change` with a full session snapshot                                       |
| Subscription                                               | Does not emit an initial snapshot; call `getSession`                             |
| Connect/disconnect ordering                                | Page-facing changes arrive before the request resolves, including across bridges |
| Pending operation                                          | Recheck authorization before signing or broadcasting                             |
| Session change                                             | Clear approvals; old approval cannot survive a changed session                   |



## Optional Atomic Batch Capabilities

| Item                           | Requirement                                                                                                                                                       |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Advertisement                  | Providers implementing `getCapabilities` must include that exact name in top-level `supportedMethods`, separate from `info` and `WalletSession`                   |
| Unknown advertised method      | Ignore the name; it does not invalidate the provider                                                                                                              |
| Unadvertised capability method | Clients must not probe it; the SDK reports unsupported batching without making that request                                                                       |
| Response shape                 | Exactly `{ account, networkHash, atomicBatch: { maxCalls: number } \| null }`                                                                                     |
| Scope                          | Response account and network must match the request’s canonical account and network; provider verifies current origin/account authorization and network           |
| Side effects                   | Capability queries must not prompt, grant access, sign, or broadcast                                                                                              |
| Unsupported batching           | `atomicBatch: null`, no advertisement, or an advertised capability request returning `4200`                                                                       |
| Other failures                 | Permission and transport errors propagate; malformed responses or mismatched scope are errors, not unsupported capability                                         |
| Call limit                     | `maxCalls` is an integer from 1 to 16; a batch must contain at least one call and stay within the advertised limit                                                |
| Atomicity                      | Ordered, all-or-nothing calls inside one `DefaultWallet.execute` transaction, not multiple independent transactions; an inner abort or fault rolls back the batch |
| Queued work                    | A successful batch that enqueues work does not establish the outcome of later processing                                                                          |
| Session changes                | Discard capability state when the account/network session changes; check support again before batch preparation                                                   |
| Approval                       | Use the existing `signTransaction` and `submitTransaction` requests; one approval covers only that exact batch transaction                                        |
| Persistence and recovery       | Save signed bytes, hash, account, and network before submission; inspect the original hash after uncertainty                                                      |
| Fallback                       | Never split a rejected or uncertain batch into individual transactions                                                                                            |
| Application usage              | [Execute multiple calls](../pages/typescript/transactions.md#execute-multiple-calls)                                                                              |



## Signing and Transaction Identity

| Item          | Requirement                                                                                                |
| ------------- | ---------------------------------------------------------------------------------------------------------- |
| Root identity | Transaction root address and complete pubkey claim match the selected account                              |
| Signed bytes  | Preserve unsigned transaction byte-for-byte                                                                |
| Signature     | Exactly one Ed25519 signature with public-key ID zero                                                      |
| Preimage      | `cxs(DomainSeparator("Transaction")) \|\| networkHash \|\| txs(transaction)`                               |
| Verification  | Strict Ed25519 with ZIP-215 disabled; public key and signature point R are non-small-order and prime-order |
| Signing       | Sign the preimage directly, without an extra pre-hash                                                      |
| Result hash   | `0x` plus lowercase SHA-256 of unsigned transaction XDR; excludes signatures and network                   |
| Web Crypto    | Required by SDK signature verification; HTTPS or localhost in browsers                                     |



## Approval and Submission

| Boundary                    | Requirement                                                                                                      |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Trusted caller              | Derive origin in trusted wallet/bridge code, not page-supplied parameters                                        |
| Retained approval           | Bind exact signed bytes to origin, account, and network                                                          |
| Submission                  | Reject bytes outside the retained approval; return the approved canonical hash                                   |
| Approval lifecycle          | Clear on disconnect/session change; bound retained approvals; fail closed after eviction, restart, or lost state |
| Application persistence     | Save signed result, hash, account, and original network before broadcast                                         |
| Uncertain submission        | Observe the saved hash on the original network; do not automatically sign a replacement                          |
| Identical-byte resubmission | Requires an explicit recovery policy and still-valid provider approval                                           |
| Usage                       | [Transaction observation](../pages/typescript/transaction-status.md)                                             |



## Errors

| Code     | Meaning                                                         |
| -------- | --------------------------------------------------------------- |
| `4001`   | User rejected the request                                       |
| `4100`   | Unauthorized origin/account, stale session, or missing approval |
| `4200`   | Unsupported method                                              |
| `4900`   | Provider disconnected or transport unavailable                  |
| `4901`   | Requested network does not match                                |
| `-32602` | Invalid parameters, encoding, or limits                         |
| `-32603` | Internal error or invalid provider result                       |
| `-32002` | Another operation is pending                                    |

| Rule                    | Requirement                                                                         |
| ----------------------- | ----------------------------------------------------------------------------------- |
| Across contexts         | Preserve numeric code and message; use `parseWalletProviderError`, not `instanceof` |
| Unknown method          | Return `4200`                                                                       |
| Malformed known request | Return `-32602`                                                                     |



## Multiple-Provider Discovery

| API / rule                                           | Behavior                                                                |
| ---------------------------------------------------- | ----------------------------------------------------------------------- |
| `registerWalletProvider(provider, target = window)`  | Validate, announce immediately, and respond to provider requests        |
| `discoverWalletProviders(listener, target = window)` | Subscribe before requesting announcements; validate and deduplicate IDs |
| Request event                                        | `groundhog:requestProvider`                                             |
| Announcement event                                   | `groundhog:announceProvider`; `detail` is the provider itself           |
| Discovery limits                                     | At most 32 IDs; first valid announcement for an ID wins                 |
| Cleanup                                              | Idempotent; removes listeners, but does not disconnect sessions         |
| Registration removal                                 | Does not retract an already discovered provider                         |
| Outside browsers                                     | Imports are safe; supply an `EventTarget` to discovery helpers          |
| Trust                                                | Shape validation is not wallet identity or origin authorization         |



## Validation Helpers

| Helper                                                                  | Validates / returns                                                                                                       |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `parseWalletAccount`, `parseWalletSession`, `parseWalletProviderInfo`   | Canonical data and frozen snapshots; separately require nonempty accounts after connect                                   |
| `parseWalletProvider`                                                   | Metadata and callable methods on the live object                                                                          |
| `parseWalletHex32`, `parseWalletNetworkHash`                            | Distinct hex encodings                                                                                                    |
| `parseWalletCapabilities`                                               | Exact scoped response shape and DefaultWallet call-count bounds; authorization and expected-scope comparison are separate |
| `parseProviderRequest`                                                  | Exact request union and bounded XDR                                                                                       |
| `parseTransactionHex`, `parseSignedTransactionHex`                      | Canonical decoded objects, without signature verification                                                                 |
| `parseSignTransactionResult`, `parseSubmitTransactionResult`            | Result shape; not signature, approval, or broadcast verification                                                          |
| `assertWalletTransaction(tx, account)`                                  | Root address and complete pubkey claim; mismatch is `4100`                                                                |
| `verifySignTransactionResult(value, transaction, account, networkHash)` | Exact bytes, account claim, strict signature, and hash; invalid result is `-32603`                                        |
| `parseWalletProviderError`                                              | Recognized code and bounded message                                                                                       |

| Constant                         | Value       |
| -------------------------------- | ----------- |
| `MAX_TRANSACTION_BYTES`          | `1_048_576` |
| `MAX_UNSIGNED_TRANSACTION_BYTES` | `1_048_500` |
| `MAX_WALLET_ACCOUNTS`            | `32`        |
| `MAX_DISCOVERED_PROVIDERS`       | `32`        |
| `MAX_DEFAULT_WALLET_CALLS`       | `16`        |



## SDK Adapter Behavior

| API                                                                                   | Result / behavior                                                                                                                             |
| ------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `createProviderWalletClient({ client, provider, account, networkHash })`              | Synchronous separate binding for an authorized wire account; does not connect or mutate client                                                |
| `getCapabilities()`                                                                   | Fresh account/network capabilities when advertised; absence or `4200` means unsupported batching                                              |
| `prepareExecution(request)`                                                           | Unsigned DefaultWallet transaction with nonce, expiry, and size handling                                                                      |
| `prepareBatchExecution(request)`                                                      | Unsigned DefaultWallet transaction containing ordered `invocations`; snapshots inputs before async work and validates fresh capability limits |
| `signTransaction(transaction)`                                                        | Verified approval; never broadcasts                                                                                                           |
| `submitTransaction(signed)`                                                           | Consumes latest approval once, including on failure; verifies response hash                                                                   |
| `executeAndWait(request, controls)`                                                   | Prepare, sign, save through `onSigned`, submit, and observe successful execution                                                              |
| `executeCallsAndWait(request, controls)`                                              | Atomic typed calls and ordered decoded results                                                                                                |
| `prepareDeployment(plan, options)` / `deployContractAndWait(plan, options, controls)` | Explicit funding and optional atomic initialization                                                                                           |
| `dispose()`                                                                           | Idempotently unsubscribe and permanently invalidate; does not revoke permission                                                               |

| Lifecycle rule     | Behavior                                                                                                              |
| ------------------ | --------------------------------------------------------------------------------------------------------------------- |
| Inputs             | Snapshot configuration and inputs before async work; validate account derivation and client network identity          |
| Session            | Check before preparation/signing/submission; every change or failed/mismatched session read invalidates the adapter   |
| Concurrency        | One in-flight operation; overlapping work fails with `-32002`                                                         |
| New approval       | Clears the previous approval after local transaction validation; refusal does not restore it                          |
| Execution controls | Required `onSigned` persistence callback; optional `wait` settings and cancellation signal                            |
| Cleanup            | No automatic reconnect/retry, UI deadline, or provider-request cancellation; late results cannot reactivate or submit |
| Usage              | [Connect a wallet](../pages/tools/wallet-integration.md), [Send transactions](../pages/typescript/transactions.md)    |



## Design References

| Reference                                                                                                                                                                       | Relationship                                                                                                                                                  |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [EIP-1193](https://eips.ethereum.org/EIPS/eip-1193), [EIP-6963](https://eips.ethereum.org/EIPS/eip-6963), [Wallet Standard](https://github.com/wallet-standard/wallet-standard) | Design influences, not compatibility claims                                                                                                                   |
| Scope                                                                                                                                                                           | No arbitrary-message signing, implicit network addition, WalletConnect, hardware-wallet protocol, or source-address account support in this provider contract |
