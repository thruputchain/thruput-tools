# Tools

Documentation source: `fd91c2019cd8f984aeda15c0303042679e1c8825`. Hosted docs may be newer than this snapshot.

## Faucet

Source: <https://thruput.network/docs/tools/faucet/>

Request native test tokens for a Futurenet wallet and check the funding result.

Use the [hosted faucet](https://thruput-faucet.up.railway.app) to fund a Futurenet wallet or contract address with native test tokens. These tokens have no monetary value.



## Request funds in the browser

1. Copy your public address from the [Wallet Extension](../pages/tools/wallet-extension.md) or your [CLI wallet](../pages/cli/wallets.md#create-a-key-and-wallet).
2. Open the [faucet](https://thruput-faucet.up.railway.app).
3. Paste your wallet address into **Wallet address**.
4. Click **Request airdrop**. The faucet sets the amount.
5. Wait for the **Sent … native tokens** notice, then check the receiving wallet’s balance. The notice also shows a shortened transaction hash.

If the page cannot connect, it shows **Faucet unavailable** and disables the request. Click **Retry** to connect again.

The faucet needs only a public address. Amounts, cooldowns, and quotas depend on the deployment; follow the values and errors shown by the service.



## Request funds in the wallet

In [Thruput Wallet](../pages/tools/wallet-extension.md#select-devnet-and-get-test-hog), select **Devnet** (the wallet extension’s label for Futurenet), open **Assets**, and click **Request test HOG**. The request funds the selected wallet account.



## CLI

With a Futurenet wallet already configured:

```bash
thruput airdrop --profile futurenet
thruput balance --profile futurenet
```

The faucet selects the amount, so omit `--amount` for remote requests. For initial key and wallet setup, follow the [CLI quickstart](../pages/get-started/cli.md).

The CLI retains a nonce for a pending remote airdrop. If the outcome is unclear, rerun the same command to resume that request. A timeout does not prove that funding failed.



## TypeScript

Use the client or wallet’s `requestAirdrop` action. [Script accounts](../pages/typescript/accounts.md) covers funding and retaining a request nonce for recovery. The client must use a cluster with airdrop support.

For Localnet, use your local node’s airdrop through the [CLI](../pages/cli/local-node.md) or SDK rather than the hosted Futurenet faucet.



## If funding does not appear

- Check that the recipient address and wallet network match the request.
- Follow the displayed cooldown before requesting again.
- If you have a transaction hash, inspect it in the [Explorer](../pages/tools/block-explorer.md). A committed transaction must also have a successful execution result.
- If the browser lost its connection, check the balance before starting a new request.

---

## Explorer

Source: <https://thruput.network/docs/tools/block-explorer/>

Use the Futurenet explorer to look up transactions, inspect receipts and events, and check address activity.

Use the [Futurenet explorer](https://explorer.thruput.network/) to look up transactions, inspect receipts and events, and check address balances and recent activity. Sign in if prompted.



## Look Up a Transaction or Address

1. Open the [Futurenet explorer](https://explorer.thruput.network/).
2. Paste the transaction hash or address into the search field.
3. Select **Search**.

The home page also lists recent native-token transfers. Select a transaction to inspect it, or follow an address link to view that address.



### Transactions

The transaction page shows:

- Transaction status and, once committed, block height and execution result.
- Receipt events, including decoded token transfers, mints, and burns where supported.
- Raw receipt data for debugging.

Events without a supported decoder appear as raw topics and data.



### Addresses and Tokens

The address page shows the native-token balance. For non-token addresses, it also shows recent transactions and sent or received native-token transfers. Recognized token contracts show token metadata and token transfer history. Other contracts can show their emitted events.

Address transaction history combines transactions whose root invocation targets the address with native-token transfer activity. It does not cover every nested invocation or every token transfer involving the address.



### Share a Result

Copy the page URL to share a transaction or address:

```text
https://explorer.thruput.network/tx/<transaction-hash>
https://explorer.thruput.network/address/<address>
```



## Inspect State Without an Explorer

Use the CLI for terminal workflows, local nodes, or when the explorer is unavailable:

```bash
thruput balance <wallet-or-address> --profile futurenet
thruput tx show <transaction-hash> --profile futurenet
thruput view <contract-or-alias> <method> --profile futurenet
thruput storage <contract-or-alias> 0x<32-byte-key> --profile futurenet
```

These commands use Futurenet. For a local node, use `--profile local` instead. The hosted explorer does not show your local node’s transactions.

Use the [JSON-RPC API](../pages/reference/json-rpc-api.md) directly for receipts, status, address-rooted history, and event pagination.



## If a result is missing

Check the full hash or address and the network that produced it. Indexer-backed history can lag, so use `thruput tx show` for the original transaction before submitting another one. A pending or missing result does not prove failure.

---

## Wallet Extension

Source: <https://thruput.network/docs/tools/wallet-extension/>

Install the wallet for Project Thruput in Chrome, create a test wallet, and connect it to a Devnet app.

The Project Thruput wallet extension supports Devnet and Localnet. It appears as **Thruput Wallet** in Chrome. The prebuilt download needs no Node.js, Rust, or package-registry access. Use a test wallet for development.

The hosted network is now called Futurenet. The wallet extension and the screenshots below still use the Devnet label.



## Download and extract

[Download Thruput Wallet](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/wallet/f877c655c6778b195a651c61cc8e6f2da055d2bba33f621a9841a76f81fe0c80/thruput-wallet.zip) · [SHA-256 checksum](https://groundhog-public-release-artifacts-017820684264.s3.us-west-2.amazonaws.com/wallet/f877c655c6778b195a651c61cc8e6f2da055d2bba33f621a9841a76f81fe0c80/SHA256SUMS)

Extract the ZIP. The `thruput-wallet` folder contains `manifest.json`, `index.html`, and the extension scripts. Keep that folder in a stable location; Chrome loads the extension from it.



## Load it in Chrome

1. Open `chrome://extensions` in the address bar.
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select the extracted **thruput-wallet** folder, not the ZIP or its parent folder.
5. Open the puzzle-piece menu beside Chrome’s address bar. Find **Thruput Wallet** and click its pin button to keep it in the toolbar.

![Chrome's Extensions page with Developer mode enabled, Load unpacked, and Thruput Wallet enabled](../assets/images/wallet/wallet-install.png)

If Chrome cannot find the manifest, select the folder that directly contains `manifest.json`.



## Create a test wallet

Open the wallet from the toolbar. Select **New wallet**, enter and confirm a password of at least 12 characters, then click **Create wallet**. The password unlocks the wallet on this device.

![Thruput Wallet's New wallet screen with password and confirmation fields and the Create wallet button](../assets/images/wallet/wallet-create.png)

Follow the prompt to back up your recovery phrase in **Settings**. Keep the phrase private. Use **Restore wallet** if you already have a test recovery phrase you want to use.





## Select Devnet and get native test tokens

Check the network dropdown. New wallets start on **Devnet**; existing wallets keep their saved selection.

Open **Assets** and click **Request test HOG**, the wallet’s label for native test tokens. Wait for the balance to update. These tokens have no monetary value. They fund storage deposits and provide scheduling capacity under load; there are no conventional gas fees.

![Wallet showing the Devnet selector, Assets tab, and Request test HOG button](../assets/images/wallet/wallet-devnet.png)

| Network  | RPC endpoint                  | Use                                |
| -------- | ----------------------------- | ---------------------------------- |
| Devnet   | `https://rpc.thruput.network` | Hosted apps and shared development |
| Localnet | `http://127.0.0.1:9545`       | A node running on your computer    |

For local work, [start a local node](../pages/cli/local-node.md) before selecting Localnet. Changing networks clears app connections and pending approvals. Reconnect from the app afterward.

You can also copy the wallet’s public address and use the [hosted faucet](../pages/tools/faucet.md).



## Connect to an app

1. Open the app and choose its wallet connection action. Select **Thruput Wallet** if it offers a wallet picker.
2. In the approval popup, check the site and choose the account to share.
3. Click **Connect**. The app should display the connected account.
4. For an update, review and approve the separate transaction request in the wallet.

Closing the connection popup cancels that connection request. Connecting an account does not approve future transactions. Use the app’s disconnect control when finished.

Try this with [counter part 4](../pages/tutorials/connect-a-wallet-to-your-app.md). To add wallet support to your own app, use the [TypeScript integration](../pages/tools/wallet-integration.md) or [React wallet hooks](../pages/react/wallets.md).



## Update or build from source

After replacing the extension files, click **Reload** on its card in `chrome://extensions`, then refresh app tabs so they load the current provider.

For a source build, follow the [wallet README](https://github.com/thruputchain/thruput-examples/tree/main/apps/wallet-extension). That path needs repository and package access; load its generated `dist` folder in Chrome.



## If something does not work

| Symptom                                         | Check                                                                                                                                                                           |
| ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| The app does not detect a wallet                | Enable the extension, allow it on the site, and refresh the app tab.                                                                                                            |
| Chrome cannot find the manifest                 | Select the extracted `thruput-wallet` folder, or `dist` for a source build.                                                                                                     |
| Wrong network                                   | Select the app’s network in the wallet, then reconnect from the app.                                                                                                            |
| Connection no longer works after a Devnet reset | Select Devnet again to refresh its network identity, then reconnect.                                                                                                            |
| No native test tokens yet                       | Wait for the request to finish and follow any displayed cooldown or error.                                                                                                      |
| A transaction has a hash but no result          | Inspect that hash in the [Explorer](../pages/tools/block-explorer.md) or with [the CLI](../pages/cli/transactions.md#look-up-one-transaction) before submitting another update. |
