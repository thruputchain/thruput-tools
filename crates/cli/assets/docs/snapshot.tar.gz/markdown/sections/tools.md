# Tools

Documentation source: `53198a762a9adc3260457997acb6ad86b75d9932`. Hosted docs may be newer than this snapshot.

## Faucet

Source: <https://thruput.network/docs/tools/faucet/>

Request native test tokens for a Futurenet wallet and check the funding result.

Use the [hosted faucet](https://thruput-faucet.up.railway.app) to fund a Futurenet wallet or contract address with native test tokens. These tokens have no monetary value.



## Request funds in the browser

1. Copy your public address from the [Wallet Extension](../pages/tools/wallet-extension.md) or your [CLI wallet](../pages/cli/wallets.md#create-a-key-and-wallet).
2. Open the [faucet](https://thruput-faucet.up.railway.app).
3. Paste your wallet address into **Wallet address**.
4. Click **Request airdrop**. The faucet sets the amount.
5. Wait for the **Sent … native tokens** notice, then check the receiving wallet’s balance. The notice also shows a shortened transaction hash.

If the page cannot connect, it shows **Faucet unavailable** and disables the request. Click **Retry** to connect again.

The faucet needs only a public address. Amounts, cooldowns, and quotas depend on the deployment; follow the values and errors shown by the service.



## CLI

With a Futurenet wallet already configured:

```bash
thruput airdrop --profile futurenet
thruput balance --profile futurenet
```

The faucet selects the amount, so omit `--amount` for remote requests. For initial key and wallet setup, follow the [CLI quickstart](../pages/get-started/cli.md).

The CLI retains a nonce for a pending remote airdrop. If the outcome is unclear, rerun the same command to resume that request. A timeout does not prove that funding failed.



## TypeScript

Use the client or wallet’s `requestAirdrop` action. [Script accounts](../pages/typescript/accounts.md) covers funding and retaining a request nonce for recovery. The client must use a cluster with airdrop support.

For Localnet, use your local node’s airdrop through the [CLI](../pages/cli/local-node.md) or SDK rather than the hosted Futurenet faucet.



## If funding does not appear

- Check that the recipient address and wallet network match the request.
- Follow the displayed cooldown before requesting again.
- If you have a transaction hash, inspect it in the [Explorer](../pages/tools/block-explorer.md). A committed transaction must also have a successful execution result.
- If the browser lost its connection, check the balance before starting a new request.

---

## Explorer

Source: <https://thruput.network/docs/tools/block-explorer/>

Use the Futurenet explorer to look up transactions, inspect receipts and events, and check address activity.

Use the [Futurenet explorer](https://explorer.thruput.network/) to look up transactions, inspect receipts and events, and check address balances and recent activity. Sign in if prompted.



## Look Up a Transaction or Address

1. Open the [Futurenet explorer](https://explorer.thruput.network/).
2. Paste the transaction hash or address into the search field.
3. Select **Search**.

The home page also lists recent native-token transfers. Select a transaction to inspect it, or follow an address link to view that address.



### Transactions

The transaction page shows:

- Transaction status and, once committed, block height and execution result.
- Receipt events, including decoded token transfers, mints, and burns where supported.
- Raw receipt data for debugging.

Events without a supported decoder appear as raw topics and data.



### Addresses and Tokens

The address page shows the native-token balance. For non-token addresses, it also shows recent transactions and sent or received native-token transfers. Recognized token contracts show token metadata and token transfer history. Other contracts can show their emitted events.

Address transaction history combines transactions whose root invocation targets the address with native-token transfer activity. It does not cover every nested invocation or every token transfer involving the address.



### Share a Result

Copy the page URL to share a transaction or address:

```text
https://explorer.thruput.network/tx/<transaction-hash>
https://explorer.thruput.network/address/<address>
```



## Inspect State Without an Explorer

Use the CLI for terminal workflows, local nodes, or when the explorer is unavailable:

```bash
thruput balance <wallet-or-address> --profile futurenet
thruput tx show <transaction-hash> --profile futurenet
thruput view <contract-or-alias> <method> --profile futurenet
thruput storage <contract-or-alias> 0x<32-byte-key> --profile futurenet
```

These commands use Futurenet. For a local node, use `--profile local` instead. The hosted explorer does not show your local node’s transactions.

Use the [JSON-RPC API](../pages/reference/json-rpc-api.md) directly for receipts, status, address-rooted history, and event pagination.



## If a result is missing

Check the full hash or address and the network that produced it. Indexer-backed history can lag, so use `thruput tx show` for the original transaction before submitting another one. A pending or missing result does not prove failure.

---

## Wallet Extension

Source: <https://thruput.network/docs/tools/wallet-extension/>

Download and install the Thruput fork of Freighter in Chrome for Futurenet testing.

Use [Thruput Freighter](https://github.com/thruputchain/freighter), a fork of Stellar’s Freighter wallet with added Thruput support. Developer builds are available for Futurenet testing.



## Download and extract

1. Sign in to GitHub.
2. Open the [successful Run Tests builds](https://github.com/thruputchain/freighter/actions/workflows/runTests.yml?query=is%3Asuccess).
3. Open the newest run with a **thruput-freighter-dev-…** download in its **Artifacts** section.
4. Download the artifact ZIP and extract it.

Artifacts expire after 14 days. If no download is available, follow the source-build instructions in the [Freighter repository](https://github.com/thruputchain/freighter).

Keep the extracted folder in a stable location. Chrome loads the extension from the folder that directly contains `manifest.json`.



## Load it in Chrome

1. Open `chrome://extensions` in the address bar.
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select the extracted folder that directly contains `manifest.json`, not the ZIP or its parent folder.
5. Open the puzzle-piece menu beside Chrome’s address bar. Find **Thruput Freighter Dev** and click its pin button to keep it in the toolbar.

![Chrome's Extensions page with Developer mode enabled and the Load unpacked button](../assets/images/wallet/wallet-install.png)

Open the extension from the toolbar and follow its setup prompts. Use a test wallet for development. To request native test tokens, copy your public address and use the [Futurenet faucet](../pages/tools/faucet.md).



## Update the extension

Download and extract a newer build into the same folder. Click **Reload** on the extension’s card in `chrome://extensions`, then refresh any connected app tabs.



## If something does not work

| Symptom                          | Check                                                                                                 |
| -------------------------------- | ----------------------------------------------------------------------------------------------------- |
| No artifact download             | Sign in to GitHub and choose a successful run with an unexpired **thruput-freighter-dev-…** artifact. |
| Chrome cannot find the manifest  | Select the extracted folder that directly contains `manifest.json`.                                   |
| The app does not detect a wallet | Enable the extension, allow it on the site, and refresh the app tab.                                  |

For application integration, see the [TypeScript integration](../pages/tools/wallet-integration.md) or [React wallet hooks](../pages/react/wallets.md).
