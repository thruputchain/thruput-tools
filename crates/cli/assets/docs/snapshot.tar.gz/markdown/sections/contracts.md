# Smart Contracts

Documentation source: `3cc5d07f366f6182e06af875daffd57a90a66e06`. Hosted docs may be newer than this snapshot.

## Smart Contracts

Source: <https://thruput.network/docs/contracts/>

Write, test, and understand Project Thruput contracts with the Rust SDK.

Build contract logic with the Rust SDK. Use this section for storage choices, authorization, events, testing, and the contract programming model.



## Write your first contract

Follow the [contract quickstart](../pages/get-started/contract.md) to deploy a counter on Futurenet. Then read [Build a Counter](../pages/tutorials/build-a-counter.md) to understand its code and tests, or [Project structure](../pages/contracts/project-structure.md) to find the generated files.

Use the [CLI section](../pages/cli.md) for build and deployment commands.



## Work on a contract

- [Define methods and interfaces](../pages/contracts/methods.md).
- [Choose storage types](../pages/programming-model/storage-types.md) for your data.
- [Authorize calls](../pages/how-it-works/authorization.md).
- [Define and handle errors](../pages/contracts/errors.md).
- [Emit and test events](../pages/contracts/events.md).
- [Call another contract](../pages/contracts/cross-contract-calls.md).
- [Choose a test mode and write tests](../pages/programming-model/testing.md).
- [Debug a contract](../pages/contracts/debugging.md).
- [Generate client bindings](../pages/contracts/client-bindings.md) for application developers.



## Understand the programming model

Read [Contract Execution](../pages/programming-model/execution.md) first for snapshots, merged changes, and the rules that cause bugs. Then read [Storage Types](../pages/programming-model/storage-types.md), starting with [Balance](../pages/programming-model/storage-types.md#balance) for nonnegative counts and amounts. Continue with [NNInt and concurrent updates](../pages/programming-model/nnint.md) to understand the underlying signed deltas, explicit bases, and merge rules. [Exclusive writes](../pages/programming-model/storage-types.md#exclusive-writes) and [invocation frames](../pages/how-it-works/invocation-frames.md) cover other storage and call constraints.

Read [Contract artifacts and addresses](../pages/how-it-works/contracts.md) to understand code hashes, deployment addresses, and immutability.



## Look up an API

Use the [storage API tables](../pages/reference/storage-types.md), [SDK macros](../pages/reference/sdk-macros.md), [syscalls](../pages/reference/syscalls.md), and [generated Rust API docs](../pages/tools/rust-api-docs.md).

For larger worked examples, visit [Guides](../pages/guides.md).

---

## Project structure

Source: <https://thruput.network/docs/contracts/project-structure/>

Understand the files, build artifacts, and SDK layers in a CLI-generated contract project.

`thruput new` creates a minimal Cargo contract project by default. Use `thruput new my-counter --template counter` for the counter layout below, including its example methods and tests. Keep the generated dependency versions, compiler settings, and CLI configuration together.



## Generated files

```text
my-counter/
  Cargo.toml              # Package, SDK dependencies, and build features
  AGENTS.md               # Instructions for coding agents
  build.rs                # Integration-test setup
  thruput.toml          # Project profiles and contract aliases
  rust-toolchain.toml     # Selected compiler and targets
  .cargo/
    config.toml           # Registry and Cargo configuration
    contract.toml         # Contract-build configuration
  src/
    lib.rs                # Library modules
    implementation.rs     # Contract logic, storage, errors, and events
    main.rs               # Contract entrypoint wrapper
  tests/
    test.rs               # Native logic tests
    test_rv32.rs          # Contract artifact tests
    integration.rs        # Tests against a running node
```

The `.gitignore` excludes build output and project-local runtime state.



## Build artifacts

`thruput build` compiles the entrypoint for RV32, Project Thruput’s 32-bit RISC-V contract target. It lowers the compiler output into an artifact the node can execute.

For `my-counter`, the output under `target/thruput/` includes:

- `my_counter.rv32a`: deployable contract artifact.
- `my_counter.rv32.json`: lowering metadata.
- `my_counter.spec.xdr`: binary contract specification.
- `my_counter.spec.json`: readable contract specification.

The specification describes the contract interface and supports [TypeScript binding generation](../pages/tools/typescript-bindings.md).



## Test modes

- `cargo test` runs the native contract tests.
- `thruput test` runs the RV32 artifact tests.
- `thruput test --integration` manages a local node for the integration tests.

See [Testing](../pages/programming-model/testing.md) for the execution modes, generated integration environment, and how to add assertions.



## SDK layers

Generated projects start with the SDK’s contract and storage macros. Use typed storage handles for normal state access. Lower-level syscall wrappers are available when you need a custom abstraction.

These layers can be combined within a contract. Use [Storage Types](../pages/programming-model/storage-types.md) to choose an API, [SDK Macros](../pages/reference/sdk-macros.md) for macro reference, and [Rust API Docs](../pages/tools/rust-api-docs.md) for exact signatures.

---

## Methods and interfaces

Source: <https://thruput.network/docs/contracts/methods/>

Define contract state, expose methods, and share typed interfaces with Rust callers.

Start with a [generated project](../pages/cli/create-project.md) so its host tests and RV32 entrypoint are configured.



## Define state and behavior

```rust
use thruput_sdk::storage::Balance;
use thruput_sdk::*;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}

#[contract]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.increase(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.get()
    }
}
```

`#[thruput_sdk::storage]` assigns each field a storage path. The field is a handle to persisted data, not an in-memory integer that you must save manually. `#[contract]` generates entrypoints, a `CounterClient`, and interface metadata.

`Balance::get()` gives the never-written counter a zero default while preserving other storage errors. `increase` records a relative change and checks for overflow. Start with [Balance](../pages/programming-model/storage-types.md#balance) for nonnegative counts and amounts; use [NNInt](../pages/programming-model/nnint.md) when you need signed deltas or an explicit base.



## Expose methods

Public methods on an inherent implementation become entrypoints. Private helper methods stay internal. Use `&mut self` to update through mutable storage handles and `&self` to read through shared handles. A method without a receiver does not need the generated storage struct.

Rust receiver mutability is separate from runtime call restrictions. Use [read-only child calls](../pages/contracts/cross-contract-calls.md#gas-limits) when the runtime must reject state changes.

Exported methods return their normal values. Use [contract exceptions](../pages/contracts/errors.md) for failures.



## Share an interface

Put a trait in a shared interface crate when callers need the interface without importing its implementation:

```rust
use thruput_sdk::*;

#[contract]
pub trait CounterApi {
    fn increment(&mut self, amount: u64);
    fn get(&self) -> i128;
}
```

This generates `CounterApiClient`. Mark the trait implementation with `#[contract]` too. Declare `throws` and `emits` on the trait definition, not again on its implementation.

For a self-contained contract, the inherent implementation in the first example is enough. The [macro reference](../pages/reference/sdk-macros.md#contract) lists parameters and reserved method names.



## Define argument and return types

```rust
#[contract_type]
pub struct CounterSummary {
    pub value: i128,
    pub owner: ContractAddress,
}
```

`#[contract_type]` supplies serialization and spec metadata. Use `Value<T>` when plain data must persist; choose other [storage types](../pages/programming-model/storage-types.md) for other update patterns.



## Initialize and generate bindings

Initialization is an ordinary method, not an automatic constructor. Enforce one-time initialization when required and [initialize atomically with deployment](../pages/cli/deploy-and-call.md#include-initialization).

Rust callers use generated clients. [Generate client bindings](../pages/contracts/client-bindings.md) to share the built contract interface with TypeScript applications. Keep bindings and deployment addresses from the same interface build.

---

## Contract Execution

Source: <https://thruput.network/docs/programming-model/execution/>

The rules your contract relies on: snapshots, compatible state changes, exclusion, and gas limits.

Your contract reads from a frozen snapshot and produces typed storage changes, called deltas. Ordinary storage reads do not see other transactions’ writes. The runtime checks whether each transaction’s deltas can coexist with the other changes landing in the block. Deltas that can coexist form the next committed state. Transactions with conflicting deltas are excluded and reported as `retry`.

Read this page first, then [Storage Types](../pages/programming-model/storage-types.md). It explains the behavior your contract relies on without requiring the engine’s lock and reservation implementation.



## Rules That Cause Bugs

- **Reads are not checked at commit.** A decision based on a value that another transaction can change in the same block can be stale. See [Snapshot Isolation](../pages/programming-model/execution.md#snapshot-isolation).
- **Decreases must fit the base.** All decreases admitted to one `Balance` or `NNInt` in a block must fit within the base value. For `Balance` and ordinary `NNInt` updates, the base is the start-of-block snapshot; an explicit `NNInt::set_add` uses the base it sets. Same-block credits do not count. See [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) and [NNInt](../pages/programming-model/nnint.md).
- **Excluded is not failed.** An excluded transaction can be resubmitted unchanged. A transaction whose root call aborts, reverts, or runs out of gas is committed and its nonce is consumed. See [Exclusion](../pages/programming-model/execution.md#exclusion).
- **Absolute writes merge only when equal.** Two `Value`, `Bytestring`, or `NNInt::set` writes to one key land together only when they write the same value. See [Storage Types](../pages/programming-model/storage-types.md#choosing-a-type).
- **Some operations allow one writer per block.** One transaction per block can consume from a queue, push or pop a `Vector`, or hold an exclusive write on a key. See [RCQ](../pages/programming-model/storage-types.md#rcqt--retrocausalqueue) and [Exclusive Writes](../pages/programming-model/storage-types.md#exclusive-writes).
- **The full gas limit is reserved.** Scheduling uses the declared limit, not the gas used. See [Gas](../pages/programming-model/execution.md#gas).



## Snapshot Isolation

All transactions in a block read the same committed state from the previous block. Ordinary storage reads do not see another transaction’s writes within the block. Reads include changes made within your transaction, including successful child calls. Other transactions cannot change the snapshot you read.

Reads are not validated when the transaction commits. Only writes can conflict. If two transactions each read `total_supply`, find room under a cap, and mint, both can land and exceed the cap. Enforce a rule that spans transactions with a write the runtime checks: a `Balance` or `NNInt` floor, a [`CapacityConstraint`](../pages/programming-model/storage-types.md#capacityconstraint), or an [exclusive write](../pages/programming-model/storage-types.md#exclusive-writes).

`RetrocausalQueue` has separate observation rules: a consumer can observe concurrent inserts in the same block. The proposer records these observations for validator replay.



## Merged Deltas

A delta describes how one transaction changes a storage location. It is not necessarily an arithmetic difference. The storage type gives the delta its meaning and defines whether it can coexist with other changes to the same location.

For a `Balance`, the delta is an increase or decrease. When you write:

```rust
self.balance.lazy_increase(5);
```

This says “add 5 to the balance.” It does not say “set the balance to 105.”

Suppose two transactions read a balance of 100:

```text
Tx A: lazy_decrease(20)
Tx B: lazy_decrease(30)
Both land: 100 - 20 - 30 = 50
```

Both changes can land because addition gives the same result in either order and the combined debit fits within the balance. We say the operations **commute**, and the runtime can merge their deltas. If the transactions instead try to debit 80 and 30, the combined debit exceeds the snapshot balance, so whichever transaction reserves second is excluded.

Merge rules depend on the storage type:

- `Balance` merges increases and decreases. All decreases admitted in a block must fit within the snapshot value; credits from other transactions in the same block do not fund a decrease.
- `NNInt` exposes lower-level signed changes and explicit bases.
- Changes to different `Map` keys are independent.
- Two `Value` writes to the same key can coexist only when they store the same value.

In these docs, **compatible deltas** means the storage type allows both changes to land. See [`Balance`](../pages/programming-model/storage-types.md#balance) for the ordinary balance API and [NNInt and concurrent updates](../pages/programming-model/nnint.md) for the underlying `set_add` rules.



## Block Lifecycle

1. **Read and execute:** your contract reads the block snapshot plus its own changes and successful child calls. It records typed deltas.
2. **Reserve:** after the root call succeeds, the runtime checks whether the complete delta batch can coexist with the proposal’s other changes.
3. **Commit or exclude:** admissible transactions contribute to the finalized block. Conflicting transactions are excluded and reported as `retry`.

Your contract does not control these phases. [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md) covers submission through finalization; [Parallel Execution](../pages/how-it-works/execution-model.md) explains the reservation machinery.



## Exclusion

From your contract’s perspective, a conflicting transaction doesn’t land. Your code runs, produces deltas, and the system determines whether that completed delta batch is compatible with other transactions in the block. An excluded transaction is not committed and its replay nonce is not consumed, so the client can resubmit the same signed transaction until it commits or expires. See [How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the engine-level details.

Exclusion is not the same as a failed call. If the root call aborts, reverts, or runs out of gas, the transaction is still committed. Its contract changes are discarded, but its replay nonce and RCQ observations are recorded, so the signed transaction is consumed. Fix the cause and sign a new transaction.

Clients keep the submitted hash and observe its outcome. A pending result is not a reason to sign a replacement transaction. See [Track transaction results](../pages/typescript/transaction-status.md). When a recent attempt hit a storage conflict, [`getTransactionStatus`](../pages/reference/json-rpc-api.md#gettransactionstatus) can include `recentFailure` with `cause.kind` set to `dbConflict` and a `conflict` object naming the contract address, storage key, and conflict code. Use it to find hot keys.

To handle a conflict inside a child call, use [`with_commit_locking()`](../pages/contracts/cross-contract-calls.md#gas-limits). The child takes its commit locks before it returns, so a `try_` call sees the conflict as a failure.



## Gas

Transactions and cross-contract calls specify a gas limit. Gas bounds computation, including work in child calls, but costs zero tokens.

For root transactions, the gas limit is the scheduling quantity. The scheduler accounts for the amount you declare whether execution uses all of it or only part of it. If execution exceeds the limit, the transaction faults. The fault is committed with its contract changes discarded.

Each chain caps the root gas limit at `max_tx_gas`. A transaction above the cap is rejected, not clamped. Wire `14.1.0` servers expose the cap as `stated.maxTxGas` in [`getChainConfig`](../pages/reference/json-rpc-api.md#getchainconfig) and report the rejection as `gasLimitTooHigh`.

A child call without `with_gas_limit` can use all of the caller’s remaining gas. Unused child-call gas returns to the caller’s execution budget. That is not a token refund and does not change the root transaction’s scheduling amount.

```rust
let client = TokenClient::new(&token_address);
client.with_gas_limit(100_000).transfer(&to, amount);
```

Gas has no token fee, but lower gas limits use less scheduling capacity. Choose a limit that covers execution and design storage operations to avoid unnecessary conflicts.

Project Thruput needs no gas price estimation because the token price of gas is zero. Gas usage still matters when choosing an execution limit.



## Throughput

Your unlocked native-token balance provides scheduling capacity. A transaction’s gas limit must fit within the capacity the sending account’s tokens provide; the scheduler drops a transaction whose limit exceeds it. Compatible storage changes do not guarantee inclusion in the next block: admission, capacity, propagation, and expiry still matter. See [Balance-Proportional Scheduling](../pages/how-it-works/storage-economics.md#balance-proportional-scheduling) for the allocation rules.



## Storage Costs

The address that owns stored data funds its deposit. The runtime accounts for storage changes; your contract does not calculate the deposit itself. Delete data you no longer need with `delete()` or `Map::delete_at` to release its deposit. See [Storage: Refundable Deposits](../pages/how-it-works/storage-economics.md#storage-refundable-deposits) for funding and cost rules.

Next, [Storage Types](../pages/programming-model/storage-types.md) turns this model into concrete API choices.

---

## Storage Types

Source: <https://thruput.network/docs/programming-model/storage-types/>

SDK storage types, their conflict semantics, and how to choose between them.

Start with `Balance` for nonnegative counts and amounts. It exposes reads, increases, and decreases without requiring you to manage the underlying integer base. The storage type you choose determines whether concurrent writes merge, conflict, or ignore each other.

This page explains behavior and tradeoffs. For exact method signatures, see [Storage Types Reference](../pages/reference/storage-types.md) or [`thruput_sdk::storage` Rustdoc](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html).



## Balance

Nonnegative, zero-defaulting storage for counters, balances, allowances, and supply. `Balance` uses `i128` amounts in `0..=i128::MAX`, rejects negative inputs, and exposes no signed adjustment or absolute `set`.

```rust
use thruput_sdk::storage::Balance;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}
```

Read with `self.value.get()`. A never-written value returns zero; other storage failures still abort. With a snapshot value of `100`, these changes can merge:

```rust
// Two transactions run against a snapshot value of 100:
self.value.increase(5);   // Tx A: "add 5"
self.value.decrease(3);   // Tx B: "subtract 3"
// If both transactions are admitted, the result is 102.
```

Both methods check bounds during execution and record relative changes. The runtime also checks aggregate bounds when it reserves concurrent transactions. Two decreases that each fit the snapshot may still exceed it together, and credits from other transactions in the same block do not count toward a decrease. Successful execution alone does not guarantee inclusion. See [Merged Deltas](../pages/programming-model/execution.md#merged-deltas).



### Checked and lazy updates

For per-account amounts, combine Balance with a Map:

```rust
use thruput_sdk::{storage::{Balance, Map}, ContractAddress};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

Each direction has a checked and lazy form:

```rust
let sender = get_caller();

// Load the sender and fail during execution if funds are insufficient.
self.balances.at_mut(&sender).decrease(amount);

// Skip the receiver load and defer its bound check.
self.balances.at_mut(&receiver).lazy_increase(amount);
```

All four adjustment methods record deltas that can merge with compatible transactions:

| Method                  | Snapshot base      | Snapshot-bound result                        | Deltas merge? |
| ----------------------- | ------------------ | -------------------------------------------- | ------------- |
| `increase(amount)`      | Loaded if needed   | Overflow detected during contract execution  | Yes           |
| `decrease(amount)`      | Loaded if needed   | Underflow detected during contract execution | Yes           |
| `lazy_increase(amount)` | Not forced to load | Overflow decided during delta reservation    | Yes           |
| `lazy_decrease(amount)` | Not forced to load | Underflow decided during delta reservation   | Yes           |

The `try_` variants report errors that are available during contract execution, so a contract can translate an immediate failure into a domain error. Lazy variants cannot report a snapshot-bound failure that they deliberately did not load. They can still report conversion and transaction-local accumulated-delta errors.



## NNInt

`NNInt` is the lower-level integer API behind Balance. Use it when your state model needs a signed delta or an explicit base. For ordinary nonnegative counts and amounts, keep using Balance.

```rust
use thruput_sdk::storage::NNInt;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct IntegerState {
    value: NNInt,
}
```

The direction is part of the delta:

```rust
// Two transactions run against a nonnegative snapshot value of 100:
self.value.strict_inc(5);    // Tx A: "add 5"
self.value.strict_inc(-3);   // Tx B: "subtract 3"
// If both transactions are admitted, the result is 102.
```

`strict_inc` loads the base for an immediate underflow check; `inc` skips the forced read. Both produce deltas that can merge when their resolved bases match and aggregate bounds permit. Unlike Balance, `NNInt::get` fails on missing storage, and `set` can replace the base, including with a negative value. Negative bases change the commit-time floor.

Continue with [NNInt and concurrent updates](../pages/programming-model/nnint.md) for the `set_add` representation, base matching, and negative-base rules. Balance provides a narrower API over that same storage primitive; it does not use a different merge mechanism.



## Map\<K, V>

Key-value store. Different keys use independent storage locations. Same-key behavior follows the value type’s rules. Other shared writes or storage-funding limits can still prevent the complete transactions from landing together.

```rust
use thruput_sdk::{storage::{Balance, Map}, ContractAddress};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}
```

```rust
// Different keys: always independent, never conflict
self.balances.at_mut(&alice).lazy_increase(10);  // Tx A
self.balances.at_mut(&bob).lazy_increase(20);    // Tx B, no interaction

// Same key: follows Balance rules (compatible deltas merge)
self.balances.at_mut(&alice).increase(10);       // Tx A
self.balances.at_mut(&alice).lazy_increase(20);  // Tx B, merges to +30
```

Maps can nest: `Map<K, Map<K2, Balance>>` gives composite keys with independent conflict domains at each level. The ERC-20 allowance pattern uses this for owner and spender pairs.

Maps cannot enumerate keys, so a whole `Map` cannot be deleted. Delete one entry with `delete_at(&key)`, or call `delete()` on a deletable handle. Deleting data returns its [storage deposit](../pages/how-it-works/storage-economics.md#storage-refundable-deposits).



## Bytestring

Raw bytes. Concurrent writes of the same value commute. Concurrent writes of different values conflict.

```rust
use thruput_sdk::storage::Bytestring;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Config {
    owner: Bytestring,
}
```

```rust
self.owner.set(&new_owner);    // Tx A
self.owner.set(&other_owner);  // Tx B: conflict, one excluded
```

Use Bytestring for raw configuration or metadata. Writers of different values to the same location conflict; writers of identical values can coexist.



## RCQ\<T> / RetrocausalQueue

Multi-producer, single-consumer queue. Inserts from different transactions merge. Persisted entries are ordered by queue block, then lexicographically within that block. Concurrent observations follow the proposer-recorded order.

```rust
// These two transactions can both land:
self.requests.insert(&entry_a);  // Tx A
self.requests.insert(&entry_b);  // Tx B: no conflict

// Consumes pull from the front of the queue
let entry = self.requests.try_consume();
```

Only one transaction per block can consume from a given queue; a second consumer is excluded. A queue accepts at most 250 inserted entries per block, and each entry is at most 256 bytes. Use `RCQ<T>` when producers are concurrent and one consumer processes items in order. Lower-level raw functions are available when you need byte-level control.



## CapacityConstraint

A commit-time limit shared by changes from multiple transactions. Use it for a rule that spans transactions, such as a supply cap or an aggregate withdrawal limit. A check against a snapshot read cannot enforce that rule, because [reads are not checked at commit](../pages/programming-model/execution.md#snapshot-isolation).

```rust
use thruput_sdk::storage::CapacityConstraint;

#[thruput_sdk::storage]
pub struct WithdrawalLimit {
    remaining: CapacityConstraint,
}
```

```rust
// Reset at the start of a period.
self.remaining.set_capacity(period_limit);

// Each withdrawal consumes capacity without loading competing withdrawals.
self.remaining.consume_capacity(amount);
```

Consumption is staged on the handle and written when the handle is flushed or dropped. Call `try_flush()` to catch a flush error instead of aborting in drop. A negative amount releases capacity. The runtime enforces that the committed remaining capacity does not fall below its floor. As with `Balance`, all consumption in a block must fit the capacity the block started with; releases in other transactions do not count.

`set_capacity` must be the first write to that constraint in the transaction, except that repeating the same value is allowed. A reset uses `NNInt::set` rules: it conflicts with consumers in the same block unless it sets the current capacity value.



## Vector\<S>

Ordered collection. Each element is an independent storage slot. Internally backed by a `Map<u32, S>` for elements and a length counter.

```rust
use thruput_sdk::storage::{Vector, Node, Value};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Item {
    value: Value<u64>,
}

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Registry {
    items: Vector<Node<Item>>,
}
```

```rust
// Push a new element
self.items.push_with(|item| {
    item.value.set(&42);
});

// Read by index (bounds-checked)
let val = self.items.at(0).value.get();

// Mutate by index
*self.items.at_mut(0).value.load_mut() = 99;

// Iterate
for item in &self.items {
    let v = item.value.get();
}
```

Different indices are independent and never conflict (same as Map). Same-index writes follow the element type’s rules. Pushes and pops write the length with an exclusive lock, so only one transaction per block can change a vector’s length. That transaction can push or pop several times.

Use Vector for ordered collections where elements are accessed by index. Wrap compound structs in `Node<T>` so storage derivation works through the nesting. For hot concurrent writes, Map with application-managed keys is more parallelism-friendly than Vector with pushes.



## Value\<T>

Typed storage slot. Stores any CXS-serializable value. Conflict semantics are the same as Bytestring: concurrent writes of the same value commute, different values conflict.

```rust
use thruput_sdk::{storage::Value, ContractAddress};

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Config {
    owner: Value<ContractAddress>,
    threshold: Value<u64>,
}
```

```rust
let owner = self.owner.get();             // read (aborts if unset)
let result = self.threshold.try_get();    // read without aborting
self.owner.set(&new_owner);               // write
*self.threshold.load_mut() = 10;          // read-modify-write
```

Use `Value<T>` for typed single-slot storage. Use `Bytestring` when you need raw byte access or variable-length data without a fixed schema.



## Choosing a Type

| If your write pattern is…                        | Use                | Why                                                                             |
| ------------------------------------------------ | ------------------ | ------------------------------------------------------------------------------- |
| Nonnegative count, balance, allowance, or supply | Balance            | Nonnegative amounts, zero default, and checked or lazy deltas.                  |
| Signed delta or explicit integer base            | NNInt              | Signed deltas merge and `set` controls the base.                                |
| Cap or limit that spans transactions             | CapacityConstraint | The runtime enforces the limit across the block; a snapshot read cannot.        |
| `INSERT INTO ... (key, value)` with unique keys  | Map                | Different keys are independent.                                                 |
| Ordered list, accessed by index                  | Vector             | Per-element independence. One transaction per vector per block can push or pop. |
| Store a typed value                              | Value\<T>          | Typed Bytestring. Same conflict rules.                                          |
| `col = absolute_value` (raw bytes)               | Bytestring         | Accept that concurrent writes conflict.                                         |
| Append to a log or work queue                    | RCQ\<T>            | Inserts merge. One consumer per queue per block.                                |



## Exclusive Writes

Use exclusive writes when an operation needs sole write access to a storage location for the duration of a block. Compatible deltas normally merge; an exclusive write prevents concurrent modifications to that key.

- `Value<T>::set_exclusive(&v)`: one exclusive write to a typed slot.
- `Map::at_mut_exclusive(&key)`: every write through the returned handle (`Value`, `Balance`, `NNInt`, `Bytestring`, or nested fields) requests the lock.
- `Deletable::delete_exclusive()`: delete, then request the lock.
- Raw keys: `non_negative_int_set_exclusive`, `bytestring_set_exclusive`, `delete_exclusive`, or `set_storage_flags`.

```rust
self.config.set_exclusive(&new_value);          // Value<Config>
self.integer_state.at_mut_exclusive(&owner).set(v);  // Map<_, NNInt>
```

If two transactions write exclusively to the same key, one is excluded. An exclusive write is also excluded if another transaction in the block has already written that key. Once an exclusive write is admitted, every later write to the key in that block is excluded. Whichever transaction reserves first wins. Prefer `Balance` or `NNInt` deltas when the operation can tolerate concurrent updates.



### Lock Requests

An exclusive write requests `ExclusiveLock` after the write succeeds. Later ordinary writes to the key in the same transaction keep the request, including writes from other call frames. The admitted transaction then holds the key’s exclusive lock for the whole block. `clear_flags` withdraws the request.

```rust
self.integer_state.at_mut_exclusive(&owner).set(0);
self.integer_state.at_mut(&owner).inc(1);  // The lock request remains.
```

A reverted frame or failed `try_invoke` discards its flag changes along with its writes. Leaf handles implement `Flaggable` to read, add, or clear flags; see [Flaggable Trait](../pages/reference/storage-types.md#flaggable-trait) and [Storage Flags](../pages/reference/syscalls.md#storage-flags).

If `Balance` covers your state model, you do not need its lower-level representation. Read [NNInt and concurrent updates](../pages/programming-model/nnint.md) when you need signed changes, an explicit base, or the exact `set_add` commutativity rules. For runtime reservation details, continue to [Parallel Execution](../pages/how-it-works/execution-model.md).

---

## NNInt and concurrent updates

Source: <https://thruput.network/docs/programming-model/nnint/>

The set_add primitive underneath NNInt and why concurrent transactions merge.

`NNInt` is the lower-level signed-integer storage API underneath [`Balance`](../pages/programming-model/storage-types.md#balance). This page explains its `set_add` representation and why concurrent transactions can merge safely.

Start with `Balance` for nonnegative counters, balances, allowances, and supply. Read this page when you need signed changes, an explicit integer base, or the exact representation that makes checked and lazy balance deltas compatible.

For exact SDK method signatures, see [Rust API Docs](../pages/tools/rust-api-docs.md) or [Storage Types Reference](../pages/reference/storage-types.md#nnint).



## From Balance to NNInt

Balance gives each direction a name: `increase(5)` adds five and `decrease(3)` subtracts three. NNInt exposes the signed delta directly: `strict_inc(5)` and `strict_inc(-3)`. Both APIs record relative changes. Checked operations load the base for early bound checks; lazy operations defer snapshot-bound checks to reservation.

Balance also enforces a nonnegative value and supplies zero for missing storage. NNInt adds control over the base through `set`, and its `get` fails on missing storage. Use that lower-level control only when the state model needs it.



## The set_add Primitive

Every NNInt storage location maintains two pending values during a transaction:

- **set**: `i128`. The absolute base value.
- **add**: `i128`. The accumulated delta.

The low-level operation is `set_add(set_value, add_value)`. It replaces both pending values. The final committed value is `set + add`, subject to overflow, reservation, and floor checks. The storage handle’s `strict_inc`, `inc`, and `set` methods map to this operation.



## The One Rule

Two concurrent `set_add` calls commute **if and only if their resolved set values are equal**.

The bases must match each other; they do not have to equal the snapshot value.

| Tx A              | Tx B                         | Result                                                  |
| ----------------- | ---------------------------- | ------------------------------------------------------- |
| `set_add(S, x)`   | `set_add(S, y)`              | Merge: same base, adds combine to `x + y`               |
| `set_add(100, x)` | `set_add(100, y)`            | Merge: same explicit base, even if snapshot != 100      |
| `set_add(A, x)`   | `set_add(B, y)` where A != B | **Conflict**: different bases, one transaction excluded |

A merge still has to fit in `i128` and respect the floor described in [Negative Set Values](../pages/programming-model/nnint.md#negative-set-values). All negative deltas admitted in a block must fit within the base; positive deltas from other transactions do not offset them.



## The None Path

`set_add` also accepts `None` as the set value: `set_add(None, add_value)`. This means “I don’t need to choose the base in this transaction. Let the runtime resolve it from the snapshot.”

The runtime resolves `None` to the start-of-block value, or to `0` if the key is absent or not an NNInt. This skips the snapshot read in the contract and gives the same result as loading the base yourself.

| Tx A               | Tx B                                | Commutes?                                     |
| ------------------ | ----------------------------------- | --------------------------------------------- |
| `set_add(None, x)` | `set_add(None, y)`                  | Yes: both resolve to the start-of-block value |
| `set_add(None, x)` | `set_add(S, y)` where S = snapshot  | Yes: same effective base                      |
| `set_add(None, x)` | `set_add(S, y)` where S != snapshot | **No**: different resolved bases              |



## How the API Maps to set_add

| Method              | Effective call                                       | Loads the base? | Commutes?                                         |
| ------------------- | ---------------------------------------------------- | --------------- | ------------------------------------------------- |
| `strict_inc(delta)` | `set_add(Some(base), accumulated + delta)`           | Yes             | When resolved bases match                         |
| `inc(delta)`        | `set_add(existing_set_or_None, accumulated + delta)` | No              | When resolved bases match                         |
| `set(value)`        | `set_add(Some(value), 0)`                            | No              | Only if all concurrent callers set the same value |

**strict_inc(delta)** loads the base (a pending explicit set, the snapshot value, or `0` for an empty key) and aborts immediately if the transaction’s running total would be negative. Use it when you want an early underflow check.

**inc(delta)** keeps a pending explicit set if this transaction has one; otherwise it uses the `None` path and skips the read. Underflow is caught later, during reservation, which can be harder to debug.

**set(value)** replaces the base and clears the delta. `set(100)` merges with `set(100)` and conflicts with `set(200)`. It conflicts with a concurrent `strict_inc` or `inc` unless the snapshot is 100. Reserve `set` for initialization or admin operations.

`strict_inc` and `inc` merge with each other when their resolved bases match. Choose between them based on read cost and the need for early underflow detection.



## Negative Set Values

Despite the protocol name `NonnegativeInt`, an explicit `set` can be negative. The commit-time invariant is:

```text
value >= min(set, 0)
```

A negative base becomes the floor. An increment can move the value up from it, but nothing can subtract from it:

```rust
non_negative_int_set(key, -5);
non_negative_int_inc(key, 1);  // The value becomes -4.
// set_add(-5, -1) is rejected.
```

`strict_inc` rejects a running total that remains negative, so use `inc` or the raw functions for negative-base state. Use `Balance` for ordinary nonnegative counters, balances, and allowances. A negative NNInt base is a separate state model, not a way to represent a Balance.

Matching bases are required, but do not guarantee inclusion: aggregate bounds and other transaction changes still matter. See [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) for the contract-level model.

---

## Authorization

Source: <https://thruput.network/docs/how-it-works/authorization/>

How transaction signatures, address auth data, caller identity, and auth tokens work in Project Thruput.

Project Thruput treats addresses uniformly. An address can hold code, store auth data, receive calls, and originate transactions through either supported admission model.

Authorization has two layers:

1. **Transaction admission**: hogd checks the transaction’s auth claim and signatures before execution.
2. **Runtime authorization**: contracts use caller identity, explicit signature checks, and typed auth tokens while executing.

These layers are related but separate. Transaction admission decides whether the root transaction may enter the block. Runtime authorization decides what authority a contract gives to a caller or token it receives.



## Authorize an application operation

For an owner-controlled method, store the owner in `Value<ContractAddress>` and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), AccessError::NotOwner);
```

Define `AccessError` with [a contract exception](../pages/contracts/errors.md#defining-errors). Initialize the owner through a guarded method and [deploy and initialize atomically](../pages/cli/deploy-and-call.md#include-initialization) if the first caller becomes the owner.

`get_caller()` identifies the immediate caller. A forwarded call identifies the forwarding contract, not the original user. For authority passed through several frames, use the [typed auth-token model](../pages/how-it-works/authorization.md#auth-tokens-and-signedt) below and validate its minter and payload.



## Transaction Admission

A `SignedTransaction` contains an inner transaction, decorated signatures, and, for pubkey accounts, the signing public key:

```text
struct DecoratedSignature {
  unsigned int public_key_id;
  Signature signature;
};

struct SignedTransaction {
  Transaction tx;
  DecoratedSignature signatures<>;
  PublicKey *pubkey_claim_key;
};
```

The source address is the root invocation’s `invoked_address`. Every transaction signature covers this preimage:

```text
cxs(DomainSeparator("Transaction")) || networkHash || txs(transaction)
```

`txs(value)` denotes its standard XDR encoding. The domain separator prevents a transaction signature from being interpreted as a signature over another object. The network hash binds the signature to one Project Thruput network and prevents cross-network replay.

The canonical transaction hash is `sha256(txs(transaction))`. It identifies the inner transaction and excludes signatures. It is distinct from both the signature preimage and the encoded `SignedTransaction` wrapper.



### Signature Schemes

| Scheme               | Public key  | Signature   | Notes                                                    |
| -------------------- | ----------- | ----------- | -------------------------------------------------------- |
| Ed25519              | 32 bytes    | 64 bytes    | Default scheme in the CLI                                |
| ML-DSA-65 (FIPS 204) | 1,952 bytes | 3,309 bytes | Pure ML-DSA with an empty context string, not HashML-DSA |

Both schemes sign the preimage above directly, with no extra pre-hash. ML-DSA-65 signing is randomized by default, so two valid signatures over one transaction can differ. The transaction hash stays the same because it excludes signatures.



## Admission Models

The transaction’s `AuthClaim` selects one of two admission models:

```text
enum AuthClaim switch (AuthClaimType claim_type) {
case kSourceAddressAuthData:
  struct {
    BitMap allowed_keys;
    Weight required_weight;
  } source_address_claim;

case kPubkeySignature:
  PubkeyAccountPreimage pubkey_preimage;
};
```



### Pubkey Accounts

`kPubkeySignature` authorizes an account whose address is derived from `PubkeyAccountPreimage { pubkey_hash, nonce }`. The preimage holds a hash of the public key, not the key itself:

```text
pubkey_hash = sha256(cxs(DomainSeparator("PublicKey")) || cxs(PublicKey))
```

The `PublicKey` encoding includes its scheme, so the same key bytes under Ed25519 and ML-DSA-65 give different addresses. The full key travels in `SignedTransaction.pubkey_claim_key`.

This derivation also changed Ed25519 addresses. A pubkey-account address saved before the Futurenet reset that introduced ML-DSA-65 does not match the same key now. Derive the address again from the key and update saved addresses.

hogd accepts the claim only when:

- the derived address equals the root invocation’s `invoked_address`;
- the source address has no registered `AddressAuthData`;
- the transaction has exactly one signature, with `public_key_id` 0;
- `pubkey_claim_key` is present and its hash equals `pubkey_hash`;
- the signature uses the same scheme as `pubkey_claim_key` (Ed25519 or ML-DSA-65) and verifies against it.

During root execution at an undeployed pubkey-account address, the runtime falls back to the network’s configured DefaultWallet contract. This gives a new pubkey account wallet behavior without first deploying code at its derived address. The fallback applies only to the root invocation.



### Source-Address Accounts

`kSourceAddressAuthData` authorizes the root invocation from auth data stored at its source address. The source address must have `AddressAuthData`; a source-address claim without it is rejected. A source-address claim must not carry `pubkey_claim_key`.

hogd checks:

- `allowed_keys` does not set bits beyond `kMaxSigners = 21`.
- Every signature’s `public_key_id` appears in `allowed_keys`.
- Signature `public_key_id` values are strictly increasing, so duplicates and out-of-order signatures are rejected.
- Each referenced key exists in the source address’s `AddressAuthData`.
- Each signature uses its registered key’s scheme and verifies against that key.
- The sum of matched key weights is at least `max(address.required_weight, claim.required_weight)`.

The threshold is `max(address.required_weight, claim.required_weight)`. This lets the address set a standing minimum while each transaction can require an equal or higher threshold.

Contracts can inspect the root transaction’s auth claim with [`get_auth_claim()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/auth_claim/fn.get_auth_claim.html), but admission has already happened by the time contract code runs. For a pubkey account, the claim exposes `pubkey_hash` and `nonce`, not the public key.



## Address Auth Data

`AddressAuthData` is stored under `StorageKeyType::AuthData` for an address:

```text
struct PublicKeyConfig {
  PublicKey key;
  Weight max_weight;
};

struct AddressAuthData {
  PublicKeyConfigOpt public_keys[21];
  Weight required_weight;
  BlockHeight last_written_height;
};
```

Each key slot is optional. Empty slots do not contribute weight.

An address can mutate only its own auth data. The SDK exposes the current syscalls as:

```rust
use thruput_sdk::{
    add_address_public_key,
    remove_address_public_key,
    set_address_required_weight,
};

add_address_public_key(0, public_key, 1)?;
set_address_required_weight(1)?;
remove_address_public_key(0)?;
```

Registered keys can be Ed25519 or ML-DSA-65. `add_address_public_key` accepts both schemes, and admission verifies each signature with its slot’s scheme.

Use these for source-address accounts, wallet contracts, and contracts that are meant to originate later transactions. Replay protection is transaction-level, through the transaction `Uniquifier`. `AddressAuthData` does not contain nonce policy or gas-sponsorship policy fields.



## Caller Identity

Inside a contract, [`get_caller()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_caller.html) returns the direct caller of the current invocation frame:

```rust
use thruput_sdk::get_caller;

let caller = get_caller();
```

This is Project Thruput’s equivalent of `msg.sender`: immediate caller identity. It is not a signer set and it does not tell you which key signed the root transaction. A root frame has no caller, so the underlying syscall errors there.

Use [`get_current_address()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/contract_op/fn.get_current_address.html) when a contract needs its own address.



## Contract Signature Checks

Contracts can verify arbitrary messages with [`verify_signature_ed25519()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/crypto/fn.verify_signature_ed25519.html):

```rust
use thruput_sdk::crypto::verify_signature_ed25519;

let ok = verify_signature_ed25519(&public_key, &signature, message);
```

Contract signature checks support Ed25519 and ML-DSA-65. `verify_signature()` takes a `PublicKey` and a `Signature` and verifies in the key’s scheme. ML-DSA-65 is pure ML-DSA with an empty context. `verify_signature_ed25519()` takes Ed25519 types only.

This is runtime logic, separate from transaction admission. A wallet contract can use it to accept an off-chain signature, apply its own policy, and then mint an auth token in the wallet contract’s name.



## Auth Tokens and `Signed<T>`

The SDK’s [`Signed<T>`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/struct.Signed.html) is a typed runtime auth-token handle. It is not a cryptographic signature and it is not a durable bearer token.

An auth token carries:

- **Minter**: set by the host to the current contract address at mint time.
- **Consumer**: the contract address allowed to consume the token.
- **Payload**: CXS-encoded typed data from the SDK.
- **Expiry height**: the token is valid through this block height.
- **Child nodes**: nested auth tokens that materialize when the parent is consumed.

`Signed<T>` is a handle to this runtime token. The handle travels out-of-band alongside calldata; it does not serialize the payload into the method argument bytes. Contract specifications represent it as a `SignedToken` node containing the payload type.

To make a payload type usable in a token, mark it as a contract type:

```rust
use thruput_sdk::*;

#[contract_type]
pub struct TransferAuth {
    pub to: ContractAddress,
    pub amount: i128,
}
```

Mint with [`mint_auth_token()`](https://crates.thruput.network/docs/sdk/0.34.3/doc/sdk/signer/fn.mint_auth_token.html):

```rust
use thruput_sdk::*;

let token: Signed<TransferAuth> = mint_auth_token(
    expiry,
    AuthTokenPreimage {
        consumer: token_contract,
        data: TransferAuth { to, amount },
    },
);
```

Consume with `Signed<T>::consume()`:

```rust
use thruput_sdk::*;

pub fn transfer_from(
    amount: i128,
    to: &ContractAddress,
    auth: Signed<TransferAuth>,
) {
    let (claim, minter) = auth.consume();

    assert!(minter == expected_wallet(), "unauthorized minter");
    assert!(claim.to == *to, "unauthorized recipient");
    assert!(amount <= claim.amount, "exceeds authorized amount");

    // Move funds from `minter` to `to`.
}
```

Consuming proves only two things: the token was minted by the returned `minter`, and the token was destined for the current contract. Any contract can mint a token whose payload decodes as `TransferAuth`. Always check the returned minter against an address your contract trusts before acting on the payload.



## Passing Auth Tokens

Auth tokens never flow implicitly across contract calls. Generated clients collect `Signed<T>` handles from arguments and pass those token ids to `Invoke` beside calldata. A callee receives only the tokens that appeared in its arguments.

Frame ownership works like this:

- When a parent forwards a token to a child call, the child owns that token while it runs.
- If the child returns the token in its return value, the parent receives it back.
- If the child aborts or the parent handles a reverted child frame, forwarded tokens are restored to the parent.
- If the child succeeds without returning a forwarded token, the parent does not automatically regain it.
- Consuming a token removes it. Any child tokens become fresh handles owned by the consuming frame.

This makes method signatures part of the authorization surface: a function that does not take a `Signed<T>` argument cannot consume that token.

Generated clients assign returned token handles to `Signed<T>` fields in the return value. Lower-level callers that receive a `Vec<Signed<Opaque>>` can use `AssumeTokens::try_assume_tokens` to convert an exact number of opaque handles into a typed tuple. A count mismatch returns `CallingError::DecodingSuccess`; `AssumeTokens::assume_tokens` is the throwing convenience form.



## Nested Auth Tokens

A token payload can contain `Signed<U>` fields. When the outer token is consumed, the runtime creates child-token handles for those fields. Child tokens keep the same minter and expiry as the parent, but each child has its own consumer address and payload.

```rust
use thruput_sdk::*;

#[contract_type]
pub struct DexIntent {
    pub pool: ContractAddress,
    pub deadline: BlockHeight,
    pub min_received: i128,
    pub transfer: Signed<TransferAuth>,
}

pub fn execute_swap(intent: Signed<DexIntent>) {
    let (intent, trader) = intent.consume();

    assert!(trader == expected_wallet(), "unauthorized trader");
    assert!(get_block_height() <= intent.deadline, "intent expired");

    // The nested transfer token is now a fresh handle that can be passed to
    // the token contract selected as its consumer.
    token_client.transfer_from(amount_in, &intent.pool, intent.transfer);
}
```

The outer token might be consumed only by the DEX. The nested transfer token might be consumed only by the token contract. Attribution stays with the original minter through the chain.



## Limits

The protocol caps an auth-token payload at 256 bytes and child nodes per token at 4. Network parameters cap tree depth (`max_auth_token_depth`, default 4) and token ids per `Invoke` or `Return` list (`max_auth_tokens`, default 64). `MintAuthToken` rejects malformed token nodes, expired-at-mint tokens, and tokens that would exceed runtime caps. `ConsumeAuthToken` rejects tokens not owned by the current frame, expired tokens, and already-consumed handles.



## Not Landed

Do not rely on these patterns yet:

- Detached admission-time signatures that directly become `Signed<T>` values.
- Nonce or gas-sponsorship policy fields in `AddressAuthData`.
- Durable, storable, or off-chain portable `Signed<T>` handles. A `Signed<T>` is a runtime handle owned by invocation frames inside a transaction.



## See Also

- [Invocation Frames](../pages/how-it-works/invocation-frames.md)
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md)
- [Syscalls](../pages/reference/syscalls.md)
- [SDK Macros](../pages/reference/sdk-macros.md)
- [Rust API Docs](../pages/tools/rust-api-docs.md)

---

## Handle errors

Source: <https://thruput.network/docs/contracts/errors/>

How errors work in Project Thruput contracts.

Exported Project Thruput contract methods return their declared values and signal failure by throwing an exception. The frame aborts, all state changes in that frame are discarded, and control returns to the caller. Private helpers may use `Result` when they translate failures into a contract or library exception.

You cannot catch a thrown exception within the same frame. Use `Result`-returning helpers for local fallible work and generated `try_*` client methods for another contract. See [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md).

For exact SDK signatures, see [Rust API Docs](../pages/tools/rust-api-docs.md).



## Defining Errors

Use `#[contract_exception]` to define error types. It generates `Debug`, `PartialEq`, serialization and spec traits, and the `Exn` implementation. Add `Clone` yourself if the type needs it.



### `thiserror` and `anyhow`

You can use `thiserror` with `#[contract_exception]` when you want `Display` messages for logs, tests, or off-chain tooling. Put `#[derive(thiserror::Error)]` on the exception type and use `#[error("...")]` on each variant:

```rust
use thruput_sdk::*;

#[derive(thiserror::Error)]
#[contract_exception]
pub enum CounterError {
    #[error("not authorized")]
    NotAuthorized = 1,
}
```

Do not copy the usual `#[derive(Error, Debug)]` pattern from generic Rust examples. `#[contract_exception]` already generates `Debug` and `PartialEq`; deriving them again creates duplicate implementations.

For contract crates, configure `thiserror` without the default `std` feature:

```toml
thiserror = { version = "2", default-features = false }
```

Avoid `anyhow` for contract exception types and public contract method surfaces. `anyhow::Error` is an erased application error type, while contract exceptions need concrete CXS-serializable types that appear in the contract spec. `anyhow` is fine in off-chain tools, build scripts, tests, or CLI code. Inside a contract, private helpers may use `Result` if they immediately convert failures into concrete contract exceptions with `throw`, `ensure`, or `or_throw`.



### Enum errors

Enum errors carry variant-level meaning. Each variant gets an explicit `i32` discriminant. The macro adds `#[repr(i32)]` for you.

```rust
use thruput_sdk::*;

#[contract_exception]
pub enum ERC20Error {
    AlreadyInitialized = 1,
    MustBeContractOwner = 2,
    TooLarge = 3,
    BalanceNotZero = 4,
    NegativeAmount = 5,
    Internal = 100,
}
```



### Struct errors

Struct errors work when you only need a single error type with no variants.

```rust
use thruput_sdk::*;

#[contract_exception]
pub struct Unauthorized;
```

Structs with fields work too:

```rust
#[contract_exception]
pub struct InsufficientBalance {
    pub balance: u64,
}
```



## Throwing Errors



### `throw(exn)`

Aborts the current frame with the given error. Never returns.

```rust
use thruput_sdk::*;

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    if amount < 0 {
        throw(ERC20Error::NegativeAmount);
    }
    // ...
}
```



### `ensure(condition, error)`

Throws `error` if `condition` is false. A convenience wrapper around `throw`.

```rust
use thruput_sdk::*;

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    ensure(
        get_caller() == self._administrator(),
        ERC20Error::MustBeContractOwner,
    );

    self._increase_total_supply(amount);
    self._lazy_increase_balance(receiver, amount);
}
```



### `result.or_throw(exn)`

Extension method on `Result`. Returns the `Ok` value, or throws `exn` on `Err`. Useful for converting fallible operations into contract exceptions.

```rust
use thruput_sdk::*;

fn _decrease_balance(&mut self, owner: &ContractAddress, amount: Amount) {
    self.balances
        .at_mut(owner)
        .try_decrease(amount)
        .or_throw(ERC20Error::TooLarge);
}
```



## Automatic Aborts

The SDK throws `LibraryExn` errors automatically when internal preconditions fail. You do not need to define error variants for these.

| Operation                                 | Throws when                                                                                         |
| ----------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `Balance::decrease(amount)`               | Balance is insufficient (`NonNegativeIntUnderflow`)                                                 |
| `Balance::increase(amount)`               | Balance would overflow (`NonNegativeIntOverflow`)                                                   |
| `NNInt::strict_inc(delta)`                | Result would be negative (`NonNegativeIntUnderflow`)                                                |
| `NNInt::strict_inc(delta)`                | Result would overflow (`NonNegativeIntOverflow`)                                                    |
| `CapacityConstraint::set_capacity(value)` | Another non-idempotent write already occurred this transaction (`CapacityConstraintAlreadyWritten`) |
| `bytestring_get_sized`                    | Stored length does not match expected (`BytestringWrongSize`)                                       |
| `NNInt::get()`                            | Key does not exist (syscall error); `Balance::get()` defaults missing storage to zero               |

```rust
// Aborts automatically if balance would go below zero.
// No error handling code needed.
balance.decrease(amount);
```

Every public SDK function whose name starts with `try_` reports its own failures through `Option` or `Result` instead of aborting. Storage `try_` getters return `Result<T, LibraryExn>`. Use `error.is_storage_missing()` to identify absence, or `.none_if_missing()` to convert only absence into `None` while re-throwing other failures.



## LibraryExn

`LibraryExn` is the SDK’s built-in error enum. It covers all errors generated by SDK internals and runtime operations.

| Variant                                              | Discriminant | Trigger                                                                                                                                                                                                 |
| ---------------------------------------------------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Syscall(SyscallExn)`                                | 0            | A host syscall returned an error (e.g. storage key not found)                                                                                                                                           |
| `Handling(HandlingError)`                            | 1            | Error while handling an incoming contract call (decoding args, encoding result)                                                                                                                         |
| `Calling(CallingError)`                              | 2            | Error while making an outgoing contract call: encoding args, decoding the result, or the runtime refusing the invoke as reentrant (`Reentrance`) or past the cross-invoke depth bound (`DepthExceeded`) |
| `Called(FaultString)`                                | 3            | The called contract reverted                                                                                                                                                                            |
| `AuthToken(AuthTokenError)`                          | 4            | Error encoding or consuming an authorization token                                                                                                                                                      |
| `BytestringWrongSize { expected, found }`            | 5            | A fixed-size bytestring read found a different length                                                                                                                                                   |
| `NonNegativeIntUnderflow`                            | 6            | An integer or balance operation would violate its lower bound                                                                                                                                           |
| `NonNegativeIntOverflow`                             | 7            | An integer or balance operation would overflow                                                                                                                                                          |
| `StorageSerialization`                               | 8            | A typed storage value could not be serialized or deserialized                                                                                                                                           |
| `StorageIndexOutOfBounds { len, access }`            | 9            | A vector index was outside its logical extent                                                                                                                                                           |
| `StorageKeypathOverflow`                             | 10           | A no-allocation storage keypath exceeded its fixed budget                                                                                                                                               |
| `RetrocausalQueueEntryWrongSize { expected, found }` | 11           | A fixed-size queue read found a different entry length                                                                                                                                                  |
| `CapacityConstraintAlreadyWritten`                   | 12           | `set_capacity` followed an incompatible write in the same transaction                                                                                                                                   |
| `UnknownMethod`                                      | 13           | The callee has no entrypoint for the invoked method ID                                                                                                                                                  |

`LibraryExn` is `#[non_exhaustive]`: when matching, always include a wildcard arm.

Generated `try_*` calls can return a `LibraryExn` thrown by the callee. See [Library errors](../pages/contracts/errors.md#library-errors) below for an example.



## Cross-Contract Errors

A thrown exception travels as `[selector][payload]`, where the selector is derived from the exception *type*, not from the interface that threw it. Callers match on that selector, so what a caller can catch does not depend on what the callee’s interface declared.

`throws` declares an interface’s error contract: it is published in the contract spec and tells callers what to expect. It does not gate catching.



### Declaring thrown errors

Single error type:

```rust
#[contract(client = CounterClient, throws = CounterError)]
impl Counter {
    // ...
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    // ...
}
```



### Catching errors with `try_*` methods

Every method on the generated client has a `try_` variant returning `Result<T, CallError>` instead of aborting. `CallError` is the same type for every client; a caught exception stays undecoded inside it, and `match_exn!` decodes it against the types you name:

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(val) => {
        // Success
    }
    Err(CallError::Fault(f)) => {
        // The called contract panicked
    }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => {
            // Handle the expected error
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Fault`, `Invalid`, and encode/decode failures with ordinary `match` arms on `CallError`. `match_exn!` handles only the typed part, and its arms are tried in order, so a final `_` arm is required.



### Library errors

`LibraryExn` is matched like any other exception type. There is no special wrapper variant:

```rust
match client.try_do_something() {
    Err(e) => match_exn!(e, {
        LibraryExn::NonNegativeIntUnderflow => {
            // The called contract underflowed an NNInt
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```



### Non-try calls and re-throwing

Non-try client methods (e.g. `client.do_something()` without the `try_` prefix) automatically re-throw any exception from the called contract. The error propagates through the call chain with its original selector intact.



### Undeclared errors

An error type absent from `throws` is caught exactly like a declared one. The selector identifies it either way:

```rust
match client.try_throw_undeclared() {
    Err(e) => match_exn!(e, {
        SecretError => {
            // Never declared by the interface; matched all the same
        }
        _ => e.re_throw(),
    }),
    Ok(_) => {}
}
```

This is what lets an extension define errors the base interface does not declare. `ERC20PausableError::EnforcedPause` can come back from `ERC20::transfer`, and an `ERC20Client` caller matches it in the same `match_exn!` as `ERC20Error`, no separate decode step, and no coupling of the base interface to the extension.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&to, 1).unwrap_err().try_as(),
    Some(ERC20PausableError::EnforcedPause),
);
```

`None` covers all three ways this can miss: no exception, a different type, or a payload that failed to decode. Use `try_decode` when the last of those must be distinguished from the other two. See [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one), which also explains how this can occur through semver-compatible evolution.

See [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md) for the full calling patterns.

---

## Events

Source: <https://thruput.network/docs/contracts/events/>

Define, declare, emit, and test typed events in a Rust contract.

Events expose contract activity to applications. A contract emits topics for filtering and a payload for the data consumers need to read. Use storage for state your contract must read later; contracts cannot read events back.



## Define an event

```rust
use thruput_sdk::*;

#[derive(Event, Clone, Debug)]
pub struct CounterIncremented {
    #[topic]
    pub by: ContractAddress,
    pub amount: u64,
}
```

`#[derive(Event)]` generates the event signature, topic encoding, and a payload type. Topic 0 is the signature. Up to two fields can use `#[topic]`; fields without it go into the CXS-encoded payload.

Here, consumers can filter on `by` and read `amount` from the payload. Strings and byte slices used as topics retain only a hash, so also include them in the payload if consumers need their original values. The total size of topics and payload is limited to 1,024 bytes.



## Declare and emit it

Add the event to a counter method to record the amount and caller:

```rust
use thruput_sdk::storage::Balance;

#[derive(Debug)]
#[thruput_sdk::storage]
pub struct Counter {
    value: Balance,
}

#[contract(emits(CounterIncremented))]
impl Counter {
    pub fn increment(&mut self, amount: u64) {
        self.value.increase(amount as i128);
        log_event(&CounterIncremented {
            by: get_caller(),
            amount,
        });
    }
}
```

`get_caller()` identifies the immediate caller of this frame. For a forwarded call, that is the forwarding contract.

`emits(...)` records the event in the contract spec. Put it on the inherent implementation or interface trait definition, not on a trait implementation. When adding an event to an existing contract, retain its other event and error declarations.



## Test an emitted event

Export the event alongside the generated client from your contract library. In a native test, call `increment` and inspect the returned `TransactResult`:

```rust
let result = env.transact(|tx| {
    tx.call(&caller).run(|| {
        CounterClient::new(&address).increment(5);
    })
});
result.assert_success();
result.assert_event_count(1);
result.assert_event::<CounterIncremented>(0, |event| {
    assert_eq!(event.topic(0), Some(CounterIncremented::SIGNATURE));
    let by: &ContractAddress = event.topic(1).unwrap().into();
    assert_eq!(by, &caller);
    assert_eq!(event.payload().amount, 5);
});
```

Here, `env` is the test environment, `caller` is the calling address, and `address` is the deployed test contract. See [Testing](../pages/programming-model/testing.md#basic-pattern) for registration and deployment setup.

The event count covers all contracts called by the test transaction. Assert both topics and payload so the test checks the event’s content, not only its presence.



## Include the event in the interface

Rebuild after changing an event declaration. The generated spec records its name, signature, topic layout, and payload layout. [Client bindings](../pages/contracts/client-bindings.md) use that metadata to expose the event to applications.

For library-emitted events that no interface declares, `#[event_spec(export)]` explicitly includes the type in the linked contract’s spec. See the [event macro reference](../pages/reference/sdk-macros.md#deriveevent) for the generated API.

Use [Read events](../pages/typescript/events.md) for application queries, receipt decoding, and pagination.

---

## Cross-Contract Calls

Source: <https://thruput.network/docs/contracts/cross-contract-calls/>

Calling other contracts from your contract.

Use a generated Rust client to call another contract through its interface. Direct calls propagate failures; `try_*` calls let your contract inspect them. These are onchain clients, separate from the TypeScript clients used by applications.



## Client Generation

On a trait definition or inherent impl, `#[contract]` generates a client struct, named `{Interface}Client` unless you override it with `client = CustomName`. The client mirrors every public method on the trait or impl block.

For interface design, see [Methods and interfaces](../pages/contracts/methods.md). For macro parameters, see [SDK Macros](../pages/reference/sdk-macros.md#contract).

Single error type:

```rust
#[contract(client = ERC20Client, throws = ERC20Error)]
pub trait ERC20 {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount);
    fn get_balance_of(&self, addr: &ContractAddress) -> Amount;
}
```

Multiple error types:

```rust
#[contract(client = MultiClient, throws(AlphaError, BetaError))]
pub trait MultiThrows {
    fn succeed() -> u32;
    fn throw_alpha_not_found();
    fn throw_beta_denied();
}
```

For each method `foo`, the generated client provides:

| Method         | Signature                            | On error                                                                                                 |
| -------------- | ------------------------------------ | -------------------------------------------------------------------------------------------------------- |
| `foo(...)`     | Same return type as the trait method | Re-throws. Your contract aborts too.                                                                     |
| `try_foo(...)` | `Result<T, CallError>`               | Returns the error for inspection. Match it with `match_exn!`, or decode it with `try_as` / `try_decode`. |



## Making Calls

Construct a client with the target contract’s address, then call methods on it.

```rust
let token = ERC20Client::new(&token_addr);
let balance = token.get_balance_of(&account);
token.transfer(&recipient, 100);
```

Client methods take `&self` (not `&mut self`). Clients are lightweight value types holding an address and configuration.



## Gas Limits

Use `with_gas_limit` to cap how much computation the callee can perform. It returns a new client instance (non-mutating).

```rust
let token = ERC20Client::new(&token_addr);
let capped = token.with_gas_limit(500_000);
capped.transfer(&recipient, 100);
```

The default request is `u64::MAX`; the child is still bounded by the caller’s remaining gas. Use an explicit cap when the callee should receive less. See [Contract Execution](../pages/programming-model/execution.md#gas) for details.

| Method                      | Signature                               | Description                                                                                               |
| --------------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `new(address)`              | `fn new(&ContractAddress) -> Self`      | Create a client for the given contract address.                                                           |
| `with_gas_limit(gas_limit)` | `fn with_gas_limit(&self, u64) -> Self` | Return a new client with the specified gas limit.                                                         |
| `with_commit_locking()`     | `fn with_commit_locking(&self) -> Self` | Ask the child frame to acquire its commit locks before returning, so a `try_` call can handle a conflict. |
| `with_read_only()`          | `fn with_read_only(&self) -> Self`      | Prevent the child frame from modifying state.                                                             |

`with_commit_locking()` and `with_read_only()` return a configured copy of the client. They can be combined:

```rust
let result = ERC20Client::new(&token_addr)
    .with_commit_locking()
    .with_read_only()
    .try_get_balance_of(&account);
```

Commit locking performs early conflict detection at the child-frame boundary. If lock acquisition fails, the child reverts and a `try_` method can inspect the failure. Read-only calls may read storage but cannot write, deploy a contract, or perform another state-changing operation.



## Error Handling



### Direct calls (re-throw)

Direct calls propagate errors automatically. If the callee throws, your contract throws the same exception to its own caller. No error handling needed or possible.

```rust
let client = MultiClient::new(&addr);

// If this throws AlphaError::NotFound, your contract
// re-throws the same error to whoever called you.
client.throw_alpha_not_found();
```



### try\_ calls (inspect)

Prefixing any method with `try_` returns a `Result` you can match on. The error type is the SDK’s `CallError`, the same type for every client.

```rust
let client = MultiClient::new(&addr);

match client.try_throw_alpha_not_found() {
    Ok(()) => { /* success */ }
    Err(e) => match_exn!(e, {
        AlphaError::NotFound => { /* handle this error */ }
        _ => e.re_throw(),
    }),
}
```



### CallError

`try_*` does not pre-decode the exception into a per-interface enum. A caught exception stays a `RawException`, and `CallError` describes only how the call failed:

```rust
pub enum CallError {
    Invalid,
    Reentrance,
    DepthExceeded,
    InvokeRejected(SysErr),
    Exception(RawException),
    Fault(FaultInfo),
    UnparseableReturn(FaultString),
    UnparseableAbort(FaultString),
    UnparseableAuthHandles(FaultString),
    EncodingArgs(FaultString),
}
```

| Variant                               | When it appears                                                                                                                                                                                                                                       |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Invalid`                             | The call could not be made (e.g. invalid contract address before the call dispatched).                                                                                                                                                                |
| `Reentrance`                          | The target already had a frame open on the invocation stack, so the runtime refused the call as reentrant. See [`Reentrance`](../pages/reference/syscalls.md) in the syscall errors.                                                                  |
| `DepthExceeded`                       | Admitting the call would have exceeded the network’s cross-invoke depth bound. The same call succeeds from a shallower frame.                                                                                                                         |
| `InvokeRejected(SysErr)`              | The invoke syscall was refused for another reason, carrying the raw syscall error.                                                                                                                                                                    |
| `Exception(RawException)`             | The callee threw. Any exception type, declared in `throws` or not, including the SDK’s own `LibraryExn`.                                                                                                                                              |
| `Fault(FaultInfo)`                    | The callee panicked, trapped, or exhausted gas. Child faults carry no diagnostic message across the call boundary. `FaultInfo` exists on every target and is zero-sized without `dev`; only a native root-frame panic can retain harness diagnostics. |
| `UnparseableReturn(FaultString)`      | The callee committed but its return buffer could not be decoded as the expected type.                                                                                                                                                                 |
| `UnparseableAbort(FaultString)`       | The callee aborted but the abort payload could not be parsed.                                                                                                                                                                                         |
| `UnparseableAuthHandles(FaultString)` | The callee committed but the returned auth-token handle list was malformed.                                                                                                                                                                           |
| `EncodingArgs(FaultString)`           | The caller’s arguments could not be encoded before dispatch.                                                                                                                                                                                          |

The first four variants mean the callee never ran: the invoke syscall was refused before any child frame opened, so the call was a complete no-op that observed nothing and wrote nothing. `CallError::is_rejected_before_call()` tests for exactly that set, which is the distinction to reach for when a retry or a fallback is only safe if the callee did not execute.



### Matching exceptions with `match_exn!`

An exception carries a selector derived from its type, independent of any interface’s `throws` list. `match_exn!` matches on that, so errors from different interfaces are peers:

```rust
match client.try_transfer(&recipient, 100) {
    Ok(()) => { /* transfer succeeded */ }
    Err(CallError::Fault(f)) => {
        // The callee panicked
    }
    Err(e) => match_exn!(e, {
        ERC20Error::MustBeContractOwner => {
            // Caller is not the owner
        }
        ERC20PausableError::EnforcedPause => {
            // Declared by an extension the ERC20 interface knows nothing
            // about, matched here exactly like a declared error
        }
        LibraryExn::NonNegativeIntUnderflow => {
            // SDK-level failure inside the callee
        }
        _ => e.re_throw(),
    }),
}
```

Handle `Ok`, `Fault`, `Invalid`, and encode/decode failures with an ordinary `match`. `match_exn!` only does typed downcasting, and its arms are tried in order, so it requires a final `_` arm.

Two rules follow from how the macro infers the type from each arm’s pattern:

- Every typed arm must be path-rooted (`Type::Variant`, `Type::Variant { .. }`, or a unit-struct `Type`). A bare identifier would be a binding, leaving nothing to infer the type from; `_` is the untyped escape hatch, and the error value is still in scope there.
- `|` cannot combine patterns of different exception types. Alternates within one type are fine.



### Matching a single type

When only one exception type matters, `try_as` skips the macro:

```rust
assert_eq!(
    client.try_transfer(&recipient, 100).unwrap_err().try_as(),
    Some(ERC20Error::MustBeContractOwner),
);
```

`None` covers all three ways this can miss: the failure carried no exception, it carried a different type, or the payload failed to decode.



### Telling a corrupt error from an unknown one

`try_as` returns `None` both for a selector belonging to another type and for a matching selector whose payload will not decode, and `match_exn!` sweeps both into `_`. `try_decode` separates them:

```rust
match client.try_call_something().unwrap_err().try_decode::<SomeKnownError>() {
    Some(Ok(err)) => { /* decoded */ }
    Some(Err(_)) => { /* right selector, payload did not decode */ }
    None => { /* no exception, or a different type */ }
}
```

A version change can cause this distinction. An exception’s selector uses the first 8 bytes of `sha256(major_version :: crate :: type)`, not the payload layout. Adding an enum variant leaves the selector unchanged, but an older caller cannot decode that new variant. Use `try_decode` if your contract must distinguish an unknown type from an undecodable payload of a known type.

The reverse direction is not detectable at all: decoding reads a *prefix*, so a callee that **appends a field** to a struct exception is accepted silently by an older caller, which decodes the shorter shape and drops the extra data.



### Raw inspection

`RawException` also exposes `selector()` and `payload()` for inspecting bytes directly, and `re_throw()` to propagate the original abort verbatim.



## Error Forwarding

When contract A calls contract B with a direct (non-try) call and B throws, the error propagates through A to A’s caller with the original selector and payload intact. This means callers further up the chain can still decode the original error.

```rust
fn forward_alpha(target: ContractAddress) {
    // If target throws AlphaError::NotFound, this contract
    // re-throws it unchanged. Our caller sees AlphaError::NotFound.
    MultiClient::new(&target).throw_alpha_not_found();
}
```



## Full Example

A contract that calls an ERC20 token contract:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

pub use thruput_erc20_if as erc20_if;

use erc20_if::Amount;
use erc20_if::ERC20Client;
use thruput_sdk::storage::Value;
use thruput_sdk::*;

#[storage]
pub struct Caller {
    token_contract: Value<ContractAddress>,
}

#[contract(client = CallerClient)]
impl Caller {
    pub fn initialize(&mut self, token_contract: &ContractAddress) {
        self.token_contract.set(token_contract);
    }

    pub fn check_balance(&self, account: &ContractAddress) -> Amount {
        let token = ERC20Client::new(&self.token_contract.get());
        token.get_balance_of(account)
    }
}
```

See [Handle errors](../pages/contracts/errors.md) for defining error types with `#[contract_exception]`.

---

## Invocation Frames

Source: <https://thruput.network/docs/how-it-works/invocation-frames/>

How contract calls track state, return results, and merge or discard child effects.

An invocation frame is the execution context for one contract call. A transaction begins with a root frame. A [cross-contract call](../pages/contracts/cross-contract-calls.md) creates a child frame and returns control to its parent when it finishes.

The same model applies to RV32 contracts and native system contracts.



## Frame Structure

| Part          | Contents                                                                          |
| ------------- | --------------------------------------------------------------------------------- |
| Call context  | Contract address, entrypoint, calldata, invocation flags, and gas budget          |
| State changes | Storage operations and deployments made by this frame and its successful children |
| Events        | Events emitted by this frame and its successful children                          |
| Child result  | Status and return bytes from the most recent child call                           |
| Resource use  | Gas consumed by this frame and its children                                       |

A transaction’s root invocation has no child-call flags. A child’s gas budget is capped by its parent’s remaining budget. See [Invocation configuration](../pages/contracts/cross-contract-calls.md) for SDK controls.



## Call Stack

```text
Root: wallet.execute
  Child: counter.increment
    Nested child: another contract method
```

Each child has its own execution context. Its ordinary reads use the block snapshot plus visible changes from the current transaction. A child call is part of that transaction, not a separate transaction or a separate block.



## Frame Lifecycle



### 1. Creation

The runtime creates a frame with the call context and an empty record of local changes and events.



### 2. Execution

Contract code uses [syscalls](../pages/reference/syscalls.md) to read state, record changes, emit events, and call other contracts. Child calls can create further frames.



### 3. Completion

| Result           | Return bytes                                  | Contract effects                      |
| ---------------- | --------------------------------------------- | ------------------------------------- |
| **Return** (`0`) | Returned to the caller                        | Preserved for merging into the parent |
| **Fault** (`1`)  | Empty                                         | Discarded                             |
| **Abort** (`2`)  | Returned to the caller, usually as error data | Discarded                             |

A fault can result from an invalid instruction, invalid memory access, or exhausted gas. An abort is an explicit revert. SDK-generated wrappers use the Return syscall with its revert flag to produce a return or abort. Gas consumed before either failure remains consumed; it is computation metering, not a token fee.



### 4. Merge into Parent (or Finalize for Root)

On a successful child return, its storage changes, deployments, and events become part of the parent frame. They have not committed to the ledger yet. On a child abort or fault, those effects are discarded.

In either case, the parent receives the child’s status and return buffer and accounts for its gas use. A recoverable SDK call lets the parent inspect the failure. A throwing call propagates an unhandled failure. See [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md#error-handling).

When the root returns successfully, the transaction’s changes must still pass reservation against the proposed block. A committed root abort or fault records the failure while discarding contract effects; protocol bookkeeping such as replay protection remains. See [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md#root-frame-completion).



### 5. Pop and Return

The runtime discards the completed frame’s guest memory, registers, and stack. Control returns to the parent, or execution ends for the root. Only state written through the storage APIs can persist beyond execution.



## Example: Nested Contract Calls

Suppose contract A calls B, C, and D using recoverable calls:

| Step                         | Outcome                                          | Changes retained by A |
| ---------------------------- | ------------------------------------------------ | --------------------- |
| A writes `AAA`               | A continues                                      | `AAA`                 |
| B writes `BBB` and returns   | Child effects merge                              | `AAA`, `BBB`          |
| C writes `CCC` and aborts    | Child effects are discarded; A handles the error | `AAA`, `BBB`          |
| D writes `DDD` and faults    | Child effects are discarded; A handles the fault | `AAA`, `BBB`          |
| A writes `FINAL` and returns | Root changes enter reservation                   | `AAA`, `BBB`, `FINAL` |

If the transaction is admitted and committed, the ledger contains `AAA`, `BBB`, and `FINAL`. C’s and D’s writes never commit. If A instead propagates either child failure, A’s contract effects are discarded too.



## Related Documentation

- [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md): SDK call and error-handling patterns
- [Authorization](../pages/how-it-works/authorization.md#passing-auth-tokens): Auth-token ownership across frames
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): Reservation and final outcomes
- [Contract artifacts and addresses](../pages/how-it-works/contracts.md): Code and deployment identities

---

## Testing

Source: <https://thruput.network/docs/programming-model/testing/>

How to test Project Thruput contracts: native logic tests, RV32 integration tests, setup, and error matching.



## Test Modes

Start with `cargo test` for native logic tests in process, then run `thruput test` against the RV32 artifact. Add `thruput test --integration` when you need to test the same path a partner or app will use: build artifact, local node, deployment, signing profile, RPC URL, and generated client behavior. [Build and test](../pages/cli/build-and-test.md#choose-a-test-boundary) compares the three modes and their command options.

Fresh projects include the integration target and host-only dependencies. The CLI can acquire a compatible catalog-pinned `hog-devnode`; use `thruput toolchain list` to inspect it. `THRUPUT_DEVNODE_BINARY` selects an explicit matching source build.



## What the Scaffold Gives You

Every new project (the default minimal contract, `--template counter`, and `--template counter-app`) includes:

```text
build.rs
tests/
  test.rs
  test_rv32.rs
  integration.rs
```

`tests/test.rs` holds native tests, and `tests/test_rv32.rs` runs under `thruput test`.

`tests/integration.rs` starts with one ignored RPC smoke test. It checks that the CLI provided a base58 contract address, connects to the ephemeral node with `thruput-json-rpc-client`, and calls `getChainTip`. Replace or extend the final placeholder with assertions for your contract.

The starter remains ignored under ordinary `cargo test`, even if you explicitly enable its feature. `thruput test --integration` enables the feature and sets `THRUPUT_INTEGRATION_TEST=1`, which lets the scaffold’s `build.rs` activate the live test. You can rename the module and test functions without changing how activation works.

The generated `thruput-integration-test` feature enables the optional RPC client and Tokio dependencies. Their target-specific Cargo entries keep them out of RV32 guest builds. Preserve the SDK and RPC versions selected together by the scaffold.

The generated `build.rs` contains:

```rust
fn main() {
    println!("cargo:rerun-if-env-changed=THRUPUT_INTEGRATION_TEST");
    println!("cargo:rustc-check-cfg=cfg(thruput_integration_runner)");

    if std::env::var("THRUPUT_INTEGRATION_TEST").as_deref() == Ok("1") {
        println!("cargo:rustc-cfg=thruput_integration_runner");
    }
}
```

> **tip: Projects created with an older scaffold**
>
> Compare with a fresh scaffold, then add `tests/integration.rs`, its feature and host-only dependencies, and the integration activation logic from `build.rs`. If your project already has a build script, merge the activation lines into its existing `main` function. The CLI exits with `integration_test_not_found` when the test target is absent.



## Test Setup

Your `lib.rs` must include `thruput_sdk::declare_mock_contract!()` to generate the `register_mock_contract` function used in tests:

```rust
#![cfg_attr(not(feature = "dev"), no_std)]

thruput_sdk::declare_mock_contract!();

mod implementation;
pub use implementation::*;
```



## Basic Pattern

```rust
use thruput_sdk::*;

use my_counter::{CounterClient, register_mock_contract};

static NONCE: SHA256Hash = thruput_sdk::sha256_static!("COUNTER_NONCE");

fn setup() -> (TestEnvironmentHandle, SHA256Hash) {
    let env = TestEnvironment::no_cost();
    let test_contract = register_mock_contract(&env);
    let contract_hash = *test_contract.as_hash();
    (env, contract_hash)
}

#[test]
fn test_counter() {
    let (env, contract_hash) = setup();

    env.transact(|tx| {
        let caller = ContractAddress::named("test_counter");
        tx.call(&caller).run(move || {
            let addr = deploy_contract(&NONCE, &contract_hash);
            let client = CounterClient::new(&addr);

            client.initialize(10);
            client.increment(5);
            assert_eq!(client.get(), 15);
        })
    })
    .assert_success();
}
```

Breaking this down:

1. **[`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost)** creates an in-process test environment with storage costs disabled.
2. **`register_mock_contract(&env)`** registers the contract with the test environment. This function is generated by `declare_mock_contract!()`.
3. **`*test_contract.as_hash()`** copies the contract hash for deployment.
4. **`env.transact(...)`** runs the closure as a single auto-committed transaction. `tx.call(&caller)` sets the address the transaction originates from, and `.run(closure)` executes the closure in a simulated execution context. The returned `TransactResult` records the outcome, return value, and emitted events. `.assert_success()` panics with details if the transaction did not commit.
5. **`deploy_contract`** deploys the contract and returns its address. The nonce makes the address deterministic.
6. **`CounterClient::new`** creates a typed client. Methods return values directly.



## `no_cost` vs `default`

Use [`TestEnvironment::no_cost()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.no_cost) for most contract logic tests. It disables storage cost enforcement, which keeps tests focused on method behavior, storage mutations, events, and expected exceptions.

Use [`TestEnvironment::default()`](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html#method.default) when the test should exercise the normal storage cost model. This is useful for storage-token behavior, deployment cost checks, or tests that should fail when the caller has not been funded correctly.

Use `TestEnvironment::new(Some(&model))` when the test is specifically about a custom `StorageCostModel`. Use `setup_grant_storage_tokens` to fund accounts in cost-sensitive tests.

For the full generated API, see the [`TestEnvironment` Rustdoc](https://crates.thruput.network/docs/sdk/0.41.1/doc/sdk/struct.TestEnvironment.html) or [Rust API Docs](../pages/tools/rust-api-docs.md).

When a native test needs a custom transaction context, start with `env.transaction()`. The builder currently supports replacing the default authorization claim:

```rust
let result = env
    .transaction()
    .with_auth_claim(auth_claim)
    .transact(|tx| tx.call(&caller).run(|| {
        // contract calls
    }));
```

Finish the builder with `transact` for auto-commit, `transact_manual` for explicit commit or abort control, or `build` to obtain a `MockTransactionHandler` directly. Plain `env.transact(...)` remains the shorthand for the default transaction configuration.

Use `thruput test --integration` when the thing under test is not just contract logic: local node startup, RV32 artifact deployment, profile resolution, signing, RPC environment variables, or generated off-chain client behavior.



## Testing Error Cases

Use `try_*` methods to verify that operations fail as expected:

```rust
// Inside tx.call(&caller).run(...), after client.initialize(5):
assert_eq!(
    client.try_decrement(10).unwrap_err().try_as(),
    Some(LibraryExn::NonNegativeIntUnderflow),
);
```

The `try_decrement` method (generated alongside `decrement` by the `#[contract]` macro) returns a `Result` instead of aborting. The error type is the SDK’s `CallError`, which is the same for every client: a caught exception stays undecoded inside it, and `try_as` decodes it as whichever exception type you name. When more than one type is of interest, `match_exn!` matches several in one place. See [Handle errors](../pages/contracts/errors.md) for the full error model.



## Blocks and Conflicts

Each `env.transact` call runs in the current block. Transactions in the same block read the previous block’s committed state and do not see each other’s writes. Call `env.advance_block()` to commit the block and make its effects visible. Use `env.advance_block_at(timepoint)` to pin the next block’s time for deadline and expiry tests.

Use same-block transactions to test merges and exclusion:

```rust
fn transfer(env: &TestEnvironmentHandle, from: ContractAddress, to: ContractAddress, amount: i128) -> TransactResult {
    env.transact(|tx| tx.call(&from).run(move || ERC20Client::new(&token()).transfer(&to, amount)))
}

// Alice holds 100. Both transfers run in the same block.
transfer(&env, alice(), bob(), 60).assert_success();
transfer(&env, alice(), carol(), 60).assert_commit_failed_nondeterministically();
env.advance_block();
```

`assert_commit_failed_nondeterministically()` means the root call succeeded but its deltas could not be reserved with the block’s other changes. On a network, that transaction is excluded and reported as `retry`. `TransactResult` also provides `assert_return_as::<T>()`, `assert_abort_as::<E>()`, `events()`, and `filter_events::<E>()`. See [`contracts/erc20/tests/same_block.rs`](https://github.com/thruputchain/thruput-examples/blob/main/contracts/erc20/tests/same_block.rs) for more same-block cases.



## Integration Test Environment

`thruput test --integration` runs `tests/integration.rs` against an ephemeral `hog-devnode`. The CLI builds and deploys the selected artifact, then sets:

| Variable                   | Value                                                                   |
| -------------------------- | ----------------------------------------------------------------------- |
| `THRUPUT_INTEGRATION_TEST` | `1`; activates the scaffolded live test                                 |
| `THRUPUT_RPC_URL`          | RPC URL for the ephemeral node                                          |
| `THRUPUT_CONTRACT_ADDRESS` | Deployed contract address                                               |
| `THRUPUT_PROFILE`          | `integration`                                                           |
| `THRUPUT_DEFAULT_KEY`      | `integration`, a temporary key the CLI creates and funds for this run   |
| `THRUPUT_RUNTIME_MANIFEST` | Runtime manifest path, when available                                   |
| `XDG_CONFIG_HOME`          | Temporary config directory that holds the `integration` key and profile |

The full run is:

1. Build the RV32 artifact.
2. Start an isolated local node.
3. Deploy it with a temporary `integration` key that the CLI generates and funds at node genesis.
4. Enable `thruput-integration-test` and run only the `integration` Cargo test target with the environment above.
5. Shut down the node after the test run, including after test failures.

Normal test-harness controls such as `--match-test`, `--skip`, `--fail-fast`, `--show-output`, `--no-capture`, and `--test-threads` apply to integration tests. `--watch`, `--rerun`, and `--workspace` cannot be combined with `--integration` yet.

Integration tests use the same RV32 artifact path as normal builds and deployments.



## Named Addresses

`ContractAddress::named("alice")` produces a deterministic address from a string. Same name always returns the same address. The method hashes the name with SHA-256 at runtime, so it cannot initialize a `static` or `const`. Bind it inside the test or a `LazyLock` instead:

```rust
#[test]
fn transfer_between_known_addresses() {
    let alice = ContractAddress::named("alice");
    let bob   = ContractAddress::named("bob");
    // ...
}
```

The `Named` trait that provides this method is re-exported through `thruput_sdk::*` when the `dev` feature is enabled.

---

## Debug a contract

Source: <https://thruput.network/docs/contracts/debugging/>

Isolate failures in native tests, RV32 artifact tests, and submitted transactions.

Start at the boundary that failed. A compiler error, a contract exception, and an uncertain network submission need different checks.



## Reproduce the logic

Use the smallest input that reproduces the problem:

```bash
RUST_BACKTRACE=1 cargo test test_counter -- --nocapture
```

Native tests provide Rust diagnostics and work with host debugging tools. Use generated `try_*` client methods to assert on expected errors.

Once the logic passes, run `thruput test` to check the RV32 artifact. A passing host test does not replace the artifact test.



## Inspect the build or artifact test

```bash
thruput --show-cargo-commands build
thruput test --match-test counter --show-output
```

Confirm the package, toolchain, and features. In a workspace, use `-p PACKAGE`. See [Build and test](../pages/cli/build-and-test.md).



## Classify a deployed failure

| Observation                                     | Next check                                                                                                                                                                                                                                                                |
| ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Submission rejected                             | Inspect the signing account, profile, network identity, and reported admission error                                                                                                                                                                                      |
| Committed exception                             | Decode the typed error; check input and authorization conditions                                                                                                                                                                                                          |
| Committed fault                                 | Reproduce in tests; inspect execution limits and panics                                                                                                                                                                                                                   |
| `pending`, `recentFailure`, or `unknown` status | Observe the original transaction on the same network                                                                                                                                                                                                                      |
| `retry` or `dropped` status                     | Read the reported error. A `retry` can succeed if you resubmit the same transaction. For a `dropped` transaction, change it before you resubmit, unless the error is insufficient native tokens: then fund the sender and resubmit the same transaction before it expires |
| Unexpected view result                          | Check address, interface/spec, read height, and simulated caller                                                                                                                                                                                                          |

```bash
thruput tx show TX_HASH --profile futurenet
```

See [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish) for outcomes and [CLI troubleshooting](../pages/cli/troubleshooting.md) for configuration checks.



## Reproduce through RPC

Start a local node with `thruput node --verbose` and retain its logs while reproducing the problem. CLI transaction inspection shows public status and receipt data, not a full execution trace.

For repeatable build, deployment, and RPC checks, use `thruput test --integration` and add contract-specific assertions to the generated test.

---

## Generate client bindings

Source: <https://thruput.network/docs/contracts/client-bindings/>

Deliver a contract's typed interface to TypeScript application developers.

Client bindings let an application use your contract’s methods, types, errors, and events. Generate them from the contract spec produced by the same build you deploy:

```bash
thruput build --bindings ts
```

The spec describes the exported interface. Bindings turn that description into TypeScript code for application developers.



## Keep the interface and deployment together

- Regenerate bindings when methods, argument or return types, errors, or events change.
- Give application developers the bindings and the matching deployment address and network.
- Keep generated files separate from application code so regeneration does not overwrite manual changes.

See [Generate TypeScript bindings](../pages/cli/codegen.md) for output paths and generation from an existing spec, and [Use contract bindings](../pages/tools/typescript-bindings.md) for consuming the generated interface in an application.

---

## Contract artifacts and addresses

Source: <https://thruput.network/docs/how-it-works/contracts/>

Understand compiled artifacts, code hashes, deployment addresses, and contract immutability.

An artifact is compiled contract code. Its code hash identifies that code; a deployment address identifies one instance with its own storage. The same artifact can be deployed at multiple addresses.

This page explains those identities and the rules of deployment. For deployment commands, see [Deploy and call](../pages/cli/deploy-and-call.md).

User contracts compile to RV32, Project Thruput’s 32-bit RISC-V contract target. Native system contracts serve separate purposes, described below.



## Contract Types



### RV32 Contracts

`thruput build` compiles the contract’s RV32 entrypoint wrapper for `riscv32im-unknown-none-elf`, lowers that ELF into a deployable `.rv32a` artifact, and finalizes its contract-spec sidecars.

For a crate named `counter`, the default build writes:

```txt
target/thruput/counter.rv32a
target/thruput/counter.rv32.json
target/thruput/counter.spec.xdr
target/thruput/counter.spec.json
```

The `.rv32a` file is the executable contract artifact. `thruput deploy` wraps those bytes in the protocol’s `Contract::kRv32` variant before signing and submitting the deploy transaction.

Deployment must satisfy the network’s limits on attached contract size, RV32 code, guest memory, and new contracts per transaction. Client and gateway submission limits also apply. Use the selected network’s configuration rather than assuming a fixed maximum.



#### Entrypoints

Every callable method is identified by an 8-byte `ContractEntrypointID`. The SDK’s `#[contract]` macro emits one dispatch record per method into the `thruput_rv32_entrypoints` link section.

When hogd invokes an RV32 contract, it enters the guest at `_start` with the method ID in registers. The RV32 runtime dispatches by scanning that section, then calls the generated wrapper for the matching method. That wrapper decodes calldata, calls the Rust method, and returns through the Return syscall.

Entrypoint IDs can be arbitrary 8-byte values at the protocol layer. The SDK derives them as the first 8 bytes of `SHA256("<interface>::<major>::<method>")`. See [SDK Macros](../pages/reference/sdk-macros.md) and the [contract spec reference](../pages/reference/contract-spec.md) for the developer-facing shape.



#### Artifact Shape

Most developers should let the [Thruput CLI](../pages/cli/build-and-test.md) produce RV32 artifacts. Under the hood, the RV32 lowerer:

- Parses the `riscv32im-unknown-none-elf` contract binary.
- Validates the layout expected by the Project Thruput RV32 runtime.
- Packs code, initial memory, metadata, and section digests into the `.rv32a` artifact.
- Self-verifies the artifact before writing it.

The node executes the lowered artifact through the RV32 runtime. Contract state does not live in guest memory. Durable state must be written through Project Thruput storage APIs.



### Native Precompiled Contracts

Native precompiled contracts are implemented directly inside the Project Thruput runtime. They are used for trusted system behavior, such as the native token contract, and can have permissions that user-deployed guest contracts do not have.

Users cannot deploy native contracts. Network configuration assigns system contract addresses; implementations are identified by values from `HogexecPrecompiledNativeContracts`.



## Contract Deployment

Contracts are deployed by the DeployContract [system call](../pages/reference/syscalls.md). In normal CLI usage, `thruput deploy` calls `deploy` on the signing account. For a pubkey account, that call runs the native DefaultWallet, which calls DeployContract with the artifact hash and deployment nonce.



### Contract Identification

Contracts are identified by the SHA256 hash of the XDR-encoded `Contract` union. For an RV32 artifact, the deploy hash is:

```txt
SHA256(XDR(Contract::kRv32 {
    rv32_contract: ContractBlob {
        data: <.rv32a artifact bytes>
    }
}))
```

This is not just the SHA256 hash of the raw `.rv32a` bytes. The XDR wrapper and `kRv32` type tag are part of the hash preimage.



### DeployContract Syscall

To deploy a contract, the caller invokes DeployContract with two arguments:

- `nonce`: a 32-byte value chosen by the caller
- `contract_hash`: the SHA256 hash identifying the contract artifact to deploy

The system then:

1. Verifies that the contract identified by `contract_hash` is available for deployment.
2. Computes the deployment address: `ContractAddress = SHA256(XDR(ContractDeploymentHashPreimage))`.
3. Writes the contract’s `DeployedContractHash` to the computed address’s `Metadata` key.
4. Stores the contract code separately in the deduplicated contract code store.



### Deterministic Address Derivation

The address to which a contract is deployed is computed from the deployer address, nonce, and contract hash. Anyone can predict the address before deployment.

A single contract artifact can be deployed at many addresses. Each deployment has separate metadata and separate storage.



### Deployment Preimage

```rust
pub struct ContractDeploymentHashPreimage {
    /// Address of the contract performing the deployment.
    pub deployer_address: ContractAddress,

    /// Arbitrary 32-byte nonce chosen by the deployer.
    pub nonce: SHA256Hash,

    /// SHA256 hash of the contract artifact.
    pub contract_hash: SHA256Hash,
}
```

Under XDR encoding, this structure serializes as the concatenation of its fields:

```txt
XDR(ContractDeploymentHashPreimage) = deployer_address || nonce || contract_hash
```



### Example

A wallet contract at address `0x1234...` deploys `counter.rv32a`:

```txt
deployer_address = 0x1234...
nonce            = 0x5678...
contract_hash    = SHA256(XDR(Contract::kRv32 {
                       rv32_contract: ContractBlob { data: bytes(counter.rv32a) }
                   }))
                 = 0xabcd...

ContractAddress  = SHA256(0x1234... || 0x5678... || 0xabcd...)
                 = 0x9999...
```

The deployed counter contract’s address is now `0x9999...`.

This scheme is analogous to Ethereum’s `CREATE2` opcode because the address can be calculated before deployment.



## Deployment Eligibility

To be deployed via DeployContract, a contract identified by `contract_hash` must be available in the context of the current transaction.

A contract is available if either of the following holds:

- The contract code already exists in the on-chain contract code store.
- The contract is included in the `contracts_to_deploy` field of the current transaction.

```rust
pub struct Transaction {
    pub invocation: Invocation,
    pub uniquifier: Uniquifier,

    /// New contract code to make available for deployment.
    pub contracts_to_deploy: VecM<Contract>,

    /// Authorization claim specifying required signatures.
    pub auth_claim: AuthClaim,
}
```

`contracts_to_deploy` makes contract code available, but it does not deploy the code to an address by itself. Deployment to a specific address happens when a contract invokes DeployContract.

Example flow:

1. The transaction includes `contracts_to_deploy: [Contract::kRv32 { rv32_contract: ContractBlob { data: <artifact bytes> } }]`.
2. The contract code becomes available under its `contract_hash`.
3. During execution, a contract calls `DeployContract(nonce, contract_hash)`.
4. The system computes the deployed address and writes its metadata.



## Address Metadata

When a contract is deployed, the system writes its `DeployedContractHash` to the storage key `(contract_address, StorageKeyType::Metadata)`.

```rust
pub struct DeployedContractHash {
    /// SHA256 hash of the contract code.
    pub hash: SHA256Hash,

    /// Size of the contract in bytes.
    pub contract_size: u32,

    /// Type of contract: kNative, kMockTest, or kRv32.
    pub contract_type: ContractType,
}
```

This metadata allows the executor and off-chain tools to:

- Verify what code is running at an address.
- Determine the contract type without loading bytecode.
- Calculate storage costs from the contract size.

The metadata is set during deployment and persists for the lifetime of the contract address.



## Deployment Concurrency

Multiple transactions may deploy the same contract to the same address in the same block. Project Thruput does not consider concurrent deployments of the same contract to the same address to be in conflict. Collision resistance of SHA256 implies that different contracts cannot be deployed to the same address.

If a contract requires one-time initialization, implement that guard in contract storage.



## Redeployment and Immutability

Once a contract is deployed to an address, that address’s `DeployedContractHash` cannot be changed. Deployed contracts are immutable.



## Related Documentation

- [Thruput CLI](../pages/cli.md): RV32 builds, local nodes, deployment, and codegen
- [Invocation Frames](../pages/how-it-works/invocation-frames.md): execution context and call stack management
- [Syscalls](../pages/reference/syscalls.md): system calls available to contracts
- [SDK Macros](../pages/reference/sdk-macros.md): SDK entrypoint IDs and generated clients
- [Contract Spec](../pages/reference/contract-spec.md): generated method, type, event, and error metadata
- [System Overview](../pages/how-it-works/architecture.md): the component map

---

## Rust API Docs

Source: <https://thruput.network/docs/tools/rust-api-docs/>

Find generated Rustdoc for the SDK or build documentation for your project's resolved dependencies.

Use Rustdoc for exact signatures, trait bounds, and source links. Use this site for contract tasks and the programming model.



## Match your project

The hosted links below select one SDK release. If your project’s dependency differs, select its version at [crates.thruput.network](https://crates.thruput.network) or build its resolved SDK documentation locally:

```bash
cargo doc -p thruput-sdk --no-deps --open
```

Run this from the generated contract project after [Cargo access setup](../pages/cli/install.md#configure-cargo-access). Hosted Rustdoc may require your onboarding credentials.



## Common Links

| Need                                         | Rustdoc                                                                                                                                                                                                                                                    |
| -------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| SDK overview and re-exports                  | [`thruput_sdk`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/index.html)                                                                                                                                                                         |
| Contract types                               | [`ContractAddress`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.ContractAddress.html), [`SHA256Hash`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/types/struct.SHA256Hash.html)                                         |
| Native tests                                 | [`TestEnvironment`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/struct.TestEnvironment.html)                                                                                                                                                    |
| Storage types and traits                     | [`thruput_sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html)                                                                                                                                                        |
| Nonnegative balances and counters            | [`Balance`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/balance/struct.Balance.html)                                                                                                                                                    |
| Lower-level signed deltas and explicit bases | [`NNInt`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/nnint/struct.NNInt.html)                                                                                                                                                          |
| Shared capacity                              | [`CapacityConstraint`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/capacity_constraint/struct.CapacityConstraint.html)                                                                                                                  |
| Keyed and indexed storage                    | [`Map`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/map/struct.Map.html), [`Vector`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/vector/struct.Vector.html)                                                          |
| Typed and raw values                         | [`Value`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/value/struct.Value.html), [`Bytestring`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/bytestring/struct.Bytestring.html)                                        |
| Queues and nested state                      | [`RCQ`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/rcq/struct.RCQ.html), [`Node`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/node/struct.Node.html)                                                                |
| Contract and storage macros                  | [`#[contract]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract.html), [`#[storage]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.storage.html)                                                                       |
| Error macro                                  | [`#[contract_exception]`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/attr.contract_exception.html)                                                                                                                                             |
| Events                                       | [`Event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/derive.Event.html), [`log_event`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/event/fn.log_event.html)                                                                         |
| Error helpers                                | [`throw`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.throw.html), [`ensure`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/fn.ensure.html), [`OrThrow`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/trait.OrThrow.html) |
| Deployment                                   | [`deploy_contract`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/deploy/fn.deploy_contract.html)                                                                                                                                                 |
| Mock registration                            | [`declare_mock_contract!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.declare_mock_contract.html)                                                                                                                                        |
| Compile-time hashes                          | [`sha256_static!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.sha256_static.html), [`hash_ident!`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/macro.hash_ident.html)                                                         |



## How to Use These Docs

- Start with [Testing](../pages/programming-model/testing.md) to choose native, artifact, or RPC tests.
- Use [storage API tables](../pages/reference/storage-types.md) for common operations and [storage guidance](../pages/programming-model/storage-types.md) to choose a type.
- Use [SDK Macros](../pages/reference/sdk-macros.md) for parameters and generated items.
- Follow Rustdoc source links when you need the implementation behind an API.

---

## Storage Types

Source: <https://thruput.network/docs/reference/storage-types/>

API reference for Project Thruput storage types.

| Area                                  | Links                                                                                                                                                 |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| Type choice and conflict semantics    | [Storage guidance](../pages/programming-model/storage-types.md)                                                                                       |
| Generated type, guard, and trait APIs | [`thruput_sdk::storage`](https://crates.thruput.network/docs/sdk/0.42.2/doc/sdk/storage/index.html), [Rust API Docs](../pages/tools/rust-api-docs.md) |
| Encoding                              | CXS; serialization traits retain the names `ReadXDR` and `WriteXDR`                                                                                   |



## Balance

| Property        | Value                                                                                                                              |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| Representation  | `i128`, backed by NNInt                                                                                                            |
| Range           | `0..=i128::MAX`; `Balance::MAX` is `i128::MAX`                                                                                     |
| Missing value   | Zero                                                                                                                               |
| Negative amount | Rejected with `NonNegativeIntUnderflow`                                                                                            |
| Operations      | No absolute `set` or signed adjustment                                                                                             |
| Traits          | `Deletable`                                                                                                                        |
| Usage           | [Balance guidance](../pages/programming-model/storage-types.md#balance), [Counter tutorial](../pages/tutorials/build-a-counter.md) |

| Method              | Signature                                                                 | Description                                                                                                   |
| ------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> i128`                                                   | Read the balance. A never-written location returns zero.                                                      |
| `try_get`           | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read without aborting. A never-written location returns `Ok(0)`.                                              |
| `increase`          | `fn increase(&mut self, amount: i128)`                                    | Load and increase the balance. Aborts immediately on overflow.                                                |
| `try_increase`      | `fn try_increase(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked increase that leaves storage unmodified on `Err`.                                                     |
| `decrease`          | `fn decrease(&mut self, amount: i128)`                                    | Load and decrease the balance. Aborts immediately if funds are insufficient.                                  |
| `try_decrease`      | `fn try_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>`      | Checked decrease that leaves storage unmodified on `Err`.                                                     |
| `lazy_increase`     | `fn lazy_increase(&mut self, amount: i128)`                               | Record an increase without loading the committed balance. Aggregate overflow is checked during reservation.   |
| `try_lazy_increase` | `fn try_lazy_increase(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta overflow.                                                       |
| `lazy_decrease`     | `fn lazy_decrease(&mut self, amount: i128)`                               | Record a decrease without loading the committed balance. Aggregate sufficiency is checked during reservation. |
| `try_lazy_decrease` | `fn try_lazy_decrease(&mut self, amount: i128) -> Result<(), LibraryExn>` | Report a negative amount or accumulated-delta underflow.                                                      |



## NNInt

| Property         | Value                                                                                                                                                           |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Data model       | Signed changes, explicit `set`, and a commit-time floor                                                                                                         |
| Decrement        | Negative `inc` or `strict_inc` argument                                                                                                                         |
| Exclusive writes | Handle from `Map::at_mut_exclusive`, `delete_exclusive`, or `non_negative_int_set_exclusive` in `thruput_sdk::sys_exn::nnint`; no handle `set_exclusive` method |
| Traits           | `Deletable`                                                                                                                                                     |
| Usage            | [Merged deltas](../pages/programming-model/execution.md#merged-deltas), [NNInt and concurrent updates](../pages/programming-model/nnint.md)                     |

| Method           | Signature                                                                 | Description                                                                                                                     |
| ---------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `get`            | `fn get(&self) -> i128`                                                   | Read current value. Aborts if the location has never been set.                                                                  |
| `try_get`        | `fn try_get(&self) -> Result<i128, LibraryExn>`                           | Read current value without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.                      |
| `set`            | `fn set(&mut self, set_value: i128)`                                      | Set the value. Uses the keypath’s locking mode.                                                                                 |
| `inc`            | `fn inc(&mut self, increment: i128)`                                      | Add `increment` without forcing a snapshot read. Underflow is caught by later runtime checks, not immediately.                  |
| `strict_inc`     | `fn strict_inc(&mut self, increment: i128)`                               | Add `increment`, loading the current base for early underflow detection. Aborts immediately if the result would be negative.    |
| `try_strict_inc` | `fn try_strict_inc(&mut self, increment: i128) -> Result<(), LibraryExn>` | Checked increment that reports overflow, underflow, or storage failure instead of aborting. Leaves storage unmodified on `Err`. |



## CapacityConstraint

| Property | Value                                                         |
| -------- | ------------------------------------------------------------- |
| Purpose  | Commit-time capacity for a contract-defined linear constraint |
| Flush    | Staged changes are written on flush or drop                   |
| Traits   | `Deletable`                                                   |

| Method                       | Signature                                                                    | Description                                                                                                                |
| ---------------------------- | ---------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `get_remaining_capacity`     | `fn get_remaining_capacity(&self) -> i128`                                   | Return the committed capacity plus changes staged in this transaction and handle. A never-written location starts at zero. |
| `try_get_remaining_capacity` | `fn try_get_remaining_capacity(&self) -> Result<i128, LibraryExn>`           | Read remaining capacity without aborting.                                                                                  |
| `consume_capacity`           | `fn consume_capacity(&mut self, amount: i128)`                               | Stage consumption for commit-time enforcement. A negative amount releases capacity.                                        |
| `try_consume_capacity`       | `fn try_consume_capacity(&mut self, amount: i128) -> Result<(), LibraryExn>` | Stage consumption and report arithmetic overflow instead of aborting.                                                      |
| `set_capacity`               | `fn set_capacity(&mut self, capacity: i128)`                                 | Set the capacity. Must be the first write in the transaction, except for an idempotent repeat.                             |
| `try_set_capacity`           | `fn try_set_capacity(&mut self, capacity: i128) -> Result<(), LibraryExn>`   | Set capacity and report invalid write ordering instead of aborting.                                                        |
| `flush`                      | `fn flush(&mut self)`                                                        | Merge staged changes into pending storage immediately.                                                                     |
| `try_flush`                  | `fn try_flush(&mut self) -> Result<(), LibraryExn>`                          | Flush staged changes and report failure. On error, changes remain staged and drop retries the flush.                       |



## Map\<K, V>

| Property        | Value                                                             |
| --------------- | ----------------------------------------------------------------- |
| Bounds          | `K: WriteXDR`, `V: StorageType`                                   |
| Enumeration     | Not supported; no `keys()` or iterator                            |
| Deletion        | Does not implement `Deletable`                                    |
| Disjoint access | Compares derived keypaths, not `PartialEq`; duplicate slots panic |

| Method                      | Signature                                                                                                      | Description                                                                                                                                   |
| --------------------------- | -------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `at`                        | `fn at(&self, entry_key: &K) -> SlotRef<'_, Self, V>`                                                          | Read-only borrow of the value at `entry_key`. Returns a `SlotRef` that derefs to `V`.                                                         |
| `at_mut`                    | `fn at_mut(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                                  | Mutable borrow of the value at `entry_key`. Returns a `SlotMut` that derefs to `V`.                                                           |
| `at_mut_exclusive`          | `fn at_mut_exclusive(&mut self, entry_key: &K) -> SlotMut<'_, Self, V>`                                        | Mutable borrow with an exclusive lock. One writer per key per block. Later writes to the entry in the same transaction keep the lock request. |
| `at_disjoint_mut`           | `fn at_disjoint_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>`                  | Mutably borrow N elements at once. Panics if any keys are equal.                                                                              |
| `at_disjoint_unchecked_mut` | `unsafe fn at_disjoint_unchecked_mut<const N: usize>(&mut self, keys: [&K; N]) -> DisjointMut<'_, Self, V, N>` | Mutably borrow N elements without duplicate checking. Caller must ensure all keys are disjoint.                                               |
| `keypath`                   | `fn keypath(&self) -> &Keypath`                                                                                | Reference to the map’s root keypath.                                                                                                          |



### DisjointMut\<Owner, S, N>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `at_disjoint_mut`                                              |
| Borrow   | Exclusive borrow of the parent map                             |
| Traits   | `Deref<Target = [S; N]>`, `DerefMut`; supports direct indexing |



## Vector\<S>

| Property       | Value                                                                                                    |
| -------------- | -------------------------------------------------------------------------------------------------------- |
| Representation | `Map<u32, S>` and a separate length; `S: StorageType`                                                    |
| Sparse slots   | Deleting element storage does not shrink `len`; an in-bounds slot can be missing                         |
| Iterators      | `Iterator`, `ExactSizeIterator`, `DoubleEndedIterator`; `IntoIterator` for shared and mutable references |
| Deletion       | `Deletable` when `S: Deletable`; deletes elements, then length                                           |

| Method            | Signature                                                      | Description                                                                                                                  |
| ----------------- | -------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `len`             | `fn len(&self) -> u32`                                         | Current logical length. Returns 0 if never set.                                                                              |
| `is_empty`        | `fn is_empty(&self) -> bool`                                   | True if `len() == 0`.                                                                                                        |
| `at`              | `fn at(&self, index: u32) -> SlotRef<'_, Self, S>`             | Read-only borrow at `index`. Bounds-checked.                                                                                 |
| `at_mut`          | `fn at_mut(&mut self, index: u32) -> SlotMut<'_, Self, S>`     | Mutable borrow at `index`. Bounds-checked.                                                                                   |
| `push_empty_slot` | `fn push_empty_slot(&mut self) -> SlotMut<'_, Self, S>`        | Increment `len` and return a mutable handle to the new slot. Marked `#[must_use]`.                                           |
| `push_with`       | `fn push_with<R>(&mut self, f: impl FnOnce(&mut S) -> R) -> R` | Initialize a new slot through the closure `f`, then increment `len`. If `f` traps, neither the data nor `len` are committed. |
| `pop`             | `fn pop(&mut self)`                                            | Delete the last element and decrement `len`. Aborts if empty. Requires `S: Deletable`.                                       |
| `iter`            | `fn iter(&self) -> VectorIter<'_, S>`                          | Read-only iterator. Yields `SlotRef` handles. Shared borrow prevents structural modifications.                               |
| `iter_mut`        | `fn iter_mut(&mut self) -> VectorIterMut<'_, S>`               | Mutable iterator. Yields `SlotMut` handles. Exclusive borrow on the vector.                                                  |
| `keypath`         | `fn keypath(&self) -> &Keypath`                                | Reference to the vector’s root keypath.                                                                                      |



## Value\<T>

| Property | Value                                            |
| -------- | ------------------------------------------------ |
| Data     | One serialized typed value                       |
| Bounds   | `T: WriteXDR` for writes, `T: ReadXDR` for reads |
| Traits   | `Deletable`                                      |

| Method              | Signature                                                              | Description                                                                                                   |
| ------------------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `get`               | `fn get(&self) -> T`                                                   | Deserialize and return the stored value. Aborts if the key does not exist.                                    |
| `try_get`           | `fn try_get(&self) -> Result<T, LibraryExn>`                           | Deserialize without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`.           |
| `set`               | `fn set(&mut self, value: &T)`                                         | Serialize and store the value. Uses the keypath’s locking mode.                                               |
| `try_set`           | `fn try_set(&mut self, value: &T) -> Result<(), LibraryExn>`           | Serialize and store without aborting. Leaves storage unmodified on `Err`.                                     |
| `set_exclusive`     | `fn set_exclusive(&mut self, value: &T)`                               | Serialize and store the value with an exclusive lock, regardless of keypath flag.                             |
| `try_set_exclusive` | `fn try_set_exclusive(&mut self, value: &T) -> Result<(), LibraryExn>` | Exclusive store that reports failure instead of aborting.                                                     |
| `load_mut`          | `fn load_mut(&mut self) -> ValueMut<'_, T>`                            | Load the value and return a mutable guard. Flushes back to storage on drop. Requires `T: WriteXDR + ReadXDR`. |
| `key`               | `fn key(&self) -> &StorageKey`                                         | Reference to the value’s resolved storage key.                                                                |



### ValueMut\<T>

| Property | Value                                                          |
| -------- | -------------------------------------------------------------- |
| Origin   | `load_mut`                                                     |
| Traits   | `Deref<Target = T>`, `DerefMut`                                |
| Drop     | Writes back after mutable access; a clean guard does not write |

| Method      | Signature                                           | Description                                                                                            |
| ----------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `flush`     | `fn flush(&mut self)`                               | Write a dirty value immediately. A clean guard is a no-op.                                             |
| `try_flush` | `fn try_flush(&mut self) -> Result<(), LibraryExn>` | Flush and report serialization or storage failure. On error, the guard remains dirty and drop retries. |



## Bytestring

| Property         | Value                                                                                                                                                          |
| ---------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Data             | Raw bytes                                                                                                                                                      |
| Exclusive writes | Handle from `Map::at_mut_exclusive`, `delete_exclusive`, or `bytestring_set_exclusive` in `thruput_sdk::sys_exn::bytestring`; no handle `set_exclusive` method |
| Traits           | `Deletable`                                                                                                                                                    |

| Method      | Signature                                            | Description                                                                                  |
| ----------- | ---------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `len`       | `fn len(&self) -> usize`                             | Length in bytes.                                                                             |
| `is_empty`  | `fn is_empty(&self) -> bool`                         | True if length is zero.                                                                      |
| `exists`    | `fn exists(&self) -> bool`                           | True if a bytestring exists. Returns false for a missing key.                                |
| `get`       | `fn get(&self) -> Box<[u8]>`                         | Read stored bytes as a heap-allocated slice.                                                 |
| `try_get`   | `fn try_get(&self) -> Result<Box<[u8]>, LibraryExn>` | Read without aborting. Missing storage is an `Err` identifiable with `is_storage_missing()`. |
| `get_sized` | `fn get_sized<const N: usize>(&self) -> [u8; N]`     | Read into a fixed-size array. Aborts if length does not match `N`.                           |
| `set`       | `fn set(&mut self, buf: &[u8])`                      | Write bytes. Exclusive when the handle came from `Map::at_mut_exclusive`.                    |



## RCQ\<T>

| Property    | Value                                                                                               |
| ----------- | --------------------------------------------------------------------------------------------------- |
| Data        | CXS-encoded `T`; multi-producer queue                                                               |
| Concurrency | Inserts merge, up to 250 entries per queue per block; one consuming transaction per queue per block |
| Traits      | `StorageType`, `Deletable`                                                                          |
| Modules     | Typed wrapper in `thruput_sdk::storage`; raw-key functions in `thruput_sdk::sys_exn::rcq`           |

| Method              | Signature                                                                        | Description                                                                                        |
| ------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `insert`            | `fn insert(&mut self, entry: &T)` where `T: WriteXDR`                            | CXS-encode and insert the entry.                                                                   |
| `insert_raw`        | `fn insert_raw(&mut self, queue_entry: &[u8])`                                   | Insert raw bytes; bypasses CXS encoding.                                                           |
| `consume`           | `fn consume(&mut self) -> T` where `T: ReadXDROwned`                             | Consume the next entry and decode it. Aborts if the queue is empty or the entry cannot be decoded. |
| `try_consume`       | `fn try_consume(&mut self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`     | Consume and decode without aborting. A decode failure leaves the entry in the queue.               |
| `consume_raw`       | `fn consume_raw(&mut self) -> Box<[u8]>`                                         | Consume the next entry as raw bytes. Aborts if the queue is empty.                                 |
| `try_consume_raw`   | `fn try_consume_raw(&mut self) -> Result<Box<[u8]>, LibraryExn>`                 | Consume raw bytes without aborting.                                                                |
| `consume_sized`     | `fn consume_sized<const N: usize>(&mut self) -> [u8; N]`                         | Consume into a fixed-size array. Aborts on size mismatch.                                          |
| `try_consume_sized` | `fn try_consume_sized<const N: usize>(&mut self) -> Result<[u8; N], LibraryExn>` | Consume without aborting. A wrong-size entry is left in the queue.                                 |
| `peek`              | `fn peek(&self) -> T` where `T: ReadXDROwned`                                    | Read the next entry without consuming. Aborts if empty.                                            |
| `try_peek`          | `fn try_peek(&self) -> Result<T, LibraryExn>` where `T: ReadXDROwned`            | Read and decode without aborting or consuming.                                                     |
| `peek_raw`          | `fn peek_raw(&self) -> Box<[u8]>`                                                | Raw-bytes peek. Aborts if empty.                                                                   |
| `try_peek_raw`      | `fn try_peek_raw(&self) -> Result<Box<[u8]>, LibraryExn>`                        | Raw-bytes peek without aborting.                                                                   |
| `peek_sized`        | `fn peek_sized<const N: usize>(&self) -> [u8; N]`                                | Fixed-size peek. Aborts on size mismatch.                                                          |
| `try_peek_sized`    | `fn try_peek_sized<const N: usize>(&self) -> Result<[u8; N], LibraryExn>`        | Fixed-size peek without aborting.                                                                  |
| `key`               | `fn key(&self) -> &StorageKey`                                                   | Reference to the queue’s resolved storage key.                                                     |



### Lower-level free functions (`thruput_sdk::sys_exn::rcq`)

| Function                              | Signature                                                                                                 | Description                                                         |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `retrocausal_queue_insert`            | `fn retrocausal_queue_insert(key: &StorageKey, queue_entry: &[u8])`                                       | Insert raw bytes.                                                   |
| `retrocausal_queue_consume_sized`     | `fn retrocausal_queue_consume_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                         | Consume a fixed-size entry. Aborts on size mismatch or empty queue. |
| `retrocausal_queue_try_consume_sized` | `fn retrocausal_queue_try_consume_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>` | Consume a fixed-size entry without aborting.                        |
| `retrocausal_queue_peek_sized`        | `fn retrocausal_queue_peek_sized<const N: usize>(key: &StorageKey) -> [u8; N]`                            | Peek a fixed-size entry.                                            |
| `retrocausal_queue_try_peek_sized`    | `fn retrocausal_queue_try_peek_sized<const N: usize>(key: &StorageKey) -> Result<[u8; N], LibraryExn>`    | Peek a fixed-size entry without aborting.                           |
| `retrocausal_queue_consume`           | `fn retrocausal_queue_consume(key: &StorageKey) -> Box<[u8]>`                                             | Consume a raw entry.                                                |
| `retrocausal_queue_try_consume`       | `fn retrocausal_queue_try_consume(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                     | Consume a raw entry without aborting.                               |
| `retrocausal_queue_peek`              | `fn retrocausal_queue_peek(key: &StorageKey) -> Box<[u8]>`                                                | Peek a raw entry.                                                   |
| `retrocausal_queue_try_peek`          | `fn retrocausal_queue_try_peek(key: &StorageKey) -> Result<Box<[u8]>, LibraryExn>`                        | Peek a raw entry without aborting.                                  |



## Slot Types

| Type                    | Implements                       | Description                                              |
| ----------------------- | -------------------------------- | -------------------------------------------------------- |
| `SlotRef<'a, Owner, S>` | `Deref<Target = S>`              | Read-only handle. Holds a shared borrow on the parent.   |
| `SlotMut<'a, Owner, S>` | `Deref<Target = S>` + `DerefMut` | Mutable handle. Holds an exclusive borrow on the parent. |

| Access                | Lifetime                  | Syntax                                    |
| --------------------- | ------------------------- | ----------------------------------------- |
| Map or vector element | Tied to parent collection | `*slot` or direct field access; no unwrap |



## Node\<T>

| Property           | Value                                                       |
| ------------------ | ----------------------------------------------------------- |
| Data               | Compound storage field group; does not keep its own keypath |
| Bound              | `T: From<Keypath>`                                          |
| Access             | `Deref<Target = T>`, `DerefMut`                             |
| Collection support | Implements `StorageType` for use in maps and vectors        |
| Deletion           | `Deletable` when `T: Deletable`; delegates to inner fields  |



## Deletable Trait

| Implementor                                                     | Behavior                                               |
| --------------------------------------------------------------- | ------------------------------------------------------ |
| `Balance`, `NNInt`, `CapacityConstraint`, `Value`, `Bytestring` | Delete one key                                         |
| `Node`, `Vector`                                                | Delete recursively when elements implement `Deletable` |
| `Map`                                                           | Not implemented; entries cannot be enumerated          |

| Method             | Signature                        | Description                                                |
| ------------------ | -------------------------------- | ---------------------------------------------------------- |
| `delete`           | `fn delete(&mut self)`           | Delete using the keypath’s own locking semantics.          |
| `delete_exclusive` | `fn delete_exclusive(&mut self)` | Delete with an exclusive lock, regardless of keypath flag. |



## Flaggable Trait

| Property     | Value                                                |
| ------------ | ---------------------------------------------------- |
| Implementors | `Value`, `NNInt`, `Balance`, `Bytestring`            |
| Scope        | Current transaction’s requested flags for a leaf key |
| Type         | `StorageFlags` aliases `StorageDeltaFlags`           |
| Flag         | `ExclusiveLock`                                      |

| Method        | Signature                                      | Description                                                                                      |
| ------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| `flags`       | `fn flags(&self) -> StorageFlags`              | The key’s flags as seen by the current call frame. `None` if the key has no pending write.       |
| `set_flags`   | `fn set_flags(&mut self, flags: StorageFlags)` | Add `flags` (bitwise OR). Throws unless a write to the key is pending in the current call frame. |
| `clear_flags` | `fn clear_flags(&mut self)`                    | Remove every flag. Does nothing if the key has no pending write.                                 |



### Raw-key functions

| Function              | Signature                                                          | Description                                                    |
| --------------------- | ------------------------------------------------------------------ | -------------------------------------------------------------- |
| `storage_flags`       | `fn storage_flags(key: &StorageKey) -> StorageDeltaFlags`          | Read the key’s flags.                                          |
| `set_storage_flags`   | `fn set_storage_flags(key: &StorageKey, flags: StorageDeltaFlags)` | Add flags. Throws if no write is pending or a flag is unknown. |
| `clear_storage_flags` | `fn clear_storage_flags(key: &StorageKey)`                         | Remove every flag.                                             |

| Module                           | Behavior                                                                   |
| -------------------------------- | -------------------------------------------------------------------------- |
| `thruput_sdk::sys_exn::flags`    | Throwing versions, re-exported at crate root                               |
| `thruput_sdk::sys_result::flags` | Non-throwing versions returning `Result`                                   |
| Usage                            | [Lock requests](../pages/programming-model/storage-types.md#lock-requests) |

---

## SDK Macros

Source: <https://thruput.network/docs/reference/sdk-macros/>

Macro targets, parameters, generated APIs, and constraints for the Rust SDK.

| Task                          | Guide                                                              |
| ----------------------------- | ------------------------------------------------------------------ |
| Define state and methods      | [Methods and interfaces](../pages/contracts/methods.md)            |
| Choose storage                | [Storage types](../pages/programming-model/storage-types.md)       |
| Declare and handle failures   | [Handle errors](../pages/contracts/errors.md)                      |
| Call another contract         | [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md) |
| Define, emit, and test events | [Events](../pages/contracts/events.md)                             |
| Register a test contract      | [Testing](../pages/programming-model/testing.md)                   |
| Find complete generated APIs  | [Rust API Docs](../pages/tools/rust-api-docs.md)                   |



## `#[contract]`



### Applies to

| Target                  | Generates                                               |
| ----------------------- | ------------------------------------------------------- |
| Trait definition        | Client struct and interface metadata                    |
| Trait implementation    | Export functions and mock registration                  |
| Inherent implementation | Export functions, client struct, and interface metadata |
| Free function           | Export function, no client                              |



### Parameters

| Parameter                                    | Default                 | Meaning                                                                                |
| -------------------------------------------- | ----------------------- | -------------------------------------------------------------------------------------- |
| `throws = Error` or `throws(ErrorA, ErrorB)` | None                    | Error types recorded in the spec; does not restrict which exceptions callers can catch |
| `emits(EventA, EventB)`                      | None                    | Event types recorded in the spec                                                       |
| `client = ClientName`                        | `{Interface}Client`     | Generated client name                                                                  |
| `interface = "Name"`                         | Trait or self-type name | Interface identity used for entrypoints                                                |
| `version = "0.1.0"`                          | `CARGO_PKG_VERSION`     | Version used for entrypoint identity                                                   |
| `exports = "name"`                           | Generated               | Internal exports module name                                                           |



### `throws` rules

| Constraint | Rule                                                                                       |
| ---------- | ------------------------------------------------------------------------------------------ |
| Placement  | Trait definition or inherent implementation; rejected on trait implementations             |
| Duplicates | The same type cannot be listed twice; different paths with the same final name are allowed |
| Runtime    | A known exception can be caught whether or not it is declared in `throws`                  |



### `emits` rules

| Constraint       | Rule                                                                                                    |
| ---------------- | ------------------------------------------------------------------------------------------------------- |
| Placement        | Trait definition or inherent implementation; rejected on trait implementations                          |
| Type             | Must implement `Event`                                                                                  |
| Spec             | Records name, signature, topics, and payload layout                                                     |
| Undeclared event | May be emitted; use `#[event_spec(export)]` to include a library event without an interface declaration |



### Generated client

| Method                                           | Behavior                                                                                |
| ------------------------------------------------ | --------------------------------------------------------------------------------------- |
| `ClientName::new(&ContractAddress)`              | Construct a client                                                                      |
| `with_gas_limit(&self, u64) -> Self`             | Return a configured copy with a child gas cap                                           |
| `with_commit_locking(&self) -> Self`             | Request commit locks before the child returns                                           |
| `with_read_only(&self) -> Self`                  | Reject child state changes                                                              |
| `method(&self, ...) -> T`                        | Return the value or propagate failure                                                   |
| `try_method(&self, ...) -> Result<T, CallError>` | Return the value or an inspectable failure                                              |
| Reserved names                                   | `new`, `with_gas_limit`, `with_commit_locking`, `with_read_only`, and the `try_` prefix |



### Inspecting errors

| API                 | Purpose                                                                                                  |
| ------------------- | -------------------------------------------------------------------------------------------------------- |
| `match_exn!`        | Match typed exceptions; requires a final `_` arm                                                         |
| `try_as::<E>()`     | Decode one known exception type; returns `None` for a different type or failed decoding                  |
| `try_decode::<E>()` | Distinguish unknown type from malformed payload                                                          |
| Usage               | [Error matching examples](../pages/contracts/cross-contract-calls.md#matching-exceptions-with-match_exn) |



### Method behavior

| Method                      | Behavior                                                                                    |
| --------------------------- | ------------------------------------------------------------------------------------------- |
| Public inherent method      | Exported                                                                                    |
| Private inherent method     | Internal helper                                                                             |
| Trait implementation method | Exported                                                                                    |
| Storage receiver            | Uses generated storage handles; see [Methods and interfaces](../pages/contracts/methods.md) |



## `#[contract_exception]`

| Property            | Value                                                                  |
| ------------------- | ---------------------------------------------------------------------- |
| Targets             | Structs and enums; no generics                                         |
| Generated derives   | `Debug`, `PartialEq`, `ReadXDR`, `WriteXDR`, `ContractTypeSpec`        |
| Generated traits    | `Exn` and `ContractTypeName`                                           |
| Enum representation | Adds `#[repr(i32)]`; variants require explicit discriminants           |
| `version = "0.1.0"` | Override `CARGO_PKG_VERSION` for identity                              |
| `name = "Name"`     | Override the Rust type name for identity                               |
| `Clone`             | Add the derive explicitly if needed                                    |
| Examples            | [Enum and struct errors](../pages/contracts/errors.md#defining-errors) |



### Selector computation

| Component       | Rule                                                                                                                                                                                           |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Selector        | First 8 bytes of `sha256(MAJOR_VERSION :: CRATE_NAME :: TYPE_NAME)`                                                                                                                            |
| `MAJOR_VERSION` | Leftmost nonzero version component: `1.2.3` → `1`, `0.9.2` → `0.9`, `0.0.2` → `0.0.2`                                                                                                          |
| `CRATE_NAME`    | `CARGO_PKG_NAME`                                                                                                                                                                               |
| `TYPE_NAME`     | Type name or explicit `name`                                                                                                                                                                   |
| Compatibility   | Stable selector does not guarantee an older caller can decode every new payload; see [decoding errors](../pages/contracts/cross-contract-calls.md#telling-a-corrupt-error-from-an-unknown-one) |



## `#[exn]`

| Property                   | Value                                                                             |
| -------------------------- | --------------------------------------------------------------------------------- |
| Purpose                    | Low-level `Exn` implementation with computed selector                             |
| Derives and representation | Supplied by the author; prefer `#[contract_exception]` for normal contract errors |
| `version`                  | Optional selector-version override                                                |



## `#[storage]` / `#[derive(Storage)]`

| Property    | Value                                                                     |
| ----------- | ------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                      |
| Output      | `From<Keypath>` implementation assigning each field a subpath             |
| Fields      | Storage handles; wrap plain data in `Value<T>`                            |
| Collections | Use `Node<T>` to place a compound storage struct inside `Map` or `Vector` |
| Usage       | [Storage types](../pages/programming-model/storage-types.md)              |



## `#[derive(Deletable)]`

| Property    | Value                                                                               |
| ----------- | ----------------------------------------------------------------------------------- |
| Targets     | Named-field structs and unit structs                                                |
| Requirement | Every field must implement `Deletable`; `Map` does not                              |
| Output      | Calls each field’s `delete_internal()`; exposes `delete()` and `delete_exclusive()` |



## `#[derive(Event)]`

| Property                     | Value                                                                                                           |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Target                       | Named-field struct                                                                                              |
| `#[topic]`                   | Mark an indexed field; at most two fields, in addition to the signature at topic 0                              |
| Direct topics                | `ContractAddress`, `SHA256Hash`, `[u8; 32]`, `U256`, `I256`, `u32`, `u64`, `u128`, `i32`, `i64`, `i128`, `bool` |
| Integer topics               | Fixed 32-byte big-endian encoding with zero or sign extension                                                   |
| String and byte-slice topics | Hashed; filterable but not recoverable from the topic                                                           |
| Payload                      | Non-topic fields, serialized by the generated `WriteXDR` implementation                                         |
| `#[event_spec(export)]`      | Include the event in the linked contract spec without `emits(...)`                                              |
| `SIGNATURE`                  | Full 32-byte hash of version, defining crate, and type identity                                                 |
| `Event` implementation       | Topic access and payload decoding                                                                               |
| `{Name}Payload`              | Companion payload type with `ReadXDR`                                                                           |
| Usage                        | [Event definitions, emission, and tests](../pages/contracts/events.md)                                          |



## Utility Macros

| Macro                                      | Output / usage                                                                                                         |
| ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- |
| `static_key!("slot")`                      | Compile-time SHA-256 `StorageKey`                                                                                      |
| `sha256_static!("text")`                   | Compile-time `SHA256Hash`                                                                                              |
| `sha256_ident!(Name)`                      | `SHA256Hash` of an identifier                                                                                          |
| `hash_ident! { static NAME: SHA256Hash; }` | Named hash static; also supports `ContractAddress` and visibility                                                      |
| `sha256_array_ident!(Name)`                | Identifier hash as `[u8; 32]`                                                                                          |
| `hash_to_array!("text")`                   | String or byte-string hash as `[u8; 32]`                                                                               |
| `declare_mock_contract!()`                 | Crate-root mock registration when `dev` is enabled; see [test setup](../pages/programming-model/testing.md#test-setup) |



## `#[contract_type]`

| Property                | Value                                                                                                            |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Targets                 | Named, tuple, or unit structs and enums                                                                          |
| Output                  | Serialization derives and `ContractTypeSpec`                                                                     |
| `name = "Name"`         | Override spec type name                                                                                          |
| `export`                | Include an otherwise unreachable type in the spec                                                                |
| Enum variants           | Explicit discriminants required                                                                                  |
| Generic type parameters | Not supported                                                                                                    |
| Spec inclusion          | Types reachable through method signatures, errors, events, or other reachable types; otherwise requires `export` |
| Spec kind               | Struct, enum without payloads, or union with payloads                                                            |
| Examples                | [Argument and return types](../pages/contracts/methods.md#define-argument-and-return-types)                      |



## `#[derive(ContractTypeSpec)]`

| Property                        | Value                                                              |
| ------------------------------- | ------------------------------------------------------------------ |
| Targets                         | Structs and enums                                                  |
| Output                          | `ContractTypeSpec` only; serialization must be supplied separately |
| `#[contract_type_spec(export)]` | Include an otherwise unreachable type in the spec                  |

---

## Syscalls

Source: <https://thruput.network/docs/reference/syscalls/>

Host function numbers, parameters, and errors for Project Thruput contracts.

These are the host functions available to Project Thruput guest contracts. Most developers use the SDK rather than calling syscalls directly. See [Programming Model: Storage Types](../pages/programming-model/storage-types.md) for the high-level API.

The tables below describe the protocol’s logical typed interface. The generated low-level bindings map it to each guest target’s ABI. User contracts use RV32. Variable-length buffers are passed as spans.

The return value is a `SyscallErrorCode`. Any syscall can return `Fault` (1) if a pointer argument is out of guest memory bounds, or `NoSyscall` (2) if the syscall number is not supported. Per-syscall error codes are listed with each entry below, and the full enum is at the bottom of this page.



## Hashing



### SHA256

|            |   |
| ---------- | - |
| **Number** | 0 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |
| out       | `hash`   | `SHA256Hash`  |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the SHA-256 hash of the input buffer.



### SHA256Update

|            |    |
| ---------- | -- |
| **Number** | 26 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `index`  | `u32`         |
| in        | `buffer` | `[u8]` (span) |
| in        | `reset`  | `bool`        |

Errors:

- `InvalidSyscallInput` if the indexed hash buffer does not exist and `reset` is false, the buffer becomes too large, or there are too many active hash buffers.

Updates the SHA-256 hash computation at the specified index with the supplied bytes. If `reset` is true, the hash state is cleared before the update.



### SHA256Finalize

|            |    |
| ---------- | -- |
| **Number** | 27 |

| Direction | Name     | Type         |
| --------- | -------- | ------------ |
| in        | `index`  | `u32`        |
| out       | `output` | `SHA256Hash` |

Errors:

- `InvalidSyscallInput` if the queried hash buffer does not exist (for example, calling finalize twice on the same buffer without an intervening reset).

Finalizes the SHA-256 hash computation at the specified index, returns the digest, and removes the buffer.



### SHA256Copy

|            |    |
| ---------- | -- |
| **Number** | 33 |

| Direction | Name        | Type  |
| --------- | ----------- | ----- |
| in        | `src_index` | `u32` |
| in        | `dst_index` | `u32` |

Errors:

- `InvalidSyscallInput` if the hash computation at `src_index` does not exist, or if `dst_index` does not already hold a hash computation and there are too many active hash buffers.

Copies the in-progress SHA-256 hash computation at `src_index` to `dst_index`, replacing any hash computation already at `dst_index`. Both computations can then be extended and finalized independently. Copying an index onto itself succeeds and changes nothing.



## Calldata



### GetCalldataLen

|            |   |
| ---------- | - |
| **Number** | 2 |

| Direction | Name               | Type                  |
| --------- | ------------------ | --------------------- |
| out       | `len`              | `RuntimeMemoryLength` |
| out       | `auth_token_count` | `u32`                 |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the length of the calldata supplied to the invocation associated with the current call frame, plus the number of auth tokens supplied to that invocation.



### GetCalldata

|            |   |
| ---------- | - |
| **Number** | 3 |

| Direction | Name               | Type                  |
| --------- | ------------------ | --------------------- |
| out       | `buffer`           | `[u8]` (span)         |
| out       | `written_len`      | `RuntimeMemoryLength` |
| out       | `auth_token_count` | `u32`                 |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the calldata and the number N of auth tokens supplied to the invocation associated with the current call frame. Auth-token ids are local to each frame; the supplied tokens are ids `0..N-1`.



## Logging



### ConsoleLog

|            |   |
| ---------- | - |
| **Number** | 4 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| in        | `buffer` | `[u8]` (span) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Logs the input buffer to the console. No-op on release builds and on-chain; calling it from a production contract is harmless but pointless.



### LogEvent

|            |    |
| ---------- | -- |
| **Number** | 24 |

| Direction | Name     | Type                         |
| --------- | -------- | ---------------------------- |
| in        | `topic0` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic1` | `Option<Topic>` (`[u8; 32]`) |
| in        | `topic2` | `Option<Topic>` (`[u8; 32]`) |
| in        | `data`   | `[u8]` (span)                |

Errors:

- `InvalidSyscallInput` if the serialized event (32 bytes per topic plus the data) is longer than the maximum event length (1,024 bytes), the transaction has already emitted 1,000 events, or topics are not supplied as a continuous prefix (for example `topic0` and `topic2` without `topic1`).

Emits an event with up to three 32-byte topics and a data payload. The serialized event is `topic0 || topic1 || topic2 || data`, with a separate `num_topics` field that lets downstream indexers filter on the leading topic chunks. Events are accumulated into a per-block merkle-patricia trie.



## Invocation



### Invoke

|            |   |
| ---------- | - |
| **Number** | 5 |

| Direction | Name                        | Type                                                                                       |
| --------- | --------------------------- | ------------------------------------------------------------------------------------------ |
| in        | `address`                   | `ContractAddress`                                                                          |
| in        | `calldata`                  | `[u8]` (span)                                                                              |
| in        | `owned_auth_token_ids_list` | `[u8]` (span, interpreted as `[u32]`)                                                      |
| in        | `inputs`                    | `CopyableInvokeInputs` (`entrypoint_id`, `gas_limit`, `flags`, `reserved`)                 |
| out       | `outputs`                   | `CopyableInvokeOutputs` (`return_buffer_len`, `returned_auth_token_count`, `frame_status`) |

Errors:

- `InvalidSyscallInput` if the call is rejected before a child frame runs: the target is missing, the flags are invalid, the calldata is longer than `max_calldata_len`, more auth-token ids are supplied than `max_auth_tokens`, or an auth-token id is malformed, duplicated, or not owned by the current frame.
- `Reentrance` if the invoked address is already on the call stack.
- `InvokeDepthExceeded` if the transaction already holds the maximum number of invocation frames open. Like `Reentrance`, the call is rejected before any child frame runs and the syscall is a no-op. This is a resource limit rather than a malformed call: the same invocation succeeds from a shallower frame.

Invokes the specified entrypoint of the contract at `address` with the supplied calldata and auth tokens, creating a new call frame. The new frame is capped at `min(gas_limit, remaining gas in current frame)`; unused child-frame gas returns to the caller’s execution budget. This is not a token refund. The SDK defaults `gas_limit` to `u64::MAX` so the child inherits everything the parent has left.

`entrypoint_id` is the big-endian interpretation of the 8-byte `ContractEntrypointID` (`ContractEntrypointID::into_u64` in the Rust bindings). `frame_status` is `Return`, `Abort`, or `Fault`; it reports the outcome after a child frame actually runs. A nonzero syscall error means the call was rejected before the child ran and the output struct is untouched.



### GetMsgSender

|            |   |
| ---------- | - |
| **Number** | 1 |

| Direction | Name     | Type              |
| --------- | -------- | ----------------- |
| out       | `sender` | `ContractAddress` |

Errors:

- `IsRootTransaction` if there is no caller (the syscall was made from a root transaction frame).

Returns the contract address of the contract that invoked the current call frame.



### GetCurrentAddress

|            |    |
| ---------- | -- |
| **Number** | 19 |

| Direction | Name      | Type              |
| --------- | --------- | ----------------- |
| out       | `address` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the contract address of the current call frame.



## Return



### Return

|            |   |
| ---------- | - |
| **Number** | 6 |

| Direction | Name                      | Type                                  |
| --------- | ------------------------- | ------------------------------------- |
| in        | `buffer`                  | `[u8]` (span)                         |
| in        | `revert_frame`            | `bool`                                |
| in        | `returned_auth_token_ids` | `[u8]` (span, interpreted as `[u32]`) |

Errors:

- `Fault` (the current frame faults, like `Exit`) if the buffer is longer than `max_return_buffer_len`, a frame marked for revert returns auth tokens, or the auth-token id list is longer than `max_auth_tokens`, malformed, duplicated, or names tokens the current frame does not own.

Does not return to the caller (terminates execution of the current guest invocation).

Returns data and a set of auth-token ids from the current call frame and optionally marks the frame for revert. The return buffer is made available to the caller via `GetReturnedBuffer`.



### GetReturnedBuffer

|            |   |
| ---------- | - |
| **Number** | 7 |

| Direction | Name                        | Type                  |
| --------- | --------------------------- | --------------------- |
| out       | `buffer`                    | `[u8]` (span)         |
| out       | `written_len`               | `RuntimeMemoryLength` |
| out       | `returned_auth_token_start` | `u32`                 |
| out       | `returned_auth_token_count` | `u32`                 |

Errors:

- `NoReturnBufferAvailable` if no return buffer is available: the most recent subcall faulted (for example by trapping or calling `Exit`), or no subcall has been made in this frame.

Returns the return buffer and the returned auth tokens from the most recent subcall that ended with `Return`. The tokens join the current frame as ids `returned_auth_token_start` to `returned_auth_token_start + returned_auth_token_count - 1`.



### Exit

|            |   |
| ---------- | - |
| **Number** | 8 |

No inputs. No outputs. Does not return.

Errors: none beyond the universal `Fault` / `NoSyscall`.

Terminates the current call frame immediately. The frame reverts and the caller sees a deterministic error with no return buffer available.



## Storage



### BytestringGetLen

|            |    |
| ---------- | -- |
| **Number** | 13 |

| Direction | Name     | Type                     |
| --------- | -------- | ------------------------ |
| in        | `key`    | `StorageKeyContractData` |
| out       | `length` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist in the current transaction view.
- `InvalidSyscallInput` if the key exists but holds a different storage type (e.g. NNInt rather than bytestring).

Returns the length of the bytestring stored at `key`.



### BytestringGet

|            |    |
| ---------- | -- |
| **Number** | 14 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| out       | `bytestring`  | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted.
- `InvalidSyscallInput` if the key exists but holds a different storage type.

Retrieves the bytestring stored at `key`.



### BytestringSet

|            |    |
| ---------- | -- |
| **Number** | 15 |

| Direction | Name         | Type                     |
| --------- | ------------ | ------------------------ |
| in        | `key`        | `StorageKeyContractData` |
| in        | `bytestring` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the bytestring is too long.

Writes the bytestring value at `key`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](../pages/reference/syscalls.md#storage-flags) unchanged.



### NonnegativeIntGet

|            |    |
| ---------- | -- |
| **Number** | 16 |

| Direction | Name                       | Type                     |
| --------- | -------------------------- | ------------------------ |
| in        | `key`                      | `StorageKeyContractData` |
| in        | `force_load_from_snapshot` | `bool`                   |
| out       | `current_set`              | `i128`                   |
| out       | `current_set_opt`          | `bool`                   |
| out       | `current_add`              | `i128`                   |

Errors:

- `StorageKeyNotExist` if the storage key does not exist or has been deleted (only returned when `force_load_from_snapshot` is true).
- `InvalidSyscallInput` if the key exists but holds a different storage type (only returned when `force_load_from_snapshot` is true).

Retrieves the NNInt value at `key`.

If `force_load_from_snapshot` is true, `current_set` will never be null: the syscall reads the snapshot value. A snapshot that is not an NNInt, or a prior write on this key that is not an NNInt, returns `InvalidSyscallInput`. A snapshot that does not exist, or was deleted by a prior write, returns `StorageKeyNotExist`.

If `force_load_from_snapshot` is false, the prior snapshot state is ignored unless the prior write on `key` is itself an NNInt write (in which case the parameters of that write are returned). If the prior write is not an NNInt or was a deletion, the syscall returns `(None, 0)` without error.



### NonnegativeIntSetAdd

|            |    |
| ---------- | -- |
| **Number** | 17 |

| Direction | Name        | Type                     |
| --------- | ----------- | ------------------------ |
| in        | `key`       | `StorageKeyContractData` |
| in        | `set_value` | `Option<i128>`           |
| in        | `add_value` | `i128`                   |

Errors:

- `InvalidSyscallInput` if the operation would always violate the NNInt floor (for example `set_add(1, -2)` or `set_add(-1, -1)`).

Sets or modifies the NNInt at `key`. `set_value` (if `Some`) supplies the base, and `add_value` is added as a delta. The resolved value must satisfy `value >= min(set, 0)`. Overwrites any existing value, even if that value has a different storage type. Leaves the key’s [storage flags](../pages/reference/syscalls.md#storage-flags) unchanged. See [Programming Model: NNInt](../pages/programming-model/nnint.md) for commutativity rules.



### DeleteObject

|            |    |
| ---------- | -- |
| **Number** | 18 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Deletes the object at `key`. Leaves the key’s [storage flags](../pages/reference/syscalls.md#storage-flags) unchanged.



## Storage Flags

A transaction keeps one `StorageDeltaFlagSet` per storage key, separate from its writes. Every change the transaction commits on a key carries that key’s flags. `ExclusiveLock` (`0x1`) is the only flag: it gives the key’s change an exclusive lock for the whole block, so no concurrent transaction in the block can modify the key.

Writes never change a key’s flags. A lock requested after one write stays on the key through later writes in the same transaction, including writes from other call frames, until `ClearStorageFlags` withdraws it. Flag changes follow call frames like writes do: a successful frame passes them to its caller, and a reverted frame or failed `try_invoke` discards them.

Each flag syscall costs the same storage access gas as a write and does not read the ledger.



### SetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 36 |

| Direction | Name    | Type                                    |
| --------- | ------- | --------------------------------------- |
| in        | `key`   | `StorageKeyContractData`                |
| in        | `flags` | `StorageDeltaFlagSet` (`u32`, by value) |

Errors:

- `InvalidSyscallInput` if `flags` contains an unknown flag, or no write to `key` is pending in the current call frame’s view of the transaction.

Adds `flags` (bitwise OR) to the flags the transaction requests for `key`. A pending write is one made earlier in this frame, or inherited from a caller or a successful callee. A pending deletion counts. A value that exists only in the block snapshot does not.



### GetStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 37 |

| Direction | Name    | Type                     |
| --------- | ------- | ------------------------ |
| in        | `key`   | `StorageKeyContractData` |
| out       | `flags` | `StorageDeltaFlagSet`    |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the flags the transaction requests for `key`, as visible in the current call frame. A key with no pending write returns `None` (`0`). Allowed in read-only frames.



### ClearStorageFlags

|            |    |
| ---------- | -- |
| **Number** | 38 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Removes every flag the transaction requests for `key`, as visible in the current call frame. Does nothing if no write to `key` is pending.



## Retrocausal Queue



### RetrocausalQueueInsert

|            |    |
| ---------- | -- |
| **Number** | 20 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `queue_entry` | `[u8]` (span)            |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type that cannot be converted to a retrocausal queue, if the entry is too large, or if too many entries are inserted in the current transaction.

Inserts an entry into the retrocausal queue at `key`.



### RetrocausalQueueConsume

|            |    |
| ---------- | -- |
| **Number** | 21 |

| Direction | Name          | Type                     |
| --------- | ------------- | ------------------------ |
| in        | `key`         | `StorageKeyContractData` |
| in        | `peek`        | `bool`                   |
| out       | `queue_entry` | `[u8]` (span)            |
| out       | `written_len` | `RuntimeMemoryLength`    |

Errors:

- `NoRetrocausalQueueEntry` if the queue is empty.
- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Consumes (or with `peek = true`, only inspects) the next entry from the retrocausal queue at `key`.



### RetrocausalQueuePeekLen

|            |    |
| ---------- | -- |
| **Number** | 30 |

| Direction | Name  | Type                     |
| --------- | ----- | ------------------------ |
| in        | `key` | `StorageKeyContractData` |
| out       | `len` | `RuntimeMemoryLength`    |

Errors:

- `InvalidSyscallInput` if the key exists but holds a different storage type.
- `NoRetrocausalQueueEntry` if the queue is empty.
- `RetrocausalQueueReadLimitReached` if the transaction has reached its per-transaction limit on concurrent retrocausal-queue reads. This does not fail the transaction; a contract may use it as a stop condition.

Returns the length (in bytes) of the next entry in the retrocausal queue at `key`.



## Auth



### VerifySignature

|            |    |
| ---------- | -- |
| **Number** | 12 |

| Direction | Name         | Type                        |
| --------- | ------------ | --------------------------- |
| in        | `scheme`     | `i32` (CryptographicScheme) |
| in        | `signature`  | `[u8]` (span)               |
| in        | `public_key` | `[u8]` (span)               |
| in        | `message`    | `[u8]` (span)               |

No outputs: the result is the `SyscallErrorCode` itself (`None` on success).

Errors:

- `InvalidSyscallInput` if verification fails or the inputs are malformed (wrong key/signature size for the chosen scheme, unsupported scheme, etc.).

Verifies a cryptographic signature against a public key and message.



### GetAuthClaim

|            |    |
| ---------- | -- |
| **Number** | 25 |

| Direction | Name         | Type        |
| --------- | ------------ | ----------- |
| out       | `auth_claim` | `AuthClaim` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the authentication claim associated with the current transaction. Takes no input.



### ChangePublicKeyRegistration

|            |    |
| ---------- | -- |
| **Number** | 23 |

| Direction | Name         | Type                                |
| --------- | ------------ | ----------------------------------- |
| in        | `key_index`  | `u32`                               |
| in        | `key_scheme` | `Option<i32>` (CryptographicScheme) |
| in        | `key_bytes`  | `[u8]` (span)                       |
| in        | `key_weight` | `Option<u32>`                       |

Errors:

- `InvalidSyscallInput` if the registration is invalid or `key_index` is out of bounds.

Changes the public key registration for the current contract address at `key_index`. If `key_scheme` is `None`, the key is removed. Otherwise the key is set with the supplied scheme, bytes, and weight.



### WriteAddressRequiredWeight

|            |    |
| ---------- | -- |
| **Number** | 28 |

| Direction | Name              | Type                       |
| --------- | ----------------- | -------------------------- |
| in        | `required_weight` | `Weight` (`u32`, by value) |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Writes the required-weight threshold for the current contract address. This is the minimum total weight of signing keys needed to authorize a transaction from this address.



### MintAuthToken

|            |    |
| ---------- | -- |
| **Number** | 31 |

| Direction | Name                    | Type          |
| --------- | ----------------------- | ------------- |
| in        | `expiry_height`         | `BlockHeight` |
| in        | `serialized_auth_token` | `[u8]` (span) |
| out       | `token_id`              | `u32`         |

Errors:

- `InvalidSyscallInput` if the serialized token fails to parse as a valid `AuthToken`, `expiry_height` is in the past, or minting would exceed the per-transaction auth-token cap.

Mints an authentication token for the current contract address.



### ConsumeAuthToken

|            |    |
| ---------- | -- |
| **Number** | 32 |

| Direction | Name                       | Type                  |
| --------- | -------------------------- | --------------------- |
| in        | `token_id`                 | `u32`                 |
| out       | `auth_payload`             | `[u8]` (span)         |
| out       | `token_minter`             | `ContractAddress`     |
| out       | `auth_payload_written_len` | `RuntimeMemoryLength` |
| out       | `unwrapped_token_id_start` | `u32`                 |
| out       | `unwrapped_token_id_count` | `u32`                 |

Errors:

- `InvalidSyscallInput` if the token is not owned by the current contract address, or the token has expired.

Consumes an authentication token owned by the current contract address. Returns the token’s auth payload, its minter, and the id range of any nested tokens unwrapped as a side effect.



## Address



### GetDeployAddress

|            |   |
| ---------- | - |
| **Number** | 9 |

| Direction | Name             | Type              |
| --------- | ---------------- | ----------------- |
| in        | `caller_address` | `ContractAddress` |
| in        | `nonce`          | `SHA256Hash`      |
| in        | `contract_hash`  | `SHA256Hash`      |
| out       | `to_be_deployed` | `ContractAddress` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Computes the address that would be deployed for a contract with the given deployer address, nonce, and contract hash. Pure computation; does not deploy anything.



### DeployContract

|            |    |
| ---------- | -- |
| **Number** | 10 |

| Direction | Name               | Type              |
| --------- | ------------------ | ----------------- |
| in        | `nonce`            | `SHA256Hash`      |
| in        | `contract_hash`    | `SHA256Hash`      |
| out       | `deployed_address` | `ContractAddress` |

Errors:

- `InvalidSyscallInput` if the requested contract is not available for deployment, or the contract is a special precompiled (native) contract that cannot be deployed. A contract must either already exist on chain or be supplied in the transaction’s `contracts_to_deploy` field.
- `ContractAlreadyDeployed` if a contract with the same nonce and contract hash has already been deployed at the computed address in a previous block or earlier in this transaction. A contract can be deployed multiple times concurrently in the same block; if a contract must initialize only once, gate the initialization on a semaphore.

Deploys a contract with the specified nonce and contract hash at the computed address.



## Block



### GetBlockHeight

|            |    |
| ---------- | -- |
| **Number** | 29 |

| Direction | Name     | Type          |
| --------- | -------- | ------------- |
| out       | `result` | `BlockHeight` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the current block height.



### GetBlockTimepoint

|            |    |
| ---------- | -- |
| **Number** | 35 |

| Direction | Name              | Type        |
| --------- | ----------------- | ----------- |
| out       | `block_timepoint` | `TimePoint` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the timepoint of the block currently executing. The value is fixed by the coordinator before execution begins and is carried in the block’s `ProposalHeader`, so it is part of the block identity and is identical for every invocation in the block.

Like a block height, this is consensus data rather than a trusted clock: it is chosen by the proposer within whatever bounds the network’s validators enforce. Contracts should treat it as coarse-grained wall-clock time, suitable for expiries, vesting schedules, and deadlines, and must not rely on it for fine-grained ordering or as a source of randomness.



## Network



### GetNetworkHash

|            |    |
| ---------- | -- |
| **Number** | 34 |

| Direction | Name           | Type          |
| --------- | -------------- | ------------- |
| out       | `network_hash` | `NetworkHash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the network name, the identifier that separates this network’s blocks from those of every other network. It is fixed for the life of the network, so it is constant across every block and every invocation.

Transaction signatures already commit to this value (the signature preimage is `cxs(DomainSeparator("Transaction")) || network_hash || xdr(tx)`). Exposing it to contracts lets a contract bind its own off-chain signed messages to this network the same way, so a message signed for one network cannot be replayed against a contract at the same address on another.



## Transaction



### GetSourceTransactionHash

|            |    |
| ---------- | -- |
| **Number** | 11 |

| Direction | Name             | Type         |
| --------- | ---------------- | ------------ |
| out       | `source_tx_hash` | `SHA256Hash` |

Errors: none beyond the universal `Fault` / `NoSyscall`.

Returns the hash of the transaction that initiated the current execution.



### GetTransactionStatistics

|            |    |
| ---------- | -- |
| **Number** | 22 |

| Direction | Name        | Type                   |
| --------- | ----------- | ---------------------- |
| in        | `statistic` | `TransactionStatistic` |
| out       | `result`    | `u64`                  |

Errors:

- `InvalidSyscallInput` if the requested statistic does not exist or is not available in this configuration.

Returns a transaction statistic. Statistics may be disabled in release builds or production execution, and may be nondeterministic in test configurations. Nondeterministic stats are disabled in production settings.



## Error Codes

The full `SyscallErrorCode` enum, from `protocol/syscall_error.x`:

| Code | Name                               | Description                                                                                                                                                                                                                              |
| ---- | ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 0    | `None`                             | Success.                                                                                                                                                                                                                                 |
| 1    | `Fault`                            | A pointer argument is out of guest memory bounds. Any syscall can return this.                                                                                                                                                           |
| 2    | `NoSyscall`                        | The supplied syscall number is not supported. Any syscall can return this.                                                                                                                                                               |
| 3    | `IsRootTransaction`                | Cannot call `GetMsgSender` from a root invocation.                                                                                                                                                                                       |
| 4    | `Reentrance`                       | Reentrance guard violation: the invoked address is already on the call stack.                                                                                                                                                            |
| 5    | `ContractAlreadyDeployed`          | Attempt to deploy a contract twice (same nonce, contract hash, and deployer).                                                                                                                                                            |
| 6    | `NoReturnBufferAvailable`          | No return buffer from a child call frame. Either the most recent subcall faulted or no subcall has been made in this frame.                                                                                                              |
| 7    | `InvalidSyscallInput`              | Invalid input to a syscall (type mismatch, value out of range, data too long, unknown storage flag, etc.).                                                                                                                               |
| 8    | `StorageKeyNotExist`               | The storage key does not exist in the current view.                                                                                                                                                                                      |
| 9    | `NoRetrocausalQueueEntry`          | The retrocausal queue is empty.                                                                                                                                                                                                          |
| 10   | `RetrocausalQueueReadLimitReached` | The transaction reached its concurrent RCQ read limit. The contract may use this as a stop condition.                                                                                                                                    |
| 11   | `InvokeDepthExceeded`              | The transaction already holds the maximum number of invocation frames open, so another would exceed the network’s cross-invoke depth bound. A resource limit, not a malformed call: the same invocation succeeds from a shallower frame. |
