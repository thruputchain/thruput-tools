# React

Documentation source: `245ae77a61dbf80ce178bf622622c0e73f1230a6`. Hosted docs may be newer than this snapshot.

## React

Source: <https://thruput.network/docs/react/>

Use Project Thruput's React provider and hooks for wallets and contract data.

Build wallet controls and contract-data interfaces with `@thruputchain/react`. The library supplies state and hooks; you supply the components, styling, and application workflow.



## How the layers fit

- The **TypeScript client** connects to a network and executes typed contract operations.
- **WalletProvider** shares that client and manages wallet discovery, connection, and account selection.
- **TanStack Query** manages read state, caching, and mutations through your application’s `QueryClient`.
- **Contract bindings** describe each contract’s methods, results, errors, and events.

The library manages one configured application network and one selected wallet connection. Public reads work without wallet permission. A connected wallet supplies the signing client for writes.



## Start with a read

The [React quickstart](../pages/get-started/react.md) displays Futurenet’s native-token supply using the supplied ERC-20 binding and contract address. You do not need Rust, the CLI, or your own deployment.

For an existing app, follow [Setup](../pages/react/setup.md) and [Providers and clients](../pages/react/providers.md). Then use [Read contract data](../pages/react/reads.md) or [Read balances](../pages/react/balances.md). [Cache and refresh data](../pages/react/queries.md) explains the query behavior shared by those hooks.



## Add wallet actions

[Connect a wallet](../pages/react/wallets.md) covers discovery, account selection, and connection states. [Send transactions](../pages/react/transactions.md) and [Track transaction results](../pages/react/transaction-status.md) cover the approval-to-receipt flow.

Use the [TypeScript account model](../pages/typescript/wallet-clients.md) for shared signing concepts and the [React API reference](../pages/react/reference.md) for exact hook inputs and results. Complete application walkthroughs belong in [Guides](../pages/guides.md).

---

## Setup

Source: <https://thruput.network/docs/react/setup/>

Install the React integration and connect its wallet and query providers to Futurenet.

Use the current Node.js LTS release. For a new app, create a React TypeScript project:

```bash
npm create vite@latest my-thruput-ui -- --template react-ts
cd my-thruput-ui
npm install
```

Complete the shared [registry access setup](../pages/typescript/setup.md#give-npm-package-access), then install the integration and its client together:

```bash
npm install @thruputchain/react @thruputchain/client @thruputchain/protocol @tanstack/react-query
```

The package manager resolves the React library’s compatible client dependency. Keep the lockfile. In an existing application, satisfy the library’s peer dependencies rather than forcing an incompatible client version. The integration uses React 19 and TanStack Query 5.



## Connect the application

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, futurenet } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Futurenet…</p>);

async function start() {
  const client = await createThruputClient({ cluster: futurenet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

void start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Futurenet"}</p>,
  );
});
```

The public client and query cache are created once, before rendering the app. `WalletProvider` does not request wallet permission automatically.



## Check the setup

Start the development server:

```bash
npm run dev
```

In another terminal, check the production build:

```bash
npm run build
```

---

## Providers and clients

Source: <https://thruput.network/docs/react/providers/>

Understand the React contexts, public and signing clients, and their lifetimes.

The [setup page](../pages/react/setup.md) mounts two contexts. They have different responsibilities:

| Provider              | Responsibility                                                                                  |
| --------------------- | ----------------------------------------------------------------------------------------------- |
| `WalletProvider`      | Public client, wallet discovery, authorized session, selected account, signing-client lifecycle |
| `QueryClientProvider` | Read cache, query state, refresh policies, and mutations                                        |

`WalletProvider`, `useClient`, `useWallet`, and `useWalletClient` work without TanStack Query context. Balance, contract-view, receipt, and execution hooks require both providers.

The React `WalletProvider` is a context component. A discovered wallet provider is the external wallet object that handles permission and signing requests. See [Accounts and wallet clients](../pages/typescript/wallet-clients.md) for that shared model.



## Use the public client

`useClient()` returns the initialized client supplied to `WalletProvider`. It remains available while disconnected and stays on the application’s network when the wallet changes networks.

Use it with SDK actions or [custom queries](../pages/react/events.md). Contract reads do not require a connected wallet.

Choose a cluster or pin its identity through the TypeScript [network configuration](../pages/typescript/connect.md), then supply that cluster-validated client to `WalletProvider`.

Configure HTTP timeouts and batching through the [client transport](../pages/typescript/transport.md). Configure caching and refresh behavior through [TanStack Query](../pages/react/queries.md).



## Use the signing client

`useWalletClient()` returns the current provider-backed signing client, or `null` when unavailable. `useWallet()` exposes the connection state and selection actions.

Enable writes only when `wallet.status === "connected"`. An account address can still be present in a wrong-network session, so an address alone is not evidence that signing is available.

The provider owns the signing client’s lifecycle. Session changes invalidate the old binding immediately and create a fresh binding after event dispatch when the session is valid. Use the current hook result for new operations.



## Keep identities stable

Create the public client and `QueryClient` once for the application’s lifetime. Replacing the public client starts a disconnected wallet lifecycle, even when the new client points to the same network. Reads through different client instances have separate cache identities.

Unmounting `WalletProvider` disposes its signing binding without revoking remote permission. The user’s [Disconnect action](../pages/react/wallets.md) requests permission revocation. Calling the current signing client’s `dispose()` also clears the local React connection.



## Use a client-rendered boundary

In a server-rendered framework, initialize the client and mount these providers in the application’s client-rendered boundary. Server rendering starts disconnected; browser discovery runs after mounting.

Project Thruput query keys contain in-memory client identities. Use them within one query-cache lifetime, not as persisted keys or server-to-browser hydration identifiers. See [Cache and refresh data](../pages/react/queries.md) for cache scope and reusable query factories.

---

## Read contract data

Source: <https://thruput.network/docs/react/reads/>

Display a typed contract view with loading, error, data, and refresh states.

`useContractView` reads a generated method descriptor and infers its arguments and result. Mount the [application providers](../pages/react/setup.md) first.



## Display native-token supply

Use this as `src/App.tsx`. The binding and deployed address are supplied by the SDK packages:

```tsx
import { formatUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    address: NATIVE_TOKEN_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>Native-token supply</h1>
      {supply.isLoading ? <p>Reading the contract…</p> : null}
      {supply.error ? <p role="alert">{supply.error.message}</p> : null}
      {supply.data ? (
        <>
          <p>{formatUnits(supply.data.value, 7)} native tokens</p>
          <p>Read at block {supply.data.stateBlockHeight.toString()}</p>
        </>
      ) : null}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

No wallet, signer, or new deployment is needed. The result retains `value`, `stateBlockHeight`, `gasUsed`, and simulated `events`.



## Pass method arguments

For a method with arguments, pass its generated argument object:

```tsx
import type { ContractAddress } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export function RawBalance({ owner }: { owner: ContractAddress }) {
  const balance = useContractView({
    method: ERC20.v0_1.getBalanceOf,
    address: NATIVE_TOKEN_ADDRESS,
    args: { addr: owner },
  });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Reading balance…</p>;
  return <p>{balance.data.value.toString()} base units</p>;
}
```

Pass `caller` when a view needs simulated caller context. It does not authorize a transaction. Custom contracts use their own [generated bindings](../pages/tools/typescript-bindings.md).



## Control when a read runs

`enabled: false` disables automatic reads and retains cached data. `staleTime` controls freshness. Arguments must still be valid: the hook encodes them while constructing the query, even when disabled. Mount a read component only after required inputs are ready.

Keep generated descriptors stable. Cache identity includes the client, method decoder, contract address, encoded arguments, and caller. Equivalent argument values share a query; changing an input selects a different query.



## Handle refresh and cancellation

Use `isLoading` for the first active fetch and `isFetching` for any active fetch, including refresh. A disabled query can be pending without loading. Display read errors separately from cached data when a refresh fails.

Query cancellation aborts contract-view requests and ignores late results from custom transports. Independent views can use different snapshots. After a write, check that a view’s `stateBlockHeight` has reached the receipt’s `blockHeight` before treating its data as post-transaction state.

---

## Read balances

Source: <https://thruput.network/docs/react/balances/>

Read native-token and contract-token balances for a connected account or an explicit address.

Use `useBalance` for the native token and `useTokenBalance` for a standard ERC-20 contract. Both return query state, a `queryKey`, and data containing `rawBalance` and `stateBlockHeight`.



## Follow the connected account

```tsx
import { formatUnits } from "@thruputchain/client";
import { useBalance } from "@thruputchain/react";

export function NativeBalance() {
  const balance = useBalance();
  if (balance.isLoading) return <p>Loading balance…</p>;
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Connect a wallet on this network to see its balance.</p>;
  return <p>{formatUnits(balance.data.rawBalance, 7)} native tokens</p>;
}
```

With no address, the hook follows the selected account only while the wallet is connected to the application’s network. Account changes select a different query rather than displaying the previous account’s balance.



## Read an explicit address

Pass an address to read without wallet permission:

```tsx
import { formatUnits } from "@thruputchain/client";
import { useTokenBalance, type BalanceAddress } from "@thruputchain/react";

export function TokenBalance({ token, owner, decimals }: {
  token: BalanceAddress;
  owner: BalanceAddress;
  decimals: number;
}) {
  const balance = useTokenBalance({ token, address: owner });
  if (balance.error) return <p role="alert">{balance.error.message}</p>;
  if (!balance.data) return <p>Loading token balance…</p>;
  return (
    <p>{formatUnits(balance.data.rawBalance, decimals)} at block {balance.data.stateBlockHeight.toString()}</p>
  );
}
```

Addresses accept base58 strings or SDK-branded bytes. Equivalent inputs share a key. The hook does not fetch token metadata or choose decimals; supply those from the application or a metadata read. The native token has seven decimals.



## Handle missing inputs

| Input                          | Behavior                                                               |
| ------------------------------ | ---------------------------------------------------------------------- |
| Omitted or undefined `address` | Resolve the connected account on the app’s network                     |
| Explicit address               | Read even while disconnected or while the wallet is on another network |
| `address: null`                | Disable account resolution and fetching                                |
| Missing or null `token`        | Disable token fetching                                                 |

Missing-input queries are idle with `isLoading: false`. Invalid addresses surface through query error state.



## Set refresh behavior

Pass options through `query`, for example `{ staleTime: 10_000, refetchInterval: 15_000 }`. The balance hooks also support retry, garbage-collection, focus/reconnect, and `select` options. Defaults come from your QueryClient and TanStack Query.

Abandoned balance results are discarded, but their underlying RPC may still finish. Use [Cache and refresh data](../pages/react/queries.md) for polling, reusable query options, and invalidation after writes.

---

## Cache and refresh data

Source: <https://thruput.network/docs/react/queries/>

Share query results, reuse query factories, and refresh the original data after a transaction.

Project Thruput query hooks use your application’s TanStack Query cache. Keep the public client and QueryClient stable so components reading the same inputs can share data and in-flight requests.



## Understand cache scope

Keys include network and public-client instance identity. Balance keys also include owner and token where applicable. Contract-view keys include the method decoder, target, encoded arguments, and caller.

Different client instances do not share cached reads, even on the same network. Use the `queryKey` returned by a hook or factory rather than constructing a library-owned key yourself.

`staleTime` controls when data becomes stale. Polling and post-transaction invalidation are explicit application choices. Independent queries do not guarantee a common read height.



## Reuse query options

Factories work outside components when given an initialized client and explicit inputs:

```ts
import type { ConnectedThruputClient } from "@thruputchain/client";
import { tokenBalanceQueryOptions, type BalanceAddress } from "@thruputchain/react";
import type { QueryClient } from "@tanstack/react-query";

export function prefetchBalance(
  queries: QueryClient,
  client: ConnectedThruputClient,
  owner: BalanceAddress,
  token: BalanceAddress,
) {
  return queries.prefetchQuery(tokenBalanceQueryOptions({
    client,
    address: owner,
    token,
    query: { staleTime: 10_000 },
  }));
}
```

The same client and inputs produce the key used by `useTokenBalance`. Factories also exist for native balances, contract views, and receipts.

Balance factories do not resolve the connected wallet. Missing inputs produce a skipped query for hook use; call imperative `fetchQuery` or `prefetchQuery` only when inputs are present. `enabled` controls observers, not imperative fetching. `select` transforms observer data, not the cache’s raw data.



## Read a dynamic list

Use one balance component per token, or compose factory options with `useQueries`:

```tsx
import { toBase58 } from "@thruputchain/client";
import { useQueries } from "@tanstack/react-query";
import { tokenBalanceQueryOptions, useClient, useWallet, type BalanceAddress } from "@thruputchain/react";

export function TokenBalances({ tokens }: { tokens: BalanceAddress[] }) {
  const client = useClient();
  const wallet = useWallet();
  const tokenKeys = tokens.map(token => typeof token === "string" ? token : toBase58(token));
  const balances = useQueries({
    queries: tokenKeys.map(token => tokenBalanceQueryOptions({
      client,
      address: wallet.status === "connected" ? wallet.address : null,
      token,
      query: { staleTime: 10_000 },
    })),
  });

  return (
    <ul>
      {balances.map((balance, index) => (
        <li key={tokenKeys[index]}>
          {balance.isLoading ? "Loading…" : balance.error ? balance.error.message : balance.data?.rawBalance.toString() ?? "No balance loaded"}
        </li>
      ))}
    </ul>
  );
}
```

Pass a list of unique tokens. Base58 is case-sensitive, so do not change the case of address strings. These are independent queries, not one atomic read or a concurrency-limited batch. Use a grouped application query and check heights when several values must describe the same snapshot.



## Refresh after a write

After observing a committed transaction, invalidate the key for the account and token that operation affected:

```ts
import type { QueryClient } from "@tanstack/react-query";
import type { BalanceQueryKey } from "@thruputchain/react";

export function refreshBalance(queries: QueryClient, originalKey: BalanceQueryKey) {
  return queries.invalidateQueries({ queryKey: originalKey, exact: true });
}
```

Capture the original key when starting the operation. An account change while waiting should not redirect the refresh to the newly selected account. Invalidating a query requests another read; check its height when the application needs post-transaction state.

For custom queries, append an application namespace and every read input to `getClientQueryKey(client)`. Canonicalize addresses and hashes with `toBase58`, other byte arrays with `toHex0x`, and bigints as decimal strings. [Read events](../pages/react/events.md) shows a custom query with fixed inputs.



## Keep persistence separate

Query keys contain in-memory identities and are not portable across server/browser processes or persisted cache sessions. Store application records, such as pending transaction hashes and their networks, separately from the query cache. See [Track transaction results](../pages/react/transaction-status.md).

---

## Read events

Source: <https://thruput.network/docs/react/events/>

Use the public client and TanStack Query to display typed contract events in React.

Compose the TypeScript client’s event actions with TanStack Query. Generated bindings provide filtering and decoding; React components provide loading, empty, error, and refresh states.



## Display recent native-token transfers

```tsx
import { toBase58 } from "@thruputchain/client";
import { thruput_erc20_if } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { getClientQueryKey, useClient } from "@thruputchain/react";
import { useQuery } from "@tanstack/react-query";

const { TransferEvent } = thruput_erc20_if.v0_1.events;

export function RecentTransfers() {
  const client = useClient();
  const transfers = useQuery({
    queryKey: [...getClientQueryKey(client), "app", "recent-native-token-transfers"],
    queryFn: ({ signal }) => client.getContractEvents({
      event: TransferEvent,
      addresses: [NATIVE_TOKEN_ADDRESS],
      start: { order: "descending", anchor: { kind: "atEnd" } },
      limit: 20,
    }, { signal }),
    staleTime: 10_000,
  });

  return (
    <section aria-label="Recent native-token transfers">
      {transfers.isLoading ? <p>Loading transfers…</p> : null}
      {transfers.error ? <p role="alert">{transfers.error.message}</p> : null}
      {transfers.data?.events.length === 0 ? <p>No transfers in this page.</p> : null}
      <ul>
        {transfers.data?.events.map(event => (
          <li key={`${toBase58(event.transactionHash)}:${event.sequenceNumber}`}>
            {event.fields.amount.toString()} base units at block {event.blockHeight.toString()}
          </li>
        ))}
      </ul>
      <button disabled={transfers.isFetching} onClick={() => void transfers.refetch()}>
        Refresh transfers
      </button>
    </section>
  );
}
```

The query has fixed contract, event, start, and page-size inputs. If you make them configurable, include each input in the key. Include the cursor string when caching separate historical pages.



## Choose a history workflow

Refreshing the example starts at the head again. A saved `nextCursor` continues an older historical walk; it is not a subscription. Use the TypeScript [event pagination guidance](../pages/typescript/events.md) for iteration and durable checkpoints.

For live refresh, choose an explicit polling policy. Query caching does not create a background indexer or save progress across reloads.



## Decode transaction events

A receipt returned by an execution or receipt hook contains events. Use a generated descriptor’s `allFromReceipt` or `singleFromReceipt` with the emitting contract address.

A committed receipt can report failed execution. Check the result before treating its events as successful application activity. See [Track transaction results](../pages/react/transaction-status.md).

---

## Connect a wallet

Source: <https://thruput.network/docs/react/wallets/>

Build wallet and account selectors with explicit connection, network, and error states.

`useWallet` exposes discovered wallets, the selected account, and connection actions. `WalletProvider` manages discovery and session listeners; your components render the controls.

To install and fund a wallet for testing, follow [Wallet Extension](../pages/tools/wallet-extension.md).



## Select and connect a wallet

```tsx
import { useWallet } from "@thruputchain/react";

export function WalletControls() {
  const wallet = useWallet();
  const busy = wallet.status === "connecting" || wallet.status === "disconnecting";
  const authorized = wallet.status === "connected" || wallet.status === "wrongNetwork";

  return (
    <section aria-label="Wallet connection">
      <select
        aria-label="Wallet"
        value={wallet.provider?.info.id ?? ""}
        disabled={busy || wallet.providers.length === 0}
        onChange={event => wallet.selectProvider(event.target.value)}
      >
        <option value="" disabled>Choose a wallet</option>
        {wallet.providers.map(provider => (
          <option key={provider.info.id} value={provider.info.id}>{provider.info.name}</option>
        ))}
      </select>
      {wallet.providers.length === 0 ? <p>No wallet provider detected.</p> : null}
      {authorized ? (
        <button disabled={busy} onClick={() => void wallet.disconnect()}>Disconnect</button>
      ) : (
        <button disabled={busy || !wallet.provider} onClick={() => void wallet.connect()}>
          {wallet.status === "connecting" ? "Connecting…" : "Connect wallet"}
        </button>
      )}
      {wallet.status === "wrongNetwork" ? <p>Switch your wallet to the application's network.</p> : null}
      {wallet.error ? <p role="alert">{wallet.error.message}</p> : null}
    </section>
  );
}
```

Discovery selects the first provider without prompting. The user grants access through `connect()`. Provider names and IDs are display metadata, not proof of identity. The library supplies no branded buttons or wallet installation links.



## Select an authorized account

```tsx
import { useWallet } from "@thruputchain/react";

export function AccountSelector() {
  const wallet = useWallet();
  if (!wallet.session?.accounts.length) return null;

  return (
    <select
      aria-label="Account"
      value={wallet.address ?? ""}
      onChange={event => wallet.selectAccount(event.target.value)}
    >
      {wallet.session.accounts.map(account => (
        <option key={account.address} value={account.address}>{account.address}</option>
      ))}
    </select>
  );
}
```

Selection does not prompt. An unauthorized address or unknown provider sets `error` while preserving the current binding. Selecting another provider clears the local binding without revoking the previous provider’s permission.



## Interpret connection state

| State           | UI behavior                                                 |
| --------------- | ----------------------------------------------------------- |
| `disconnected`  | Offer connection when a provider is available               |
| `connecting`    | Show progress and prevent duplicate connection requests     |
| `connected`     | Enable supported signing actions                            |
| `disconnecting` | Local authorization is already cleared; wait for revocation |
| `wrongNetwork`  | Ask the user to switch networks; keep signing disabled      |

`connect()` and `disconnect()` resolve after handling the request. Read failures from `wallet.error`; those actions do not throw provider request failures. Signing and submission operations do reject on failure.



## Handle changes and cleanup

Session changes invalidate old signing bindings immediately. The provider binds a fresh client after event dispatch when possible, retaining the selected account if still authorized. Do not retain an old signing client for future operations.

Disconnect clears local authorization immediately. If remote revocation fails, the UI remains disconnected and exposes an error. Unmounting disposes the local binding without requesting revocation. Connection is explicit; there is no automatic reconnect or persisted connection.

Use the shared [wallet-provider error codes](../pages/tools/wallet-provider.md#errors) for application-specific messages. Do not infer transaction failure from a disconnected wallet; [receipt observation](../pages/react/transaction-status.md) uses the public client.

---

## Send transactions

Source: <https://thruput.network/docs/react/transactions/>

Use an explicit mutation to request approval, save signed transaction data, submit once, and show the result.

`useExecute` runs a wallet-backed transaction from a user action. It prepares, signs, awaits your persistence callback, submits once, and waits for successful execution. Both [providers](../pages/react/providers.md) are required.



## Execute a typed call

This component sends a small native-token transfer to an already funded recipient. The application supplies `savePending`, which must durably save the approved transaction before resolving:

```tsx
import { gasAmount, parseUnits, toBase58, TransactionObservationError, type ContractAddress } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { NATIVE_TOKEN_ADDRESS } from "@thruputchain/protocol";
import { useExecute, useWallet, type ExecuteVariables } from "@thruputchain/react";

type SavePending = ExecuteVariables["options"]["onSigned"];

export function SendNativeTokens({ receiver, savePending }: {
  receiver: ContractAddress;
  savePending: SavePending;
}) {
  const wallet = useWallet();
  const execution = useExecute();
  const unresolved = execution.error instanceof TransactionObservationError;

  function send() {
    execution.mutate({
      request: {
        invocation: ERC20.v0_1.transfer.invocation(NATIVE_TOKEN_ADDRESS, gasAmount(500_000n), {
          receiver,
          amount: parseUnits("0.0001", 7),
        }),
        gasLimit: gasAmount(1_000_000n),
      },
      options: { onSigned: savePending, wait: { timeoutMs: 60_000 } },
    });
  }

  return (
    <section aria-label="Send native tokens">
      <button disabled={wallet.status !== "connected" || execution.isPending || unresolved} onClick={send}>
        {execution.isPending ? "Waiting for approval or confirmation…" : "Send native tokens"}
      </button>
      {execution.error ? <p role="alert">{execution.error.message}</p> : null}
      {unresolved ? <p>Check the saved transaction before starting another transfer.</p> : null}
      {execution.data ? <p>Committed: {toBase58(execution.data.transactionHash)}</p> : null}
    </section>
  );
}
```

`mutate` exposes failures through mutation state. Use `mutateAsync` when an event handler needs to await the result, and handle its rejected promise. Trigger writes from user actions, not render effects.

The example budgets apply to this transfer, not every contract. See [gas and funding](../pages/typescript/transactions.md#set-gas-and-funding) for root and child limits and first-address storage funding.



## Save before submission

`onSigned` receives the `0x` hex signed transaction, its base58 `hash`, the account, and the original base58 network hash. Await the application’s durable write. A rejected callback prevents broadcast.

The query cache is not the pending-transaction store. Keep the saved record available after a reload, account change, or disconnect. Use it to [observe the original transaction](../pages/react/transaction-status.md) rather than automatically signing a replacement.



## Handle mutation state

| State       | Meaning                                                                               |
| ----------- | ------------------------------------------------------------------------------------- |
| `isPending` | Preparation, approval, persistence, submission, or receipt observation is in progress |
| `data`      | Successful committed execution with `transactionHash` and `receipt`                   |
| `error`     | Inspect the error boundary; an observation failure is not proof of failed execution   |

Mutation retries are disabled, including when the QueryClient’s defaults enable retries. A wallet change invalidates the captured signing binding; observation after broadcast can continue on the original network.

`reset()` clears mutation UI state. It does not cancel a transaction or resolve an unknown outcome. See the shared [execution error model](../pages/typescript/transaction-status.md#handle-execution-helper-errors).



## Decode returns and refresh reads

For typed child returns, use the current `useWalletClient()` binding’s `executeCallsAndWait` with the required persistence options. Keep its promise and UI state in the application’s write handler; `useExecute` returns the root execution result.

After commitment, explicitly [invalidate affected queries](../pages/react/queries.md#refresh-after-a-write). Capture their original account/token keys before starting the operation so a later account selection does not change the refresh target.

---

## Track transaction results

Source: <https://thruput.network/docs/react/transaction-status/>

Observe a saved transaction hash without wallet permission and distinguish query errors from execution failures.

`useWaitForTransactionReceipt` observes a hash through the public client. It works while the wallet is disconnected. Use a client on the transaction’s original network.



## Display a receipt

```tsx
import { useWaitForTransactionReceipt } from "@thruputchain/react";

export function TransactionStatus({ hash }: { hash: string | null }) {
  const receipt = useWaitForTransactionReceipt({
    hash: hash || null,
    wait: { timeoutMs: 60_000, pollingIntervalMs: 500 },
  });

  if (!hash) return <p>No transaction selected.</p>;
  if (receipt.error) {
    return (
      <section>
        <p role="alert">Observation stopped: {receipt.error.message}</p>
        <button disabled={receipt.isFetching} onClick={() => void receipt.refetch()}>
          Check again
        </button>
      </section>
    );
  }
  if (!receipt.data) return <p>Waiting for a committed receipt…</p>;

  const { execution } = receipt.data;
  const succeeded = "result" in execution && execution.result === "return";
  return (
    <p>
      {succeeded ? "Execution succeeded" : "Execution failed"}
      {" at block "}{receipt.data.blockHeight.toString()}
    </p>
  );
}
```

A failed committed execution is **receipt data**, not a query error. A query timeout means observation stopped, not that the transaction failed.



## Resume observation

Restore the saved base58 hash and its network from the application’s pending record. Missing hashes disable the query. Refetch explicitly to resume after a timeout; do not submit a new operation merely to obtain a result.

The SDK owns polling. The receipt query disables retries and automatic focus/reconnect refetching. Committed receipts have infinite stale time. Observers of the same hash share the query, so configure their timeout and polling settings consistently.

Canceling the query cancels observation, never the transaction.



## Interpret contract results

The receipt is for the transaction’s root method. A wallet-wrapped application call must be decoded through the wallet’s child results, not by treating the root as the application method. Use the [TypeScript receipt model](../pages/typescript/transaction-status.md#decode-the-correct-method).

Generated event descriptors can select receipt events by emitter and type. The application decides whether commitment completes its workflow; a queued request may require later events before the requested action is complete.

---

## React API reference

Source: <https://thruput.network/docs/react/reference/>

Provider props, wallet hooks, query hooks, transaction hooks, and reusable query factories.

| Entry point                                                     | Purpose                                                                                               |
| --------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `@thruputchain/react`                                           | All public React exports below                                                                        |
| [Setup](../pages/react/setup.md)                                | Installation and context wiring                                                                       |
| [TypeScript client reference](../pages/tools/typescript-sdk.md) | Shared SDK concepts and operations; use the client supported by the React package’s peer dependencies |
| [React source](https://github.com/thruputchain/thruput-react)   | Public declarations and implementation                                                                |



## WalletProvider

| Prop               | Type / behavior                                                                   |
| ------------------ | --------------------------------------------------------------------------------- |
| `client`           | Initialized `ConnectedThruputClient` with validated cluster identity; keep stable |
| `children`         | `ReactNode`                                                                       |
| `discoveryTarget?` | `EventTarget`; browser default is `window` after mounting                         |

| Context behavior   | Rule                                                                        |
| ------------------ | --------------------------------------------------------------------------- |
| Scope              | One application network and selected wallet connection                      |
| Discovery          | Automatic after mounting; first provider selected without prompting         |
| Connection         | Explicit; no automatic reconnect or persisted connection                    |
| Client replacement | Dispose binding and start disconnected, including same-network replacements |
| Server rendering   | Disconnected initial state; browser discovery after mount                   |
| Usage              | [Providers and clients](../pages/react/providers.md)                        |



## Wallet hooks

| Hook                | Result                                                           |
| ------------------- | ---------------------------------------------------------------- |
| `useClient()`       | The configured public client, including while disconnected       |
| `useWallet()`       | `WalletConnection`: reactive state and stable connection actions |
| `useWalletClient()` | Current provider-backed signing client or `null`                 |
| Context requirement | `WalletProvider`; no QueryClient required for these three hooks  |



### WalletConnection

| Field / action               | Meaning                                                                    |
| ---------------------------- | -------------------------------------------------------------------------- |
| `providers` / `provider`     | Discovered providers and selected provider                                 |
| `session`                    | Validated network and authorized accounts, or `null`                       |
| `account` / `address`        | Selected wire account and canonical base58 address, or `null`              |
| `networkHash`                | Expected application network in unprefixed base58                          |
| `status`                     | `disconnected`, `connecting`, `connected`, `disconnecting`, `wrongNetwork` |
| `error`                      | Latest connection/selection error, or `null`                               |
| `connect()` / `disconnect()` | `Promise<void>`; request failures appear in `error`                        |
| `selectProvider(id)`         | Select a discovered provider without prompting                             |
| `selectAccount(address)`     | Select an authorized account and recreate the binding                      |
| Usage                        | [Connect a wallet](../pages/react/wallets.md)                              |



## Contract reads

| API                               | Inputs / result                                                                                                 |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `useContractView(input)`          | Generated `method`, contract `address`, typed `args`, optional `caller`, `enabled`, `staleTime`                 |
| `contractViewQueryOptions(input)` | Same inputs plus explicit initialized `client`; reusable TanStack options                                       |
| Result                            | Query state and `queryKey`; data is `ContractView<R>` with `value`, `stateBlockHeight`, `gasUsed`, and `events` |
| Defaults                          | `enabled: true`, `staleTime: 0`; other query behavior follows the QueryClient                                   |
| Key                               | Client/network, decoder identity, contract address, entrypoint, encoded arguments, caller                       |
| Cancellation                      | Abort the view request and discard late results                                                                 |
| Validation                        | Arguments are encoded while constructing the query, even when disabled                                          |
| Usage                             | [Read contract data](../pages/react/reads.md)                                                                   |



## Balances

| API                                             | Inputs / result                                                                    |
| ----------------------------------------------- | ---------------------------------------------------------------------------------- |
| `useBalance({ address?, query? }?)`             | Native-token balance                                                               |
| `useTokenBalance({ token?, address?, query? })` | Standard ERC-20 balance                                                            |
| `BalanceAddress`                                | Base58 string or SDK-branded address bytes                                         |
| `BalanceData`                                   | `{ rawBalance: bigint; stateBlockHeight: bigint }`                                 |
| Hook result                                     | TanStack Query state plus `queryKey`; `query.select` can change observer data type |
| Omitted `address`                               | Connected account on the application’s network                                     |
| Explicit address                                | Read without wallet permission                                                     |
| Null address / missing token                    | Skip fetching                                                                      |
| Invalid address                                 | Query error state                                                                  |
| Cancellation                                    | Discard abandoned results; underlying balance RPC may finish                       |
| Usage                                           | [Read balances](../pages/react/balances.md)                                        |



### Balance query options

| Option                                                         | Behavior                                                     |
| -------------------------------------------------------------- | ------------------------------------------------------------ |
| `enabled`                                                      | Control automatic observer fetching                          |
| `staleTime`, `gcTime`                                          | Freshness and cache retention                                |
| `refetchInterval`, `refetchIntervalInBackground`               | Explicit polling                                             |
| `refetchOnMount`, `refetchOnReconnect`, `refetchOnWindowFocus` | Refresh triggers                                             |
| `retry`, `retryDelay`                                          | Read retry policy                                            |
| `select`                                                       | Transform observer data; cache remains raw `BalanceData`     |
| Key / fetch function                                           | Owned by the library; not configurable through these options |



## Transaction execution

| API / field                | Behavior                                                                          |
| -------------------------- | --------------------------------------------------------------------------------- |
| `useExecute()`             | TanStack mutation through the current wallet                                      |
| `ExecuteVariables.request` | SDK `PrepareExecutionRequest`: inner invocation, root budget, transaction options |
| `ExecuteVariables.options` | Required `onSigned`; optional `wait` observation controls                         |
| `mutate(variables)`        | Start from an event handler; expose mutation state                                |
| `mutateAsync(variables)`   | Await execution; rejects on failure                                               |
| Successful data            | `{ transactionHash, receipt }` after successful committed execution               |
| Retry                      | Always disabled by the hook                                                       |
| Invalidation               | Application-owned; no automatic balance refresh                                   |
| Typed child results        | Use the signing client’s `executeCallsAndWait`                                    |
| Usage                      | [Send transactions](../pages/react/transactions.md)                               |



## Receipt observation

| API / option                                      | Behavior                                                                        |
| ------------------------------------------------- | ------------------------------------------------------------------------------- |
| `useWaitForTransactionReceipt({ hash?, wait? }?)` | Public observation; wallet connection not required                              |
| `hash`                                            | Base58 string; `null` or `undefined` skips fetching                             |
| `wait.timeoutMs` / `pollingIntervalMs`            | SDK observation settings; configure consistently for the same hash              |
| Data                                              | `TransactionReceipt`, including failed committed execution                      |
| Query error                                       | Observation failure, not proof of failed execution                              |
| `queryKey`                                        | Client/network-scoped canonical hash                                            |
| Defaults                                          | Infinite stale time; no query retry, focus/reconnect refetch, or retry on mount |
| Cancellation                                      | Cancels observation, never the transaction                                      |
| Usage                                             | [Track transaction results](../pages/react/transaction-status.md)               |



## Query factories and keys

| Export                           | Inputs / purpose                                                                         |
| -------------------------------- | ---------------------------------------------------------------------------------------- |
| `balanceQueryOptions`            | Explicit client, address, optional balance-query settings                                |
| `tokenBalanceQueryOptions`       | Explicit client, address, token, optional balance-query settings                         |
| `contractViewQueryOptions`       | Explicit client and typed view inputs                                                    |
| `transactionReceiptQueryOptions` | Explicit client, hash, and wait settings                                                 |
| `getClientQueryKey(client)`      | Stable-value network/client prefix for custom query keys                                 |
| Factory context                  | No hook or provider required; use the same client instance to share cache entries        |
| Missing balance inputs           | Skipped query; do not use imperative fetch with missing inputs                           |
| Cache lifetime                   | In-memory client identity; not portable for persisted caches or server/browser hydration |
| Usage                            | [Cache and refresh data](../pages/react/queries.md)                                      |
