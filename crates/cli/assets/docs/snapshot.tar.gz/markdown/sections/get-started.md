# Get Started

Documentation source: `1a24dab12e61451e433e7cf043671d87a3194e81`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Get Started

Source: <https://thruput.network/get-started/>

Choose a starting point for Stellar Thruput contracts, applications, or coding agents.

Get a working result on Futurenet. Choose the tools you want to use; you do not need to follow every path.



## Choose your path

- **[CLI quickstart](../pages/get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](../pages/get-started/contract.md):** build and test a counter, deploy it to Futurenet, and read its updated value.
- **[TypeScript quickstart](../pages/get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](../pages/get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.



## Work with a coding agent

[Build with an Agent](../pages/start/build-with-an-agent.md) gives you one prompt to install the tools, fund a wallet, and deploy and call a counter on Futurenet. For a smaller task, use the prompt in an individual quickstart.



## What you need

CLI and contract work use the [Thruput CLI and Cargo registry](../pages/cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](../pages/typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Futurenet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.



## Build a complete application

Follow the four-part [Build a counter](../pages/tutorials/build-a-counter.md) guide from contract to TypeScript, React, and a wallet-approved update. Each part builds on the project from the previous part.

For token and AMM contract projects, see [Guides](../pages/guides.md). New to the platform? Read the [Introduction](../pages/architecture.md) before choosing a path.

---

## CLI quickstart

Source: <https://thruput.network/get-started/cli/>

Create a Futurenet wallet, request native test tokens, and inspect your first transaction from the terminal.

Create a wallet on Futurenet, fund it with native test tokens, and inspect the funding transaction. These tokens have no monetary value. You do not need a contract project or a local node.

**Before you start:** [install the latest CLI](../pages/cli/install.md). Run these commands outside an existing Stellar Thruput project so they use your global configuration.



## 1. Set up the CLI

```bash
thruput init
thruput config use futurenet
```

On a fresh installation, accept signing-key creation and decline starter-project creation. Setup creates the `default` key and the `local` and `futurenet` network profiles. Selecting `futurenet` sets the global default, so later commands and new projects use it without a `--profile` flag.



## 2. Create a wallet

```bash
thruput wallet create
```

Confirm the prompt. The CLI saves a wallet address for your selected key. Creating this wallet does not fund it or send a transaction.

```bash
thruput wallet ls
```

You should see your wallet’s name and address. With a fresh setup, its name is `default`.



## 3. Request test funds

```bash
thruput airdrop
thruput balance
```

Confirm the airdrop and wait for its result. You should have a positive native-token balance. Save the transaction hash printed by the airdrop command.

The faucet selects the test-token amount; you do not need an amount flag. CLI output currently labels the native token `HOG`.



## 4. Inspect the transaction

Replace `TX_HASH` with the hash from the airdrop:

```bash
thruput tx show TX_HASH
```

Check that the transaction committed successfully. You now have a funded wallet and have verified an onchain result.



## Next

[Deploy your first contract](../pages/get-started/contract.md) using this wallet.

If funding is pending, rerun the same airdrop command to resume the request. For network errors or faucet limits, see [Faucet](../pages/tools/faucet.md).



## Use a coding agent

Copy this prompt into your agent:

```text
Help me complete the Thruput CLI quickstart:
https://thruput.network/docs/get-started/cli/
Use the latest CLI, install the thruput skill, and read thruput skill show cli.
Run thruput init, then thruput config use futurenet outside a project.
Set up a Futurenet wallet without creating a contract project or running a local node.
Preserve any existing keys and configuration. Request test funds,
check the wallet balance, and inspect the airdrop transaction.
Report success only after checking the committed transaction result.
Ask me to supply any required registry access through my environment,
not in this conversation. Report a network failure rather than bypassing it.
```

---

## Contract quickstart

Source: <https://thruput.network/get-started/contract/>

Create, test, and deploy a Rust counter contract to Stellar Thruput Futurenet.

Deploy a counter to Futurenet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](../pages/get-started/cli.md) so you have the latest CLI and a funded Futurenet wallet. Keep your [Cargo registry access](../pages/cli/install.md#configure-cargo-access) available in this terminal.



## 1. Create a contract

```bash
thruput new my-counter --template counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`. The counter uses [Balance](../pages/programming-model/storage-types.md#balance) for nonnegative counts.



## 2. Build and test

```bash
thruput build
thruput test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.

The generated project follows your global Futurenet selection. Check it with `thruput config get` before deploying.



## 3. Deploy to Futurenet

```bash
thruput deploy --estimate
```

Read the reported minimum funding in whole native tokens. Add **10 native test tokens** as this walkthrough’s storage allowance, then replace `TOTAL_FUNDING` below with that decimal total. The allowance is an example budget, not an estimate of initializer writes or a universal requirement. These tokens have no monetary value. See [deployment estimates](../pages/cli/deploy-and-call.md#estimate-deployment-funding) for the breakdown.

```bash
thruput deploy --fund TOTAL_FUNDING \
  --init initialize --init-arg 10
```

Confirm the deployment. Funding, deployment, and initialization happen atomically. The CLI prints the contract address and saves the alias `my-counter` in the project’s Futurenet profile. The sender also needs its own storage and scheduling capacity.



## 4. Change the counter

Increase the counter initialized during deployment:

```bash
thruput call my-counter increment 5
```

Confirm the call and wait for success. Do not initialize again: this example method adds the initial amount rather than enforcing one-time initialization.



## 5. Read the result

```bash
thruput view my-counter get
```

The result should be **15**. You have built, tested, deployed, and called a contract on Futurenet.



## Next

[Build a Counter](../pages/tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](../pages/contracts/project-structure.md).



## Use a coding agent

```text
Help me complete the Stellar Thruput contract quickstart:
https://thruput.network/docs/get-started/contract/
Use the latest CLI, install the thruput skill for this project, and read
thruput skill show contracts. Scaffold with --template counter. Check CLI setup and
Futurenet funding first. Scaffold my-counter, preserve its generated
dependency and compiler settings, then build and test it.
Read the deployment estimate and add the documented storage allowance to its
minimum. Deploy with that explicit total and initialize atomically to 10,
increment by 5, and verify that the view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```

---

## TypeScript quickstart

Source: <https://thruput.network/get-started/typescript/>

Connect to Futurenet and read the native-token contract with a typed TypeScript client.

Read the native token’s total supply from Futurenet with a typed contract call. This experimental token has no monetary value. This path needs Node.js and package access, but no CLI, signing key, or contract deployment.



## 1. Create a project

```bash
mkdir my-thruput-app
cd my-thruput-app
npm init -y
npm pkg set type=module
mkdir -p src
```

Configure [npm package access](../pages/typescript/setup.md#give-npm-package-access) in this directory, then install the latest SDK and a TypeScript runner:

```bash
npm install @thruputchain/client @thruputchain/protocol
npm install --save-dev typescript tsx @types/node
```



## 2. Read a contract

Create `src/index.ts`:

```ts
import { createThruputClient, devnet, formatUnits, getContract } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";

async function main() {
  const client = await createThruputClient({ cluster: devnet() });
  const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
  const supply = await hog.totalSupply.view({ args: undefined });

  console.log("Native-token supply:", formatUnits(supply.value, 7));
  console.log("Read at block:", supply.stateBlockHeight.toString());
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
```

`devnet()` selects the hosted network. The SDK includes the native-token contract’s standard binding, and `HOG_ADDRESS` is its protocol constant, so you do not need to generate a binding. `supply.value` is a typed integer; formatting it displays whole-token units rather than base units.



## 3. Run it

```bash
npx tsx src/index.ts
```

You should see **Native-token supply** and **Read at block**, each followed by a value. Run the command again to make another read. The values come from Futurenet and can change; there is no fixed expected block number.

This is a read-only call. It does not request wallet permission or submit a transaction.



## Next

Use [Read contract data](../pages/typescript/reads.md) for arguments, caller context, and cancellation, or [Connect a wallet](../pages/tools/wallet-integration.md) to add signing and transaction submission.



## Use a coding agent

```text
Build the Stellar Thruput TypeScript quickstart:
https://thruput.network/docs/get-started/typescript/
Use the latest published SDK packages and the hosted Futurenet.
Configure package access through my environment. Create the typed native-token
total-supply read shown in the guide and run it. Show the actual supply
and block height, or report the exact error if the request fails.
Do not install the Rust toolchain, deploy a contract, or create a wallet
for this read-only example. Keep the generated package lockfile.
```

---

## React quickstart

Source: <https://thruput.network/get-started/react/>

Display live Futurenet contract data in React with a typed query and a refresh action.

Build a React page that reads the native token’s total supply from Futurenet and refreshes it on demand. This experimental token has no monetary value. You do not need a wallet, the CLI, or your own contract.



## 1. Create the application

Use the current Node.js LTS release:

```bash
npm create vite@latest my-thruput-ui -- --template react-ts
cd my-thruput-ui
```

Configure [npm package access](../pages/typescript/setup.md#give-npm-package-access) in this directory, then install the application dependencies:

```bash
npm install
npm install @thruputchain/react @thruputchain/client @thruputchain/protocol @tanstack/react-query
```



## 2. Connect the providers

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createThruputClient, devnet } from "@thruputchain/client";
import { WalletProvider } from "@thruputchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Futurenet…</p>);

async function start() {
  const client = await createThruputClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Futurenet"}</p>,
  );
});
```

The client and query cache are created once. `WalletProvider` makes the client available to Stellar Thruput hooks; it does not connect a wallet automatically.



## 3. Display the result

Replace `src/App.tsx`:

```tsx
import { formatUnits } from "@thruputchain/client";
import { ERC20 } from "@thruputchain/client/contracts";
import { HOG_ADDRESS } from "@thruputchain/protocol";
import { useContractView } from "@thruputchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    address: HOG_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>Native token on Futurenet</h1>
      {supply.isPending && <p>Reading the contract…</p>}
      {supply.error && <p role="alert">{supply.error.message}</p>}
      {supply.data && (
        <>
          <p>Supply: {formatUnits(supply.data.value, 7)} native tokens</p>
          <p>Read at block: {supply.data.stateBlockHeight.toString()}</p>
        </>
      )}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

The hook runs the typed view and exposes loading, error, and data states. Refresh makes another network read; it does not send a transaction.



## 4. Open the app

```bash
npm run dev
```

Open the local URL printed by Vite. The page should show a supply value and block height. Click **Refresh** and confirm that the page finishes another read. Also check that the project builds:

```bash
npm run build
```



## Next

See [Read contract data](../pages/react/reads.md) for arguments and query behavior, or [Connect a wallet](../pages/react/wallets.md) to add wallet controls. [Send transactions](../pages/react/transactions.md) covers approval and execution state.



## Use a coding agent

```text
Build the Stellar Thruput React quickstart:
https://thruput.network/docs/get-started/react/
Use a React TypeScript Vite project, the latest published Stellar Thruput
packages, and hosted Futurenet. Configure package access through my environment.
Display the native-token total supply and its read height with useContractView.
Include loading and error states and a Refresh button. Run the build
and verify the actual page result. No CLI, contract deployment, or wallet
connection is needed for this read-only example. Report package or network
errors rather than forcing incompatible dependencies or faking results.
```

---

## Build with an Agent

Source: <https://thruput.network/start/build-with-an-agent/>

Give your coding agent one prompt to install the Thruput CLI, fund a wallet, and deploy and call a counter contract on Stellar Thruput Futurenet.

Paste this prompt into your coding agent. It will install the CLI and skill, read an exported copy of the docs, and build and verify a counter contract on Futurenet.



## Copy the prompt

```text
Help me deploy and use my first Stellar Thruput counter contract on Futurenet.

1. Install the latest Thruput CLI and run thruput init. Use
   thruput --help to see all available commands. Follow the installation
   instructions at https://thruput.network/docs/cli/install/.
2. Install the thruput skill for this project and coding agent with
   thruput skill install, then read the installed skill.
3. Export the documentation into a new folder with thruput docs export.
   Read its index and the relevant setup and contract instructions.
4. Outside a project, run thruput config use futurenet to select the global
   default. Create a wallet with thruput wallet create, then request test funds
   with thruput airdrop. Verify the balance before deployment.
5. Run thruput new counter --template counter, enter the project directory,
   and check thruput config get still selects futurenet. New projects inherit
   the global default. Build the contract and run its tests.
6. Deploy and initialize the counter to 10. Call increment with 5,
   then verify that its read-only view returns 15.

Finish with the project location, contract address, transaction hashes,
verified counter value, and the CLI commands I can use next.
```

The agent follows the [CLI](../pages/get-started/cli.md) and [contract](../pages/get-started/contract.md) quickstarts. Provide repository or registry access through your local environment when requested.

See [Skills and local docs](../pages/cli/agent-tools.md) for installation requirements, agent selection, and Markdown export. For a smaller task, use the prompt in an individual [quickstart](../pages/get-started.md).
