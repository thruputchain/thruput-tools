# Get Started

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## CLI quickstart

Source: <https://docs.groundhog.dev/get-started/cli/>

Create a Devnet wallet, request test HOG, and inspect your first transaction from the terminal.

Create a wallet on Devnet, fund it with test HOG, and inspect the funding transaction. You do not need a contract project or a local node.

**Before you start:** [install the latest CLI](../pages/cli/install.md). Run these commands outside an existing Groundhog project so they use your global configuration.



## 1. Set up the CLI

```bash
groundhog init
```

On a fresh installation, accept signing-key creation and decline starter-project creation. Setup creates the `default` key and the built-in network profiles.



## 2. Create a wallet

```bash
groundhog wallet create --profile devnet
```

Confirm the prompt. The CLI saves a wallet address for your selected key. Creating this wallet does not fund it or send a transaction.

```bash
groundhog wallet ls --profile devnet
```

You should see your wallet’s name and address. With a fresh setup, its name is `default`.



## 3. Request test funds

```bash
groundhog airdrop --profile devnet
groundhog balance --profile devnet
```

Confirm the airdrop and wait for its result. You should have a positive HOG balance. Save the transaction hash printed by the airdrop command.

Devnet HOG is for testing. The faucet selects the amount; you do not need an amount flag.



## 4. Inspect the transaction

Replace `TX_HASH` with the hash from the airdrop:

```bash
groundhog tx show TX_HASH --profile devnet
```

Check that the transaction committed successfully. You now have a funded wallet and have verified an onchain result.



## Next

[Deploy your first contract](../pages/get-started/contract.md) using this wallet.

If funding is pending, rerun the same airdrop command to resume the request. For network errors or faucet limits, see [Faucet](../pages/tools/faucet.md).



## Use a coding agent

Copy this prompt into your agent:

```text
Help me complete the Groundhog CLI quickstart:
https://docs.groundhog.dev/get-started/cli/
Use the latest CLI and read groundhog skill show cli. Set up a Devnet
wallet without creating a contract project or running a local node.
Preserve any existing keys and configuration. Request test funds,
check the wallet balance, and inspect the airdrop transaction.
Report success only after checking the committed transaction result.
Ask me to supply any required registry access through my environment,
not in this conversation. Report a network failure rather than bypassing it.
```

---

## Contract quickstart

Source: <https://docs.groundhog.dev/get-started/contract/>

Create, test, and deploy a Rust counter contract to Groundhog Devnet.

Deploy a counter to Devnet, increase its value, and read the result.

**Before you start:** complete the [CLI quickstart](../pages/get-started/cli.md) so you have the latest CLI and a funded Devnet wallet. Keep your [Cargo registry access](../pages/cli/install.md#configure-cargo-access) available in this terminal.



## 1. Create a contract

```bash
groundhog new my-counter
cd my-counter
```

The project includes a Rust counter and tests. Its main methods are `initialize`, `increment`, `decrement`, and `get`.



## 2. Build and test

```bash
groundhog build
groundhog test
```

The first build installs the compiler components selected by the project. Wait for the build and tests to finish successfully.

These commands run on your machine. You do not need to start a local blockchain.



## 3. Deploy to Devnet

```bash
groundhog deploy --profile devnet --fund 10
```

Confirm the deployment. The CLI prints the contract address and saves the alias `my-counter` in the project’s Devnet profile.

`--fund 10` transfers 10 test HOG to the contract for this example’s storage. It is a funding amount, not a fixed deployment fee.



## 4. Change the counter

Initialize this new counter, then increase it:

```bash
groundhog call my-counter initialize 10 --profile devnet
groundhog call my-counter increment 5 --profile devnet
```

Confirm each call and wait for success. Run `initialize` only once for this walkthrough; this example method adds the initial amount rather than enforcing one-time initialization.



## 5. Read the result

```bash
groundhog view my-counter get --profile devnet
```

The result should be **15**. You have built, tested, deployed, and called a contract on Devnet.



## Next

[Build a Counter](../pages/tutorials/build-a-counter.md) explains the contract and its tests. For the generated files and build artifacts, see [Project structure](../pages/contracts/project-structure.md).



## Use a coding agent

```text
Help me complete the Groundhog contract quickstart:
https://docs.groundhog.dev/get-started/contract/
Use the latest CLI and read groundhog skill show contracts. Check CLI setup and
Devnet funding first. Scaffold my-counter, preserve its generated
dependency and compiler settings, then build and test it.
Deploy to Devnet with the documented contract funding, initialize
the new counter to 10, increment by 5, and verify that its view returns 15.
Do not start a local node or repeat initialization on an existing counter.
Report the actual build, test, deployment, and read results separately.
```

---

## Get Started

Source: <https://docs.groundhog.dev/get-started/>

Choose a starting point for Groundhog contracts, applications, or coding agents.

Get a working result on Devnet. Choose the tools you want to use; you do not need to follow every path.



## Choose your path

- **[CLI quickstart](../pages/get-started/cli.md):** create a wallet, request test funds, and inspect a transaction.
- **[Contract quickstart](../pages/get-started/contract.md):** build and test a counter, deploy it to Devnet, and read its updated value.
- **[TypeScript quickstart](../pages/get-started/typescript.md):** read an existing contract from a small script. No Rust or wallet required.
- **[React quickstart](../pages/get-started/react.md):** display contract data and refresh it from an interface. No contract deployment required.



## Work with a coding agent

[Build with an Agent](../pages/start/build-with-an-agent.md) gives you two setup commands and one prompt for a complete counter application on Devnet. For a smaller task, use the prompt in an individual quickstart.



## What you need

CLI and contract work use the [Groundhog CLI and Cargo registry](../pages/cli/install.md). TypeScript and React applications use [Node.js and GitHub Packages](../pages/typescript/setup.md). Install the latest releases; the quickstarts link to the setup they need.

Devnet is a shared test network and can be reset. Keep your development keys, but expect to request new test funds or redeploy after a reset.

For a worked project, go to [Guides](../pages/guides.md). New to the platform? Read the [Introduction](../pages/architecture.md) before choosing a path.

---

## React quickstart

Source: <https://docs.groundhog.dev/get-started/react/>

Display live Devnet contract data in React with a typed query and a refresh action.

Build a React page that reads the HOG token’s total supply from Devnet and refreshes it on demand. You do not need a wallet, the CLI, or your own contract.



## 1. Create the application

Use the current Node.js LTS release:

```bash
npm create vite@latest my-groundhog-ui -- --template react-ts
cd my-groundhog-ui
```

Complete [package setup](../pages/typescript/setup.md) in this directory, then install the application dependencies:

```bash
npm install
npm install @groundhogchain/react @groundhogchain/client @groundhogchain/protocol @tanstack/react-query
```



## 2. Connect the providers

Replace `src/main.tsx`:

```tsx
import { createRoot } from "react-dom/client";
import { createGroundhogClient, devnet } from "@groundhogchain/client";
import { WalletProvider } from "@groundhogchain/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<p>Connecting to Devnet…</p>);

async function start() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const queries = new QueryClient();

  root.render(
    <QueryClientProvider client={queries}>
      <WalletProvider client={client}>
        <App />
      </WalletProvider>
    </QueryClientProvider>,
  );
}

start().catch((error: unknown) => {
  root.render(
    <p role="alert">{error instanceof Error ? error.message : "Could not connect to Devnet"}</p>,
  );
});
```

The client and query cache are created once. `WalletProvider` makes the client available to Groundhog hooks; it does not connect a wallet automatically.



## 3. Display the result

Replace `src/App.tsx`:

```tsx
import { formatUnits } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";
import { useContractView } from "@groundhogchain/react";

export default function App() {
  const supply = useContractView({
    method: ERC20.v0_1.totalSupply,
    contract: HOG_ADDRESS,
    args: undefined,
  });

  return (
    <main>
      <h1>HOG on Devnet</h1>
      {supply.isPending && <p>Reading the contract…</p>}
      {supply.error && <p role="alert">{supply.error.message}</p>}
      {supply.data && (
        <>
          <p>Supply: {formatUnits(supply.data.value, 7)} HOG</p>
          <p>Read at block: {supply.data.height.toString()}</p>
        </>
      )}
      <button disabled={supply.isFetching} onClick={() => void supply.refetch()}>
        {supply.isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </main>
  );
}
```

The hook runs the typed view and exposes loading, error, and data states. Refresh makes another network read; it does not send a transaction.



## 4. Open the app

```bash
npm run dev
```

Open the local URL printed by Vite. The page should show a supply value and block height. Click **Refresh** and confirm that the page finishes another read. Also check that the project builds:

```bash
npm run build
```



## Next

See [Read contract data](../pages/react/reads.md) for arguments and query behavior, or [Connect a wallet](../pages/react/wallets.md) to add wallet controls. [Send transactions](../pages/react/transactions.md) covers approval and execution state.



## Use a coding agent

```text
Build the Groundhog React quickstart:
https://docs.groundhog.dev/get-started/react/
Use a React TypeScript Vite project, the latest published Groundhog
packages, and hosted Devnet. Configure package access through my environment.
Display the HOG total supply and its read height with useContractView.
Include loading and error states and a Refresh button. Run the build
and verify the actual page result. No CLI, contract deployment, or wallet
connection is needed for this read-only example. Report package or network
errors rather than forcing incompatible dependencies or faking results.
```

---

## TypeScript quickstart

Source: <https://docs.groundhog.dev/get-started/typescript/>

Connect to Devnet and read the native HOG contract with a typed TypeScript client.

Read the HOG token’s total supply from Devnet with a typed contract call. This path needs Node.js and package access, but no CLI, signing key, or contract deployment.



## 1. Create a project

```bash
mkdir my-groundhog-app
cd my-groundhog-app
npm init -y
npm pkg set type=module
```

Complete [package setup](../pages/typescript/setup.md) in this directory, then install the latest SDK and a TypeScript runner:

```bash
npm install @groundhogchain/client @groundhogchain/protocol
npm install --save-dev typescript tsx @types/node
```



## 2. Read a contract

Create `index.ts`:

```ts
import { createGroundhogClient, devnet, formatUnits, getContract } from "@groundhogchain/client";
import { ERC20 } from "@groundhogchain/client/contracts";
import { HOG_ADDRESS } from "@groundhogchain/protocol";

async function main() {
  const client = await createGroundhogClient({ cluster: devnet() });
  const hog = getContract({ binding: ERC20.v0_1, address: HOG_ADDRESS, client });
  const supply = await hog.totalSupply.view({ args: undefined });

  console.log("HOG supply:", formatUnits(supply.value, 7));
  console.log("Read at block:", supply.height.toString());
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
```

`devnet()` selects the hosted network. The SDK includes the HOG contract’s standard binding, so you do not need to generate one. `supply.value` is a typed integer; formatting it displays HOG rather than base units.



## 3. Run it

```bash
npx tsx index.ts
```

You should see **HOG supply** and **Read at block**, each followed by a value. Run the command again to make another read. The values come from Devnet and can change; there is no fixed expected block number.

This is a read-only call. It does not request wallet permission or submit a transaction.



## Next

Use [Read contract data](../pages/typescript/reads.md) for arguments, caller context, and cancellation, or [Connect a wallet](../pages/tools/wallet-integration.md) to add signing and transaction submission.



## Use a coding agent

```text
Build the Groundhog TypeScript quickstart:
https://docs.groundhog.dev/get-started/typescript/
Use the latest published SDK packages and the hosted Devnet.
Configure package access through my environment. Create the typed HOG
total-supply read shown in the guide and run it. Show the actual supply
and block height, or report the exact error if the request fails.
Do not install the Rust toolchain, deploy a contract, or create a wallet
for this read-only example. Keep the generated package lockfile.
```

---

## Build with an Agent

Source: <https://docs.groundhog.dev/start/build-with-an-agent/>

Give your coding agent the Groundhog skill and docs, then build a counter application on Devnet with one prompt.

Give your agent the Groundhog instructions and docs, then copy the prompt below. The goal is a working counter application: a Rust contract on Devnet, typed bindings, and a React interface.



## 1. Install the skill

Run:

```bash
groundhog skill install
```

Select your coding agent and installation scope. This requires Node.js 22.20 or newer, npm, Git, and access to the private `groundhogchain/agent-skills` repository. Use existing Git, GitHub CLI, or SSH authentication. If the CLI is missing, start with [Install the CLI](../pages/cli/install.md).

For offline reading, your agent can use `groundhog skill show` and then read a topic such as `groundhog skill show contracts`. This reads the CLI’s bundled skill, which can differ from the latest installed skill.



## 2. Share the docs

```bash
groundhog docs --background
```

Give your agent the printed Markdown index path. Open the printed browser URL for your own reading. This serves documentation, not a local blockchain. Use `groundhog docs stop` when you finish; the Markdown files remain available.

For an agent on another machine, use `groundhog docs export --output ./groundhog-docs` and share that folder. The destination must be new. The agent can start with `index.md`, choose a page, or read a bundle under `sections/`. `full.md` contains everything. Bundled docs are a snapshot; use the installed CLI’s help to confirm command behavior.



## 3. Copy the prompt

```text
Build a working Groundhog counter application for me on Devnet.

First read this project's AGENTS.md if present, run groundhog skill show,
and read the documentation at the URL or in the files I share. If you
cannot access the docs, ask me for a copy before guessing at an API.

Use the latest release installation instructions and preserve generated
dependency settings and lockfiles. Work in a new project unless I ask
you to extend an existing one. Preserve existing files, keys, and profiles.
Ask me to provide any missing Cargo or npm access through my environment.
Keep credentials and private keys out of this conversation and browser code.

Build and verify these stages:

1. Set up the CLI and a funded Devnet wallet. Use the hosted network;
   do not start a local blockchain node. A local documentation or app
   development server is fine.

2. Scaffold a Rust counter contract with the CLI. Build it and run its
   tests. Deploy it to Devnet with the funding described in the contract
   quickstart. Initialize the new counter to 10, increment by 5, and
   verify that its read-only view returns 15. Do not repeat initialization
   on a counter that has already been initialized for this walkthrough.

3. Generate TypeScript bindings from that contract's spec. Use the actual
   deployment address and generated methods rather than handwritten
   entrypoint IDs or a hardcoded example address.

4. Build a small React interface that displays the counter and has an
   Increment button. Use the Groundhog React library and typed bindings.
   Include loading, error, and pending-transaction states. Use a compatible
   browser wallet for signing; ask me to install or connect it and approve
   the test transaction when needed. Do not put a CLI signing key in the app.

5. Save the transaction evidence needed for recovery before broadcasting,
   wait for successful committed execution, and refresh the counter.
   Prevent duplicate submissions while a request is pending. If the outcome
   is uncertain, check the original transaction instead of signing another.

6. Run the app's build and test the browser flow. Verify that one successful
   increment changes the displayed counter by one. If wallet approval or
   a network service is unavailable, state which stage remains unverified.
   Do not replace a failed Devnet call with a mock and report success.

Use the CLI and contract quickstarts for setup and deployment, the
TypeScript binding docs for code generation, and the React and wallet
integration docs for the interface. Use groundhog <command> --help to
confirm command options. Adapt the read-only React quickstart to this
counter rather than treating it as a complete wallet application.

Finish with the project location, how to run the app, its contract address,
the transaction hashes you verified, and a short summary of what passed
and what still needs my action.
```

The prompt uses the [CLI](../pages/get-started/cli.md) and [contract](../pages/get-started/contract.md) quickstarts, [TypeScript bindings](../pages/tools/typescript-bindings.md), [React](../pages/react.md), and [wallet integration](../pages/tools/wallet-integration.md). Your agent can work through them while you provide access and approve wallet interactions.

For a smaller task, use the prompt in an individual [quickstart](../pages/get-started.md).
