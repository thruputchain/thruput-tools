# CLI

Documentation source: `186564d64f845490f9ea3fc1cfd6dd7bf9591c99`. Hosted docs may be newer than this snapshot.

## CLI

Source: <https://thruput.network/cli/>

Install the Thruput CLI, configure networks, and build, test, deploy, and call contracts.

`thruput` is the command-line tool for working with Project Thruput projects and networks. Use it to create a project, build and test a contract, run a local node, or interact with a deployed contract.



## Projects and networks

The CLI works with two kinds of configuration:

- A **project** contains your Rust contract, tests, and build settings.
- A **profile** selects the network and identity used for an interaction.

This lets you build a contract once and use profiles to target a local node or Futurenet. You can also use network commands without creating a contract project.



## The development loop

| Task                        | Command          |
| --------------------------- | ---------------- |
| Create a contract project   | `thruput new`    |
| Build a contract artifact   | `thruput build`  |
| Run contract artifact tests | `thruput test`   |
| Start a local node          | `thruput node`   |
| Deploy a contract           | `thruput deploy` |
| Call a deployed contract    | `thruput call`   |

These are command names, not a setup script. Start with [installation](../pages/cli/install.md), then follow the [CLI quickstart](../pages/get-started/cli.md) for a first Futurenet interaction.

The [contract quickstart](../pages/get-started/contract.md) adds deployment and calls. Use [Run a local node](../pages/cli/local-node.md) when you want a disposable node on your machine.



## Look up an option

Run `thruput <command> --help` for the installed version’s options, or use the [command reference](../pages/cli/reference.md). [Profiles and networks](../pages/cli/configuration.md) explains profile selection and project overrides.

Use [Skills and local docs](../pages/cli/agent-tools.md) to install agent guidance, read bundled references, and serve or export documentation. [Build with an Agent](../pages/start/build-with-an-agent.md) combines setup with a first-project prompt.

---

## Install the CLI

Source: <https://thruput.network/cli/install/>

Install the latest Thruput CLI and prepare Cargo access for contract development.

Install the latest `thruput` release. The CLI selects the dependencies and compiler settings for projects it creates; you do not need to choose SDK or node versions.



## Before you start

- Install the current stable Rust toolchain with [rustup](https://rustup.rs/).
- Obtain access to the Project Thruput Cargo registry from your onboarding contact. Repository access alone does not grant package access.

Check that Cargo is available:

```bash
cargo --version
```



## Configure Cargo access

Set the registry address and credential provider in your shell:

```bash
export CARGO_REGISTRIES_THRUPUT_INDEX="sparse+https://crates.thruput.network/api/v1/crates/"
export CARGO_REGISTRIES_THRUPUT_CREDENTIAL_PROVIDER=cargo:token
```

Supply `CARGO_REGISTRIES_THRUPUT_TOKEN` through your credential manager or onboarding environment. Keep the token out of project files and agent prompts. If you already use a Cargo credential manager for this registry, keep its provider instead.

Use the same registry access in terminals where you build contracts. The generated project includes the registry address, but it does not include your credentials.



## Install with Cargo

```bash
cargo install thruput-cli --registry thruput --locked
thruput --version
```

The first command installs the latest CLI with its release’s dependency lockfile. The second should print the installed CLI version.

Cargo installs executables in `~/.cargo/bin`. If `thruput` is not found, add that directory to your shell’s `PATH` and open a new terminal.



## Set up the local runtime

Local nodes and RPC integration tests use `hog-devnode`. The CLI selects a compatible runtime from its bundled catalog and can download it when needed. To inspect available versions and install the selected runtime in advance:

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

`list` shows the runtime catalog and installed versions. `install` downloads and verifies the selected runtime bundle. `which` shows the selected binary’s path.

On Linux, a local node requires the system jemalloc and Snappy libraries. If an error names `libjemalloc.so.2` or `libsnappy.so.1`, install your distribution’s corresponding packages (`libjemalloc2` and `libsnappy1v5` on Ubuntu).

These commands manage the local-node runtime. Rust is managed through `rustup`, and the CLI is installed separately as shown above. You do not need a local node to use Futurenet.

See [runtime selection](../pages/cli/local-node.md#runtime-selection) for version and binary overrides.



## Update an existing installation

Run the same `cargo install` command to install the latest release. Keep the `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml` generated for each project rather than replacing them with files from another example.

If an older executable is still selected, check its location:

```bash
command -v thruput
thruput --version
```

---

## Profiles and networks

Source: <https://thruput.network/cli/configuration/>

Select Futurenet, local development, or a custom endpoint and manage global and project configuration.

A profile selects the network, endpoint, and account settings for a command. Global profiles are reusable across projects; a project’s `thruput.toml` can override them.



## Inspect the current settings

```bash
thruput config profiles
thruput config get futurenet --sources
thruput status --profile futurenet
```

`config get` shows persisted configuration and where it came from. `status` adds environment diagnostics, including the effective key and local-runtime selection. Neither command requests funds or deploys a contract.



## Choose a profile

For one command:

```bash
thruput balance --profile futurenet
```

To make Futurenet your global default, including in new projects:

```bash
thruput config use futurenet --global
```

New project templates omit `default_profile`. Existing projects can still have a project default that overrides the global selection. To select Futurenet for one project:

```bash
thruput config use futurenet --project
```

Profile selection checks, in order:

1. `--profile`
2. `THRUPUT_PROFILE`
3. Project `default_profile`
4. Global `default_profile`

If none selects a profile, network commands fail. Offline builds and tests can use a scaffold’s local overlay without a selected default. The name `default` has no special fallback meaning.



## Futurenet

`thruput init` creates `local` and `futurenet`, with `local` as the initial default. Futurenet uses `https://rpc.thruput.network` and `https://faucet.thruput.network`. Initialization preserves existing defaults and custom profile fields. For a first funded account, follow the [CLI quickstart](../pages/get-started/cli.md).

The CLI validates the selected network before signing. An explicit `network-hash` pins the network identity. Without a pin, hosted native-account operations use the configured network descriptor and RPC identity. Do not copy a hash from a different deployment; a Futurenet reset can change the identity.

`network = "devnet"` remains a compatibility alias for the hosted network. Existing Devnet profiles and saved wallets keep their names and settings. New installations create only the `futurenet` hosted profile. To add it to an older installation, rerun `thruput init`, then select it with `thruput config use futurenet --global`. Profile names are distinct; the network alias does not copy wallets or contract aliases between profiles. Older CLIs do not recognize `network = "futurenet"` and can fail to update a global config containing it. Upgrade those CLIs or keep their configuration separate.

`config new --network futurenet` stores only the supplied fields. A project overlay inherits omitted endpoints from the same-named global profile.



## Local development

Profiles with `network = "local"` can use the endpoint and runtime manifest recorded by a running `thruput node`. See [Run a local node](../pages/cli/local-node.md).

For a one-off endpoint override on an RPC command:

```bash
thruput balance --profile local --rpc-url http://127.0.0.1:9546
```

Local airdrops also need that node’s runtime manifest, which identifies the node’s faucet. Use `--runtime-manifest PATH` when automatic discovery does not apply.



## Global settings and project overrides

| Layer   | Location                        | Purpose                                                   |
| ------- | ------------------------------- | --------------------------------------------------------- |
| Global  | `~/.config/thruput/config.toml` | Shared profiles, key defaults, and wallet bindings        |
| Project | Nearest ancestor `thruput.toml` | Project defaults, profile overrides, and contract aliases |

`XDG_CONFIG_HOME` changes the global configuration root. Same-named profiles merge field by field; project values win. Contract aliases and wallet bindings merge by name.

Inside a project, choose `--global` or `--project` when changing configuration. Outside a project, omitted scope means global.

```bash
thruput config set default-key alice --profile futurenet --project
thruput config unset default-key --profile futurenet --project
```

The second command removes the project override and reveals any inherited value. The editable fields are `network`, `rpc-url`, `network-hash`, `faucet-url`, and `default-key`. Use [wallet commands](../pages/cli/wallets.md) to select wallets and deployment commands to create contract aliases.



## Add another endpoint

Replace the example URLs with the RPC and faucet for the same deployment:

```bash
thruput config new staging --network futurenet \
  --rpc-url https://rpc.example.com \
  --faucet-url https://faucet.example.com \
  --global
```

Use `config new` to create a profile in a layer before changing its fields there. `config rm staging --global` removes that layer’s profile, including its saved aliases and wallet bindings. It does not delete onchain state.

---

## Keys and wallets

Source: <https://thruput.network/cli/wallets/>

Create signing keys, save native wallet bindings, select an account, and request test funds.

A **key** signs transactions. A **wallet binding** gives an account address a reusable name within a profile. Keys are global; bindings can be global or project-local.

For first-time setup, the [CLI quickstart](../pages/get-started/cli.md) creates and funds a Futurenet account. This page covers account management after that setup.



## Create a key and wallet

```bash
thruput keys generate alice
thruput wallet create --key alice --profile futurenet
```

Confirm wallet creation. The CLI derives a native account and saves its address, owner, and account nonce. It does not deploy a wallet contract or request funds.

An ordinary stored key can also use its native account without a saved binding. Saving a binding is useful when you want a name for selection and inspection. Existing legacy wallet bindings keep their original account identity and transaction format.



### ML-DSA-65 keys

ML-DSA-65 keys require CLI `0.30.0` or later. Check with `thruput --version`.

```bash
thruput keys generate carol --scheme mldsa65
thruput airdrop carol --profile futurenet
```

An ML-DSA-65 key always uses its native account. `balance`, `transfer`, `tx`, and `call` work the same way as with Ed25519 keys. These commands are Ed25519 only:

- `wallet create` does not accept ML-DSA-65 keys.
- `keys import` accepts Ed25519 seeds only.
- `keys export --format strkey` does not apply, because ML-DSA-65 keys have no StrKey form.
- `init --generate-key` creates an Ed25519 key.



## Inspect accounts

```bash
thruput keys ls
thruput wallet ls --profile futurenet
thruput status --profile futurenet
```

Keys live under `${XDG_CONFIG_HOME:-$HOME/.config}/thruput/keys/`. Wallet bindings live in the selected configuration layer. Wallet mutations inside a project update its overlay; outside a project they update global configuration.



## Select an account

```bash
thruput keys use alice
thruput wallet use alice --profile futurenet
thruput balance alice --profile futurenet
```

A profile’s `default-key` can override the global key. Inspect it with `thruput config get futurenet --sources`. Selecting a key does not replace an explicitly selected wallet belonging to another key; the CLI checks ownership rather than silently switching accounts.

For one deployment or call, use `--wallet NAME`. When targets are omitted from `balance`, `airdrop`, or `tx list`, the CLI resolves the effective account from the selected profile and key.



## Fund and transfer

```bash
thruput airdrop alice --profile futurenet
thruput balance alice --profile futurenet
```

The hosted faucet selects the amount. Local-node requests can use `--amount`:

```bash
thruput airdrop alice --profile local --amount 25
```

To transfer native tokens to another saved wallet or an address:

```bash
thruput transfer RECIPIENT 1 --profile futurenet
```

Replace `RECIPIENT` with the destination. Confirm the transaction and inspect its result. A new recipient needs a sufficient first credit to cover its balance storage; funding amounts depend on the network. See [Faucet](../pages/tools/faucet.md) and [storage costs](../pages/how-it-works/storage-economics.md).



## Remove local records

`thruput wallet rm alice --profile futurenet` removes the saved binding, not the onchain account. `thruput keys rm alice` removes the local signing key and asks for confirmation. Keep a key if you still need it to control an account.

`thruput keys export NAME` prints private key material. Use it only for an intended export, not as a diagnostic or a way to put a signer into browser code.

---

## Create a project

Source: <https://thruput.network/cli/create-project/>

Create a contract project and keep its generated compiler, build, and test configuration together.

Use `thruput new` to create a Rust contract project. If this is your first setup, [install the CLI](../pages/cli/install.md) and run `thruput init` first.



## Choose a template

```bash
thruput new my-counter --template counter
cd my-counter
```

The explicit `counter` template includes counter methods, an event, an error, and tests. Without `--template`, the CLI creates a minimal contract:

```bash
thruput new my-contract
```

The minimal project and named templates include the files needed for native tests, RV32 builds, and integration tests. Keep the generated `Cargo.toml`, `rust-toolchain.toml`, and `.cargo/` configuration together. You do not need to select SDK or compiler versions yourself.

Discover named templates and their prerequisites without network access:

```bash
thruput templates list
thruput templates show counter-app
```

`counter-app` adds a local React application, generated bindings, and a temporary browser wallet. It separates contract deployment (`npm run contract:deploy`) from frontend startup (`npm run dev`). Use [Build a counter](../pages/tutorials/build-a-counter.md) to build the application step by step instead.

Run `thruput new` without a name for interactive setup, or pass `--path PATH` to select a destination. The destination must be new or empty.



## Find the code

- `src/implementation.rs`: contract logic and storage.
- `tests/test.rs`: native logic tests.
- `tests/test_rv32.rs`: artifact tests.
- `tests/integration.rs`: RPC integration test entry point.
- `thruput.toml`: project profiles and deployment aliases.

See [Project structure](../pages/contracts/project-structure.md) for the complete layout and generated artifacts.



## Select a network

New projects omit `default_profile` and follow your global selection. After `thruput config use futurenet --global`, new projects use Futurenet. Inspect the selected profile before deploying:

```bash
thruput config get --sources
```

Use `thruput config use futurenet --project` to set a project override, or `--profile futurenet` for one command. Builds and native/artifact tests run on your machine regardless of the profile. See [Profiles and networks](../pages/cli/configuration.md).



## Work in a Cargo workspace

Keep shared `thruput.toml`, `.cargo/`, and `rust-toolchain.toml` files at the workspace root. Select a package when building from that root:

```bash
thruput build -p my-counter
thruput test -p my-counter
```

---

## Build and test

Source: <https://thruput.network/cli/build-and-test/>

Build RV32 artifacts and choose native, artifact, or RPC integration tests.

Run these commands inside a [CLI-generated project](../pages/cli/create-project.md) with [Cargo access](../pages/cli/install.md#configure-cargo-access) configured.



## Build a deployable artifact

```bash
thruput build
```

The CLI compiles for RV32 and lowers the result into `target/thruput/<package>.rv32a`. It also writes lowering metadata and contract-spec sidecars. Artifact names use the package’s snake-case name. See [Project structure](../pages/contracts/project-structure.md#build-artifacts).

Plain `cargo build` targets your host. Use it for Rust tooling and IDE checks, not to produce the deployable artifact.

At a workspace root, select a package:

```bash
thruput build -p my-counter
```

Use `--show-cargo-commands` to inspect the compiler invocation. Arguments after `--` go to Cargo. Keep the scaffold’s compiler and feature configuration instead of recreating the cross-compilation command by hand.



## Choose a test boundary

| Command                      | What it exercises                                                             |
| ---------------------------- | ----------------------------------------------------------------------------- |
| `cargo test`                 | Native contract logic through the SDK test environment                        |
| `thruput test`               | The built RV32 artifact through `tests/test_rv32.rs`                          |
| `thruput test --integration` | Artifact build, disposable local node, deployment, and `tests/integration.rs` |

The first two do not require a running RPC node. Integration mode starts and stops its own node; it does not submit transactions to Futurenet.

```bash
cargo test
thruput test
```

For test code, assertions, and storage-cost setup, use [Test contracts](../pages/programming-model/testing.md).



## Focus a test run

```bash
thruput test --match-test counter
thruput test --skip slow
thruput test --show-output
thruput test --no-capture --test-threads 1
```

`--match-test` and `--skip` filter test names. `--show-output` includes output from passing tests; `--no-capture` streams output as tests run.

```bash
thruput test --rerun
thruput test --watch
```

`--rerun` uses the previous failure cache. `--watch` runs immediately, then repeats after source or configuration changes. They can be combined.



## Integration and workspace runs

```bash
thruput test --integration
thruput test --workspace
```

These are separate modes. `--workspace` runs members with a `test_rv32` target in package-name order. It cannot be combined with `-p` or `--integration`. Integration mode does not support `--watch` or `--rerun`.

The CLI can acquire its selected local runtime for integration tests. See [runtime selection](../pages/cli/local-node.md#runtime-selection) for explicit overrides, and [Automation](../pages/cli/automation.md) for structured test reports.

---

## Run a local node

Source: <https://thruput.network/cli/local-node/>

Start an isolated development chain, select its accounts, and preserve or inspect local state.

Use a local node for disposable development and RPC tests. For a first hosted deployment, follow the [Futurenet contract quickstart](../pages/get-started/contract.md).



## Start the node

```bash
thruput node
```

Keep this terminal running. The CLI starts its managed `hog-devnode` and exposes JSON-RPC at `http://127.0.0.1:9545` by default. If the selected runtime is missing, the CLI can download its verified bundle.

The CLI records the active endpoint and runtime manifest so commands using a local profile can find the node.

The node funds the selected project/global key. If local and Futurenet profiles use different keys, run `THRUPUT_PROFILE=local thruput node` so startup uses the key selected by local commands. `--key NAME` explicitly selects a stored key.



## Select a local account

From another terminal in your project:

```bash
thruput status --profile local
thruput balance --profile local
```

`status` shows the effective key. On a fresh chain, the node gives that key’s account 100 native tokens. Use `thruput node --initial-account-tokens AMOUNT` to change the amount. The faucet key is private to the node, and the node creates no other accounts. An ML-DSA-65 key gets no genesis allocation. To fund it, or any other key, run `thruput airdrop NAME --profile local`.

If the profile already selects a saved wallet, key selection alone does not replace that wallet. Inspect `thruput status --profile local` and [wallet selection](../pages/cli/wallets.md#select-an-account) before submitting.

You can now use the normal [deployment and call commands](../pages/cli/deploy-and-call.md) with `--profile local`.



## Preserve state

Without a data directory, stopping the node discards its chain state. Stored signing keys and project configuration remain, but the local deployments and balances do not.

```bash
thruput node --data-dir .thruput/node
```

Restart with the same data directory to reuse the chain. Repeat the same `--network-config` overrides, and omit `--init-network-hash`. A runtime older than `0.1.31-rc.10` created data directories that the current runtime cannot open. Use a new directory for them.

Stop the node before backing up or restoring that directory:

```bash
thruput chain dump --data-dir .thruput/node --output chain-backup.json
thruput chain restore --data-dir .thruput/node --input chain-backup.json
```

Restore asks before replacing populated state. Use `--yes` only when that replacement is intended.



## Change the endpoint or logging

```bash
thruput node --port 9546
thruput node --verbose
```

Choose logging before reproducing a problem: restarting an ephemeral node to enable it loses the old state. `RUST_LOG` provides finer control and overrides the verbose preset.

The public listener binds to loopback by default. `--host` changes that listener for container or VM access; exposing it beyond loopback exposes an unauthenticated development RPC endpoint.



## Runtime selection

The CLI selects a default from its bundled runtime catalog. See [local runtime setup](../pages/cli/install.md#set-up-the-local-runtime) to inspect and install managed runtimes.

To inspect the effective configuration:

```bash
thruput status --json
```

An explicit `--hog-devnode-binary`, `THRUPUT_DEVNODE_BINARY`, or adjacent binary can take precedence over managed selection. Use `--hog-devnode-version VERSION` when intentionally selecting an exact catalog entry. `--offline` prevents managed downloads, not RPC or Cargo traffic.

If the runtime is incompatible, select matching binaries. `--hogd-protocol` changes a handshake token only; it does not make different wire formats compatible.

For isolated automated runs, prefer [integration tests](../pages/cli/build-and-test.md#integration-and-workspace-runs) rather than managing a long-running node yourself.

---

## Deploy and call

Source: <https://thruput.network/cli/deploy-and-call/>

Deploy an artifact, fund its storage, call methods, and read committed state.

Run these commands in a contract project with a built artifact. Deployment and calls need a funded account; estimating needs no signing key. Select the intended [profile](../pages/cli/configuration.md) explicitly. The examples use Futurenet and the scaffolded counter’s methods.



## Estimate deployment funding

```bash
thruput build
thruput deploy --estimate --profile futurenet
thruput deploy --estimate --profile futurenet --json
```

The estimate reads the network’s authoritative execution rules and storage prices without signing or submitting. It checks the artifact, code, and memory limits and assumes a fresh, unfunded contract address. Unlike `--dry-run`, it does not prepare a signed transaction.

| Report field                                | Meaning                                                                                                                             |
| ------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `balanceDepositRaw`, `deploymentCostRaw`    | First balance-item deposit and code collateral, in native-token base units                                                          |
| `minimumFundingRaw`, `minimumFundingTokens` | Their sum, as an integer base-unit string and a whole-token decimal string respectively; one native token has 10,000,000 base units |
| `initializerFundingRaw`                     | `null` when an initializer is requested, because its storage is not estimated; `"0"` when none is requested                         |
| `execution`                                 | Observed committed tip, configuration hash, effective limits, and storage prices                                                    |

Missing authoritative rules or prices produce an error, not a zero-cost estimate. The reading applies at its reported configuration; prices can change before inclusion. Re-estimate after rebuilding or changing networks.

For deployment without initialization, the CLI can read and transfer the minimum directly:

```bash
thruput deploy --profile futurenet --fund minimum
```

The minimum leaves **zero free contract balance** for further storage. It excludes initializer writes, later storage growth, the sender’s replay storage, and the sender’s scheduling capacity. `--fund minimum` cannot be combined with `--init`. Use an explicit total amount when initialization or later calls need storage, as in the [counter guide](../pages/tutorials/build-a-counter.md#build-deploy-and-initialize).



## Deploy an artifact

```bash
thruput build
thruput deploy --profile futurenet --fund 10
```

Confirm the deployment. The CLI waits for its result, prints the deployed address, and saves an alias using the package name. For a project named `my-counter`, later commands can use that alias instead of the address.

Numeric `--fund` transfers exactly that many native tokens from the sender to the new contract. Set it to the estimated minimum plus an allowance for contract storage. `10` above illustrates the syntax; choose your total from the current estimate rather than treating it as a fixed fee or minimum.

At a workspace root, use `-p PACKAGE`. Use `--artifact PATH` to select an artifact directly and `--alias NAME` when you want a specific alias.



## Include initialization

For a new deployment that initializes the counter in the same transaction, use this instead:

```bash
thruput deploy --profile futurenet --fund 10 \
  --init initialize --init-arg 10
```

Repeat `--init-arg` for additional arguments. The initializer sees the deploying wallet as its caller. Funding, deployment, and initialization succeed together or roll back together.

Initialization is an ordinary contract method. The contract must enforce one-time initialization when its design requires it. The starter counter simply adds the supplied amount, so do not call it again after initializing this example.



## Submit a call

For a counter that has been deployed and initialized:

```bash
thruput call my-counter increment 5 --profile futurenet
```

This signs and submits a transaction. Method names and typed arguments use the contract spec. Without metadata, an explicit entrypoint and raw calldata are required; use generated metadata for normal development.

Use `--gas-limit` when the call needs a different execution budget. The sender must have the corresponding scheduling capacity; gas itself has no token fee.



## Read without submitting

```bash
thruput view my-counter get --profile futurenet
```

`view` runs a sandboxed call against committed state. It does not submit a transaction. Use `--from ADDRESS` when a read needs a simulated caller; this does not prove control of that address.

`thruput storage CONTRACT KEY` reads a raw storage item. Prefer a view when you want the contract’s typed behavior.



## Prepare without broadcasting

```bash
thruput deploy --profile futurenet --fund 10 --dry-run
thruput call my-counter increment 5 --profile futurenet --dry-run
```

A dry run prepares and signs a transaction but does not submit it. It still needs the selected key and network access. It is not a simulation of the state change and does not prove that execution will succeed.



## Inspect an uncertain result

Keep the transaction hash and original network if submission or receipt observation fails:

```bash
thruput tx show TX_HASH --profile futurenet
```

A timeout or `unknown` status does not prove that the transaction failed. Repeating a deployment creates a new nonce and predicted address. Inspect the original transaction before deciding to submit a new operation. See [Inspect transactions and events](../pages/cli/transactions.md).

---

## Inspect transactions and events

Source: <https://thruput.network/cli/transactions/>

Inspect receipts, address history, contract events, and token transfers from the CLI.

Use the same profile and network that received the transaction. The commands below are read-only.



## Look up one transaction

```bash
thruput tx show TX_HASH --profile futurenet
```

Replace `TX_HASH` with the submitted hash. This performs one status lookup and fetches the receipt when committed; it does not wait for a pending transaction.

Check the receipt’s execution result. A committed failure is different from a transaction that is still `pending` or was reported as `retry` or `dropped`. See [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).



## List history

```bash
thruput tx list my-counter --profile futurenet --limit 25
```

History is indexed by root invocation target. A wallet-wrapped call can appear under the wallet rather than the inner target contract. Use the receipt and contract events to inspect inner activity; absence from an address-history page does not prove an operation did not occur.



## Read contract events

```bash
thruput events list my-counter --profile futurenet --limit 25
```

For decoded events, supply the trusted spec from the same contract build:

```bash
thruput events list my-counter --profile futurenet \
  --spec target/thruput/my_counter.spec.xdr --event PingEvent
```

Use `--topic0`, `--topic1`, or `--topic2` for raw topic filters. Repeated values at one position mean OR; filters across positions mean AND. Use the signature from the generated spec rather than copying one from another contract.



## Inspect token transfers

```bash
thruput token transfers NATIVE_TOKEN --profile futurenet
```

Use `--account ADDRESS` to restrict the query to an account. Amounts are returned as base-unit values; formatting is separate from the stored amount.



## Continue a page

These list commands return one newest-first page at a time. Pass the returned cursor to the same command with the same target and filters:

```bash
thruput tx list my-counter --profile futurenet --limit 25 --cursor CURSOR
```

Replace `CURSOR` with the exact returned value. An empty page with a non-empty cursor is not the end. The returned cursor `0x` ends that historical walk.

To check for new activity, omit `--cursor` and start at the head again. A saved cursor continues the old walk; it is not a subscription. For forward ingestion and durable checkpoints, use the [event indexing guidance](../pages/typescript/events.md#resume-without-missing-events).

The [Explorer](../pages/tools/block-explorer.md) provides a browser-based inspection path.

---

## Generate TypeScript bindings

Source: <https://thruput.network/cli/codegen/>

Generate typed application bindings from a built contract's canonical specification.

Generate bindings from the same contract build you deploy. Bindings provide method descriptors, argument types, result decoders, and declared event and error types.

Use Thruput CLI 0.29.0 or newer for applications that import the private `@thruputchain` npm packages. Older generators emit the previous package namespace.



## Generate during a build

```bash
thruput build --bindings ts
```

The build prints the generated binding path alongside the contract artifacts. Use `-p PACKAGE` when selecting a workspace member.



## Write bindings into an application

Build first, then select the binary spec sidecar:

```bash
thruput build
mkdir -p web/src/contracts
thruput codegen ts target/thruput/my_counter.spec.xdr \
  --output web/src/contracts/my-counter.ts
```

Replace `my_counter` with your artifact’s name and the output directory with your application’s location. `codegen ts` accepts `.spec.xdr`, not the readable `.spec.json` or the deployable `.rv32a` file.



## Keep code and deployment aligned

Regenerate bindings when the contract interface changes. Use the address from the matching deployment rather than an address copied from another example.

Do not edit generated files. Put application wrappers next to them so regeneration does not overwrite application logic.

Continue with [Use contract bindings](../pages/tools/typescript-bindings.md) for descriptors and typed calls, or [Read events](../pages/typescript/events.md) for filters and decoding.

---

## Skills and local docs

Source: <https://thruput.network/cli/agent-tools/>

Install, update, and read the thruput skill, and serve or export local documentation.

Use `thruput skill` for coding-agent instructions and `thruput docs` for the developer documentation. For a first project, follow [Build with an Agent](../pages/start/build-with-an-agent.md).



## Install the maintained skill

Installation requires Node.js 22.20 or newer, npm, Git, and access to the private [skill repository](https://github.com/thruputchain/agent-skills). Configure repository authentication through Git, GitHub CLI, or SSH.

```bash
thruput skill install
```

The installer lets you choose your agents, project or global scope, and installation method. Project scope is the default. To select an agent or use a user-wide installation explicitly:

```bash
thruput skill install --agent opencode
thruput skill install --global --agent claude-code
```

Repeat `--agent` to select more than one agent. These commands run `npx skills` against the maintained source. You can also install directly:

```bash
npx skills add thruputchain/agent-skills --skill thruput
```

Installing the skill does not configure Cargo or npm access for a contract or application. Follow the relevant [quickstart](../pages/get-started.md) for those dependencies.



## Update an installed skill

Run the update in the same scope as the installation:

```bash
thruput skill update
thruput skill update --global
```

Each command updates only the `thruput` skill, not other installed skills. If `thruput` is absent from that scope, run `skill install` there first. A current installation needs no change. Repeating installation uses the installer again; it does not create a second skill name.

For a direct project-scoped update:

```bash
npx skills update thruput --project
```





## Read installed guidance offline

```bash
thruput skill show
thruput skill list
thruput skill show contracts
thruput skill show contracts --global
thruput skill list --global
```

`show` prints the installed `SKILL.md` unchanged. `list` lists the Markdown references in that installation. Select a topic, such as `contracts`, to read its reference. There is no `--all` option; read the entry and the references needed for your task.

By default, these commands look for `.agents/skills/thruput` in the current directory, then under your home directory. Run them from the directory where you installed the project skill. `--global` selects only the home-directory installation. An invalid project installation reports an error rather than falling back to the global copy.

Install the skill before reading it. Once installed, `show` and `list` need no Node.js, npm, Git, or network access. Missing files produce an installation or read error, not bundled fallback content. Add `--json` for the selected scope, file path, and content or topic list.

Updates change the installed files that `show` and `list` read. This is separate from `thruput docs`, which serves a documentation snapshot bundled with the CLI.



## Automate skill setup

For an intended unattended installation or update:

```bash
thruput skill install --agent opencode --yes --non-interactive --json
thruput skill update --yes --non-interactive --json
```

Installation requires an explicit `--agent` when prompts are unavailable. Both operations require `--yes` to authorize npm execution and skill changes. Add `--global` for user-wide scope. `--non-interactive` and `--json` do not grant consent. `--offline` rejects installation and updates before invoking npm.



## Serve local documentation

```bash
thruput docs
```

This serves the CLI’s bundled site on `127.0.0.1:4321` until you press Ctrl-C. `--foreground` makes that mode explicit. The command prints the browser URL, Markdown index path, and snapshot source. It starts no blockchain node.

To keep the server running after the command returns:

```bash
thruput docs --background --port 0
thruput docs status
thruput docs stop
```

Port `0` chooses an available port. Background startup returns only when the server is ready and reports the browser URL, Markdown index, and log path. Repeating the same start command reuses a matching instance. Stop it before changing its port, snapshot, or CLI executable.

`status` and `stop` manage the current user’s background server, not a foreground process. The server does not start automatically after reboot. Stopping it leaves the extracted Markdown available. Add `--json` to start, status, or stop for structured reports.

Use the printed Markdown index to find individual pages under `pages/`, focused bundles under `sections/`, and the complete `full.md`. Agents on the same machine can read these files without keeping the server running. Bundled documentation is a snapshot and can differ from the hosted site.



## Export Markdown without a server

```bash
thruput docs export --output ./thruput-docs
```

The destination must not exist, and its parent directory must exist. The CLI copies the Markdown tree and snapshot identity, then prints the absolute path to `index.md`. It does not start a server or replace an existing export. Choose a new destination for another export.

Share the whole folder with an agent on another machine. Relative links and local assets remain usable away from the website. A remote agent cannot use your local filesystem path or loopback URL directly.



## Use a trusted site snapshot

```bash
thruput docs --dir /path/to/docs-snapshot --port 0
thruput docs export --dir /path/to/docs-snapshot --output ./exported-docs
```

Pass a directory produced by the documentation snapshot build, including its `snapshot.json`. Keep it unchanged while serving. Export requires `markdown/index.md` in that snapshot. The override does not fetch the hosted site.

Serving bundled docs and exporting them work offline. Linked repositories, package registries, and network services can still require network access.

---

## Use the CLI in scripts

Source: <https://thruput.network/cli/automation/>

Use non-interactive commands and structured output without treating output flags as confirmation.

Use `--non-interactive` to disable questions and terminal UI. It does not authorize state changes. Pass `--yes` to confirm an intended write, such as a deployment, an airdrop, or skill setup. On write commands other than `skill`, `--force` remains an alias.



## Set up explicitly

```bash
thruput init --non-interactive --generate-key
```

`--generate-key` authorizes initial key creation when there are no stored keys or explicit selections. It does not replace an existing key. Use `thruput new` separately to create a project in a script.



## Request structured output

```bash
thruput config get futurenet --json
thruput test --json
```

The envelope identifies the command, its `ok` result, warnings, and command data. Payloads carry a command-specific `schemaVersion`; check it before relying on exact fields.

Check the process exit status as well as the envelope. A reported test failure can carry `ok: false` on stdout. Other command failures can emit an error envelope on stderr. Keep the streams separate instead of assuming every failed command produces a successful-data shape on stdout.

With `test --watch --json`, each completed run is a separate JSON record. A long-running `node` or watch command still runs until stopped.



## Confirm intended writes

For a deployment you intend to submit:

```bash
thruput deploy --profile futurenet --fund 10 --non-interactive --yes --json
```

For preparation without submission, use `--dry-run` instead. Neither `--quiet` nor `--json` substitutes for confirmation.



## Set up agent tools

```bash
thruput skill install --agent opencode --yes --non-interactive --json
thruput docs --background --port 0 --json
```

Unattended skill installation needs both `--yes` and an explicit agent. Updates need `--yes`; add `--global` to either operation for user-wide scope. See [Skills and local docs](../pages/cli/agent-tools.md) for prerequisites, targeted updates, and offline reads.

Background docs reports include `running`, `reused`, `server`, and `logPath` in `data`. Read `server.url` and `server.markdownIndex` when a server is present. Use `thruput docs status --json` to inspect it and `thruput docs stop --json` to stop it. A status with `running: false` is a valid result, not a command failure.

---

## Troubleshooting

Source: <https://thruput.network/cli/troubleshooting/>

Diagnose configuration, build, runtime, funding, and transaction-observation problems.

Start with the command’s error and the selected environment:

```bash
thruput --version
thruput status --profile futurenet
thruput config get futurenet --sources
```

For local work, use `--profile local`. `status` can exit nonzero when it finds warnings; inspect the findings rather than assuming the report itself failed.



## Cargo cannot access packages

Complete [Cargo access setup](../pages/cli/install.md#configure-cargo-access) in the terminal running the build. A registry token alone is not enough if Cargo has no credential provider configured. Repository access does not imply registry access.



## The wrong profile or account is selected

An explicit `--profile` wins over `THRUPUT_PROFILE`, which wins over project and global defaults. A profile-specific key or selected wallet can also override the global key. Inspect both configuration and `wallet ls --profile NAME` before changing them.

Use [Profiles and networks](../pages/cli/configuration.md) and [Keys and wallets](../pages/cli/wallets.md) to change the intended layer. Preserve existing keys rather than generating replacements to hide a selection error.



## The local runtime is missing or incompatible

```bash
thruput toolchain list
thruput toolchain install
thruput toolchain which
```

Check for an intentional `THRUPUT_DEVNODE_BINARY` override or an adjacent binary. The installed CLI’s catalog chooses a compatible managed runtime. A protocol-token override does not fix a wire-format mismatch. See [runtime selection](../pages/cli/local-node.md#runtime-selection).

On Linux, a missing shared-library error identifies the system dependency to install. See [CLI installation](../pages/cli/install.md) for runtime-library guidance.



## The node restarted and the deployment disappeared

An ephemeral local node loses chain state on shutdown. Restarting it does not restore the old wallets, balances, or deployments, even when local configuration still has their aliases. Redeploy on the new chain, or use a persistent [data directory](../pages/cli/local-node.md#preserve-state).



## Deployment needs funding

Native deployment requires an explicit `--fund` amount. The sender needs funds for the transfer and scheduling capacity; the deployed contract needs funds for its own storage. Inspect the sender with `thruput balance --profile NAME`, then request appropriate test funding or reduce the operation. See [Deploy and call](../pages/cli/deploy-and-call.md).



## Submission timed out or status is unknown

Keep the transaction hash and original network. Run `thruput tx show TX_HASH --profile NAME` to inspect it. A timeout is not proof of failure. Do not automatically repeat a deployment or sign a replacement call.



## A view or call cannot resolve a method

Use the correct contract alias and the spec from the matching build. Rebuild after interface changes. At a Cargo workspace root, select the package with `-p`. Explicit entrypoint calls require the matching encoded calldata; changing only the entrypoint does not adapt an incompatible interface.



## The integration target is missing

Current CLI projects include `tests/integration.rs` and its activation wiring. Compare an older project with a fresh scaffold before adding them; do not replace its dependency configuration blindly. See [Test contracts](../pages/programming-model/testing.md#what-the-scaffold-gives-you).

---

## Command reference

Source: <https://thruput.network/cli/reference/>

Thruput CLI commands, common options, and links to task instructions.





## First-Run Setup

| Command                                                              | Purpose                                                                       | Usage                                                                 |
| -------------------------------------------------------------------- | ----------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| `thruput --version`                                                  | Print the installed release                                                   | [Install](../pages/cli/install.md)                                    |
| `thruput init`                                                       | Initialize profiles and check setup; offer initial key creation interactively | [CLI quickstart](../pages/get-started/cli.md)                         |
| `thruput init --non-interactive --generate-key`                      | Explicitly authorize initial key creation without prompts                     | [Automation](../pages/cli/automation.md)                              |
| `thruput status [--profile NAME]`                                    | Inspect project, key, compiler, and runtime readiness                         | [Troubleshooting](../pages/cli/troubleshooting.md)                    |
| `thruput new [NAME] [--path PATH] [--template counter\|counter-app]` | Create a minimal contract by default; omit the name for interactive setup     | [Create a project](../pages/cli/create-project.md)                    |
| `thruput templates list` / `thruput templates show NAME`             | Discover named templates and their prerequisites offline                      | [Choose a template](../pages/cli/create-project.md#choose-a-template) |
| `thruput completion SHELL`                                           | Print shell completions                                                       | `thruput completion --help`                                           |
| `thruput COMMAND --help`                                             | Print the installed command’s options                                         | Available on each command                                             |



## Configuration

| Command                                 | Purpose                                             | Usage                                                                            |
| --------------------------------------- | --------------------------------------------------- | -------------------------------------------------------------------------------- |
| `config profiles`                       | List persisted profiles                             | [Profiles and networks](../pages/cli/configuration.md)                           |
| `config get [NAME] [--sources]`         | Inspect merged persisted settings and their origins | [Inspect settings](../pages/cli/configuration.md#inspect-the-current-settings)   |
| `config new NAME --network NETWORK`     | Create a profile in one layer                       | [Add an endpoint](../pages/cli/configuration.md#add-another-endpoint)            |
| `config set FIELD VALUE --profile NAME` | Set one typed field in an existing profile layer    | [Overrides](../pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config unset FIELD --profile NAME`     | Remove a field from one layer                       | [Overrides](../pages/cli/configuration.md#global-settings-and-project-overrides) |
| `config use NAME`                       | Set the layer’s default profile                     | [Select a profile](../pages/cli/configuration.md#choose-a-profile)               |
| `config rm NAME`                        | Remove a profile from one layer                     | Requires confirmation; `--yes` for an intended automated removal                 |
| `--global` / `--project`                | Choose the layer for a configuration mutation       | Required inside a project; mutually exclusive                                    |



## Keys and Wallets

| Command                                            | Purpose                                                            | Usage                                                              |
| -------------------------------------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------ |
| `keys generate [NAME] [--scheme ed25519\|mldsa65]` | Generate a stored key; Ed25519 by default                          | [Keys and wallets](../pages/cli/wallets.md)                        |
| `keys import NAME`                                 | Import an Ed25519 secret seed through the supported input flow     | `thruput keys import --help`                                       |
| `keys ls` / `keys use NAME`                        | List or select a global key                                        | [Select an account](../pages/cli/wallets.md#select-an-account)     |
| `keys export NAME`                                 | Print private key material                                         | Intended export only; exclude from logs                            |
| `keys rm NAME`                                     | Delete a local key                                                 | Requires confirmation                                              |
| `wallet create [--key NAME] [--name NAME]`         | Derive and save an empty native account binding; Ed25519 keys only | [Create a wallet](../pages/cli/wallets.md#create-a-key-and-wallet) |
| `wallet ls` / `wallet use NAME`                    | List or select a profile wallet                                    | [Select an account](../pages/cli/wallets.md#select-an-account)     |
| `wallet rm NAME`                                   | Remove a local binding                                             | Does not remove onchain state                                      |
| `balance [TARGET]`                                 | Read the native-token balance                                      | [Funding](../pages/cli/wallets.md#fund-and-transfer)               |
| `airdrop [RECIPIENT]`                              | Request test funding                                               | [Faucet](../pages/tools/faucet.md)                                 |
| `transfer RECIPIENT AMOUNT`                        | Transfer native tokens from the selected account                   | [Funding and transfers](../pages/cli/wallets.md#fund-and-transfer) |



## Build and Test

| Command or option                        | Purpose                                       | Usage                                                                                   |
| ---------------------------------------- | --------------------------------------------- | --------------------------------------------------------------------------------------- |
| `build [-p PACKAGE]`                     | Build a deployable RV32 artifact              | [Build and test](../pages/cli/build-and-test.md)                                        |
| `build --bindings ts`                    | Also generate TypeScript bindings             | [Code generation](../pages/cli/codegen.md)                                              |
| `build --stack-size SIZE`                | Set guest stack size within configured memory | `thruput build --help`                                                                  |
| `test [-p PACKAGE]`                      | Build and run the RV32 artifact test target   | [Test modes](../pages/cli/build-and-test.md#choose-a-test-boundary)                     |
| `test --integration`                     | Run an isolated local-node integration target | [Integration tests](../pages/programming-model/testing.md#integration-test-environment) |
| `test --workspace`                       | Run eligible workspace members                | [Workspace runs](../pages/cli/build-and-test.md#integration-and-workspace-runs)         |
| `test --match-test TEXT` / `--skip TEXT` | Filter test names                             | [Focused runs](../pages/cli/build-and-test.md#focus-a-test-run)                         |
| `test --rerun` / `--watch`               | Repeat failures or watch files                | Not supported with `--integration`                                                      |
| `test --show-output` / `--no-capture`    | Control test output                           | [Focused runs](../pages/cli/build-and-test.md#focus-a-test-run)                         |



## Local Node

| Command or option                                     | Purpose                                   | Usage                                                                             |
| ----------------------------------------------------- | ----------------------------------------- | --------------------------------------------------------------------------------- |
| `node`                                                | Start an ephemeral local node             | [Run a local node](../pages/cli/local-node.md)                                    |
| `node --data-dir PATH`                                | Preserve chain state                      | [Persistent state](../pages/cli/local-node.md#preserve-state)                     |
| `node --port PORT` / `--host ADDRESS`                 | Configure the public listener             | [Endpoint and logging](../pages/cli/local-node.md#change-the-endpoint-or-logging) |
| `node --verbose`                                      | Forward node diagnostics                  | [Troubleshooting](../pages/cli/troubleshooting.md)                                |
| `node --network-config NAME=VALUE`                    | Override a supported genesis parameter    | Repeatable; preserve settings when reopening a data directory                     |
| `node --key NAME` / `--initial-account-tokens AMOUNT` | Fund a stored key on a fresh chain        | Default: the selected key and 100 native tokens                                   |
| `node --bootstrap-accounts FILE`                      | Fund fixture-owned public keys at genesis | JSON array; cannot be combined with `--key` or `--initial-account-tokens`         |
| `toolchain list` / `install` / `which`                | Inspect or acquire managed runtimes       | [Local runtime setup](../pages/cli/install.md#set-up-the-local-runtime)           |
| `toolchain use VERSION` / `clean VERSION`             | Select or remove a managed version        | `thruput toolchain --help`                                                        |
| `chain dump --data-dir PATH --output FILE`            | Back up a stopped local chain             | [Persistent state](../pages/cli/local-node.md#preserve-state)                     |
| `chain restore --data-dir PATH --input FILE`          | Restore a stopped local chain             | Requires confirmation before replacing populated state                            |



## Deploy and Interact

| Command or option                       | Purpose                                                                                                                      | Usage                                                                           |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| `deploy --fund AMOUNT`                  | Deploy and fund a contract with native tokens                                                                                | [Deploy and call](../pages/cli/deploy-and-call.md)                              |
| `deploy --estimate [--json]`            | Read deployment collateral and configuration context without loading a signing key or submitting                             | [Estimate funding](../pages/cli/deploy-and-call.md#estimate-deployment-funding) |
| `deploy --fund minimum`                 | Fund a fresh deployment’s balance-item deposit and code collateral; leaves no free balance and cannot include initialization | [Minimum funding](../pages/cli/deploy-and-call.md#estimate-deployment-funding)  |
| `deploy --init METHOD --init-arg VALUE` | Initialize atomically with deployment                                                                                        | [Initialization](../pages/cli/deploy-and-call.md#include-initialization)        |
| `deploy --artifact PATH --alias NAME`   | Select an artifact and saved alias                                                                                           | [Deployment](../pages/cli/deploy-and-call.md#deploy-an-artifact)                |
| `call CONTRACT METHOD [ARGS...]`        | Submit a signed contract invocation                                                                                          | [Calls](../pages/cli/deploy-and-call.md#submit-a-call)                          |
| `view CONTRACT METHOD [ARGS...]`        | Run a sandboxed read without submitting                                                                                      | [Views](../pages/cli/deploy-and-call.md#read-without-submitting)                |
| `storage CONTRACT KEY`                  | Read a raw committed storage item                                                                                            | [Views and storage](../pages/cli/deploy-and-call.md#read-without-submitting)    |
| `--dry-run`                             | Prepare deploy/call transactions without broadcast                                                                           | Still requires signing context and network access                               |
| `--yes` (alias `--force`)               | Confirm an intended write without a prompt; `skill` commands accept only `--yes`                                             | [Automation](../pages/cli/automation.md#confirm-intended-writes)                |
| `--profile NAME` / `--rpc-url URL`      | Select configuration or override the endpoint                                                                                | [Profiles](../pages/cli/configuration.md)                                       |



## Transactions, Events, and Tokens

| Command                         | Purpose                                         | Usage                                                                        |
| ------------------------------- | ----------------------------------------------- | ---------------------------------------------------------------------------- |
| `tx show HASH`                  | One public status and receipt lookup            | [Inspect transactions](../pages/cli/transactions.md#look-up-one-transaction) |
| `tx list [TARGET]`              | One page of root-invocation history             | [History](../pages/cli/transactions.md#list-history)                         |
| `events list CONTRACT`          | One page of raw or spec-decoded contract events | [Events](../pages/cli/transactions.md#read-contract-events)                  |
| `token transfers TOKEN`         | One page of token transfer records              | [Token transfers](../pages/cli/transactions.md#inspect-token-transfers)      |
| `--limit N` / `--cursor CURSOR` | Control a historical list page                  | [Pagination](../pages/cli/transactions.md#continue-a-page)                   |



## TypeScript Bindings

| Command                   | Input/output                                                     | Usage                                                                           |
| ------------------------- | ---------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| `build --bindings ts`     | Contract build plus generated bindings                           | [Generate bindings](../pages/cli/codegen.md)                                    |
| `codegen ts SPEC -o FILE` | Canonical `.spec.xdr` to TypeScript; stdout if output is omitted | [Write into an app](../pages/cli/codegen.md#write-bindings-into-an-application) |





## Skills and Local Documentation

| Command                                              | Purpose                                                                                                     | Usage                                                                           |
| ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| `thruput skill install [--global] [--agent NAME]`    | Install the maintained skill through `npx skills`; `--agent` is repeatable                                  | [Install the skill](../pages/cli/agent-tools.md#install-the-maintained-skill)   |
| `thruput skill update [--global]`                    | Update only the `thruput` skill in the selected scope; requires an existing installation                    | [Update the skill](../pages/cli/agent-tools.md#update-an-installed-skill)       |
| `skill install --yes` / `skill update --yes`         | Authorize npm execution and skill changes; unattended installation also needs `--agent`                     | [Automate setup](../pages/cli/agent-tools.md#automate-skill-setup)              |
| `thruput skill show [TOPIC] [--global]`              | Read an installed skill file offline; current-directory installation before global unless `--global` is set | [Read guidance](../pages/cli/agent-tools.md#read-installed-guidance-offline)    |
| `thruput skill list [--global]`                      | List reference names from the selected installed skill                                                      | [Read guidance](../pages/cli/agent-tools.md#read-installed-guidance-offline)    |
| `thruput docs [--foreground] [--port PORT]`          | Serve the bundled site in the foreground; default port `4321`, `0` selects a free port                      | [Serve docs](../pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs --dir PATH`                            | Serve a trusted local snapshot                                                                              | [Snapshot override](../pages/cli/agent-tools.md#use-a-trusted-site-snapshot)    |
| `thruput docs --background [--port PORT]`            | Start or reuse a matching background server; conflicts with `--foreground`                                  | [Serve docs](../pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs status`                                | Inspect the current user’s background server and log path                                                   | [Serve docs](../pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs stop`                                  | Stop the managed background server while retaining extracted Markdown                                       | [Serve docs](../pages/cli/agent-tools.md#serve-local-documentation)             |
| `thruput docs export --output PATH [--dir SNAPSHOT]` | Export portable Markdown into a new directory without serving                                               | [Export Markdown](../pages/cli/agent-tools.md#export-markdown-without-a-server) |



## Shared Flags

| Global flag             | Effect                                                                                                  |
| ----------------------- | ------------------------------------------------------------------------------------------------------- |
| `--non-interactive`     | Disable prompts and terminal UI; does not grant confirmation                                            |
| `--json`                | Emit structured output                                                                                  |
| `--quiet`               | Suppress status messages                                                                                |
| `--show-cargo-commands` | Print Cargo invocations                                                                                 |
| `--offline`             | Disable managed runtime downloads and skill installation/updates; does not disable RPC or Cargo traffic |



### JSON output

| Output concern      | Rule                                                        | Usage                                                                     |
| ------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------- |
| Success and failure | Check exit status and `ok`; command failures may use stderr | [Use the CLI in scripts](../pages/cli/automation.md)                      |
| Payload shape       | Check command-specific `data.schemaVersion`                 | [Structured output](../pages/cli/automation.md#request-structured-output) |
| Watch mode          | One JSON record per completed test run                      | [Structured output](../pages/cli/automation.md#request-structured-output) |
