# Understand Project Thruput

Documentation source: `2f1715e9f3c3effe1821328189bbce9f15de9211`. Hosted docs may be newer than this snapshot.

## Introduction

Source: <https://www.thruput.network/docs/architecture/>

Learn what Project Thruput is and how compatible updates let contracts share state.

Project Thruput is a moonshot project exploring how parallel execution can make compute abundant. Transactions record compatible changes to shared state, allowing the network to combine them without requiring sequential execution.

The project’s future is open. No decisions have been made about timelines or its relationship to Stellar’s existing L1 network. These docs describe the development network and tools available today.

The [whitepapers](../pages/whitepapers.md) introduce the system design and research on bridging between Federated Byzantine Agreement blockchains.

You write contract logic in Rust and connect applications through the TypeScript client or React library. The runtime combines changes using rules defined by the storage type.



## Record the change

Consider a counter with a value of `100`. Two transactions want to increase it, one by `5` and the other by `3`.

If each transaction replaces the value it read, they propose different results: `105` and `103`. With mergeable integer storage, they record the increases instead:

```text
Starting value:    100
Transaction A:     +5
Transaction B:     +3
Combined value:    108
```

These increases can combine if the rest of the transactions are compatible and network limits permit them. Neither transaction needs to calculate a replacement value that includes the other’s update.

This is useful for shared counters and balances. It does not make every operation independent: replacing a value, enforcing uniqueness, or choosing a winning order can require different rules. Your storage choices determine which changes can combine.

[Parallel Execution](../pages/architecture/execution-model.md) explains how Project Thruput applies these rules. [Storage types](../pages/contracts/storage-types.md) shows how to use them in a contract.



## Build in two layers

**Contracts** define application rules and store onchain state. Use the Rust SDK to write and test them, and the CLI to build, deploy, and inspect them.

**Applications** read contract data and request transactions. The TypeScript client provides network and contract operations. The React library adds wallet connection and balance hooks for interfaces.

You can start with either layer. An application can use an existing contract without implementing one first.



## Where to start

Choose a path in [Get Started](../pages/get-started.md) to write code. To explore the platform first, use the [System Overview](../pages/architecture/system-overview.md) as a map, then follow the [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md) or read about [Compute, Capacity & Storage](../pages/architecture/storage-economics.md).

---

## System Overview

Source: <https://www.thruput.network/docs/architecture/system-overview/>

How Project Thruput's public gateway, execution services, storage, and consensus coordinator fit together.

Project Thruput separates three responsibilities: serving applications, executing transactions and storing state, and agreeing on blocks. This page maps those responsibilities to the services that handle them.



## Components

```text
Applications and wallets
      |
      v
JSON-RPC gateway
      |
      +-- Reads
      |   State / Views / History
      |
   submits
      v
  Scheduler <--> Coordinator
      |               |
      |         Other validators
      |
      +-- Auth server
      +-- Executors <--> DB shards
      +-- Event server
```

The diagram shows the main service relationships. [Networking](../pages/architecture/networking.md) covers registration and communication between them.

| Component                            | Responsibility                                                                                                      |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------- |
| **JSON-RPC gateway** (`hog-gateway`) | Accepts application requests, submits transactions to the scheduler, and routes reads to the relevant service       |
| **Scheduler / mempool** (`hogd`)     | Queues transactions, coordinates authorization, dispatches execution, and orchestrates block production and commits |
| **Auth server**                      | Checks transaction authorization claims and signatures before scheduling                                            |
| **Executors**                        | Run contract code and submit its state changes for reservation against the proposed block                           |
| **DB shards**                        | Serve state snapshots, enforce storage merge rules, and store committed state                                       |
| **Event server and indexer**         | Collect execution results and make transaction history, receipts, and events available for queries                  |
| **Coordinator** (`chuckd`)           | Drives consensus with other validators and asks the execution layer to propose, validate, and commit blocks         |



## Two paths through the gateway

**Transactions** enter through the gateway and reach the scheduler. The scheduler arranges signature checks, selects work, and dispatches it to executors. The execution layer produces a block proposal; the coordinator handles agreement with other validators.

**Reads** use the service appropriate to the request. State and balance queries use the database gateway, read-only contract calls use the view gateway, and receipt and event queries use the indexer. The scheduler supplies information such as the chain tip and pending transaction status.

The public gateway does not participate in consensus. Applications use its [JSON-RPC API](../pages/reference/json-rpc-api.md) rather than the internal service interfaces.



## Execution and agreement

The execution layer determines what a proposed block would do. Contracts run against a shared snapshot and produce typed state changes. Executors and DB shards check which changes can be reserved together.

The coordinator drives agreement on which valid proposal to commit. It uses the Stellar Consensus Protocol (SCP); it does not run the contracts itself. Each validator checks the proposed result through its own execution layer before committing it.

Multiple execution workers and database shards distribute work within a node. Consensus coordinates agreement between validators. These are different responsibilities; adding execution capacity does not change the consensus rules.



## Explore the details

- [Parallel Execution](../pages/architecture/execution-model.md): Snapshots, compatible updates, and conflict reservation
- [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md): Submission, execution outcomes, and commit
- [Compute, Capacity & Storage](../pages/architecture/storage-economics.md): Scheduling and storage deposits
- [Consensus](../pages/architecture/consensus.md): Proposals, validation, and finality
- [Networking](../pages/architecture/networking.md): Component registration and internal interfaces

For the behavior your contract relies on, read [Contract Execution](../pages/contracts/execution.md).

---

## Parallel Execution

Source: <https://www.thruput.network/docs/architecture/execution-model/>

How the engine executes transactions against snapshots and reserves compatible state changes.



## The Core Idea

Every transaction reads from a consistent snapshot and records typed deltas. The storage type determines how those deltas combine.

Commutativity describes operations whose combined result does not depend on their order. Project Thruput still enforces resource limits, including gas limits, bounded return values, and a maximum encoded transaction size.

This page explains the engine: snapshots, concurrent reservation, and conflict selection. For the rules your code relies on, read [Contract Execution](../pages/contracts/execution.md).



## Snapshot Isolation

Each transaction sees the ledger as it was at the start of the block. All transactions in a block read from the same snapshot. Ordinary storage reads do not observe other transactions’ writes within that block.

Reads also reflect changes within the current transaction and successful child calls. The database snapshot analogy does not imply identical SQL isolation or conflict rules.

`RetrocausalQueue` also permits observations of concurrent inserts. These are recorded as nondeterministic proposal data and replayed by validators. Its read semantics differ from ordinary snapshot storage.



## Delta Writes

Transactions record typed operations: arithmetic deltas, value replacements, or deletions. Each storage type defines how those operations combine.

Instead of “set balance to 50”, a transaction says “increment balance by 10.” After each root contract call completes, the runtime reserves its delta batch alongside compatible deltas already admitted to the proposed block. The admitted deltas form the next state at commit.

In Solidity, a transfer looks like this:

```solidity
// Solidity: read balances and assign their updated values.
balances[from] = balances[from] - amount;
balances[to] = balances[to] + amount;
```

In Project Thruput:

```rust
// Project Thruput: write deltas. Two compatible transfers to the same
// account produce two deltas that merge cleanly.
balances.at_mut(&from).decrease(amount);
balances.at_mut(&to).increase(amount);
```

Two compatible increments to the same balance produce the same result regardless of order. `(x + 3) + 5 = (x + 5) + 3`. That is commutativity, and it is why Project Thruput can execute transactions in parallel without declared access lists.



## What Commutes and What Doesn’t

Transactions execute concurrently. Storage merge rules determine whether their changes can land together. A conflicting transaction is excluded from that proposal. Exclusion does not guarantee automatic requeue or a `retry` status. See [Exclusion, requeue, and resubmission](../pages/architecture/transaction-lifecycle.md#exclusion-requeue-and-resubmission) for scheduler behavior and client recovery.

| Operation                               | Can both changes land? | Why                                                             |
| --------------------------------------- | ---------------------- | --------------------------------------------------------------- |
| Two balance changes on the same counter | When compatible        | Resolved bases must match and aggregate bounds must hold        |
| Two writes to different Map keys        | Yes                    | Independent keys don’t interact                                 |
| Two writes to the same bytestring       | When identical         | Different values conflict                                       |
| Multiple inserts into the same queue    | Yes                    | Entries are sorted; insertion order doesn’t matter              |
| Two deletions of the same key           | Yes                    | Same outcome regardless of order                                |
| A deletion and a write to the same key  | No                     | Different operation types conflict; one transaction is excluded |

These rules describe the listed operations. Other changes in either transaction can still cause a conflict.



### What This Means for Your Data Model

Choose storage around the changes your application needs to combine. Mergeable arithmetic still has bounds; absolute writes can coexist when they store identical values. [Storage Types](../pages/contracts/storage-types.md#choosing-a-type) turns these rules into contract-design choices.



## How Conflicts Are Resolved

The programming model describes a transaction as executing first and then attempting to land its deltas. The engine implements that boundary directly: ordinary storage conflicts are checked after the root contract call returns, before the transaction is committed into the proposed block.



### Concurrent Delta Reservation

Contract execution accumulates writes in the transaction’s `ItemView`. A checked operation such as `Balance::decrease(30)` first loads the snapshot base and can abort immediately if that transaction alone would underflow. A lazy operation skips that load and therefore cannot report a snapshot-bound failure from contract code. Both forms produce an NNInt delta.

After the root call returns successfully, `try_commit_transaction()` submits the transaction’s complete delta batch to hogd. For a lazy `NonnegativeIntAdd`, hogd resolves the set value from the block snapshot. A checked `NonnegativeIntSetAdd` already carries that same snapshot value. Both then use the same NNInt type-class match and aggregate bounds reservation.

For a snapshot balance of 10, the per-key reservation starts with subtraction capacity of 10:

```plaintext
Snapshot: Alice balance = 10
          Subtraction budget = 10

Tx A contract returns with delta -8
      Reserve delta batch: capacity 10 → 2 → admitted

Tx B contract returns with delta -5
      Reserve delta batch: capacity would be -3 → excluded
```

Whichever transaction reserves first wins. The lock is per-key, per-block and is initialized from the snapshot. Reservations on different keys use separate locks. Transactions touching the same key contend for the same aggregate bounds. Reservation can happen concurrently across executor workers; atomic capacity accounting ensures the combined admitted delta remains in range.

Compatible operations, such as two increases within the upper bound or two decreases within the available balance, can both reserve successfully. Checked and lazy operations share these merge rules. Checked operations can detect underflow in contract code; lazy operations leave that check to reservation. Credits from other transactions do not increase the snapshot’s subtraction budget. A lazy decrease cannot rely on another transaction’s same-block credit.



### What Block Close Does

By the time block close runs, all capacity conflicts have been resolved. Block close stages the already-finalized locks into a ChangeSet and computes the block hash. No conflict resolution happens at this stage for Balance, NNInt, Map, Value, or Bytestring operations.

RetrocausalQueue is the exception: it has end-of-block invariant checks that the other storage types do not. RCQ entries from excluded transactions are removed during block finalization.

The proposer records reservation-dependent outcomes so validators can replay and verify the proposed block. Contract code chooses storage operations; it does not manage the engine’s reservation locks.



## Related reading

- [Contract Execution](../pages/contracts/execution.md): The contract-author model
- [Storage Types](../pages/contracts/storage-types.md): API choices and merge rules
- [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Compute, Capacity & Storage](../pages/architecture/storage-economics.md): Gas limits, scheduling, and deposits

---

## Transaction Lifecycle

Source: <https://www.thruput.network/docs/architecture/transaction-lifecycle/>

How a transaction moves from submission to committed state.

Submitting a transaction is the start of the process. A successful submission does not prove that the contract call succeeded. Check the committed receipt’s execution result.



## Outcomes to distinguish

| Outcome                       | What it means                                                                                                                                                                               |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Rejected before execution** | Admission or authorization failed; the transaction did not reach contract execution                                                                                                         |
| **Committed success**         | The transaction is in a finalized block and its contract changes were applied                                                                                                               |
| **Committed abort or fault**  | The failure is recorded in the block, but the contract changes are discarded                                                                                                                |
| **Excluded from a proposal**  | That attempt did not land in the proposal. Exclusion does not consume its replay nonce or establish its outcome in another proposal. Requeue and reported status depend on later processing |

A pending or `unknown` status, a timeout, or an advisory `recentFailure` is not proof of a committed failure. Keep the original network and transaction hash, and resume observation instead of automatically signing a replacement. See [Track transaction results](../pages/typescript/transaction-status.md) for the application workflow.



## Overview

A transaction passes through six stages:

1. **Submission**: Client submits a signed transaction
2. **Authorization**: Signatures are verified before the transaction enters the scheduling queue
3. **Scheduling**: The transaction is queued and selected for a block
4. **Execution and reservation**: Contract code runs against a snapshot, then its completed delta batch is reserved against the proposal
5. **Block Assembly**: The proposer packages results into a block proposal for consensus
6. **Commit**: Finalized state is written to storage



## Stage 1: Submission

The client signs the domain-separated preimage containing the network hash and inner transaction, then submits the signed wrapper through the JSON-RPC gateway. The network hash prevents replay on another Project Thruput network. The gateway submits directly to the hogd scheduler.



## Stage 2: Authorization

The mempool sends the transaction to the auth server, which verifies the root address, auth claim, and signatures. Pubkey claims use the public key attached to the signed transaction (`SignedTransaction.pubkey_claim_key`). Its hash must equal the claim’s `pubkey_hash`. Source-address claims use the root address’s registered authorization data. This happens before the transaction enters the scheduling queue, not during execution.

- If verification succeeds: the transaction enters the scheduling queue
- If verification fails: the transaction is rejected

See [Authorization](../pages/contracts/authorization.md) for the signature preimage and admission models.



## Stage 3: Scheduling

Verified transactions are queued by account with balance-proportional scheduling. When the coordinator asks for a block proposal, the mempool selects transactions from accounts whose token-backed capacity has waited longest. See [Compute, Capacity & Storage](../pages/architecture/storage-economics.md) for how scheduling priority works.



## Stage 4: Execution

Selected transactions execute in parallel against a **consistent snapshot** of the ledger state. All transactions in a block read from the same snapshot taken at the start of block processing.

When contract code executes:

- It reads state values from the snapshot (via syscalls like `BytestringGet`, `NonnegativeIntGet`)
- Ordinary storage reads do not see writes from other transactions in the block; RCQ consumers can observe concurrent inserts
- It produces deltas describing how to modify state
- It runs until termination (return, abort, or fault)

**Conflict checking follows root execution.** If the root call succeeds, the executor submits its completed delta batch for reservation against the proposed block. An incompatible batch is excluded. Contract execution and reservation can both proceed concurrently across executor workers. See [Parallel Execution: How Conflicts Are Resolved](../pages/architecture/execution-model.md#how-conflicts-are-resolved) for the mechanism and the distinction between checked and lazy operations.

See [Invocation Frames](../pages/contracts/invocation-frames.md) for detailed execution semantics (frame lifecycle, child calls, merge/discard rules).



### Root Frame Completion

When the root frame completes, the runtime checks its status:

- **Return (success)**: the transaction’s deltas are submitted for reservation. They are included only if the transaction remains admissible.
- **Deterministic Abort or Fault**: the failure can be included in the block with the contract’s writes discarded. Protocol bookkeeping, including replay protection, is still recorded. Once committed, this is a final execution result, not a transaction waiting to be retried.

This is distinct from **conflict exclusion** during reservation (Stage 4): the root frame may return successfully, but its completed delta batch can still fail reservation and be excluded. Deterministic abort and non-deterministic conflict exclusion are two different failure modes with different on-chain semantics.



## Stage 5: Block Assembly

The proposer packages the included transaction results into a consensus proposal: signed transaction hashes (`SignedTransactionHash`), nondeterministic execution data, and the computed block hash. The proposal is sent to validators via SCP. See [Consensus](../pages/architecture/consensus.md) for how the proposer/validator split works.



## Stage 6: Commit

Once consensus confirms the block, each validator commits the verified result to its DB shards. The new ledger state becomes the snapshot for the next block.

Committed aborts and faults remain in the block with their contract changes discarded. Their replay nonces are consumed.



## Exclusion, requeue, and resubmission

Exclusion applies to one proposal. It does not guarantee that the transaction will return to the mempool or that the client will observe `retry`.

| What happens to the node’s proposal | What its scheduler does                                                                                      |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Its own proposal commits            | Removes the attempted transactions, including excluded ones. Records retryable execution failures as `retry` |
| A different proposal commits        | Can requeue transactions from its nomination that are absent from the committed block                        |
| Its nomination is rolled back       | Requeues its cached transactions                                                                             |

Automatic requeue in the last two cases does not guarantee later inclusion. After removal in the first case, that scheduler needs another submission to attempt the transaction again.

`retry` is a retained scheduler outcome. The indexer can separately report an advisory `recentFailure`, either as a status or alongside `pending`, `retry`, or `dropped`. It can describe an earlier attempt. Indexed commitment takes priority over these observations. A timeout, `unknown`, or `recentFailure` alone does not prove that the transaction never executed.

Clients retain the signed bytes, transaction hash, and original network. Receipt polling observes the outcome and does not resubmit. When retrying is appropriate, resubmit the same signed transaction while it remains valid. Expiration prevents future inclusion; it does not prove that an earlier attempt never committed. See [Resubmission and replacement](../pages/typescript/transaction-status.md#resubmission-and-replacement) for the application workflow.

Sources: engine `0.1.31-rc.16` [commit handling](https://github.com/thruputchain/hogd/blob/fff489c82d0ff28594e9dc8694aa5571787be7fd/hogd/hog_mempool/rpc_from_coord.cc#L3251-L3335) and [nomination rollback](https://github.com/thruputchain/hogd/blob/fff489c82d0ff28594e9dc8694aa5571787be7fd/hogd/hog_mempool/rpc_from_coord.cc#L1246-L1258), and tools `0.40.0` [status composition](https://github.com/thruputchain/thruput-tools/blob/774ea4be4287b096eb38a57aa4aa952b038f5c7b/crates/x23/hogd-backend/src/native/transaction/status.rs#L4-L54).



## Related Documentation

- [Invocation Frames](../pages/contracts/invocation-frames.md): Execution context
- [Authorization](../pages/contracts/authorization.md): How signatures are verified
- [Contract artifacts and addresses](../pages/contracts/artifacts-and-addresses.md): Code hashes and deployment identities

---

## Compute, Capacity & Storage

Source: <https://www.thruput.network/docs/architecture/storage-economics/>

How the native token provides scheduling capacity and refundable storage deposits without conventional gas fees.

Project Thruput has no conventional gas fees. Its native token backs onchain storage and provides scheduling capacity under load. The current experimental network’s native token has no monetary value.

Removing the sequential execution bottleneck is intended to make compute abundant rather than keep it scarce by design. Parallel execution does not remove hardware limits or contention: the network still meters computation and allocates capacity when demand exceeds it.



## The Two Jobs of the Native Token

Each unit of the native token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Locking native tokens for storage reduces the free balance available for scheduling.



## Execution: Metered, Throughput-Allocated

Running contract code has no conventional gas fee. It still uses finite execution and scheduling capacity, backed by the sender’s unlocked native-token balance.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

A root gas limit above the network’s `max_tx_gas` (default 1,000,000,000) fails validation, and the gateway rejects the transaction at submission. Scheduling reserves one native-token base unit (one ten-millionth of a token) per unit of gas limit. If the gas limit is larger than all of the account’s unlocked native tokens, the scheduler drops the transaction with status `dropped`.

There is no unused-gas token refund. Metering does not debit or refund the sender’s native-token balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.



### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to unlocked native-token balances over time. If account A holds 1,000 unlocked native tokens and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s unlocked tokens sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, its declared gas limit determines how much token-backed capacity moves from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose capacity has waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

Tokens cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

Native tokens transferred between accounts enter the recipient’s scheduling queue as newly received capacity. They do not carry the sender’s accumulated scheduling age.



## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks native tokens according to the [storage type](../pages/contracts/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees native tokens for other storage or scheduling capacity.



### Cost Accounting

Every contract has a native-token balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts native tokens from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked native tokens to the contract’s free balance.

If an address does not have enough unlocked native tokens to cover a storage change, reservation can fail for insufficient funds. That attempt is excluded from the proposal. Exclusion does not guarantee automatic requeue or a `retry` status. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Exclusion, requeue, and resubmission](../pages/architecture/transaction-lifecycle.md#exclusion-requeue-and-resubmission).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.



### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.



### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.



## The Native Token

A sufficient first native-token credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](../pages/typescript/accounts.md#request-futurenet-funds).

The native token is implemented by a native precompiled contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting. Use `ADDRESS_NATIVE_TOKEN` in Rust, `NATIVE_TOKEN_ADDRESS` from `@thruputchain/protocol` in TypeScript, and the `NATIVE_TOKEN` contract alias in CLI commands.



## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.



## Related Documentation

- [Contract Execution](../pages/contracts/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](../pages/architecture/execution-model.md): How compatible state changes are admitted
- [System Overview](../pages/architecture/system-overview.md): The component map
- [Storage Types Reference](../pages/contracts/reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](../pages/get-started/contract.md): Deploy your first contract

---

## Consensus

Source: <https://www.thruput.network/docs/architecture/consensus/>

How SCP coordinates proposals, validation, and finalized blocks.



## Overview

Project Thruput uses the Stellar Consensus Protocol (SCP) for agreement. Each validator chooses **quorum slices**: sets of validators whose agreement it considers sufficient. Overlapping quorum slices allow validators to agree on a block.

Nomination uses a priority function to favor a proposed value in each round. Validators still need agreement under the configured quorum rules before finalizing a block.

SCP provides finality under its quorum-intersection and fault assumptions. Applications use the finalized block result rather than a probabilistic confirmation count.



## The Coordinator

Consensus is driven by the coordinator (chuckd), which is separate from the execution engine (hogd). The coordinator’s job is to get validators to agree on which block to commit. Contract execution and storage belong to the execution layer, orchestrated by the scheduler. See [System Overview](../pages/architecture/system-overview.md) for the component roles.

Each coordinator is configured with its own quorum set: the list of other validators it trusts for consensus. This peer configuration is managed by the coordinator, not the mempool. The mempool handles intra-node component registration (executors, DB shards, etc.); the coordinator handles inter-node consensus topology. This separation keeps execution concerns and agreement concerns independent.

It runs a state machine called the **baton** that drives the consensus loop.



## Block Production

The baton runs a drive loop after every event:

```plaintext
driveCommit()    →  Commit any externalized block
driveNominate()  →  Propose next block if idle
driveCatchup()   →  Fetch missing blocks from peers
driveLiveness()  →  Detect stuck consensus
```



### Single-Node Flow

On a single validator (e.g. during development):

1. Baton calls `schedulercoord_propose_block` on the mempool. The execution layer runs queued transactions and assembles a proposal.
2. SCP externalizes immediately (single-node quorum).
3. Baton calls `schedulercoord_commit_block` on the mempool. The execution layer commits the finalized proposal to storage.
4. Next drive cycle begins.



### Multi-Node Flow

With multiple validators:

1. **Propose.** A validator asks its mempool for a block proposal. The proposal contains the transactions and metadata.
2. **Disseminate.** The full consensus value (nomination + metadata) is broadcast to peers via Dogwood (see below). A compact hash reference (the “cue”) is sent through SCP.
3. **Validate.** Receiving validators ask their own mempool: “is this nomination valid against my state?” Validation runs asynchronously and results are cached.
4. **Converge.** SCP envelope exchange continues until validators agree. Agreement depends on quorum intersection and the configured trust assumptions.
5. **Commit.** Once SCP externalizes a value, each validator commits the block locally via its mempool.



### Execution During Block Production

The proposer and validators execute transactions differently.

**The proposer runs concurrent execution.** Transactions are fanned across multiple executors and coroutines in parallel. After a root call completes, NNInt capacity locks reserve its delta batch via atomic compare-and-swap (see [Parallel Execution: How Conflicts Are Resolved](../pages/architecture/execution-model.md#how-conflicts-are-resolved)). Which transaction wins a contested lock depends on thread scheduling. This is non-deterministic: two runs of the same transaction set on the same machine can produce different winners.

**The proposer captures nondeterministic outcomes.** Each transaction produces a `NondeterministicProposalData` payload covering proposal-dependent decisions such as capacity reservation outcomes and retrocausal queue observations. This payload is packaged alongside the signed transaction hashes (`SignedTransactionHash`) in the consensus proposal.

**Validators replay deterministically.** Validators receive the proposer’s nominated transaction list and the nondeterministic data. They reconstruct each transaction from their local mempool, pair it with the proposer’s captured decisions, and replay execution using those decisions as input. Validators do not re-run the concurrent race. They verify that the transactions produce the claimed state transitions, recompute the block hash, and confirm it matches.

|                       | Proposer                                                          | Validator                                 |
| --------------------- | ----------------------------------------------------------------- | ----------------------------------------- |
| Execution             | Concurrent across executors                                       | Deterministic replay with proposer’s data |
| Conflict resolution   | Non-deterministic thread race                                     | Reproduced from captured decisions        |
| Transaction selection | Discretionary (from local mempool)                                | Fixed (from nomination)                   |
| Output                | Nomination: signed tx hashes + nondeterministic data + block hash | Accept or reject the nomination           |

The proposer has discretion over which transactions to include and which conflicting transaction wins. Validators verify the math of the proposed result, not the policy that produced it. Deterministic replay makes the proposed result verifiable. It does not establish proposer fairness; scheduling and transaction selection are separate from validating state transitions.



## Dissemination: Dogwood

Validators exchange three types of data during consensus:

| Data                 | Description                                                               |
| -------------------- | ------------------------------------------------------------------------- |
| **Transactions**     | Signed transactions gossiped between validators                           |
| **Consensus values** | Full block nominations (transactions + metadata)                          |
| **SCP envelopes**    | Protocol messages for agreement (nominate, prepare, confirm, externalize) |

Dogwood is the dissemination layer. It uses **erasure-coded multicast**: data is split into chunks, encoded with redundancy, and broadcast over BFS multicast trees. Receivers can reconstruct the original data from a subset of chunks, reducing bandwidth requirements while tolerating packet loss.

Each data type is tagged and demultiplexed on receipt. Transactions are forwarded to the mempool. Consensus values are cached locally for validation. SCP envelopes are fed to the embedded SCP kernel.



## Finality Model

Under the required quorum assumptions, loss of enough validators can stop progress without invalidating finalized blocks. Incorrect or disjoint trust configurations can violate those assumptions.

Practical implications:

- **No confirmation count.** A confirmed transaction is final. There is no “wait for 6 blocks” or “99.9% probability of finality.”
- **Finalized blocks.** Under the consensus safety assumptions, finalized blocks are not replaced by competing blocks.
- **Halt recovery.** If the network halts due to quorum loss, it resumes from the last committed block once enough validators return. Nodes may need to catch up before participating again.



## Catchup and Repair

Validators that fall behind (new nodes, network partitions, restarts) catch up by fetching missing blocks from peers. The catchup agent requests blocks by height, validates them, and replays them locally.

A separate repair agent handles missing data during active consensus: if a validator receives a hash reference it cannot resolve (a consensus value or SCP envelope it hasn’t seen), it requests the full data from the originating peer.



## Related Documentation

- [Networking](../pages/architecture/networking.md): Node topology and how the coordinator connects to the mempool
- [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Parallel Execution](../pages/architecture/execution-model.md): How transactions execute against snapshots
- [System Overview](../pages/architecture/system-overview.md): The component map

---

## Networking

Source: <https://www.thruput.network/docs/architecture/networking/>

Node topology, component registration, and how transactions reach the mempool.

The [System Overview](../pages/architecture/system-overview.md#components) maps the main components. This page explains how they find each other and communicate.



## Topology

Project Thruput’s services are organized into an execution layer and a consensus layer.

The **coordinator** (chuckd, written in Go) sits above the execution layer. It drives consensus with other validators, manages peer topology, and tells the local mempool when to produce and commit blocks.

The **mempool** (scheduler, part of hogd) is the hub of the execution layer. All execution components register with it: executors, DB shards, event server, auth server. The mempool orchestrates block production, transaction execution, and state commits.

Separately, the **RPC gateway** (`hog-gateway`) provides external API access. It connects to the scheduler, indexer, database gateway, and view gateway but does not participate in consensus. It can be scaled independently of the validator.

Within the execution layer, no component discovers peers independently. The mempool is the registry for intra-node communication. When a component registers, it gets back the addresses of everything else it needs to talk to.

The coordinator manages inter-node consensus and transaction gossip using its configured peers and quorum sets. See [Consensus](../pages/architecture/consensus.md) for how coordinators reach agreement.



## Component Registration

Components register their addresses and readiness with the scheduler. Most use an “intro” RPC; the event server uses a prepare/activate handshake. The scheduler waits for the required components before dispatching work.

Registration interfaces:

1. **DB shards** register via `scheddb_intro_shard`. Multiple shards can register (horizontal storage scaling).
2. **Event server** registers via `schedevent_prepare_event` and `schedevent_activate_event`. One per node.
3. **Executors** register via `schedexec_intro_exec`. Multiple executors can register (parallel transaction execution).
4. **Auth server** registers via `mempoolauth_intro_auth`. Handles transaction signature verification.
5. **Coordinator** registers via `schedulercoord_intro_coord`. Drives consensus and block production.

The listed execution-layer interfaces use XDR-RPC over TCP. Protocol definitions live in `.x` files (XDR IDL) and are compiled to C++ (hogd), Rust (thruput-protocol-rs crates such as `thruput-xdr`), TypeScript, and Go bindings.



## The Mempool as Orchestrator

The mempool (scheduler) is more than a transaction pool. It orchestrates the block lifecycle:

- Receives client transactions directly from the RPC gateway and peer transactions from the coordinator
- Verifies transactions through the auth server
- Maintains per-account transaction queues with balance-proportional scheduling
- Assembles block nominations when the coordinator requests them
- Dispatches transactions to executors for parallel execution
- Collects execution results after executors have submitted their deltas to the database for reservation
- Notifies DB shards of state changes at commit

The coordinator requests proposals and commits. The scheduler coordinates the execution services that perform the work.



## Coordinator Connection

The coordinator (chuckd) is the consensus participant. It connects to the mempool and drives block production through these RPC calls:

| Call                            | Purpose                                           |
| ------------------------------- | ------------------------------------------------- |
| `schedulercoord_propose_block`  | “Build a proposal for this block”                 |
| `schedulercoord_validate_block` | “Is this peer’s proposed block valid?”            |
| `schedulercoord_commit_block`   | “Finalize this block”                             |
| `schedulercoord_submit_vetted`  | Forward peer-gossiped transactions to the mempool |

The mempool also calls back to the coordinator via a reverse RPC channel to notify it when transactions pass vetting (triggering dissemination to peers).



## External Access

Clients submit transactions and query state through the public gateway.

**JSON-RPC gateway.** Exposes JSON-RPC 2.0 over HTTP and routes requests to the relevant execution-layer service. See [JSON-RPC API](../pages/reference/json-rpc-api.md) for the method reference.

**Wallet integration.** Wallets sign transactions client-side and submit them through the JSON-RPC gateway. See [Wallet Integration](../pages/typescript/wallet-integration.md) for the application-facing flow.



## Transaction Flow

Client submissions reach the scheduler through the gateway; peer-gossiped transactions arrive through the coordinator. The coordinator then drives proposal, validation, and commit through the interfaces above. Follow [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md) for the complete sequence and its possible outcomes.



## Related Documentation

- [Consensus](../pages/architecture/consensus.md): How the coordinator reaches agreement with peers
- [Parallel Execution](../pages/architecture/execution-model.md): How transactions execute against snapshots and produce deltas
- [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md): The six stages from submission to commit
- [System Overview](../pages/architecture/system-overview.md): The component map

---

## For Blockchain Developers

Source: <https://www.thruput.network/docs/architecture/coming-from/blockchain/>

Understand Project Thruput's storage and execution rules through a familiar token transfer.

The contract lifecycle is familiar: write, test, deploy, and call. The main changes are how storage updates combine and how execution and storage are funded. This page introduces those shifts using a Solidity transfer as the starting point.

***



## Token Transfers

A token transfer on Solidity:

```solidity
function transfer(address to, uint256 amount) public {
    require(balances[msg.sender] >= amount, "insufficient");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

The same transfer on Project Thruput:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The code stays familiar. `balances` is a `Map<ContractAddress, Balance>`. Calling `at_mut(address)` selects the balance that will change and returns a mutable handle. Selecting it does not load the balance.

`decrease(amount)` loads the sender’s snapshot balance because the contract needs to fail immediately when funds are insufficient. `lazy_increase(amount)` skips the receiver load because the contract does not need an immediate overflow result. Its bound is checked when the transaction’s completed delta batch is admitted. Both calls produce deltas that can merge with compatible transactions. `Balance` accepts only nonnegative amounts and exposes no absolute `set` operation.

[Build a Token](../pages/guides/build-a-token.md) uses this pattern in a complete contract. [Merged Deltas](../pages/contracts/execution.md#merged-deltas) explains how Project Thruput combines changes across a block.

***



## Reentrancy and Balance Checks

`Balance::decrease` checks the transaction’s current balance view. The runtime also checks aggregate bounds when concurrent deltas are reserved. This does not replace authorization or application-specific checks.

Contract calls also have different reentrancy rules from the EVM. See the [EVM reentrancy comparison](../pages/architecture/coming-from/evm.md#reentrancy) for that call pattern, and [Authorization](../pages/contracts/authorization.md) for caller checks and signed permissions.

***



## Resource and Transaction Rules

Project Thruput exposes these rules to contract developers:

- **Gas price estimation.** Gas limits exist for metering, but gas costs zero. The declared gas limit still consumes scheduling capacity.
- **Ordering-sensitive balance updates.** Commutative balance deltas have the same merged outcome in any execution order. Application flows that conflict still need protocol-aware design.
- **Nonces.** Replay protection uses a unique expiry-height and nonce pair, without a sequential account counter.
- **Access lists.** Project Thruput discovers storage access during execution. Compare [Solana account declarations](../pages/architecture/coming-from/solana.md#access-lists-vs-type-based-parallelism) with Ethereum’s optional [EIP-2930 access lists](https://eips.ethereum.org/EIPS/eip-2930).
- **Storage slot packing.** Typed fields via `#[thruput_sdk::storage]`. No manual layout, no packing variables into 256-bit slots.
- **TTL management.** No storage expiry. Data persists as long as its native-token deposit is held. Delete the data, get the deposit back.

***



## The Programming Model in Brief

Choose operations that express the change you intend. Use `Balance` for ordinary balance adjustments, `Map` for separate records, and other storage types when the application needs different merge rules. Compatible arithmetic can combine, but ordering-sensitive workflows still need an explicit design.

[Contract Execution](../pages/contracts/execution.md) explains snapshots and deltas. [Storage Types](../pages/contracts/storage-types.md) covers the available APIs, and [NNInt and concurrent updates](../pages/contracts/nnint.md) covers the lower-level integer model.

***



## Storage Choices and Parallelism

The transfer example uses relative balance adjustments so compatible transfers can share a block. Replacing those adjustments with absolute values changes the conflict rules. Review your data model, not just the syntax, when adapting an existing contract.

***



## Next Steps

Continue in layers:

1. [Contract quickstart](../pages/get-started/contract.md) builds and deploys your first contract.
2. [Build a Token](../pages/guides/build-a-token.md) applies checked and lazy balance operations in a complete ERC-20-style contract.
3. [Contract Execution](../pages/contracts/execution.md) and [Storage Types](../pages/contracts/storage-types.md) give the full contract-author model.
4. [How Conflicts Are Resolved](../pages/architecture/execution-model.md#how-conflicts-are-resolved) explains the engine’s reservation machinery.

For a detailed mapping from Solidity to Project Thruput, see [EVM & Solidity](../pages/architecture/coming-from/evm.md).

---

## EVM & Solidity

Source: <https://www.thruput.network/docs/architecture/coming-from/evm/>

Translate Solidity contract patterns into Project Thruput storage, calls, and authorization.

The contract lifecycle remains write, test, deploy, and call. The main differences are typed storage updates, the call runtime, and resource accounting. This page compares those mechanisms, not network performance.



## The Contract Lifecycle

| Task       | Project Thruput path                                                     |
| ---------- | ------------------------------------------------------------------------ |
| Write      | Rust with SDK storage handles and contract macros                        |
| Compile    | `thruput build` produces an RV32 artifact and contract-spec sidecars     |
| Deploy     | Fund the new contract’s storage and deploy with the CLI or wallet client |
| Initialize | Call an ordinary method, optionally atomically through `deploy --init`   |
| Call       | Use generated Rust or TypeScript bindings                                |
| Read       | Use a typed view through the public client or `thruput view`             |

Project Thruput entrypoints use 8-byte IDs and CXS arguments. Ethereum contract calls commonly use a 4-byte selector and ABI arguments; see [Ethereum transactions](https://ethereum.org/en/developers/docs/transactions/). Use bindings rather than constructing either encoding manually.

Project Thruput deployment addresses derive from the deployer, nonce, and code hash. This resembles `CREATE2` in allowing address prediction, but uses a different preimage. See [Contract artifacts and addresses](../pages/contracts/artifacts-and-addresses.md).



## Mental Model Shifts

| Solidity / EVM pattern               | Project Thruput pattern                                                                                |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| Mapping of token balances            | `Map<ContractAddress, Balance>`                                                                        |
| Read-modify-write balance assignment | Checked or lazy relative balance changes                                                               |
| `require` or `revert`                | `ensure` or a typed contract exception                                                                 |
| `msg.sender`                         | `get_caller()`, the immediate caller                                                                   |
| Constructor                          | An ordinary initializer with a contract-defined guard                                                  |
| Solidity interface and ABI           | Shared Rust interface and generated contract spec                                                      |
| `view` / `pure`                      | Rust receiver choice does not enforce runtime read-only behavior; use the call’s read-only restriction |



## Execution Differences



### Reentrancy

An EVM external call can call back into a contract already on the stack; see [Solidity external calls](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls).

Project Thruput rejects invocation of a contract already on the call stack. For A → B → A, the last call is rejected as reentrant. This runtime check is separate from snapshot isolation. Reads within a transaction can still observe its own earlier changes and successful child calls.

Use [recoverable calls](../pages/contracts/cross-contract-calls.md#error-handling) when the parent should inspect a child failure rather than propagate it.



### Ordering and MEV

Compatible arithmetic changes have the same merged value regardless of execution order. Conflicting operations do not all land together, and the proposer still selects transactions and conflict winners. This is not a guarantee that every application is free from ordering-dependent outcomes or MEV.



### Gas Limits and Gas Price Estimation

Ethereum transactions specify gas limits and fee parameters. Project Thruput gas meters execution but costs zero tokens, so no gas price estimation is needed. Gas usage still matters: the declared root limit consumes scheduling capacity, and exceeding it faults execution.

Unlocked native-token balances provide capacity; stored data requires separate deposits. See [Compute, Capacity & Storage](../pages/architecture/storage-economics.md).



### Nonce Management

Ethereum account transactions use a sequential nonce. Project Thruput replay protection uses an expiry-height and nonce pair, unique for the originating address. It need not increase sequentially. That permits independent transactions from one address without a sequential account counter.



### Integer Overflow/Underflow

`Balance` accepts nonnegative amounts. Its checked methods reject underflow or overflow during execution; lazy methods defer snapshot-bound checks to reservation. The runtime also enforces aggregate bounds across concurrent transactions.



### The `approve()` Race Condition

An absolute allowance replacement can grant new spending authority after the previous allowance has already been spent. The example Project Thruput token instead uses relative allowance adjustments. The caller requests an increase or decrease, not a replacement amount.

This does not remove the need to inspect outcomes or choose an authorization policy. See the [token implementation](../pages/guides/build-a-token.md#apply-supply-and-allowance-policy) for its exact allowance methods and exclusive-update option.



## Pattern Adaptations



### Balance Transfer

In a token implementation, use balance deltas:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution. The lazy credit skips a balance load and defers its bound check. Other changes and resource limits still determine whether complete transactions can land together.



### Access Control

Store an owner or role policy and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Define `Error` with `#[contract_exception]`. A forwarding contract becomes the immediate caller; it does not inherit the original user’s identity. See [Authorization](../pages/contracts/authorization.md).



### Constructor and Initialization

Project Thruput does not invoke `initialize` automatically or make it once-only. Guard initialization in contract storage when required. The CLI’s [atomic initialization](../pages/cli/deploy-and-call.md#include-initialization) combines funding, deployment, and the initializer call.



### Events

Define events with `#[derive(Event)]`, mark filterable fields with `#[topic]`, and declare emitted types on the contract interface. See [Events](../pages/contracts/events.md) for the complete pattern and [Read events](../pages/typescript/events.md) for application queries.

[Build a token](../pages/guides/build-a-token.md) walks through the maintained ERC-20 implementation, including allowances, supply policy, events, and tests.



## What Doesn’t Exist

| EVM feature                               | Project Thruput approach                                    |
| ----------------------------------------- | ----------------------------------------------------------- |
| `msg.value`                               | Transfer tokens explicitly through their contract interface |
| `delegatecall` and proxy code replacement | Deploy a new immutable contract at a new address            |
| `selfdestruct`                            | No equivalent contract-removal operation                    |
| Solidity `receive` / `fallback` dispatch  | Use declared methods in the generated SDK dispatcher        |
| Storage-slot packing                      | Use typed storage paths                                     |

Block context and gas inspection do exist: `get_block_timepoint()`, `get_block_height()`, and `stats::gas_remaining()`. Artifact and transaction bounds are network constraints, not EVM limits; see [Contract artifacts](../pages/contracts/artifacts-and-addresses.md).



## Next Steps

- [Contract quickstart](../pages/get-started/contract.md): build and deploy a counter
- [Build a token](../pages/guides/build-a-token.md): maintained token code and tests
- [Contract Execution](../pages/contracts/execution.md): snapshots and deltas
- [Storage Types](../pages/contracts/storage-types.md): choose a storage API

---

## Solana & Anchor

Source: <https://www.thruput.network/docs/architecture/coming-from/solana/>

Translate Solana account, storage, and CPI patterns into Project Thruput contracts.

Both ecosystems support Rust contract development. Project Thruput changes how a contract addresses state and how concurrent writes combine. The comparison below follows Solana’s [account model](https://solana.com/docs/core/accounts) and [CPI rules](https://solana.com/docs/core/cpi).



## Accounts vs. Storage

Solana state lives in accounts with an address, owner, lamport balance, and data. Instructions receive declared accounts; Anchor expresses their expected types and constraints.

Project Thruput stores typed fields under contract addresses. For example, a token implementation uses `Map<ContractAddress, Balance>` rather than receiving separate token-account objects for each balance. Contract code still checks caller authority and application rules.



## Access Lists vs. Type-Based Parallelism

Solana transactions declare account access before execution. The runtime uses read/write access to schedule work; transactions that contend for a writable account cannot execute together in that schedule.

Project Thruput discovers storage access during execution. Typed merge rules allow compatible changes to the same location to combine. Different map keys use separate locations, but other shared writes and storage-funding limits can still conflict.



## The Contract Lifecycle



### Writing

| Anchor concept                    | Project Thruput SDK concept                                                  |
| --------------------------------- | ---------------------------------------------------------------------------- |
| `#[program]`                      | `#[contract]` on an interface or implementation                              |
| Account-data structure            | Typed fields under `#[thruput_sdk::storage]`                                 |
| `#[derive(Accounts)]` constraints | Explicit argument and authorization checks; no caller-supplied account array |
| Initialization instruction        | Ordinary initializer, optionally called atomically with deployment           |



### Compiling

Solana programs compile to SBF. Project Thruput contracts compile to RV32 through:

```bash
thruput build
```

The build produces a deployable artifact and contract spec. Keep the generated toolchain and dependencies together.



### Deploying

Project Thruput deployment derives an address from the deployer, nonce, and code hash. This shares a PDA’s predictability, not its derivation or authorization model. See [Contract artifacts and addresses](../pages/contracts/artifacts-and-addresses.md).



### Calling

Use a generated client for another contract:

```rust
let token = ERC20Client::new(&token_address);
token.transfer(&recipient, amount);
```

The receiver sees the calling contract as its immediate caller. [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md) covers gas limits and recoverable errors.



## Mental Model Shifts

| Solana / Anchor pattern              | Project Thruput pattern                                          |
| ------------------------------------ | ---------------------------------------------------------------- |
| Per-user state account               | Often a `Map` entry under the contract                           |
| Serialized account data              | Typed storage handles                                            |
| Account-level write conflicts        | Storage-type merge rules, including compatible shared-key deltas |
| Rent-exempt storage balance          | Storage deposit backed by native tokens                          |
| Compute-unit budget                  | Gas limit, with no token fee for gas                             |
| Signer privileges passed through CPI | Immediate caller identity and explicit runtime auth tokens       |



## Account and Call Patterns



### Account Arrays and Validation

Project Thruput has no caller-supplied account array. That removes account-list construction, not authorization. Validate caller identities, contract addresses, amounts, and application conditions before applying changes.



### Rent and Account Lifecycle

Solana accounts hold a refundable minimum lamport balance for their storage. Project Thruput storage also requires funding: it locks native tokens according to the data’s type and size, and releases the deposit when data is deleted. The runtime accounts for it, but the owning address must have enough funds.



### Compute Unit Budgets

Project Thruput gas limits bound computation, including child calls. Gas costs zero tokens, but a root transaction’s declared limit consumes scheduling capacity. Account funding and execution bounds still matter. See [Compute, Capacity & Storage](../pages/architecture/storage-economics.md).



### PDA Seed Management

A PDA used only for per-user state often maps to a `Map` entry. A PDA used as an authority needs an authorization design as well; replacing its storage with a map does not reproduce its signing role.



### Signer Propagation in CPIs

Solana CPI passes existing signer and writable privileges to the callee. `invoke_signed` additionally supplies seeds when the calling program must authorize a PDA. Ordinary CPI does not always require signer seeds.

Project Thruput’s `get_caller()` returns the immediate calling contract, not the root signer. Use contract policy, allowances, or [typed auth tokens](../pages/contracts/authorization.md#auth-tokens-and-signedt) when authority must pass through several calls.



## Pattern Adaptations



### PDA State Accounts → Map Fields

```rust
#[thruput_sdk::storage]
pub struct Registry {
    user_states: Map<ContractAddress, Value<UserState>>,
}
```

`UserState` is your serializable application type. Access an entry with `at` or `at_mut`; first writes create storage and require its deposit. See [Storage Types](../pages/contracts/storage-types.md).



### Token Transfer

Inside a token implementation:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

This updates the token’s own balance map. To transfer another contract’s token, call its generated client rather than writing its storage directly.



### Cross-Program Invocation → Cross-Contract Call

```rust
let token = ERC20Client::new(&token_address);
let result = token.try_mint(&recipient, amount);
```

The callee applies its own authorization policy. `try_mint` returns a `Result`; the direct `mint` method propagates failure. See [Handle errors](../pages/contracts/errors.md).



### Error Handling

Define errors with `#[contract_exception]` and check conditions with `ensure`:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Unlike signer-account validation, this checks the immediate contract caller. A failure aborts the frame and discards its contract effects.



## What Doesn’t Exist

Project Thruput does not use Solana account arrays, associated token accounts, PDA bump seeds, or account `space`/`realloc` arguments. It has its own contract-address, storage, and authorization models. These are pattern translations, not wire or tooling compatibility.



## Next Steps

- [Contract quickstart](../pages/get-started/contract.md): build and deploy a counter
- [Build a token](../pages/guides/build-a-token.md): token state and tests
- [Storage Types](../pages/contracts/storage-types.md): map and balance APIs
- [Authorization](../pages/contracts/authorization.md): caller and auth-token rules

---

## Stellar & Soroban

Source: <https://www.thruput.network/docs/architecture/coming-from/stellar/>

Map Stellar and Soroban operations to Thruput storage, authorization, and development workflow.

Stellar provides native payments, assets, trustlines, and a decentralized exchange alongside Soroban smart contracts. Your Rust and contract-design experience applies to Project Thruput. The network, executable format, contract interfaces, and authorization model are different. This page shows what changes when you port a Soroban contract. It does not cover moving assets between chains or running Soroban Wasm on Thruput.

Project Thruput is a development network. Its relationship to the Stellar network is not decided. See [Architecture](../pages/architecture.md).



## Before you start

Install the [Thruput CLI](../pages/cli/install.md). `thruput new` [creates a project](../pages/cli/create-project.md) with native and RV32 guest tests.

The examples follow one payment. Alice starts with 100 units. She pays Bob 10 directly, then 7 through a router. Alice ends with 83 and Bob with 17. Mallory tries to spend Alice’s balance and is refused. The Soroban side is a small fixed-supply teaching ledger, not a full token implementation. It follows the official [Soroban auth](https://developers.stellar.org/docs/build/smart-contracts/example-contracts/auth) and [cross-contract](https://developers.stellar.org/docs/build/smart-contracts/example-contracts/cross-contract-call) examples: enum storage keys, a generated client, typed errors, and scoped authorization tests. The Thruput side uses the ERC20 token from [Build a token](../pages/guides/build-a-token.md).



## Keys and addresses

Thruput supports the `G` public-key and `S` seed encodings for Ed25519 keys. A G public key identifies a signer, not its Thruput wallet. Thruput derives an account address from a hash of the key and a nonce, so one key can control more than one account.

Thruput address inputs accept base58 or a checksummed Thruput `Z` StrKey. Stellar `C` contract addresses are rejected. Reports and JSON-RPC identifiers use base58. A Z address does not identify a network. Select the intended profile and use the address reported by the tools. See [keys and wallets](../pages/cli/wallets.md).



## Map the development workflow

| Soroban                                                                 | Thruput                                                                                                                                                                         |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `stellar contract build` produces Wasm                                  | `thruput build` produces an RV32 artifact and a contract spec                                                                                                                   |
| `__constructor` runs at deployment                                      | An ordinary initializer with a contract-defined guard, run atomically with [`deploy --init`](../pages/cli/deploy-and-call.md)                                                   |
| `stellar contract deploy`                                               | `thruput deploy`; fund the contract’s storage with an explicit `--fund` amount when you use `--init`                                                                            |
| `Address`, `#[contracttype]`                                            | `ContractAddress`, `#[contract_type]`                                                                                                                                           |
| `env.current_contract_address()`                                        | `get_current_address()`; `get_caller()` returns the immediate caller                                                                                                            |
| `stellar contract invoke`, sent or simulated                            | `thruput call` submits a transaction; `thruput view` simulates against committed state                                                                                          |
| `contractimport!` and generated clients                                 | Generated Rust clients from a shared interface; `try_*` methods return a [`CallError`](../pages/contracts/cross-contract-calls.md#callerror)                                    |
| `#[contracterror]` and `Result<T, E>` returns                           | [`#[contract_exception]`](../pages/contracts/errors.md); exported methods throw instead of returning `Result`                                                                   |
| `#[contractevent]` types, or the older `env.events().publish`           | Declared [typed events](../pages/contracts/events.md) emitted with `log_event`. Topic 0 is the event’s signature, not static symbols; up to two fields can be marked as topics. |
| `env.ledger().timestamp()` (Unix seconds) and `env.ledger().sequence()` | `get_block_timepoint()` (Unix nanoseconds, fixed for the block) and `get_block_height()`                                                                                        |
| `update_current_contract_wasm`                                          | Deployed contracts are [immutable](../pages/contracts/artifacts-and-addresses.md); deploy a new contract at a new address                                                       |
| `Env` tests with `mock_auths` and `env.auths()`                         | [`TestEnvironment`](../pages/contracts/testing.md) transactions with explicit callers and `env.advance_block()`, run natively and as RV32 guests                                |

Generated Thruput projects set `overflow-checks = false` in their release profile, while the Soroban examples set `true`. Plain `+` that panics on overflow in a Soroban build wraps in the RV32 guest, even though native tests still panic. Use checked arithmetic and throw a typed exception where the source relied on that panic. Test the overflow path in the RV32 guest.



## Read and change balances

In the Soroban ledger, an enum key identifies each balance in persistent storage:

```rust
pub fn balance(env: Env, id: Address) -> i128 {
    env.storage()
        .persistent()
        .get(&DataKey::Balance(id))
        .unwrap_or_default()
}
```

The transfer checks authorization and a nonnegative amount, checks the available balance, then writes the debit and credit.

The Thruput token uses `Map<ContractAddress, Balance>`. A missing balance also reads as zero:

```rust
fn _balance_amount_of(&self, owner: &ContractAddress) -> Amount {
    self.balances.at(owner).get()
}
```

A `Balance` handle supplies nonnegative amount checks and checked or lazy changes. This excerpt shows a direct transfer:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `Amount` is `i128`. The excerpt simplifies error handling: the example token uses `try_decrease` and throws `ERC20Error::TooLarge` when the balance is insufficient. The checked debit detects insufficient funds during execution. The lazy credit records a relative change. Relative changes from different transactions can merge if the combined result stays within the balance bounds.

[Build a token](../pages/guides/build-a-token.md) covers the complete example: initialization, supply policy, error mapping, allowances, and events.

Thruput tokens use native contract interfaces. The SDK’s `thruput-sep41` client adapter provides familiar token operations over supported ERC20 interfaces. It uses Thruput caller authorization, native events, and Thruput block heights for approval expiry. See [Rust API Docs](../pages/contracts/reference/rust-api-docs.md) for exact signatures and the [adapter’s API comments](https://github.com/thruputchain/thruput-sdk-rs/blob/main/standard-impls/thruput-sep41/src/lib.rs) for its requirements and differences.

The adapter does not provide Soroban ABI compatibility. Moving assets between Stellar and Thruput through a bridge is a separate integration. Each bridge defines its supported assets and transfer guarantees.



## Port authorization

For each operation, find whose authority it needs and how that authority reaches the contract.

Soroban’s [`Address::require_auth()`](https://docs.rs/soroban-sdk/latest/soroban_sdk/struct.Address.html#method.require_auth) checks that an address authorized the invocation and its arguments. User authorization can cover a tree of contract calls. The contract can use an `Address` without implementing signature checks itself. It does not need to treat that address as the immediate caller. In Soroban, a contract that calls another contract directly is authorized for its own address. This invoker rule is the closest match to `get_caller()`.

Thruput separates transaction admission from the authority a contract uses during execution:

| Question                                         | Thruput mechanism                                                             |
| ------------------------------------------------ | ----------------------------------------------------------------------------- |
| May this account originate the root transaction? | Transaction signatures and the account’s admission policy                     |
| Which address called this method directly?       | `get_caller()`                                                                |
| May this intermediary act for another address?   | An allowance or explicit auth-token policy enforced by the receiving contract |

Do not replace `from.require_auth()` with `get_caller() == from` before you check the full call path. Signing the root transaction does not grant arbitrary downstream authority. The root frame itself has no caller.



### Direct payment

For a direct Thruput wallet-to-token call, the token sees the wallet as its caller. The transfer excerpt above spends that wallet’s balance.

Soroban’s ledger transfer instead receives an explicit `from` address and calls `from.require_auth()`. The named address must authorize the operation. A supplied address alone is not authority.



### A user acting on their own state

Soroban’s [auth example](https://developers.stellar.org/docs/build/smart-contracts/example-contracts/auth) calls `user.require_auth()` before changing that user’s own counter. When the source has no intermediary, checking `get_caller() == user` keeps who may change the record. This removes two behaviors. Another account cannot submit the call for the user, as a Soroban relayer or fee sponsor can. Thruput does not support sponsored transactions yet. They are [planned](../pages/architecture/roadmap.md#sponsored-transactions). A call through an intermediary is refused, because the callee sees the intermediary. Document this change, and test that a forwarded call is refused.



### Payment through a router

In the Soroban example, the router roots authorization in the payment and calls the ledger through its generated client:

```rust
pub fn pay(env: Env, ledger: Address, from: Address, to: Address, amount: i128) {
    from.require_auth();
    LedgerClient::new(&env, &ledger).transfer(&from, &to, &amount);
}
```

The ledger also calls `from.require_auth()`. Tests should inspect the complete root-and-child authorization tree with `env.auths()` before reading balances. A missing child authorization or changed recipient is refused.

On Thruput, a token called by a router sees the router. Calling its direct `transfer` method spends the router’s balance, even when Alice signed the transaction. A router that forwards to `transfer` is an easy porting mistake.

The working port uses the token’s allowance interface. Alice first calls the token’s `adjust_allowance` to grant the router a budget. The router then binds the payer to its own immediate caller:

```rust
pub fn pay(token: &ContractAddress, to: &ContractAddress, amount: i128) {
    let payer = get_caller();
    ERC20Client::new(token).transfer_from(&payer, to, amount);
}
```

Mallory cannot name Alice as the payer through this method. Mallory’s separate call to the token also lacks Alice’s allowance to Mallory. Test balances and the remaining grant after each refused attempt.

This port changes the authorization policy. An allowance is a persistent spending budget. It usually does not bind a recipient. A Soroban authorization tree can bind the operation, recipient, amount, and child calls. Use a narrower grant interface when the application needs authority for one operation only.

For such interfaces, Thruput’s `Signed<T>` is a typed runtime auth-token handle, not an off-chain signature or a durable bearer token. Pass it explicitly. The receiving contract must check the consumed minter and payload against its policy. See [caller identity and auth tokens](../pages/contracts/authorization.md).



### Several parties authorizing one operation

In Soroban’s [atomic swap](https://developers.stellar.org/docs/build/smart-contracts/example-contracts/atomic-swap), each of two parties authorizes its side of one invocation. Both signed entries travel in one transaction. Each is consumed only if that transaction succeeds. A Thruput transaction has one source address, and `get_caller()` names one address. Detached signatures cannot yet become `Signed<T>` values; a wallet contract must check a signature and mint the token during execution.

A port can store a grant for each party before the swap. Alternatively, each party’s wallet can mint a `Signed<T>` in the swap transaction. Bind each grant to the source’s authorized arguments. Consume it once, and give it an expiry and a revocation path. Check when each authorization is consumed. If a call that does not complete the swap can consume it, anyone who can submit that call can cancel that party’s side.



## Other porting decisions

| Starting point                                      | Thruput decision                                                                                                                                                                                    |
| --------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Classic payments and asset operations               | Select a token contract and its transfer policy. Native Stellar asset semantics are not automatic.                                                                                                  |
| Trustlines and asset authorization                  | Store policy and enforce it on every relevant operation. A stored flag alone does not restrict transfers.                                                                                           |
| Several classic operations                          | Compose calls in one root transaction or a DefaultWallet typed call batch.                                                                                                                          |
| Soroban storage get/set                             | Select typed handles such as `Value`, `Map`, and `Balance`; review their merge rules.                                                                                                               |
| Instance, Persistent, and Temporary storage         | Review lifetime requirements. Thruput has one persistent model and no storage TTL; funded data remains until deleted.                                                                               |
| Built-in offers, liquidity pools, and path payments | Select an application-defined venue. Thruput has no built-in order book or liquidity pool.                                                                                                          |
| Inclusion fees                                      | Gas costs zero tokens. Scheduling uses the sender’s native-token balance. Sponsored transactions are [planned](../pages/architecture/roadmap.md#sponsored-transactions).                            |
| Resource fees and rent for storage                  | [Storage deposits](../pages/architecture/storage-economics.md) come from the contract that owns the data, not the submitter. A write the contract cannot fund is excluded, not aborted.             |
| Methods that let any caller create entries          | Each new balance, allowance, or per-user record spends the contract’s funds. Decide who may create entries, and consider refusing writes that only allocate, such as zero approvals for a new pair. |

Soroban’s Temporary data is deleted at TTL expiry. Persistent and Instance entries can be archived and restored. See [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival). Anyone can extend an entry’s TTL. For this reason, Stellar’s storage guidance stores an explicit deadline and checks it on read. Port that check as it is. Some sources also extend a Temporary entry to its deadline. Soroban then refuses deadlines past the network’s maximum TTL. Thruput block heights have no such limit. Keep an explicit bound if the source relied on it.



### Transaction snapshots

On Stellar, the result of a ledger matches applying its transactions one at a time in order. Thruput transactions in the same block execute against the same committed snapshot. A transaction does not read another transaction’s writes in that block. Later calls within one transaction see its own changes, including successful child calls. See [Contract Execution](../pages/contracts/execution.md). In SDK tests, call `env.advance_block()` after a write before a dependent transaction reads it. A test transaction reporting success does not advance the block.

Authorization checks read the snapshot too. After an admin change or a revoked grant, the previous holder still passes a stored-role check in other transactions of the same block. Their writes land unless they conflict with the change. Test the previous holder acting in that block.

Two absolute `Value::set` writes can coexist when they store the same value. A read/increment/set port could therefore lose an increment even if both writes land. Use Balance deltas when their bounds and return semantics fit, or an [exclusive write](../pages/contracts/storage-types.md#exclusive-writes) for an absolute update that needs one included writer. Preserve source numeric limits. Exclusion does not guarantee an automatic retry.



### Atomic calls and queued work

[Classic Stellar transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions) can bundle operations atomically. Soroban transactions contain one smart-contract operation, which can invoke other contracts.

A Thruput transaction has one root invocation, which can call several contracts. The native DefaultWallet also supports [atomic typed call batches](../pages/typescript/transactions.md#execute-multiple-calls). If the root aborts, its contract changes and successful child changes are discarded. A parent using recoverable calls can handle a child’s failure and continue. See [Invocation Frames](../pages/contracts/invocation-frames.md).

If the source completes an operation in one call, keep it that way. Use a queue only if a delayed result is acceptable. The [AMM example](../pages/guides/build-an-amm.md) shows queued requests processed in later transactions; there, acceptance is not a completed swap.



## Work with an agent

Install the Thruput agent skill with `thruput skill install`. See [agent tools](../pages/cli/agent-tools.md). Then give your agent one workflow:

```text
Help me port one small Soroban contract to Thruput.
Read the source contract, its tests, and its dependency pins.
Use the Stellar & Soroban docs page as a checklist.
Identify the authorized principal, amount bounds, call path, and state changes.
Preserve synchronous behavior unless the application requires later processing.
Explain any change from invocation-specific authority to an allowance or grant.
Check direct, unauthorized, and forwarded calls, including the actual payer.
Port the tests and run them natively and as RV32 guests. Match expected errors
and inspect state after success and refusal. Report unrun checks as unverified.
Do not infer bridge, token-standard, or Soroban ABI compatibility.
```

For the Thruput execution and storage model, continue with [Contract Execution](../pages/contracts/execution.md), [Storage Types](../pages/contracts/storage-types.md), and [Testing](../pages/contracts/testing.md).

---

## For Backend Developers

Source: <https://www.thruput.network/docs/architecture/coming-from/backend/>

Map your Postgres and database experience to Project Thruput's programming model.

Database snapshot isolation is a useful starting point for Project Thruput. Transactions share a committed block snapshot, but their writes follow typed storage merge rules rather than SQL conflict rules.



## Shared Snapshot

Every transaction in a block starts from the previous block’s committed state. Ordinary storage reads include its own changes and successful child calls, but not other transactions’ writes. `RetrocausalQueue` has separate rules for observing concurrent inserts. Each transaction produces typed changes, called **deltas**. Compatible deltas form the next committed state. See [Merged Deltas](../pages/contracts/execution.md#merged-deltas).



## Deltas, Not Assignments

The core shift from a database: instead of `UPDATE accounts SET balance = 50`, you call `increase(5)`, meaning “adjust this value by +5.” This is `UPDATE accounts SET balance = balance + 5`. You express **how the value should change**, not what it should become.

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);          // checked debit
    self.balances.at_mut(receiver).lazy_increase(amount);    // deferred bound check
}
```

[`Balance`](../pages/contracts/storage-types.md#balance) is the SDK type for this pattern. Both calls record deltas that can merge with concurrent transactions. `decrease()` loads the sender’s balance so an insufficient debit fails during execution. `lazy_increase()` skips the receiver load and defers its bound check until the delta batch is reserved. If two transactions debit 20 and 30 from a balance of 100, both can land and the next balance is 50. Applying the changes in either order gives the same result, so the operations **commute**.

[NNInt and concurrent updates](../pages/contracts/nnint.md) explains the representation behind these balance operations, including base matching and early bound checks.

**Relative updates such as `SET col = col + ?` map naturally to mergeable integer operations.** Compatibility still depends on bounds and the transaction’s other changes. Absolute replacements can conflict when they assign different values.

***



## Conflicts and Retries

When deltas conflict, that attempt is excluded from the proposal. Contract code does not retry the operation. The scheduler can requeue transactions after a nomination is rolled back or a different proposal commits, but exclusion does not guarantee automatic requeue or a `retry` status. Clients observe the original transaction and, when retrying is appropriate, resubmit the same signed bytes while valid. Replay protection permits at most one commitment. See [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md#exclusion-requeue-and-resubmission).

The balance constraint works the same way. If two concurrent withdrawals together exceed the available balance, one or more transactions are excluded. This is `CHECK (balance >= 0)` enforced by the storage model rather than application code.

***



## What’s Different From a Database

- **No ad-hoc queries.** Storage is key-value with typed values. You access data by key, not by query. An indexer provides query capabilities off-chain.
- **No JOINs.** If you need data from two Maps, you read both explicitly.
- **Deterministic execution.** Use block context rather than the host clock. Contract code cannot make HTTP calls or use the host’s random-number generator.
- **Storage deposits.** Stored data locks native tokens according to its type and size. Deleting the data returns the deposit.
- **No conventional gas fees.** Gas meters computation (prevents infinite loops) but no tokens are burned. Your unlocked native-token balance provides scheduling capacity under load. The declared gas limit determines how much capacity the transaction uses.

***



## Next Steps

For storage type details (`Balance`, `NNInt`, `Map`, `Vector`, `Value`, `Bytestring`, `CapacityConstraint`, and `RetrocausalQueue`) and their conflict semantics, see [Programming Model: Storage Types](../pages/contracts/storage-types.md). For the contract-level execution model, see [Merged Deltas](../pages/contracts/execution.md#merged-deltas).

Ready to write code? The [contract quickstart](../pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## For Distributed Systems Developers

Source: <https://www.thruput.network/docs/architecture/coming-from/distributed-systems/>

Understand Project Thruput's use of commutative updates within consensus blocks.

Project Thruput uses commutative operations to combine concurrent changes within a block. The storage model supports parallel execution; consensus selects the result validators commit.



## Your Head Start

Additions such as `+5` and `+3` have the same sum in either order. Project Thruput’s [`Balance`](../pages/contracts/storage-types.md#balance) and [`NNInt`](../pages/contracts/nnint.md) expose relative updates with explicit bounds. `Map<K, V>` gives separate keys independent storage locations.

The similarity to counters and maps in CRDT systems is useful, but the coordination model differs.



## Coordination at Block Boundaries

CRDTs can reconcile independently updated replicas. Project Thruput instead executes transactions against a common committed snapshot, reserves compatible typed changes, and uses [consensus](../pages/architecture/consensus.md) to select a finalized block.

- **Merge rules operate within a proposal.** Applications do not maintain vector clocks to reconcile ordinary balance or map updates.
- **Bounds still apply.** A balance cannot commit below zero. If concurrent debits exceed the available value, an overdrawing attempt is excluded from the proposal. Requeue and reported status depend on later processing. See [Transaction Lifecycle](../pages/architecture/transaction-lifecycle.md#exclusion-requeue-and-resubmission).
- **Consensus selects one result.** Validators verify the proposed state transition. Nodes that have applied the same finalized block agree on that state.
- **Readers can see different heights.** A node may lag while receiving or replaying blocks. Check the returned read height when freshness matters.



## If You Don’t Know Any of This

You can write contracts without implementing a concurrency algorithm. Choose the storage type for the updates your application needs, then use its ordinary Rust methods. The [backend-developer guide](../pages/architecture/coming-from/backend.md) explains the same model through database concepts.



## Next Steps

- [Contract Execution](../pages/contracts/execution.md): snapshots, deltas, and exclusion
- [Storage Types](../pages/contracts/storage-types.md): data-model choices
- [How Conflicts Are Resolved](../pages/architecture/execution-model.md#how-conflicts-are-resolved): engine reservation details
- [Contract quickstart](../pages/get-started/contract.md): build and deploy a counter

---

## Project Thruput roadmap

Source: <https://www.thruput.network/docs/architecture/roadmap/>

Things we'd like to see built in Thruput.

Building something on Thruput? Tell us what you’re trying to do and where you get stuck. Real examples help us decide what to build first and give us something to test as we go.



## Core improvements



### Sharded state storage

Sharded storage would increase the amount of state each validator can hold by spreading it across multiple HogDB instances. Applications would still see one key space and would not need to choose or manage shards. An [initial proposal](https://github.com/thruputchain/hogd/pull/3108) covers the first part of this work.



### Sponsored transactions

Today, the account that sends a transaction backs its scheduling with its own native tokens. A contract pays the storage deposits for data stored under its address, which lets an operator [sponsor its users’ storage](../pages/architecture/storage-economics.md#sponsoring-users). We plan to let one party cover scheduling or storage deposits for another. If you need to bring users on without asking them to hold tokens, submit transactions for them, or let callers cover storage deposits, tell us who should pay and what they should be able to limit.



### Post-quantum consensus

Post-quantum signing with ML-DSA-65 is already supported for accounts and contracts. The next phase is to extend post-quantum support to validator signatures and consensus. This needs protocol design, performance testing, and an upgrade path for future validators that may need to transition from classical to post-quantum signatures.



## Exploring



### External calls

We’re exploring how contracts could call services outside the chain within one atomic transaction. While a call is pending, executors would run other transactions. The proposer would record the response so other nodes could replay it. Responses would need to be self-authenticating, and block time would bound each call’s timeout. The contract API and abuse protections still need design. If your app needs a market-maker quote, an oracle read, or a compliance check during a transaction, we’d like to hear how that call would work.



## Open to builders



### Additional storage types

Contracts use the [storage types](../pages/contracts/storage-types.md) the SDK provides today. Earlier research prototypes also used ordered sets and bitmaps. If the current types make something hard to store or update, show us what you’re working with.



### Ecosystem tooling

The [wallet integration guide](../pages/typescript/wallet-integration.md) is a starting point for wallet builders. If you’re missing a wallet integration, oracle, or a convention that would help apps work together, come talk to us in [GitHub Discussions](https://github.com/thruputchain/thruput-docs/discussions) or on [Discord](https://discord.com/channels/897514728459468821/1564948118162898954). We’d be glad to work through your use case with you.
