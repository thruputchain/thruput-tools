# Understand Groundhog

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Introduction

Source: <https://docs.groundhog.dev/architecture/>

Learn what Groundhog is and how compatible updates let contracts share state.

Groundhog is an L1 blockchain for smart contract applications. You write contract logic in Rust and connect applications through the TypeScript client or React library.

Its central idea is that transactions can update shared state by recording compatible changes. The runtime combines those changes using rules defined by the storage type.



## Record the change

Consider a counter with a value of `100`. Two transactions want to increase it, one by `5` and the other by `3`.

If each transaction replaces the value it read, they propose different results: `105` and `103`. With mergeable integer storage, they record the increases instead:

```text
Starting value:    100
Transaction A:     +5
Transaction B:     +3
Combined value:    108
```

These increases can combine if the rest of the transactions are compatible and network limits permit them. Neither transaction needs to calculate a replacement value that includes the other’s update.

This is useful for shared counters and balances. It does not make every operation independent: replacing a value, enforcing uniqueness, or choosing a winning order can require different rules. Your storage choices determine which changes can combine.

[Parallel Execution](../pages/how-it-works/execution-model.md) explains how Groundhog applies these rules. [Storage types](../pages/programming-model/storage-types.md) shows how to use them in a contract.



## Build in two layers

**Contracts** define application rules and store onchain state. Use the Rust SDK to write and test them, and the CLI to build, deploy, and inspect them.

**Applications** read contract data and request transactions. The TypeScript client provides network and contract operations. The React library adds wallet connection and balance hooks for interfaces.

You can start with either layer. An application can use an existing contract without implementing one first.



## Where to start

Choose a path in [Get Started](../pages/get-started.md) to write code. To explore the platform first, use the [System Overview](../pages/how-it-works/architecture.md) as a map, then follow the [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md) or read about [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md).

---

## EVM & Solidity

Source: <https://docs.groundhog.dev/ecosystem/evm/>

Groundhog concepts for Solidity and EVM developers.

This guide is for developers who know Solidity and the EVM. It uses familiar EVM concepts to compare Groundhog’s storage and execution rules.

For the foundational concepts (delta operations, commutativity, storage types), see [For Blockchain Developers](../pages/start/for-blockchain-developers.md). This page builds on that with concrete patterns and a worked example.



## The Contract Lifecycle

If you’ve deployed and called contracts on Ethereum, the Groundhog lifecycle will feel familiar. The mechanics differ, but the shape is the same: write a contract, compile it, deploy it, call functions on it.



### Writing

Groundhog contracts are written in Rust and compiled to RV32 artifacts by default, not EVM bytecode. RV32 is Groundhog’s 32-bit RISC-V contract target. The SDK provides optional convenience macros, but you can also work directly with raw syscalls. A minimal contract looks like this:

```rust
use sdk::*;
use sdk::storage::NNInt;

#[contract_exception]
pub enum Error {
    NotAuthorized = 1,
}

#[derive(Debug)]
#[sdk::storage]
pub struct MyContract {
    value: NNInt,
}

#[contract(throws = Error)]
impl MyContract {
    pub fn increment(&mut self, amount: u64) {
        self.value.strict_inc(amount as i128);
    }

    pub fn get(&self) -> i128 {
        self.value.try_get().none_if_missing().unwrap_or(0)
    }
}
```

Where Solidity uses `constructor()`, Groundhog contracts commonly expose an ordinary `initialize` method. Deployment does not call it automatically or enforce that it runs once, so the contract must guard one-time initialization when that matters. Where Solidity uses `uint256` state variables, Groundhog uses typed storage fields (`Balance`, `NNInt`, `Map<K, V>`, `Bytestring`). The type you choose determines how concurrent writes merge. This is the core difference: storage types enforce parallelism rules, not the developer.



### Compiling

Solidity compiles to EVM bytecode. Groundhog contracts compile to RV32, a 32-bit RISC-V target, by default:

```bash
groundhog build
```

The output is a `.rv32a` artifact plus [contract spec](../pages/reference/contract-spec.md) sidecars, analogous to Solidity’s bytecode + ABI.



### Deploying

On Ethereum, you send a transaction containing bytecode, the EVM executes the constructor, and you get an address back. On Groundhog, deployment submits the contract artifact and creates a contract instance with a nonce:

1. **Include the RV32 artifact** in the deploy transaction.
2. **Create a contract instance** with a nonce. The nonce, combined with the deployer’s address and the contract hash, deterministically produces the contract address.

This is closer to Ethereum’s `CREATE2` than `CREATE`. The address is predictable before deployment.

The same contract artifact can be instantiated multiple times at different addresses. Initialization is a separate contract call unless an application-specific deployer combines deployment and initialization in one parent invocation.



### Calling

On Ethereum, you send a transaction specifying a contract address, a function selector (4-byte hash), and ABI-encoded arguments. On Groundhog, a transaction specifies a contract address, an entrypoint ID (8-byte identifier), and CXS-encoded arguments.

The SDK generates entrypoint IDs from method names and the `#[contract]` macro handles encoding. From a developer’s perspective, calling a contract looks like this:

```rust
let client = MyContractClient::new(&contract_addr);
client.increment(42);
let value = client.get();
```

The generated client handles serialization. You don’t construct raw calldata.



### Reading State

On Ethereum, you call `view` functions or read storage slots directly via `eth_getStorageAt`. On Groundhog, typed reads normally use `&self` methods through `groundhog_view`. The gateway also exposes `groundhog_getStorageAt` for low-level reads of a specific 32-byte contract-data key.

Transactions in a block share a starting snapshot. Ordinary storage reads can reflect earlier writes within the same transaction, but not writes from concurrent transactions. `RetrocausalQueue` has separate rules for observing concurrent inserts.



## Mental Model Shifts

| Solidity / EVM                                 | Groundhog                                                                 | Why                                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `balance = newValue`                           | `balance.increase(amount)` or `decrease(amount)`                          | Deltas merge in parallel. Different absolute writes conflict.                              |
| `mapping(address => uint256)`                  | `Map<ContractAddress, Balance>`                                           | Same concept. The value type enforces non-negativity and enables parallel execution.       |
| Gas per operation                              | Gas exists for metering but costs zero. HOG deposit for storage capacity. | Gas limits bound computation, but no tokens are burned.                                    |
| Sequential execution                           | Parallel by default                                                       | Transactions execute concurrently against the same block snapshot.                         |
| `require(condition, "message")`                | `ensure(condition, Error::Variant)`                                       | Typed errors instead of string messages.                                                   |
| `revert()` / `require()`                       | `throw(error)`                                                            | Aborts the transaction. Cannot be caught within the same contract.                         |
| Solidity + EVM bytecode                        | Rust + RV32 artifact                                                      | Different VM and artifact format. Attached Groundhog contract blobs are capped at 256 KiB. |
| `constructor()`                                | Ordinary initialization method                                            | Deployment does not invoke it automatically; guard one-time initialization in storage.     |
| `msg.sender`                                   | `get_caller()`                                                            | Same concept.                                                                              |
| `view` / `pure`                                | `&self` / no self                                                         | Read-only methods don’t produce state changes.                                             |
| `public` / `external` / `internal` / `private` | `pub` / not pub                                                           | Rust visibility. Public methods become contract entrypoints.                               |
| OpenZeppelin inheritance                       | Trait implementations                                                     | Rust uses traits and composition, not inheritance.                                         |



## Execution Differences

The runtime and storage model change how these patterns are implemented.



### Reentrancy

See [Solidity’s contract-call semantics](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls) for the EVM side of this comparison.

On the EVM, calling an external contract hands over execution control. That contract can call back into yours before your state updates are complete. Entire categories of exploits (DAO hack, read-only reentrancy) exist because of this.

Groundhog bans reentrancy at the runtime level. A contract cannot be called while it is already on the call stack. The runtime enforces this: if contract A calls contract B, and B tries to call back into A, the call fails. This is not a convention or a guard you add. It is a protocol-level guarantee.

Within a transaction, reads can observe earlier writes and successful child calls. Snapshot isolation separates concurrent transactions; the explicit runtime check prevents reentrancy.

You do not need a `nonReentrant` guard for contract calls. Application logic and error handling still depend on call order.



### Ordering and MEV

On Ethereum, pending transactions are visible in the mempool. Searchers can insert transactions before yours (front-running), after yours (back-running), or around yours (sandwich attacks). This is because transaction order within a block affects outcomes.

On Groundhog, commutative operations produce the same merged result regardless of execution order. Two compatible credits to the same account therefore produce the same final balance whichever executes first. Operations that conflict do not both land: one is excluded and returned to the mempool. The proposer still controls transaction selection and which contender wins a conflict, so Groundhog does not make a blanket claim that every application is MEV-free.



### Gas Limits and Gas Price Estimation

EVM developers spend significant effort estimating gas, setting gas limits, and handling out-of-gas reverts. Groundhog has gas limits for metering (bounding computation, preventing infinite loops), but gas costs zero tokens. You hold HOG tokens for capacity (compute throughput and storage). There is no gas price to estimate. Exceeding the declared gas limit still faults the transaction, and the declared limit determines its scheduling cost.



### Nonce Management

Every Ethereum transaction requires a sequential nonce per account. Sending transactions in parallel requires careful nonce tracking, and a stuck transaction blocks all subsequent ones. Groundhog has no sequential nonces. Replay protection uses a `Uniquifier` (a per-address value made of a block expiry height and an arbitrary nonce); it just has to be unique, not monotonic, so transactions from the same address can execute concurrently and out of order.



### Integer Overflow/Underflow

Solidity 0.8+ added checked arithmetic by default, but earlier versions required SafeMath. Groundhog’s `Balance` type enforces non-negativity at the storage layer. Checked `increase` and `decrease` abort automatically if the result would overflow or underflow. You don’t write separate arithmetic checks because the type handles them.



### The `approve()` Race Condition

The ERC-20 `approve(spender, amount)` function sets an absolute allowance. If you approve 100, then want to change it to 50, the spender can front-run your second `approve` and spend the original 100 before the new value takes effect.

Groundhog’s ERC-20 pattern uses `adjust_allowance(spender, diff)` instead. You send a delta (+50 or -50), not an absolute value. Concurrent allowance adjustments merge correctly because addition commutes.



## Pattern Adaptations



### Balance Transfer

**Solidity:**

```solidity
mapping(address => uint256) private balances;

function transfer(address to, uint256 amount) external {
    require(balances[msg.sender] >= amount, "Insufficient balance");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

**What changes:** No explicit balance check. `decrease` loads the sender and aborts during contract execution if its snapshot balance is insufficient. `lazy_increase` skips the receiver load and defers its bound check until delta reservation. Both operations produce mergeable deltas. Two transfers from the same account in the same block execute against the snapshot and produce deltas. If the account has enough balance for both, both succeed. If not, one is excluded.



### Access Control

**Solidity:**

```solidity
address public owner;

modifier onlyOwner() {
    require(msg.sender == owner, "Not owner");
    _;
}

function mint(address to, uint256 amount) external onlyOwner {
    balances[to] += amount;
    totalSupply += amount;
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    contract_owner: Value<ContractAddress>,
    // ...
}

fn mint(&mut self, receiver: &ContractAddress, amount: Amount) {
    ensure(get_caller() == self.contract_owner.get(), Error::NotOwner);
    self.total_supply.increase(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

**What changes:** No modifier system. Rust doesn’t have decorators. Use `ensure(condition, error)` at the top of the method. The pattern is the same (check authorization, then act), just expressed differently. For contracts with multiple roles, store a `Map<ContractAddress, Value<Role>>` and check against it.



### Constructor and Initialization

**Solidity:**

```solidity
contract Token {
    address public owner;
    uint256 public totalSupply;

    constructor(uint256 initialSupply) {
        owner = msg.sender;
        totalSupply = initialSupply;
        balances[msg.sender] = initialSupply;
    }
}
```

**Groundhog:**

```rust
use sdk::*;
use sdk::storage::{Balance, Map, Value};
use groundhog_erc20_if::{Amount, MintEvent, log_mint_event};

#[contract_exception]
pub enum Error {
    AlreadyInitialized = 1,
}

#[sdk::storage]
pub struct Token {
    contract_owner: Value<ContractAddress>,
    total_supply: Balance,
    balances: Map<ContractAddress, Balance>,
}

#[contract(throws = Error, emits(MintEvent))]
impl Token {
    pub fn initialize(&mut self, initial_supply: Amount) {
        ensure(
            self.contract_owner.try_get().none_if_missing().is_none(),
            Error::AlreadyInitialized,
        );
        let caller = get_caller();
        self.contract_owner.set_exclusive(&caller);
        self.total_supply.increase(initial_supply);
        self.balances.at_mut(&caller).lazy_increase(initial_supply);
        log_mint_event(&caller, initial_supply);
    }
}
```

The `groundhog_erc20_if` dependency provides the amount type and mint event helpers. See [Build a Token](../pages/tutorials/build-a-token.md) for dependency setup and a complete token contract.

**What changes:** Groundhog has no special constructor syntax. Call `initialize` after deployment, or have an application-specific deployer invoke it in the same parent transaction. The runtime does not provide once-only constructor semantics. This example uses the owner field as its initialization marker. The exclusive write prevents concurrent initializations from both landing, even for the same caller. State initialization uses the same storage operations as everything else.



### Events

**Solidity:**

```solidity
event Transfer(address indexed from, address indexed to, uint256 value);

function transfer(address to, uint256 amount) external {
    // ... transfer logic ...
    emit Transfer(msg.sender, to, amount);
}
```

**Groundhog:**

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    // ... transfer logic ...
    log_transfer_event(&caller, receiver, amount);
}
```

**What changes:** Fields marked `#[topic]` become topics on typed events. Interface 0.1.41 uses `TransferEvent` and `AllowanceChangeEvent`, whose `.log()` methods encode the event. Allowance changes carry signed deltas, not absolute approvals. Filtering happens through the indexer/RPC. See [Add Events](../pages/tutorials/add-events-to-a-contract.md) and [Contract Spec](../pages/reference/contract-spec.md#events).



## ERC-20 Side-by-Side

Here’s how the core of an ERC-20 token compares. This isn’t the full implementation (see [Build a Token](../pages/tutorials/build-a-token.md) for that), but it shows the key design differences.

**Solidity (OpenZeppelin-style):**

```solidity
contract ERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;

    function transfer(address to, uint256 amount) public returns (bool) {
        require(_balances[msg.sender] >= amount, "Insufficient");
        _balances[msg.sender] -= amount;
        _balances[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) public returns (bool) {
        _allowances[msg.sender][spender] = amount;  // absolute write
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public returns (bool) {
        require(_allowances[from][msg.sender] >= amount, "Allowance exceeded");
        require(_balances[from] >= amount, "Insufficient");
        _allowances[from][msg.sender] -= amount;
        _balances[from] -= amount;
        _balances[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct TokenContract {
    contract_owner: Value<ContractAddress>,
    balances: Map<ContractAddress, Balance>,
    allowances: Map<ContractAddress, Map<ContractAddress, Balance>>,
    total_supply: Balance,
}

#[contract(version = "0.1.5")]
impl ERC20 for TokenContract {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let owner = get_caller();
        self.balances.at_mut(&owner).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
        log_transfer_event(&owner, receiver, amount);
    }

    fn adjust_allowance(&mut self, spender: &ContractAddress, diff: Difference) {
        let owner = get_caller();
        let mut allowances = self.allowances.at_mut(&owner);
        let mut allowance = allowances.at_mut(spender);
        if diff >= 0 {
            allowance.increase(diff as u128);
        } else {
            allowance.decrease(diff.unsigned_abs());
        }
        log_approval_event(&owner, spender, diff);
    }

    fn transfer_from(&mut self, owner: &ContractAddress, receiver: &ContractAddress, amount: Amount) {
        let spender = get_caller();
        self.allowances.at_mut(owner).at_mut(&spender).decrease(amount);
        self.balances.at_mut(owner).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
        log_transfer_event(owner, receiver, amount);
    }
}
```

**Key differences:**

- **No explicit balance checks.** `Balance::decrease` aborts if the result would be negative. The check is built into the type.
- **`adjust_allowance` instead of `approve`.** Deltas instead of absolute writes. Compatible relative adjustments merge. The application must choose this API explicitly.
- **No success boolean.** These ERC-20 methods return unit on success and abort on failure, instead of returning `bool`. Other Groundhog methods can return typed values.
- **No `require` guards.** `Balance` enforces non-negativity. You only need `ensure()` for business logic checks (authorization, etc.), not arithmetic safety.
- **Parallel execution.** Two transfers debiting the same account both run against the snapshot. If the account has enough balance for both, both succeed and their deltas merge. If not, one is excluded and returned to the mempool.

For the full implementation with initialization, minting, burning, and tests, see [Build a Token](../pages/tutorials/build-a-token.md).



## What Doesn’t Exist

These EVM features have no Groundhog equivalent. Set your expectations:

| EVM Feature                        | Status on Groundhog                            | Alternative                                                                                |
| ---------------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `msg.value` (send ETH with call)   | Does not exist                                 | Transfer tokens explicitly via a token contract                                            |
| `delegatecall` / proxy patterns    | Does not exist                                 | Contracts are immutable. Deploy new versions at new addresses.                             |
| `selfdestruct`                     | Does not exist                                 | Contracts are permanent                                                                    |
| `receive()` / `fallback()`         | Does not exist                                 | All methods must be explicitly defined                                                     |
| `block.timestamp` / `block.number` | `get_block_timepoint()` / `get_block_height()` | The timepoint is coarse consensus time chosen by the proposer, not a per-transaction clock |
| `gasleft()`                        | `stats::gas_remaining()`                       | Available for execution control, but gas costs zero tokens                                 |
| Contract inheritance               | Does not exist                                 | Use Rust traits and composition                                                            |
| 24KB EVM runtime-code limit        | Different limit                                | Attached Groundhog contract blobs are capped at 256 KiB                                    |
| Storage slot packing               | Does not exist                                 | Each storage field is independent                                                          |



## Next Steps

- [Contract quickstart](../pages/get-started/contract.md) for a first deployment, and [Project structure](../pages/contracts/project-structure.md) for the generated files
- [Build a Counter](../pages/tutorials/build-a-counter.md) for a step-by-step first contract
- [Build a Token](../pages/tutorials/build-a-token.md) for the full ERC-20 implementation
- [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) for the contract-level merge model
- [Storage Types](../pages/reference/storage-types.md) for the full `Balance`, `NNInt`, `Map`, and `Bytestring` API

---

## Solana & Anchor

Source: <https://docs.groundhog.dev/ecosystem/solana/>

Groundhog concepts for Solana and Anchor developers.

This guide is for developers who know Solana and Anchor. It uses familiar Solana concepts to compare Groundhog’s storage and call patterns.

For the foundational concepts (delta operations, commutativity, storage types), see [For Blockchain Developers](../pages/start/for-blockchain-developers.md). This page builds on that with Solana-specific patterns.



## Accounts vs. Storage

This is the biggest mental model shift. On Solana, state lives in accounts. Each account is a separate object with its own address, lamport balance, owner program, and serialized data. Your program receives an array of accounts, validates them, deserializes them, operates on them, and serializes them back. Anchor’s `#[derive(Accounts)]` automates the validation, but the account array is always there.

Groundhog does not use Solana’s caller-supplied account-array model. State lives under contract addresses in typed storage fields. A token contract doesn’t receive “the sender’s balance account” and “the receiver’s balance account” as separate objects. It has a `Map<ContractAddress, Balance>` field called `balances`, and it reads and writes entries in that map.

**Solana (Anchor):**

```rust
#[derive(Accounts)]
pub struct Transfer<'info> {
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    pub authority: Signer<'info>,
}
```

**Groundhog:**

```rust
#[sdk::storage]
pub struct Token {
    balances: Map<ContractAddress, Balance>,
}

fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The method accesses typed storage through `Map`. It still needs application authorization checks.



## Access Lists vs. Type-Based Parallelism

On Solana, you declare every account a transaction will touch before the transaction runs. The runtime uses this manifest to schedule parallel execution: transactions that don’t share writable accounts can run concurrently. This is why you build the account array. It’s not just for validation. It’s how Solana knows what can parallelize.

On Groundhog, you do not declare an account access list. The storage types themselves determine what parallelizes. `Balance` increases and decreases use mergeable deltas. `Map` operations on different keys never interact. The runtime doesn’t need a manifest because the types carry the parallelism rules.

This is a fundamental difference. On Solana, scheduling depends on the accounts and mutability declared by the transaction, and Anchor validates those accounts before instruction logic runs. On Groundhog, the runtime discovers storage access during execution and applies the merge rules of each storage type.



## The Contract Lifecycle

Both platforms separate contract code from address-specific state, and both compile Rust to a deployable binary format: SBF on Solana and RV32 on Groundhog. A Groundhog transaction can attach code and invoke `DeployContract` in the same transaction.



### Writing

Solana programs are written in Rust with Anchor (or native). Groundhog contracts are also Rust, with a different SDK. The macro system has a similar role but different surface area:

| Anchor                | Groundhog SDK                  | Purpose                                                             |
| --------------------- | ------------------------------ | ------------------------------------------------------------------- |
| `#[program]`          | `#[contract]`                  | Marks the implementation block                                      |
| `#[derive(Accounts)]` | *(not needed)*                 | Account validation. Groundhog has no account arrays.                |
| `#[account]`          | `#[sdk::storage]`              | Marks state structure                                               |
| `#[instruction]`      | Method parameters              | Instruction data. Groundhog methods take typed parameters directly. |
| `init` constraint     | Ordinary initialization method | Groundhog deployment does not invoke it automatically.              |



### Compiling

Solana compiles programs for SBF (`cargo build-sbf`). Groundhog compiles to RV32, a 32-bit RISC-V target, by default:

```bash
groundhog build
```



### Deploying

On Solana, you upload the program binary, then initialize accounts for it. On Groundhog, you deploy the RV32 artifact and create a contract instance via `DeployContract` with a nonce. The contract address is deterministically derived from the deployer’s address, the contract hash, and the nonce. Similar to Solana PDAs in predictability, with a different derivation: deployer address, contract hash, and nonce.



### Calling

On Solana, a transaction contains instructions, each specifying a program ID, account array, and serialized instruction data. On Groundhog, a transaction specifies a contract address, an entrypoint ID, and CXS-encoded arguments. No account array needed.

The SDK generates typed clients:

```rust
let client = TokenClient::new(&token_addr);
client.transfer(&recipient, 100);
```



## Mental Model Shifts

| Solana / Anchor                        | Groundhog                                        | Why                                                                                            |
| -------------------------------------- | ------------------------------------------------ | ---------------------------------------------------------------------------------------------- |
| Accounts with serialized data          | Typed storage fields (`Map`, `Balance`, `NNInt`) | State lives inside the contract. No external accounts.                                         |
| `#[derive(Accounts)]` validation       | Typed parameters and explicit authorization      | No caller-supplied account array.                                                              |
| PDAs (seeds + bump)                    | Deterministic address (deployer + nonce + hash)  | Simpler derivation. No seed discovery.                                                         |
| Rent-exempt account funding            | HOG deposit (refundable)                         | Hold tokens for storage capacity. No rent clock.                                               |
| Per-transaction compute budget         | Gas limits exist but cost zero                   | Metering bounds computation. No tokens burned. Hold HOG for throughput capacity.               |
| CPI (cross-program invocation)         | Cross-contract calls                             | Same concept, simpler API, snapshot isolation.                                                 |
| `Signer<'info>` propagation            | Caller identity and explicit auth tokens         | `get_caller()` identifies the immediate caller, not the root signer.                           |
| `balance -= amount; balance += amount` | `decrease(amount); lazy_increase(amount)`        | Deltas merge in parallel. Assignments conflict.                                                |
| Account-level write locks              | Type-level guarantees                            | The type (`Balance`, `Map`, `Bytestring`) enforces correctness; concurrency follows from that. |



## Account and Call Patterns



### Account Arrays and Validation

Solana instructions supply account metadata. Anchor expresses the required accounts and validation constraints in the `Accounts` structure.

Groundhog has addresses and account authorization, but no caller-supplied account array. Contract methods receive typed parameters and access storage under their own address.



### Rent and Account Lifecycle

[Solana accounts](https://solana.com/docs/core/accounts) hold a refundable minimum lamport balance proportional to their data size.

Groundhog uses a capital deposit model for storage. You hold HOG tokens as a deposit while storage is allocated, and the deposit is refundable when storage is freed. No rent clock, no garbage collection, no minimum balance calculations.



### Compute Unit Budgets

Solana transactions have a compute budget that can be adjusted per transaction through compute-budget instructions. Programs must fit within that resource budget, including the work performed by CPIs.

Groundhog has gas limits that meter computation, but gas costs zero tokens. Specify a gas limit to bound execution, but don’t optimize for gas cost. There are no priority fees and no fee-related failures.



### PDA Seed Management

PDAs on Solana require choosing seeds and deriving an off-curve address with a bump. Anchor’s `seeds` and `bump` constraints validate that derivation.

Groundhog contract addresses are derived from deployer + nonce + contract hash. One derivation, deterministic, no bumps. If your Solana program uses PDAs as state accounts (one per user, one per pool), the Groundhog equivalent is a `Map<Key, Value>` field in your contract storage. The map entries replace the PDAs.



### Signer Propagation in CPIs

On Solana, cross-program invocations require passing signer seeds so the runtime can verify PDA authority. The callee receives the signer authority verified by the runtime.

Groundhog cross-contract calls don’t propagate signers. The called contract sees `get_caller()` returning the calling contract’s address. Authorization is the called contract’s responsibility, checked against its own storage. No signer arrays, no PDA signing.



## Pattern Adaptations



### PDA State Accounts → Map Fields

**Solana pattern:** create a PDA account per user to store their state.

```rust
#[derive(Accounts)]
pub struct CreateUserAccount<'info> {
    #[account(
        init,
        payer = user,
        space = 8 + UserState::INIT_SPACE,
        seeds = [b"user", user.key().as_ref()],
        bump,
    )]
    pub user_state: Account<'info, UserState>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}
```

**Groundhog:** a Map field inside the contract. No separate account creation.

```rust
#[sdk::storage]
pub struct MyContract {
    user_states: Map<ContractAddress, Value<UserState>>,
}

fn get_user_state(&self, user: &ContractAddress) -> UserState {
    self.user_states
        .at(user)
        .try_get()
        .none_if_missing()
        .unwrap_or_default()
}
```

No `init` instruction, no `space` calculation, no `payer`, no `system_program`. The map entry is created on first write.



### Token Transfer

**Solana (SPL Token):**

```rust
let cpi_accounts = Transfer {
    from: ctx.accounts.from_token_account.to_account_info(),
    to: ctx.accounts.to_token_account.to_account_info(),
    authority: ctx.accounts.authority.to_account_info(),
};
let cpi_ctx = CpiContext::new(ctx.accounts.token_program.to_account_info(), cpi_accounts);
token::transfer(cpi_ctx, amount)?;
```

**Groundhog:**

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The Groundhog example implements the token contract itself. To transfer another contract’s token, call its generated client. In this implementation, each balance is a map field. Both calls produce mergeable deltas. `decrease` loads and checks the sender during execution, while `lazy_increase` skips the receiver load and defers its bound check.



### Cross-Program Invocation → Cross-Contract Call

**Solana:**

```rust
let cpi_accounts = MintTo {
    mint: ctx.accounts.mint.to_account_info(),
    to: ctx.accounts.token_account.to_account_info(),
    authority: ctx.accounts.authority.to_account_info(),
};
let seeds = &[b"mint_authority", &[bump]];
let signer_seeds = &[&seeds[..]];
let cpi_ctx = CpiContext::new_with_signer(
    ctx.accounts.token_program.to_account_info(),
    cpi_accounts,
    signer_seeds,
);
token::mint_to(cpi_ctx, amount)?;
```

**Groundhog:**

```rust
let token = ERC20Client::new(&token_addr);
token.mint(&recipient, amount);
```

The `#[contract]` macro generates the client. No account arrays, no signer seeds, no CPI context construction. The call executes within the same snapshot. If the called contract aborts, your contract aborts too (or use `try_mint` to handle the error).



### Error Handling

**Solana (Anchor):**

```rust
#[error_code]
pub enum MyError {
    #[msg("Not authorized")]
    NotAuthorized,
    #[msg("Insufficient balance")]
    InsufficientBalance,
}

// In handler:
require!(ctx.accounts.authority.key() == expected, MyError::NotAuthorized);
```

**Groundhog:**

```rust
#[contract_exception]
pub enum Error {
    NotAuthorized = 1,
}

// In method:
ensure(get_caller() == self.contract_owner.get(), Error::NotAuthorized);
```

Similar pattern: define error variants, check conditions. Anchor uses `require!` macro, Groundhog uses `ensure()`. Both abort the transaction on failure. The difference: Groundhog errors are CXS-serialized (for cross-contract error inspection), and `Balance::decrease` aborts automatically on underflow without a separate balance check.



## What Doesn’t Exist

| Solana Feature                                        | Status on Groundhog    | Alternative                                                      |
| ----------------------------------------------------- | ---------------------- | ---------------------------------------------------------------- |
| Caller-supplied account arrays                        | Not used               | State lives in contract storage fields                           |
| `#[derive(Accounts)]`                                 | Does not exist         | No account validation needed                                     |
| PDAs and bump seeds                                   | Does not exist         | Deterministic address from deployer + nonce + contract hash      |
| Rent / rent exemption                                 | Does not exist         | Refundable HOG deposit for storage                               |
| Compute unit budget                                   | Gas limits (cost zero) | Metering exists for bounding computation. No per-operation fees. |
| Priority fees                                         | Does not exist         | Throughput via HOG token holding                                 |
| `Signer<'info>` propagation                           | Does not exist         | `get_caller()` for identity                                      |
| Associated Token Accounts                             | Does not exist         | `Map<ContractAddress, Balance>` in contract storage              |
| Account `space` / `realloc`                           | Does not exist         | Storage grows as needed                                          |
| `system_program`, `token_program`, `rent` as accounts | Does not exist         | No system accounts passed to instructions                        |
| Versioned transactions                                | Does not exist         | One transaction format                                           |
| Address lookup tables                                 | Does not exist         | No account arrays to compress                                    |



## Next Steps

- [Contract quickstart](../pages/get-started/contract.md) for a first deployment, and [Project structure](../pages/contracts/project-structure.md) for the generated files
- [Build a Counter](../pages/tutorials/build-a-counter.md) for a step-by-step first contract
- [Build a Token](../pages/tutorials/build-a-token.md) for a full ERC-20 implementation
- [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) for the contract-level merge model
- [Storage Types](../pages/reference/storage-types.md) for the full `Balance`, `NNInt`, `Map`, and `Bytestring` API

---

## Stellar & Soroban

Source: <https://docs.groundhog.dev/ecosystem/stellar/>

Groundhog patterns for developers building in the Stellar ecosystem.



## Who This Guide Is For

This guide is for Stellar and Soroban developers evaluating where Groundhog fits alongside the Stellar economy. It focuses on **pattern translation**: how familiar workflows look when they are expressed with Groundhog’s parallel storage primitives.

***



## Mental Model Shifts

Before diving into specific patterns, here are the main differences in emphasis:

| Aspect                   | Stellar                                                 | Groundhog                                                                    |
| ------------------------ | ------------------------------------------------------- | ---------------------------------------------------------------------------- |
| **Execution model here** | Classic Stellar operations                              | Contract calls with snapshot isolation and delta merge                       |
| **State model**          | Account-centric (balances, trustlines, offers built in) | Contract-centric (you define storage with typed primitives)                  |
| **Error handling**       | Transaction result codes                                | Typed abort with structured errors                                           |
| **DEX execution**        | Built-in offers and synchronous path payments           | Synchronous contracts or queued intent settlement, chosen by the application |
| **Multi-operation**      | Bundle multiple operations in one transaction           | Single root invocation with cross-contract calls                             |

Payments and token operations map directly to Groundhog’s balance deltas. DEX applications can use a synchronous AMM, or use a request queue when they want concurrent submission and later settlement, as shown in [Design a Swap](../pages/tutorials/design-a-swap.md).

***



## Pattern Translations



### 1. Simple Payments

**Stellar Pattern:**

```javascript
// Stellar SDK
const payment = Operation.payment({
  destination: "GDEST...",
  asset: Asset.native(),
  amount: "100"
});

transaction.addOperation(payment);
```

**Groundhog Pattern:**

```rust
// Token contract transfer (see Build a Token for the full implementation)
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
    log_transfer_event(&sender, receiver, amount);
}
```

**What This Highlights:**

- You write a token contract with explicit balance primitives instead of using built-in account-level balances
- Both balance updates are delta operations, so transfers to and from the same account can execute in parallel
- Underflow is automatically rejected by `Balance::decrease` (the balance can never go negative)

The token contract in [Build a Token](../pages/tutorials/build-a-token.md) shows the full version of this pattern.

***



### 2. Multi-Operation Transactions

Classic Stellar transactions can bundle operations atomically. Soroban transactions have a single smart-contract operation. See [Stellar operations and transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions).

**Stellar Pattern:**

```javascript
// Stellar: All operations execute atomically, sequentially
// Add these to a TransactionBuilder configured for the target network.
transaction
  .addOperation(Operation.payment({ destination: A, asset: Asset.native(), amount: "100" }))
  .addOperation(Operation.payment({ destination: B, asset: Asset.native(), amount: "50" }))
  .addOperation(Operation.changeTrust({ asset: USD }));
```

**Groundhog Pattern:**

```rust
// A contract method that performs multiple operations
fn batch_payment_and_trust(
    &mut self,
    dest_a: &ContractAddress,
    dest_b: &ContractAddress,
    token: &ContractAddress,
) {
    let sender = get_caller();

    // These are delta operations on independent keys, so they commute
    self.balances.at_mut(&sender).decrease(150);
    self.balances.at_mut(dest_a).lazy_increase(100);
    self.balances.at_mut(dest_b).lazy_increase(50);

    // Trust is just contract storage
    self.trustlines.at_mut(&sender).at_mut(token).set(&true);
}
```

**What This Highlights:**

- No operation bundling. You write a contract method that does everything you need
- For cross-contract operations, use [cross-contract calls](../pages/contracts/cross-contract-calls.md): your method invokes other contracts
- Groundhog does not require you to declare which state you’ll touch upfront. Ordinary storage conflicts are checked during delta reservation after execution
- Each contract invocation is atomic: if your method aborts, all state changes are discarded

The main shift is organizational: logic that would be represented as a list of Stellar operations becomes a contract method.

***



### 3. Market Making / Resting Orders

Groundhog does not provide a built-in order book. A contract can store orders by ID in a `Map`, or accept order intents through a `RetrocausalQueue` when many producers need to submit concurrently.

**Stellar Pattern:**

```javascript
// Place a new offer
Operation.manageSellOffer({
  selling: XLM,
  buying: USD,
  amount: "1000",
  price: "0.10",
  offerId: 0  // 0 = new offer
});

// Cancel an existing offer
Operation.manageSellOffer({
  selling: XLM,
  buying: USD,
  amount: "0",   // 0 = cancel
  price: "0.10",
  offerId: 12345
});
```

With a map-based book, different order IDs are independent. Changes to the same order follow the stored value type’s conflict rules. With a queue-based design, inserts commute, one consumer sequences matching, and results are reported later through stored state or events. The queue is an application architecture, not a protocol requirement.

***



### 4. DEX Trading / Swaps

There are two useful Groundhog designs, and they make different tradeoffs.

**Stellar Pattern:**

```javascript
// Synchronous path payment: result is immediate
Operation.pathPaymentStrictReceive({
  sendAsset: XLM,
  sendMax: "1000",
  destination: dest,
  destAsset: USD,
  destAmount: "100",
  path: [EUR]  // Optional intermediate assets
});

// After confirmation, inspect the transaction result:
// - Did it execute?
// - What was the actual rate?
// - How much was sent?
```

**Synchronous contract.** A swap method can call token contracts and return in one transaction. The SDK example uses this Uniswap-style shape. Swaps against different pair contracts are independent. Swaps against the same pair usually conflict because each calculates and writes a new reserve value, so only a compatible subset lands in a block.

**Queued intents.** A venue can instead accept intents through `RetrocausalQueue`. Inserts commute, then a consumer matches and settles them later. This shape needs event polling or another application-level result channel, but separates highly concurrent submission from sequential matching.

Use the synchronous model when callers need an immediate contract result. Use a queue when submit-then-settle semantics fit the product.

***



### 5. Account & Trust Management

**Stellar Pattern:**

```javascript
// Create trustline
Operation.changeTrust({
  asset: new Asset("USD", "GISSUER..."),
  limit: "10000"
});

// Configure account
Operation.setOptions({
  homeDomain: "example.com",
  setFlags: AuthRequiredFlag
});
```

**Groundhog Pattern:**

```rust
// Trust and account config are just contract storage
fn set_trustline(&mut self, asset: &ContractAddress, limit: Amount) {
    let account = get_caller();
    self.trustlines.at_mut(&account).at_mut(asset).set(&limit);
}

fn set_options(&mut self, home_domain: &[u8], flags: u32) {
    let account = get_caller();
    self.config.at_mut(&account).set(&serialize_options(home_domain, flags));
}
```

**What This Highlights:**

- Explicit key-value storage instead of built-in account abstraction
- Per-account operations on different accounts are fully parallel (different `Map` keys)
- Different configuration writes to the same account conflict; identical bytestring writes can coexist

***



### 6. Soroban Smart Contracts

If you’re already writing Soroban contracts, Groundhog is best read as an adjacent contract environment with a different storage model. Soroban remains a strong fit for applications that want the Soroban runtime and Stellar integration directly; Groundhog is useful when parallel execution, permanent storage, and delta-oriented state are the shape you want.

**Soroban:**

```rust
#[contractimpl]
impl TokenContract {
    pub fn transfer(env: Env, from: Address, to: Address, amount: i128) {
        from.require_auth();
        assert!(amount >= 0);
        let from_balance: i128 = env.storage().persistent().get(&from).unwrap_or(0);
        let to_balance: i128 = env.storage().persistent().get(&to).unwrap_or(0);
        assert!(from_balance >= amount);
        env.storage().persistent().set(&from, &(from_balance - amount));
        env.storage().persistent().set(&to, &(to_balance + amount));
    }
}
```

**Groundhog:**

```rust
#[contract(throws = TokenError)]
impl TokenContract {
    fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
        let sender = get_caller();
        self.balances.at_mut(&sender).decrease(amount);
        self.balances.at_mut(receiver).lazy_increase(amount);
    }
}
```

**Side-by-Side Patterns:**

| Soroban                                                       | Groundhog                                                                                      |
| ------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| `env.storage().persistent().get/set` (read-modify-write)      | `Balance` increase/decrease (delta operation; no absolute rewrite)                             |
| Three storage tiers (Instance, Persistent, Temporary)         | One storage model, no tiers                                                                    |
| TTLs on all storage; must call `extend_ttl()` or data expires | Permanent storage, no TTLs, no expiration                                                      |
| `require_auth()` for caller authorization                     | `ensure(caller == self.owner.get(), err)` pattern                                              |
| `#[contractimpl]`                                             | `#[contract]` with `#[sdk::storage]`                                                           |
| `Env` passed to every function                                | `&self` / `&mut self` with `get_caller()`                                                      |
| Resource limits constrain transaction complexity              | Gas metering exists but costs zero tokens                                                      |
| Sequence numbers serialize transactions per Stellar account   | No sequential nonce; each Groundhog transaction carries a unique `(expiry height, nonce)` pair |
| Fees per transaction (inclusion + resource fees)              | No per-operation fees; available (unlocked) HOG balance determines throughput share            |

The important Groundhog concept is commutativity: which storage operations can merge determines how much parallelism your contract gets. See [Parallel Execution](../pages/how-it-works/execution-model.md).

***



## Pattern Summary

| Pattern        | Groundhog Shape       | Notes                                                      |
| -------------- | --------------------- | ---------------------------------------------------------- |
| Payments       | Direct                | Token contract transfers with `Balance` storage            |
| Resting orders | Direct or queued      | Map entries keep orders independent; queue inserts commute |
| Trust/Auth     | Direct                | Explicit key-value model                                   |
| DEX trades     | Synchronous or queued | Direct AMM calls return immediately; queues settle later   |
| Soroban tokens | Direct                | Delta operations instead of read-modify-write              |
| Soroban DEX    | Synchronous or queued | Choose based on contention and product semantics           |

Payments and token operations fit `Balance` directly. DEX applications should deliberately choose between synchronous execution and a queued intent design.

***



## What Doesn’t Change

Despite the differences, many concepts translate directly:

| Stellar Concept             | Groundhog Equivalent                                                  |
| --------------------------- | --------------------------------------------------------------------- |
| Accounts                    | Contract addresses                                                    |
| Assets (XLM, issued tokens) | Token contracts                                                       |
| Trustlines                  | Contract-level authorization                                          |
| Order book DEX              | Application-defined map or queued-intent venue                        |
| Sequence numbers            | Unique expiry-height and nonce pair, not a monotonic account sequence |

***



## Common Questions



### Q: Do I lose atomicity for multi-op transactions?

No. Each Groundhog contract invocation is atomic. If your method aborts, all state changes are discarded. For multi-step workflows that span multiple contracts, use [cross-contract calls](../pages/contracts/cross-contract-calls.md): a parent contract calls child contracts, and if the parent aborts, all child changes are reverted too.



### Q: When should I use a queued DEX model?

Use a queue when concurrent intent submission matters more than an immediate result. Poll execution events or read venue state to learn the settlement outcome. If callers need synchronous output, use a direct swap contract instead.



### Q: Will my market making bot need major changes?

That depends on the venue design. A synchronous venue looks like an ordinary contract call. A queued venue requires the bot to correlate submitted intents with later settlement events or state.

***



## References

- [Contract quickstart](../pages/get-started/contract.md): Build, test, and deploy a Groundhog contract
- [Build a Token](../pages/tutorials/build-a-token.md): Full ERC-20 token walkthrough
- [Merged Deltas](../pages/programming-model/execution.md#merged-deltas): How concurrent state changes combine
- [Storage Types](../pages/reference/storage-types.md): Balance, NNInt, Map, Vector, Value, Bytestring, RetrocausalQueue API reference

---

## System Overview

Source: <https://docs.groundhog.dev/how-it-works/architecture/>

How Groundhog's public gateway, execution services, storage, and consensus coordinator fit together.

Groundhog separates three responsibilities: serving applications, executing transactions and storing state, and agreeing on blocks. This page maps those responsibilities to the services that handle them.



## Components

```text
Applications and wallets
      |
      v
JSON-RPC gateway
      |
      +-- Reads
      |   State / Views / History
      |
   submits
      v
  Scheduler <--> Coordinator
      |               |
      |         Other validators
      |
      +-- Auth server
      +-- Executors <--> DB shards
      +-- Event server
```

The diagram shows the main service relationships. [Networking](../pages/how-it-works/networking.md) covers registration and communication between them.

| Component                              | Responsibility                                                                                                      |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| **JSON-RPC gateway** (`groundhog-rpc`) | Accepts application requests, submits transactions to the scheduler, and routes reads to the relevant service       |
| **Scheduler / mempool** (`hogd`)       | Queues transactions, coordinates authorization, dispatches execution, and orchestrates block production and commits |
| **Auth server**                        | Checks transaction authorization claims and signatures before scheduling                                            |
| **Executors**                          | Run contract code and submit its state changes for reservation against the proposed block                           |
| **DB shards**                          | Serve state snapshots, enforce storage merge rules, and store committed state                                       |
| **Event server and indexer**           | Collect execution results and make transaction history, receipts, and events available for queries                  |
| **Coordinator** (`chuckd`)             | Drives consensus with other validators and asks the execution layer to propose, validate, and commit blocks         |





## Two paths through the gateway

**Transactions** enter through the gateway and reach the scheduler. The scheduler arranges signature checks, selects work, and dispatches it to executors. The execution layer produces a block proposal; the coordinator handles agreement with other validators.

**Reads** use the service appropriate to the request. State and balance queries use the database gateway, read-only contract calls use the view gateway, and receipt and event queries use the indexer. The scheduler supplies information such as the chain tip and pending transaction status.

The public gateway does not participate in consensus. Applications use its [JSON-RPC API](../pages/reference/json-rpc-api.md) rather than the internal service interfaces.





## Execution and agreement

The execution layer determines what a proposed block would do. Contracts run against a shared snapshot and produce typed state changes. Executors and DB shards check which changes can be reserved together.

The coordinator drives agreement on which valid proposal to commit. It uses the Stellar Consensus Protocol (SCP); it does not run the contracts itself. Each validator checks the proposed result through its own execution layer before committing it.



Multiple execution workers and database shards distribute work within a node. Consensus coordinates agreement between validators. These are different responsibilities; adding execution capacity does not change the consensus rules.



## Explore the details

- [Parallel Execution](../pages/how-it-works/execution-model.md): Snapshots, compatible updates, and conflict reservation
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): Submission, execution outcomes, and commit
- [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md): Scheduling and storage deposits
- [Consensus](../pages/how-it-works/consensus.md): Proposals, validation, and finality
- [Networking](../pages/how-it-works/networking.md): Component registration and internal interfaces

For the behavior your contract relies on, read [Contract Execution](../pages/programming-model/execution.md).

---

## Consensus

Source: <https://docs.groundhog.dev/how-it-works/consensus/>

SCP-based consensus, block production, and irrevocable finality.

> **caution: Draft**
>
> This page describes the current architecture. Some details may change as the protocol matures.



## Overview

Groundhog uses the Stellar Consensus Protocol (SCP) for agreement. SCP is a federated Byzantine agreement protocol: each validator picks its own **quorum slices** (the sets of validators it trusts), and the network converges on a single value without a fixed committee or rotating leader. Nomination uses a priority function to bias which validator’s proposed value is considered first per round, but no validator can unilaterally decide a block; agreement comes from overlapping quorum slices, not from a designated proposer.

SCP provides finality under its quorum-intersection and fault assumptions. Applications use the finalized block result rather than a probabilistic confirmation count.



## The Coordinator

Consensus is driven by the coordinator (chuckd), which is separate from the execution engine (hogd). The coordinator’s job is to get validators to agree on which block to commit. Contract execution and storage belong to the execution layer, orchestrated by the scheduler. See [System Overview](../pages/how-it-works/architecture.md) for the component roles.

Each coordinator is configured with its own quorum set: the list of other validators it trusts for consensus. This peer configuration is managed by the coordinator, not the mempool. The mempool handles intra-node component registration (executors, DB shards, etc.); the coordinator handles inter-node consensus topology. This separation keeps execution concerns and agreement concerns independent.

It runs a state machine called the **baton** that drives the consensus loop.



## Block Production

The baton runs a drive loop after every event:

```plaintext
driveCommit()    →  Commit any externalized block
driveNominate()  →  Propose next block if idle
driveCatchup()   →  Fetch missing blocks from peers
driveLiveness()  →  Detect stuck consensus
```



### Single-Node Flow

On a single validator (e.g. during development):

1. Baton calls `propose_block` on the mempool. The execution layer runs queued transactions and assembles a proposal.
2. SCP externalizes immediately (single-node quorum).
3. Baton calls `commit` on the mempool. The execution layer commits the finalized proposal to storage.
4. Next drive cycle begins.



### Multi-Node Flow

With multiple validators:

1. **Propose.** A validator asks its mempool for a block proposal. The proposal contains the transactions and metadata.
2. **Disseminate.** The full consensus value (nomination + metadata) is broadcast to peers via Dogwood (see below). A compact hash reference (the “cue”) is sent through SCP.
3. **Validate.** Receiving validators ask their own mempool: “is this nomination valid against my state?” Validation runs asynchronously and results are cached.
4. **Converge.** SCP envelope exchange continues until validators agree. Agreement depends on quorum intersection and the configured trust assumptions.
5. **Commit.** Once SCP externalizes a value, each validator commits the block locally via its mempool.



### Execution During Block Production

The proposer and validators execute transactions differently.

**The proposer runs concurrent execution.** Transactions are fanned across multiple executors and coroutines in parallel. After a root call completes, NNInt capacity locks reserve its delta batch via atomic compare-and-swap (see [Parallel Execution: How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved)). Which transaction wins a contested lock depends on thread scheduling. This is non-deterministic: two runs of the same transaction set on the same machine can produce different winners.

**The proposer captures nondeterministic outcomes.** Each transaction produces a `NondeterministicProposalData` payload covering proposal-dependent decisions such as capacity reservation outcomes and retrocausal queue observations. This payload is packaged alongside the transaction hashes in the consensus proposal.

**Validators replay deterministically.** Validators receive the proposer’s nominated transaction list and the nondeterministic data. They reconstruct each transaction from their local mempool, pair it with the proposer’s captured decisions, and replay execution using those decisions as input. Validators do not re-run the concurrent race. They verify that the transactions produce the claimed state transitions, recompute the block hash, and confirm it matches.

|                       | Proposer                                                   | Validator                                 |
| --------------------- | ---------------------------------------------------------- | ----------------------------------------- |
| Execution             | Concurrent across executors                                | Deterministic replay with proposer’s data |
| Conflict resolution   | Non-deterministic thread race                              | Reproduced from captured decisions        |
| Transaction selection | Discretionary (from local mempool)                         | Fixed (from nomination)                   |
| Output                | Nomination: tx hashes + nondeterministic data + block hash | Accept or reject the nomination           |

The proposer has discretion over which transactions to include and which conflicting transaction wins. Validators verify the math of the proposed result, not the policy that produced it. Deterministic replay makes the proposed result verifiable. It does not establish proposer fairness; scheduling and transaction selection are separate from validating state transitions.



## Dissemination: Dogwood

Validators exchange three types of data during consensus:

| Data                 | Description                                                               |
| -------------------- | ------------------------------------------------------------------------- |
| **Transactions**     | Signed transactions gossiped between validators                           |
| **Consensus values** | Full block nominations (transactions + metadata)                          |
| **SCP envelopes**    | Protocol messages for agreement (nominate, prepare, confirm, externalize) |

Dogwood is the dissemination layer. It uses **erasure-coded multicast**: data is split into chunks, encoded with redundancy, and broadcast over BFS multicast trees. Receivers can reconstruct the original data from a subset of chunks, reducing bandwidth requirements while tolerating packet loss.

Each data type is tagged and demultiplexed on receipt. Transactions are forwarded to the mempool. Consensus values are cached locally for validation. SCP envelopes are fed to the embedded SCP kernel.



## Finality Model

Under the required quorum assumptions, loss of enough validators can stop progress without invalidating finalized blocks. Incorrect or disjoint trust configurations can violate those assumptions.

Practical implications:

- **No confirmation count.** A confirmed transaction is final. There is no “wait for 6 blocks” or “99.9% probability of finality.”
- **Finalized blocks.** Under the consensus safety assumptions, finalized blocks are not replaced by competing blocks.
- **Halt recovery.** If the network halts due to quorum loss, it resumes from the last committed block once enough validators return. Nodes may need to catch up before participating again.



## Catchup and Repair

Validators that fall behind (new nodes, network partitions, restarts) catch up by fetching missing blocks from peers. The catchup agent requests blocks by height, validates them, and replays them locally.

A separate repair agent handles missing data during active consensus: if a validator receives a hash reference it cannot resolve (a consensus value or SCP envelope it hasn’t seen), it requests the full data from the originating peer.



## Related Documentation

- [Networking](../pages/how-it-works/networking.md): Node topology and how the coordinator connects to the mempool
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Parallel Execution](../pages/how-it-works/execution-model.md): How transactions execute against snapshots
- [System Overview](../pages/how-it-works/architecture.md): The component map

---

## Parallel Execution

Source: <https://docs.groundhog.dev/how-it-works/execution-model/>

How the engine executes transactions against snapshots and reserves compatible state changes.



## The Core Idea

Every transaction reads from a consistent snapshot and records typed deltas. The storage type determines how those deltas combine.

Commutativity describes operations whose combined result does not depend on their order. Groundhog still enforces resource limits, including gas limits, bounded return values, and a maximum encoded transaction size.

This page explains the engine: snapshots, concurrent reservation, and conflict selection. For the rules your code relies on, read [Contract Execution](../pages/programming-model/execution.md).



## Snapshot Isolation

Each transaction sees the ledger as it was at the start of the block. All transactions in a block read from the same snapshot. Ordinary storage reads do not observe other transactions’ writes within that block.

Reads also reflect changes within the current transaction and successful child calls. The database snapshot analogy does not imply identical SQL isolation or conflict rules.

`RetrocausalQueue` also permits observations of concurrent inserts. These are recorded as nondeterministic proposal data and replayed by validators. Its read semantics differ from ordinary snapshot storage.



## Delta Writes

Transactions do not write final values. They produce deltas: descriptions of how to change a value.

Instead of “set balance to 50”, a transaction says “increment balance by 10.” After each root contract call completes, the runtime reserves its delta batch alongside compatible deltas already admitted to the proposed block. The admitted deltas form the next state at commit.

In Solidity, a transfer looks like this:

```solidity
// Solidity: read balances and assign their updated values.
balances[from] = balances[from] - amount;
balances[to] = balances[to] + amount;
```

In Groundhog:

```rust
// Groundhog: write deltas. Two compatible transfers to the same
// account produce two deltas that merge cleanly.
balances.at_mut(&from).decrease(amount);
balances.at_mut(&to).increase(amount);
```

Two compatible increments to the same balance produce the same result regardless of order. `(x + 3) + 5 = (x + 5) + 3`. That is commutativity, and it is why Groundhog can execute transactions in parallel without declared access lists.



## What Commutes and What Doesn’t

Transactions execute concurrently. Storage merge rules determine whether their changes can land together. A conflicting transaction is excluded from the proposal and returned to the mempool.

| Operation                               | Can both changes land? | Why                                                             |
| --------------------------------------- | ---------------------- | --------------------------------------------------------------- |
| Two balance changes on the same counter | When compatible        | Resolved bases must match and aggregate bounds must hold        |
| Two writes to different Map keys        | Yes                    | Independent keys don’t interact                                 |
| Two writes to the same bytestring       | When identical         | Different values conflict                                       |
| Multiple inserts into the same queue    | Yes                    | Entries are sorted; insertion order doesn’t matter              |
| Two deletions of the same key           | Yes                    | Same outcome regardless of order                                |
| A deletion and a write to the same key  | No                     | Different operation types conflict; one transaction is excluded |

These rules describe the listed operations. Other changes in either transaction can still cause a conflict.



### What This Means for Your Data Model

Choose storage around the changes your application needs to combine. Mergeable arithmetic still has bounds; absolute writes can coexist when they store identical values. [Storage Types](../pages/programming-model/storage-types.md#choosing-a-type) turns these rules into contract-design choices.



## How Conflicts Are Resolved

The programming model describes a transaction as executing first and then attempting to land its deltas. The engine implements that boundary directly: ordinary storage conflicts are checked after the root contract call returns, before the transaction is committed into the proposed block.



### Concurrent Delta Reservation

Contract execution accumulates writes in the transaction’s `ItemView`. A checked operation such as `Balance::decrease(30)` first loads the snapshot base and can abort immediately if that transaction alone would underflow. A lazy operation skips that load and therefore cannot report a snapshot-bound failure from contract code. Both forms produce an NNInt delta.

After the root call returns successfully, `try_commit_transaction()` submits the transaction’s complete delta batch to hogd. For a lazy `NonnegativeIntAdd`, hogd resolves the set value from the block snapshot. A checked `NonnegativeIntSetAdd` already carries that same snapshot value. Both then use the same NNInt type-class match and aggregate bounds reservation.

For a snapshot balance of 10, the per-key reservation starts with subtraction capacity of 10:

```plaintext
Snapshot: Alice balance = 10
          Subtraction budget = 10

Tx A contract returns with delta -8
      Reserve delta batch: capacity 10 → 2 → admitted

Tx B contract returns with delta -5
      Reserve delta batch: capacity would be -3 → excluded
```

Whichever transaction reserves first wins. The lock is per-key, per-block and is initialized from the snapshot. Reservations on different keys use separate locks. Transactions touching the same key contend for the same aggregate bounds. Reservation can happen concurrently across executor workers; atomic capacity accounting ensures the combined admitted delta remains in range.

For operations that commute (two increases, or two decreases that fit within the balance), both reservations succeed and both transactions land. Checked and lazy operations share this merge behavior. The difference is that checked operations may fail earlier in contract code, while lazy operations leave the snapshot-bound decision to reservation. A lazy adjustment that is invalid against the snapshot can still be admitted if a compatible offsetting delta has already been admitted before its batch is reserved. If the lazy adjustment reserves first, it is excluded. This possibility depends on reservation order, not eventual block-wide netting.



### What Block Close Does

By the time block close runs, all capacity conflicts have been resolved. Block close stages the already-finalized locks into a ChangeSet and computes the block hash. No conflict resolution happens at this stage for Balance, NNInt, Map, Value, or Bytestring operations.

RetrocausalQueue is the exception: it has end-of-block invariant checks that the other storage types do not. RCQ entries from excluded transactions are removed during block finalization.



### Why the Simplified Model Still Holds

From a contract developer’s perspective, the result is the same: your transaction either lands or is excluded. You don’t manage locks, budgets, or reservation order. The programming model (“compatible deltas merge; incompatible transactions are excluded”) is accurate for deciding how to structure your storage. The proposer records reservation-dependent outcomes so validators can replay and verify the proposed block.



## Related reading

- [Contract Execution](../pages/programming-model/execution.md): The contract-author model
- [Storage Types](../pages/programming-model/storage-types.md): API choices and merge rules
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md): Gas limits, scheduling, and deposits

---

## Networking

Source: <https://docs.groundhog.dev/how-it-works/networking/>

Node topology, component registration, and how transactions reach the mempool.

The [System Overview](../pages/how-it-works/architecture.md#components) maps the main components. This page explains how they find each other and communicate.



## Topology

Groundhog’s services are organized into an execution layer and a consensus layer.

The **coordinator** (chuckd, written in Go) sits above the execution layer. It drives consensus with other validators, manages peer topology, and tells the local mempool when to produce and commit blocks.

The **mempool** (scheduler, part of hogd) is the hub of the execution layer. All execution components register with it: executors, DB shards, event server, auth server. The mempool orchestrates block production, transaction execution, and state commits.

Separately, the **RPC gateway** (groundhog-rpc) provides external API access. It connects to the scheduler, indexer, database gateway, and view gateway but does not participate in consensus. It can be scaled independently of the validator.

Within the execution layer, no component discovers peers independently. The mempool is the registry for intra-node communication. When a component registers, it gets back the addresses of everything else it needs to talk to.

Inter-node communication (consensus, transaction gossip) is managed by the coordinator, which maintains its own peer topology via configured quorum sets. The mempool knows nothing about other validators. See [Consensus](../pages/how-it-works/consensus.md) for how coordinators find and talk to each other.



## Component Registration

Components register their addresses and readiness with the scheduler. Most use an “intro” RPC; the event server uses a prepare/activate handshake. The scheduler waits for the required components before dispatching work.

Registration interfaces:

1. **DB shards** register via `scheddb_intro_shard`. Multiple shards can register (horizontal storage scaling).
2. **Event server** registers via `schedevent_prepare_event` and `schedevent_activate_event`. One per node.
3. **Executors** register via `schedexec_intro_exec`. Multiple executors can register (parallel transaction execution).
4. **Auth server** registers via `mempoolauth_intro_auth`. Handles transaction signature verification.
5. **Coordinator** registers via `schedulercoord_intro_coord`. Drives consensus and block production.

The listed execution-layer interfaces use XDR-RPC over TCP. Protocol definitions live in `.x` files (XDR IDL) and are compiled to C++ (hogd), Rust (groundhog-rpc), TypeScript, and Go bindings.



## The Mempool as Orchestrator

The mempool (scheduler) is more than a transaction pool. It orchestrates the block lifecycle:

- Receives client transactions directly from the RPC gateway and peer transactions from the coordinator
- Verifies transactions through the auth server
- Maintains per-account transaction queues with balance-proportional scheduling
- Assembles block nominations when the coordinator requests them
- Dispatches transactions to executors for parallel execution
- Collects execution results after executors have submitted their deltas to the database for reservation
- Notifies DB shards of state changes at commit

The coordinator does not execute transactions or manage storage. It asks the mempool “give me a block to propose” and “commit this block.” The mempool handles everything else.



## Coordinator Connection

The coordinator (chuckd) is the consensus participant. It connects to the mempool and drives block production through these RPC calls:

| Call                            | Purpose                                           |
| ------------------------------- | ------------------------------------------------- |
| `schedulercoord_propose_block`  | ”Build a proposal for this block”                 |
| `schedulercoord_validate_block` | ”Is this peer’s proposed block valid?”            |
| `schedulercoord_commit_block`   | ”Finalize this block”                             |
| `schedulercoord_submit_vetted`  | Forward peer-gossiped transactions to the mempool |

The mempool also calls back to the coordinator via a reverse RPC channel to notify it when transactions pass vetting (triggering dissemination to peers).



## External Access

Clients submit transactions and query state through the public gateway.

**JSON-RPC gateway.** A separate service (`groundhog-rpc`) that exposes a JSON-RPC 2.0 API over HTTP. It submits transactions directly to the hogd scheduler. Reads use the scheduler, indexer, database gateway, or view gateway according to the method. The gateway is architecturally separate from the validator. It does not participate in consensus and can be scaled independently. See [JSON-RPC API](../pages/reference/json-rpc-api.md) for the method reference.

**Wallet integration.** Wallets sign transactions client-side and submit them through the JSON-RPC gateway. See [Wallet Integration](../pages/tools/wallet-integration.md) for the application-facing flow.



## Transaction Flow

Client submissions reach the scheduler through the gateway; peer-gossiped transactions arrive through the coordinator. The coordinator then drives proposal, validation, and commit through the interfaces above. Follow [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md) for the complete sequence and its possible outcomes.



## Related Documentation

- [Consensus](../pages/how-it-works/consensus.md): How the coordinator reaches agreement with peers
- [Parallel Execution](../pages/how-it-works/execution-model.md): How transactions execute against snapshots and produce deltas
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): The six stages from submission to commit
- [System Overview](../pages/how-it-works/architecture.md): The component map

---

## Compute, Capacity & Storage

Source: <https://docs.groundhog.dev/how-it-works/storage-economics/>

How HOG provides scheduling capacity and refundable storage deposits, while gas meters execution without a token fee.

Groundhog’s economic model is capital-based, not usage-based. You hold HOG tokens to get capacity. You don’t pay per operation.

HOG has two jobs: providing scheduling capacity and backing stored data.



## The Two Jobs of HOG

Every HOG token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Free HOGs determine how many transactions you can push through the network. Locked HOGs hold your data on-chain. The tradeoff is direct: every HOG you lock for storage is one less HOG contributing to your throughput share.



## Execution: Free, Throughput-Allocated

Running contract code has no token fee. It still uses finite execution and scheduling capacity.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

There is no unused-gas token refund. Metering does not debit or refund the sender’s HOG balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.



### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to free HOG balances over time. If account A holds 1,000 free HOGs and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s free HOGs sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, the transaction’s declared gas limit moves that much HOG capacity from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose HOGs have waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

HOGs cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

HOG transferred between accounts enters the recipient’s scheduling queue as newly received capacity. It does not carry the sender’s accumulated scheduling age.



## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks HOG according to the [storage type](../pages/programming-model/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees HOG for other storage or scheduling capacity.



### Cost Accounting

Every contract has a HOG balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts HOG from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked HOG to the contract’s free balance.

If an address does not have enough free HOG to cover a storage change, reservation can fail for insufficient funds. The transaction is excluded from that proposal and returned to the mempool. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.



### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.



### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.



## The Native Token

A sufficient first HOG credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](../pages/typescript/accounts.md#request-devnet-funds).

HOG is implemented by a native precompiled token contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting.



## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.



## Related Documentation

- [Contract Execution](../pages/programming-model/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](../pages/how-it-works/execution-model.md): How compatible state changes are admitted
- [System Overview](../pages/how-it-works/architecture.md): The component map
- [Storage Types Reference](../pages/reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](../pages/get-started/contract.md): Deploy your first contract

---

## Transaction Lifecycle

Source: <https://docs.groundhog.dev/how-it-works/transaction-lifecycle/>

How a transaction moves from submission to committed state.

Submitting a transaction is the start of the process. A successful submission does not prove that the contract call succeeded. Check the committed receipt’s execution result.



## Outcomes to distinguish

| Outcome                       | What it means                                                                                                              |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Rejected before execution** | Admission or authorization failed; the transaction did not reach contract execution                                        |
| **Committed success**         | The transaction is in a finalized block and its contract changes were applied                                              |
| **Committed abort or fault**  | The failure is recorded in the block, but the contract changes are discarded                                               |
| **Excluded from a proposal**  | The transaction did not land in that proposal; conflicting transactions return to the mempool for possible later inclusion |

A pending or `unknown` status, a timeout, or an advisory `recentFailure` is not proof of a committed failure. Keep the original network and transaction hash, and resume observation instead of automatically signing a replacement. See [Track transaction results](../pages/typescript/transaction-status.md) for the application workflow.



## Overview

A transaction passes through six stages:

1. **Submission**: Client submits a signed transaction
2. **Authorization**: Signatures are verified before the transaction enters the scheduling queue
3. **Scheduling**: The transaction is queued and selected for a block
4. **Execution and reservation**: Contract code runs against a snapshot, then its completed delta batch is reserved against the proposal
5. **Block Assembly**: The proposer packages results into a block proposal for consensus
6. **Commit**: Finalized state is written to storage



## Stage 1: Submission

The client signs the domain-separated preimage containing the network hash and inner transaction, then submits the signed wrapper through the JSON-RPC gateway. The network hash prevents replay on another Groundhog network. The gateway submits directly to the hogd scheduler.



## Stage 2: Authorization

The mempool sends the transaction to the auth server, which verifies the root address, auth claim, and signatures. Pubkey claims use the public key embedded in the claim. Source-address claims use the root address’s registered authorization data. This happens before the transaction enters the scheduling queue, not during execution.

- If verification succeeds: the transaction enters the scheduling queue
- If verification fails: the transaction is rejected

See [Authorization](../pages/how-it-works/authorization.md) for the signature preimage and admission models.



## Stage 3: Scheduling

Verified transactions are queued by account with balance-proportional scheduling. When the coordinator asks for a block proposal, the mempool selects transactions from accounts whose HOGs have waited longest. See [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md) for how scheduling priority works.



## Stage 4: Execution

Selected transactions execute in parallel against a **consistent snapshot** of the ledger state. All transactions in a block read from the same snapshot taken at the start of block processing.

When contract code executes:

- It reads state values from the snapshot (via syscalls like `BytestringGet`, `NonnegativeIntGet`)
- Ordinary storage reads do not see writes from other transactions in the block; RCQ consumers can observe concurrent inserts
- It produces deltas describing how to modify state
- It runs until termination (return, abort, or fault)

**Conflict checking follows root execution.** If the root call succeeds, the executor submits its completed delta batch for reservation against the proposed block. An incompatible batch is excluded. Contract execution and reservation can both proceed concurrently across executor workers. See [Parallel Execution: How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the mechanism and the distinction between checked and lazy operations.

See [Invocation Frames](../pages/how-it-works/invocation-frames.md) for detailed execution semantics (frame lifecycle, child calls, merge/discard rules).



### Root Frame Completion

When the root frame completes, the runtime checks its status:

- **Return (success)**: the transaction’s deltas are submitted for reservation. They are included only if the transaction remains admissible.
- **Deterministic Abort or Fault**: the failure can be included in the block with the contract’s writes discarded. Protocol bookkeeping, including replay protection, is still recorded. Once committed, this is a final execution result, not a transaction waiting to be retried.

This is distinct from **conflict exclusion** during reservation (Stage 4): the root frame may return successfully, but its completed delta batch can still fail reservation and be returned to the mempool for a future block. Deterministic abort and non-deterministic conflict exclusion are two different failure modes with different on-chain semantics.



## Stage 5: Block Assembly

The proposer packages the included transaction results into a consensus proposal: transaction hashes, nondeterministic execution data, and the computed block hash. The proposal is sent to validators via SCP. See [Consensus](../pages/how-it-works/consensus.md) for how the proposer/validator split works.



## Stage 6: Commit

Once consensus confirms the block, each validator commits the verified result to its DB shards. The new ledger state becomes the snapshot for the next block.

Transactions excluded during delta reservation (Stage 4) are returned to the mempool and may be re-evaluated in future blocks, subject to scheduling and expiry. Committed aborts and faults remain in the block with their contract changes discarded.



## Related Documentation

- [Invocation Frames](../pages/how-it-works/invocation-frames.md): Execution context
- [Authorization](../pages/how-it-works/authorization.md): How signatures are verified
- [Contract artifacts and addresses](../pages/how-it-works/contracts.md): Code hashes and deployment identities

---

## For Backend Developers

Source: <https://docs.groundhog.dev/start/for-backend-developers/>

Map your Postgres and database experience to Groundhog's programming model.

Database snapshot isolation is a useful starting point for Groundhog. Transactions share a committed block snapshot, but their writes follow typed storage merge rules rather than SQL conflict rules.



## Shared Snapshot

Every transaction in a block starts from the previous block’s committed state. Ordinary storage reads include its own changes and successful child calls, but not other transactions’ writes. `RetrocausalQueue` has separate rules for observing concurrent inserts. Each transaction produces typed changes, called **deltas**. Compatible deltas form the next committed state. See [Merged Deltas](../pages/programming-model/execution.md#merged-deltas).



## Deltas, Not Assignments

The core shift from a database: instead of `UPDATE accounts SET balance = 50`, you call `increase(5)`, meaning “adjust this value by +5.” This is `UPDATE accounts SET balance = balance + 5`. You express **how the value should change**, not what it should become.

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);          // checked debit
    self.balances.at_mut(receiver).lazy_increase(amount);    // deferred bound check
}
```

[`Balance`](../pages/programming-model/storage-types.md#balance) is the SDK type for this pattern. Both calls record deltas that can merge with concurrent transactions. `decrease()` loads the sender’s balance so an insufficient debit fails during execution. `lazy_increase()` skips the receiver load and defers its bound check until the delta batch is reserved. If two transactions debit 20 and 30 from a balance of 100, both can land and the next balance is 50. Applying the changes in either order gives the same result, so the operations **commute**.

That is enough of the model for most contract code. [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) explains how storage types decide which concurrent changes can land together. [NNInt and concurrent updates](../pages/programming-model/nnint.md) covers the lower-level `set_add` representation behind `Balance`, including base matching and the difference between `strict_inc`, `inc`, and `set`.

**Relative updates such as `SET col = col + ?` map naturally to mergeable integer operations.** Compatibility still depends on bounds and the transaction’s other changes. Absolute replacements can conflict when they assign different values.

***



## Conflicts and the Mempool

When deltas conflict, the transaction is excluded and returned to the mempool for possible inclusion in a later block. Contract code does not retry the operation. Clients still need to track confirmation and transaction expiry.

The balance constraint works the same way. If two concurrent withdrawals together exceed the available balance, one or more transactions are excluded. This is `CHECK (balance >= 0)` enforced by the storage model rather than application code.

***



## What’s Different From a Database

- **No ad-hoc queries.** Storage is key-value with typed values. You access data by key, not by query. An indexer provides query capabilities off-chain.
- **No JOINs.** If you need data from two Maps, you read both explicitly.
- **Deterministic execution.** No `NOW()`, no `RANDOM()`, no HTTP calls.
- **Write costs are deposits, not fees.** Storing data locks HOG tokens proportional to bytes stored. Delete the data, get the tokens back.
- **Gas limits exist but cost zero.** Gas meters computation (prevents infinite loops) but no tokens are burned. Your free HOG balance provides scheduling capacity. The declared gas limit determines how much capacity the transaction uses.

***



## Next Steps

For storage type details (`Balance`, `NNInt`, `Map`, `Vector`, `Value`, `Bytestring`, `CapacityConstraint`, and `RetrocausalQueue`) and their conflict semantics, see [Programming Model: Storage Types](../pages/programming-model/storage-types.md). For the contract-level execution model, see [Merged Deltas](../pages/programming-model/execution.md#merged-deltas).

Ready to write code? The [contract quickstart](../pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## For Blockchain Developers

Source: <https://docs.groundhog.dev/start/for-blockchain-developers/>

Map your Ethereum, Solana, or Move experience to Groundhog's programming model.

The contract lifecycle is familiar: write, test, deploy, and call. The main changes are how storage updates combine and how execution and storage are funded. This page introduces those shifts using a Solidity transfer as the starting point.

***



## Token Transfers

A token transfer on Solidity:

```solidity
function transfer(address to, uint256 amount) public {
    require(balances[msg.sender] >= amount, "insufficient");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

The same transfer on Groundhog:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The code stays familiar. `balances` is a `Map<ContractAddress, Balance>`. Calling `at_mut(address)` selects the balance that will change and returns a mutable handle. Selecting it does not load the balance.

`decrease(amount)` loads the sender’s snapshot balance because the contract needs to fail immediately when funds are insufficient. `lazy_increase(amount)` skips the receiver load because the contract does not need an immediate overflow result. Its bound is checked when the transaction’s completed delta batch is admitted. Both calls produce deltas that can merge with compatible transactions. `Balance` accepts only nonnegative amounts and exposes no absolute `set` operation.

That is enough of the model for this transfer. [Build a Token](../pages/tutorials/build-a-token.md) uses this pattern in a complete contract. [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) explains how Groundhog combines changes across a block.

***



## Reentrancy and Balance Checks

`Balance::decrease` checks the transaction’s current balance view. The runtime also checks aggregate bounds when concurrent deltas are reserved. This does not replace authorization or application-specific checks.

Contract calls also have different reentrancy rules from the EVM. See the [EVM reentrancy comparison](../pages/ecosystem/evm.md#reentrancy) for that call pattern, and [Authorization](../pages/how-it-works/authorization.md) for caller checks and signed permissions.

***



## Resource and Transaction Rules

Groundhog exposes these rules to contract developers:

- **Gas price estimation.** Gas limits exist for metering, but gas costs zero. The declared gas limit still consumes scheduling capacity.
- **Ordering-sensitive balance updates.** Commutative balance deltas have the same merged outcome in any execution order. Application flows that conflict still need protocol-aware design.
- **Nonces.** Replay protection uses a unique expiry-height and nonce pair, without a sequential account counter.
- **Fee-driven compute tuning.** Gas limits still bound each transaction and child call, but using more gas does not increase a token fee.
- **Access lists.** Unlike Solana, where every account a transaction touches must be declared up front, Groundhog discovers storage access during execution. (EVM only requires explicit access lists when opting into EIP-2930.)
- **Storage slot packing.** Typed fields via `#[sdk::storage]`. No manual layout, no packing variables into 256-bit slots.
- **TTL management.** No storage expiry. Data persists as long as its HOG deposit is held. Delete the data, get the deposit back.

***



## The Programming Model in Brief

Choose operations that express the change you intend. Use `Balance` for ordinary balance adjustments, `Map` for separate records, and other storage types when the application needs different merge rules. Compatible arithmetic can combine, but ordering-sensitive workflows still need an explicit design.

[Contract Execution](../pages/programming-model/execution.md) explains snapshots and deltas. [Storage Types](../pages/programming-model/storage-types.md) covers the available APIs, and [NNInt and concurrent updates](../pages/programming-model/nnint.md) covers the lower-level integer model.

***



## Storage Choices and Parallelism

The transfer example uses relative balance adjustments so compatible transfers can share a block. Replacing those adjustments with absolute values changes the conflict rules. Review your data model, not just the syntax, when adapting an existing contract.

***



## Next Steps

Continue in layers:

1. [Contract quickstart](../pages/get-started/contract.md) builds and deploys your first contract.
2. [Build a Token](../pages/tutorials/build-a-token.md) applies checked and lazy balance operations in a complete ERC-20-style contract.
3. [Contract Execution](../pages/programming-model/execution.md) and [Storage Types](../pages/programming-model/storage-types.md) give the full contract-author model.
4. [How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved) explains the engine’s reservation machinery.

For a detailed Solidity-to-Groundhog mapping, see [EVM & Solidity](../pages/ecosystem/evm.md).

---

## For Distributed Systems Developers

Source: <https://docs.groundhog.dev/start/for-distributed-systems-developers/>

Map your distributed systems experience to Groundhog's programming model.

Commutative operations are a useful starting point for Groundhog. Its typed deltas combine changes within a consensus block, rather than reconciling independently writable replicas.

***



## Your Head Start

You already think in terms of commutative operations. You know that `x + 5` and `x + 3` produce the same result in any order. You know that operations on independent keys don’t interact. You’ve designed systems around these properties.

That instinct is exactly right for Groundhog. [`Balance`](../pages/programming-model/storage-types.md#balance) exposes checked and lazy increases and decreases for non-negative values. Lower-level [`NNInt`](../pages/programming-model/storage-types.md#nnint) works like a counter whose signed changes combine additively. `Map<K, V>` gives you key-level independence. If you’ve ever reached for a PN-Counter or a per-key CRDT map, you already know why these primitives exist.

The key distinction is where coordination happens.

***



## Coordination at Block Boundaries

**Groundhog has consensus.** CRDTs solve the problem of replicas that diverge and must eventually agree without coordination. Groundhog has a consensus protocol. Every block is agreed upon by the network. The types don’t exist to achieve convergence across unsynchronized replicas. They exist to enable parallel execution *within* a single consensus round.

All transactions in a block execute against the same frozen snapshot. They produce typed changes, called [deltas](../pages/programming-model/execution.md#merged-deltas). The runtime checks which changes can coexist, and each finalized block contains one committed result. There’s no divergence to reconcile.

This means:

- **No causal metadata.** No vector clocks, no dot stores, no version vectors. The block boundary is the synchronization point. There’s no partial order to resolve.
- **Balance limits are enforced.** A PN-Counter can go negative. Groundhog’s `Balance` API keeps ordinary balances non-negative, and the runtime checks the combined result when lazy deltas commit. If debits exceed the available value, one or more transactions are excluded and returned to the mempool. No tombstones, no compensating operations.
- **Each block has one result.** There is no continuous merge through anti-entropy or gossip. Nodes that have applied the same finalized block agree on its state.
- **Finalized state.** Nodes may lag while receiving or replaying blocks; applications read the state at the serving node’s available height.

***



## If You Don’t Know Any of This

That’s fine. Groundhog doesn’t require distributed systems knowledge. Use `Balance` for balances and allowances, `NNInt` for signed counters or votes, and `Map` for per-key data. The types handle commutativity for you. The [For Backend Developers](../pages/start/for-backend-developers.md) guide maps the same concepts from database experience, which may be a better starting point.

***



## Next Steps

For the contract-level model, see [Merged Deltas](../pages/programming-model/execution.md#merged-deltas). For the storage type API, see [Storage Types](../pages/programming-model/storage-types.md). For concurrent delta reservation and the engine’s actual conflict timing, see [How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved).

Ready to write code? The [contract quickstart](../pages/get-started/contract.md) walks you through building and deploying your first contract.
