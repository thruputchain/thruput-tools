# Understand Stellar Thruput

Documentation source: `1a24dab12e61451e433e7cf043671d87a3194e81`.

Historical guide artifact: CLI 0.19.0. Current guidance uses the maintained Thruput skill. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Introduction

Source: <https://thruput.network/architecture/>

Learn what Stellar Thruput is and how compatible updates let contracts share state.

Stellar Thruput is a moonshot project exploring how parallel execution can make compute abundant. Transactions record compatible changes to shared state, allowing the network to combine them without requiring sequential execution.

The project’s future is open. No decisions have been made about mainnet or its relationship to Stellar. These docs describe the development network and tools available today.

You write contract logic in Rust and connect applications through the TypeScript client or React library. The runtime combines changes using rules defined by the storage type.



## Record the change

Consider a counter with a value of `100`. Two transactions want to increase it, one by `5` and the other by `3`.

If each transaction replaces the value it read, they propose different results: `105` and `103`. With mergeable integer storage, they record the increases instead:

```text
Starting value:    100
Transaction A:     +5
Transaction B:     +3
Combined value:    108
```

These increases can combine if the rest of the transactions are compatible and network limits permit them. Neither transaction needs to calculate a replacement value that includes the other’s update.

This is useful for shared counters and balances. It does not make every operation independent: replacing a value, enforcing uniqueness, or choosing a winning order can require different rules. Your storage choices determine which changes can combine.

[Parallel Execution](../pages/how-it-works/execution-model.md) explains how Stellar Thruput applies these rules. [Storage types](../pages/programming-model/storage-types.md) shows how to use them in a contract.



## Build in two layers

**Contracts** define application rules and store onchain state. Use the Rust SDK to write and test them, and the CLI to build, deploy, and inspect them.

**Applications** read contract data and request transactions. The TypeScript client provides network and contract operations. The React library adds wallet connection and balance hooks for interfaces.

You can start with either layer. An application can use an existing contract without implementing one first.



## Where to start

Choose a path in [Get Started](../pages/get-started.md) to write code. To explore the platform first, use the [System Overview](../pages/how-it-works/architecture.md) as a map, then follow the [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md) or read about [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md).

---

## System Overview

Source: <https://thruput.network/how-it-works/architecture/>

How Stellar Thruput's public gateway, execution services, storage, and consensus coordinator fit together.

Stellar Thruput separates three responsibilities: serving applications, executing transactions and storing state, and agreeing on blocks. This page maps those responsibilities to the services that handle them.



## Components

```text
Applications and wallets
      |
      v
JSON-RPC gateway
      |
      +-- Reads
      |   State / Views / History
      |
   submits
      v
  Scheduler <--> Coordinator
      |               |
      |         Other validators
      |
      +-- Auth server
      +-- Executors <--> DB shards
      +-- Event server
```

The diagram shows the main service relationships. [Networking](../pages/how-it-works/networking.md) covers registration and communication between them.

| Component                              | Responsibility                                                                                                      |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| **JSON-RPC gateway** (`groundhog-rpc`) | Accepts application requests, submits transactions to the scheduler, and routes reads to the relevant service       |
| **Scheduler / mempool** (`hogd`)       | Queues transactions, coordinates authorization, dispatches execution, and orchestrates block production and commits |
| **Auth server**                        | Checks transaction authorization claims and signatures before scheduling                                            |
| **Executors**                          | Run contract code and submit its state changes for reservation against the proposed block                           |
| **DB shards**                          | Serve state snapshots, enforce storage merge rules, and store committed state                                       |
| **Event server and indexer**           | Collect execution results and make transaction history, receipts, and events available for queries                  |
| **Coordinator** (`chuckd`)             | Drives consensus with other validators and asks the execution layer to propose, validate, and commit blocks         |





## Two paths through the gateway

**Transactions** enter through the gateway and reach the scheduler. The scheduler arranges signature checks, selects work, and dispatches it to executors. The execution layer produces a block proposal; the coordinator handles agreement with other validators.

**Reads** use the service appropriate to the request. State and balance queries use the database gateway, read-only contract calls use the view gateway, and receipt and event queries use the indexer. The scheduler supplies information such as the chain tip and pending transaction status.

The public gateway does not participate in consensus. Applications use its [JSON-RPC API](../pages/reference/json-rpc-api.md) rather than the internal service interfaces.





## Execution and agreement

The execution layer determines what a proposed block would do. Contracts run against a shared snapshot and produce typed state changes. Executors and DB shards check which changes can be reserved together.

The coordinator drives agreement on which valid proposal to commit. It uses the Stellar Consensus Protocol (SCP); it does not run the contracts itself. Each validator checks the proposed result through its own execution layer before committing it.



Multiple execution workers and database shards distribute work within a node. Consensus coordinates agreement between validators. These are different responsibilities; adding execution capacity does not change the consensus rules.



## Explore the details

- [Parallel Execution](../pages/how-it-works/execution-model.md): Snapshots, compatible updates, and conflict reservation
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): Submission, execution outcomes, and commit
- [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md): Scheduling and storage deposits
- [Consensus](../pages/how-it-works/consensus.md): Proposals, validation, and finality
- [Networking](../pages/how-it-works/networking.md): Component registration and internal interfaces

For the behavior your contract relies on, read [Contract Execution](../pages/programming-model/execution.md).

---

## Parallel Execution

Source: <https://thruput.network/how-it-works/execution-model/>

How the engine executes transactions against snapshots and reserves compatible state changes.



## The Core Idea

Every transaction reads from a consistent snapshot and records typed deltas. The storage type determines how those deltas combine.

Commutativity describes operations whose combined result does not depend on their order. Stellar Thruput still enforces resource limits, including gas limits, bounded return values, and a maximum encoded transaction size.

This page explains the engine: snapshots, concurrent reservation, and conflict selection. For the rules your code relies on, read [Contract Execution](../pages/programming-model/execution.md).



## Snapshot Isolation

Each transaction sees the ledger as it was at the start of the block. All transactions in a block read from the same snapshot. Ordinary storage reads do not observe other transactions’ writes within that block.

Reads also reflect changes within the current transaction and successful child calls. The database snapshot analogy does not imply identical SQL isolation or conflict rules.

`RetrocausalQueue` also permits observations of concurrent inserts. These are recorded as nondeterministic proposal data and replayed by validators. Its read semantics differ from ordinary snapshot storage.



## Delta Writes

Transactions record typed operations: arithmetic deltas, value replacements, or deletions. Each storage type defines how those operations combine.

Instead of “set balance to 50”, a transaction says “increment balance by 10.” After each root contract call completes, the runtime reserves its delta batch alongside compatible deltas already admitted to the proposed block. The admitted deltas form the next state at commit.

In Solidity, a transfer looks like this:

```solidity
// Solidity: read balances and assign their updated values.
balances[from] = balances[from] - amount;
balances[to] = balances[to] + amount;
```

In Stellar Thruput:

```rust
// Stellar Thruput: write deltas. Two compatible transfers to the same
// account produce two deltas that merge cleanly.
balances.at_mut(&from).decrease(amount);
balances.at_mut(&to).increase(amount);
```

Two compatible increments to the same balance produce the same result regardless of order. `(x + 3) + 5 = (x + 5) + 3`. That is commutativity, and it is why Stellar Thruput can execute transactions in parallel without declared access lists.



## What Commutes and What Doesn’t

Transactions execute concurrently. Storage merge rules determine whether their changes can land together. A conflicting transaction is excluded from the proposal and reported as `retry`. The client resubmits it.

| Operation                               | Can both changes land? | Why                                                             |
| --------------------------------------- | ---------------------- | --------------------------------------------------------------- |
| Two balance changes on the same counter | When compatible        | Resolved bases must match and aggregate bounds must hold        |
| Two writes to different Map keys        | Yes                    | Independent keys don’t interact                                 |
| Two writes to the same bytestring       | When identical         | Different values conflict                                       |
| Multiple inserts into the same queue    | Yes                    | Entries are sorted; insertion order doesn’t matter              |
| Two deletions of the same key           | Yes                    | Same outcome regardless of order                                |
| A deletion and a write to the same key  | No                     | Different operation types conflict; one transaction is excluded |

These rules describe the listed operations. Other changes in either transaction can still cause a conflict.



### What This Means for Your Data Model

Choose storage around the changes your application needs to combine. Mergeable arithmetic still has bounds; absolute writes can coexist when they store identical values. [Storage Types](../pages/programming-model/storage-types.md#choosing-a-type) turns these rules into contract-design choices.



## How Conflicts Are Resolved

The programming model describes a transaction as executing first and then attempting to land its deltas. The engine implements that boundary directly: ordinary storage conflicts are checked after the root contract call returns, before the transaction is committed into the proposed block.



### Concurrent Delta Reservation

Contract execution accumulates writes in the transaction’s `ItemView`. A checked operation such as `Balance::decrease(30)` first loads the snapshot base and can abort immediately if that transaction alone would underflow. A lazy operation skips that load and therefore cannot report a snapshot-bound failure from contract code. Both forms produce an NNInt delta.

After the root call returns successfully, `try_commit_transaction()` submits the transaction’s complete delta batch to hogd. For a lazy `NonnegativeIntAdd`, hogd resolves the set value from the block snapshot. A checked `NonnegativeIntSetAdd` already carries that same snapshot value. Both then use the same NNInt type-class match and aggregate bounds reservation.

For a snapshot balance of 10, the per-key reservation starts with subtraction capacity of 10:

```plaintext
Snapshot: Alice balance = 10
          Subtraction budget = 10

Tx A contract returns with delta -8
      Reserve delta batch: capacity 10 → 2 → admitted

Tx B contract returns with delta -5
      Reserve delta batch: capacity would be -3 → excluded
```

Whichever transaction reserves first wins. The lock is per-key, per-block and is initialized from the snapshot. Reservations on different keys use separate locks. Transactions touching the same key contend for the same aggregate bounds. Reservation can happen concurrently across executor workers; atomic capacity accounting ensures the combined admitted delta remains in range.

Compatible operations, such as two increases within the upper bound or two decreases within the available balance, can both reserve successfully. Checked and lazy operations share these merge rules. Checked operations can detect underflow in contract code; lazy operations leave that check to reservation. Credits from other transactions do not increase the snapshot’s subtraction budget. A lazy decrease cannot rely on another transaction’s same-block credit.



### What Block Close Does

By the time block close runs, all capacity conflicts have been resolved. Block close stages the already-finalized locks into a ChangeSet and computes the block hash. No conflict resolution happens at this stage for Balance, NNInt, Map, Value, or Bytestring operations.

RetrocausalQueue is the exception: it has end-of-block invariant checks that the other storage types do not. RCQ entries from excluded transactions are removed during block finalization.



The proposer records reservation-dependent outcomes so validators can replay and verify the proposed block. Contract code chooses storage operations; it does not manage the engine’s reservation locks.



## Related reading

- [Contract Execution](../pages/programming-model/execution.md): The contract-author model
- [Storage Types](../pages/programming-model/storage-types.md): API choices and merge rules
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md): Gas limits, scheduling, and deposits

---

## Transaction Lifecycle

Source: <https://thruput.network/how-it-works/transaction-lifecycle/>

How a transaction moves from submission to committed state.

Submitting a transaction is the start of the process. A successful submission does not prove that the contract call succeeded. Check the committed receipt’s execution result.



## Outcomes to distinguish

| Outcome                       | What it means                                                                                                                             |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| **Rejected before execution** | Admission or authorization failed; the transaction did not reach contract execution                                                       |
| **Committed success**         | The transaction is in a finalized block and its contract changes were applied                                                             |
| **Committed abort or fault**  | The failure is recorded in the block, but the contract changes are discarded                                                              |
| **Excluded from a proposal**  | The transaction did not land in that proposal and is reported as `retry`; its replay nonce is not consumed, so the client can resubmit it |

A pending or `unknown` status, a timeout, or an advisory `recentFailure` is not proof of a committed failure. Keep the original network and transaction hash, and resume observation instead of automatically signing a replacement. See [Track transaction results](../pages/typescript/transaction-status.md) for the application workflow.



## Overview

A transaction passes through six stages:

1. **Submission**: Client submits a signed transaction
2. **Authorization**: Signatures are verified before the transaction enters the scheduling queue
3. **Scheduling**: The transaction is queued and selected for a block
4. **Execution and reservation**: Contract code runs against a snapshot, then its completed delta batch is reserved against the proposal
5. **Block Assembly**: The proposer packages results into a block proposal for consensus
6. **Commit**: Finalized state is written to storage



## Stage 1: Submission

The client signs the domain-separated preimage containing the network hash and inner transaction, then submits the signed wrapper through the JSON-RPC gateway. The network hash prevents replay on another Stellar Thruput network. The gateway submits directly to the hogd scheduler.



## Stage 2: Authorization

The mempool sends the transaction to the auth server, which verifies the root address, auth claim, and signatures. Pubkey claims use the public key embedded in the claim. Source-address claims use the root address’s registered authorization data. This happens before the transaction enters the scheduling queue, not during execution.

- If verification succeeds: the transaction enters the scheduling queue
- If verification fails: the transaction is rejected

See [Authorization](../pages/how-it-works/authorization.md) for the signature preimage and admission models.



## Stage 3: Scheduling

Verified transactions are queued by account with balance-proportional scheduling. When the coordinator asks for a block proposal, the mempool selects transactions from accounts whose token-backed capacity has waited longest. See [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md) for how scheduling priority works.



## Stage 4: Execution

Selected transactions execute in parallel against a **consistent snapshot** of the ledger state. All transactions in a block read from the same snapshot taken at the start of block processing.

When contract code executes:

- It reads state values from the snapshot (via syscalls like `BytestringGet`, `NonnegativeIntGet`)
- Ordinary storage reads do not see writes from other transactions in the block; RCQ consumers can observe concurrent inserts
- It produces deltas describing how to modify state
- It runs until termination (return, abort, or fault)

**Conflict checking follows root execution.** If the root call succeeds, the executor submits its completed delta batch for reservation against the proposed block. An incompatible batch is excluded. Contract execution and reservation can both proceed concurrently across executor workers. See [Parallel Execution: How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved) for the mechanism and the distinction between checked and lazy operations.

See [Invocation Frames](../pages/how-it-works/invocation-frames.md) for detailed execution semantics (frame lifecycle, child calls, merge/discard rules).



### Root Frame Completion

When the root frame completes, the runtime checks its status:

- **Return (success)**: the transaction’s deltas are submitted for reservation. They are included only if the transaction remains admissible.
- **Deterministic Abort or Fault**: the failure can be included in the block with the contract’s writes discarded. Protocol bookkeeping, including replay protection, is still recorded. Once committed, this is a final execution result, not a transaction waiting to be retried.

This is distinct from **conflict exclusion** during reservation (Stage 4): the root frame may return successfully, but its completed delta batch can still fail reservation and be excluded. Deterministic abort and non-deterministic conflict exclusion are two different failure modes with different on-chain semantics.



## Stage 5: Block Assembly

The proposer packages the included transaction results into a consensus proposal: transaction hashes, nondeterministic execution data, and the computed block hash. The proposal is sent to validators via SCP. See [Consensus](../pages/how-it-works/consensus.md) for how the proposer/validator split works.



## Stage 6: Commit

Once consensus confirms the block, each validator commits the verified result to its DB shards. The new ledger state becomes the snapshot for the next block.

Transactions excluded during delta reservation (Stage 4) are reported as `retry`. Do not rely on the network to include them later. Resubmit the same signed transaction until it commits or expires. Committed aborts and faults remain in the block with their contract changes discarded.



## Related Documentation

- [Invocation Frames](../pages/how-it-works/invocation-frames.md): Execution context
- [Authorization](../pages/how-it-works/authorization.md): How signatures are verified
- [Contract artifacts and addresses](../pages/how-it-works/contracts.md): Code hashes and deployment identities

---

## Compute, Capacity & Storage

Source: <https://thruput.network/how-it-works/storage-economics/>

How the native token provides scheduling capacity and refundable storage deposits without conventional gas fees.

Stellar Thruput has no conventional gas fees. Its native token backs onchain storage and provides scheduling capacity under load. The current experimental network’s native token has no monetary value.

Removing the sequential execution bottleneck is intended to make compute abundant rather than keep it scarce by design. Parallel execution does not remove hardware limits or contention: the network still meters computation and allocates capacity when demand exceeds it.





## The Two Jobs of the Native Token

Each unit of the native token in your account is in one of two states:

| State      | What it does                                  | How you get it back                                         |
| ---------- | --------------------------------------------- | ----------------------------------------------------------- |
| **Free**   | Entitles you to a share of network throughput | No deposit to reclaim; scheduling does not spend the tokens |
| **Locked** | Backs a piece of on-chain storage             | Returned when you delete the data                           |

Locking native tokens for storage reduces the free balance available for scheduling.





## Execution: Metered, Throughput-Allocated

Running contract code has no conventional gas fee. It still uses finite execution and scheduling capacity, backed by the sender’s unlocked native-token balance.

The protocol defines gas limits on transactions and cross-contract calls, but gas costs zero. The gas infrastructure exists for computational metering (preventing infinite loops, bounding cross-contract calls), not for billing.

For root transactions, scheduling uses the **declared gas limit**, not measured consumption. A transaction with a `100_000` gas limit reserves capacity for that limit whether execution uses `20_000`, `95_000`, or all `100_000`. Exceeding the limit faults the transaction.

There is no unused-gas token refund. Metering does not debit or refund the sender’s native-token balance, so it does not add a balance update for each transaction. Choose a limit that covers execution without reserving unnecessary scheduling capacity.



### Balance-Proportional Scheduling

When demand is below capacity, there is less scheduling contention. Inclusion still depends on admission, propagation, storage conflicts, and transaction expiry; the next block is not guaranteed.

When demand exceeds capacity, the scheduler allocates capacity proportionally to unlocked native-token balances over time. If account A holds 1,000 unlocked native tokens and account B holds 500, A receives roughly twice the scheduling capacity for comparable demand. This is Balance-Proportional Scheduling (BPS). Transaction counts also depend on their declared gas limits.

The mechanism works through age-weighted queuing. Each account’s unlocked tokens sit in a scheduling queue tagged with the block number they entered. When a transaction is scheduled, its declared gas limit determines how much token-backed capacity moves from the “ready” group to the “scheduled” group. The proposer fills each block by selecting transactions whose capacity has waited longest. Over time, this produces proportional allocation without requiring any fee market or priority auction.

Tokens cycle through scheduling groups and become ready again. This changes their scheduling priority, not the number of tokens held.

Native tokens transferred between accounts enter the recipient’s scheduling queue as newly received capacity. They do not carry the sender’s accumulated scheduling age.



## Storage: Refundable Deposits

When your contract adds data to the ledger, it locks native tokens according to the [storage type](../pages/programming-model/storage-types.md) and size of the data. Delete the data and the deposit is returned to the address that held it. This is a deposit, not a burn.

Deleting unused state frees native tokens for other storage or scheduling capacity.



### Cost Accounting

Every contract has a native-token balance that represents its unlocked (free) tokens. When a transaction commits, the runtime computes the storage delta for each piece of modified data and adjusts the contract’s balance accordingly.

- **Writing new data** deducts native tokens from the contract’s free balance. The cost depends on the storage type: NNInt has a fixed per-key cost, bytestrings include a per-byte cost, and other types have their own formulas.
- **Modifying existing data** adjusts the deposit up or down based on the size difference.
- **Deleting data** returns the locked native tokens to the contract’s free balance.

If an address does not have enough unlocked native tokens to cover a storage change, reservation can fail for insufficient funds. The transaction is excluded from that proposal and reported as `retry`. This differs from a committed contract abort, whose result is recorded with its contract changes discarded. See [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md#outcomes-to-distinguish).

Your contract does not calculate storage costs or manage deposits manually. The runtime handles it as part of the normal transaction commit process.



### Configured Costs

The current implementation uses configured rates: base item costs, per-byte costs, and costs for specific item types such as authorization keys and queue entries. These rates come from the network’s storage cost model. The implementation does not adjust prices automatically based on total network state size.



### Sponsoring Users

A contract funds deposits for data stored under its address. Its operator can therefore provide application storage without asking users to fund each item. Users originating transactions still need scheduling capacity; storage funding does not provide execution sponsorship.



## The Native Token

A sufficient first native-token credit can pay for the recipient’s new balance-item deposit. A small first credit may be excluded with `insufficientFunds`; funding the balance item first is one option, not a universal requirement to use an airdrop. Amounts depend on runtime configuration. Funding a target’s storage does not fund the sender’s scheduling capacity. See the [client funding example](../pages/typescript/accounts.md#request-devnet-funds).

The native token is implemented by a native precompiled contract exposing the standard asset interface, including transfers, balance queries, and allowances. Applications call it through that interface. The runtime also uses its balances for scheduling and storage accounting. Current tooling calls this token `HOG`; use the existing `HOG_ADDRESS` SDK constant and CLI token alias when writing code or commands.



## Toll-Free Calls

> **caution: Planned, Not Implemented**
>
> Execution sponsorship is a planned feature, not a capability applications can currently rely on.

The intent is to let a contract provide scheduling capacity for its callers. That would let callers execute without holding the full capacity required by the transaction. This is separate from the storage funding described above.



## Related Documentation

- [Contract Execution](../pages/programming-model/execution.md): Contract-writing rules for execution and gas
- [Parallel Execution](../pages/how-it-works/execution-model.md): How compatible state changes are admitted
- [System Overview](../pages/how-it-works/architecture.md): The component map
- [Storage Types Reference](../pages/reference/storage-types.md): API for the typed primitives that storage deposits back
- [Contract quickstart](../pages/get-started/contract.md): Deploy your first contract

---

## Consensus

Source: <https://thruput.network/how-it-works/consensus/>

How SCP coordinates proposals, validation, and finalized blocks.



## Overview

Stellar Thruput uses the Stellar Consensus Protocol (SCP) for agreement. Each validator chooses **quorum slices**: sets of validators whose agreement it considers sufficient. Overlapping quorum slices allow validators to agree on a block.

Nomination uses a priority function to favor a proposed value in each round. Validators still need agreement under the configured quorum rules before finalizing a block.

SCP provides finality under its quorum-intersection and fault assumptions. Applications use the finalized block result rather than a probabilistic confirmation count.



## The Coordinator

Consensus is driven by the coordinator (chuckd), which is separate from the execution engine (hogd). The coordinator’s job is to get validators to agree on which block to commit. Contract execution and storage belong to the execution layer, orchestrated by the scheduler. See [System Overview](../pages/how-it-works/architecture.md) for the component roles.

Each coordinator is configured with its own quorum set: the list of other validators it trusts for consensus. This peer configuration is managed by the coordinator, not the mempool. The mempool handles intra-node component registration (executors, DB shards, etc.); the coordinator handles inter-node consensus topology. This separation keeps execution concerns and agreement concerns independent.

It runs a state machine called the **baton** that drives the consensus loop.



## Block Production

The baton runs a drive loop after every event:

```plaintext
driveCommit()    →  Commit any externalized block
driveNominate()  →  Propose next block if idle
driveCatchup()   →  Fetch missing blocks from peers
driveLiveness()  →  Detect stuck consensus
```



### Single-Node Flow

On a single validator (e.g. during development):

1. Baton calls `propose_block` on the mempool. The execution layer runs queued transactions and assembles a proposal.
2. SCP externalizes immediately (single-node quorum).
3. Baton calls `commit` on the mempool. The execution layer commits the finalized proposal to storage.
4. Next drive cycle begins.



### Multi-Node Flow

With multiple validators:

1. **Propose.** A validator asks its mempool for a block proposal. The proposal contains the transactions and metadata.
2. **Disseminate.** The full consensus value (nomination + metadata) is broadcast to peers via Dogwood (see below). A compact hash reference (the “cue”) is sent through SCP.
3. **Validate.** Receiving validators ask their own mempool: “is this nomination valid against my state?” Validation runs asynchronously and results are cached.
4. **Converge.** SCP envelope exchange continues until validators agree. Agreement depends on quorum intersection and the configured trust assumptions.
5. **Commit.** Once SCP externalizes a value, each validator commits the block locally via its mempool.



### Execution During Block Production

The proposer and validators execute transactions differently.

**The proposer runs concurrent execution.** Transactions are fanned across multiple executors and coroutines in parallel. After a root call completes, NNInt capacity locks reserve its delta batch via atomic compare-and-swap (see [Parallel Execution: How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved)). Which transaction wins a contested lock depends on thread scheduling. This is non-deterministic: two runs of the same transaction set on the same machine can produce different winners.

**The proposer captures nondeterministic outcomes.** Each transaction produces a `NondeterministicProposalData` payload covering proposal-dependent decisions such as capacity reservation outcomes and retrocausal queue observations. This payload is packaged alongside the transaction hashes in the consensus proposal.

**Validators replay deterministically.** Validators receive the proposer’s nominated transaction list and the nondeterministic data. They reconstruct each transaction from their local mempool, pair it with the proposer’s captured decisions, and replay execution using those decisions as input. Validators do not re-run the concurrent race. They verify that the transactions produce the claimed state transitions, recompute the block hash, and confirm it matches.

|                       | Proposer                                                   | Validator                                 |
| --------------------- | ---------------------------------------------------------- | ----------------------------------------- |
| Execution             | Concurrent across executors                                | Deterministic replay with proposer’s data |
| Conflict resolution   | Non-deterministic thread race                              | Reproduced from captured decisions        |
| Transaction selection | Discretionary (from local mempool)                         | Fixed (from nomination)                   |
| Output                | Nomination: tx hashes + nondeterministic data + block hash | Accept or reject the nomination           |

The proposer has discretion over which transactions to include and which conflicting transaction wins. Validators verify the math of the proposed result, not the policy that produced it. Deterministic replay makes the proposed result verifiable. It does not establish proposer fairness; scheduling and transaction selection are separate from validating state transitions.



## Dissemination: Dogwood

Validators exchange three types of data during consensus:

| Data                 | Description                                                               |
| -------------------- | ------------------------------------------------------------------------- |
| **Transactions**     | Signed transactions gossiped between validators                           |
| **Consensus values** | Full block nominations (transactions + metadata)                          |
| **SCP envelopes**    | Protocol messages for agreement (nominate, prepare, confirm, externalize) |

Dogwood is the dissemination layer. It uses **erasure-coded multicast**: data is split into chunks, encoded with redundancy, and broadcast over BFS multicast trees. Receivers can reconstruct the original data from a subset of chunks, reducing bandwidth requirements while tolerating packet loss.

Each data type is tagged and demultiplexed on receipt. Transactions are forwarded to the mempool. Consensus values are cached locally for validation. SCP envelopes are fed to the embedded SCP kernel.



## Finality Model

Under the required quorum assumptions, loss of enough validators can stop progress without invalidating finalized blocks. Incorrect or disjoint trust configurations can violate those assumptions.

Practical implications:

- **No confirmation count.** A confirmed transaction is final. There is no “wait for 6 blocks” or “99.9% probability of finality.”
- **Finalized blocks.** Under the consensus safety assumptions, finalized blocks are not replaced by competing blocks.
- **Halt recovery.** If the network halts due to quorum loss, it resumes from the last committed block once enough validators return. Nodes may need to catch up before participating again.



## Catchup and Repair

Validators that fall behind (new nodes, network partitions, restarts) catch up by fetching missing blocks from peers. The catchup agent requests blocks by height, validates them, and replays them locally.

A separate repair agent handles missing data during active consensus: if a validator receives a hash reference it cannot resolve (a consensus value or SCP envelope it hasn’t seen), it requests the full data from the originating peer.



## Related Documentation

- [Networking](../pages/how-it-works/networking.md): Node topology and how the coordinator connects to the mempool
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): How a transaction moves from submission to commit
- [Parallel Execution](../pages/how-it-works/execution-model.md): How transactions execute against snapshots
- [System Overview](../pages/how-it-works/architecture.md): The component map

---

## Networking

Source: <https://thruput.network/how-it-works/networking/>

Node topology, component registration, and how transactions reach the mempool.

The [System Overview](../pages/how-it-works/architecture.md#components) maps the main components. This page explains how they find each other and communicate.



## Topology

Stellar Thruput’s services are organized into an execution layer and a consensus layer.

The **coordinator** (chuckd, written in Go) sits above the execution layer. It drives consensus with other validators, manages peer topology, and tells the local mempool when to produce and commit blocks.

The **mempool** (scheduler, part of hogd) is the hub of the execution layer. All execution components register with it: executors, DB shards, event server, auth server. The mempool orchestrates block production, transaction execution, and state commits.

Separately, the **RPC gateway** (groundhog-rpc) provides external API access. It connects to the scheduler, indexer, database gateway, and view gateway but does not participate in consensus. It can be scaled independently of the validator.

Within the execution layer, no component discovers peers independently. The mempool is the registry for intra-node communication. When a component registers, it gets back the addresses of everything else it needs to talk to.

The coordinator manages inter-node consensus and transaction gossip using its configured peers and quorum sets. See [Consensus](../pages/how-it-works/consensus.md) for how coordinators reach agreement.



## Component Registration

Components register their addresses and readiness with the scheduler. Most use an “intro” RPC; the event server uses a prepare/activate handshake. The scheduler waits for the required components before dispatching work.

Registration interfaces:

1. **DB shards** register via `scheddb_intro_shard`. Multiple shards can register (horizontal storage scaling).
2. **Event server** registers via `schedevent_prepare_event` and `schedevent_activate_event`. One per node.
3. **Executors** register via `schedexec_intro_exec`. Multiple executors can register (parallel transaction execution).
4. **Auth server** registers via `mempoolauth_intro_auth`. Handles transaction signature verification.
5. **Coordinator** registers via `schedulercoord_intro_coord`. Drives consensus and block production.

The listed execution-layer interfaces use XDR-RPC over TCP. Protocol definitions live in `.x` files (XDR IDL) and are compiled to C++ (hogd), Rust (groundhog-rpc), TypeScript, and Go bindings.



## The Mempool as Orchestrator

The mempool (scheduler) is more than a transaction pool. It orchestrates the block lifecycle:

- Receives client transactions directly from the RPC gateway and peer transactions from the coordinator
- Verifies transactions through the auth server
- Maintains per-account transaction queues with balance-proportional scheduling
- Assembles block nominations when the coordinator requests them
- Dispatches transactions to executors for parallel execution
- Collects execution results after executors have submitted their deltas to the database for reservation
- Notifies DB shards of state changes at commit

The coordinator requests proposals and commits. The scheduler coordinates the execution services that perform the work.



## Coordinator Connection

The coordinator (chuckd) is the consensus participant. It connects to the mempool and drives block production through these RPC calls:

| Call                            | Purpose                                           |
| ------------------------------- | ------------------------------------------------- |
| `schedulercoord_propose_block`  | ”Build a proposal for this block”                 |
| `schedulercoord_validate_block` | ”Is this peer’s proposed block valid?”            |
| `schedulercoord_commit_block`   | ”Finalize this block”                             |
| `schedulercoord_submit_vetted`  | Forward peer-gossiped transactions to the mempool |

The mempool also calls back to the coordinator via a reverse RPC channel to notify it when transactions pass vetting (triggering dissemination to peers).



## External Access

Clients submit transactions and query state through the public gateway.

**JSON-RPC gateway.** Exposes JSON-RPC 2.0 over HTTP and routes requests to the relevant execution-layer service. See [JSON-RPC API](../pages/reference/json-rpc-api.md) for the method reference.

**Wallet integration.** Wallets sign transactions client-side and submit them through the JSON-RPC gateway. See [Wallet Integration](../pages/tools/wallet-integration.md) for the application-facing flow.



## Transaction Flow

Client submissions reach the scheduler through the gateway; peer-gossiped transactions arrive through the coordinator. The coordinator then drives proposal, validation, and commit through the interfaces above. Follow [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md) for the complete sequence and its possible outcomes.



## Related Documentation

- [Consensus](../pages/how-it-works/consensus.md): How the coordinator reaches agreement with peers
- [Parallel Execution](../pages/how-it-works/execution-model.md): How transactions execute against snapshots and produce deltas
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md): The six stages from submission to commit
- [System Overview](../pages/how-it-works/architecture.md): The component map

---

## For Blockchain Developers

Source: <https://thruput.network/start/for-blockchain-developers/>

Understand Stellar Thruput's storage and execution rules through a familiar token transfer.

The contract lifecycle is familiar: write, test, deploy, and call. The main changes are how storage updates combine and how execution and storage are funded. This page introduces those shifts using a Solidity transfer as the starting point.

***



## Token Transfers

A token transfer on Solidity:

```solidity
function transfer(address to, uint256 amount) public {
    require(balances[msg.sender] >= amount, "insufficient");
    balances[msg.sender] -= amount;
    balances[to] += amount;
}
```

The same transfer on Stellar Thruput:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

The code stays familiar. `balances` is a `Map<ContractAddress, Balance>`. Calling `at_mut(address)` selects the balance that will change and returns a mutable handle. Selecting it does not load the balance.

`decrease(amount)` loads the sender’s snapshot balance because the contract needs to fail immediately when funds are insufficient. `lazy_increase(amount)` skips the receiver load because the contract does not need an immediate overflow result. Its bound is checked when the transaction’s completed delta batch is admitted. Both calls produce deltas that can merge with compatible transactions. `Balance` accepts only nonnegative amounts and exposes no absolute `set` operation.

[Build a Token](../pages/guides/build-a-token.md) uses this pattern in a complete contract. [Merged Deltas](../pages/programming-model/execution.md#merged-deltas) explains how Stellar Thruput combines changes across a block.

***



## Reentrancy and Balance Checks

`Balance::decrease` checks the transaction’s current balance view. The runtime also checks aggregate bounds when concurrent deltas are reserved. This does not replace authorization or application-specific checks.

Contract calls also have different reentrancy rules from the EVM. See the [EVM reentrancy comparison](../pages/ecosystem/evm.md#reentrancy) for that call pattern, and [Authorization](../pages/how-it-works/authorization.md) for caller checks and signed permissions.

***



## Resource and Transaction Rules

Stellar Thruput exposes these rules to contract developers:

- **Gas price estimation.** Gas limits exist for metering, but gas costs zero. The declared gas limit still consumes scheduling capacity.
- **Ordering-sensitive balance updates.** Commutative balance deltas have the same merged outcome in any execution order. Application flows that conflict still need protocol-aware design.
- **Nonces.** Replay protection uses a unique expiry-height and nonce pair, without a sequential account counter.
- **Access lists.** Stellar Thruput discovers storage access during execution. Compare [Solana account declarations](../pages/ecosystem/solana.md#access-lists-vs-type-based-parallelism) with Ethereum’s optional [EIP-2930 access lists](https://eips.ethereum.org/EIPS/eip-2930).
- **Storage slot packing.** Typed fields via `#[thruput_sdk::storage]`. No manual layout, no packing variables into 256-bit slots.
- **TTL management.** No storage expiry. Data persists as long as its native-token deposit is held. Delete the data, get the deposit back.

***



## The Programming Model in Brief

Choose operations that express the change you intend. Use `Balance` for ordinary balance adjustments, `Map` for separate records, and other storage types when the application needs different merge rules. Compatible arithmetic can combine, but ordering-sensitive workflows still need an explicit design.

[Contract Execution](../pages/programming-model/execution.md) explains snapshots and deltas. [Storage Types](../pages/programming-model/storage-types.md) covers the available APIs, and [NNInt and concurrent updates](../pages/programming-model/nnint.md) covers the lower-level integer model.

***



## Storage Choices and Parallelism

The transfer example uses relative balance adjustments so compatible transfers can share a block. Replacing those adjustments with absolute values changes the conflict rules. Review your data model, not just the syntax, when adapting an existing contract.

***



## Next Steps

Continue in layers:

1. [Contract quickstart](../pages/get-started/contract.md) builds and deploys your first contract.
2. [Build a Token](../pages/guides/build-a-token.md) applies checked and lazy balance operations in a complete ERC-20-style contract.
3. [Contract Execution](../pages/programming-model/execution.md) and [Storage Types](../pages/programming-model/storage-types.md) give the full contract-author model.
4. [How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved) explains the engine’s reservation machinery.

For a detailed mapping from Solidity to Stellar Thruput, see [EVM & Solidity](../pages/ecosystem/evm.md).

---

## EVM & Solidity

Source: <https://thruput.network/ecosystem/evm/>

Translate Solidity contract patterns into Stellar Thruput storage, calls, and authorization.

The contract lifecycle remains write, test, deploy, and call. The main differences are typed storage updates, the call runtime, and resource accounting. This page compares those mechanisms, not network performance.



## The Contract Lifecycle



| Task       | Stellar Thruput path                                                     |
| ---------- | ------------------------------------------------------------------------ |
| Write      | Rust with SDK storage handles and contract macros                        |
| Compile    | `thruput build` produces an RV32 artifact and contract-spec sidecars     |
| Deploy     | Fund the new contract’s storage and deploy with the CLI or wallet client |
| Initialize | Call an ordinary method, optionally atomically through `deploy --init`   |
| Call       | Use generated Rust or TypeScript bindings                                |
| Read       | Use a typed view through the public client or `thruput view`             |

Stellar Thruput entrypoints use 8-byte IDs and CXS arguments. Ethereum contract calls commonly use a 4-byte selector and ABI arguments; see [Ethereum transactions](https://ethereum.org/en/developers/docs/transactions/). Use bindings rather than constructing either encoding manually.

Stellar Thruput deployment addresses derive from the deployer, nonce, and code hash. This resembles `CREATE2` in allowing address prediction, but uses a different preimage. See [Contract artifacts and addresses](../pages/how-it-works/contracts.md).



## Mental Model Shifts

| Solidity / EVM pattern               | Stellar Thruput pattern                                                                                |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| Mapping of token balances            | `Map<ContractAddress, Balance>`                                                                        |
| Read-modify-write balance assignment | Checked or lazy relative balance changes                                                               |
| `require` or `revert`                | `ensure` or a typed contract exception                                                                 |
| `msg.sender`                         | `get_caller()`, the immediate caller                                                                   |
| Constructor                          | An ordinary initializer with a contract-defined guard                                                  |
| Solidity interface and ABI           | Shared Rust interface and generated contract spec                                                      |
| `view` / `pure`                      | Rust receiver choice does not enforce runtime read-only behavior; use the call’s read-only restriction |



## Execution Differences



### Reentrancy

An EVM external call can call back into a contract already on the stack; see [Solidity external calls](https://docs.soliditylang.org/en/latest/control-structures.html#external-function-calls).

Stellar Thruput rejects invocation of a contract already on the call stack. For A → B → A, the last call is rejected as reentrant. This runtime check is separate from snapshot isolation. Reads within a transaction can still observe its own earlier changes and successful child calls.

Use [recoverable calls](../pages/contracts/cross-contract-calls.md#error-handling) when the parent should inspect a child failure rather than propagate it.



### Ordering and MEV

Compatible arithmetic changes have the same merged value regardless of execution order. Conflicting operations do not all land together, and the proposer still selects transactions and conflict winners. This is not a guarantee that every application is free from ordering-dependent outcomes or MEV.



### Gas Limits and Gas Price Estimation

Ethereum transactions specify gas limits and fee parameters. Stellar Thruput gas meters execution but costs zero tokens, so no gas price estimation is needed. Gas usage still matters: the declared root limit consumes scheduling capacity, and exceeding it faults execution.

Unlocked native-token balances provide capacity; stored data requires separate deposits. See [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md).



### Nonce Management

Ethereum account transactions use a sequential nonce. Stellar Thruput replay protection uses an expiry-height and nonce pair, unique for the originating address. It need not increase sequentially. That permits independent transactions from one address without a sequential account counter.



### Integer Overflow/Underflow

`Balance` accepts nonnegative amounts. Its checked methods reject underflow or overflow during execution; lazy methods defer snapshot-bound checks to reservation. The runtime also enforces aggregate bounds across concurrent transactions.



### The `approve()` Race Condition

An absolute allowance replacement can grant new spending authority after the previous allowance has already been spent. The example Stellar Thruput token instead uses relative allowance adjustments. The caller requests an increase or decrease, not a replacement amount.

This does not remove the need to inspect outcomes or choose an authorization policy. See the [token implementation](../pages/guides/build-a-token.md#apply-supply-and-allowance-policy) for its exact allowance methods and exclusive-update option.



## Pattern Adaptations



### Balance Transfer

In a token implementation, use balance deltas:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution. The lazy credit skips a balance load and defers its bound check. Other changes and resource limits still determine whether complete transactions can land together.



### Access Control

Store an owner or role policy and check it before changing state:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Define `Error` with `#[contract_exception]`. A forwarding contract becomes the immediate caller; it does not inherit the original user’s identity. See [Authorization](../pages/how-it-works/authorization.md).



### Constructor and Initialization

Stellar Thruput does not invoke `initialize` automatically or make it once-only. Guard initialization in contract storage when required. The CLI’s [atomic initialization](../pages/cli/deploy-and-call.md#include-initialization) combines funding, deployment, and the initializer call.



### Events

Define events with `#[derive(Event)]`, mark filterable fields with `#[topic]`, and declare emitted types on the contract interface. See [Events](../pages/contracts/events.md) for the complete pattern and [Read events](../pages/typescript/events.md) for application queries.



[Build a token](../pages/guides/build-a-token.md) walks through the maintained ERC-20 implementation, including allowances, supply policy, events, and tests.



## What Doesn’t Exist

| EVM feature                               | Stellar Thruput approach                                    |
| ----------------------------------------- | ----------------------------------------------------------- |
| `msg.value`                               | Transfer tokens explicitly through their contract interface |
| `delegatecall` and proxy code replacement | Deploy a new immutable contract at a new address            |
| `selfdestruct`                            | No equivalent contract-removal operation                    |
| Solidity `receive` / `fallback` dispatch  | Use declared methods in the generated SDK dispatcher        |
| Storage-slot packing                      | Use typed storage paths                                     |

Block context and gas inspection do exist: `get_block_timepoint()`, `get_block_height()`, and `stats::gas_remaining()`. Artifact and transaction bounds are network constraints, not EVM limits; see [Contract artifacts](../pages/how-it-works/contracts.md).



## Next Steps

- [Contract quickstart](../pages/get-started/contract.md): build and deploy a counter
- [Build a token](../pages/guides/build-a-token.md): maintained token code and tests
- [Contract Execution](../pages/programming-model/execution.md): snapshots and deltas
- [Storage Types](../pages/programming-model/storage-types.md): choose a storage API

---

## Solana & Anchor

Source: <https://thruput.network/ecosystem/solana/>

Translate Solana account, storage, and CPI patterns into Stellar Thruput contracts.

Both ecosystems support Rust contract development. Stellar Thruput changes how a contract addresses state and how concurrent writes combine. The comparison below follows Solana’s [account model](https://solana.com/docs/core/accounts) and [CPI rules](https://solana.com/docs/core/cpi).



## Accounts vs. Storage

Solana state lives in accounts with an address, owner, lamport balance, and data. Instructions receive declared accounts; Anchor expresses their expected types and constraints.

Stellar Thruput stores typed fields under contract addresses. For example, a token implementation uses `Map<ContractAddress, Balance>` rather than receiving separate token-account objects for each balance. Contract code still checks caller authority and application rules.



## Access Lists vs. Type-Based Parallelism

Solana transactions declare account access before execution. The runtime uses read/write access to schedule work; transactions that contend for a writable account cannot execute together in that schedule.

Stellar Thruput discovers storage access during execution. Typed merge rules allow compatible changes to the same location to combine. Different map keys use separate locations, but other shared writes and storage-funding limits can still conflict.



## The Contract Lifecycle



### Writing

| Anchor concept                    | Stellar Thruput SDK concept                                                  |
| --------------------------------- | ---------------------------------------------------------------------------- |
| `#[program]`                      | `#[contract]` on an interface or implementation                              |
| Account-data structure            | Typed fields under `#[thruput_sdk::storage]`                                 |
| `#[derive(Accounts)]` constraints | Explicit argument and authorization checks; no caller-supplied account array |
| Initialization instruction        | Ordinary initializer, optionally called atomically with deployment           |



### Compiling

Solana programs compile to SBF. Stellar Thruput contracts compile to RV32 through:

```bash
thruput build
```

The build produces a deployable artifact and contract spec. Keep the generated toolchain and dependencies together.



### Deploying

Stellar Thruput deployment derives an address from the deployer, nonce, and code hash. This shares a PDA’s predictability, not its derivation or authorization model. See [Contract artifacts and addresses](../pages/how-it-works/contracts.md).



### Calling

Use a generated client for another contract:

```rust
let token = ERC20Client::new(&token_address);
token.transfer(&recipient, amount);
```

The receiver sees the calling contract as its immediate caller. [Cross-Contract Calls](../pages/contracts/cross-contract-calls.md) covers gas limits and recoverable errors.



## Mental Model Shifts

| Solana / Anchor pattern              | Stellar Thruput pattern                                          |
| ------------------------------------ | ---------------------------------------------------------------- |
| Per-user state account               | Often a `Map` entry under the contract                           |
| Serialized account data              | Typed storage handles                                            |
| Account-level write conflicts        | Storage-type merge rules, including compatible shared-key deltas |
| Rent-exempt storage balance          | Storage deposit backed by native tokens                          |
| Compute-unit budget                  | Gas limit, with no token fee for gas                             |
| Signer privileges passed through CPI | Immediate caller identity and explicit runtime auth tokens       |



## Account and Call Patterns



### Account Arrays and Validation

Stellar Thruput has no caller-supplied account array. That removes account-list construction, not authorization. Validate caller identities, contract addresses, amounts, and application conditions before applying changes.



### Rent and Account Lifecycle

Solana accounts hold a refundable minimum lamport balance for their storage. Stellar Thruput storage also requires funding: it locks native tokens according to the data’s type and size, and releases the deposit when data is deleted. The runtime accounts for it, but the owning address must have enough funds.



### Compute Unit Budgets

Stellar Thruput gas limits bound computation, including child calls. Gas costs zero tokens, but a root transaction’s declared limit consumes scheduling capacity. Account funding and execution bounds still matter. See [Compute, Capacity & Storage](../pages/how-it-works/storage-economics.md).



### PDA Seed Management

A PDA used only for per-user state often maps to a `Map` entry. A PDA used as an authority needs an authorization design as well; replacing its storage with a map does not reproduce its signing role.



### Signer Propagation in CPIs

Solana CPI passes existing signer and writable privileges to the callee. `invoke_signed` additionally supplies seeds when the calling program must authorize a PDA. Ordinary CPI does not always require signer seeds.

Stellar Thruput’s `get_caller()` returns the immediate calling contract, not the root signer. Use contract policy, allowances, or [typed auth tokens](../pages/how-it-works/authorization.md#auth-tokens-and-signedt) when authority must pass through several calls.



## Pattern Adaptations



### PDA State Accounts → Map Fields

```rust
#[thruput_sdk::storage]
pub struct Registry {
    user_states: Map<ContractAddress, Value<UserState>>,
}
```

`UserState` is your serializable application type. Access an entry with `at` or `at_mut`; first writes create storage and require its deposit. See [Storage Types](../pages/programming-model/storage-types.md).



### Token Transfer

Inside a token implementation:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let caller = get_caller();
    self.balances.at_mut(&caller).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

This updates the token’s own balance map. To transfer another contract’s token, call its generated client rather than writing its storage directly.



### Cross-Program Invocation → Cross-Contract Call

```rust
let token = ERC20Client::new(&token_address);
let result = token.try_mint(&recipient, amount);
```

The callee applies its own authorization policy. `try_mint` returns a `Result`; the direct `mint` method propagates failure. See [Handle errors](../pages/contracts/errors.md).



### Error Handling

Define errors with `#[contract_exception]` and check conditions with `ensure`:

```rust
ensure(get_caller() == self.owner.get(), Error::NotOwner);
```

Unlike signer-account validation, this checks the immediate contract caller. A failure aborts the frame and discards its contract effects.



## What Doesn’t Exist

Stellar Thruput does not use Solana account arrays, associated token accounts, PDA bump seeds, or account `space`/`realloc` arguments. It has its own contract-address, storage, and authorization models. These are pattern translations, not wire or tooling compatibility.



## Next Steps

- [Contract quickstart](../pages/get-started/contract.md): build and deploy a counter
- [Build a token](../pages/guides/build-a-token.md): token state and tests
- [Storage Types](../pages/programming-model/storage-types.md): map and balance APIs
- [Authorization](../pages/how-it-works/authorization.md): caller and auth-token rules

---

## Stellar & Soroban

Source: <https://thruput.network/ecosystem/stellar/>

Translate Stellar operations and Soroban contract patterns into Stellar Thruput applications.



## Who This Guide Is For

For Stellar developers, distinguish classic operations from Soroban contracts before comparing either with Stellar Thruput. Stellar Thruput exposes contract calls and typed storage; payment, trust, and exchange policy belongs in contracts.



## Mental Model Shifts

| Starting point                        | Stellar Thruput approach                              |
| ------------------------------------- | ----------------------------------------------------- |
| Classic payments and token operations | Call a token contract                                 |
| Account trustlines and asset policy   | Implement or select a contract’s authorization policy |
| Multiple classic operations           | Compose calls in one transaction                      |
| Built-in offers and path payments     | Use an application-defined exchange                   |
| Soroban storage get/set               | Choose typed storage operations and their merge rules |

These are design translations, not compatibility claims. Stellar Thruput does not automatically provide Stellar’s asset or trustline semantics.



## Pattern Translations



### 1. Simple Payments

Classic Stellar provides a payment operation. A Stellar Thruput token implementation updates typed balances:

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);
    self.balances.at_mut(receiver).lazy_increase(amount);
}
```

Here, `balances` is `Map<ContractAddress, Balance>`. The checked debit detects insufficient funds during execution; the lazy credit records a relative change. Compatible transactions can merge if aggregate bounds and their other changes permit it. See [Build a token](../pages/guides/build-a-token.md) for the complete implementation and events.



### 2. Multi-Operation Transactions

[Classic Stellar transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions) can bundle operations atomically. Soroban transactions contain a single smart-contract operation, which can invoke other contracts.

A Stellar Thruput transaction has one root invocation. That invocation can call several contracts. The native DefaultWallet and its SDK helpers also support [atomic typed call batches](../pages/typescript/transactions.md#execute-multiple-calls).

If the root aborts, its contract changes and successful child changes are discarded. A parent using recoverable calls can instead handle a child’s failure and continue. See [Invocation Frames](../pages/how-it-works/invocation-frames.md).



### 3. Market Making / Resting Orders

Stellar Thruput has no built-in order book. A contract can store orders by ID in a `Map`, or accept requests through a `RetrocausalQueue`.

Separate order IDs have independent storage locations. Changes to the same order follow its value type’s merge rules. A queue allows concurrent insertion and later ordered processing. Choose according to the venue’s matching and settlement rules.



### 4. DEX Trading / Swaps

Two designs are possible:

- **Synchronous calls:** execute a swap and return its result in one transaction. Reserve-dependent writes to the same pair can conflict.
- **Queued requests:** accept a request first, then process it in a later transaction. The client tracks a request ID through outcome events or stored state.

The maintained [AMM example](../pages/guides/build-an-amm.md) uses the queued design. Request acceptance is not proof that the swap completed. A synchronous result refers to execution within a transaction, not immediate network confirmation.



### 5. Account & Trust Management

A Stellar Thruput contract can store per-account policy in a map, but a stored trust flag has no effect unless the token or application checks it.

Use [caller checks and auth tokens](../pages/how-it-works/authorization.md) to enforce the policy. Use [account authorization](../pages/typescript/wallet-clients.md) for signatures that can originate transactions. These are separate responsibilities.



### 6. Soroban Smart Contracts

Both environments support Rust contracts, with different storage and authorization APIs:

| Soroban                                     | Stellar Thruput                                                                           |
| ------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `persistent().get/set`                      | Typed handles such as `Value<T>`, `Map<K, V>`, and `Balance`                              |
| Instance, Persistent, and Temporary storage | One persistent storage model with type-specific operations                                |
| Storage TTL and archival/restoration        | No storage TTL; funded data remains until deleted                                         |
| `require_auth()`                            | Immediate-caller checks or explicit runtime auth tokens, according to the contract policy |
| `#[contractimpl]`                           | `#[contract]` on a Rust interface or implementation                                       |
| Inclusion and resource fees                 | No conventional gas fees; native-token-backed scheduling and storage                      |

Soroban TTL expiry is not the same for every storage type: Temporary data is deleted, while Persistent and Instance entries are archived and can be restored. See [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival).

Stellar Thruput’s storage types determine which concurrent changes can combine. Use [Contract Execution](../pages/programming-model/execution.md) for snapshots and [Storage Types](../pages/programming-model/storage-types.md) for API choices.



## Pattern Summary

| Pattern                 | Design decision                                                         |
| ----------------------- | ----------------------------------------------------------------------- |
| Payments                | Select the token contract and its transfer policy                       |
| Resting orders          | Choose keyed storage, a queue, or both                                  |
| Trust and authorization | Store policy and enforce it on every relevant action                    |
| Swaps                   | Choose synchronous execution or accepted requests with later settlement |
| Client recovery         | Track transaction hashes and, for queued work, request outcomes         |



## What Doesn’t Change

Applications still need to validate amounts, choose the intended network, authorize writes, and inspect outcomes. A successful submission is not successful execution on either platform.



## Common Questions



### Q: Do I lose atomicity for multi-op transactions?

No. Calls can execute atomically inside one root transaction. A workflow split across several transactions, such as queue acceptance and later settlement, needs application-level outcome tracking.



### Q: When should I use a queued DEX model?

Use it when concurrent request submission and later processing fit the venue. Use a synchronous call when the caller needs the swap result during the same transaction.



### Q: Will my market making bot need major changes?

The venue determines that. A queued venue requires the bot to connect accepted request IDs with later outcomes. It must not treat a successful processing transaction as proof that every queued request succeeded.



## References

- [Stellar operations and transactions](https://developers.stellar.org/docs/learn/fundamentals/transactions/operations-and-transactions)
- [Stellar state archival](https://developers.stellar.org/docs/learn/fundamentals/contract-development/storage/state-archival)
- [Contract quickstart](../pages/get-started/contract.md)
- [Build a token](../pages/guides/build-a-token.md)
- [Build an AMM](../pages/guides/build-an-amm.md)

---

## For Backend Developers

Source: <https://thruput.network/start/for-backend-developers/>

Map your Postgres and database experience to Stellar Thruput's programming model.

Database snapshot isolation is a useful starting point for Stellar Thruput. Transactions share a committed block snapshot, but their writes follow typed storage merge rules rather than SQL conflict rules.



## Shared Snapshot

Every transaction in a block starts from the previous block’s committed state. Ordinary storage reads include its own changes and successful child calls, but not other transactions’ writes. `RetrocausalQueue` has separate rules for observing concurrent inserts. Each transaction produces typed changes, called **deltas**. Compatible deltas form the next committed state. See [Merged Deltas](../pages/programming-model/execution.md#merged-deltas).



## Deltas, Not Assignments

The core shift from a database: instead of `UPDATE accounts SET balance = 50`, you call `increase(5)`, meaning “adjust this value by +5.” This is `UPDATE accounts SET balance = balance + 5`. You express **how the value should change**, not what it should become.

```rust
fn transfer(&mut self, receiver: &ContractAddress, amount: Amount) {
    let sender = get_caller();
    self.balances.at_mut(&sender).decrease(amount);          // checked debit
    self.balances.at_mut(receiver).lazy_increase(amount);    // deferred bound check
}
```

[`Balance`](../pages/programming-model/storage-types.md#balance) is the SDK type for this pattern. Both calls record deltas that can merge with concurrent transactions. `decrease()` loads the sender’s balance so an insufficient debit fails during execution. `lazy_increase()` skips the receiver load and defers its bound check until the delta batch is reserved. If two transactions debit 20 and 30 from a balance of 100, both can land and the next balance is 50. Applying the changes in either order gives the same result, so the operations **commute**.

[NNInt and concurrent updates](../pages/programming-model/nnint.md) explains the representation behind these balance operations, including base matching and early bound checks.

**Relative updates such as `SET col = col + ?` map naturally to mergeable integer operations.** Compatibility still depends on bounds and the transaction’s other changes. Absolute replacements can conflict when they assign different values.

***



## Conflicts and Retries

When deltas conflict, the transaction is excluded and reported as `retry`. Contract code does not retry the operation. The client resubmits the same signed transaction until it commits or expires. It can commit at most once.

The balance constraint works the same way. If two concurrent withdrawals together exceed the available balance, one or more transactions are excluded. This is `CHECK (balance >= 0)` enforced by the storage model rather than application code.

***



## What’s Different From a Database

- **No ad-hoc queries.** Storage is key-value with typed values. You access data by key, not by query. An indexer provides query capabilities off-chain.
- **No JOINs.** If you need data from two Maps, you read both explicitly.
- **Deterministic execution.** Use block context rather than the host clock. Contract code cannot make HTTP calls or use the host’s random-number generator.
- **Storage deposits.** Stored data locks native tokens according to its type and size. Deleting the data returns the deposit.
- **No conventional gas fees.** Gas meters computation (prevents infinite loops) but no tokens are burned. Your unlocked native-token balance provides scheduling capacity under load. The declared gas limit determines how much capacity the transaction uses.

***



## Next Steps

For storage type details (`Balance`, `NNInt`, `Map`, `Vector`, `Value`, `Bytestring`, `CapacityConstraint`, and `RetrocausalQueue`) and their conflict semantics, see [Programming Model: Storage Types](../pages/programming-model/storage-types.md). For the contract-level execution model, see [Merged Deltas](../pages/programming-model/execution.md#merged-deltas).

Ready to write code? The [contract quickstart](../pages/get-started/contract.md) walks you through building and deploying your first contract.

---

## For Distributed Systems Developers

Source: <https://thruput.network/start/for-distributed-systems-developers/>

Understand Stellar Thruput's use of commutative updates within consensus blocks.

Stellar Thruput uses commutative operations to combine concurrent changes within a block. The storage model supports parallel execution; consensus selects the result validators commit.



## Your Head Start

Additions such as `+5` and `+3` have the same sum in either order. Stellar Thruput’s [`Balance`](../pages/programming-model/storage-types.md#balance) and [`NNInt`](../pages/programming-model/nnint.md) expose relative updates with explicit bounds. `Map<K, V>` gives separate keys independent storage locations.

The similarity to counters and maps in CRDT systems is useful, but the coordination model differs.



## Coordination at Block Boundaries

CRDTs can reconcile independently updated replicas. Stellar Thruput instead executes transactions against a common committed snapshot, reserves compatible typed changes, and uses [consensus](../pages/how-it-works/consensus.md) to select a finalized block.

- **Merge rules operate within a proposal.** Applications do not maintain vector clocks to reconcile ordinary balance or map updates.
- **Bounds still apply.** A balance cannot commit below zero. If concurrent debits exceed the available value, an overdrawing transaction is excluded and reported as `retry` for the client to resubmit.
- **Consensus selects one result.** Validators verify the proposed state transition. Nodes that have applied the same finalized block agree on that state.
- **Readers can see different heights.** A node may lag while receiving or replaying blocks. Check the returned read height when freshness matters.



## If You Don’t Know Any of This

You can write contracts without implementing a concurrency algorithm. Choose the storage type for the updates your application needs, then use its ordinary Rust methods. The [backend-developer guide](../pages/start/for-backend-developers.md) explains the same model through database concepts.



## Next Steps

- [Contract Execution](../pages/programming-model/execution.md): snapshots, deltas, and exclusion
- [Storage Types](../pages/programming-model/storage-types.md): data-model choices
- [How Conflicts Are Resolved](../pages/how-it-works/execution-model.md#how-conflicts-are-resolved): engine reservation details
- [Contract quickstart](../pages/get-started/contract.md): build and deploy a counter

---

## Thruput roadmap

Source: <https://thruput.network/architecture/roadmap/>

Candidate improvements, open questions, and ways to help shape Stellar Thruput.

These are candidate improvements to Stellar Thruput, roughly ordered by what they could unblock. The order is provisional. Scope and priorities can change as people build on Futurenet; there are no committed delivery dates.

Last reviewed: October 21, 2026.



## Proposed next work



### Block and transaction history

Public block queries and recoverable transaction feeds would let explorers and independent indexers discover chain activity without private infrastructure access. Block queries remain incomplete; the supported feed and its recovery contract still need qualification. Indexer requirements and tests for resuming after an outage would help.



### Contract failure diagnostics

Failures inside wallet or other nested contract calls can be difficult to locate. The goal is to preserve which call failed and provide more useful runtime fault details through the [public API](../pages/reference/json-rpc-api.md). Small contracts that reproduce difficult failures are useful contributions.



### State preserving upgrades

Supported upgrade paths and migration tooling would reduce the need to recreate applications after network changes. This work is deferred. Futurenet can still reset, as described in [Get Started](../pages/get-started.md). Upgrade fixtures, compatibility tests, and operator feedback would help define the supported paths.



### Sharded state storage

Partitioning state across multiple HogDB shards within each validator is the planned path for scaling state. This is not chain sharding: applications see one key space and never choose a shard. Each account’s state is owned by one shard, and execution routes reads and writes to the owning shard. Initial support is in review in the core engine. Cross-shard snapshot reads, protocol support for shard identity, and a two-phase block commit across shards still need to land. Large-state workloads and benchmarks across shard counts would help.



### Post-quantum signatures

Each address can register multiple keys, and authorization is abstracted over the signature scheme, so users can add or revoke keys without changing addresses. Ed25519 and ML-DSA-65 (FIPS 204) are supported. Validator key migration still needs design, and more schemes may follow as they are standardized. Threat-model, performance, and migration-design reviews would help.



## Exploring



### External calls

Contracts could call services outside the chain within one atomic transaction. While a call is pending, executors run other transactions. The proposer records the response in the block proposal, so other nodes replay it without making the call. Responses must be self-authenticating, and each call’s timeout is bounded by block time. This is not implemented. The contract API and protections against using the chain to flood other services still need design. Use cases such as market-maker quotes, on-demand oracle reads, and compliance checks would help shape it.



## Open to builders



### Additional storage types

Contracts use the [storage types](../pages/programming-model/storage-types.md) the SDK provides today. Earlier research prototypes also used ordered sets and bitmaps, and new types will follow developer demand. If an application is hard to express with the current types, describe the workload and where it conflicts.



### Ecosystem tooling

Wallet integrations, oracles, and application conventions are areas where builder demand can shape the work. The [wallet integration guide](../pages/tools/wallet-integration.md) is a starting point. Bring an integration or application that exposes a concrete need, and find related projects through the [GitHub community](https://github.com/thruputchain).
