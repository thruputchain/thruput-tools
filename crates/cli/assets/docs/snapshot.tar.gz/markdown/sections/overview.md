# Overview

Documentation source: `6ec960dc7192d06668b4db586ea0eace570f4270`.

Included standalone agent guide: CLI 0.19.0. This is not a version guarantee for every example. Hosted docs may be newer than this snapshot.

## Groundhog

Source: <https://docs.groundhog.dev/>

Build Groundhog contracts and applications with the Rust SDK, CLI, and TypeScript client.



The blockchain built for\
abundance
---------

Groundhog is an early technology preview of a blockchain designed from first principles. Build a contract, try the developer tools, and help shape what comes next.

## Use a coding agent

```text
Help me deploy my first Groundhog contract to Devnet. Follow https://docs.groundhog.dev/get-started/contract/ using the latest CLI. Read groundhog skill show and its contracts reference, and preserve the project settings it generates. If documentation access is blocked, ask me for a saved copy or use groundhog docs. Keep credentials and signing keys out of this conversation. Set up a funded Devnet wallet, create and test a counter, deploy it, initialize it to 10, increment by 5, and verify that its view returns 15. Do not start a local node. Report actual results and any setup or network errors.
```



## Programming model



01 / COMPUTE



### [Keep the logic on-chain](../pages/programming-model/execution.md)

Match orders, run an auction, or resolve a game turn alongside the assets it moves. Start with the rules your application needs.

Explore execution



02 / CAPACITY



### [Compute without gas fees](../pages/programming-model/execution.md#gas)

Gas meters execution but costs zero tokens. Hold HOG for capacity and fund storage deposits. Execution still has limits.

Understand capacity



03 / CONCURRENCY



### [Build on shared state](../pages/programming-model/storage-types.md)

Typed storage lets compatible changes merge while contracts execute in parallel. Use the SDK's balance and collection types.

Choose your storage



## Development resources



FIRST CONTRACT



### [Make something work](../pages/tutorials/build-a-counter.md)

Build and test a counter. Learn the contract loop before expanding your idea.



APPLICATIONS



### [Connect an interface](../pages/tutorials/work-with-groundhog-from-typescript.md)

Use generated TypeScript bindings to call your contract and read its results.



UNDER THE HOOD



### [Understand the engine](../pages/how-it-works/architecture.md)

Explore execution, consensus, and the storage model behind Groundhog.
