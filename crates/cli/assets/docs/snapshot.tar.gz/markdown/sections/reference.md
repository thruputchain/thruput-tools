# Reference

Documentation source: `186564d64f845490f9ea3fc1cfd6dd7bf9591c99`. Hosted docs may be newer than this snapshot.

## JSON-RPC API

Source: <https://thruput.network/reference/json-rpc-api/>

Project Thruput native JSON-RPC methods, wire types, and error codes for wire format 14.

| API property  | Value                                                                                                                                                                                            |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Wire format   | `14.x`. Tools `0.33.0` serves `14.0.0`; `14.1.0` adds `stated.maxTxGas` and the `gasLimitTooHigh` transaction detail                                                                             |
| Compatibility | Breaking wire changes increase the major version of `getVersionInfo.wireFormat`. Clients accept one major version and do not fall back                                                           |
| Schema        | [Generated OpenRPC specification](https://github.com/thruputchain/thruput-tools/blob/main/crates/json-rpc/open-rpc-spec/snapshots/thruput-spec.json) for exact method signatures and field types |
| Transport     | JSON-RPC 2.0 over HTTP. For the node topology, see [Networking](../pages/how-it-works/networking.md)                                                                                             |



## Request Format

```json
{
  "jsonrpc": "2.0",
  "method": "getTransactionStatus",
  "params": { "transactionHash": "<base58 transaction hash>" },
  "id": 1
}
```

| Request rule         | Contract                                                                                                                                    |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| Parameter shape      | One named-parameter object. Positional arrays, wrapped objects, and unknown fields return `-32602`                                          |
| No-parameter methods | Accept `{}`, `[]`, `null`, or omitted `params`; clients send `{}`                                                                           |
| Method names         | Unprefixed core names. Optional groups use `faucet_` and `dev_` prefixes                                                                    |
| Discovery            | `getVersionInfo.supportedMethods` lists the methods that this endpoint registered. An unlisted method returns `Method not found` (`-32601`) |
| Field names          | camelCase in requests, responses, and error data                                                                                            |



## Value Encoding

| Value                                                                                                                                                     | JSON encoding                                                                                                                                                                        |
| --------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Addresses, transaction hashes, block and network hashes, config hashes, public keys, public-key hashes, validator IDs                                     | Unprefixed, case-sensitive base58 (Bitcoin/Solana alphabet). Must decode to exactly 32 bytes. `0x` hex is rejected                                                                   |
| Signed transactions, calldata, entrypoints, return and abort data, storage keys and bytes, event topics and data, cursors, client nonces, upgrade entries | `0x`-prefixed lowercase hex with an even number of digits                                                                                                                            |
| 64-bit and wider integers: heights, nanosecond timestamps, gas, counts, balances, amounts                                                                 | Canonical decimal string, including `"0"`                                                                                                                                            |
| Smaller bounded integers: protocol versions, page limits, event sequence numbers, key IDs, weights                                                        | JSON number                                                                                                                                                                          |
| Encoding choice                                                                                                                                           | By field meaning, not byte length. A raw event topic stays hex even when its decoded value is an address or hash                                                                     |
| Decimal string rejects                                                                                                                                    | Numeric JSON, leading zeros, `+`, negative zero, whitespace, fractions, exponents, overflow                                                                                          |
| Binary payloads                                                                                                                                           | Transactions use classic XDR; contract arguments and return values use CXS. See [XDR Protocol](../pages/reference/xdr-protocol.md)                                                   |
| Tagged unions                                                                                                                                             | Discriminator field such as `status`, `result`, `kind`, or `attemptStatus`. Accept unknown tag values (for example `other` or `unknown`) without treating them as success or absence |



## JSON-RPC Arrays

| Property        | Contract                                                                                                                                  |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| Maximum entries | 1,000 per array on the gateway and local node                                                                                             |
| Correlation     | Match responses by request ID; response order is not execution order                                                                      |
| Errors          | Per-entry RPC errors remain independent; transport failures can affect the shared exchange                                                |
| Guarantees      | No shared snapshot, ordering, or atomicity between independent requests                                                                   |
| Other limits    | Request and response byte limits and concurrency settings are separate                                                                    |
| Client defaults | Opt-in HTTP batching uses 100 entries and a 0ms scheduling window; see [client transport](../pages/typescript/transport.md#http-batching) |



## Discovery Methods



### `getVersionInfo`

**Parameters:** None.

| Response field                                                            | Contract                                                                              |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| `wireFormat`                                                              | Wire-format SemVer, for example `"14.1.0"`. The only field that selects client codecs |
| `supportedMethods`                                                        | Sorted names of the methods registered on this endpoint                               |
| `implementation`                                                          | Diagnostic implementation version                                                     |
| `commitHash`, `platformVersion`, `releaseVersion`, `bundleManifestDigest` | Optional diagnostics; omitted when unavailable                                        |



### `getNetworkInfo`

**Parameters:** None.

```json
{ "networkHash": "<base58, 32 bytes>" }
```

`networkHash` is the signing network identity. It is part of every transaction signature preimage. Compare it with the expected network before signing. See [Authorization](../pages/how-it-works/authorization.md).



### `getServerLimits`

**Parameters:** None. Answered without contacting a backend.

| Response field               | Contract                                                                                                                          |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| `maxSimulationGas`           | Maximum simulation `gasLimit`, and the default when `gasLimit` is omitted; decimal string                                         |
| `maxSimulationCalldataBytes` | Maximum simulation calldata size in bytes; decimal string                                                                         |
| `maxEventsPerPage`           | Maximum `getEvents` `limit`; JSON number                                                                                          |
| `maxTransactionsPerPage`     | Maximum transaction-page `limit`; JSON number                                                                                     |
| `maxCursorBytes`             | Maximum decoded cursor size in bytes; decimal string                                                                              |
| `simulationBatch`            | Optional: `maxInvocations`, `maxCalldataBytes`, `maxBackendResponseBytes` (JSON numbers), `maxGas`, `timeoutMs` (decimal strings) |

These are operator settings, not consensus parameters. Values can differ between endpoints on the same chain.



### `getChainTip`

**Parameters:** None.

```json
{ "blockHeight": "42", "blockHash": "<base58 block hash>" }
```



### `getChainConfig`

**Parameters:** None.

| Response field              | Contract                                                                                                                                                                                                                                                    |
| --------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `stated`                    | Explicit configuration values. A missing field is unspecified, not zero                                                                                                                                                                                     |
| `stated.max*`               | `maxSha256Buffers`, `maxCrossInvokeDepth`, `maxNewContractsPerTx`, `maxBytestringLen`, `maxContractSizeBytes`, `maxSavepointDepth`, `maxAuthTokenDepth`, `maxRv32CodeBytes`, `maxRv32MemoryBytes`: JSON numbers. `maxTxGas` (wire `14.1.0`): decimal string |
| `execution`                 | Optional authoritative reading. A missing `execution` means the backend cannot supply it; do not infer zero prices                                                                                                                                          |
| `execution.observedTip`     | `blockHeight` and `blockHash` that the rules were read with                                                                                                                                                                                                 |
| `execution.configHash`      | Base58 configuration and storage-model commitment                                                                                                                                                                                                           |
| `execution.effectiveLimits` | Runtime-resolved limits, same fields as `stated`                                                                                                                                                                                                            |
| `execution.storageCosts`    | `baseDataItemCost`, `bytestringCostPerByte`, `baseContractDeploymentCost`, `contractDeploymentCostPerByte`, `authPerKeyCost`, `rcqCostPerEntry`, `replayCacheCostPerEntry`, `balanceCost`: native-token base units as decimal strings                       |

Later transactions can execute under newer rules. Usage: [Estimate deployment funding](../pages/cli/deploy-and-call.md#estimate-deployment-funding).



## Transaction Methods



### `sendTransaction`

| Parameter           | Type | Description                             |
| ------------------- | ---- | --------------------------------------- |
| `signedTransaction` | hex  | `0x` hex of the `SignedTransaction` XDR |

```json
{ "transactionHash": "<base58 transaction hash>", "admission": "accepted" }
```

| Case                 | Contract                                                                                                                                                                                                                     |
| -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Success              | Scheduler admission only, not commitment or execution                                                                                                                                                                        |
| `transactionHash`    | `sha256` of the inner `Transaction` XDR; excludes signatures                                                                                                                                                                 |
| `-32000`             | Invalid encoding, envelope, size, or executor bound. `data.detail.reason` can be `tooManyContracts`, `contractTooLarge`, `duplicateContract`, `rv32MemoryTooLarge`, `rv32CodeTooLarge`, or `gasLimitTooHigh` (wire `14.1.0`) |
| `-32001`             | `data.reason` is `expired` (`blockExpiryHeight` at or below the tip) or `authenticationRejected`                                                                                                                             |
| `data.admission`     | `notAttempted`, `rejected`, or `unknown` for this attempt                                                                                                                                                                    |
| `-32051` or `-32050` | Admission can be unknown. Query `getTransactionStatus` with the hash before you prepare a replacement                                                                                                                        |
| `-32053`             | Retryable refusal; optional `data.retryAfterMs`                                                                                                                                                                              |



### `getTransactionStatus`

| Parameter         | Type   | Description      |
| ----------------- | ------ | ---------------- |
| `transactionHash` | base58 | Transaction hash |

| `status`        | Fields and meaning                                                                                                                                                                                                                                                                                                                       |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pending`       | In the scheduler, not committed. Optional `recentFailure`                                                                                                                                                                                                                                                                                |
| `committed`     | `blockHeight` of the block that included it, including `"0"`                                                                                                                                                                                                                                                                             |
| `retry`         | Scheduler processing failed; `error`; optional `recentFailure`. Resubmitting the same signed transaction can succeed                                                                                                                                                                                                                     |
| `dropped`       | Permanent scheduler failure; `error`; optional `recentFailure`. `error` tells you if a change is needed. After a drop for insufficient native tokens (`SchedulerErrorInsufficientNativeTokens`), fund the sender and resubmit the same signed transaction before it expires. For other drops, change the transaction before you resubmit |
| `recentFailure` | Scheduler miss with a recent indexed failure: `attemptBlockHeight`, `cause`                                                                                                                                                                                                                                                              |
| `unknown`       | Both the scheduler and committed history reported a miss                                                                                                                                                                                                                                                                                 |
| `other`         | Status from a newer server version                                                                                                                                                                                                                                                                                                       |

| Field           | Contract                                                                                                            |
| --------------- | ------------------------------------------------------------------------------------------------------------------- |
| `error.source`  | `auth`, `scheduler`, `executor`, or `other`                                                                         |
| `error.code`    | Signed 32-bit JSON number from `AuthErrorCode`, `SchedulerErrorCode`, or `ExecResult`                               |
| `recentFailure` | Advisory `{ attemptBlockHeight, cause }`. It can describe a different attempt. It does not authorize resubmission   |
| `cause.kind`    | `dbConflict` with `conflict { address, key, code }`, `contractRejected` with `contractIndex` and `code`, or `other` |

Indexed commitment takes priority. No status proves nonexecution, and a failed backend lookup returns an error, not `unknown`. Usage: [Handle scheduler processing errors](../pages/typescript/transaction-status.md#handle-scheduler-processing-errors).



### `getTransactionReceipt`

| Parameter         | Type   | Description      |
| ----------------- | ------ | ---------------- |
| `transactionHash` | base58 | Transaction hash |

**Returns:** `TransactionReceipt`, or `null` if no receipt is available.

```json
{
  "transactionHash": "<base58 transaction hash>",
  "blockHeight": "12345",
  "execution": { "result": "return", "returnData": "0x42" },
  "events": [],
  "gasUsed": "1500"
}
```

| `execution.result`      | Meaning                                                       |
| ----------------------- | ------------------------------------------------------------- |
| `return`                | Root call returned; `returnData` is required, possibly `"0x"` |
| `abort`                 | Root call aborted; `abortData` is required, possibly `"0x"`   |
| `fault`                 | Deterministic execution fault                                 |
| `nonDeterministicError` | Proposal-time storage conflict or race                        |
| `failedGasSponsorship`  | Gas sponsorship failed                                        |
| `other`                 | Result from a newer server version                            |

A receipt proves commitment. Only `execution.result: "return"` proves successful execution. `gasUsed` is metered work, not a fee: gas has no token cost and no refund.



## State Methods



### `getBalance`

| Parameter | Type   | Description                 |
| --------- | ------ | --------------------------- |
| `address` | base58 | Account or contract address |

```json
{ "address": "<base58 address>", "stateBlockHeight": "4567", "rawBalance": "1000000000" }
```

`rawBalance` is free native-token base units as a decimal string. Storage collateral is separate.



### `getStorage`

| Parameter | Type   | Description            |
| --------- | ------ | ---------------------- |
| `address` | base58 | Contract address       |
| `key`     | hex    | Serialized storage key |

```json
{ "stateBlockHeight": "4567", "item": { "kind": "nonnegativeInt", "value": "1000000000" } }
```

| `item.kind`                                        | Fields                                            |
| -------------------------------------------------- | ------------------------------------------------- |
| `nonnegativeInt`                                   | `value`: decimal string                           |
| `bytestring`                                       | `bytes`: hex                                      |
| `deployedContract`                                 | `hash` (base58), `size`, `contractType`           |
| `authData`, `retrocausalQueue`, `replayCacheEntry` | None                                              |
| `unknown`                                          | `typeId` for a storage kind newer than the client |

`item` is `null` when the key has no value. `stateBlockHeight` names the snapshot for both cases.



### `getRegisteredAuth`

| Parameter | Type   | Description     |
| --------- | ------ | --------------- |
| `address` | base58 | Account address |

| Response field                | Contract                                                                                                                        |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `address`, `stateBlockHeight` | Echoed address and snapshot height                                                                                              |
| `configuration`               | `null`, or `{ signers, requiredWeight }`                                                                                        |
| `signers[]`                   | `keyId`, `maxWeight`, and `publicKey`: `{ "scheme": "ed25519", "key": "<base58>" }` or `{ "scheme": "unknown", "schemeId": n }` |

`null` does not prove that the account is absent. It does not recover the key of a pubkey-derived account.



## Simulation Methods



### `simulateInvocation`

| Parameter             | Type           | Description                                                                   |
| --------------------- | -------------- | ----------------------------------------------------------------------------- |
| `address`             | base58         | Contract address                                                              |
| `entrypoint`          | hex            | 8-byte entrypoint ID                                                          |
| `calldata`            | hex            | Call input                                                                    |
| `caller`              | base58         | Optional parent contract                                                      |
| `assumedAuth`         | object         | Optional assumed claim; see below                                             |
| `gasLimit`            | decimal string | Optional, positive, at most `maxSimulationGas`; omission selects that maximum |
| `minStateBlockHeight` | decimal string | Optional freshness floor; not a historical selector                           |

| `assumedAuth.kind` | Fields                                                                           |
| ------------------ | -------------------------------------------------------------------------------- |
| `sourceAddress`    | `allowedKeys`, `requiredWeight`: JSON numbers                                    |
| `pubkeySignature`  | `pubkeyHash` (base58), `accountNonce` (decimal string; account derivation nonce) |

No signature is verified. Contract checks still run, and writes never commit. Omission supplies a zero-key, zero-weight source-address claim.

| Response field or case               | Contract                                                                                                 |
| ------------------------------------ | -------------------------------------------------------------------------------------------------------- |
| `stateBlockHeight`                   | Committed state height H. Execution uses context H+1                                                     |
| `output`                             | `{ "result": "return", "returnData" }`, `{ "result": "abort", "abortData" }`, or `{ "result": "fault" }` |
| `events`                             | Events emitted during the simulation                                                                     |
| `gasUsed`                            | Decimal string. Equals the selected limit on an out-of-gas fault                                         |
| Snapshot below `minStateBlockHeight` | `-32012` with `requestedStateBlockHeight` and `observedStateBlockHeight`; no wait or refresh             |



### `simulateInvocations`

| Parameter             | Contract                                                                                                               |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `invocations`         | Nonempty array. Each entry takes `address`, `entrypoint`, `calldata`, and optional `caller`, `assumedAuth`, `gasLimit` |
| `minStateBlockHeight` | Optional floor for the whole group. A per-entry floor is rejected                                                      |

| Response field or case       | Contract                                                                           |
| ---------------------------- | ---------------------------------------------------------------------------------- |
| `stateBlockHeight`           | One snapshot height for all invocations                                            |
| `results`                    | One `{ output, events, gasUsed }` per invocation, in input order                   |
| Isolation                    | Invocations do not see each other’s simulated writes                               |
| Abort or fault               | Per-invocation outcome, not a group failure                                        |
| Limits                       | `getServerLimits.simulationBatch` plus per-call limits; violations return `-32602` |
| Snapshot failure or deadline | The group fails; no partial results. Backend work can outlive the deadline         |

Usage: [Read related values from one snapshot](../pages/typescript/reads.md#read-related-values-from-one-snapshot).



## History Methods



### `getEvents`

| Parameter             | Type         | Description                                                                                                                                  |
| --------------------- | ------------ | -------------------------------------------------------------------------------------------------------------------------------------------- |
| `filters`             | array        | 1 to 5 filters. OR across filters                                                                                                            |
| `filters[].addresses` | base58 array | 1 to 5 contract addresses                                                                                                                    |
| `filters[].topics`    | object       | Optional `topic0`, `topic1`, `topic2`: up to 16 32-byte hex values each. AND across positions, OR within one. Omitted or empty is a wildcard |
| `start`               | object       | First page only; see [Pagination](../pages/reference/json-rpc-api.md#pagination)                                                             |
| `cursor`              | hex          | Later pages only                                                                                                                             |
| `limit`               | number       | Optional page size                                                                                                                           |

**Returns:** `EventPage`.

| Field                                                  | Contract                                                        |
| ------------------------------------------------------ | --------------------------------------------------------------- |
| `events[]`                                             | `{ transactionHash, blockHeight, sequenceNumber, event }`       |
| `event`                                                | `address` (base58), `topics` (up to 3 hex values), `data` (hex) |
| `nextCursor`                                           | Hex, or `null` when the walk is complete                        |
| `oldestIndexedBlockHeight`, `latestIndexedBlockHeight` | Serving bounds as decimal strings; not checkpoints              |

Event identity is `transactionHash` plus `sequenceNumber`. Usage: [Read events](../pages/typescript/events.md#query-events).



### `getTransactionsByRootAddress`

| Parameter                  | Type   | Description                                                     |
| -------------------------- | ------ | --------------------------------------------------------------- |
| `address`                  | base58 | Root invocation target                                          |
| `start`, `cursor`, `limit` |        | See [Pagination](../pages/reference/json-rpc-api.md#pagination) |

**Returns:** `TransactionRefPage` with `transactions[]` of `{ transactionHash, blockHeight }`, plus `nextCursor` and the serving bounds. Internal calls and incoming transfers do not match. Hydrate a reference with `getTransactionReceipt`.



### `getBlockByHeight`

| Parameter     | Type           | Description              |
| ------------- | -------------- | ------------------------ |
| `blockHeight` | decimal string | Nonnegative block height |

**Returns:** `BlockInfo`, or `null` outside indexed coverage (including genesis).

```json
{
  "blockHash": "<base58>",
  "protocol": 1,
  "networkHash": "<base58>",
  "configHash": "<base58>",
  "proposer": "<base58 validator ID>",
  "blockTimepoint": "1791200000000000001",
  "blockHeight": "42",
  "txsHash": "<base58>",
  "storageHash": "<base58>",
  "eventsHash": "<base58>",
  "prevBlockHash": "<base58>",
  "proposalTxsHash": "<base58>",
  "upgrades": ["0x..."]
}
```

An unavailable or corrupt index returns an error, not `null`. The index can lag behind `getChainTip`.



### `getTransactionsByBlock`

| Parameter         | Type           | Description                                                                |
| ----------------- | -------------- | -------------------------------------------------------------------------- |
| `blockHeight`     | decimal string | Committed block height                                                     |
| `start`           | object         | First page only: `{ "order": "ascending" }` or `{ "order": "descending" }` |
| `cursor`, `limit` |                | See [Pagination](../pages/reference/json-rpc-api.md#pagination)            |

**Returns:** `TransactionRefPage`. References are ordered by unsigned transaction-hash bytes, not execution order. An empty page does not prove that the block exists; use `getBlockByHeight`.



## Pagination

| Rule                      | Contract                                                                                                                                                                                                    |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| First page                | Send `start` and no `cursor`                                                                                                                                                                                |
| `start` for range history | `{ "order": "ascending", "anchor": { "kind": "atBeginning" } }`, `{ "order": "descending", "anchor": { "kind": "atEnd" } }`, or either order with `{ "kind": "atHeight", "blockHeight": "42" }` (inclusive) |
| Later pages               | Send the returned `cursor` verbatim with the same query fields and no `start`. The cursor owns direction and its snapshot bound                                                                             |
| `start` and `cursor`      | Exactly one is required                                                                                                                                                                                     |
| `limit`                   | Omission selects the smaller of 50 and the page cap. `0` or values above the cap return `-32602`. The cap is at most 200                                                                                    |
| Completion                | `nextCursor: null`. An empty page with a non-null cursor is not the end                                                                                                                                     |
| Invalid cursor            | Empty or oversized cursors return `-32602`. Rejected tokens return `-32602` with `data.kind: "invalidCursor"` and `reason` `malformed`, `unsupportedVersion`, or `queryMismatch`                            |
| Retention                 | `-32013` with `reason: "outsideRetention"` and optional indexed bounds                                                                                                                                      |
| Subscriptions             | A walk does not follow new blocks. Start a new walk to check for new activity                                                                                                                               |

For an application pattern, see [Resume without missing events](../pages/typescript/events.md#resume-without-missing-events).



## Optional Methods

These methods appear in `supportedMethods` only when the endpoint configures them.



### `faucet_requestAirdrop`

| Parameter     | Type   | Description                        |
| ------------- | ------ | ---------------------------------- |
| `recipient`   | base58 | Recipient address                  |
| `clientNonce` | hex    | Caller-selected 1-to-32-byte nonce |

| `attemptStatus` | Fields                                                                                                        |
| --------------- | ------------------------------------------------------------------------------------------------------------- |
| `pending`       | `recipient`, `rawAmount`, `retryAfterSeconds`, optional `transactionHash`                                     |
| `succeeded`     | `recipient`, `rawAmount`, `transactionHash`, `blockHeight`, `execution: { "result": "return", "returnData" }` |

Each call advances one attempt bound to `recipient` and `clientNonce`. Do not repeat it automatically. Poll a returned `transactionHash` with `getTransactionStatus` and `getTransactionReceipt`. `pending` does not prove admission. `-32030` means the faucet stopped the attempt; it does not prove nonexecution.



### `dev_fundAccount`

Local node only.

| Parameter     | Type           | Description                   |
| ------------- | -------------- | ----------------------------- |
| `recipient`   | base58         | Recipient address             |
| `rawAmount`   | decimal string | Positive amount in base units |
| `clientNonce` | hex            | 1-to-32-byte nonce            |
| `faucet`      | base58         | Expected local faucet address |

**Returns:** `{ recipient, rawAmount, transactionHash, signedTransaction }`. Check the receipt before you treat the transfer as successful. `-32031` means signed evidence exists without a resolved outcome. Retry with the same request.



### `dev_getPendingTransactionCount`

Local node only. **Parameters:** None. **Returns:** `{ "count": "0" }`, the local scheduler’s pending count as a decimal string.



## Method Availability

| Methods                                                                                                            | Registered when the endpoint has     |
| ------------------------------------------------------------------------------------------------------------------ | ------------------------------------ |
| `getVersionInfo`, `getNetworkInfo`, `getServerLimits`                                                              | Always                               |
| `sendTransaction`                                                                                                  | Scheduler                            |
| `getTransactionStatus`                                                                                             | Scheduler and indexer                |
| `getTransactionReceipt`, `getEvents`, `getTransactionsByRootAddress`, `getBlockByHeight`, `getTransactionsByBlock` | Indexer                              |
| `getChainTip`, `getChainConfig`, `getBalance`, `getStorage`, `getRegisteredAuth`                                   | State database                       |
| `simulateInvocation`, `simulateInvocations`                                                                        | Simulation backend                   |
| `faucet_requestAirdrop`                                                                                            | Hosted faucet, or local node funding |
| `dev_fundAccount`                                                                                                  | Local node funding                   |
| `dev_getPendingTransactionCount`                                                                                   | Local node only                      |

A configured backend that is down returns a backend error. It does not remove the method.



## Error Codes

Standard JSON-RPC 2.0 errors also apply, including `-32601` for unregistered methods. Error `data` carries a `kind` discriminator in camelCase.

| Code     | `data.kind`                      | Meaning                                                                                |
| -------- | -------------------------------- | -------------------------------------------------------------------------------------- |
| `-32602` | `invalidParams`, `invalidCursor` | Invalid named request or continuation token; optional `reason` and JSON-pointer `path` |
| `-32000` | `transactionInvalid`             | Invalid transaction framing, envelope, or executor bound                               |
| `-32001` | `transactionRejected`            | Expiry or scheduler authentication refusal for this attempt                            |
| `-32012` | `stateHeightUnavailable`         | Simulation snapshot below the requested floor                                          |
| `-32013` | `historyUnavailable`             | Required history cannot be served                                                      |
| `-32030` | `fundingAttemptStopped`          | Funding service stopped this attempt                                                   |
| `-32031` | `localFundingUnresolved`         | Local funding has signed evidence without a resolved outcome                           |
| `-32050` | `backendUnavailable`             | Required backend is unavailable                                                        |
| `-32051` | `backendTimeout`                 | Deadline exceeded; writes may have been dispatched                                     |
| `-32053` | `overloaded`                     | Temporary refusal; retry with backoff                                                  |
| `-32054` | `backendDataInvalid`             | Backend data cannot satisfy the method contract                                        |



## Client Libraries

| Language   | Package                                    | Wire selection                                                                                                         |
| ---------- | ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- |
| TypeScript | `@thruputchain/client` `0.24`              | Calls `getVersionInfo` once at connect and requires major `14`. See [TypeScript SDK](../pages/tools/typescript-sdk.md) |
| Rust       | `thruput-json-rpc-client` (`NativeClient`) | `thruput-client`’s `check_endpoint` requires major `14` and the methods you name                                       |



## Related Documentation

- [Networking](../pages/how-it-works/networking.md)
- [Authorization](../pages/how-it-works/authorization.md)
- [Transaction Lifecycle](../pages/how-it-works/transaction-lifecycle.md)
- [Storage Types](../pages/reference/storage-types.md)

---

## Contract Spec

Source: <https://thruput.network/reference/contract-spec/>

Canonical contract metadata, structured identities, methods, types, events, and exceptions.

For usage, see [TypeScript Bindings](../pages/tools/typescript-bindings.md) and [Build a Counter](../pages/tutorials/build-a-counter.md).



## Where the Spec Lives

| Artifact            | Purpose                                                                                                                  |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| `<crate>.spec.xdr`  | Canonical contract API, consumed by standalone TypeScript codegen                                                        |
| `<crate>.spec.json` | Human-readable rendering for inspection; not the codegen input                                                           |
| `<crate>.rv32a`     | Deployable RV32 artifact                                                                                                 |
| Generation          | SDK macros emit fragments; build canonicalizes, sorts, validates, and writes sidecars under `target/thruput/` by default |



## Top-Level Structure

| JSON key     | Contents                                                          |
| ------------ | ----------------------------------------------------------------- |
| `format`     | `gh_contract_spec_v1`, the inspection-rendering tag               |
| `interfaces` | Exported interfaces, methods, and declared exceptions             |
| `type_defs`  | Reachable named type layouts                                      |
| `events`     | Declared event identities, signatures, topics, and payload fields |



## Structured Identity

| Identity field        | Meaning                                                                                                             |
| --------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `crate`               | Declaring crate in the JSON rendering (`crate_name` in the canonical type)                                          |
| `major`               | Compatibility major, such as `1`, `0.1`, or `0.0.2`                                                                 |
| `module_path`         | Module within that crate                                                                                            |
| `declared`            | Declaration name                                                                                                    |
| Used by               | Named type references, type definitions, and event names                                                            |
| TypeScript projection | Crate, compatibility-major namespace, module path, then declaration; interface methods use interface name and major |

The compatibility major is the leftmost non-zero SemVer component. Use canonical IDs and generated descriptors; short declaration names are not globally unique.



## Interfaces

| Field                | Meaning                                                                                                                                                                                                                               |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `name`               | Interface name from the trait, inherent self type, or explicit override                                                                                                                                                               |
| `version`            | Full interface version                                                                                                                                                                                                                |
| `throws`             | Declared exception selectors and types                                                                                                                                                                                                |
| `methods`            | Exported methods in canonical order                                                                                                                                                                                                   |
| Method `name`        | ABI name                                                                                                                                                                                                                              |
| Method `args`        | Ordered fields with `name` and `type`                                                                                                                                                                                                 |
| Method `return_type` | Contract type of the result                                                                                                                                                                                                           |
| Entrypoint ID        | Derived from interface name, compatibility major, and method name: `SHA256("<name>::<major>::<method>")[0..8]`. Not a JSON field                                                                                                      |
| Method `effect`      | Optional author-declared effect: `pure`, `readOnly`, or `stateChanging`, set with `#[contract(effect = "...")]`. Omitted when the method has no declaration. It is not a runtime guarantee. Do not assume read-only when it is absent |



## Type Encoding

| `kind`                                                     | Other JSON fields    | Meaning                                     |
| ---------------------------------------------------------- | -------------------- | ------------------------------------------- |
| `void`, `bool`, `u8`                                       | None                 | Unit, boolean, or byte                      |
| `u32`, `i32`, `u64`, `i64`, `u128`, `i128`, `u256`, `i256` | None                 | Corresponding integer                       |
| `string`, `bytes`, `address`                               | None                 | String, variable bytes, or contract address |
| `option`                                                   | `inner`              | Optional value                              |
| `vec`                                                      | `element`, `max_len` | Variable-length sequence                    |
| `array`                                                    | `element`, `len`     | Fixed-length sequence                       |
| `tuple`                                                    | `items`              | Ordered element types                       |
| `named`                                                    | `name`               | Structured identity of a named type         |
| `signed_token`                                             | `preimage`           | Payload type, or null when erased           |

Contract arguments, results, and exception payloads use CXS. The spec sidecar uses its canonical XDR encoding. JSON is the inspection projection, not either binary encoding.



## Type Definitions

| Kind                | Fields beyond structured `name`                      |
| ------------------- | ---------------------------------------------------- |
| `struct`            | `fields`, each with name/type                        |
| `enum`              | `variants`, each with name/value                     |
| `union`             | `cases`, each with name, discriminant, and case_type |
| Union case `void`   | No payload                                           |
| Union case `tuple`  | `items`                                              |
| Union case `struct` | `fields`                                             |



## Events

| Field       | Meaning                                                                                        |
| ----------- | ---------------------------------------------------------------------------------------------- |
| `name`      | Structured event identity                                                                      |
| `signature` | 32-byte event signature rendered as hex; topic 0 for derived events                            |
| `topics`    | User topic fields and their types                                                              |
| `fields`    | CXS payload fields and their types                                                             |
| Limits      | At most three topics including signature; 1,024 bytes for topics plus payload                  |
| Discovery   | Events must be declared by the interface or explicitly exported through supported SDK metadata |

Use the generated signature rather than copying a literal from another contract. See [Events](../pages/contracts/events.md) for emission and [Read events](../pages/typescript/events.md) for filtering and restart.



## Errors

| Field or case        | Meaning                                                                                  |
| -------------------- | ---------------------------------------------------------------------------------------- |
| Exception `selector` | Hex rendering of its 64-bit selector                                                     |
| Exception `type`     | Payload type, potentially a structured named reference                                   |
| Known selector       | Generated decoder interprets the declared payload and rejects trailing bytes             |
| Unknown selector     | Client preserves selector and raw abort bytes                                            |
| Runtime fault        | May have no contract exception payload; do not infer a child ABI from root failure bytes |



## Related Documentation

- [SDK Macros](../pages/reference/sdk-macros.md)
- [TypeScript Bindings](../pages/tools/typescript-bindings.md)
- [XDR Protocol](../pages/reference/xdr-protocol.md)

---

## XDR Protocol

Source: <https://thruput.network/reference/xdr-protocol/>

Encoding boundaries and source definitions for the Project Thruput protocol.



## Encodings

| Surface                                                                      | Encoding                                                                                    | Reference                                                                                                          |
| ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| `Transaction`, `SignedTransaction`, contract spec sidecars                   | Classic XDR                                                                                 | Protocol definitions below                                                                                         |
| Contract arguments, return values, exceptions, typed storage, event payloads | CXS, the compact encoding used by the SDK                                                   | [Contract Spec](../pages/reference/contract-spec.md), [TypeScript Bindings](../pages/tools/typescript-bindings.md) |
| Transaction signing preimage                                                 | CXS domain separator, raw network hash, then classic XDR transaction                        | [Authorization](../pages/how-it-works/authorization.md)                                                            |
| Public JSON-RPC requests and responses                                       | JSON, with base58 identifiers, `0x` hex byte fields, and decimal strings for large integers | [JSON-RPC API](../pages/reference/json-rpc-api.md)                                                                 |

The Rust traits retain the names `ReadXDR` and `WriteXDR` for both encodings. Use generated SDK clients and TypeScript bindings for contract payloads; a classic XDR encoder produces different bytes.



## Source Definitions

| Source baseline            | Value                  |
| -------------------------- | ---------------------- |
| Rust protocol package      | `thruput-xdr` `0.61.0` |
| Embedded protocol revision | `hogp/6705996afff00a0` |

| Definition                                                                                                                        | Types                                                                |
| --------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| [transaction.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/transaction.x)     | `Invocation`, `Transaction`, `SignedTransaction`, invocation outputs |
| [types.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/types.x)                 | Addresses, hashes, signatures, protocol scalar types                 |
| [storage_item.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/storage_item.x)   | Storage items and deltas                                             |
| [header.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/header.x)               | Proposal header                                                      |
| [consensus.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/consensus.x)         | Consensus values                                                     |
| [contract_spec.x](https://github.com/thruputchain/thruput-protocol/blob/6705996afff00a07c2eb699233a7a928fd77f715/contract_spec.x) | Contract types, methods, events, and interface metadata              |

---

## Firehose API

Source: <https://thruput.network/reference/firehose/>

Hosted Futurenet WebSocket subscriptions for committed block records, acknowledgements, and resumable replay.

| Surface                   | Contract                                                                                 |
| ------------------------- | ---------------------------------------------------------------------------------------- |
| Hosted Futurenet endpoint | `wss://firehose.thruput.network`                                                         |
| Transport                 | JSON-RPC 2.0 over WebSocket with TLS. Browsers connect directly without a CORS preflight |
| Access                    | No authentication. Public chain data. Experimental, no SLA                               |
| Usage                     | [Consume the Firehose](../pages/guides/consume-the-firehose.md)                          |
| Scope                     | Separate from the JSON-RPC gateway                                                       |



## Methods

| Request convention | Value                                         |
| ------------------ | --------------------------------------------- |
| Protocol           | JSON-RPC 2.0 on the same WebSocket connection |
| Parameters         | Positional arrays                             |

| Method                 | `params`                                               | Result                                                                                                                                          |
| ---------------------- | ------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `firehose_subscribe`   | `[{"from":"height","height":N}]` or `[{"from":"tip"}]` | Transport subscription ID, used for unsubscribe and notification routing                                                                        |
| `firehose_unsubscribe` | `[subscriptionId]`                                     | Removes the transport subscription                                                                                                              |
| `firehose_ack`         | `[subscriberId,height]`                                | `null`. Must acknowledge this connection’s outstanding block; wrong heights, duplicate ACKs, and unknown or foreign subscriber IDs are rejected |
| `firehose_stats`       | `[]`                                                   | Process totals and active subscriber details below                                                                                              |

| Cursor                         | Behavior                                                                                                                                                        |
| ------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `{"from":"height","height":N}` | Inclusive replay from `N`, then follow publications. `0 <= N < 9223372036854775807`. Future heights wait; missing historical records close with `archive_error` |
| `{"from":"tip"}`               | Publications after registration only. Does not replay the current tip                                                                                           |
| JavaScript numbers             | Heights and subscriber IDs are JSON integers. Reject values outside the safe integer range in a client using `JSON.parse`                                       |



## Notifications

| Envelope field        | Value                                                        |
| --------------------- | ------------------------------------------------------------ |
| `jsonrpc`             | `"2.0"`                                                      |
| `method`              | `"firehose_block"` for both block and terminal notifications |
| `params.subscription` | Transport subscription ID, distinct from `subscriberId`      |
| `params.result`       | One of the following tagged payloads                         |

| Block payload field          | Type             | Meaning                                                                                                                      |
| ---------------------------- | ---------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `type`                       | string           | `"block"`                                                                                                                    |
| `subscriberId`               | integer          | Numeric application ID for ACKs on this connection                                                                           |
| `block.schemaVersion`        | integer          | Record format version. Currently `2`                                                                                         |
| `block.height`               | integer          | Committed height                                                                                                             |
| `block.consensusHash`        | base58 string    | Consensus hash contained in the record, not an independent trust anchor                                                      |
| `block.byteLength`           | integer          | Original XDR byte count, before hex or JSON framing                                                                          |
| `block.record`               | hex string       | Exact complete stored XDR record, including consensus value, event logs, and transaction bodies. Canonical `0x`-prefixed hex |
| `block.ingestedAtUnixMicros` | optional integer | Publication timestamp after durable append. Absent on archive reads; outside the commitment                                  |

| Terminal payload field | Type    | Meaning                                                                                            |
| ---------------------- | ------- | -------------------------------------------------------------------------------------------------- |
| `type`                 | string  | `"closed"`. Stop consuming this subscription                                                       |
| `reason`               | string  | Termination reason below                                                                           |
| `nextHeight`           | integer | Inclusive first unacknowledged height. May already have been processed locally if its ACK was lost |

| Close behavior | Contract                                                                                                                        |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Scope          | Application notification, not a WebSocket close frame; other subscriptions can continue                                         |
| Delivery       | Bounded 250 ms enqueue opportunity. A broken or blocked connection can lose this notification; retain a local durable cursor    |
| Ordering       | One outstanding block per subscription. ACK before the next block; heights are ordered without duplicates within a subscription |
| Reconnection   | No exactly-once guarantee across connections. Replay uncertain work idempotently                                                |



## Request errors

| Code / layer     | Message or reason                                                 | Meaning                                                                                                                 |
| ---------------- | ----------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| HTTP 429 (nginx) | Connection limit                                                  | More than 8 concurrent connections from a client IP                                                                     |
| `-32006`         | `Too many subscriptions on the connection`                        | One subscription already exists on this connection. Data: `"Exceeded max limit of 1"`. Existing subscription stays open |
| `-32009`         | `subscriber limit reached`                                        | Global subscriber cap reached                                                                                           |
| `-32009`         | `invalid height`                                                  | Height outside the accepted range                                                                                       |
| `-32009`         | `below_window`                                                    | Requested height below `max(0, tip - 42428)` at attach. No subscription accepted or records sent                        |
| `-32009`         | `subscriber IDs exhausted`                                        | Server cannot allocate another application subscriber ID                                                                |
| `-32009`         | `unknown subscriber`                                              | ACK names no active application subscriber                                                                              |
| `-32009`         | `acknowledgement must match this connection's outstanding height` | Wrong height, duplicate ACK, or ACK from another connection                                                             |



## Cursors and resume

| Rule              | Contract                                                                                                                                                                             |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Serve window      | New height requests must be within 42,428 blocks below tip (about 24 hours at about 2 seconds per block). Boundary and future heights are accepted                                   |
| Available history | Starts when the archive started. No catch-up from genesis or guaranteed historical depth. Store retention is about 7 days, but requests remain limited by the serve window           |
| Moving window     | Accepted subscriptions retain their cursors as the window advances, subject to delivery deadlines                                                                                    |
| Durable progress  | Persist application output and the inclusive replay height together before ACK. After a successful ACK response, persist the next height as the last acknowledged cursor’s successor |
| Uncertain ACK     | Keep the prior replay height if ACK delivery or checkpoint persistence is uncertain. Reapply idempotently; never resume from the last received height alone                          |
| Resume            | Subscribe with `{"from":"height","height":savedReplayHeight}`. A terminal `nextHeight` is the server’s first unacknowledged height, not proof of durable client processing           |
| Expired cursor    | `below_window` requires an explicit recovery decision: restore application state from another source or deliberately start a new tip subscription and accept the gap                 |



## Close Reasons

| Reason                   | Meaning                                                                                  |
| ------------------------ | ---------------------------------------------------------------------------------------- |
| `catchup_timeout`        | Archive-mode send/ACK deadline expired, including the extra deadline after live demotion |
| `catchup_falling_behind` | Archive lag increased across a progress window                                           |
| `archive_timeout`        | Archive read deadline expired                                                            |
| `archive_error`          | Archive record could not be read, including missing history                              |
| `archive_corrupt`        | Record decoding or commitment verification failed                                        |
| `archive_gap`            | Decoded height differs from the requested height                                         |
| `record_too_large`       | Raw record exceeds the configured delivery limit                                         |
| `encoding_error`         | Notification could not be encoded                                                        |
| `height_exhausted`       | Height cannot advance safely                                                             |
| `client_closed`          | Client subscription or transport closed; also recorded in diagnostics                    |



## Delivery Limits

| Hosted admission limit           | Value         |
| -------------------------------- | ------------- |
| Connections per client IP        | 8             |
| Subscriptions per connection     | 1             |
| Global active subscribers        | 12            |
| Largest deliverable block record | 20 MiB        |
| Serve request window             | 42,428 blocks |

| Service flag               | Release default | Hosted Futurenet | Effect                                                                |
| -------------------------- | --------------: | ---------------: | --------------------------------------------------------------------- |
| `--max-subscribers`        |            `64` |             `12` | Global subscription cap; also connection cap                          |
| `--subscriber-queue`       |             `8` |              `8` | Maximum queued live blocks per subscriber                             |
| `--subscriber-queue-bytes` |       `2097152` |        `2097152` | Maximum raw bytes in a live queue                                     |
| `--max-record-bytes`       |       `4194304` |       `20971520` | Maximum deliverable raw record; ingestion can accept larger records   |
| `--live-timeout-ms`        |          `5000` |          `60000` | Live send plus ACK deadline before demotion                           |
| `--catchup-timeout-ms`     |         `10000` |          `60000` | Archive read deadline and, separately, archive send plus ACK deadline |
| `--catchup-progress-ms`    |         `30000` |         `120000` | Window for checking whether archive lag grows                         |



## Statistics

| Result field                                              | Meaning                                                         |
| --------------------------------------------------------- | --------------------------------------------------------------- |
| `currentSubscribers`                                      | Active subscription count                                       |
| `tip`                                                     | Durable archive height, or `-1` before an origin is known       |
| `totals`                                                  | Process-lifetime counters, retained after subscribers leave     |
| `subscribers`                                             | Active subscriber array, bounded by the configured cap          |
| `subscribers[].id`                                        | Application subscriber ID                                       |
| `subscribers[].nextHeight`                                | Inclusive next unacknowledged height                            |
| `subscribers[].lagBlocks`                                 | Lag relative to the durable archive, not the node’s current tip |
| `subscribers[].mode`                                      | `"live"` or `"catchup"`                                         |
| `subscribers[].queuedBlocks`, `subscribers[].queuedBytes` | Live queue occupancy; bytes count raw records                   |
| `subscribers[].counters`                                  | Counters for this active subscriber                             |

| Counter field (in `totals` and `counters`) | Meaning                                                                                      |
| ------------------------------------------ | -------------------------------------------------------------------------------------------- |
| `demotions`                                | Transitions from live delivery to archive catch-up                                           |
| `blocksSent`, `bytesSent`                  | Successful transport enqueues, not confirmed application processing; bytes count raw records |
| `catchupSeconds`                           | Time in catch-up, including disk, send, and ACK waits                                        |
| `disconnects`                              | Counts keyed by termination reason                                                           |
